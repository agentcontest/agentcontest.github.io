package de.tub.mac13.teamb.util;

import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import de.tub.mac13.teamb.ontology.World;
import de.tub.mac13.teamb.ontology.graph.Path;
import de.tub.mac13.teamb.ontology.graph.Vertex;

public class GoodZoneCalculator {
    private int agentCount = 5;
    private World world;
    private EnvironmentInformation env;
    private Zoner zoner;
    private Heater heater;

    public GoodZoneCalculator(World world) {
        this.world = world;
        this.env = new EnvironmentInformation(world);
        this.zoner = new Zoner(world, true);
        this.heater = new Heater(world);
    }

    public int[] calculatePositions() {        
        final LinkedList<Vertex> heatV = heater.getHeatVertices();
        final LinkedList<Vertex> coldV = heater.getHeatVertices(false);
        this.zoner.setStopVertices(coldV);
        final LinkedList<Vertex> filteredHeat = new LinkedList<>();

        for(Vertex v : heatV) {
            for(Vertex w : world.graph.getNeighborsOf(v)) {
                if(!heatV.contains(w)) {
                    filteredHeat.add(v);
                    break;
                }
            }
        }

        Path best = null;
        for(Vertex v : filteredHeat) {
            Queue<Path> paths = env.getPathsToNext(v.id, new PathFilter() {
                @Override
                public boolean matches(Path path) {
                    if(path.getStepCount() == agentCount * 2 - 2) {
                        List<Integer> shortPath = new LinkedList<Integer>();
                        for(int i = 0; i <= path.getPath().size() / 2; i++) {
                            shortPath.add(path.getPath().get(i * 2));
                        }
                        path.setZone(zoner.buildZoneWithIDs(shortPath));
                        
                        return true;
                    }
                    return false;
                }

                @Override
                public boolean accepts(Path path) {
                    Vertex target = path.getTargetVertex();
                    if(path.getStepCount() > agentCount * 2 - 2 || coldV.contains(path.getTargetVertex()))
                        return false;

                    if(!filteredHeat.contains(target) && heatV.contains(target))
                        return false;

                    for(Vertex v : world.graph.getNeighborsOf(target)) {
                        if((path.getStep(path.getStepCount() - 1) != v.id && !(path.getStepCount() == agentCount * 2 - 2 && v.id == path.getStart()))
                                && path.contains(v)) {
                            return false;
                        }
                    }
                    return true;
                }

            }, COMPARE_VALUE, COMPARE_ZONEVALUE);

            Path localBest = paths.peek();
            if(localBest != null && (best == null || best.getZoneValue() < localBest.getZoneValue())) {
                best = localBest;
            }
        }

        if(best == null)
            return null;
        
        int[] result = new int[(best.getStepCount() + 2) / 2];

        for(int i = 0; i < result.length; i++) {
            result[i] = best.getPath().get(i * 2);
        }
        return result;
    }
    
    public int getAgentCount() {
        return agentCount;
    }

    public void setAgentCount(int agentCount) {
        this.agentCount = agentCount;
    }
    
    public Heater getHeater() {
        return this.heater;
    }

    private static final Comparator<Path> COMPARE_VALUE = new Comparator<Path>() {
        @Override
        public int compare(Path p1, Path p2) {
            return p2.getTargetVertex().value - p1.getTargetVertex().value;
        }
    };

    private static final Comparator<Path> COMPARE_ZONEVALUE = new Comparator<Path>() {
        @Override
        public int compare(Path p1, Path p2) {
            return p2.getZoneValue() - p1.getZoneValue();
        }
    };
}
