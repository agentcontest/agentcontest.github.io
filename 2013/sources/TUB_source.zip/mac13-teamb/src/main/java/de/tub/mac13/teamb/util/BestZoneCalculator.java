package de.tub.mac13.teamb.util;

import java.util.LinkedList;
import java.util.List;

import de.tub.mac13.teamb.ontology.graph.Vertex;
import de.tub.mac13.teamb.ontology.graph.Path;
import de.tub.mac13.teamb.ontology.World;

public class BestZoneCalculator {
    private World world;
    private int agentCount = 5;

    private Zoner zoner;
    private Heater heater;

    public BestZoneCalculator(World world) {
        this.world = world;
        this.zoner = new Zoner(world);
        this.heater = new Heater(world);
    }

    public int[] calculateBest() {
        return calculateBest(null);
    }

    public int[] calculateBest(Zone ignore) {
        final LinkedList<Vertex> heatV = heater.getHeatVertices();
        final LinkedList<Vertex> coldV = heater.getHeatVertices(false);
        this.zoner.setStopVertices(coldV);
        final LinkedList<Vertex> filteredHeat = new LinkedList<>();

        for(Vertex v : heatV) {
            for(Vertex w : world.graph.getNeighborsOf(v)) {
                if(!heatV.contains(w)) {
                    filteredHeat.add(v);
                    break;
                }
            }
        }

        Path bestPath = null;
        List<Zone> seenZones = new LinkedList<>();
        if(ignore != null) {
            seenZones.add(ignore);
        }
        
        long time = System.currentTimeMillis();

        for(Vertex v : filteredHeat) {
            List<Path> paths = getPaths(v.id, heatV);
            Path p = calculateBest(paths, seenZones);

            if(p != null && (bestPath == null || bestPath.getZoneValue() < p.getZoneValue())) {
                bestPath = p;
            }
        }

        System.out.println(System.currentTimeMillis() - time);

        if(bestPath != null) {
            int[] result = new int[(bestPath.getStepCount() + 2) / 2];

            for(int i = 0; i < result.length; i++) {
                result[i] = bestPath.getPath().get(i * 2);
            }
            return result;
        }
        return null;
    }

    private Path calculateBest(List<Path> paths, List<Zone> seenZones) {
        Path path = null;

        for(Path p : paths) {
            List<Integer> temp = new LinkedList<>();

            for(int i = 0; i < (p.getPath().size() + 1) / 2; i++) {
                temp.add(p.getPath().get(i * 2));
            }

            boolean notSeen = true;
            for(Zone z : seenZones) {
                if(z.containsIDs(p.getPath())) {
                    notSeen = false;
                    break;
                }
            }

            if(notSeen) {
                p.setZone(zoner.buildZoneWithIDs(temp));
                if(path == null || path.getZoneValue() < p.getZoneValue()) {
                    path = p;
                }
                seenZones.add(p.getZone());
            }
        }

        return path;
    }

    private List<Path> getPaths(int position, List<Vertex> heatV) {
        List<Path> done = new LinkedList<>();
        return getPaths(new Path(position, world), done, heatV);
    }

    private List<Path> getPaths(Path current, List<Path> done, List<Vertex> heatV) {
        List<Path> result = new LinkedList<Path>();
        done.add(current);

        if(current.getStepCount() == agentCount * 2 - 2) {
            result.add(current);
        } else {
            for(Vertex v : world.graph.getNeighborsOf(current.getTargetVertex())) {
                if(!current.contains(v) && (current.getStepCount() == 0 || current.getStep(current.getStepCount() - 1) != v.id) && heatV.contains(v)) {

                    boolean next = true;
                    for(Vertex w : world.graph.getNeighborsOf(v)) {
                        if(current.contains(w) && current.getStep(current.getStepCount()) != w.id) {
                            next = false;
                        }
                    }

                    if(next) {
                        Path path = new Path(current);
                        path.addStep(v.id);
                        if(!done.contains(path)) {
                            result.addAll(getPaths(path, done, heatV));
                        }
                    }
                }
            }
        }

        return result;
    }

    public int getAgentCount() {
        return agentCount;
    }

    public void setAgentCount(int agentCount) {
        this.agentCount = agentCount;
    }
}
