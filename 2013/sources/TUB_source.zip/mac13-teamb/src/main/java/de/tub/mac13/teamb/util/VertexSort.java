package de.tub.mac13.teamb.util;

import java.util.ArrayList;
import de.tub.mac13.teamb.ontology.graph.Graph;
import de.tub.mac13.teamb.ontology.graph.Vertex;

/**
 * Sotiert Knoten nach Abstand
 *
 * @author
 * @version 0.1
 */
public class VertexSort {

    public static Vertex[] sort(int[] distancesMap, Graph g) {
        ArrayList<Integer> lookup = sort(distancesMap, initLookup(distancesMap));

        Vertex[] result = new Vertex[distancesMap.length];
        for (int i = 0; i < result.length; i++) {
            result[i] = g.getVertex(lookup.get(i));
        }
        return result;
    }

    static ArrayList<Integer> sort(int[] distancesMap, ArrayList<Integer> lookup) {
        if (lookup.isEmpty()) {
            return lookup;
        }
        int pivot = lookup.size() / 2;
        ArrayList<Integer> equal = new ArrayList<Integer>();
        ArrayList<Integer> lesser = new ArrayList<Integer>();
        ArrayList<Integer> greater = new ArrayList<Integer>();

        for (int k = 0; k < lookup.size(); k++) {
            if (distancesMap[lookup.get(k)] < distancesMap[lookup.get(pivot)]) {
                lesser.add(lookup.get(k));
            } else if (distancesMap[lookup.get(k)] > distancesMap[lookup.get(pivot)]) {
                greater.add(lookup.get(k));
            } else if (k != pivot) {
                equal.add(lookup.get(k));
            }
        }
        lesser = sort(distancesMap, lesser);
        if (greater.size() > 1) {
            greater = sort(distancesMap, greater);
        }

        ArrayList<Integer> sorted = new ArrayList<Integer>(lookup.size());
        for (int number : lesser) {
            sorted.add(number);
        }

        for (int number : equal) {
            sorted.add(number);
        }
        sorted.add(lookup.get(pivot));


        for (int number : greater) {
            sorted.add(number);
        }
        return sorted;
    }

    private static ArrayList<Integer> initLookup(int[] src) {
        ArrayList<Integer> lookup = new ArrayList<Integer>(src.length);

        for (int i = 0; i < src.length; i++) {
            lookup.add(i);
        }
        return lookup;
    }
}
