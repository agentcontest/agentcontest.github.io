package de.tub.mac13.teamb.ontology.graph;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import javax.swing.event.EventListenerList;

public class Graph implements Serializable {

    private static final long serialVersionUID = -921948951192741407L;
    private EventListenerList listener = new EventListenerList();
    private Vertex[] vertices;
    private Edge[][] edges;

    //UI Stuff
    public static final int ADDED_VERT = 0x3;
    public static final int ADDED_EDGE = 0x7;
    public static final int UPDATED_VERT = 0xa;
    public static final int UPDATED_EDGE = 0xc;

    public Graph(int verts) {
        vertices = new Vertex[verts];
        edges = new Edge[verts][verts];
    }

    public Edge[][] getEdgesAsArray() {
        return edges;
    }

    public Vertex[] getVerticesAsArray() {
        return vertices;
    }

    public void setVerticesArray(final Vertex[] vertices) {
        this.vertices = vertices;
    }

    public void setEdgesArray(final Edge[][] edges) {
        this.edges = edges;
    }

    public void addVertex(int id) {
        if(vertices[id] == null) {
            return;
        }
        vertices[id] = new Vertex(id);
        notify(new ActionEvent(vertices[id], ADDED_VERT, null));
    }

    public void addVertex(Vertex vertex) {
        if(vertex != null && !existsVertex(vertex)) {
            vertices[vertex.id] = vertex;
            notify(new ActionEvent(vertex, ADDED_VERT, null));
        } else {
            Vertex v = vertices[vertex.id];
            v.merge(vertex);
            vertices[vertex.id] = v;
            notify(new ActionEvent(vertex, UPDATED_VERT, null));
        }

    }

    public void addEdge(Edge e) {
        if(e != null && !existsEdge(e)) {
            edges[e.node1][e.node2] = e;
            edges[e.node2][e.node1] = e;
            notify(new ActionEvent(e, ADDED_EDGE, null));
        } else {
            edges[e.node1][e.node2].merge(e);
            edges[e.node2][e.node1].merge(e);
            notify(new ActionEvent(e, UPDATED_EDGE, null));
        }
    }

    public Vertex getVertex(int id) {
        // Look for vertex
        if(vertices[id] != null) {
            return vertices[id];
        }

        // if not found, create new Vertex
        Vertex v = new Vertex(id);
        vertices[id] = v;
        return v;
    }

    public Edge getEdge(int id1, int id2) {
        return edges[id1][id2];
    }

    public Edge getEdge(Vertex node1, Vertex node2) {
        return getEdge(node1.getId(), node2.getId());
    }

    public ArrayList<Vertex> getNeighborsListOf(Vertex vertex) {
        return getNeighborsListOf(vertex.id);
    }

    public ArrayList<Vertex> getNeighborsListOf(int vertexID) {
        Edge[] con = edges[vertexID];
        ArrayList<Vertex> vert = new ArrayList<>();
        for(Edge e : con) {
            if(e != null) {
                if(e.node1 == vertexID) {
                    vert.add(vertices[e.node2]);
                } else {
                    vert.add(vertices[e.node1]);
                }
            }
        }
        return vert;
    }


    public Vertex[] getNeighborsOf(Vertex vertex) {
        return getNeighborsOf(vertex.id);
    }
    
    public Vertex[] getNeighborsOf(int vertexID) {
        ArrayList<Vertex> vertList = getNeighborsListOf(vertexID);
        return vertList.toArray(new Vertex[vertList.size()]);
    }

    private boolean existsVertex(Vertex other) {
        return vertices[other.id] != null;
    }

    private boolean existsEdge(Edge other) {
        return edges[other.node1][other.node2] != null;
    }

    private void notify(ActionEvent e) {
        for(ActionListener ac : listener.getListeners(ActionListener.class)) {
            ac.actionPerformed(e);
        }
    }

    public void add(ActionListener ac) {
        listener.add(ActionListener.class, ac);
    }

    public Collection<Edge> getEdges() {
        //FIXME should be cached?
        HashMap<Integer, Edge> edges = new HashMap<>();
        Edge e;
        for(int i = 0; i < this.edges.length; i++) {
            for(int j = 0; j < this.edges.length; j++) {
                e = this.edges[i][j];
                if(e != null && !edges.containsKey(e.hashCode())) {
                    edges.put(e.hashCode(), e);
                }
            }
        }
        return edges.values();
    }

    public Collection<Vertex> getVertices() {
        LinkedList<Vertex> list = new LinkedList<>();
        for(Vertex v : this.vertices) {
            if(v != null) {
                list.add(v);
            }
        }
        return list;
    }

    public HashMap<Integer, Vertex> getVerticesHashmap() {
        HashMap<Integer, Vertex> verts = new HashMap<>();
        for(Vertex v : this.vertices) {
            if(v != null) {
                verts.put(v.getId(), v);
            }
        }
        return verts;
    }

    public int getVertexCount() {
        return vertices.length;
    }

    public ArrayList<Edge> getEdgesOfVertex(Vertex v) {
        return getEdgesOfVertex(v.id);
    }

    public ArrayList<Edge> getEdgesOfVertex(int id) {
        Edge[] con = edges[id];
        ArrayList<Edge> edges = new ArrayList<>();
        for(Edge e : con) {
            if(e != null) {
                edges.add(e);
            }
        }
        edges.trimToSize();
        return edges;
    }

    public void free() {
        listener = new EventListenerList();
        edges = null;
        vertices = null;
    }
}
