package de.tub.mac13.teamb.strategy;

import de.tub.mac13.teamb.bean.DefaultDecisionBean;
import de.tub.mac13.teamb.ontology.Agent;
import de.tub.mac13.teamb.ontology.Entity;
import de.tub.mac13.teamb.ontology.Goal;
import de.tub.mac13.teamb.ontology.Intention;
import de.tub.mac13.teamb.ontology.enums.AgentRole;
import de.tub.mac13.teamb.ontology.enums.TeamType;
import de.tub.mac13.teamb.ontology.graph.Path;
import de.tub.mac13.teamb.ontology.graph.Vertex;
import de.tub.mac13.teamb.util.EnvironmentInformation;
import de.tub.mac13.teamb.util.strategyhelper.Annoy;
import de.tub.mac13.teamb.util.PathFilter;

import java.util.*;

public class AnnoyingInspectorStrategy extends RandomStrategy {
    // TODO Implement Inspector same as Random

    private static final int OFFSET = 20;

    Random rand = new Random();
    EnvironmentInformation pPlan;
    BaseStrategy base;
    Annoy annoy = new Annoy();

    HashSet<Integer> noGoList = new HashSet<>();

    public AnnoyingInspectorStrategy(DefaultDecisionBean decider, String username) {
        super(decider, username);
        base = new BaseStrategy(decider,username);
        pPlan = base.pPlan;
    }

    public Goal getGoal(){
        noGoList.clear();

        Goal goal = base.getGoal();
        //end of base
        if(goal == null){
            //Collision prevention
            for(String agent:world.teamGoals.keySet()){
                if(!agent.matches(world.username)){
                    Goal g = world.teamGoals.get(agent);
                    noGoList.add(g.getTargetVertex());
                }
            }


            for(Agent agent:world.team.values()){
                if(agent.role == world.self.role && world.self.id < agent.id ){
                    if(agent.position == world.self.position){
                        Goal g = new Goal();
                        Vertex[] vertexes = world.graph.getNeighborsOf(world.self.position);
                        Vertex id = vertexes[rand.nextInt(vertexes.length)];
                        g.setTargetVertex(id.getId());
                        g.addFirstIntention(goToVertex(id));
                        return g;
                    }
                }
            }

            //inspecting
            boolean inspect = false;
            for(Entity e:world.enemyAgents.values()){
                if(e.position != null){
                    if(e.position.id == world.self.position){
                        if(e.lastInspect+OFFSET < world.step){
                            inspect = true;
                            break;
                        }
                    }
                }
            }
            if(inspect){
                getLog().info("inspecting @"+world.self.position);
                return new Goal(inspect());
            }
            Queue<Path> result = pPlan.getPathsToNextSorted(enemyFilter,comp);
            if(!result.isEmpty()){
                Path p = result.poll();

                if(p.getTarget() == world.self.position){
                    return new Goal(inspect());
                }

                getLog().info("planing to use path:"+p);

                Goal plan = new Goal();
                plan.addFirstIntention(goToVertex(p.getFirstStep()));
                plan.setTargetVertex(p.getTarget());
                return plan;
            }
            getLog().info("lets try to annoy!");
            Path p = pPlan.getPathToNext(annoy.getFilter(world,TeamType.ENEMY,noGoList));
            if(p != null && p.getStepCount() > 0){
                Goal plan = new Goal();
                plan.addFirstIntention(goToVertex(p.getFirstStep()));
                plan.setTargetVertex(p.getTarget());
                return plan;
            }

        } else {
            getLog().info("Using Base Strategy");
            return goal;
        }

        //Now then lets find us a luster of enemies sort them by distance ..
        // avoid dublicading the same thing a difrent inspector dose
        // inspect inspect ....
        // if nothig else is to be done move on to a node that is
        // controlled by the enmey but with noe enemy agent on it
        // therfore disrubting a zone

        getLog().error("Using Fallback!!");
        return super.getGoal();
    }

    PathFilter enemyFilter = new PathFilter() {
        @Override
        public boolean matches(Path p) {
            if(p != null) {
                int vid = p.getTarget();
                if(noGoList.contains(vid)){
                    return false;
                }
                for(Entity e : world.enemyAgents.values()) {
                    if(vid == e.position.id) {
                        if(e.lastInspect+OFFSET < world.step){
                            return true;
                        }
                    }
                }
            }
            return false;
        }

    };

    Comparator<Path> comp = new Comparator<Path>() {
        @Override
        public int compare(Path o1, Path o2) {
            Entity e1 = null,e2 = null;
            if(o1 != null) {
                int vid = o1.getTarget();
                for(Entity e : world.enemyAgents.values()) {
                    if(vid == e.position.id) {
                        e1 = e;
                    }
                }
            }
            if(o2 != null) {
                int vid = o2.getTarget();
                for(Entity e : world.enemyAgents.values()) {
                    if(vid == e.position.id) {
                        e2 = e;
                    }
                }
            }
            if(o1 != null && o2 != null){
                return Integer.compare(o1.getCost(),o2.getCost());
            }
            if(e1 != null && e2 != null){
                return Integer.compare(e1.lastInspect,e2.lastInspect);
            }
            return 0;
        }
    };

	@Override
    public String toString() {
        return "InspectorStrategy";
    }
}
