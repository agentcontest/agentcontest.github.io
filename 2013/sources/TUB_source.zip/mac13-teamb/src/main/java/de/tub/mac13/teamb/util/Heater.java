package de.tub.mac13.teamb.util;

import java.util.LinkedList;

import de.tub.mac13.teamb.ontology.World;
import de.tub.mac13.teamb.ontology.graph.Vertex;

public class Heater {
    private int layer = 1;
    private float heatMin = 0.5f;
    private World world;

    public Heater(World world) {
        this.world = world;
    }

    public Heater(World world, int layerCount) {
        this.world = world;
        this.layer = layerCount;
    }

    public void setLayerCount(int layerCount) {
        this.layer = layerCount;
    }

    public int getLayerCount() {
        return layer;
    }

    public void setHeatMin(float heatMin) {
        this.heatMin = heatMin;
    }

    public float getHeatMin() {
        return heatMin;
    }
    
    public LinkedList<Vertex> getHeatVertices() {
        return getHeatVertices(true);
    }

    public LinkedList<Vertex> getHeatVertices(boolean hot) {

        LinkedList<Vertex> result = new LinkedList<>();
        int[] values = new int[world.graph.getVerticesAsArray().length];

        for(int i = 0; i < layer; i++) {
            values = addLayer(values, result, hot);
        }

        return result;
    }

    private int[] addLayer(int[] values, LinkedList<Vertex> verts, boolean hot) {
        int avg = 0;
        int highest = 0;

        int[] result = new int[values.length];

        for(int i = 0; i < result.length; i++) {
            Vertex v = world.graph.getVertex(i);
            if(values[i] == 0) {
                if(v.value != -1) {
                    result[i] = v.value;

                    for(Vertex w : world.graph.getNeighborsOf(v)) {
                        if(w.value != -1) {
                            result[i] += w.value;
                        }
                    }

                    avg += result[i];
                    if(highest < result[i]) {
                        highest = result[i];
                    }
                }
            } else {
                result[i] = values[i];
                for(Vertex w : world.graph.getNeighborsOf(v)) {
                    result[i] += values[w.id];
                }

                avg += result[i];
                if(highest < result[i]) {
                    highest = result[i];
                }
            }
        }

        for(Vertex v : world.graph.getVerticesAsArray()) {
            if(hot) {
                if(result[v.id] > (1 + heatMin) * avg / world.graph.getVerticesAsArray().length) {
                    if(!verts.contains(v))
                        verts.add(v);
                }
            }else {
                if(result[v.id] < heatMin * avg / world.graph.getVerticesAsArray().length) {
                    if(!verts.contains(v))
                        verts.add(v);
                }
            }
        }

        return result;
    }
}
