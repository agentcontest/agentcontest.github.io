package de.tub.mac13.teamb.strategy;

import de.tub.mac13.teamb.bean.DefaultDecisionBean;
import de.tub.mac13.teamb.ontology.Agent;
import de.tub.mac13.teamb.ontology.Entity;
import de.tub.mac13.teamb.ontology.Goal;
import de.tub.mac13.teamb.ontology.Intention;
import de.tub.mac13.teamb.ontology.enums.AgentRole;
import de.tub.mac13.teamb.ontology.enums.TeamType;
import de.tub.mac13.teamb.ontology.graph.Path;
import de.tub.mac13.teamb.ontology.graph.Vertex;
import de.tub.mac13.teamb.util.EnvironmentInformation;
import de.tub.mac13.teamb.util.PathFilter;

import java.util.Queue;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Random;

public class BaseStrategy extends RandomStrategy {
    public EnvironmentInformation pPlan;


    public BaseStrategy(DefaultDecisionBean decider, String username) {
        super(decider, username);
        pPlan = new EnvironmentInformation(world);
    }

    public Goal getGoal(){

        //recharge if low
        if(world.self.energy < 2){
            getLog().info("recharge");
            return new Goal(recharge());
        }

        //request Heal
        if(world.self.health == 0){
            getLog().info("health is low");
            Queue<Path> result = pPlan.getPathsToNext(FIND_REPAIRER_DIS_PATHS, COMP);
            if(result != null && !result.isEmpty()){
                Path p = result.poll();
                return new Goal(goToVertex(p.getFirstStep()));
            }
        }

        //end of base


        return null;
    }
    
    protected final PathFilter FIND_REPAIRER_DIS_PATHS = new PathFilter() {
        @Override
        public boolean matches(Path p) {
            if(p != null) {
                for(Agent s : world.team.values()) {
                    // we don't wont to find us!
                    if(s.id == world.self.id) {
                        continue;
                    }
                    if(s.role == AgentRole.REPAIRER && s.position == p.getTarget()) {
                        return true;
                    }
                }
            }
            return false;
        }

        @Override
        public boolean accepts(Path p){
           return p.getHighestStepCost() <= world.self.maxEnergyDisabled;
        }
       };
       
       
       protected final Comparator<Path> COMP = new Comparator<Path>() {
        @Override
        public int compare(Path o1, Path o2) {
            return Integer.compare(o1.getCost(),o2.getCost());
        }
       };
}
