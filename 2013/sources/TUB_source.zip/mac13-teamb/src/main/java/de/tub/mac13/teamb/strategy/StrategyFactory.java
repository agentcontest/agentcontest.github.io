package de.tub.mac13.teamb.strategy;

import de.tub.mac13.teamb.bean.DefaultDecisionBean;
import de.tub.mac13.teamb.ontology.World;
import de.tub.mac13.teamb.ontology.enums.AgentRole;

public class StrategyFactory {

    public static DecisionStrategy createStrategy(World w, String username, DefaultDecisionBean d) {
        AgentRole role = w.self.role;
        int id = w.id;
        switch (role) {
            case EXPLORER:
                return new ExplorerStrategy(username, d);
            case REPAIRER:
                if(id%3 == 0){
                    return new CravenRepairer(username,d);
                } else {
                    return new RepairerStrategy(d,username);
                }
            case SABOTEUR:
                if(id%4 == 0){
                    return new ZoneDefenderStrategy(d, username);
                } else {
                    return new SaboteurStrategy(d,username);
                }
            case SENTINEL:
            	return new SentinelStrategy(d, username);
            case INSPECTOR:
                return new AnnoyingInspectorStrategy(d, username);
            default:
                return new RandomStrategy(d, username);
        }
    }
}
