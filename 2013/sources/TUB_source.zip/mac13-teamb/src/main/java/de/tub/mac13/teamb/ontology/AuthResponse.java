package de.tub.mac13.teamb.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;

public class AuthResponse implements IFact {

    private static final long serialVersionUID = 7319877492282137288L;
    private boolean authSuccessful = false;

    public AuthResponse(boolean successful) {
        this.authSuccessful = successful;
    }

    public void setAuthSuccessful(boolean successful) {
        this.authSuccessful = successful;
    }

    public boolean isAuthSuccessful() {
        return authSuccessful;
    }
}
