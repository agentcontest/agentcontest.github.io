/**
 * 
 */
package de.tub.mac13.teamb.util;

import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;

import de.tub.mac13.teamb.ontology.graph.Edge;
import de.tub.mac13.teamb.ontology.graph.Graph;
import de.tub.mac13.teamb.ontology.graph.Vertex;

/**
 * @author Sebastian
 *
 */
public class GraphAnalytics {
	
	private Graph graph;
	
	public GraphAnalytics(Graph graph) {
		this.graph = graph;
	}
	
	public boolean isFullyKnown(){
		return isFullyKnown(graph);
	}
	
	public boolean isFullyProbed(){
		return isFullyProbed(graph);
	}
	
	
	public int getHighesVertex(){
		return getHighesVertex(graph.getVertices());
	}
	

	
	public Vertex[] getHeightsPairVertex(){
		return getHeightsPairVertex(graph.getVertices(),graph);
	}
	
	public static HashSet<Vertex> makeZoneSet(Vertex v,Graph g){
		HashSet<Vertex> zoneSet = new HashSet<>();
		synchronized (g) {
			zoneSet.add(v);
			zoneSet.addAll(g.getNeighborsListOf(v));
			for(Vertex neighbor:zoneSet){
				zoneSet.addAll(g.getNeighborsListOf(neighbor));
			}
			zoneSet.remove(v);
			return zoneSet;
		}
	}
	
	/**
	 * Thats quite the hacked function!
	 * what it dose is it finds the Nodes with the heights value
	 * if there multiple it will find all of them.
	 * it then will build a Set of 2 step distanced neighbors of each of those Nodes
	 * and look for the highest valued Node in that set. 
	 * the set with the tow Highest valued Nodes will be retuned. 
	 * (theoreticly it can be used to  create a good Zone)
	 * @return
	 */
	public static Vertex[] getHeightsPairVertex(Collection<Vertex> nodes,Graph graph){
		Vertex[] pair = new Vertex[2];
		List<Vertex> verts = getHighesVertexList(nodes);
		HashSet<Vertex> zoneSet = null;
		int vMax = 0;
		for(Vertex possible:verts){
			zoneSet = makeZoneSet(possible,graph);
			
			int vid = getHighesVertex(zoneSet);
			int vValue = graph.getVertex(vid).value;
			if(vMax < vValue){
				pair[0] = possible;
				pair[1] = graph.getVertex(vid);
				vMax = vValue;
			}
			
		}
		
		return pair;
	}
	

	public static boolean isFullyKnown(Graph graph){
		Collection<Vertex> vertList = graph.getVertices();
		if(vertList.size() < graph.getVertexCount()){
			return false;
		}
		for(Vertex v:vertList){
			if(v.value == -1){
				return false;
			}
		}
		for(Edge e:graph.getEdges()){
			if(e.getWeight() == Integer.MAX_VALUE){
				return false;
			}
		}
		return true;
	}
	
	public static boolean isFullyProbed(Graph graph){
		Collection<Vertex> vertList = graph.getVertices();
		if(vertList.size() < graph.getVertexCount()){
			return false;
		}
		for(Vertex v:vertList){
			if(v.value == -1){
				return false;
			}
		}
		return true;
	}
	
	/**
	 * @param knowenNodes list of knowenNodes
	 * @return the id of a Node witch has the highest value of all 
	 * known nodes. If there are multiple Nodes with the same value
	 * no guaranty will be made as to witch ID will be returned.
	 * If no node can be found -1 will be returned as ID.
	 * 
	 */
	public static int getHighesVertex(Collection<Vertex> knowenNodes){
		Vertex vMax = null; int wMax = Integer.MIN_VALUE;
		for(Vertex v:knowenNodes){
			if(wMax < v.value){
				wMax  = v.value;
				vMax  = v;
			}
		}
		if(vMax != null){
			return vMax.id;
		} else {
			return -1;
		}
	}
	
	/**
	 * @param knowenNodes list of knowenNodes
	 * @return the Vertex that has the highest value of all 
	 * known nodes. If there are multiple Nodes with the same value
	 * all will be retuned.
	 * If no node can be found null will be returned .
	 * 
	 */
	public static List<Vertex> getHighesVertexList(Collection<Vertex> knowenNodes){
		int wMax = Integer.MIN_VALUE;
		LinkedList<Vertex> vMaxList = null;
		for(Vertex v:knowenNodes){
			if(wMax < v.value){
				wMax  = v.value;
				vMaxList = new LinkedList<>();
				vMaxList.add(v);
			} else if(wMax == v.value){
				vMaxList.add(v);
			}
		}
		if(vMaxList != null){
			return vMaxList;
		} else {
			return null;
		}
	}
	
	private void swap(Vertex[] list,int i,int j){
		Vertex v = list[i];
		list[i] = list[j];
		list[j] = v;
	}
	
	private int partition(Vertex[] list,int left,int right,int pivotIndex){
		Vertex pivotValue = list[pivotIndex];
		swap(list,pivotIndex,right);
		int storeIndex = left;
		for(int i = left;i<right;i++){
			if(list[i] == null){ continue;}
			if(list[i].value < pivotValue.value){
				swap(list,storeIndex,i);
			}
		}
		swap(list,right,storeIndex);
		return storeIndex;
	}
	
	/**
	 * retunes the k-th smalles Vertex(value) of the given Vertex[]
	 * <b>WARINING</b> the list parameter will be modified!
	 * @param list
	 * @param left
	 * @param right
	 * @param k
	 * @return
	 */
	@SuppressWarnings("unused")
	private Vertex select(Vertex[] list,int left,int right,int k){
		 if(left == right){
			 return list[left];
		 } 
		 int pivotIndex = (right-left)/2;
		 int pivotNewIndex = partition(list, left, right, pivotIndex);
	     int pivotDist = pivotNewIndex - left + 1;

	     if(pivotDist == k){
	    	 return list[pivotNewIndex];
	     } else if (k < pivotDist){
	         return select(list, left, pivotNewIndex - 1, k);
	     } else {
	    	 return select(list, pivotNewIndex + 1, right, k - pivotDist);
	     }
	         
	}
	
}
