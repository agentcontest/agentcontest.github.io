package de.tub.mac13.teamb.ontology.enums;

public enum ActionResult {
	SUCCESS("successful"), RANDOM("failed random"), NOACTION("failed"), TARGET_ESCAPED(
			"failed away"), TARGET_BLOCKED("failed parry"), NOMONEY(
			"failed limit"), LOWENERGY("failed resources"), KIA(
			"failed attacked"), WRONG_ACTION("failed role"), DISABLED(
			"failed status"), WRONG_PARAM("failed wrong param"),UNKNOWN("UNKNOWN"),
            USELESS("useless"),UNREACHABLE("failed ureachable"),OUTOFRANGE("out of range"),
            PARRIED("parried"),INRANGE("failed_in_range");

	private String value;

	private ActionResult(String value) {
		this.value = value;
	}

	public String toString() {
		return value;
	}
	

	public static ActionResult getByString(String s) {
		switch (s) {
		case "successful":
			return SUCCESS;
		case "failed_random":
			return RANDOM;
		case "failed":
			return NOACTION;
		case "failed_away":
			return TARGET_ESCAPED;
		case "failed_parry":
			return TARGET_BLOCKED;
		case "failed_limit":
			return NOMONEY;
		case "failed_resources":
			return LOWENERGY;
		case "failed_attacked":
			return KIA;
		case "failed_role":
			return WRONG_ACTION;
        case "failed_ureachable":
            return UNREACHABLE;
        case "failed_out_of_range":
            return OUTOFRANGE;
		case "failed_status":
			return DISABLED;
        case "failed_wrong_param":
            return WRONG_PARAM;
        case "failed_parried":
            return PARRIED;
        case "failed_in_range":
            return INRANGE;
        case "useless":
            return USELESS;
		default:
            System.err.println(s);
			return UNKNOWN;
		}
	}
}
