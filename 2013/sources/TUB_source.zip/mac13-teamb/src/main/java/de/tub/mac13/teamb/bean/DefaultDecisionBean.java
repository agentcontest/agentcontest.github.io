package de.tub.mac13.teamb.bean;

import org.w3c.dom.Document;

import de.dailab.jiactng.agentcore.IAgentBean;
import de.dailab.jiactng.agentcore.action.AbstractMethodExposingBean;
import de.dailab.jiactng.agentcore.action.Action;
import de.dailab.jiactng.agentcore.comm.ICommunicationAddress;
import de.dailab.jiactng.agentcore.comm.IGroupAddress;
import de.dailab.jiactng.agentcore.comm.message.IJiacMessage;
import de.tub.mac13.teamb.Constants;
import de.tub.mac13.teamb.connection.ActionFactory;
import de.tub.mac13.teamb.ontology.Goal;
import de.tub.mac13.teamb.ontology.Intention;
import de.tub.mac13.teamb.ontology.Order;
import de.tub.mac13.teamb.ontology.Perception;
import de.tub.mac13.teamb.ontology.World;
import de.tub.mac13.teamb.strategy.DecisionStrategy;
import de.tub.mac13.teamb.strategy.StrategyFactory;

public class DefaultDecisionBean extends AbstractMethodExposingBean{

    private World world;
    private Perception perception;
    
    private DecisionStrategy strategy;
    
    IGroupAddress teamChannel;
    PerceptionBean perceptionBean;
    ServerCommunicationBean serverCommunicationBean;
    Action sendAction;
    public Intention intention;

    public void setWorld(World world) {
        this.world = world;
        if (world == null) {
            this.strategy = null;
        } else {
            this.strategy = StrategyFactory.createStrategy(world,
                    world.username, this);
        }
    }

    public DecisionStrategy getStrategy() {
        return strategy;
    }
    
    public void switchStrategy(DecisionStrategy newStrategy){
    	if(newStrategy != null){
    		newStrategy.setFallback(strategy);
    		this.strategy = newStrategy;
    	}
    }

    public String getStrategyName() {
        if (strategy == null) {
            return "NO Strategy";
        } else {
            return strategy.toString();
        }
    }

    public World getWorld() {
        return this.world;
    }

    public Perception getPerception() {
        return perception;
    }

    public void setPerception(Perception perception) {
        this.perception = perception;
    }

    @Override
    public void doStart() {
    	//System.out.println("start");
        for (IAgentBean ab : thisAgent.getAgentBeans()) {
            if (ab instanceof PerceptionBean) {
                this.perceptionBean = ((PerceptionBean) ab);
                this.teamChannel = perceptionBean.teamChannel;
            }
            if (ab instanceof ServerCommunicationBean) {
                this.serverCommunicationBean = (ServerCommunicationBean) ab;
            }
        }
        // retrieving needed actions from own CommunicationBean
        sendAction = memory.read(new Action(
                "de.dailab.jiactng.agentcore.comm.ICommunicationBean#send",
                null, new Class[]{IJiacMessage.class,
            ICommunicationAddress.class}, null));
        if (sendAction == null) {
            throw new RuntimeException("Could not find Communication...1");
        }
    }
    
    public void decide() {
        long t1 = System.currentTimeMillis();
        Intention intention = null;
        Goal goal = null;
        // TODO fallback to random? instead of SKIP?
        if (this.strategy == null) { // fallback
            intention = new Intention(Constants.ACTION_SKIP, null);
            goal = new Goal(intention);
        } else {
        	try{
        		goal = this.strategy.getGoal();
        	} catch(Exception e){
        		log.fatal(String.format("Agent:%s Strategy broke down!!!", getWorld().username), e);
        	}
            
        }

        if (goal == null){// no decision could be reached
        	intention = new Intention(Constants.ACTION_SKIP, null);
        	goal = new Goal(intention);
            log.error(String
                    .format("Agent:%s:%s Strategy Failed to deliver an Intention! (%s)",
                    getWorld().username, getWorld().self.role,
                    strategy.toString()));
        }
        if(goal.getIntentions().isEmpty()){
            log.error("NO VALID GOAL INTENTION");
        }

        long decisionTime = System.currentTimeMillis() - t1;
        if(decisionTime < Constants.WTIME && Constants.WAIT){
            try {
                Thread.sleep(Constants.WTIME -decisionTime);
            } catch (InterruptedException e) {}
        }

        brodcastGoal(goal);
        //TODO wait for all agents to make a decison and revaulate?
        sendActionResponse(goal);
        long t2 = System.currentTimeMillis();
        if ((t2 - t1) > 2000) {
            log.error(String.format("%s ,too long decision!!! (%d)",
                    world.username, (t2 - t1)));
        }
    }
    
    public void brodcastIntention(Intention it) {
        it.username = (world != null) ? world.username : "NONE";
        perceptionBean.sendIntention(it);
    }
    
    
    public void brodcastGoal(Goal goal) {
        goal.setUsername((world != null) ? world.username : "NONE");
        perceptionBean.sendGoal(goal);
    }   
    
    public void broadcastOrder(Order order) {
        perceptionBean.sendOrder(order);
    }  
    
    public void sendActionResponse(Goal goal) {
        try {
        	//kill the sender thread either this method was invoked by sender or
        	//a new consensus could be reached and the sender is no longer necessary!
        	
        	
        	Intention intention = goal.getIntentions().getFirst();
        	//System.out.println(world.username + ": " + intention);
            Document response = ActionFactory.getAction(intention.action,
                    intention.param, getWorld().id);
            serverCommunicationBean.sendActionResponse(response);
            intention.send = true;
            brodcastIntention(intention);
            
            //brodcastGoal(goal);

        } catch (NullPointerException e) {
            e.printStackTrace();
            log.error("agent: " + getWorld().username + ":" + getWorld().self.role,e);
        }
    }
}