package de.tub.mac13.teamb.util;

import de.tub.mac13.teamb.ontology.graph.Path;

public abstract class PathFilter implements Filter<Path> {

    /**
     * should be used to check, if a path has the right criteria. For example:
     * don't walk over enemy territory
     *
     * @param path
     * @return
     */
    public boolean accepts(Path path) {
        return true;
    }
}
