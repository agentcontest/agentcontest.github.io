package de.tub.mac13.teamb.ontology;

import java.util.LinkedList;
import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac13.teamb.ontology.enums.ActionResult;
import de.tub.mac13.teamb.ontology.enums.AgentRole;
import de.tub.mac13.teamb.ontology.enums.StrategyType;
import de.tub.mac13.teamb.ontology.graph.Edge;
import de.tub.mac13.teamb.ontology.graph.Vertex;

public class Perception implements IFact {

    private static final long serialVersionUID = 8856781490395163392L;
    public String username;
    public long timestamp;
    public int id;
    public long deadline;
    public String lastAction;
    public String lastActionParam;
    public ActionResult lastActionResult;
    
    public int energy;
    public int health;
    public int maxEnergy;
    public int maxEnergyDisabled;
    public int maxHealth;
    public int position;
    public int strength;
    public int visRange;
    public int zoneScore;
    public Team team = new Team();
    public LinkedList<Vertex> vertices = new LinkedList<>();
    public LinkedList<Edge> edges = new LinkedList<>();
    public LinkedList<Entity> entities = new LinkedList<>();
    public AgentRole role;
    public StrategyType strategy;

    public Perception(String username) {
        this.username = username;
    }

    public void add(Vertex v) {
        int index = vertices.indexOf(v);
        if (index != -1) {
            Vertex vi = vertices.remove(index);
            vi.merge(v);
            vertices.add(vi);
        } else {
            vertices.add(v);
        }
    }

    public void add(Edge e) {
        int index = edges.indexOf(e);
        if (index != -1) {
            Edge ei = edges.remove(index);
            ei.merge(e);
            edges.add(ei);
        } else {
            edges.add(e);
        }
    }

    public void add(Entity e) {
        int index = entities.indexOf(e);
        if (index != -1) {
            Entity ei = entities.remove(index);
            ei.merge(e);
            entities.add(ei);
        } else {
            entities.add(e);
        }
    }
}
