package de.tub.mac13.teamb.util;

import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Comparator;

import de.tub.mac13.teamb.ontology.World;
import de.tub.mac13.teamb.ontology.enums.TeamType;
import de.tub.mac13.teamb.ontology.graph.Path;
import de.tub.mac13.teamb.ontology.graph.Vertex;

public class Zoner {
    private World world;
    private EnvironmentInformation env;
    private boolean ignoreEnemy = false;
    private List<Vertex> stopVertices = null;

    public Zoner(World world) {
        this.world = world;
        this.env = new EnvironmentInformation(world);
    }

    public Zoner(World world, boolean ignoreEnemy) {
        this.world = world;
        this.env = new EnvironmentInformation(world);
        this.ignoreEnemy = ignoreEnemy;
    }

    public Zoner(World world, boolean ignoreEnemy, List<Vertex> stopVertices) {
        this.world = world;
        this.env = new EnvironmentInformation(world);
        this.ignoreEnemy = ignoreEnemy;
        this.stopVertices = stopVertices;

    }

    public Zone buildZoneWithIDs(int[] vIDs) {
        return buildZone(makeVertexList(vIDs));
    }
    
    public Zone buildZoneWithIDs(List<Integer> vIDs) {
        return buildZone(makeVertexList(vIDs));
    }

    public Zone buildZone(List<Vertex> vertices) {
        List<Vertex> list = build(vertices);
        
        return new Zone(list, world);
    }

    public int calculateZoneWithIDs(List<Integer> vIDs) {
        return calculateZone(makeVertexList(vIDs));
    }

    public int calculateZone() {
        List<Vertex> verts = new LinkedList<>();

        for(Vertex v : world.graph.getVerticesAsArray()) {
            if(v.team == TeamType.OWN) {
                verts.add(v);
            }
        }
        return calculateZone(verts);
    }

    public int calculateZone(List<Vertex> vertices) {
        List<Vertex> list = build(vertices);

        int result = 0;

        for(Vertex v : list) {
            result += v.value;
        }
        return result;
    }

    private List<Vertex> makeVertexList(int[] vIDs) {
        List<Vertex> vertices = new LinkedList<Vertex>();

        for(Integer id : vIDs) {
            vertices.add(world.graph.getVertex(id));
        }

        return vertices;
    }
    
    private List<Vertex> makeVertexList(List<Integer> vIDs) {
        List<Vertex> vertices = new LinkedList<Vertex>();

        for(Integer id : vIDs) {
            vertices.add(world.graph.getVertex(id));
        }

        return vertices;
    }

    private List<Vertex> build(List<Vertex> vertices) {
        List<Vertex> list = new LinkedList<>(vertices);

        list = markNeighbors(list);
        if(isZone(list)) {
            list = markZone(list);
        }
        
        return list;
    }

    private boolean isZone(List<Vertex> verts) {
        final List<Integer> neighbors = new LinkedList<>();
        for(Vertex v : verts) {
            for(Vertex w : world.graph.getNeighborsOf(v)) {
                if(!neighbors.contains(w) && !verts.contains(w))
                    neighbors.add(w.id);
            }
        }
        
        return !isConnected(neighbors);
    }

    private boolean isConnected(List<Integer> neighbors) {
        connect(neighbors.get(0), neighbors);
        
        return neighbors.isEmpty();
    }

    private void connect(Integer current, List<Integer> neighbors) {
        if(!neighbors.isEmpty()) {
            neighbors.remove(current);
            for(Vertex v : world.graph.getNeighborsListOf(current)) {
                if(neighbors.contains(v.id)) {
                    connect(v.id, neighbors);
                }
            }
        }
    }

    private LinkedList<Vertex> markNeighbors(List<Vertex> verts) {
        LinkedList<Vertex> result = new LinkedList<Vertex>(verts);
        for(Vertex v : verts) {
            for(Vertex w : world.graph.getNeighborsListOf(v)) {
                if(!result.contains(w) && !verts.contains(w)) {
                    int count = 0;
                    for(Vertex r : world.graph.getNeighborsListOf(w)) {
                        if(verts.contains(r))
                            count++;
                        if(!ignoreEnemy && r.team == TeamType.ENEMY)
                            count--;
                    }
                    if(count > 1) {
                        result.add(w);
                    }
                }
            }
        }
        return result;
    }

    public boolean isIgnoreEnemy() {
        return ignoreEnemy;
    }

    public void setIgnoreEnemy(boolean ignoreEnemy) {
        this.ignoreEnemy = ignoreEnemy;
    }

    private LinkedList<Vertex> markZone(final List<Vertex> verts) {
        Queue<List<Vertex>> listVertex = new PriorityQueue<List<Vertex>>(20, LIST_COMPARATOR);
        LinkedList<Vertex> result = new LinkedList<Vertex>(verts);

        final LinkedList<Vertex> marked = new LinkedList<>();
        boolean enemy = false;
        for(Vertex v : verts) {
            if(!marked.contains(v)) {
                marked.add(v);
                LinkedList<Vertex> neighbors = new LinkedList<>();
                for(Vertex w : world.graph.getNeighborsOf(v)) {
                    if(!verts.contains(w)) {
                        neighbors.add(w);
                    }
                }

                if(world.graph.getNeighborsOf(v).length - neighbors.size() > 1) {
                    for(Vertex n : neighbors) {
                        if(!marked.contains(n)) {
                            Path path = env.getPathToNext(n, new PathFilter() {

                                @Override
                                public boolean matches(Path path) {
                                    return (stopVertices != null && stopVertices.contains(path.getTargetVertex()))
                                            || (!ignoreEnemy && path.getTargetVertex().team == TeamType.ENEMY);
                                }

                                @Override
                                public boolean accepts(Path path) {
                                    return !verts.contains(path.getTargetVertex());
                                }

                            }, Path.BY_STEPCOUNT);

                            if(path == null) {
                                listVertex.add(addNeighborsRecursive(n, verts, marked));
                            } else {
                                addNeighborsRecursive(n, verts, marked);
                                enemy = true;
                            }
                        }
                    }
                }
            }
        }

        if(listVertex.size() == 1 && enemy) {
            result.addAll(listVertex.poll());
        } else if(listVertex.size() >= 2) {
            listVertex.remove();

            for(List<Vertex> v : listVertex) {
                result.addAll(v);
            }
        }

        return result;
    }

    private List<Vertex> addNeighborsRecursive(Vertex neighbor, List<Vertex> verts, LinkedList<Vertex> marked) {
        LinkedList<Vertex> result = new LinkedList<>();

        addNeighborsRecursive(result, neighbor, verts);

        marked.addAll(result);
        return result;
    }

    private void addNeighborsRecursive(LinkedList<Vertex> result, Vertex neighbor, List<Vertex> verts) {
        if(!result.contains(neighbor)) {
            result.add(neighbor);

            for(Vertex v : world.graph.getNeighborsOf(neighbor)) {
                if(!verts.contains(v)) {
                    addNeighborsRecursive(result, v, verts);
                }
            }
        }
    }

    public List<Vertex> getStopVertices() {
        return stopVertices;
    }

    public void setStopVertices(List<Vertex> stopVertices) {
        this.stopVertices = stopVertices;
    }

    private static Comparator<List<Vertex>> LIST_COMPARATOR = new Comparator<List<Vertex>>() {
        @Override
        public int compare(List<Vertex> o1, List<Vertex> o2) {
            return o2.size() - o1.size();
        }
    };
}
