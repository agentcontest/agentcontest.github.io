package de.tub.mac13.teamb.connection;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import de.tub.mac13.teamb.Constants;

/**
 * This class creates valid message content for ac server communication.
 *
 * @author axle
 */
public class ActionFactory {

    /**
     * New factory, which is used to build new documents
     */
    private static DocumentBuilderFactory documentbuilderfactory = DocumentBuilderFactory.newInstance();

    /**
     * Method that creates a new AuthenticationAction in valid XML-Syntax.
     *
     * @param username - the username
     * @param password - the password
     * @return the corresponding xml-document
     */
    public static Document getAuthenticationAction(String username, String password) {
        Document doc = null;
        try {
            doc = documentbuilderfactory.newDocumentBuilder().newDocument();
            Element root = doc.createElement("message");
            root.setAttribute("type", Constants.MESSAGE_AUTH_RESPONSE);
            doc.appendChild(root);
            Element auth = doc.createElement("authentication");
            auth.setAttribute("username", username);
            auth.setAttribute("password", password);
            root.appendChild(auth);
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }
        return doc;
    }

    /**
     * Method that creates a new Action in valid XML-Syntax!
     *
     * @param action - one of the actions "goto", "attack", "parry", "probe",
     * "survey", "inspect", "repair", "buy", "recharge", "skip"
     * @param param the action parameter if any, if null the attribute will not
     * be set
     * @param id - the id of the request message
     * @return the corresponding xml-document
     */
    public static Document getAction(String action, String param, int id) {
        Document doc = null;
        try {
            doc = documentbuilderfactory.newDocumentBuilder().newDocument();
            Element root = doc.createElement("message");
            root.setAttribute("type", "action");
            doc.appendChild(root);
            Element act = doc.createElement("action");
            act.setAttribute("type", action);
            act.setAttribute("id", Integer.toString(id));
            if (param != null) {
                act.setAttribute("param", param);
            }
            root.appendChild(act);
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }
        return doc;
    }
}
