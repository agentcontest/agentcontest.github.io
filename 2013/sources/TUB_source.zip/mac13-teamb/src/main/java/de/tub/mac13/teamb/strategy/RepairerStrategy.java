package de.tub.mac13.teamb.strategy;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;

import de.tub.mac13.teamb.Constants;
import de.tub.mac13.teamb.bean.DefaultDecisionBean;
import de.tub.mac13.teamb.ontology.Goal;
import de.tub.mac13.teamb.ontology.Intention;
import de.tub.mac13.teamb.ontology.Agent;
import de.tub.mac13.teamb.ontology.enums.AgentRole;
import de.tub.mac13.teamb.ontology.graph.Edge;
import de.tub.mac13.teamb.ontology.graph.Graph;
import de.tub.mac13.teamb.ontology.graph.Path;
import de.tub.mac13.teamb.ontology.graph.Vertex;
import de.tub.mac13.teamb.util.EnvironmentInformation;
import de.tub.mac13.teamb.util.PathFilter;

public class RepairerStrategy extends RandomStrategy {

    /*TODO sort Team by distance to me
     [x] custom logger
     [~] find next lowest Team Mate
     [x] goto
     [x] heal
     [~] repeat
     [ ] (adv*): minimize enemy contact
     [ ]       : part of task force ... (priority heal/follow)
	
	
     Methodes we need:
     [x] goto
     [x] heal
     [x] follow
     [ ] evade
     */
	
    private static final int RECHARGE_THRESHOLD = 2;
    private Path planedPath;
   
    private String target;
	private EnvironmentInformation pathPlaner;

    public RepairerStrategy(DefaultDecisionBean decider, String username) {
        super(decider, username);
    }



    @Override
    public Intention decide() {    	
    	return super.decide();
    }

    /**
     * Checks if an agents is within on-step-range of this agent and has low to none health
     * if so the agents name is returned. If more than one agent is in range the closes one will be 
     * returned if multiple agent are at the same distance the one with the lowest health is returned.
     * If there are only agents with the same health and the same distance than it is undetermined witch
     * agent name is returned! 
     * If no agent is in range null will be returned!
     * @return agent name or null
     */
    private String hasTeamNearMe() {
    	Set<Integer> reachableNodes = new HashSet<>();
    	reachableNodes.add(world.self.position);
    	Graph g = world.graph;
    	Edge e;
    	for(Vertex v:g.getNeighborsListOf(g.getVertex(world.self.position))){
    		e = g.getEdge(v.id,world.self.position);
    		if(e != null && e.weight < world.self.energy){
    			reachableNodes.add(v.id);
    		}
    	}
    	PriorityQueue<Agent> possibleAgents = new PriorityQueue<>(4,new Comparator<Agent>() {

			@Override
			public int compare(Agent s1, Agent s2) {
				int tid = (target != null)?world.team.get(target).id:-1;
				if(s1.id == tid){
					return -1;
				} else if(s2.id == tid){
					return 1;
				}
				if(s1.position == world.self.position){
					return -1;
				} else if(s2.position == world.self.position){
					return 1;
				}
				if(s1.health != s2.health){
					return Integer.compare(s1.health, s2.health);
				}
				
				return 0;
			}
    		
		});
        for (Agent agent : world.team.values()) {
            if (!agent.username.matches(world.username)) {
                if (agent.health == 0) {
                	//FIXME all other try to flee!
                	
                		if(reachableNodes.contains(agent.position)){
                			possibleAgents.add(agent);
                		}
                }
            }
        }
        if(!possibleAgents.isEmpty()){
        	return possibleAgents.poll().username;
        }
        return null;
    }


    
    
    /**
     * TODO:
     *  fork this stragy and reimplemend this method in a way
     *  that the pathplaning/searching is limited to a zone/group of other agents
     *  so that this agents keeps helping only a small group
     *  
     *  That should be possible with the EnvironmentInformation class??? REVIEW
     */
    private void initDecisionBase() {
        
    	this.pathPlaner = new EnvironmentInformation(world,Path.BY_COST);
    	
    	@SuppressWarnings("unchecked")
		final PriorityQueue<Agent> agentCache[] = new PriorityQueue[world.graph.getVertexCount()];
    	for(Agent agent: world.team.values()){
    		if(agentCache[agent.position] == null){
    			agentCache[agent.position] = new PriorityQueue<>(2,new Comparator<Agent>() {
					@Override
					public int compare(Agent o1, Agent o2) {
						return Integer.compare(o1.health, o2.health);
					}
				});
    		} 
    		agentCache[agent.position].offer(agent);
		}
    	final String self = world.username;
    	PathFilter agentsInNeed = new PathFilter() {
			
			@Override
			public boolean matches(Path elem) {
				int id = elem.getTarget();
				if(agentCache[id] != null){
					for(Agent agent:agentCache[id]){
						if(agent.username.matches(self)){continue;}
						if(agent.health < agent.maxHealth*0.2){
							return true;
						}
					}
				}
				return false;
			}
		};
		
		final Comparator<Path> resultFilter = new Comparator<Path>() {
			
			@Override
			public int compare(Path o1, Path o2) {
				
				int length = Integer.compare(o1.getStepCount(),o2.getStepCount());
				if(length != 0){
					return length;
				} else {
					int v1 = o1.getTarget();
					int v2 = o2.getTarget();
					if(agentCache[v1] != null && agentCache[v2] != null){
						Agent a1 = agentCache[v1].peek();
						Agent a2 = agentCache[v2].peek();
						return Integer.compare(a1.health, a2.health);
					}
				}
				return 0;
			}
		};
		
	   Comparator<Path> filter = new Comparator<Path>() {
			
		   private int getUserId(String username){
			   return Integer.parseInt(username.substring(3));
		   }
		   
			@Override
			public int compare(Path o1, Path o2) {
				int v1 = o1.getTarget();
				int v2 = o2.getTarget();
				if(agentCache[v1] != null && agentCache[v2] != null){
					Agent a1 = agentCache[v1].peek();
					Agent a2 = agentCache[v2].peek();
					Intention goalIntention;
					for(Goal goal:world.teamGoals.values()){
						if(goal.getUsername().matches(world.username)){
							continue;
						} else {
							goalIntention = goal.getFinalIntention();
							if(goalIntention.action.matches(Constants.ACTION_REPAIR)){
								if(goalIntention.param.matches(a1.username)){
									//at this point some other agent has the plan to heal a1
									if(goal.getCostsBySteps() < o1.getStepCount() || 
											(goal.getCostsBySteps() == o1.getStepCount() && getUserId(goal.getUsername()) < getUserId(world.username))){
										//ignore a1/o1
										return 1;
									} 
								}
								
								if(goalIntention.param.matches(a2.username)){
									//at this point some other agent has the plan to heal a2
									if(goal.getCostsBySteps() < o1.getStepCount() || 
											(goal.getCostsBySteps() == o1.getStepCount() && getUserId(goal.getUsername()) < getUserId(world.username))){
										//ignore a2/o2
										return -1;
										
									} 
								}
								// at this point the we need to choose one 
								
							}
						}
					}
				}
				return resultFilter.compare(o1, o2);
			}
		};
    	
		Queue<Path> pathsChoice = this.pathPlaner.getPathsToNext(world.self.position, agentsInNeed, Path.BY_COST, filter);
    	
    	
    	if(pathsChoice != null && !pathsChoice.isEmpty()){
    		this.planedPath = pathsChoice.poll();


    		int id = this.planedPath.getTarget();
    		target = agentCache[id].peek().username;
    		//getLog().info(world.username + "plaing to heal:" + this.target + "@" + agentCache[id].peek().position + " I am @" + world.self.position);

    	}
        
    }
    
    private final PathFilter FILTER_FIND_REPAIRER = new PathFilter() {
        @Override
        public boolean matches(Path path) {
            if(path != null) {
                for(Agent s : world.team.values()) {
                    if(s.role.equals(AgentRole.REPAIRER) && s.position == path.getTarget()) {
                        return true;
                    }
                }
            }
            return false;
        }

        @Override
        public boolean accepts(Path path) {
            if(path != null) {
                if(path.getStepCount() <= 50 && path.getLastStepCost() <= world.self.maxEnergy) {
                    return true;
                }
            }
            return false;
        }
    };
    

    private Goal needHeal(){
    	EnvironmentInformation environment = new EnvironmentInformation(world);
    	Queue<Path> queue = environment.getPathsToNext(FILTER_FIND_REPAIRER, Path.BY_STEPCOUNT);
        
        if (queue != null && !queue.isEmpty()) {
            Path chosenPath = queue.peek();
            if (chosenPath != null) {
                //FIX - hotfix follows produced an error @runtime
                if (chosenPath.getPath() != null && !chosenPath.getPath().isEmpty()) {
                    planedPath = chosenPath;

                    if (planedPath.getStepCount() <= 0) {
                        return new Goal(recharge());
                    } else {
                    	LinkedList<Intention> plan = new LinkedList<>();
                        for (int i = 1; i < planedPath.getStepCount(); i++) {
                           plan.add(goToVertexIgnoreEnergy(planedPath.getStep(i)));
                        }
                        plan.add(recharge());
                    	
                        return new Goal(plan);
                    }
                } 
            }
        }
        return new Goal(super.decide());
    }
    
    
    //TODO!!! -- the long term planing of decide() -- change planedPath etc to be stored in a Goal!
    /**
     * Decision Tree:
     *  1. check if we have sufficant energy to do anything!
     *  2. see if an agents with low health is nearby if so go to him and heal!
     *  3. see if we have had planed to executed a plan 
     *  	if so keep executing it - e.g. go to agent and heal!
     *  4. if no plan is present:
     *  	iterated over all agents / excluding this agent
     *  	sort agents by health,distance
     *  	if there is any agent that has:
     *  		a. less than 20% health
     *  		b. is reachable
     * 		go plan to go to that agent
     * 	5. if no agent needs help use fallback Strategy:
     * 		random movement --- FIXME
     * 		Survey Edges if not done 
     * @return
     */
    @Override
    public Goal getGoal() {
    	//setup 
    	 initDecisionBase();
         String teamMate = hasTeamNearMe();
         Goal goal = null;
         
         if (world.self.energy <= RECHARGE_THRESHOLD) {
             getLog().info("["+world.step+"]rechage");
             return new Goal(recharge());
         }  else if (teamMate != null) {
        	//per discussion this agent will wait for one turn excpetiong the wounded agent to come 
         	//todo 2-step goal!
        	int pos = world.team.get(teamMate).position;
         	if(pos == world.self.position){
         		goal = new Goal(repair(teamMate));
         		getLog().info("["+world.step+"]repair to closeby Teammate: "+teamMate+":"+world.team.get(teamMate).health);
         	} else if(world.team.get(teamMate).role == AgentRole.EXPLORER){ //currently only explorer do that :(
         		LinkedList<Intention> plan = new LinkedList<>();
         		plan.add(recharge());
         		plan.add(repair(teamMate));
         		goal = new Goal(plan);
         		
         		getLog().info(String.format("[%d]Per Agreement I will wait and heal:%s", world.step,teamMate));
         	} else {
         		LinkedList<Intention> plan = new LinkedList<>();
         		plan.add(goToVertexIgnoreEnergy(pos));
         		plan.add(repair(teamMate));
         		goal = new Goal(plan);
         		getLog().info("["+world.step+"]I am going to "+pos+" and heal "+teamMate+" i am @"+world.self.position);
         	}
         } else if(world.self.health == 0){ 
         	//TODO see were next repairer is and got to him
         	//for now STOP!
         	getLog().info("["+world.step+"]I am hurt! fallback Move!\t");
         	//goal = needHeal(); 
         	goal = needHeal(); 
     	} else if (target != null) {
             if (planedPath != null && planedPath.getStepCount() > 0) {
                 LinkedList<Intention> plan = new LinkedList<>();

                 if(world.self.energy < planedPath.getFirstStepCost()){
                     plan.add(recharge());
                 }
                 for (int i = 1; i < planedPath.getStepCount(); i++) {
                     plan.add(goToVertexIgnoreEnergy(planedPath.getStep(i)));
                 }
                 plan.add(repair(target));
             } else if(goal == null){
                 if (world.team.get(this.target).position == world.self.position) {
                     goal = new Goal(repair(target));
                     planedPath = null;
                     target = null;
                     getLog().info("["+world.step+"]heal" + target);
                 } else {
                     planedPath = null;
                     target = null;
                     return getGoal();
                 }
             }
         } 
         if (goal == null) {
             getLog().error("["+world.step+"][Repairer] Using Fallback?!?");
             if (world.self.health > 0) {
            	 goal = new Goal(super.decide());
             } else {
            	 goal = new Goal(recharge());
             }
         }

         return goal;
    }


	@Override
    public List<Intention> decisionPlan() {
        return null;
    }

    @Override
    public String toString() {
        return "RepairerStrategy";
    }
}
