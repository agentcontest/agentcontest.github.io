package de.tub.mac13.teamb.strategy;

import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Random;

import de.tub.mac13.teamb.bean.DefaultDecisionBean;
import de.tub.mac13.teamb.ontology.Agent;
//import de.tub.mac13.teamb.ontology.Agent;
import de.tub.mac13.teamb.ontology.Entity;
import de.tub.mac13.teamb.ontology.Intention;
import de.tub.mac13.teamb.ontology.Order;
import de.tub.mac13.teamb.ontology.enums.AgentRole;
import de.tub.mac13.teamb.ontology.enums.StrategyType;
import de.tub.mac13.teamb.ontology.enums.TeamType;
import de.tub.mac13.teamb.ontology.graph.Edge;
import de.tub.mac13.teamb.ontology.graph.Path;
import de.tub.mac13.teamb.util.BestZoneCalculator;
import de.tub.mac13.teamb.util.BestZoneVMCCalculator;
import de.tub.mac13.teamb.util.EnvironmentInformation;
import de.tub.mac13.teamb.util.GoodZoneCalculator;
import de.tub.mac13.teamb.util.PathFilter;
import de.tub.mac13.teamb.util.VMCCalculator;
//import de.tub.mac13.teamb.util.PathFilter;
import de.tub.mac13.teamb.util.Zone;
import de.tub.mac13.teamb.util.Zoner;

public class ZoneStrategy extends RandomStrategy {

    private EnvironmentInformation env;

	public ZoneStrategy(DefaultDecisionBean decider, String username) {
		super(decider, username);
		this.env = new EnvironmentInformation(world);
	}

	@Override
	public Intention decide() {
		if (world.self.energy <= 0.2f * world.self.maxEnergy) {
			return recharge();
		}
		if (world.self.health == 0) {
			Path p = env.getPathToNext(FILTER_FIND_REPAIRER);

			if (p != null) {
				return goToVertex(p.getFirstStep());
			}
		} else {

			Queue<Path> surveyedNeighbors = env
					.getPathsToNext(FILTER_NEED_SURVEY);

			if (surveyedNeighbors.size() != world.graph.getEdgesOfVertex(
					world.self.position).size()) {
				return survey();
			}

			Path enemyPath = env.getPathToNext(FILTER_ENEMY_NEAR);
			if (enemyPath != null) {
				if (enemyPath.getStepCount() == 0) {
					if (!(world.teamActions.get(world.username) != null && !world.teamActions
							.get(world.username).peek().success)) {
						// return super.decide();
						if (fallback instanceof SentinelStrategy) {
							List<Entity> enemies = world.getAgentsOnVertex(
									enemyPath.getTarget(), TeamType.ENEMY);

							boolean next = false;

							for (Entity e : enemies) {
								if ((e.role == AgentRole.SABOTEUR || e.role == null)
										&& e.health != 0)
									next = true;
							}

							if (next) {
								return parry();
							}
						}
					}
				}
			}

			int rank = 0;

			for (Entity e : world.getOwnAgents()) {
				if (e.strategy == StrategyType.ZONE || e.strategy == StrategyType.ZONE_D) {
					if (e.id > world.self.id) {
						rank++;
					}
				}
			}

			int[] positions = null;

			if (world.zoneOrder != null) {
				positions = world.zoneOrder.getPositions();
			}

			if (positions != null && rank < positions.length) {
                getLog().info(String.format("[%d]Following ZoneOrder %d ",world.step,world.zoneOrder.getStep()));
				if (positions[rank] != world.self.position) {
					Path path = env.getPathToPosition(positions[rank]);

					if (path != null)
						return this.goToVertex(path.getFirstStep());
				} else {
					if (world.self.energy != world.self.maxEnergy) {
						return recharge();
					} else {
						return skip();
					}
				}
			}
		}
		return super.decide();
	}

	@Override
	protected Intention goToVertex(int v) {
		Edge edge = world.graph.getEdge(world.self.position, v);
		if (edge != null) {
			if (world.self.energy >= edge.weight)
				return super.goToVertex(v);
			return recharge();
		}
		return super.decide();
	}

	@Override
	public List<Intention> decisionPlan() {
		return null;
	}

	@Override
	public String toString() {
		return "ZoneStrategy";
	}
}
