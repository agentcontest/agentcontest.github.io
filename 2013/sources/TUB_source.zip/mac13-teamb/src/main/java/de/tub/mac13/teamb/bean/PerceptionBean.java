package de.tub.mac13.teamb.bean;

import java.io.Serializable;
import java.util.Set;

import org.sercho.masp.space.event.SpaceEvent;
import org.sercho.masp.space.event.SpaceObserver;
import org.sercho.masp.space.event.WriteCallEvent;
import org.w3c.dom.Document;

import de.dailab.jiactng.agentcore.IAgent;
import de.dailab.jiactng.agentcore.IAgentBean;
import de.dailab.jiactng.agentcore.action.AbstractMethodExposingBean;
import de.dailab.jiactng.agentcore.action.Action;
import de.dailab.jiactng.agentcore.comm.CommunicationAddressFactory;
import de.dailab.jiactng.agentcore.comm.ICommunicationAddress;
import de.dailab.jiactng.agentcore.comm.IGroupAddress;
import de.dailab.jiactng.agentcore.comm.message.IJiacMessage;
import de.dailab.jiactng.agentcore.comm.message.JiacMessage;
import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.dailab.jiactng.agentcore.ontology.IAgentDescription;
import de.tub.mac13.teamb.connection.MessageParser;
import de.tub.mac13.teamb.ontology.AuthResponse;
import de.tub.mac13.teamb.ontology.Authentication;
import de.tub.mac13.teamb.ontology.Bye;
import de.tub.mac13.teamb.ontology.Goal;
import de.tub.mac13.teamb.ontology.Intention;
import de.tub.mac13.teamb.ontology.Order;
import de.tub.mac13.teamb.ontology.Perception;
import de.tub.mac13.teamb.ontology.SimEnd;
import de.tub.mac13.teamb.ontology.World;
import de.tub.mac13.teamb.ontology.enums.StrategyType;

public class PerceptionBean extends AbstractMethodExposingBean {

    private String username;
    private MessageParser messageParser;
    private ServerCommunicationBean serverCommunicationBean;
    private DefaultDecisionBean decisionBean;
    /**
     * Actions to communicate with other team members.
     */
    private Action sendAction, registerAction;
    /**
     * The channel where agents of one team share their knowledge.
     */
    public IGroupAddress teamChannel;
    public long time;
    private World world;

    public String getTeamChannel() {
        return this.teamChannel.toString();
    }

    public void setTeamChannel(String teamChannel) {
        this.teamChannel = CommunicationAddressFactory
                .createGroupAddress(teamChannel);
    }

    @Override
    public void doInit() throws Exception {
        super.doInit();

        for (IAgentBean ab : thisAgent.getAgentBeans()) {
            if (ab instanceof ServerCommunicationBean) {
                this.serverCommunicationBean = (ServerCommunicationBean) ab;
                messageParser = new MessageParser(
                        serverCommunicationBean.getUsername());
            } else if (ab instanceof DefaultDecisionBean) {
                this.decisionBean = (DefaultDecisionBean) ab;
            }
        }

        SpaceObserver<IFact> messageObserver = new SpaceObserver<IFact>() {
            private static final long serialVersionUID = -2109274101459190774L;

            @Override
            public void notify(SpaceEvent<? extends IFact> event) {
                if (event instanceof WriteCallEvent) {
                    @SuppressWarnings("rawtypes")
                    Object eventObj = ((WriteCallEvent) event).getObject();
                    if (eventObj instanceof IJiacMessage) {
                        IJiacMessage message = (IJiacMessage) eventObj;
                        message = memory.remove(message);
                        if (message != null) {
                            IFact payload = message.getPayload();

                            if (payload instanceof Perception) {
                                Perception perception = (Perception) payload;

                                // ignore own perception that we have received
                                // via team channel
                                if (!perception.username.equals(username)) {

                                    // only process actual perceptions and when
                                    // world is initialized
                                    if (world != null) {
                                        world.update(perception);
                                    }
                                }
                            }
                            if(payload instanceof Bye){
                                System.out.println("Bye");
                            }
                            
                            if (payload instanceof Intention) {
                                Intention it = (Intention) payload;
                                if (world != null) {
                                    world.update(it);
                                }
                            }
                       
                            if (payload instanceof Goal) {
                                Goal goal = (Goal) payload;
                                if (world != null) {
                                    world.update(goal);
                                }
                            }
                            
                            if (payload instanceof Order) {
                                Order order = (Order) payload;
                                if (world != null) {
                                    world.update(order);
                                }
                            }
                        }
                    }
                }
            }
        };
        memory.attach(messageObserver);

    }

    @Override
    public void doStart() throws Exception {
        super.doStart();

        Authentication auth = memory.read(new Authentication(null, null));
        if (auth != null) {
            this.username = auth.getUsername();
        } else {
            log.error("NO AUTHENTICATION FOUND");
        }

        // retrieving needed actions from own CommunicationBean
        sendAction = memory.read(new Action(
                "de.dailab.jiactng.agentcore.comm.ICommunicationBean#send",
                null, new Class[]{IJiacMessage.class,
            ICommunicationAddress.class}, null));
        if (sendAction == null) {
            throw new RuntimeException("Could not find Communication...1");
        }

        registerAction = memory
                .read(new Action(
                "de.dailab.jiactng.agentcore.comm.ICommunicationBean#joinGroup",
                null, new Class[]{IGroupAddress.class}, null));
        if (registerAction == null) {
            throw new RuntimeException("Could not find Communication...2");
        }

        invoke(registerAction, new Serializable[]{this.teamChannel});
    }

    public void processServerMessage(Document message) {
        IFact parseResult = messageParser.parse(message);

        time = System.nanoTime();

        if (parseResult instanceof Perception) {
            // Perception received
            Perception perception = (Perception) parseResult;

            // send own perception to other agents
            if (world != null) {
                //add additonal world for the perception!
                perception.role = world.self.role;
                
                perception.strategy = StrategyType.get(decisionBean.getStrategyName());
            }

            decisionBean.setPerception(perception);
            sendPerception(perception);

            if (world != null) {
                world.update(perception);
                decisionBean.decide();
            } else {
                System.err.println("## [INFO] Agent " + this.username
                        + " received ActionRequest before process SimStart!");
            }
        } else if (parseResult instanceof World) {

            // SimStart received
            world = (World) parseResult;
            log.debug(String.format("%s :World has been read: %s", username, world));

            decisionBean.setWorld(world);
            memory.write(world);

            sendWorld(world);

            if (memory.readAllOfType(World.class).size() == 1) {
                log.debug(String.format("%s:World found!!!", username));
            } else {
                log.error(String.format("%s:World not found!!!", username));
            }
        } else if (parseResult instanceof SimEnd) {
            // SimEnd received
            SimEnd simEnd = (SimEnd) parseResult;
            //simEnd.setSimName(world.simulationId);
            memory.write(simEnd);
            sendEnd(simEnd);
            memory.remove(world);
            world = null;
            decisionBean.setWorld(null);
            log.info(simEnd);
        } else if (parseResult instanceof Bye) {

            Set<SimEnd> results = memory.readAllOfType(SimEnd.class);
            for (SimEnd rse : results) {
                log.info(rse);
            }
            System.out.flush();

            Runtime.getRuntime().halt(666);

        } else if (parseResult instanceof AuthResponse) {
            String s = ((AuthResponse) parseResult).isAuthSuccessful() ? "AUTHENTICATION OK!"
                    : "AUTHENTICATION FAILED!";
            log.debug(s);
        }

    }

    /**
     * Sends the own perception to all team members.
     *
     * @param perception the perception object to send
     */
    private void sendPerception(Perception perception) {
        JiacMessage msg = new JiacMessage(perception);
        Serializable[] params = new Serializable[2];
        params[0] = msg;
        params[1] = this.teamChannel;//addreesse  msg box posten der msg box addr. oder die node
        //thisAgent.getAgentNode().findAgents()
        invoke(sendAction, params);
    }

    /**
     * Sends the own intention to all team members.
     *
     * @param intention the intention object to send
     */
    public void sendIntention(Intention intention) {
        JiacMessage msg = new JiacMessage(intention);
        Serializable[] params = new Serializable[2];
        params[0] = msg;
        params[1] = this.teamChannel;
        invoke(sendAction, params);
    }
    
    /**
     * Sends the own goal to all team members.
     *
     * @param goal the goal object to send
     */
    public void sendGoal(Goal goal) {
        JiacMessage msg = new JiacMessage(goal);
        Serializable[] params = new Serializable[2];
        params[0] = msg;
        params[1] = this.teamChannel;
        invoke(sendAction, params);
    }
    private IAgentDescription statisticAgent;
    private IAgentDescription zoneAgent;
    

    public void sendOrder(Order order) {
        JiacMessage msg = new JiacMessage(order);
        Serializable[] params = new Serializable[2];
        params[0] = msg;
        params[1] = this.teamChannel;
        invoke(sendAction, params);
    }

    private void sendWorld(World world) {
        if(world.id > 1){
            return;
        }

        if (statisticAgent == null || zoneAgent == null) {
            for (IAgent a : thisAgent.getAgentNode().findAgents()) {
                if (a.getAgentName().matches("statisticAgent")) {
                    statisticAgent = a.getAgentDescription();
                } else  if(a.getAgentName().matches("zoneAgent")){
                    zoneAgent = a.getAgentDescription();
                }
            }
        }
        if(statisticAgent != null){
            JiacMessage msg = new JiacMessage(world);
            Serializable[] params = new Serializable[2];

            params[0] = msg;
            params[1] = statisticAgent.getMessageBoxAddress();
            invoke(sendAction, params);
            System.out.println("SEND WORLD");
        }
        if(zoneAgent != null){
            JiacMessage msg = new JiacMessage(world);
            Serializable[] params = new Serializable[2];

            params[0] = msg;
            params[1] = zoneAgent.getMessageBoxAddress();
            invoke(sendAction, params);
        }

    }

    private void sendEnd(SimEnd se) {
        if (statisticAgent == null || zoneAgent == null) {
            for (IAgent a : thisAgent.getAgentNode().findAgents()) {
                if (a.getAgentName().matches("statisticAgent")) {
                    statisticAgent = a.getAgentDescription();
                }
                if(a.getAgentName().matches("zoneAgent")){
                    zoneAgent = a.getAgentDescription();
                }
            }
        }
        if(statisticAgent != null){
            JiacMessage msg = new JiacMessage(se);
            Serializable[] params = new Serializable[2];

            params[0] = msg;
            params[1] = statisticAgent.getMessageBoxAddress();
            invoke(sendAction, params);
        }
        if(zoneAgent != null){
            JiacMessage msg = new JiacMessage(se);
            Serializable[] params = new Serializable[2];

            params[0] = msg;
            params[1] = zoneAgent.getMessageBoxAddress();
            invoke(sendAction, params);
        }

    }
}
