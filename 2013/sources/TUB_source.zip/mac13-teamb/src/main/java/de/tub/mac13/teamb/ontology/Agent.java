package de.tub.mac13.teamb.ontology;

import java.io.Serializable;

import de.tub.mac13.teamb.ontology.enums.AgentRole;
import de.tub.mac13.teamb.ontology.enums.StrategyType;
import de.tub.mac13.teamb.ontology.enums.TeamType;

public class Agent implements Serializable {

    private static final long serialVersionUID = -7280305805748746901L;
    public String username;
    public int id;
    public AgentRole role;
    public TeamType team = TeamType.OWN;
    public int energy;
    public int health;
    public int maxEnergy;
    public int maxEnergyDisabled;
    public int maxHealth;
    public int position;
    public int strength;
    public int visRange;
    public StrategyType strategy;

    @Override
    public String toString() {
        return "SelfPerception [username=" + username + ", role=" + role
                + ", team=" + team + ", energy=" + energy + ", health="
                + health + ", maxEnergy=" + maxEnergy + ", maxEnergyDisabled="
                + maxEnergyDisabled + ", maxHealth=" + maxHealth
                + ", position=" + position + ", strength=" + strength
                + ", visRange=" + visRange + "]";
    }
}
