package de.tub.mac13.teamb.bean;

import de.dailab.jiactng.agentcore.action.AbstractMethodExposingBean;
import de.dailab.jiactng.agentcore.action.Action;
import de.dailab.jiactng.agentcore.comm.CommunicationAddressFactory;
import de.dailab.jiactng.agentcore.comm.ICommunicationAddress;
import de.dailab.jiactng.agentcore.comm.IGroupAddress;
import de.dailab.jiactng.agentcore.comm.message.IJiacMessage;
import de.dailab.jiactng.agentcore.comm.message.JiacMessage;
import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac13.teamb.ontology.*;
import de.tub.mac13.teamb.ontology.enums.StrategyType;
import de.tub.mac13.teamb.ontology.enums.TeamType;
import de.tub.mac13.teamb.ontology.graph.Path;
import de.tub.mac13.teamb.util.*;

import org.sercho.masp.space.event.SpaceEvent;
import org.sercho.masp.space.event.SpaceObserver;
import org.sercho.masp.space.event.WriteCallEvent;

import java.io.Serializable;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ZoneBean extends AbstractMethodExposingBean {

    private final int SAMPLES       = 80;
    private final int AGENTCOUNT    = 6;

	@SuppressWarnings("unused")
	private static final String username = "zoneAgent";
	private Action sendAction,registerAction;

    private ExecutorService task;

    private World world;
    private VMCCalculator vmc;

    private LinkedList<Perception> perceptions;

    private int currentStep = 0;
    
    private boolean samplerStarted = false;
    private int currentZoneValue = -1;

    /**
	 * The channel where agents of one team share their knowledge.
	 */
	public IGroupAddress teamChannel;

	public String getTeamChannel() {
		return this.teamChannel.toString();
	}

	public void setTeamChannel(String teamChannel) {
		this.teamChannel = CommunicationAddressFactory
				.createGroupAddress(teamChannel);
	}

	@Override
	public void doInit() throws Exception {
		super.doInit();
		
        perceptions = new LinkedList<>();

        SpaceObserver<IFact> messageObserver = new SpaceObserver<IFact>() {
			private static final long serialVersionUID = -2109274101459135774L;

			@Override
			public void notify(SpaceEvent<? extends IFact> event) {
				if (event instanceof WriteCallEvent) {
					@SuppressWarnings("rawtypes")
					Object eventObj = ((WriteCallEvent) event).getObject();
					if (eventObj instanceof IJiacMessage) {
						IJiacMessage message = (IJiacMessage) eventObj;
						message = memory.remove(message);
						if (message != null) {
							IFact payload = message.getPayload();
                            if(payload instanceof World){
                                if(world == null){
                                    task = Executors.newCachedThreadPool();
                                    world = World.makeWorld((World) payload);
                                    vmc = new VMCCalculator(world, AGENTCOUNT);
                                    samplerStarted = false;
                                    System.out.println("Zone Beam Started!");
                                }
                            }

							if (payload instanceof Perception) {

								Perception p = (Perception) payload;
                                if(world != null) {

                                    while (!perceptions.isEmpty()){
                                        update(perceptions.poll());
                                    }

                                    update(p);
                                } else {
                                    perceptions.offer(p);
                                }

							}

							if (payload instanceof SimEnd) {
					            close();

							}
						}
					}
				}
			}
		};
		memory.attach(messageObserver);

	}

    private void close() {
        try{
        	currentZoneValue = -1;
        	samplerStarted = false;
        	currentStep = -1;
            world = null;
            perceptions.clear();
            task.shutdown();
            task = null;
        }  catch (Exception e){}
    }
    
    protected void update(Perception p) {
        world.update(p);

        if(!samplerStarted) {
        	startSampler();
        	samplerStarted = true;
        }
        
        if(currentStep < p.id){
            currentStep = p.id;
            startZoneCalculationVMC();
        }
	}

    private final static Comparator<Entity> COMPARE_AGENT = new Comparator<Entity>() {
    	@Override
        public int compare(Entity e1, Entity e2) {
            return e2.id - e1.id;
        }
	};
	
    class Sampler implements Runnable{
    	private int samples;
    	private VMCCalculator vmc;
    	
    	
    	public Sampler(VMCCalculator vmc, int samples) {
    		this.samples = samples;
    		this.vmc = vmc;
    	}
    	
		@Override
		public void run() {
			System.out.println("sampling...");
			while(samplerStarted) {
				vmc.sample(this.samples);
				try {
					Thread.sleep(250);
				} catch (InterruptedException e) {}
			}
			System.out.println("stopped sampling");
		}
    	
    }

    class ZoneCalculation implements Runnable{
        private VMCCalculator vmc;
        private EnvironmentInformation env;
        private Random rand;

        private World world;

        public ZoneCalculation(final World w, VMCCalculator vmc){
            this.vmc = vmc;
            this.env = new EnvironmentInformation(w);
            this.rand = new Random();
            this.world = w;

        }

        
        public ZoneCalculation(final World w,int agentCount,int samples){
            this.vmc = new VMCCalculator(w, agentCount);
            this.env = new EnvironmentInformation(w);
            this.rand = new Random();
            this.world = w;

        }

        public void run(){
            int zonerCount = 0;
            
            Queue<Entity> zoner = new PriorityQueue<>(10, COMPARE_AGENT);

            for (Entity e : world.getOwnAgents()) {
                if (e.strategy == StrategyType.ZONE || e.strategy == StrategyType.ZONE_D) {
                    zoner.add(e);
                    zonerCount++;
                }
            }
            
            int[] positions = null;

            vmc.setLength(zonerCount);

            List<Entity> enemies = world.getEnemyAgents();
            List<Integer> enemyPositionIds = new LinkedList<>();

            for (Entity e : enemies) {
                if (e.position.getTeam() != TeamType.OWN && e.health != 0) {
                    enemyPositionIds.add(e.position.id);
                }
            }

            positions = vmc.getBestPath(enemyPositionIds, zonerCount);
            
            //System.out.println(Arrays.toString(positions));
            if(positions != null) {
                int zoneValue = vmc.getLastBestPaths()[0].getZoneValue();

                // if there is no zone OR the new zone is better than the current + 10 OR the zone splits because of an enemy.
                if(currentZoneValue < 0 || zoneValue >= currentZoneValue + 10 || zoneValue < currentZoneValue) {

                    currentZoneValue = zoneValue;
                    if (world.zoneOrder == null || !Arrays.equals(positions, world.zoneOrder.getPositions())) {
                        int[] orderPositions = sortPositions(positions, zoner);
                        Order order = new Order(orderPositions);
                        order.setStep(world.step);
                        sendOrder(order);
                        //System.out.println("order sent in step " + (currentStep%751));
                    }
                }
            }
        }

        private int[] sortPositions(int[] positions, Queue<Entity> zoner) {
            final List<Integer> positionsList = new LinkedList<>();

            for(int pos: positions) {
                positionsList.add(pos);
            }

            int[] result = new int[positions.length];

            for (int i = 0; i < result.length; i++) {
                Entity e = zoner.poll();

                if(e == null) {
                    break;
                }

                Path tmp = env.getPathToNext(e.position.id, new PathFilter() {
                    @Override
                    public boolean matches(Path p) {
                        return positionsList.contains(p.getTarget());
                    }

                    @Override
                    public boolean accepts(Path p) {
                        return p.getStepCount() < 20;
                    }
                });

                if(tmp != null) {
                    result[i] = tmp.getTarget();
                    positionsList.remove((Integer)tmp.getTarget());
                }else {
                    result[i] = positionsList.remove(rand.nextInt(positionsList.size()));
                }
            }

            return result;
        }
    }
    
    private void startZoneCalculationVMC() {
        if(task != null){
            task.submit(new ZoneCalculation(world, vmc));
        }
    }

    private void startZoneCalculation() {
        if(task != null){
            task.submit(new ZoneCalculation(world, AGENTCOUNT, SAMPLES));
        }
    }
    
    private void startSampler() {
        if(task != null){
            task.submit(new Sampler(vmc, SAMPLES));
        }
    }

    public void doStart() throws Exception {
        // retrieving needed actions from own CommunicationBean
        sendAction = memory.read(new Action(
                "de.dailab.jiactng.agentcore.comm.ICommunicationBean#send",
                null, new Class[]{IJiacMessage.class,
                ICommunicationAddress.class}, null));
        if (sendAction == null) {
            throw new RuntimeException("Could not find Communication...1");
        }

		registerAction = memory
				.read(new Action(
						"de.dailab.jiactng.agentcore.comm.ICommunicationBean#joinGroup",
						null, new Class[] { IGroupAddress.class }, null));
		if (registerAction == null) {
			throw new RuntimeException("Could not find Communication...2");
		}

		invoke(registerAction, new Serializable[] { this.teamChannel });
	}

    int lastOrder = 0;

    public synchronized void sendOrder(Order order) {
        if(order.getStep() < lastOrder){
            return;
        }
        lastOrder = order.getStep();
        JiacMessage msg = new JiacMessage(order);
        Serializable[] params = new Serializable[2];
        params[0] = msg;
        params[1] = this.teamChannel;
        invoke(sendAction, params);
    }
}
