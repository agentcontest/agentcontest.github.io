package de.tub.mac13.teamb.util;

import java.util.LinkedList;
import java.util.List;

import de.tub.mac13.teamb.ontology.graph.Path;

public abstract class BehaviourFilter {
    public List<Integer> doneVertices = new LinkedList<>();
    
    public abstract boolean behavesAdd(Path path, int vertexID);
    
    public void addDoneVertex(int vertexID) {
        doneVertices.add(vertexID);
    }
    
    public void clearList() {
        doneVertices.clear();
    }
}
