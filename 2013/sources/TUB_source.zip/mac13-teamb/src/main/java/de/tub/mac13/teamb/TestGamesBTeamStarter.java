package de.tub.mac13.teamb;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.GnuParser;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

import de.dailab.jiactng.agentcore.SimpleAgentNode;

public class TestGamesBTeamStarter {

    public static String NODES_SPRINGCONFIGFILE = "classpath:Testgames-B-Team.xml";
    public static boolean SHOWSTATISTICS = false;
    public static String log = null;
    
    private static CommandLine initCLI(String[] args) {
		Options options = new Options();
		options.addOption("d", "debug", false, "Show DebugUI and Do logging!");
		options.addOption(new Option("l","log",true, "[1|2|...|28] Agent Logging"));
		
		CommandLineParser clip = new GnuParser();
		CommandLine cmd = null;
		try{
			cmd = clip.parse(options, args);
		} catch (ParseException|NullPointerException ex){
			ex.printStackTrace();
		}
		return cmd;
    }
    
    /**
     * @param args
     */
    public static void main(String[] args) {
    	
    	if(args.length > 0){
    		CommandLine cmd = initCLI(args);
    		if(cmd != null){
    			if(cmd.hasOption('d')){
    				SHOWSTATISTICS = true;
    			}
    			if(cmd.hasOption('l')){
    				log = cmd.getOptionValue('l');
    			}
    		}
    	}
        SimpleAgentNode.main(new String[]{NODES_SPRINGCONFIGFILE});
    }
}
