package de.tub.mac13.teamb;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.GnuParser;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

import de.dailab.jiactng.agentcore.SimpleAgentNode;

import java.util.HashSet;

public class BTeamStarter {

    public static String NODES_SPRINGCONFIGFILE = "classpath:B-Team.xml";
    public static boolean SHOWSTATISTICS = false;
    public static  HashSet<Integer> logIDs = null;

    public static boolean WRITE_LOG = false;

    private static CommandLine initCLI(String[] args) {
		Options options = new Options();
		options.addOption("d", "debug", false, "Show DebugUI and Do logging!");
        options.addOption("s", "stats", false, "Show Infos");
		options.addOption(new Option("l","log",true, "[1|2|...|28] Agent Logging"));
		
		CommandLineParser clip = new GnuParser();
		CommandLine cmd = null;
		try{
			cmd = clip.parse(options, args);
		} catch (ParseException|NullPointerException ex){
			ex.printStackTrace();
		}
		return cmd;
    }
    
    /**
     * @param args
     */
    public static void main(String[] args) {
    	
    	if(args.length > 0){
    		CommandLine cmd = initCLI(args);
    		if(cmd != null){
    			if(cmd.hasOption('d')){
    				SHOWSTATISTICS = true;
    			}
    			if(cmd.hasOption('l')){
    				String log = cmd.getOptionValue('l');
                    String[] ids = log.split("\\|");
                    logIDs = new HashSet<>(ids.length);
                    for(String i:ids){
                        try{
                            logIDs.add(Integer.parseInt(i));
                        } catch (Exception e){}
                    }
                    System.out.println(logIDs);
    			}
    		}
    	}
        System.out.printf("UI:%b SHOW:%b LOG:%s\n",SHOWSTATISTICS, Constants.SHOW_INFOS,logIDs);
        SimpleAgentNode.main(new String[]{NODES_SPRINGCONFIGFILE});
    }
}
