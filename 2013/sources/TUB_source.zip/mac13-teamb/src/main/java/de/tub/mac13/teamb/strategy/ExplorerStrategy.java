package de.tub.mac13.teamb.strategy;

import java.util.List;
import java.util.Map.Entry;
import java.util.Queue;

import de.tub.mac13.teamb.bean.DefaultDecisionBean;
import de.tub.mac13.teamb.ontology.Entity;
import de.tub.mac13.teamb.ontology.Goal;
import de.tub.mac13.teamb.ontology.Intention;
import de.tub.mac13.teamb.ontology.enums.AgentRole;
//import de.tub.mac13.teamb.ontology.Agent;
//import de.tub.mac13.teamb.ontology.enums.AgentRole;
import de.tub.mac13.teamb.ontology.graph.Path;
import de.tub.mac13.teamb.ontology.graph.Vertex;
import de.tub.mac13.teamb.util.EnvironmentInformation;
//import de.tub.mac13.teamb.util.PathFilter;

public class ExplorerStrategy extends DecisionStrategy {
	
	private RandomStrategy fallback;
	private EnvironmentInformation environment;
	
	public ExplorerStrategy(String username, DefaultDecisionBean d) {
		super(d, username);
		this.fallback = new ZoneStrategy(d, username);
		this.environment = new EnvironmentInformation(world);		
	}

	@Override
	public Goal getGoal() {
    	Goal result = world.teamGoals.get(world.username);
    	@SuppressWarnings("unused")
		Intention lastIntention = null;
    	if(result == null){
    		result = new Goal();
    	}
    	
    	if(result.getIntentions().size() > 0) {
    		lastIntention = result.getIntentions().removeFirst();
    	}
        Queue<Path> queue;


        // energy low => recharge
        if (world.self.energy < world.self.maxEnergy*0.25) {
        	result.addFirstIntention(recharge());
        	
            return result;
        }

        // disabled => move to nearest repairer
        if (world.self.health == 0) {
        	Path p = environment.getPathToNext(FILTER_FIND_REPAIRER, Path.BY_COST);
        	if(p != null) {
        		// repairer at own position
        		//getLog().info(world.role + ": found repairer at " + p);
        		if(p.getTarget() == world.self.position) {
        			return new Goal(recharge());
        		} else {
        			// there is enough energy for the first step
        			if (world.graph.getEdge(world.graph.getVertex(world.self.position), world.graph.getVertex((int) p.getPath().get(1))).getWeight() < world.self.energy) {
        				result = new Goal();
            			for(int i = 1; i<=p.getStepCount(); i++) {
            				result.addLastIntention(goToVertex(p.getStep(i)));
            			}
            			return result;
        			} else {
        				result.addFirstIntention(recharge());
                        return result;
        			}
        		}
        	}
        } else {
        	for(Entity e : world.getOwnAgents()) {
        		if(e.role == AgentRole.EXPLORER && e.position.id == world.self.position && world.self.id < e.id) {
        			result.addFirstIntention(fallback.gotoRandomNeighbor());
        			return(result);
        		}
        	}
            // position is unprobed => probe
            if (world.graph.getVertex(world.self.position).value == -1) {
                //System.out.println(world.username + " : probe vertex" + world.self.position + ". it's value is " + world.graph.getVertex(world.self.position).value);
            	result = new Goal(probe());
            	result.setTargetVertex(world.self.position);
            	return result;
            } else {
                // are edges to neighbors unsurveyed => survey
                Vertex[] neighbors = world.graph.getNeighborsOf(world.graph.getVertex(world.self.position));
                for (Vertex v : neighbors) {
                    if (world.graph.getEdge(world.graph.getVertex(world.self.position), v).weight == Integer.MAX_VALUE) {
                    	result.addFirstIntention(survey());
                        return result;
                    }
                }

                // find next unprobed vertex
                
                // a reachable unprobed vertex has been found
                queue = environment.getPathsToNext(STRATEGY_FIND_UNPROBED, Path.BY_STEPCOUNT);
                Path chosenPath = null;
                if (queue.size() > 0) {
                	for(Path p : queue) {
                		boolean goodPath = true;
                		// check if another explorer has the same probing goal
                		for(Entry<String, Goal> e : world.teamGoals.entrySet()) {
                			if(!world.username.equals(e.getKey()) && !e.getValue().getIntentions().isEmpty() && e.getValue().getFinalIntention().action.equals("probe") &&
                					e.getValue().getTargetVertex() == p.getTarget() && p.getStepCount()+1 > e.getValue().getCostsBySteps() ) {
                				getLog().info(world.self.role + ": my probing goal(" + p.getTarget() + ", " + (p.getStepCount()+1) + " steps), " + e.getKey() + "'s probing goal(" + e.getValue().getTargetVertex() + ", " + e.getValue().getCostsBySteps() + " steps), ");
                				goodPath = false;
                				break;
                			}
                		}
                		if(goodPath) {
                			chosenPath = p;
                			//System.out.println(world.username + ": i want to probe " + p.getTarget());
                			break;
                		}
                	}
                	//found a vertex no one is wants to probe
                	if(chosenPath != null) {
                		// there is enough energy left for the first step
                        if (world.graph.getEdge(world.graph.getVertex(world.self.position), world.graph.getVertex((int) chosenPath.getPath().get(1))).getWeight() < world.self.energy) {
                        	result = new Goal();
                			for(int i = 1; i<=chosenPath.getStepCount(); i++) {
                				result.addLastIntention(goToVertex(chosenPath.getStep(i)));
                			}
                        	result.setTargetVertex(chosenPath.getTarget());
                        	result.addLastIntention(probe());
                            return result;
                        } else {
                        	result.addFirstIntention(recharge());
                            return result;
                        }	
                	}
                }
            }
        }
        // if nothing of the above => RandomStrategy
        result = new Goal(fallback.decide());
        decider.switchStrategy(fallback);
        //System.out.println("explorer using fallback!");
        return result;
    }

    @Override
    public String toString() {
        return "ExplorerStrategy";
    }
    
    
    /*private final PathFilter STRATEGY_FIND_UNPROBED = new PathFilter() {
        @Override
        public boolean matches(Path path) {
            if(path != null) {
                if(path.getTargetVertex() != null) {
                    if(path.getTargetVertex().getValue() == -1) {
                    	return true;
                    }
                }
            }
            return false;
        }

        @Override
        public boolean accepts(Path path) {
            if(path != null) {
                if(path.getStepCount() <= 50) {
                    return true;
                }
            }
            return false;
        }
    };*/
    
    /*private final PathFilter FILTER_FIND_REPAIRER = new PathFilter() {
        @Override
        public boolean matches(Path path) {
            if(path != null) {
                for(Agent s : world.team.values()) {
                    if(s.role == AgentRole.REPAIRER && s.position == path.getTarget()) {
                        return true;
                    }
                }
            }
            return false;
        }

        @Override
        public boolean accepts(Path path) {
            if(path != null) {
                if(path.getStepCount() <= 50 && path.getLastStepCost() <= world.self.maxEnergy) {
                    return true;
                }
            }
            return false;
        }
    };*/
    
 // first iteration: probe all unprobed vertices starting from the nearest.
    @Override
    public Intention decide() {
        Intention result = new Intention(null, null);
        Queue<Path> queue;

        // energy low => recharge
        if (world.self.energy < world.self.maxEnergy*0.25) {
            return recharge();
        }

        //int[] distances = dijkstra.runDijkstra(world.graph.getVertex(world.self.position), world.graph);

        // disabled => move to nearest repairer
        if (world.self.health == 0) {
            //PriorityQueue<SelfPerception> list = listRoleByDistance(distances, "Repairer");
            
        	
            queue = environment.getPathsToNext(FILTER_FIND_REPAIRER, Path.BY_STEPCOUNT);
            
            if (queue != null && !queue.isEmpty()) {
                Path chosenPath = queue.peek();
                if (chosenPath != null) {
                    //FIX - hotfix follows produced an error @runtime
                    if (chosenPath.getPath() != null && !chosenPath.getPath().isEmpty()) {
                        // nearest repairer is at agents position => do nothing / recharge
                        if (chosenPath.getPath().size() == 1) {
                            return recharge();
                        } else {
                        	//System.out.println("explorer " + world.self.username + " trying to reach repairer at " + chosenPath.getTarget());
                        	//world.self.currentGoal = goToVertex(chosenPath.getTarget());
                        	//System.out.println(world.username + ": " + world.self.currentGoal);
                            return goToVertex(chosenPath.getPath().get(1));
                        }
                    } else { // no path to a repairer has been found => do nothing / recharge
                        return recharge();
                    }
                }
            }
        } else {
            // position is unprobed => probe
            if (world.graph.getVertex(world.self.position).value == -1) {
                //System.out.println(world.username + " : probe vertex" + world.self.position + ". it's value is " + world.graph.getVertex(world.self.position).value);
                return probe();
            } else {
                // are edges to neighbors unsurveyed => survey
                Vertex[] neighbors = world.graph.getNeighborsOf(world.graph.getVertex(world.self.position));
                for (Vertex v : neighbors) {
                    if (world.graph.getEdge(world.graph.getVertex(world.self.position), v).weight == Integer.MAX_VALUE) {
                        return survey();
                    }
                }

                // find next unprobed vertex

                // a reachable unprobed vertex has been found
                queue = environment.getPathsToNext(STRATEGY_FIND_UNPROBED, Path.BY_STEPCOUNT);
                if (queue.size() > 0) {
                    Path chosenPath = queue.peek();
                    //System.out.println(world.username + ": " + world.self.currentGoal);

                    //System.out.println(world.username + ": " + chosenPath.toString());

                    // there is enough energy left for the first step
                    if (world.graph.getEdge(world.graph.getVertex(world.self.position), world.graph.getVertex((int) chosenPath.getPath().get(1))).getWeight() < world.self.energy) {
                        return goToVertex(chosenPath.getPath().get(1));
                    } else {
                        return recharge();
                    }
                }
            }
        }
        // if nothing of the above => RandomStrategy
        result = fallback.decide();
        //System.out.println("explorer using fallback!");
        return result;
    }

    @Override
    public List<Intention> decisionPlan() {
        // TODO ExplorerStrategy.decisionPlan
        return null;
    }
}
