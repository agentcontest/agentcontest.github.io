package de.tub.mac13.teamb.util;

import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Random;

import de.tub.mac13.teamb.ontology.World;
import de.tub.mac13.teamb.ontology.graph.Path;
import de.tub.mac13.teamb.ontology.graph.Vertex;

public class BestZoneVMCCalculator {
    private World world;
    private List<Path[]> samples = new LinkedList<Path[]>();
    private int length;
    private EnvironmentInformation env;
    private Random rand = new Random();
    private Zoner zoner;
    private Heater heater;

    private LinkedList<Integer> heatV;
    private LinkedList<Integer> coldV;
    private LinkedList<Integer> filteredHeat;
    
    
    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }
    
    public BestZoneVMCCalculator(World world, int length) {
        this.world = world;
        this.zoner = new Zoner(world);
        this.length = length;
        this.env = new EnvironmentInformation(world);
        this.heater = new Heater(world);
        
        init();
    }
    
    private void init() {
        heatV = new LinkedList<>();
        coldV = new LinkedList<>();
        for(Vertex v: heater.getHeatVertices()) {
            heatV.add(v.id);
        }
        
        List<Vertex> tmpCold = heater.getHeatVertices(false);
        for(Vertex v: tmpCold) {
            coldV.add(v.id);
        }
        
        this.zoner.setStopVertices(tmpCold);
        filteredHeat = new LinkedList<>();

        for(Integer vid : heatV) {
            for(Vertex w : world.graph.getNeighborsOf(vid)) {
                if(!heatV.contains(w)) {
                    filteredHeat.add(vid);
                    break;
                }
            }
        }
    }
    
    public void sample(int n) {
        for(int i = 0; i < n; i++) {
            sample();
        }
    }
    
    public void sample() {
        Path[] paths = makeRandomPath();
        
        List<Integer> temp = new LinkedList<>();

        for(Path p: paths) {
            temp.addAll(p.getShortPath());
        }
        paths[0].setZone(zoner.buildZoneWithIDs(temp));
        
        this.samples.add(paths);
    }
    
    public int[] getBestPath(List<Integer> enemies) {
        Path[] bestPaths = null;
        int bestZoneV = 0;
        
        for(Path[] paths: samples) {
            int zoneV = paths[0].getZoneValue();
            
            boolean next = true;
            
            for(int i : enemies) {
                if(paths[0].getZone().getVertexIndices().contains(i)) {
                    next = false;
                }
            }
            
            if(next && (bestPaths == null || zoneV > bestZoneV)) {
                bestPaths = paths;
                bestZoneV = zoneV;
            }
        }
        
        int[] result = null;
        
        if(bestPaths != null) {
            int s = 0;
            for(Path p: bestPaths) {
                s += p.getShortPath().size();
            }
            
            result = new int[s];
            
            int offset = 0;
            
            for(Path p: bestPaths) {
                for(int i = 0; i < p.getShortPath().size(); i++) {
                    result[i + offset] = p.getShortPath().get(i);
                }
                offset += p.getShortPath().size();
            }
        }
        
        return result;
    }
    
    protected List<int[]> getLengths(int length) {
        int minLength = 4;
        List<int[]> result = new LinkedList<int[]>();
        result.add(new int[]{length});
        int count = length / minLength;
        
        for(int i = 2; i <= count; i++) {
            int diff = length - i * minLength;
            int[] temp = new int[i];
            
            for(int j = 0; j < temp.length; j++) {
                temp[j] = minLength;
            }
            temp[i-1] += diff;
            
            result.add(copyIntArray(temp));
            
            int[] minMax = getMinMax(temp);
            
            while(temp[minMax[0]] + 1 < temp[minMax[1]]) {
                temp[minMax[0]] += 1;
                temp[minMax[1]] -= 1;
                
                result.add(copyIntArray(temp));

                minMax = getMinMax(temp);
            }
        }
        return result;
    }
    
    private int[] copyIntArray(int[] orginal) {
        int[] result = new int[orginal.length];
        
        for(int i = 0; i < result.length; i++) {
            result[i] = orginal[i];
        }
        
        return result;
    }
    
    private int[] getMinMax(int[] c) {
        int[] minMax = new int[]{-1,-1};
        int[] values = new int[]{0,0};
        
        for(int i = 0; i < c.length; i++) {
            if(minMax[0] == -1 || values[0] > c[i]) {
                minMax[0] = i;
                values[0] = c[i];
            }
            if(minMax[1] == -1 || values[1] < c[i]) {
                minMax[1] = i;
                values[1] = c[i];
            }
        }
        
        return minMax;
    }
    
    private Path[] makeRandomPath() {
        
        List<int[]> poss = getLengths(this.length);
        
        // get path lengths
        int[] paths = poss.get(rand.nextInt(poss.size()-1));
        
        Path[] result = new Path[paths.length];
        
        List<Integer> evade = new LinkedList<Integer>();
        
        for(int i = 0; i < paths.length; i++) {
            do {
                int startID = filteredHeat.get(rand.nextInt(filteredHeat.size()));
            
                result[i] = makePath(startID, paths[i] * 2 - 1, evade);
                
            }while(result[i] == null);
            
            evade.addAll(result[i].getPath());
        }
        return result;
    }
    
    private Path makePath(int startID, final int length, final List<Integer> evade) {
        Path path = env.getPathToNext(startID, new PathFilter() {
            @Override
            public boolean matches(Path path) {
                return path.getStepCount() == length;
            }

            @Override
            public boolean accepts(Path path) {
                Vertex target = path.getTargetVertex();
                if(path.getStepCount() > length || evade.contains(target.id))
                    return false;

                for(Vertex v : world.graph.getNeighborsOf(target)) {
                    if((path.getStep(path.getStepCount() - 1) != v.id) && path.contains(v) || evade.contains(v.id)) {
                        return false;
                    }
                }
                return true;
            }

        }, COMPARE_RANDOM);
        
        return path;
    }
    
    private static final Comparator<Path> COMPARE_RANDOM = new Comparator<Path>() {
        Random r = new Random();
        @Override
        public int compare(Path p1, Path p2) {
            return r.nextInt(2) - 1;
        }
    };
    
    

}
