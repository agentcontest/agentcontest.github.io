package de.tub.mac13.teamb.util.visual;

import java.io.Serializable;

/**
 * This class represents and Edge in the graph that forms the map.
 */
public class GraphEdge implements Serializable {

    private static final long serialVersionUID = -2064294215950641200L;
    public GraphNode node1;
    public GraphNode node2;
    public int weight;

    public GraphEdge(int weight, GraphNode node1, GraphNode node2) {

        this.weight = weight;
        this.node1 = node1;
        this.node2 = node2;

    }

    public float getLength() {

        return (float) Math.sqrt((node1.x - node2.x) * (node1.x - node2.x) + (node1.y - node2.y) * (node1.y - node2.y));

    }

    @Override
    public String toString() {
        double distance = Math.sqrt(Math.pow(node1.gridX - node2.gridX, 2) + Math.pow(node1.gridY - node2.gridY, 2));
        return String.format("Edge(node1=%s, node2=%s, weight=%d, distance=%.2f)",
                node1.id, node2.id, weight, distance);
    }
}