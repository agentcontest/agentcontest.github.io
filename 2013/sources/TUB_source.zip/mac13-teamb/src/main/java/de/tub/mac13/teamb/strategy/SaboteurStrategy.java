package de.tub.mac13.teamb.strategy;

//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
import java.util.Map.Entry;

import de.tub.mac13.teamb.bean.DefaultDecisionBean;
import de.tub.mac13.teamb.ontology.Entity;
import de.tub.mac13.teamb.ontology.Goal;
import de.tub.mac13.teamb.ontology.Intention;
//import de.tub.mac13.teamb.ontology.Agent;
import de.tub.mac13.teamb.ontology.enums.TeamType;
import de.tub.mac13.teamb.ontology.graph.Path;
import de.tub.mac13.teamb.util.EnvironmentInformation;
//import de.tub.mac13.teamb.util.PathFilter;

public class SaboteurStrategy extends RandomStrategy {

	private Random r = new Random();
    private RandomStrategy fallback;
    private int consecutiveAttacks;
    private String currentVictim;
    private LinkedList<String> lastVictims;
    private EnvironmentInformation environment;

    public SaboteurStrategy(DefaultDecisionBean decider, String username) {
        super(decider, username);
        this.fallback = new RandomStrategy(decider, username);
        this.environment = new EnvironmentInformation(world);
        this.lastVictims = new LinkedList<String>();
        this.consecutiveAttacks = 0;
        currentVictim = "";
    }
    
    @Override
    public Goal getGoal() {
    	
    	Goal result = world.teamGoals.get(world.username);
    	if(result == null){
    		result = new Goal();
    	}

    	// last attack successful and on same target? +1 consecutive attacks
    	if(world.teamActions != null && world.teamActions.containsKey(username) && !world.teamActions.get(username).isEmpty()) {
    		Intention lastAction = world.teamActions.get(username).peek();
    		
        	if(lastAction.action.equals("attack") && lastAction.param.equals(currentVictim) && lastAction.success) {
        		consecutiveAttacks++;
        		//getLog().info("i think i hit a guy");
        		// check if enemy should have died by now
        		int assumedMaxHealth = 8;
        		
        		/*for(Entry<Integer, Entity> e : world.enemyAgents.entrySet()) {
        			if(e.getValue().name.equals(currentVictim)) {
        				assumedMaxHealth = e.getValue().maxEnergy;
        				getLog().info("assuming max health for " + currentVictim + ": " + assumedMaxHealth);
        				break;
        			}
        		}*/
        		 
        		//getLog().info("my consecutive attacks: " + consecutiveAttacks);
        		if((world.self.strength * consecutiveAttacks) >= assumedMaxHealth) {
        			getLog().info("i think i killed a guy");
        			if(lastVictims.size() >= 4) {
        				lastVictims.removeFirst();
        			}
        			lastVictims.add(currentVictim);
        		}
        	}
    	}
    	
    	// energy low => recharge
        if (world.self.energy < 2) {
        	result.addFirstIntention(recharge());
        	
            return result;
        }

        // disabled => move to nearest repairer
        if (world.self.health == 0) {
        	//getLog().info("trying to find repairer");
        	Path p = environment.getPathToNext(FILTER_FIND_REPAIRER);
        	
        	if(p != null) {
        		getLog().info(world.self.role + ": found repairer at " + p);
        		// repairer at own position
        		if(p.getTarget() == world.self.position) {
        			return new Goal(recharge());
        		} else {
        			// there is enough energy for the first step
        			if (world.graph.getEdge(world.graph.getVertex(world.self.position), world.graph.getVertex((int) p.getPath().get(1))).getWeight() < world.self.energy) {
        				result = new Goal();
            			for(int i = 1; i<=p.getStepCount(); i++) {
            				result.addLastIntention(goToVertex(p.getStep(i)));
            			}
            			return result;
        			} else {
        				result.addFirstIntention(recharge());
                        return result;
        			}
        		}
        	}
        } else {
        	//getLog().info("trying to find enemy");
        	// functional => seek enemy agent 
        	//getLog().info("enemies in world.enemyAgents: " + world.enemyAgents.entrySet().size());
        	Queue<Path> enemyQueue = environment.getPathsToNext(FILTER_FIND_ENEMY);
        	if(!enemyQueue.isEmpty()) {
        		//getLog().info(world.role + ": found enemy at " + enemyQueue.peek());
        		// if currentVictimRoleMaxHealth < Strength*consecutiveAttacks => change victim
        		Path chosenPath = null;
        		for(Path p : enemyQueue) {
        			boolean goodPath = true;
        			// fill enemy list for the target Vertex
        			LinkedList<String> enemyList = new LinkedList<String>();
        			for(Entity e : world.enemyAgents.values()) {
        				if(e.position.id == p.getTarget() && (world.step - e.lastUpdate) <= 1) {
        					enemyList.add(e.name);
        					//getLog().info(enemyList.toString());
        				}
        			}
        			
        			// check if none of the enemies on the path are on the lastVictims list
        			if(lastVictims.containsAll(enemyList)) {
        				//getLog().info("all agents on enemyList are lastVictims");
        				goodPath = false;
        			}
        			// check if no other saboteur is currently attacking this agent
        			// also check for currentness information
        			for(Entry<String, Goal> en : world.teamGoals.entrySet()) {
        				if(!world.username.equals(en.getKey()) && !en.getValue().getIntentions().isEmpty() && en.getValue().getFinalIntention().action.equals("attack") &&
        						en.getValue().getTargetVertex() == p.getTarget() && p.getStepCount()+1 > en.getValue().getCostsBySteps() ) {
        					getLog().info(world.self.role + ": my attacking goal(" + p.getTarget() + ", " + (p.getStepCount()+1) + " steps), " + en.getKey() + "'s attacking goal(" + en.getValue().getTargetVertex() + ", " + en.getValue().getCostsBySteps() + " steps), ");
        					goodPath = false;
        					break;
        				}
        			}
        			
        			if(goodPath) {
            			chosenPath = p;
            			for(String en : enemyList) {
            				if(!lastVictims.contains(en)) {
            					if(en != currentVictim) {
            						consecutiveAttacks = 0;
            						currentVictim = en;
            					}
            				}
            			}
            			break;
            		}
        		}
        		
        		if(chosenPath != null) {
    				result = new Goal();
    				result.setTargetVertex(chosenPath.getTarget());
    				// target is at own position
    				if(chosenPath.getStepCount() == 0) {
    					getLog().info(world.self.strategy + ": attacking " + currentVictim);
    					result.addLastIntention(attack(currentVictim));
    					return result;
    				}
            		// there is enough energy left for the first step
                    if (chosenPath.getFirstStepCost() < world.self.energy) {
            			for(int i = 1; i<=chosenPath.getStepCount(); i++) {
            				result.addLastIntention(goToVertex(chosenPath.getStep(i)));
            			}
                    	result.setTargetVertex(chosenPath.getTarget());
                    	result.addLastIntention(attack(currentVictim));
                        return result;
                    } else {
                    	result.addFirstIntention(recharge());
                        return result;
                    }	
            	}
        	}
        }
    	
        getLog().info(world.self.role + " using fallback.");
    	return new Goal(fallback.decide());
    }
    

    @Override
    public Intention decide() {
        Intention intent = null;
        //only attack some times otherwise we tent to beat a dead horse/agent
        synchronized (world.enemyAgents) {
            int choice = r.nextInt(world.enemyAgents.size() / 2 + 2);
            if (choice > world.enemyAgents.size() / 2) {
                for (Entity e : world.getEnemyAgents()) {
                    if (e == null) {
                        continue;
                    }
                    if (e.team != TeamType.OWN && e.position.id == world.self.position) {
                        intent = attack(e);
                        break;
                    }
                }
            }
        }


        if (intent == null) {
            return super.decide();
        }
        return intent;
    }
    
    /*private final PathFilter FILTER_FIND_REPAIRER = new PathFilter() {
        @Override
        public boolean matches(Path path) {
            if(path != null) {
                for(Agent s : world.team.values()) {
                    if(s.role.equals("Repairer") && s.position == path.getTarget()) {
                        return true;
                    }
                }
            }
            return false;
        }

        @Override
        public boolean accepts(Path path) {
            if(path != null) {
                if(path.getStepCount() <= 50 && path.getLastStepCost() <= world.self.maxEnergy) {
                    return true;
                }
            }
            return false;
        }
    };*/
    
    /*private final PathFilter FILTER_FIND_ENEMY = new PathFilter() {
        @Override
        public boolean matches(Path path) {
            if(path != null) {
                for(Entry<Integer, Entity> e : world.enemyAgents.entrySet()) {
                    if(e.getValue().team.equals(TeamType.ENEMY) && e.getValue().position.id == path.getTarget()) {
                        return true;
                    }
                }
            }
            return false;
        }

        @Override
        public boolean accepts(Path path) {
            if(path != null) {
                if(path.getStepCount() <= 50 && path.getLastStepCost() <= world.self.maxEnergy) {
                    return true;
                }
            }
            return false;
        }
    };*/

    @Override
    public String toString() {
        return "SaboteurStrategy";
    }
}
