package de.tub.mac13.teamb.util;

public interface Filter<E> {

    public boolean matches(E elem);
}
