package de.tub.mac13.teamb.util;

import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;

import de.tub.mac13.teamb.ontology.World;
import de.tub.mac13.teamb.ontology.graph.Path;
import de.tub.mac13.teamb.ontology.graph.Vertex;

/**
 * A convenient class to get informations of the agents environment, like
 * finding the next enemy or team mate
 * 
 * @author MAC Team B 2013
 * 
 */
public class EnvironmentInformation {
    private World world;
    private Comparator<Path> comparator;

    /**
     * Sets the {@link #comparator} to By Cost {@link Path#BY_COST}
     * 
     * @param world
     */
    public EnvironmentInformation(World world) {
        this.world = world;
        // DEFAULT!
        this.comparator = Path.BY_COST;
    }

    public EnvironmentInformation(World world, Comparator<Path> pathComparator) {
        this.world = world;
        this.comparator = pathComparator;
    }

    // ALL the CALLS

    /**
     * invokes {@link #searchPath(PriorityQueue, List, Filter, Comparator)}
     * after creating a new searchQueue
     * 
     * @param startVertexID
     * @param filters
     * @param endFilter
     * @param pathComparator
     * @return
     */
    public List<Queue<Path>> getPathsToNext(int startVertexID, List<PathFilter> filters, Filter<List<Queue<Path>>> endFilter,
            Comparator<Path> pathComparator, Comparator<Path>[] resultComparator, BehaviourFilter behaveFilter) {
        PriorityQueue<Path> searchQueue = new PriorityQueue<Path>(10, pathComparator);

        searchQueue.add(new Path(startVertexID, world));
        List<Queue<Path>> e =  searchPath(searchQueue, filters, endFilter, resultComparator, behaveFilter);
        return e;
    }

    public List<Queue<Path>> getPathsToNext(int startVertexID, List<PathFilter> filters, Filter<List<Queue<Path>>> endFilter,
            Comparator<Path> pathComparator, Comparator<Path>[] resultComparator) {
        return getPathsToNext(startVertexID, filters, endFilter, pathComparator, resultComparator, BEHAVIOUR_DEFAULT);
    }

    /**
     * calls
     * {@link #getPathsToNext(int, List, Filter, Comparator, Comparator[])}
     * using world.self.position for startVertexID
     * 
     * @return @see
     *         {@link #getPathsToNext(int, List, Filter, Comparator, Comparator[])}
     */
    public List<Queue<Path>> getPathsToNext(int startVertexID, List<PathFilter> filters, Filter<List<Queue<Path>>> endFilter,
            Comparator<Path> pathComparator) {
        @SuppressWarnings("unchecked")
        Comparator<Path>[] resultComparator = new Comparator[filters.size()];

        for(int i = 0; i < filters.size(); i++) {
            resultComparator[i] = pathComparator;
        }
        return getPathsToNext(startVertexID, filters, endFilter, pathComparator);
    }

    /**
     * calls {@link #getPathsToNext(List, Filter, Comparator, Comparator[])}
     * using world.self.position for startVertexID
     * 
     * @return @see
     *         {@link #getPathsToNext(List, Filter, Comparator, Comparator[])}
     */
    public List<Queue<Path>> getPathsToNext(List<PathFilter> filters, Filter<List<Queue<Path>>> endFilter, Comparator<Path> pathComparator,
            Comparator<Path>[] resultComparator) {
        return getPathsToNext(world.self.position, filters, endFilter, pathComparator, resultComparator);
    }

    /**
     * calls {@link #getPathsToNext(int, List, Filter, Comparator)} using
     * world.self.position for startVertexID
     * 
     * @return @see {@link #getPathsToNext(int, List, Filter, Comparator)}
     */
    public List<Queue<Path>> getPathsToNext(List<PathFilter> filters, Filter<List<Queue<Path>>> endFilter, Comparator<Path> pathComparator) {
        return getPathsToNext(world.self.position, filters, endFilter, pathComparator);
    }

    /**
     * calls {@link #getPathsToNext(List, Filter, Comparator[])} using the class
     * wide Comparator {@link #comparator}
     * 
     * @return
     */
    public List<Queue<Path>> getPathsToNext(List<PathFilter> filters, Filter<List<Queue<Path>>> endFilter, Comparator<Path>[] resultComparator) {
        return getPathsToNext(filters, endFilter, comparator, resultComparator);
    }

    /**
     * calls {@link #getPathsToNext(PathFilter, Filter, Comparator)} using the
     * class wide Comparator {@link #comparator}
     * 
     * @return
     */
    public List<Queue<Path>> getPathsToNext(List<PathFilter> filters, Filter<List<Queue<Path>>> endFilter) {
        return getPathsToNext(filters, endFilter, comparator);
    }

    /**
     * calls {@link #getPathsToNext(int, PathFilter, Filter, Comparator)}
     * creates Filter list of the given PathFilter
     * 
     * @return
     */
    public Queue<Path> getPathsToNext(int startVertexID, PathFilter filter, Filter<List<Queue<Path>>> endFilter, Comparator<Path> pathComparator,
            Comparator<Path> resultComparator, BehaviourFilter behaveFilter) {
        @SuppressWarnings("unchecked")
        Comparator<Path>[] resultComparators = new Comparator[1];

        resultComparators[0] = resultComparator;

        PriorityQueue<Path> searchQueue = new PriorityQueue<Path>(10, pathComparator);

        searchQueue.add(new Path(startVertexID, world));
        List<PathFilter> filters = new LinkedList<PathFilter>();
        filters.add(filter);

        List<Queue<Path>> path = getPathsToNext(startVertexID, filters, endFilter, pathComparator, resultComparators, behaveFilter);
        if(path != null && !path.isEmpty()) {
            return path.get(0);
        } else {
            return null;
        }
    }

    public Queue<Path> getPathsToNext(int startVertexID, PathFilter filter, Filter<List<Queue<Path>>> endFilter, Comparator<Path> pathComparator,
            Comparator<Path> resultComparator) {
        return getPathsToNext(startVertexID, filter, endFilter, pathComparator, resultComparator, BEHAVIOUR_DEFAULT);
    }

    /**
     * calls {@link #getPathsToNext(int, PathFilter, Filter, Comparator)}
     * creates Filter list of the given PathFilter
     * 
     * @return
     */
    public Queue<Path> getPathsToNext(int startVertexID, PathFilter filter, Filter<List<Queue<Path>>> endFilter, Comparator<Path> pathComparator) {
        return getPathsToNext(startVertexID, filter, endFilter, pathComparator, pathComparator);
    }

    public Queue<Path> getPathsToNext(int startVertexID, PathFilter filter, Filter<List<Queue<Path>>> endFilter, Comparator<Path> pathComparator,
            BehaviourFilter behaveFilter) {
        return getPathsToNext(startVertexID, filter, endFilter, pathComparator, pathComparator, behaveFilter);
    }

    /**
     * calls {@link #getPathsToNext(int, PathFilter, Filter, Comparator)} uses
     * the {@link #ENDFILTER_DEFAULT} Filter
     * 
     * @param startVertxID
     * @param filter
     * @param pathComparator
     * @return
     */
    public Queue<Path> getPathsToNext(int startVertxID, PathFilter filter, Comparator<Path> pathComparator, Comparator<Path> resultComparator) {
        return getPathsToNext(startVertxID, filter, ENDFILTER_DEFAULT, pathComparator, resultComparator);
    }

    /**
     * Enables you to use a Vertex instead of a Vertex ID and calls
     * {@link #getPathsToNext(int, PathFilter, Filter, Comparator)}
     * 
     * @param start
     * @param filter
     * @param pathComparator
     * @return
     */
    public Queue<Path> getPathsToNext(Vertex start, PathFilter filter, Comparator<Path> pathComparator) {
        return getPathsToNext(start.id, filter, pathComparator, pathComparator);
    }

    public Queue<Path> getPathsToNext(PathFilter filter, Comparator<Path> pathComparator, Comparator<Path> resultComparator) {
        return getPathsToNext(world.self.position, filter, pathComparator, resultComparator);
    }

    /**
     * finds path form the current location using only a single filter and a
     * pathComperator calls
     * {@link #getPathsToNext(int, PathFilter, Filter, Comparator)}
     * 
     * @param filter
     * @param pathComparator
     * @return
     */
    public Queue<Path> getPathsToNext(PathFilter filter, Comparator<Path> pathComparator) {
        return getPathsToNext(world.self.position, filter, pathComparator, pathComparator);
    }

    public Queue<Path> getPathsToNextSorted(PathFilter filter, Comparator<Path> resultComparator) {
        return getPathsToNext(world.self.position, filter, comparator, resultComparator);
    }

    /**
     * finds path form the agents current position using only a single filter
     * and the class default {@link #comparator}</br> calls
     * {@link #getPathsToNext(int, PathFilter, Filter, Comparator)}
     * 
     * @param filter
     * @return
     */
    public Queue<Path> getPathsToNext(PathFilter filter) {
        return getPathsToNext(world.self.position, filter, comparator, comparator);
    }

    /**
     * Similar to {@link #getPathsToNext(int, PathFilter, Comparator))} but only
     * returns best path given the pathComparator
     * 
     * @param startID
     * @param filter
     * @param pathComparator
     * @return
     */

    public Path getPathToNext(int startID, PathFilter filter, Comparator<Path> pathComparator, BehaviourFilter behaveFilter) {
        Queue<Path> paths = getPathsToNext(startID, filter, ENDFILTER_ONE, pathComparator, behaveFilter);
        if(paths != null)
            return paths.poll();
        else
            return null;
    }

    public Path getPathToNext(int startID, PathFilter filter, Comparator<Path> pathComparator) {
        return getPathToNext(startID, filter, pathComparator, BEHAVIOUR_DEFAULT);
    }

/**
     * Similar to  {@link #getPathsToNext(Vertex, PathFilter, Comparator)
     * @param start
     * @param filter
     * @param pathComparator
     * @return
     */
    public Path getPathToNext(Vertex start, PathFilter filter, Comparator<Path> pathComparator, BehaviourFilter behaveFilter) {
        return getPathToNext(start.id, filter, pathComparator, behaveFilter);
    }

    public Path getPathToNext(Vertex start, PathFilter filter, Comparator<Path> pathComparator) {
        return getPathToNext(start.id, filter, pathComparator);
    }

    /**
     * calls {@link #getPathsToNext(int, PathFilter, Filter, Comparator)} using
     * the current position of the agent
     * 
     * @param filter
     * @param pathComparator
     * @return
     */
    public Path getPathToNext(PathFilter filter, Comparator<Path> pathComparator, BehaviourFilter behaveFilter) {
        return getPathToNext(world.self.position, filter, pathComparator, behaveFilter);
    }

    public Path getPathToNext(PathFilter filter, Comparator<Path> pathComparator) {
        return getPathToNext(world.self.position, filter, pathComparator);
    }

    /**
     * calls {@link #getPathsToNext(int, PathFilter, Comparator))} uses the
     * class {@link #comparator}
     * 
     * @param startID
     * @param filter
     * @return
     */
    public Path getPathToNext(int startID, PathFilter filter, BehaviourFilter behaveFilter) {
        return getPathToNext(startID, filter, comparator, behaveFilter);
    }

    public Path getPathToNext(int startID, PathFilter filter) {
        return getPathToNext(startID, filter, comparator);
    }

    /**
     * calls {@link #getPathsToNext(int,PathFilter)}
     * 
     * @param start
     * @param filter
     * @return
     */
    public Path getPathToNext(Vertex start, PathFilter filter) {
        return getPathToNext(start.id, filter);
    }

    /**
     * calls {@link #getPathsToNext(int,PathFilter)} using the agents current
     * position
     * 
     * @param filter
     * @return
     */
    public Path getPathToNext(PathFilter filter, BehaviourFilter behaveFilter) {
        return getPathToNext(world.self.position, filter, behaveFilter);
    }

    public Path getPathToNext(PathFilter filter) {
        return getPathToNext(world.self.position, filter);
    }

    public Path getPathToPosition(Vertex vertex) {
        return getPathToPosition(vertex.id);
    }

    public Path getPathToPosition(final int vertexID) {
        PathFilter filter = new PathFilter() {

            @Override
            public boolean matches(Path path) {
                return(path.getTarget() == vertexID);
            }

        };

        return getPathToNext(filter);
    }

    // Main Functions ----

    /**
     * set ups result Queues and invokes
     * {@link #searchPath(PriorityQueue, List, Filter, List)}
     * 
     * @param queue
     * @param filters
     * @param endFilter
     * @param pathComparator
     * @return
     */
    private List<Queue<Path>> searchPath(PriorityQueue<Path> queue, List<PathFilter> filters, Filter<List<Queue<Path>>> endFilter,
            Comparator<Path>[] resultComparator, BehaviourFilter behaveFilter) {

        List<Queue<Path>> result = new LinkedList<>();
        for(int i = 0; i < filters.size(); i++) {
            result.add(new PriorityQueue<Path>(10, resultComparator[i]));
        }
        return searchPath(queue, filters, endFilter, result, new LinkedList<Integer>(), behaveFilter);
    }

    /**
     * 
     * @param queue
     * @param filters
     * @param endFilter
     * @param result
     * @return
     */
    private List<Queue<Path>> searchPath(PriorityQueue<Path> queue, List<PathFilter> filters, Filter<List<Queue<Path>>> endFilter,
            List<Queue<Path>> result, List<Integer> doneVertices, BehaviourFilter behaveFilter) {
        Path current = queue.poll();
        if(current == null || endFilter.matches(result)) {
            behaveFilter.clearList();
            return result;
        }
        //doneVertices.add(current.getTarget());
        behaveFilter.addDoneVertex(current.getTarget());

        for(int i = 0; i < filters.size(); i++) {
            Filter<Path> f = filters.get(i);
            if(f.matches(current)) {
                result.get(i).add(current);
            }
        }

        for(Vertex v : world.graph.getNeighborsListOf(current.getTargetVertex())) {
            //if(!current.contains(v) && !doneVertices.contains(v.id)) {
            if(behaveFilter.behavesAdd(current, v.id)) {
                Path path = new Path(current);
                if(path.addStep(v)) {
                    for(PathFilter f : filters) {
                        if(f.accepts(path)) {
                            addIfBestInQueue(queue, path);
                            break;
                        }
                    }
                }
            }
        }

        return searchPath(queue, filters, endFilter, result, doneVertices, behaveFilter);
    }

    /**
     * 
     * @param queue
     * @param path
     */
    private void addIfBestInQueue(PriorityQueue<Path> queue, Path path) {
        if(queue.isEmpty()) {
            queue.add(path);
        } else {
            for(Path p : new PriorityQueue<>(queue)) {
                if(path.getStart() == p.getStart() && path.getTarget() == p.getTarget()) {
                    if(queue.comparator().compare(path, p) < 0) {
                        queue.remove(p);
                        queue.add(path);
                    }
                    return;
                }
            }
            queue.add(path);
        }
    }

    public Comparator<Path> getComparator() {
        return comparator;
    }

    public void setComparator(Comparator<Path> comparator) {
        this.comparator = comparator;
    }

    public static final Filter<List<Queue<Path>>> ENDFILTER_DEFAULT = new Filter<List<Queue<Path>>>() {

        @Override
        public boolean matches(List<Queue<Path>> list) {
            int count = 0;

            for(Queue<Path> p : list) {
                count += p.size();
            }

            return count >= 10;
        }
    };

    public static final Filter<List<Queue<Path>>> ENDFILTER_ONE = new Filter<List<Queue<Path>>>() {
        @Override
        public boolean matches(List<Queue<Path>> list) {
            int count = 0;

            for(Queue<Path> p : list) {
                count += p.size();
            }

            return count >= 1;
        }
    };

    public final BehaviourFilter BEHAVIOUR_DEFAULT = new BehaviourFilter() {

        @Override
        public boolean behavesAdd(Path path, int vertexID) {
            return !path.contains(vertexID) && !doneVertices.contains(vertexID);
        }
    };
}