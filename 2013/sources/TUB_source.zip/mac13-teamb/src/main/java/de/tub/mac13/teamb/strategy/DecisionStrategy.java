package de.tub.mac13.teamb.strategy;

import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Map.Entry;

import de.tub.mac13.teamb.Constants;
import de.tub.mac13.teamb.bean.DefaultDecisionBean;
import de.tub.mac13.teamb.ontology.Entity;
import de.tub.mac13.teamb.ontology.Goal;
import de.tub.mac13.teamb.ontology.Intention;
import de.tub.mac13.teamb.ontology.Agent;
import de.tub.mac13.teamb.ontology.World;
import de.tub.mac13.teamb.ontology.enums.AgentRole;
import de.tub.mac13.teamb.ontology.enums.StrategyType;
import de.tub.mac13.teamb.ontology.enums.TeamType;
import de.tub.mac13.teamb.ontology.graph.Edge;
import de.tub.mac13.teamb.ontology.graph.Path;
import de.tub.mac13.teamb.ontology.graph.Vertex;
import de.tub.mac13.teamb.util.Filter;
import de.tub.mac13.teamb.util.Logger;
import de.tub.mac13.teamb.util.PathFilter;

public abstract class DecisionStrategy {
    //TODO erweitere um sinnvolle Methoden, Attribute etc
	//TODO path_filter in decision statt in einzelen
    protected DefaultDecisionBean decider;
    protected String username;
    protected World world;
    
    protected DecisionStrategy fallback = null;
    

    public DecisionStrategy(DefaultDecisionBean decider, String username) {
        this.decider = decider;
        this.username = username;
        
        world = decider.getWorld();
    }

    public abstract Intention decide();

    //TODO decisionPlan
    public abstract List<Intention> decisionPlan();

    public abstract String toString();

    public Logger getLog() {
        return decider.getWorld().log;
    }
    //TODO insert general functions here

    protected Intention goToVertex(Vertex v) {
        return goToVertex(v.getId());
    }

    protected Intention goToVertexIgnoreEnergy(int v) {
        return new Intention(Constants.ACTION_GOTO, Constants.VERTEX_PREFIX + v);
    }

    protected Intention goToVertex(int v) {
        Edge e = world.graph.getEdge(world.self.position,v);
        if(e != null){
            if(world.self.energy < e.getWeight()){
                getLog().info("goto changed into recharge! " + this.username + " fucked up!");
                return recharge();
            }
        }
        return new Intention(Constants.ACTION_GOTO, Constants.VERTEX_PREFIX + v);
    }

    protected Intention survey() {
        return new Intention(Constants.ACTION_SURVEY, null);
    }

    protected Intention skip() {
        return new Intention(Constants.ACTION_SKIP, null);
    }

    protected Intention attack(String enemy) {
        return new Intention(Constants.ACTION_ATTACK, enemy);
    }

    protected Intention attack(Entity e) {
        return new Intention(Constants.ACTION_ATTACK, e.name);
    }

    protected Intention parry() {
        return new Intention(Constants.ACTION_PARRY, null);
    }

    protected Intention recharge() {
        return new Intention(Constants.ACTION_RECHARGE, null);
    }

    protected Intention repair(String teammate) {
        return new Intention(Constants.ACTION_REPAIR, teammate);
    }

    protected Intention repair(Entity e) {
        return new Intention(Constants.ACTION_REPAIR, e.name);
    }

    protected Intention probe() {
        return new Intention(Constants.ACTION_PROBE, null);
    }
    
    protected Intention inspect() {
		return new Intention(Constants.ACTION_INSPECT, null);
	}

    protected PriorityQueue<Agent> listRoleByDistance(final int[] dist, Filter<Agent> filter) {
        PriorityQueue<Agent> roleQueue = new PriorityQueue<>(28, new Comparator<Agent>() {
            @Override
            public int compare(Agent o1, Agent o2) {
                int d1 = dist[o1.position], d2 = dist[o2.position];
                return Integer.compare(d1, d2);
            }
        });
        for (String agent : world.team.keySet()) {
            Agent self = world.team.get(agent);
            if (filter.matches(self)) {
                roleQueue.add(self);
            }
        }
        return roleQueue;
    }
    
    // walkaround until every Strategy has implemented goals.
    public Goal getGoal() {
    	return new Goal(this.decide());
    }
    
    public DecisionStrategy getFallback() {
		return fallback;
	}
    
    public void setFallback(DecisionStrategy fallback) {
		this.fallback = fallback;
	}
    
    protected final PathFilter FILTER_FIND_REPAIRER = new PathFilter() {
        @Override
        public boolean matches(Path path) {
            if(path != null) {
                for(Agent s : world.team.values()) {
                    // we don't wont to find us!
                    if(s.id == world.self.id) {
                         continue;
                    }
                    if(s.role == AgentRole.REPAIRER && s.position == path.getTarget()) {
                        return true;
                    }
                }
            }
            return false;
        }

        @Override
        public boolean accepts(Path path) {
            if(path != null) {
                if(path.getStepCount() <= 50 && path.getLastStepCost() <= world.self.maxEnergy) {
                    return true;
                }
            }
            return false;
        }
    };
    
    protected final PathFilter FILTER_FIND_ENEMY = new PathFilter() {
        @Override
        public boolean matches(Path path) {
            if(path != null) {
                for(Entity e: world.enemyAgents.values()) {
                    if(e.team.equals(TeamType.ENEMY) && e.position.id == path.getTarget()) {
                        return true;
                    }
                }
            }
            return false;
        }

        @Override
        public boolean accepts(Path path) {
            if(path != null) {
                if(path.getStepCount() <= 50 && path.getLastStepCost() <= world.self.maxEnergy) {
                    return true;
                }
            }
            return false;
        }
    };
    
    protected final PathFilter FILTER_ENEMY_NEAR = new PathFilter() {
        @Override
        public boolean matches(Path path) {
            if(path != null) {
                for(Entity e : world.enemyAgents.values()) {
                    if((e.energy > 0 || e.energy == -1) && path.getTarget() == e.position.id
                            && (e.role == null || e.role == AgentRole.SABOTEUR)) {
                        return true;
                    }
                }
            }
            return false;
        }

        @Override
        public boolean accepts(Path path) {
            if(path != null) {
                if(path.getStepCount() <= 1) {
                    return true;
                }
            }
            return false;
        }
    };
    
    // filters for paths with not disabled enemies at target and a step count of max 3 
    protected final PathFilter FILTER_ENEMY_NEAR_3 = new PathFilter() {
        @Override
        public boolean matches(Path path) {
            if(path != null) {
                for(Entity e : world.enemyAgents.values()) {
                    if(e.team.equals(TeamType.ENEMY) && (e.health > 0 || e.health == -1) && path.getTarget() == e.position.id)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        @Override
        public boolean accepts(Path path) {
            if(path != null) {
                if(path.getStepCount() <= 3) {
                    return true;
                }
            }
            return false;
        }
    };
    
    protected final PathFilter STRATEGY_FIND_UNPROBED = new PathFilter() {
        @Override
        public boolean matches(Path path) {
            if(path != null) {
                if(path.getTargetVertex() != null) {
                    if(path.getTargetVertex().getValue() == -1) {
                    	return true;
                    }
                }
            }
            return false;
        }

        @Override
        public boolean accepts(Path path) {
            if(path != null) {
                if(path.getStepCount() <= 50) {
                    return true;
                }
            }
            return false;
        }
    };
    
    protected final PathFilter FILTER_NEED_SURVEY = new PathFilter() {
        @Override
        public boolean matches(Path path) {
            if(path != null) {
                if(path.getStepCount() == 1) {
                    return true;
                }
            }
            return false;

        }

        @Override
        public boolean accepts(Path path) {
            if(path != null) {
                if(path.getStepCount() <= 1) {
                    return true;
                }
            }
            return false;
        }
    };
    
    protected final PathFilter FILTER_NEXT_SENTINEL = new PathFilter() {
        @Override
        public boolean matches(Path path) {
            if(path != null) {
                if(path.getTargetVertex() != null) {
                    if(path.getTargetVertex().team.equals(TeamType.OWN)) {
                        for(Agent s : world.team.values()) {
                            if(s.username != world.username && path.getTarget() == s.position && s.role == AgentRole.SENTINEL) {
                                return true;
                            }
                        }
                        return false;
                    }
                }
            }
            return false;
        }

        @Override
        public boolean accepts(Path path) {
            if(path != null) {
                if(path.getStepCount() <= 50 && path.getLastStepCost() <= world.self.maxEnergy) {
                    return true;
                }
            }
            return false;
        }
    };
    
    protected final PathFilter FILTER_FIND_CYCLE = new PathFilter() {

        @Override
        public boolean matches(Path path) {
            // TODO set length dynamic
            if(path.getStepCount() == 7) {
                for(Vertex v : world.graph.getNeighborsOf(path.getTargetVertex())) {
                    if(v.equals(path.getStartVertex())) {
                        return true;
                    }
                }
            }
            return false;
        }

        @Override
        public boolean accepts(Path path) {
            // TODO Sentinel: more dynamic
            return path.getStepCount() <= 7;
        }

    };
}
