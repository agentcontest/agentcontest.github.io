package de.tub.mac13.teamb.util.io;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Map;
import java.util.Stack;
import java.util.Vector;

import javax.imageio.ImageIO;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;

import de.tub.mac13.teamb.Constants;
import de.tub.mac13.teamb.ontology.Entity;
import de.tub.mac13.teamb.ontology.Intention;
import de.tub.mac13.teamb.ontology.Agent;
import de.tub.mac13.teamb.ontology.Statistic;
import de.tub.mac13.teamb.ontology.graph.Edge;
import de.tub.mac13.teamb.ontology.graph.Graph;
import de.tub.mac13.teamb.ontology.graph.Vertex;
import de.tub.mac13.teamb.util.visual.GraphEdge;
import de.tub.mac13.teamb.util.visual.GraphLayouter;
import de.tub.mac13.teamb.util.visual.GraphNode;
import de.tub.mac13.teamb.util.visual.GraphLayouter.Point;

public class StatisticsIO {
	
	private static class ExportableLayout implements Serializable{

		private static final long serialVersionUID = -2288270881188337452L;
		@SuppressWarnings("unused")
		final Vector<GraphNode> nodes;
	    final Vector<GraphEdge> edges;
	    final GraphNode[] nodeLookup;
	    final Map<Integer, Point> positions;
	    
		public ExportableLayout(Vector<GraphNode> nodes,
				Vector<GraphEdge> edges, GraphNode[] nodeLookup,Map<Integer, Point> positions ) {
			this.nodes = nodes;
			this.edges = edges;
			this.nodeLookup = nodeLookup;
			this.positions = positions;
		}
		public ExportableLayout(GraphLayouter gl) {
			this(gl.nodes, gl.edges, gl.nodeLookup,gl.positions);
		}
	    
	}
	
    
    final static String glexp_fname = "default.graph";
    
    @SuppressWarnings("unused")
	private static void saveGraphLayout(GraphLayouter gl){
    	
    	ExportableLayout glexp = new ExportableLayout(gl);
    	try {
            
            FileOutputStream fos = new FileOutputStream(new File(glexp_fname));
            ObjectOutputStream out = new ObjectOutputStream(fos);      
            out.writeObject(glexp);
            out.flush();
            out.close();
            fos.close();
        }
        catch(IOException e) {
            e.printStackTrace();
        }
    }
    
    private static ExportableLayout loadGraphLayout(){
    	ExportableLayout glexp = null;
    	try {
            FileInputStream fis = new FileInputStream(new File(glexp_fname));
            ObjectInputStream in = new ObjectInputStream(fis);      
            glexp = (ExportableLayout) in.readObject();
            in.close();
            fis.close();
        }
        catch(IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    	return glexp;
    }
    
	public static void save(File logFile, Statistic statistic) throws IOException {
		save(logFile, statistic, loadGraphLayout());
	}
	
	public static void save(File f,Statistic stat,GraphLayouter gl) throws IOException{
		ExportableLayout egl = new ExportableLayout(gl);
		save(f,stat,egl);
	}
	
	public static void save(File f,Statistic stat,ExportableLayout gl) throws IOException{
		Statistic stats = new Statistic(stat);
		
		if(stat == null){return;}
		
		Element root = new Element("statistcs");
		Document doc = new Document(root);
		root.setAttribute("vertex", Integer.toString(stats.getGraph().getVertexCount()));
		root.setAttribute("steps",Integer.toString(stats.step));
		root.setAttribute("score",Integer.toString(stats.score));
		Element achievements = new Element("achievements");
		for(String s:stats.achievements){
			Element achievement = new Element("achievement");
			achievement.addContent(s);
			achievements.addContent(achievement);
		}
		root.addContent(achievements);
			
		Element team = new Element("team");
		for(Agent self:stats.team.values()){
			Element agent = new Element("agent");
			agent.setAttribute("name",self.username);
			agent.setAttribute("role",self.role.toString());
			agent.setAttribute("lastStrategy",String.format("%s",self.strategy));
			agent.setAttribute("lastPosition",Integer.toString(self.position));
			agent.setAttribute("energy",Integer.toString(self.energy));
			agent.setAttribute("maxEnergy",Integer.toString(self.maxEnergy));
			agent.setAttribute("health",Integer.toString(self.health));
			agent.setAttribute("maxHealth",Integer.toString(self.maxHealth));
			agent.setAttribute("visRange",Integer.toString(self.visRange));
			agent.setAttribute("strength",Integer.toString(self.strength));
			Statistic.AgentStatistic as = stats.teamStats.get(self.username);
			if(as != null){
				Element agentStats = new Element("stats");
				agentStats.setAttribute("timeSpendDead",Integer.toString(as.timeSpendDead));
				agentStats.setAttribute("timesHealed",Integer.toString(as.timesHealed));
				agentStats.setAttribute("failedActions",Integer.toString(as.faildActions));
				agent.addContent(agentStats);
			}
			
			Element actions = new Element("actions");
			Intention in = null;
			Stack<Intention> actionStack = copy(stats.teamActions.get(self.username));
			Element action;
			while(!actionStack.isEmpty()){
				in = actionStack.pop();
				if(in == null){
					continue;
				}
				if(in.action == null){
					continue;
				}
				action = new Element("action");
				action.setAttribute("name",in.action);
				action.setAttribute("param",String.format("%s",in.param));
				
				action.setAttribute("result",(in.result != null)?in.result.name():"null");
				actions.addContent(action);
			}
			
			if(gl != null){
				File agentFile = getAgentFile(f,self.username);
				makeImage(agentFile, gl, copy(stats.teamActions.get(self.username)));
				Element img = new Element("img");
				img.setAttribute("href",agentFile.getPath());
				agent.addContent(img);
			}
			
			
			agent.addContent(actions);
			team.addContent(agent);
		} 	
		
		root.addContent(team);
		if(gl != null) {
			persisGraph(stats.getGraph(),gl,f);
		}
			
		persistEnemyInformation(stats,f);
		XMLOutputter xmlOutput = new XMLOutputter();
		// display nice nice
		xmlOutput.setFormat(Format.getPrettyFormat());
		System.out.println("saveing xml log:"+f.getName());
		xmlOutput.output(doc, new FileWriter(f));
	}

	private static void persistEnemyInformation(Statistic stats, File f) throws IOException {
		Element root = new Element("enemys");
		Entity e;Stack<Statistic.Move> ea;
		for(String key:stats.enemyAgents.keySet()){
			Element enemy = new Element("enemy");
			e = stats.enemyAgents.get(key);
			if(e == null){
				continue;
			} 
			enemy.setAttribute("name",key);
			enemy.setAttribute("lastUpdate",Integer.toString(e.lastUpdate));
			enemy.setAttribute("maxHealth",Integer.toString(e.maxHealth));
			enemy.setAttribute("maxEnergy",Integer.toString(e.maxEnergy));
			enemy.setAttribute("lastPosition",Integer.toString(e.position.id));
			
			
			enemy.setAttribute("role",String.format("%s",e.role));
			enemy.setAttribute("visRange",Integer.toString(e.visRange));
			ea = stats.enemyMovement.get(key);
			if(ea != null){
				Element movement = new Element("movement");
				while (!ea.isEmpty()) {
					Statistic.Move m = ea.pop();
					Element node = new Element("node");
					node.setAttribute("name",Integer.toString(m.node));
					node.setAttribute("step",Integer.toString(m.step));
					movement.addContent(node);
				}
				enemy.addContent(movement);
			}
			root.addContent(enemy);
		}
		
		Document doc = new Document(root);
		XMLOutputter xmlOutput = new XMLOutputter();
		// display nice nice
		xmlOutput.setFormat(Format.getPrettyFormat());
		File out_file = new File(f.getParent()+File.separator+"enemy.xml");
		System.out.println("saveing xml log:"+out_file.getName());
		xmlOutput.output(doc, new FileWriter(out_file));
	}

	private static void persisGraph( Graph g, ExportableLayout gl, File f) throws IOException {
		Element graph = new Element("graph");
		Element verts = new Element("vertices");
		verts.setAttribute("nodes", Integer.toString(g.getVertexCount()));
		for(Vertex v:g.getVertices()){
			Element vert = new Element("v");
			vert.setAttribute("name",Integer.toString(v.id));
			vert.setAttribute("team",v.team.toString());
			vert.setAttribute("value",Integer.toString(v.value));
			if(gl != null){
				vert.setAttribute("x",Integer.toString(gl.nodeLookup[v.id].x));
				vert.setAttribute("y",Integer.toString(gl.nodeLookup[v.id].y));
			}
			
			verts.addContent(vert);
		}
		Element edges = new Element("edges");
		graph.addContent(verts);
		for(Edge e:g.getEdges()){
			Element edge = new Element("edge");
			edge.setAttribute("v1",Integer.toString(e.node1));
			edge.setAttribute("v2",Integer.toString(e.node2));
			edge.setAttribute("wight",Integer.toString(e.weight));
			edges.addContent(edge);
		}
		graph.addContent(edges);
		Document doc = new Document(graph);
		XMLOutputter xmlOutput = new XMLOutputter();
		// display nice nice
		xmlOutput.setFormat(Format.getPrettyFormat());
		File out_file = new File(f.getParent()+File.separator+"graph.xml");
		System.out.println("saveing xml log:"+out_file.getName());
		xmlOutput.output(doc, new FileWriter(out_file));
	}

	private static File getAgentFile(File f,String user){
		StringBuilder sb = new StringBuilder();
		sb.append(f.getParentFile().getAbsolutePath()).append(File.separator);
		sb.append(f.getName().substring(0, f.getName().indexOf(".")));
		sb.append('.').append(user).append('.').append("png");
		return new File(sb.toString());
	}
	
	static int W = 20;
	
	private static void clear(Graphics g){
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, 800, 820);
	}
	
	private static void drawGraph(Graphics g,ExportableLayout gl){
		for(Integer i:gl.positions.keySet()){
			Point p = gl.positions.get(i);
			drawNode(g, p);
		}
		synchronized (gl.edges) {
            for (GraphEdge e : gl.edges) {
                Point p1 = gl.positions.get(e.node1.id);
                Point p2 = gl.positions.get(e.node2.id);

               
                if (p1 != null && p2 != null) {
                    g.drawLine((int) (p1.x * W), (int) (p1.y * W),
                            (int) (p2.x * W), (int) (p2.y * W));
                }
            }
        }
	}
	
	public static void makeImage(File f,ExportableLayout gl,Stack<Intention> s) throws IOException{
		if(gl == null || s == null){
			return;
		}
		Stack<Intention> actions = copy(s);
		Intention action;
		BufferedImage img = new BufferedImage(800, 820, BufferedImage.TYPE_INT_RGB);
		Graphics g = img.getGraphics();
		//clear
		clear(g);
		//draw grayout version of compleat graph
		g.setColor(Color.LIGHT_GRAY);
		drawGraph(g,gl);
		g.setColor(Color.BLACK);
		//draw movement
		Point last = null;
		while(!actions.isEmpty()){
			action = actions.pop();
			if(action.action.equalsIgnoreCase(Constants.ACTION_GOTO)){
				g.setColor(Color.BLACK);
				Point p = gl.positions.get(getVertexId(action.param));
				drawNode(g, p);
				if(!action.success){
					switch (action.result) {
					case LOWENERGY:
						g.setColor(Color.BLUE);
						break;
					case RANDOM:
						g.setColor(Color.BLACK);
						break;
					case  WRONG_PARAM:
						g.setColor(Color.RED);
						break;
					case KIA:
						g.setColor(Color.CYAN);
						break;
					case DISABLED:
						g.setColor(Color.MAGENTA);
						break;
					default:
						g.setColor(Color.ORANGE);
					}
					drawEdge(g,last,p);
				} else {
					
					drawEdge(g,last,p);
					last = p;
				}
				
				
			} else if(action.action.equalsIgnoreCase(Constants.ACTION_PROBE)){
				g.setColor(Color.GREEN);
				
				drawNode(g, last);
				
			} else if(action.action.equalsIgnoreCase(Constants.ACTION_SURVEY)){
				g.setColor(Color.YELLOW);
				
				drawNode(g, last);
				
			} else if(action.action.equalsIgnoreCase(Constants.ACTION_RECHARGE)){
				g.setColor(Color.BLUE.brighter());
				
				drawNode(g, last);
				
			} else if(action.action.equalsIgnoreCase(Constants.ACTION_REPAIR)){
				g.setColor(Color.RED);
				
				drawNode(g, last);
				
			} else if(action.action.equalsIgnoreCase(Constants.ACTION_ATTACK)){
				g.setColor(Color.ORANGE);
				
				drawNode(g, last);
			} else if(action.action.equalsIgnoreCase(Constants.ACTION_PARRY)){
				g.setColor(Color.PINK);
				drawNode(g, last);
			} else if(action.action.equalsIgnoreCase(Constants.ACTION_INSPECT)){
				g.setColor(Color.CYAN);
				drawNode(g, last);
			}
			
		}
		drawLegend(g);
		g.dispose();
		ImageIO.write(img, "PNG", f);
	}
	
	private static void drawLegend(Graphics g) {
		g.setColor(Color.BLACK);
		g.drawRect(5, 800, 790, 18);
		drawVetexLabel(g,Color.black,"visited",10,810);
		drawVetexLabel(g,Color.GREEN,"probed",60,810);
		drawVetexLabel(g,Color.YELLOW,"survaied",120,810);
		drawVetexLabel(g,Color.BLUE,"recharge",190,810);
		drawVetexLabel(g,Color.RED,"repair",260,810);
		drawVetexLabel(g,Color.ORANGE,"attack",330,810);
		drawVetexLabel(g,Color.PINK,"parry",390,810);
		drawVetexLabel(g,Color.CYAN,"inspect",440,810);
		g.drawLine(500, 800, 500, 818);
		drawEdgeLabel(g,Color.BLUE,"noEnegy",505,810);
		drawEdgeLabel(g,Color.RED,"wrongP",565,810);
		drawEdgeLabel(g,Color.ORANGE,"other",625,810);
		drawEdgeLabel(g,Color.CYAN,"kia",690,810);
		drawEdgeLabel(g,Color.MAGENTA,"dead",735,810);
	}
	
	private static void drawEdgeLabel(Graphics g,Color c,String text,int x,int y){
		g.setColor(c);
		g.drawLine(x, y, x+12, y);
		g.setColor(Color.black);
		g.drawString(text, x+12, y);
	}

	private static void drawVetexLabel(Graphics g,Color c,String text,int x,int y){
		g.setColor(c);
		g.fillOval(x, y, 6, 6);
		g.setColor(Color.black);
		g.drawString(text, x+12, y);
	}

	private static void drawEdge(Graphics g,Point p1, Point p2) {
		if(p1 == null || p2 == null)
			return;
		g.drawLine((int) (p1.x * 20), (int) (p1.y * 20),
                (int) (p2.x * 20), (int) (p2.y * 20));
		
	}



	private static int getVertexId(String name) {
        try {
            return Integer.parseInt(name.substring(2));
        } catch (NumberFormatException e) {
            return -1;
        }
    }
	
	private static void drawNode(Graphics g,Point p){
		if(p == null){
			return;
		}
		g.fillOval((int) (p.x * W - 3), (int) (p.y * W - 3), 2 * 3, 2 * 3);
	}
	
	
	private static Stack<Intention> copy(Stack<Intention> actions){
        Stack<Intention> copy = new Stack<>();
        for (Intention it : actions) {
            copy.push(it);
        }
        return copy;
	}


}
