package de.tub.mac13.teamb.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;

public class Order implements IFact {
    private static final long serialVersionUID = -322908771358027918L;
    
    private int[] positions;

    private int step = 0;

    public Order(int[] positions) {
        this.positions = positions;
    }
    
    public Order(Order other) {
        this.positions = new int[other.positions.length];
        for(int i = 0; i < positions.length; i++) {
            this.positions[i] = other.positions[i];
        }
    }

    public int[] getPositions() {
        return positions;
    }

    public void setPositions(int[] positions) {
        this.positions = positions;
    }

    public void setStep(int step){
        this.step =step;
    }

    public int getStep(){
        return step;
    }
}
