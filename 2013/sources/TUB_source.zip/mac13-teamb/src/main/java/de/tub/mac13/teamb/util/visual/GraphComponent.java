package de.tub.mac13.teamb.util.visual;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.util.ConcurrentModificationException;
import java.util.Map;

import javax.swing.JPanel;

import de.tub.mac13.teamb.ontology.Agent;
import de.tub.mac13.teamb.ontology.Entity;
import de.tub.mac13.teamb.ontology.Statistic;
import de.tub.mac13.teamb.ontology.enums.AgentRole;
import de.tub.mac13.teamb.ontology.enums.TeamType;
import de.tub.mac13.teamb.util.visual.GraphLayouter.Point;

/**
 * Component for displaying the Layout. The graph (or the known nodes of the
 * graph) is drawn an a canvas. This canvas also allows limited interaction with
 * the layouting process: right mouse button: manually drag a node to another
 * place; left mouse button: add another node to the graph (if initialized with
 * just a few nodes); middle mouse button: calculate distances and color nodes
 * accordingly.
 *
 * @author kuester
 */
class GraphComponent extends JPanel implements ActionListener {

    private static final long serialVersionUID = 6581504051024195801L;
    
    int W = 20;
    boolean keepUpdateing = true;
    boolean showDecorations = true;
    /**
     * the layouter whose layout to display
     */
    GraphLayouter layouter;
    /**
     * last set of calculated distances from each node to all other nodes
     */
    Map<Integer, Double> distances = null;
    int highlight = -1;

	private Statistic s;

    /**
     * Create GraphComponent instance.
     *
     * @param graphLayouter the layouter whose layout to display
     */
    public GraphComponent(GraphLayouter graphLayouter) {
        this.layouter = graphLayouter;
        this.layouter.addActionListener(this);
        this.setPreferredSize(new Dimension(800, 800));
        this.addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent e) {
                if (layouter.selected != null) {
                    layouter.positions.put(layouter.selected,
                            new Point(e.getX() / (float) W, e.getY()
                            / (float) W));
                }
            }

            @Override
            public void mouseMoved(MouseEvent e) {
                updateUI();
            }
        });
        this.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                layouter.selected = null;
                if (e.getButton() == MouseEvent.BUTTON1) {
                    double best = Double.MAX_VALUE;
                    for (Integer s : layouter.positions.keySet()) {
                        Point p = layouter.positions.get(s);
                        double dx = e.getX() - p.x * W;
                        double dy = e.getY() - p.y * W;
                        double d = Math.sqrt(dx * dx + dy * dy);
                        if (d < best) {
                            best = d;
                            layouter.selected = s;
                        }
                    }
                }
                if(e.getButton() == MouseEvent.BUTTON3){
                    layouter.gravity = new GraphLayouter.Point(e.getX() / (float) W,e.getY() / (float) W);
                }
            }

            public void mouseReleased(MouseEvent e) {
                layouter.selected = null;
                if (e.getButton() == 2) {
                    distances = layouter.getRemoteliness();
                }
                if(e.getButton() == MouseEvent.BUTTON3){
                    layouter.gravitate();
                }
            }
        });
    }

    public GraphComponent(GraphLayouter layout, Statistic s) {
		this(layout);
		this.s = s;
	}

	private Color getTeamColor(TeamType team) {
        switch (team) {
            case ENEMY:// A
                return new Color(255,150,150);
            case OWN:// B
                return  new Color(150,150,255);
            case NONE:
                return Color.WHITE;
            default:
                return Color.BLACK;
        }
    }
	
	private void getEdgeColor(int n1, int n2, Graphics g) {
        TeamType nt1 = layouter.nodeLookup[n1].getDominatorTeam();
        TeamType nt2 = layouter.nodeLookup[n2].getDominatorTeam();
        if (nt1 != null && nt2 != null) {
            if (nt1 == nt2 && nt1 != TeamType.NONE) {
                g.setColor(getTeamColor(nt1));
                return;
            }
        }
        g.setColor(Color.BLACK);


    }


    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        // draw edges

        g.setColor(Color.BLACK);
        synchronized (layouter.edges) {
            for (GraphEdge e : layouter.edges) {
                Point p1 = layouter.positions.get(e.node1.id);
                Point p2 = layouter.positions.get(e.node2.id);

                getEdgeColor(e.node1.id, e.node2.id, g);

                if (p1 != null && p2 != null) {
                    g.drawLine((int) (p1.x * W), (int) (p1.y * W),
                            (int) (p2.x * W), (int) (p2.y * W));
                }
            }
        }
        // draw nodes
        g.setColor(Color.BLACK);
        int s = 4;

        for (Integer node : layouter.positions.keySet()) {
            drawNode(g,node,null,null,Color.GREEN,4);
        }
        if(this.s == null)
        	return;
        if(this.s.team == null)
        	return;
        try{

                for(Entity e:this.s.enemyAgents.values()){
                    if(e.position != null){
                        drawNode(g,e.position.id ,Color.RED,null,Color.GREEN,4);
                    }
                }
            	for(Agent agent:this.s.team.values()){
                    switch(agent.role){
                        case INSPECTOR:
                            drawNode(g,agent.position ,Color.BLUE,"I",Color.GREEN,4);;
                            break;
                        case EXPLORER:
                            drawNode(g,agent.position ,Color.BLUE,"E",Color.GREEN,4);
                            break;
                        case REPAIRER:
                            drawNode(g,agent.position ,Color.BLUE,"R",Color.GREEN,4);
                            break;
                        case SABOTEUR:
                            drawNode(g,agent.position ,Color.BLUE,"S",Color.GREEN,4);
                            break;
                        case SENTINEL:
                            drawNode(g,agent.position ,Color.BLUE,"Z",Color.GREEN,4);
                            break;
                        default:
                            drawNode(g,agent.position ,Color.BLUE,"?",Color.GREEN,4);

                    }

                }



        } catch (ConcurrentModificationException e){
        	
        }

    }



    private void drawAgent(Graphics g,int nodeID,Polygon role,Color fill){
        Point      p = layouter.positions.get(nodeID);

        if(p == null){
            return;
        }
        Polygon agent = new Polygon(role.xpoints,role.ypoints,role.npoints);
        agent.translate((int)Math.round(p.x*W),(int)Math.round(p.x*W));

        g.setColor(fill);
        g.fillPolygon(agent);
    }

    private void drawNode(Graphics g,int nodeID,Color fill,String text,Color edge,int s){
        Point p = layouter.positions.get(nodeID);
        GraphNode gn = layouter.nodeLookup[nodeID];

        if(fill != null){
            g.setColor(fill);
        } else {
            if (gn != null && gn.getDominatorTeam() != null) {
                g.setColor(getTeamColor(gn.getDominatorTeam()));
            } else {
                g.setColor(Color.WHITE);
            }
        }

        if(p == null){
            return;
        }

        g.fillOval((int) (p.x * W - 2 * s), (int) (p.y * W - 2 * s), 4 * s, 4 * s);
        if(text != null && !text.isEmpty()){
            g.setColor(invert(g.getColor()));
            g.drawString(text, (int) (p.x * W -  s), (int) (p.y * W + s));
            g.setColor(edge);
        } else if(gn.weight >= 0){
            g.setColor(invert(g.getColor()));
            g.drawString(Integer.toString(gn.weight), (int) (p.x * W -  s), (int) (p.y * W + s));
            g.setColor(edge);
        } else {
            g.setColor(Color.BLACK);

        }
        g.drawOval((int) (p.x * W - 2 * s), (int) (p.y * W - 2 * s), 4 * s, 4 * s);
    }

    private Color invert(Color c){
        return new Color(Math.abs(254-c.getRed()),Math.abs(254-c.getGreen()),Math.abs(254-c.getBlue()));
    }

    @Override
    public void actionPerformed(ActionEvent arg0) {
        if (arg0.getID() == 1) {
            updateUI();
        } else if (keepUpdateing) {
            updateUI();
        }
    }

    public synchronized void lock() {
        keepUpdateing = false;
    }

    public synchronized void unlock() {
        keepUpdateing = true;
        updateUI();
    }
    
}
