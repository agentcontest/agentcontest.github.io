package de.tub.mac13.teamb.strategy;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import de.tub.mac13.teamb.Constants;
import de.tub.mac13.teamb.bean.DefaultDecisionBean;
import de.tub.mac13.teamb.ontology.Intention;
import de.tub.mac13.teamb.ontology.World;
import de.tub.mac13.teamb.ontology.graph.Edge;
import de.tub.mac13.teamb.ontology.graph.Graph;
import de.tub.mac13.teamb.ontology.graph.Vertex;

public class RandomStrategy extends DecisionStrategy {

    protected World world;

    public RandomStrategy(DefaultDecisionBean decider, String username) {
        super(decider, username);
        world = decider.getWorld();
    }

    protected Intention gotoRandomNeighbor() {
        Graph g = decider.getWorld().graph;
        
        int cp = world.self.position;//current position
        
        //itterate over the Verts and check if it is possible to use the node
        ArrayList<Vertex> verts = g.getNeighborsListOf(g.getVertex(cp));
        Edge e;
        Iterator<Vertex> it = verts.iterator();
        Vertex v;
        while(it.hasNext()){
        	v = it.next();
        	e = g.getEdge(cp, v.id);
        	if(e != null && e.weight > world.self.energy){
        		it.remove();
        	}
        }
        if(!verts.isEmpty()){
        	return goToVertex(verts.get(new Random().nextInt(verts.size())));
        } else {
        	return survey();
        }
    }

    @Override
    public Intention decide() {
        Intention intention;
        if (world.self.energy < world.self.maxEnergy * 0.2) {
            intention = recharge();
            world.lastAction = Constants.ACTION_RECHARGE;
        } else {
            Graph g = world.graph;
            boolean survey = false;
            ArrayList<Edge> edges = g.getEdgesOfVertex(g.getVertex(world.self.position));
            for (Edge e : edges) {
                if (e.weight == Integer.MAX_VALUE) {
                    survey = true;
                    break;
                }
            }
            if (survey) {
                intention = new Intention(Constants.ACTION_SURVEY, null);
                world.lastAction = Constants.ACTION_SURVEY;
            } else {
                intention = gotoRandomNeighbor();
            }
        }


        return intention;
    }

    @Override
    public List<Intention> decisionPlan() {
        return null;
    }

    @Override
    public String toString() {
        return "RandomStrategy";
    }
}
