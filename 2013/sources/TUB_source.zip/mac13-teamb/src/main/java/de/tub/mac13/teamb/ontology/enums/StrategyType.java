package de.tub.mac13.teamb.ontology.enums;

import java.io.Serializable;

public enum StrategyType implements Serializable {
    
    DEFAULT("DecisionStrategy"),    SENTINEL("SentinelStrategy"), EXPLORER("ExplorerStrategy"),
    INSPECTOR("InspectorStrategy"), REPAIRER("RepairerStrategy"), SABOTEUR("SaboteurStrategy"),
    RANDOM("RandomStrategy"),       ZONE("ZoneStrategy"), ZONE_D("ZoneDefenderStrategy");
    private String value;

    private StrategyType(String value) {
        this.value = value;
    }
    
    @Override
    public String toString(){
        return value;
    }
    
    public static StrategyType get(String value) {
        for(StrategyType a: StrategyType.values()) {
            if(a.value.equals(value))
                return a;
        }
        return null;
    }
}
