package de.tub.mac13.teamb.strategy;

//import java.util.Random;

import de.tub.mac13.teamb.bean.DefaultDecisionBean;
import de.tub.mac13.teamb.ontology.Entity;
import de.tub.mac13.teamb.ontology.Goal;
import de.tub.mac13.teamb.ontology.Intention;
//import de.tub.mac13.teamb.ontology.enums.Action;
import de.tub.mac13.teamb.ontology.enums.StrategyType;
import de.tub.mac13.teamb.ontology.enums.TeamType;
import de.tub.mac13.teamb.ontology.graph.Path;
import de.tub.mac13.teamb.util.EnvironmentInformation;

public class ZoneDefenderStrategy extends RandomStrategy {
	
	//private final int PERIMETER_RADIUS = 4;
	//private Random r = new Random();
    private RandomStrategy fallback;
    private ZoneStrategy zoning;
    private EnvironmentInformation environment;

	public ZoneDefenderStrategy(DefaultDecisionBean decider, String username) {
		super(decider, username);
		getLog().info(world.self.role + ": got assigned ZoneDefenderStrategy");
		System.err.println("Starting Zone Defender!!!"+username);
		this.fallback = new SaboteurStrategy(decider, username);
		this.zoning = new ZoneStrategy(decider, username);
        this.environment = new EnvironmentInformation(world);
	}
	
	public Goal getGoal() {
		getLog().info(world.self.strategy + ": starting getGoal()");
		
		Intention zoningIntention = zoning.decide();
		Goal result = new Goal();
		
		if (world.self.energy < 2) {
			getLog().info(world.self.strategy + ": low energy => recharge");
        	result.addFirstIntention(recharge());
            return result;
        }
		
		// disabled => move to nearest repairer
        if (world.self.health == 0) {
        	getLog().info(world.self.strategy + ": trying to find repairer.");
        	Path p = environment.getPathToNext(FILTER_FIND_REPAIRER);
        	
        	if(p != null) {
        		getLog().info(world.self.role + ": found repairer at " + p);
        		// repairer at own position
        		if(p.getTarget() == world.self.position) {
        			return new Goal(recharge());
        		} else {
        			// there is enough energy for the first step
        			if (p.getFirstStepCost() < world.self.energy) {
        				result = new Goal();
        				getLog().info(world.self.role + ": goto repairer. path: " + p);
            			result.addFirstIntention(goToVertex(p.getFirstStep()));
            			return result;
        			} else { //not enough energy for first step
        				result.addFirstIntention(recharge());
                        return result;
        			}
        		}
        	}
        }
		
        // low energy and low health covered => gotos from zoning.decide() should be about zones, not repairers
        
		// action plan:
		// 1. move into position to defend
		// 2. wait until enemy penetrates perimeter
		// 3. attack enemy until enemy is disabled or left the perimeter
		
		// compute own rank in zoning environment
		//int zonerCount = 1;
        int rank = 0;
        for(Entity e : world.getOwnAgents()) {
            if(e.strategy == StrategyType.ZONE || e.strategy == StrategyType.ZONE_D) {
                if(e.id > world.self.id) {
                    rank++;
                }
                //zonerCount++;
            }
        }
        
        int[] positions = null;
        int zonePosition;
        if(world.zoneOrder != null) {
        	positions = world.zoneOrder.getPositions();
        }
        if(positions != null && rank < positions.length) {
        	// this is the position the agent is supposed to be in when a zoneOrder exists
        	zonePosition = positions[rank];
        	
        	// check the perimeter for enemies
        	Path perimeterCheck = null;
        	perimeterCheck = environment.getPathToNext(zonePosition, FILTER_ENEMY_NEAR_3);
        	Entity enemy = new Entity();
        	
        	for(Entity e : world.enemyAgents.values()) {
                if(e.team.equals(TeamType.ENEMY) && (e.health > 0 || e.health == -1) )
                {
                	enemy = e;
                	break;
                }
			}
        	
        	// enemy found in perimeter
        	if(perimeterCheck != null && enemy != null && world.step == enemy.lastUpdate) {
        		getLog().info(world.self.role + ": found enemy in defending perimeter.");
        		Path pathToEnemy = environment.getPathToPosition(perimeterCheck.getTarget());
        		if(pathToEnemy != null) {
        		// enemy is further than 0 steps away
	        		if(pathToEnemy.getStepCount() > 0) {
	        			// enough energy for first step
	        			if(pathToEnemy.getFirstStepCost() < world.self.energy) {
	        				getLog().info(world.self.role + ": goto enemy. path: " + pathToEnemy);
	        				result.addFirstIntention(goToVertex(pathToEnemy.getFirstStep()));
	        				return result;
	        			} else {
	        				result.addFirstIntention(recharge());
	        				return result;
	        			}
	        		} else {
	        			//enemy is in acceptable range => attack;
	        			for(Entity e : world.enemyAgents.values()) {
	                        if(e.team.equals(TeamType.ENEMY) && (e.health > 0 || e.health == -1) && pathToEnemy.getTarget() == e.position.id)
	                        {
	                        	getLog().info(world.self.strategy + ": attacking " + e.name + ", step: " + world.step + ", lastUpdate: " + e.lastUpdate);
	                        	result.addFirstIntention(attack(e.name));
	                        	return(result);
	                        }
	        			}
	        		}
        		}
        	} else {
        		// no enemy found in perimeter => do what zoning would do
        		getLog().info(world.self.strategy + ": following ZoningStrategy.");
        		zoningIntention = zoning.decide();
        		result.addFirstIntention(zoningIntention);
        		return result;
        	}
        }
		
        getLog().info(world.self.strategy + " using fallback.");
		return fallback.getGoal();
	}
	
    @Override
    public String toString() {
        return "ZoneDefenderStrategy";
    }

}
