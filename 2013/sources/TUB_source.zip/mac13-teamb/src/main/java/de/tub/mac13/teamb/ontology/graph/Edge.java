package de.tub.mac13.teamb.ontology.graph;

import java.io.Serializable;

public class Edge implements Serializable, Comparable<Edge> {

    private static final long serialVersionUID = 1861482564557175724L;
    public int node1;
    public int node2;
    public int weight = Integer.MAX_VALUE;

    public Edge(int node1, int node2) {
        this.node1 = node1;
        this.node2 = node2;
    }

    public Edge(int node1, int node2, int weight) {
        this.node1 = node1;
        this.node2 = node2;
        this.weight = weight;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public int getNode1() {
        return node1;
    }

    public int getNode2() {
        return node2;
    }

    @Override
    public int hashCode() {
        return ((node1 + node2) * (node1 + node2 + 1)) / 2 + node2;
    }

    public boolean connects(Vertex v) {
        return node1 == v.getId() || node2 == v.getId();
    }

    public void merge(Edge e) {
        //otherwise this edge has  already a weight
        if (this.weight == Integer.MAX_VALUE) {
            this.weight = e.weight;
        }
    }

    private boolean equals(Edge other) {
        return other.node1 == this.node1 && other.node2 == this.node2
                || other.node2 == this.node1 && other.node1 == this.node2;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Edge) {
            return equals((Edge) obj);
        }
        return false;
    }

    @Override
    public int compareTo(Edge other) {
        return weight - other.weight;
    }
}
