package de.tub.mac13.teamb.strategy;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import de.tub.mac13.teamb.bean.DefaultDecisionBean;
import de.tub.mac13.teamb.ontology.Entity;
import de.tub.mac13.teamb.ontology.Intention;
//import de.tub.mac13.teamb.ontology.Agent;
import de.tub.mac13.teamb.ontology.enums.AgentRole;
//import de.tub.mac13.teamb.ontology.enums.TeamType;
import de.tub.mac13.teamb.ontology.graph.Edge;
import de.tub.mac13.teamb.ontology.graph.Path;
import de.tub.mac13.teamb.ontology.graph.Vertex;
import de.tub.mac13.teamb.util.BehaviourFilter;
import de.tub.mac13.teamb.util.EnvironmentInformation;
//import de.tub.mac13.teamb.util.PathFilter;

public class SentinelStrategy extends RandomStrategy {

    private EnvironmentInformation env;
    private ZoneStrategy zoneStrat;
    
    public SentinelStrategy(DefaultDecisionBean d, String username) {
        super(d, username);
        zoneStrat = new ZoneStrategy(d, username);
        this.env = new EnvironmentInformation(world, Path.BY_COST);
        getLog().add(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                // System.out.println(arg0.getActionCommand());
            }
        });
    }

    @Override
    public Intention decide() {
        decider.switchStrategy(zoneStrat);
        if(world.self.energy == 0) {
            return recharge();
        }
        if(world.self.health == 0) {
            Path p = env.getPathToNext(FILTER_FIND_REPAIRER);

            if(p != null) {
                return goToVertex(p.getFirstStep());
            }

        } else {
            // If not surveyed then survey
            Queue<Path> surveyedNeighbors = env.getPathsToNext(FILTER_NEED_SURVEY);

            if(surveyedNeighbors.size() != world.graph.getEdgesOfVertex(world.self.position).size()) {
                return survey();
            }

            // Check for enemies
            Path enemyPath = env.getPathToNext(FILTER_ENEMY_NEAR);
            if(enemyPath != null) {
                // TODO Sentinel: react better to enemies
                if(enemyPath.getStepCount() == 0) {
                    if(!(world.teamActions.get(world.username) != null && !world.teamActions.get(world.username).peek().success)) {
                        // return super.decide();
                        return parry();
                    }
                }
            }
            LinkedList<Entity> sentinels = world.getOwnAgents();

            int position = -1;
            int idh = world.self.id;
            int rank = 0;
            for(Entity a : sentinels) {
                if(a.role == AgentRole.SENTINEL) {
                    if(a.id > world.self.id) {
                        rank++;
                    }
                    if(idh < a.id) {
                        idh = a.id;
                        position = a.position.id;
                    }
                }
            }
            if(position != -1) {
                //              Path circlePath = env.getPathToNext(v, FILTER_OWN, new Comparator<Path>() {
                //              
                //              @Override
                //              public int compare(Path p1, Path p2) {
                //                  return p2.getStepCount() - p1.getStepCount();
                //              }
                //          });
                // FIXME Sentinel : endless loop...
                Path pa = env.getPathToNext(position, FILTER_FIND_CYCLE, new BehaviourFilter() {

                    @Override
                    public boolean behavesAdd(Path path, int vertexID) {
                        return !path.contains(vertexID);
                    }
                });

                if(pa != null) {
                    final int target = pa.getStep(2 * rank);
                    if(target != world.self.position) {
                        Path p = env.getPathToPosition(target);

                        if(p != null) {
                            return goToVertex(p.getFirstStep());
                        }
                    } else {
                        if(world.self.energy != world.self.maxEnergy) {
                            return recharge();
                        } else {
                            return skip();
                        }
                    }
                }
            } else {
                Vertex high = null;
                for(Vertex v : world.graph.getVertices()) {
                    if(high == null || v.value > high.value) {
                        high = v;
                    }
                }

                if(high.id != world.self.position) {
                    Path p = env.getPathToPosition(high);
                    if(p != null) {
                        return goToVertex(p.getFirstStep());
                    } else
                        return super.decide();

                }
                if(world.self.energy != world.self.maxEnergy) {
                    return recharge();
                } else {
                    return skip();
                }
            }
            //            LinkedList<Entity> agents = world.getOwnAgents();
            //
            //            boolean follow = false;
            //            for(Entity a : agents) {
            //                if(a.role == AgentRole.SENTINEL && world.self.id < a.id) {
            //                    follow = true;
            //                    break;
            //                }
            //            }
            //            if(follow) {
            //                Queue<Path> q = env.getPathsToNext(FILTER_NEXT_SENTINEL, Path.BY_STEPCOUNT);
            //
            //                if(q != null && !q.isEmpty()) {
            //                    for(Path p : q) {
            //                        if(p.getStepCount() > 2) {
            //                            return goToVertex(p.getFirstStep());
            //                        }
            //
            //                        if(p.getStepCount() == 1) {
            ////                            LinkedList<Entity> agents2 = world.getAgentsOnVertex(p.getTarget(), TeamType.OWN);
            ////
            ////                            for(Entity a : agents2) {
            ////                                if(a.role == AgentRole.SENTINEL && world.self.id < a.id) {
            ////                                    return super.decide();
            ////                                }
            ////                            }
            //                        }
            //
            //                        if(p.getStepCount() == 0) {
            //                            return super.decide();
            //                        }
            //                    }
            //
            //                    if(world.self.energy != world.self.maxEnergy) {
            //                        return recharge();
            //                    } else {
            //                        return skip();
            //                    }
            //                }
            //            } else {
            //                Vertex high = null;
            //                for(Vertex v : world.graph.getVertices()) {
            //                    if(high == null || v.value > high.value) {
            //                        high = v;
            //                    }
            //                }
            //
            //                if(high.id != world.self.position && high.value > world.graph.getVertex(world.self.position).value) {
            //                    Path p = env.getPathToPosition(high);
            //                    if(p != null) {
            //                        return goToVertex(p.getFirstStep());
            //                    } else
            //                        return super.decide();
            //
            //                }
            //                if(world.self.energy != world.self.maxEnergy) {
            //                    return recharge();
            //                } else {
            //                    return skip();
            //                }
            //            }
        }
        return super.decide();
    }

    @Override
    protected Intention goToVertex(int v) {
        Edge edge = world.graph.getEdge(world.self.position, v);
        if(edge != null) {
            if(world.self.energy >= edge.weight)
                return super.goToVertex(v);
            return recharge();
        }
        return super.decide();
    }

    @Override
    public List<Intention> decisionPlan() {
        // TODO SentinelStrategy.decisionPlan
        return null;
    }

    @Override
    public String toString() {
        return "SentinelStrategy";
    }

    /*private final PathFilter FILTER_NEED_SURVEY = new PathFilter() {
        @Override
        public boolean matches(Path path) {
            if(path != null) {
                if(path.getStepCount() == 1) {
                    return true;
                }
            }
            return false;

        }

        @Override
        public boolean accepts(Path path) {
            if(path != null) {
                if(path.getStepCount() <= 1) {
                    return true;
                }
            }
            return false;
        }
    };*/

    /*private final PathFilter FILTER_ENEMY_NEAR = new PathFilter() {
        @Override
        public boolean matches(Path path) {
            if(path != null) {
                for(Entity e : world.enemyAgents.values()) {
                    if(e.team.equals(TeamType.ENEMY) && (e.energy > 0 || e.energy == -1) && path.getTarget() == e.position.id
                            && (e.role == null || e.role == AgentRole.SABOTEUR)) {
                        return true;
                    }
                }
            }
            return false;
        }

        @Override
        public boolean accepts(Path path) {
            if(path != null) {
                if(path.getStepCount() <= 1) {
                    return true;
                }
            }
            return false;
        }
    };*/

    //@SuppressWarnings("unused")
    /*private final PathFilter FILTER_NEXT_SENTINEL = new PathFilter() {
        @Override
        public boolean matches(Path path) {
            if(path != null) {
                if(path.getTargetVertex() != null) {
                    if(path.getTargetVertex().team.equals(TeamType.OWN)) {
                        for(Agent s : world.team.values()) {
                            if(s.username != world.username && path.getTarget() == s.position && s.role == AgentRole.SENTINEL) {
                                return true;
                            }
                        }
                        return false;
                    }
                }
            }
            return false;
        }

        @Override
        public boolean accepts(Path path) {
            if(path != null) {
                if(path.getStepCount() <= 50 && path.getLastStepCost() <= world.self.maxEnergy) {
                    return true;
                }
            }
            return false;
        }
    };*/

    /*private final PathFilter FILTER_FIND_REPAIRER = new PathFilter() {
        @Override
        public boolean matches(Path path) {
            if(path != null) {
                for(Agent s : world.team.values()) {
                    if(s.role == AgentRole.REPAIRER && s.position == path.getTarget()) {
                        return true;
                    }
                }
            }
            return false;
        }

        @Override
        public boolean accepts(Path path) {
            if(path != null) {
                if(path.getStepCount() <= 50 && path.getLastStepCost() <= world.self.maxEnergy) {
                    return true;
                }
            }
            return false;
        }
    };*/

    /*private final PathFilter FILTER_FIND_CYCLE = new PathFilter() {

        @Override
        public boolean matches(Path path) {
            // TODO set length dynamic
            if(path.getStepCount() == 7) {
                for(Vertex v : world.graph.getNeighborsOf(path.getTargetVertex())) {
                    if(v.equals(path.getStartVertex())) {
                        return true;
                    }
                }
            }
            return false;
        }

        @Override
        public boolean accepts(Path path) {
            // TODO Sentinel: more dynamic
            return path.getStepCount() <= 7;
        }

    };*/
}
