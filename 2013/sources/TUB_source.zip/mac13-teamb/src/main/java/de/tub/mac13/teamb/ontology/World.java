package de.tub.mac13.teamb.ontology;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import java.util.Stack;
import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac13.teamb.BTeamStarter;
import de.tub.mac13.teamb.Constants;
import de.tub.mac13.teamb.ontology.enums.ActionResult;
import de.tub.mac13.teamb.ontology.enums.AgentRole;
import de.tub.mac13.teamb.ontology.enums.TeamType;
import de.tub.mac13.teamb.ontology.graph.Edge;
import de.tub.mac13.teamb.ontology.graph.Graph;
import de.tub.mac13.teamb.ontology.graph.Vertex;
import de.tub.mac13.teamb.ontology.graph.Zone;
import de.tub.mac13.teamb.util.GraphAnalytics;
import de.tub.mac13.teamb.util.Logger;
import java.util.Collection;
import java.util.concurrent.ConcurrentHashMap;

public class World implements IFact, Cloneable {

    private static final long serialVersionUID = -2750428164254110909L;
    public String username;
    public int id;
    public Logger log;

    public World(String username) {
        this.username = username;
        try{
            this.id = Integer.parseInt(username.substring(Constants.TEAM_NAME.length()));
        } catch (NumberFormatException nf){}

        self = new Agent();
        log = new Logger(username);

        if(BTeamStarter.logIDs != null){

            if(BTeamStarter.logIDs.contains(id)){
                System.out.println("Log Started for:"+username);
                log.add(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent arg0) {
                        System.out.println(arg0.getActionCommand());
                    }
                });
            }
        }
    }

    public World(){

    }

    public static World makeWorld(World world){
        World w =  new World();
        w.username = "TUB66";
        w.log = new Logger("TUB66");
        w.id = 66;

        w.vertexCount = world.vertexCount;
        w.edgeCount = world.edgeCount;
        w.maxSteps = world.maxSteps;

        return w;

    }
    //MetaData
    public int edgeCount;
    public int vertexCount;
    public int maxSteps;
    
    public Agent self;
    
    public Graph graph;
    
    public long deadline;
    
    
    public ConcurrentHashMap<String, Agent> 			team 		= new ConcurrentHashMap<>();
    public ConcurrentHashMap<String, Stack<Intention>>  teamActions = new ConcurrentHashMap<>();
    public ConcurrentHashMap<String, Goal> teamGoals = new ConcurrentHashMap<>();  
    public ConcurrentHashMap<String, Entity> enemyAgents = new ConcurrentHashMap<>();
    
    public String lastAction;
    
    public int step = -1;
    
    private LinkedList<Zone> ownZones = new LinkedList<>();
    private LinkedList<Zone> enemyZones = new LinkedList<>();
    
    //FIX/REMOVE
    public LinkedList<Integer> planedZone = new LinkedList<>();    
    public Order zoneOrder = null;
    
    
    public synchronized void update(Perception perception) {
        this.id = perception.id;
        if (graph == null) {
            graph = new Graph(vertexCount);
       }
        
        //integrate Agent views
        if (perception.username.matches(username)) {
            updateSelf(perception);
        } else {
        	updateAgent(perception);
        }
        
        updateLastAction(perception);
        updateGraph(perception);
        
        //clear enemy list per turn TODO  can we do better? like traking the enemy or predicting?
        if (step < perception.id) {
        	teamGoals.clear();
            step = perception.id;
        }
        
        updateEnemy(perception);
    }
    
    public synchronized void update(Order order) {

        this.zoneOrder = new Order(order);
        this.zoneOrder.setStep(order.getStep());
    }

    public synchronized void update(Intention it) {
        Stack<Intention> its;
        if (teamActions.containsKey(it.username)) {
            its = teamActions.get(it.username);
        } else {
            its = new Stack<>();
            teamActions.put(it.username, its);
        }
        its.push(it);

    }
    
    
    public synchronized void update(Goal goal) {
    	teamGoals.put(goal.getUsername(), goal);
    }
    
	private void updateEnemy(Perception perception) {
		for (Entity e : perception.entities) {
			if(e.team == TeamType.ENEMY) {
				if (e.name.startsWith(Constants.TEAM_NAME)) return;
				e.lastUpdate = perception.id;
				if(enemyAgents.containsKey(e.name)){
					Entity ee = enemyAgents.get(e.name);
					ee.merge(e);
					enemyAgents.put(e.name, ee);
				} else {
					enemyAgents.put(e.name, e);
				}
			}
        }
	}

	public boolean isFullyProbed = false;
	private void updateGraph(Perception perception) {
		if(!isFullyProbed){
			isFullyProbed = GraphAnalytics.isFullyProbed(graph);
		}
		
		//integrate Graph
        for (Vertex v : perception.vertices) {
            graph.addVertex(v);
        }
        if(!isFullyProbed){
	        for (Edge e : perception.edges) {
	            graph.addEdge(e);
	        }
        } //trying to get rid of HugeZoneing Bug!
	}

	private void updateLastAction(Perception perception) {
        if(teamActions.get(perception.username) != null){
        	Intention it = teamActions.get(perception.username).peek();
        	 if(perception.lastActionResult != ActionResult.SUCCESS){
             	it.success = false;
                if(perception.username.matches(username))
             	    log.error("Last Action"+it+" Failed:"+perception.lastActionResult);
             }
             it.result = perception.lastActionResult;
        }
	}

	private void updateAgent(Perception perception) {
		Agent self = new Agent();
		self.position = perception.position;
		self.energy = perception.energy;
		self.health = perception.health;
		self.maxEnergy = perception.maxEnergy;
		self.maxEnergyDisabled = perception.maxEnergyDisabled;
		self.maxHealth = perception.maxHealth;
		self.strength = perception.strength;
		self.visRange = perception.visRange;
		self.username = perception.username;
		self.role = perception.role;
		self.strategy = perception.strategy;
		self.id = Integer.parseInt(perception.username.substring(Constants.TEAM_NAME.length()));
		team.put(perception.username, self);
	}

	private void updateSelf(Perception perception) {
		self.position = perception.position;

		self.energy = perception.energy;
		self.health = perception.health;
		self.maxEnergy = perception.maxEnergy;
		self.maxEnergyDisabled = perception.maxEnergyDisabled;
		self.maxHealth = perception.maxHealth;
		self.strength = perception.strength;
		self.visRange = perception.visRange;
		self.role = perception.role;
		self.strategy = perception.strategy;
        self.id = Integer.parseInt(username.substring(Constants.TEAM_NAME.length()));

		deadline 	= perception.deadline;
		
		this.lastAction = perception.lastAction;
	}

    public LinkedList<Zone> getOwnZones() {
        return ownZones;
    }

    public LinkedList<Entity> getEnemyAgents() {
        final LinkedList<Entity> enemy = new LinkedList<>();
        enemy.addAll(enemyAgents.values());
        return enemy;
    }
    
    private Entity makeEntity(Agent agent){
    	Entity e = new Entity();
    	e.energy = agent.energy;
    	e.health = agent.health;
    	e.name = agent.username;
    	e.position = graph.getVertex(agent.position);
    	e.team = TeamType.OWN;
    	e.visRange = agent.visRange;
    	e.id = agent.id;
    	e.role = agent.role;
    	e.strategy = agent.strategy;
    	//TODO fix missing
    	return e;
    }

    public LinkedList<Entity> getOwnAgents() {
        final LinkedList<Entity> own = new LinkedList<>();
        Entity e;
        for(Agent agent:team.values()){
        	e = makeEntity(agent);
        	own.add(e);
        }
        return own;
    }

    public LinkedList<Zone> getEnemyZones() {
        return enemyZones;
    }

    public LinkedList<Entity> getEnemyAgentsOnVertex(final Vertex vertex) {
        final  LinkedList<Entity> agents = new LinkedList<>();
        for (Entity agent : enemyAgents.values()){
            if (agent.position.id == vertex.id){
                agents.add(agent);
            }
        }
        return agents;
    }

    public LinkedList<Entity> getTeamAgentsOnVertex(final Vertex vertex) {
        final  LinkedList<Entity> agents = new LinkedList<>();
        for (Agent agent : team.values()){
            if (agent.position == vertex.id){
                agents.add(makeEntity(agent));
            }
        }
        return agents;
    }

    public LinkedList<Entity> getAllAgents() {
        final Collection<Entity> own = getOwnAgents();
        final Collection<Entity> enemy = enemyAgents.values();
        final LinkedList<Entity> all = new LinkedList<>();
        all.addAll(own);
        all.addAll(enemy);
        
        return all;
    }

    public LinkedList<Entity> getAgentsOnVertex(Vertex node, TeamType agentTeam) {
        return getAgentsOnVertex(node.id, agentTeam);
    }
    
    public LinkedList<Entity> getAgentsOnVertex(int id, TeamType agentTeam) {
        final LinkedList<Entity> agentsOnVertex = new LinkedList<>();
        for (Entity agent : getAllAgents()) {
            if (agent.team == agentTeam) {
                if (agent.position.id == id) {
                    agentsOnVertex.add(agent);
                }
            }
        }

        return agentsOnVertex;
    }
    
}
