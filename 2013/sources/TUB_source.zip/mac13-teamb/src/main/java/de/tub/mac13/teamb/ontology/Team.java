package de.tub.mac13.teamb.ontology;

import java.io.Serializable;
import java.util.LinkedList;

public class Team implements Serializable {

    private static final long serialVersionUID = 5280348598790415115L;
    public int lastStepScore;
    public int money;
    public int score;
    public int zoneScore;
    public LinkedList<String> achievements = new LinkedList<>();
}