package de.tub.mac13.teamb.util;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Serializable;

import javax.swing.event.EventListenerList;

import de.tub.mac13.teamb.Constants;

public class Logger implements Serializable {

    private static final long serialVersionUID = -6498181103273128684L;
    Log log;
    String name;
    EventListenerList listeners = new EventListenerList();

    public Logger(String name) {
    	int num  = 0;
    	try{
            String sub = name.substring(Constants.TEAM_NAME.length());
            num = Integer.parseInt(sub);
    	} catch (Exception ex){
    		
    	}
        this.name = String.format("b%02d", num);
    	log = new Log(25);
    }

    public void add(ActionListener ac) {
        listeners.add(ActionListener.class, ac);
    }

    public void remove(ActionListener ac) {
        listeners.remove(ActionListener.class, ac);
    }

    private void notify(ActionEvent e) {
        for (ActionListener ac : listeners.getListeners(ActionListener.class)) {
            ac.actionPerformed(e);
        }
    }

    public void info(String msg) {
        notify(new ActionEvent(this, 0, log.add(" [INFO][%s] - %s", name, msg)));
    }

    public void error(String msg) {
        notify(new ActionEvent(this, 0, log.add("[ERROR][%s] - %s", name, msg)));
    }

    public void error(String msg, Exception e) {
        StringBuilder sb = new StringBuilder();
        sb.append(e.toString());
        sb.append('\n');
        for (StackTraceElement t : e.getStackTrace()) {
            sb.append('\t');
            sb.append(t.toString());
            sb.append('\n');
        }
        notify(new ActionEvent(this, 0, log.add("[ERROR][%s] - %s\n%s", name, msg, sb.toString())));
    }

    /**
     * RingBuffer for Strings
     */
    private static class Log implements Serializable {

        private static final long serialVersionUID = 1468724887592502869L;
        private String[] messages;
        private int index;

        public Log(int capacity) {
            messages = new String[capacity];
            index = 0;
        }

        private void moveIndex() {
            index = (index + 1) % messages.length;
        }

        @SuppressWarnings("unused")
        public String add(String s) {
            return add("[%d]:%s", (System.currentTimeMillis() / 1000), s);
        }

        public String add(String s, Object... args) {
            String res = String.format(s, args);
            messages[index] = res;
            moveIndex();
            return res;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            for (int i = index + 1; i < messages.length; i++) {
                if(messages[i] == null){
                	continue;
                }
            	sb.append(messages[i]).append('\n');
            }
            for (int i = 0; i < index; i++) {
            	if(messages[i] == null){
                	continue;
                }
                sb.append(messages[i]).append('\n');
            }
            return sb.toString();
        }
    }
    
    @Override
    public String toString() {
    	return log.toString();
    }
}
