package de.tub.mac13.teamb.util.visual;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Stack;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.text.Document;

import de.tub.mac13.teamb.Constants;
import de.tub.mac13.teamb.ontology.Intention;
import de.tub.mac13.teamb.ontology.Agent;
import de.tub.mac13.teamb.ontology.Statistic;
import de.tub.mac13.teamb.ontology.graph.Graph;

public class DebugUI extends JFrame implements Runnable {

    private static final String AGENT = "AGENT";
    private static final String TEAM = "TEAM";
    private static final long serialVersionUID = 6294844555266824433L;
    // Logic
    public GraphLayouter layout;
    boolean swarmming = false;
    boolean pause = false;
    Thread animation;
    // Visual Components
    final JPanel main = new JPanel();
    final JTextArea logger = new JTextArea();
    GraphComponent view;
    final JPanel sidePanel = new JPanel();
    final JPanel infoPanel = new JPanel();
    final JPanel agentInfo = new JPanel();
    final JPanel teamInfo = new JPanel();
    final JPanel cntlPanel = new JPanel();
    final JTextArea achivmentList = new JTextArea();
    final JLabel i1 = new JLabel("Infos:");
    final JLabel i2 = new JLabel("Score:");
    final JLabel i3 = new JLabel("Dead Agents:");
    final JLabel i4 = new JLabel("Health:");
    final JLabel i5 = new JLabel("Energy");
    final JLabel i6 = new JLabel("Name:");
    final JLabel i7 = new JLabel("Role:");
    final JLabel i8 = new JLabel("Strategy:");
    final JLabel i9 = new JLabel("ActionStack:");
    // Active Components
    JLabel step = new JLabel();
    JLabel score = new JLabel();
    JLabel dead = new JLabel();
    JLabel name = new JLabel();
    JLabel role = new JLabel();
    JLabel strategy = new JLabel();
    JProgressBar health = new JProgressBar();
    JProgressBar energy = new JProgressBar();
    JTextArea actions = new JTextArea();
    JScrollPane agentsWrapper = new JScrollPane();
    JComboBox<String> agents = new JComboBox<>();
    Statistic s;

    public DebugUI(Statistic s) {
        setSize(1000, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setAlwaysOnTop(true);
        this.s = s;
        init(s.getGraph());

        setVisible(true);

        animation = new Thread(this);
        animation.start();
    }

    private void init(Graph g) {
        setLayout(new BorderLayout());

        add(main, BorderLayout.CENTER);
        main.setLayout(new CardLayout());

        initGraph(g);
        initSidePanel();

        add(cntlPanel, BorderLayout.NORTH);
        cntlPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        final JButton pauseBtn = new JButton("Pause");
        pauseBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                if (!pause) {
                    pauseBtn.setText("Play");
                    view.lock();
                    layout.lock();
                    pause = true;
                } else {
                    pauseBtn.setText("Pause");
                    view.unlock();
                    layout.unlock();
                    pause = false;
                }
            }
        });
        //cntlPanel.add(pauseBtn);
        final JButton btn = new JButton("Swarmming?");
        btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                swarmming = !swarmming;
                if (swarmming) {
                    btn.setText("Stop Swarmming?");
                } else {
                    btn.setText("Swarmming?");
                }
            }
        });
        cntlPanel.add(btn);
        final JButton simEnd = new JButton("simEnd");
        simEnd.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				Date now = new Date();
				SimpleDateFormat date_format = new SimpleDateFormat("d-m-HH");
				File f = new File("log"+File.separator+"sim"+date_format.format(now)+".log");
				System.out.println(f);
				s.save(f);
			}
		});
        //cntlPanel.add(simEnd);

    }

    private void initGraph(Graph g) {
        layout = new GraphLayouter(g);
        layout.initializeRandomPositions();
        view = new GraphComponent(layout,s);
        main.add(view, "GRAPH");
    }

    private void initSidePanel() {
        add(sidePanel, BorderLayout.EAST);
        sidePanel.setLayout(new BorderLayout());
        sidePanel.add(agents, BorderLayout.NORTH);
        initAgents();

        sidePanel.add(infoPanel, BorderLayout.CENTER);
        initInfoPanel();

        sidePanel.add(achivmentList, BorderLayout.SOUTH);
        achivmentList.setPreferredSize(new Dimension(100, 400));
    }

    private void initAgents() {
        agents.addItem("All");
        for (int i = 1; i <= 20; i++) {
            agents.addItem(String.format(Constants.TEAM_NAME+"%d", i));
        }
        agents.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                CardLayout cl = (CardLayout) infoPanel.getLayout();
                if (agents.getSelectedIndex() == 0) {
                    cl.show(infoPanel, TEAM);
                    
                } else {
                    cl.show(infoPanel, AGENT);
                }
                updateSidePanel();
            }
        });
    }
    private int lastSelection = -1;

    private void updateSidePanel() {
        if (agents.getSelectedIndex() != 0) {
        
            Agent self = s.team.get(agents.getSelectedItem());
            if (self != null) {
                name.setText(self.username);
                role.setText(self.role.toString());
                strategy.setText(String.format("%s" , self.strategy));
                health.setMaximum(self.maxHealth);
                health.setValue(self.health);
                energy.setMaximum(self.maxEnergy);
                energy.setValue(self.energy);
                if (lastSelection != agents.getSelectedIndex()) {
                    Document doc = actions.getDocument();
                    try {
                        doc.remove(0, doc.getLength());
                    } catch (Exception e) {
                    	e.printStackTrace();
                    }
                    actions.setText(makeActionList(s.teamActions
                            .get(self.username)));
                }
                actions.setText(makeActionList(s.teamActions.get(self.username)));

            }
            select();
        }
        lastSelection = agents.getSelectedIndex();
    }

    private GridBagConstraints makeGridBag(int x, int y) {
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = x;
        c.gridy = y;
        c.anchor = GridBagConstraints.WEST;
        c.insets = new Insets(2, 5, 2, 10);
        return c;
    }

    private void initInfoPanel() {
        GridBagConstraints c;

        infoPanel.setLayout(new CardLayout());
        infoPanel.add(teamInfo, TEAM);
        teamInfo.setLayout(new GridBagLayout());
        teamInfo.add(i1, makeGridBag(0, 0));
        teamInfo.add(step, makeGridBag(1, 0));
        teamInfo.add(i2, makeGridBag(0, 1));
        teamInfo.add(score, makeGridBag(1, 1));
        teamInfo.add(i3, makeGridBag(0, 2));
        teamInfo.add(dead, makeGridBag(1, 2));
        infoPanel.add(agentInfo, AGENT);
        agentInfo.setLayout(new GridLayout(2, 1));
        JPanel wrapper = new JPanel();
        wrapper.setLayout(new GridBagLayout());
        wrapper.add(i6, makeGridBag(0, 0));
        wrapper.add(name, makeGridBag(1, 0));
        wrapper.add(i7, makeGridBag(0, 1));
        wrapper.add(role, makeGridBag(1, 1));
        wrapper.add(i8, makeGridBag(0, 2));
        wrapper.add(strategy, makeGridBag(1, 2));
        wrapper.add(i4, makeGridBag(0, 3));
        c = makeGridBag(0, 4);
        c.gridwidth = 4;
        c.gridheight = 1;
        c.fill = GridBagConstraints.BOTH;
        c.anchor = GridBagConstraints.WEST;
        c.gridheight = 1;
        c.weightx = 4;
        wrapper.add(health, c);
        health.setStringPainted(true);
        wrapper.add(i5, makeGridBag(0, 5));
        c = makeGridBag(0, 6);
        c.gridwidth = 4;
        c.fill = GridBagConstraints.BOTH;
        c.gridheight = 1;
        c.weightx = 4;
        c.anchor = GridBagConstraints.WEST;
        c.gridheight = 1;
        energy.setStringPainted(true);
        wrapper.add(energy, c);
        wrapper.add(i9, makeGridBag(0, 7));
        agentInfo.add(wrapper);
        agentInfo.add(this.agentsWrapper);
        agentsWrapper.setViewportView(actions);
    }

    public void update() {
        this.step.setText(String.format("%3d", s.step));
        this.dead.setText(String.format("%2d", s.dead));
        this.score.setText(String.format("%6d", s.score));
        this.achivmentList.setText(s.achievementsList());
        updateSidePanel();
    }

    private void select() {
        if (view != null) {
            if (agents.getSelectedIndex() > 0) {
                view.highlight = s.team.get(agents.getSelectedItem()).position;
            } else {
                view.highlight = -1;
            }
        }
    }

    @Override
    public void run() {
        while (isVisible()) {
            if (!pause && isSwarmming()) {
                layout.lock();
                layout.swarm(true);
                while (isSwarmming()) {
                    if (layout != null) {
                        try {
                            layout.swarm(false);
                            Thread.sleep(1);
                            view.updateUI();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
                layout.unlock();
            } else {
                Thread.yield();
            }
        }
        free();
    }

    private void free() {
        layout.lock();
        view.lock();
        layout = null;
        view = null;
    }

    private boolean isSwarmming() {
        return swarmming;
    }

    private String makeActionList(Stack<Intention> actions) {
        if (actions == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        Stack<Intention> copy = new Stack<>();
        for (Intention it : actions) {
            copy.push(it);
        }
        while (!copy.isEmpty()) {
            Intention it = copy.pop();
            sb.append(it.action);

            if (it.param != null) {
                sb.append('(');
                sb.append(it.param);
                sb.append(')');
            }

            sb.append('\n');
        }

        return sb.toString();
    }
}
