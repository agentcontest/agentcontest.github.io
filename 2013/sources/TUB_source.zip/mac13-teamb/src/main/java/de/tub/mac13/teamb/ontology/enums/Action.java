package de.tub.mac13.teamb.ontology.enums;

import java.io.Serializable;

public enum Action implements Serializable {
	
	SKIP("skip"), GOTO("goto"), SURVEY("survey"), BUY("buy"), RECHARGE("recharge"),
	PARRY("parry"), REPAIR("repair"), ATTACK("attack"), INSPECT("inspect"), PROBE("probe");
    private String value;

    private Action(String value) {
        this.value = value;
    }

    public String toString() {
        return value;
    }
    
    public static Action get(String value) {
        for(Action a: Action.values()) {
            if(a.value.equals(value))
                return a;
        }
        return null;
    }

}
