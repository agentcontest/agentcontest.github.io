package de.tub.mac13.teamb.ontology.enums;

import java.io.Serializable;

public enum TeamType implements Serializable {

    NONE("none"), OWN("B"), ENEMY("A");
    private String value;

    private TeamType(String value) {
        this.value = value;
    }
    
    @Override
    public String toString(){
        return value;
    }
}