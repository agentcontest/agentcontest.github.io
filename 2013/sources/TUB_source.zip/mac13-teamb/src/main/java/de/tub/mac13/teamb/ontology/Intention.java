package de.tub.mac13.teamb.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac13.teamb.ontology.enums.Action;
import de.tub.mac13.teamb.ontology.enums.ActionResult;

public class Intention implements IFact {

    private static final long serialVersionUID = -5482169226353959121L;
    public String action;
    public String param;
    public String username;
    public boolean send = false;
    public boolean success = true;
    public ActionResult result = ActionResult.UNKNOWN;

    public String getAction() {
        return action.toString();
    }

    public Intention(String action, String param) {
        this.action = action;
        this.param = param;
    }

    public String toString() {
        return action + "(" + param + ")";
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getParam() {
        return param;
    }

    public void setParam(String param) {
        this.param = param;
    }
    
    /**
     * Returns the cost of an Intention.
     * Returns Integer.MAX_VALUE for underdefined Intentions.
     * @return Cost of an Intention.
     */
    public int getCost(World w) {
    	Action a = Action.get(this.action);
    	int result = Integer.MAX_VALUE;
    	if(this.action != null) {
    		switch(a) {
			case ATTACK:
				result = 2;
				break;
			case BUY:
				result = 2;
				break;
			case GOTO:
				if(this.param != null) {
					result = w.graph.getEdge(w.self.position, Integer.parseInt(this.param.substring(6))).weight;
				}
				break;
			case INSPECT:
				result = 2;
				break;
			case PARRY:
				result = 2;
				break;
			case PROBE:
				result = 1;
				break;
			case RECHARGE:
				result = 0;
				break;
			case REPAIR:
				result = 2;
				break;
			case SKIP:
				result = 0;
				break;
			case SURVEY:
				result = 1;
				break;
			default:
				break;
    		}
    	}
    	return result;
    }
}
