package de.tub.mac13.teamb.util;

import java.util.LinkedList;
import java.util.List;

import de.tub.mac13.teamb.ontology.World;
import de.tub.mac13.teamb.ontology.graph.Vertex;

public class Zone {
    
    private int value;
    private List<Vertex> vertices;
    private World world;
    
    public Zone(List<Vertex> vertices, World world) {
        this.vertices = vertices;
        this.calculateValue();
        this.world = world;
    }

    public int getSize() {
        return vertices.size();
    }

    public int getValue() {
        return value;
    }
    
    public List<Integer> getVertexIndices() {
        List<Integer> result = new LinkedList<>();
        
        for(int i = 0; i < vertices.size(); i++) {
            result.add(vertices.get(i).id);
        }
        
        return result;
    }
    
    public List<Vertex> getVertices() {
        return vertices;
    }

    public void setVertices(List<Vertex> vertices) {
        this.vertices = vertices;
        this.calculateValue();
    }
    
    private void calculateValue() {
        int value = 0;
        
        for(Vertex v : vertices) {
        	if(v.value > 0) {
        		value += v.value;
        	}
        }
        
        this.value = value;
    }
    
    public boolean contains(Vertex vertex) {
        return vertices.contains(vertex);
    }
    
    public boolean contains(int vertexID) {
        return vertices.contains(world.graph.getVertex(vertexID));
    }
    
    public boolean contains(List<Vertex> verts) {
        for(Vertex v: verts) {
            if(!verts.contains(v)) {
                return false;
            }
        }
        return true;
    }
    
    public boolean containsIDs(List<Integer> verts) {
        for(int vid: verts) {
            if(!vertices.contains(world.graph.getVertex(vid))) {
                return false;
            }
        }
        return true;
    }
}
