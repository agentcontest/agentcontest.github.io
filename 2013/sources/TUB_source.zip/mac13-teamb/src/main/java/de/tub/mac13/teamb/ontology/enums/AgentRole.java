package de.tub.mac13.teamb.ontology.enums;

import java.io.Serializable;

public enum AgentRole implements Serializable {

    EXPLORER("Explorer"), SENTINEL("Sentinel"), INSPECTOR("Inspector"),
    SABOTEUR("Saboteur"), REPAIRER("Repairer"),ERRORROLE("FUCK!!"),ZONEROLE("Zone");
    private String value;

    private AgentRole(String value) {
        this.value = value;
    }

    public String toString() {
        return value;
    }
    
    public static AgentRole get(String value) {
        for(AgentRole a: AgentRole.values()) {
            if(a.value.equals(value))
                return a;
        }
        return ERRORROLE;
    }
}
