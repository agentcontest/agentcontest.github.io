package de.tub.mac13.teamb.ontology;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.*;

import javax.swing.SwingUtilities;
import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac13.teamb.BTeamStarter;
import de.tub.mac13.teamb.Constants;
import de.tub.mac13.teamb.ontology.enums.ActionResult;
import de.tub.mac13.teamb.ontology.enums.TeamType;
import de.tub.mac13.teamb.ontology.graph.Edge;
import de.tub.mac13.teamb.ontology.graph.Graph;
import de.tub.mac13.teamb.ontology.graph.Vertex;
import de.tub.mac13.teamb.util.GraphAnalytics;
import de.tub.mac13.teamb.util.io.StatisticsIO;
import de.tub.mac13.teamb.util.visual.DebugUI;

public class Statistic implements IFact, Cloneable {

    private static final long serialVersionUID = 3178849081229184812L;
    
    private final Graph graph;
    
    public int step = -1;
    
    // UI Informations
    public int score = 0;
    public int dead = 0;
    
    public LinkedList<String> achievements = new LinkedList<>();
    public HashMap<String, Agent> team = new HashMap<>();
    public HashMap<String, AgentStatistic> teamStats = new HashMap<>();
    public HashMap<String, Stack<Intention>> teamActions = new HashMap<>();
    
    public HashMap<String, Entity> enemyAgents = new HashMap<>();
    public HashMap<String, Stack<Move>> enemyMovement = new HashMap<>();
    
    public static class Move implements Serializable{

		private static final long serialVersionUID = 7214663802264250748L;
		
		public final int node;
    	public final int step;
    	public String name;
    	
    	public Move(int nodeId, int step) {
    		this.node = nodeId;
			this.step = step;
		}
    	
		public Move(String name,int nodeId,int step) {
			this(nodeId,step);
			this.name = name;		
		}
		@Override
		public int hashCode() {
			return ((node*311+step*751+name.length()*79)*101);
		}
    }
    
    public static class AgentStatistic implements Serializable{
    	
		private static final long serialVersionUID = -696350964676343737L;
		
		public int timeSpendDead = 0;
    	public int timesHealed = 0;
    	public int faildActions = 0;
    	
		@Override
		public int hashCode() {
			return ((timeSpendDead*311+timesHealed*751+faildActions*79)*101);
		}
    }
    
    DebugUI win;
    
    
    public Statistic(World w) {
        graph = new Graph(w.vertexCount);
        if(BTeamStarter.SHOWSTATISTICS){
            final Statistic that = this;
	        SwingUtilities.invokeLater(new Runnable() {
	            @Override
	            public void run() {
	                win = new DebugUI(that);
	            }
	        });
        }
    }


    public Statistic(Statistic stat) {
		graph = stat.graph;
		step = stat.step;
		score = stat.score;
		teamActions = stat.teamActions;
		team = stat.team;
		achievements = stat.achievements;
		enemyAgents = stat.enemyAgents;
		enemyMovement = stat.enemyMovement;
	
		
	}
    public synchronized void update(Perception perception) {
        if (step < perception.id) {
            if(Constants.SHOW_INFOS){
                StringBuilder sb = new StringBuilder();
                sb.append(String.format("[GAME INFO] Step:%d Dead:%d Points:%d",step,dead,score));
                if(!achievements.isEmpty())
                    sb.append(String.format(" achievements:%d\t last achievement:%s ",achievements.size(),achievements.getLast()));
                int failed = 0;
                for(String name:team.keySet()){
                    if(teamActions.containsKey(name)){
                        Intention it = teamActions.get(name).peek();
                        if(!it.success){
                            failed++;
                        }
                    }
                }
                sb.append(String.format("\t Number of failed actions:%d",failed));
                System.out.println(sb.toString());
            }
            Agent agent;
            AgentStatistic stat;
            for(String k:team.keySet()){
                agent = team.get(k);
                stat = get(k);
                if(agent.health == 0){
                    stat.timeSpendDead +=1;
                    teamStats.put(k,stat);
                }
            }
            step = perception.id;
            if (win != null) {
                win.update();
            }
            dead = 0;
            for (String s : perception.team.achievements) {
                achievements.add(s);
            }
        }

        //integrate Agent views
        updateAgent(perception);


        score = perception.team.score + perception.team.zoneScore;

        if (perception.health == 0) {
            dead++;
        }

        updateLastAction(perception);
        updateGraph(perception);

        //clear enemy list per turn TODO  can we do better? like traking the enemy or predicting?
        if (step < perception.id) {
            step = perception.id;
        }

        updateEnemy(perception);
    }

    private void updateEnemy(Perception perception) {
        for (Entity e : perception.entities) {
            if(e.team == TeamType.ENEMY) {
                if (e.name.startsWith(Constants.TEAM_NAME)) return;
                e.lastUpdate = perception.id;
                if(enemyAgents.containsKey(e.name)){
                    Entity ee = enemyAgents.get(e.name);
                    ee.merge(e);
                    enemyAgents.put(e.name, ee);
                } else {
                    enemyAgents.put(e.name, e);
                }
            }
        }
    }

    public boolean isFullyProbed = false;
    private void updateGraph(Perception perception) {
        if(!isFullyProbed){
            isFullyProbed = GraphAnalytics.isFullyProbed(graph);
        }

        //integrate Graph
        for (Vertex v : perception.vertices) {
            graph.addVertex(v);
        }
        if(!isFullyProbed){
            for (Edge e : perception.edges) {
                graph.addEdge(e);
            }
        } //trying to get rid of HugeZoneing Bug!
    }

    private void updateLastAction(Perception perception) {
        if(teamActions.get(perception.username) != null){
            Intention it = teamActions.get(perception.username).peek();
            if(perception.lastActionResult != ActionResult.SUCCESS){
                it.success = false;
            }
            it.result = perception.lastActionResult;
        }
    }

    private void updateAgent(Perception perception) {
        Agent self = new Agent();
        self.position = perception.position;
        self.energy = perception.energy;
        self.health = perception.health;
        self.maxEnergy = perception.maxEnergy;
        self.maxEnergyDisabled = perception.maxEnergyDisabled;
        self.maxHealth = perception.maxHealth;
        self.strength = perception.strength;
        self.visRange = perception.visRange;
        self.username = perception.username;
        self.role = perception.role;
        self.strategy = perception.strategy;
        self.id = Integer.parseInt(perception.username.substring(Constants.TEAM_NAME.length()));
        team.put(perception.username, self);
    }

	/*public synchronized void update(Perception perception) {
		
        //decays information after one step cycle
        if (step < perception.id) {
        	Agent agent;
        	AgentStatistic stat;
        	for(String k:team.keySet()){
        		agent = team.get(k);
        		stat = get(k);
        		if(agent.health == 0){
        			stat.timeSpendDead +=1;
        			teamStats.put(k,stat);
        		}
        	}
            step = perception.id;
            if (win != null) {
                win.update();
            }
            dead = 0;
        }
        //BUGFIX 
        if(teamActions.get(perception.username) != null){
        	Intention it = teamActions.get(perception.username).peek();
        	 if(perception.lastActionResult != ActionResult.SUCCESS){
             	it.success = false;
             	AgentStatistic as= get(perception.username);
            	as.faildActions++;
            	teamStats.put(perception.username,as);
             }
             it.result = perception.lastActionResult;
        }
        
        for (String s : perception.team.achievements) {
            achievements.add(s);
        }
        score = perception.team.score + perception.team.zoneScore;

        if (perception.health == 0) {
            dead++;
        }

        if (graph != null) {
            for (Vertex v : perception.vertices) {
                graph.addVertex(v);
            }

            for (Edge e : perception.edges) {
                graph.addEdge(e);
            }
        }
        
        int lastHealth = (team.containsKey(perception.username))?team.get(perception.username).health:perception.health;
        Agent self = new Agent();
        self.position = perception.position;
        self.energy = perception.energy;
        self.health = perception.health;
        self.maxEnergy = perception.maxEnergy;
        self.maxEnergyDisabled = perception.maxEnergyDisabled;
        self.maxHealth = perception.maxHealth;
        self.strength = perception.strength;
        self.visRange = perception.visRange;
        self.username = perception.username;
        self.role = perception.role;
        self.strategy = perception.strategy;
        team.put(perception.username, self);
        
        if(lastHealth < self.health){
        	AgentStatistic as= get(perception.username);
        	as.timesHealed++;
        	teamStats.put(perception.username,as);
        }
        
        for (Entity e : perception.entities) {
        	
        	Stack<Move> movement = enemyMovement.get(e.name);
        	if(movement == null){
        		movement = new Stack<Move>();
        	}
        	if(!movement.isEmpty() && movement.peek().step != step){
        		movement.push(new Move(e.position.id,step));
        	} else if(movement.isEmpty()) {
        		movement.push(new Move(e.position.id,step));
        	}
        	enemyMovement.put(e.name,movement);
        	
        	
        	e.lastUpdate = perception.id;
        	if(enemyAgents.containsKey(e.name)){
        		Entity ee = enemyAgents.get(e.name);
        			   ee.merge(e);
        		enemyAgents.put(ee.name, ee);
        	} else {
        		enemyAgents.put(e.name, e);
        	}
            
        }
    }*/

	private AgentStatistic get(String username){
		if(teamStats.containsKey(username)){
			return teamStats.get(username);
		} else {
			teamStats.put(username,new AgentStatistic());
			return teamStats.get(username);
		}
	}
	
    public String achievementsList() {
        StringBuilder sb = new StringBuilder();
        for (String s : achievements) {
            sb.append(s);
            sb.append("\n");
        }
        return sb.toString();
    }

    public Graph getGraph() {
        return graph;
    }

    public void kill() {
    	if(win != null){
    		win.dispose();
    	}
        graph.free();
        team.clear();
        achievements.clear();
    }

    public synchronized void update(Intention it) {
        Stack<Intention> its;
        if (teamActions.containsKey(it.username)) {
            its = teamActions.get(it.username);
        } else {
            its = new Stack<>();
            teamActions.put(it.username, its);
        }
        its.push(it);

    }
    
    public void save(File logFile){
    	try {
    		if(BTeamStarter.SHOWSTATISTICS){
    			StatisticsIO.save(logFile, this,win.layout);
    		} else {
    			StatisticsIO.save(logFile, this);
    		}
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
}
