package de.tub.mac13.teamb.util;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;

public class UniqueQueue<E> implements Queue<E>,Serializable {

	private static final long serialVersionUID = -1205566877598611548L;
	
	private LinkedBlockingQueue<E> queue;
    private HashSet<E> set;

    public UniqueQueue(int capacity) {
        queue = new LinkedBlockingQueue<>(capacity);
        set = new HashSet<>(capacity);
    }

    @Override
    public int size() {
        return queue.size();
    }

    @Override
    public boolean isEmpty() {
        return queue.isEmpty();
    }

    @Override
    public boolean contains(Object o) {
        return queue.contains(o);
    }

    @Override
    public Iterator<E> iterator() {
        return queue.iterator();
    }

    @Override
    public Object[] toArray() {
        return queue.toArray();
    }

    @Override
    public <T> T[] toArray(T[] a) {
        return queue.toArray(a);
    }

    @Override
    public boolean remove(Object o) {
        return queue.remove(o);
    }

    @Override
    public boolean containsAll(Collection<?> c) {
        return queue.containsAll(c);
    }

    @Override
    public boolean addAll(Collection<? extends E> c) {
        return queue.addAll(c);
    }

    @Override
    public boolean removeAll(Collection<?> c) {
        return queue.removeAll(c);
    }

    @Override
    public boolean retainAll(Collection<?> c) {
        return queue.retainAll(c);
    }

    @Override
    public void clear() {
        queue.clear();
    }

    @Override
    public boolean add(E e) {
        if (!set.add(e)) {
            queue.remove(e);
        }
        return queue.add(e);
    }

    @Override
    public boolean offer(E e) {
        if (!set.add(e)) {
            queue.remove(e);
        }
        return queue.offer(e);
    }

    @Override
    public E remove() {
        E elem = queue.remove();
        set.remove(elem);
        return elem;
    }

    @Override
    public E poll() {
        E elem = queue.poll();
        set.remove(elem);
        return elem;
    }

    @Override
    public E element() {
        return queue.element();
    }

    @Override
    public E peek() {
        return queue.peek();
    }
}
