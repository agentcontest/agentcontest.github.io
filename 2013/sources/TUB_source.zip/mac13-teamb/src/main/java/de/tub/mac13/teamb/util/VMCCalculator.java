package de.tub.mac13.teamb.util;

import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Random;

import de.tub.mac13.teamb.ontology.World;
import de.tub.mac13.teamb.ontology.graph.Path;
import de.tub.mac13.teamb.ontology.graph.Vertex;

public class VMCCalculator {
    private World world;
    
    private final static Comparator<Path[]> COMPARE_SAMPLES = new Comparator<Path[]>() {
		@Override
		public int compare(Path[] o1, Path[] o2) {
			return o2[0].getZoneValue() - o1[0].getZoneValue();
		}
	};
	
    private Queue<Path[]> samples = new PriorityQueue<Path[]>(10, COMPARE_SAMPLES);
    private int length;
    private EnvironmentInformation env;
    
    private Path[] lastBestPaths;
    
    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    private Random rand = new Random();
    private Zoner zoner;
    
    public VMCCalculator(World world, int length) {
        this.world = world;
        this.zoner = new Zoner(world);
        this.length = length;
        this.env = new EnvironmentInformation(world);
    }
    
    public void sample(int n) {
        for(int i = 0; i < n; i++) {
            sample();
        }
    }
    
    public void sample() {
        Path[] paths = makeRandomPath();
        
        List<Integer> temp = new LinkedList<>();

        for(Path p: paths) {
            temp.addAll(p.getShortPath());
        }
        paths[0].setZone(zoner.buildZoneWithIDs(temp));
        
        if(paths[0].getZoneValue() > 0) {
        	// FIXME 
//        	System.out.print("a");
//            System.out.print(samples.size());
	        synchronized(samples) {
	        	this.samples.add(paths);
	        }
        }
    }
    
    public int[] getBestPath(List<Integer> enemies, int length) {
        Path[] bestPaths = null;
        
        Queue<Path[]> tmpSamples;
        synchronized(samples) {
        	tmpSamples = new PriorityQueue<>(10, COMPARE_SAMPLES);
        	tmpSamples.addAll(samples);
        }

    	System.out.print("s");
        System.out.println(samples.size());
        
    	Path[] paths;
    	while((paths = tmpSamples.poll()) != null) {
    		int tmpLength = 0;
        	for(Path p: paths) {
        		tmpLength += p.getShortPath().size();
        	}
        	if(length == tmpLength) {
        		boolean next = true;
        		
        		if(enemies != null) {
	                for(int i : enemies) {
	                    if(paths[0].getZone().getVertexIndices().contains(i)) {
	                        next = false;
	                    }
	                }
	            }
        		
        		if(next) {
        			bestPaths = paths;
        			break;
        		}
        	}
    	}
        
        int[] result = null;
        
        lastBestPaths =bestPaths;
        
        if(bestPaths != null) {
            int s = 0;
            for(Path p: bestPaths) {
                s += p.getShortPath().size();
            }
            
            result = new int[s];
            
            int offset = 0;
            
            for(Path p: bestPaths) {
                for(int i = 0; i < p.getShortPath().size(); i++) {
                    result[i + offset] = p.getShortPath().get(i);
                }
                offset += p.getShortPath().size();
            }
        }
        
        return result;
    }
    
    protected List<int[]> getLengths(int length) {
        int minLength = 4;
        List<int[]> result = new LinkedList<int[]>();
        result.add(new int[]{length});
        int count = length / minLength;
        
        for(int i = 2; i <= count; i++) {
            int diff = length - i * minLength;
            int[] temp = new int[i];
            
            for(int j = 0; j < temp.length; j++) {
                temp[j] = minLength;
            }
            temp[i-1] += diff;
            
            result.add(copyIntArray(temp));
            
            int[] minMax = getMinMax(temp);
            
            while(temp[minMax[0]] + 1 < temp[minMax[1]]) {
                temp[minMax[0]] += 1;
                temp[minMax[1]] -= 1;
                
                result.add(copyIntArray(temp));

                minMax = getMinMax(temp);
            }
        }
        return result;
    }
    
    private int[] copyIntArray(int[] orginal) {
        int[] result = new int[orginal.length];
        
        for(int i = 0; i < result.length; i++) {
            result[i] = orginal[i];
        }
        
        return result;
    }
    
    private int[] getMinMax(int[] c) {
        int[] minMax = new int[]{-1,-1};
        int[] values = new int[]{0,0};
        
        for(int i = 0; i < c.length; i++) {
            if(minMax[0] == -1 || values[0] > c[i]) {
                minMax[0] = i;
                values[0] = c[i];
            }
            if(minMax[1] == -1 || values[1] < c[i]) {
                minMax[1] = i;
                values[1] = c[i];
            }
        }
        
        return minMax;
    }
    
    private Path[] makeRandomPath() {
        List<int[]> poss = getLengths(this.length);
        
        // get path lengths
        int[] paths = null;
        if(poss.size() == 1) {
            paths = poss.get(0);
        }else {
            paths = poss.get(rand.nextInt(poss.size()-1));
        }
        
        Path[] result = new Path[paths.length];
        
        List<Integer> evade = new LinkedList<Integer>();
        
        for(int i = 0; i < paths.length; i++) {
            do {
                int startID = rand.nextInt(world.graph.getVertexCount());
                result[i] = makePath(startID, paths[i] * 2 - 1, evade);
                
            }while(result[i] == null);
            
            evade.addAll(result[i].getPath());
        }
        return result;
    }
    
    private Path makePath(int startID, final int length, final List<Integer> evade) {
        Path path = env.getPathToNext(startID, new PathFilter() {
            @Override
            public boolean matches(Path path) {
                if(path.getStepCount() == length) {                
                    return true;
                }
                return false;
            }

            @Override
            public boolean accepts(Path path) {
                Vertex target = path.getTargetVertex();
                if(path.getStepCount() > length || evade.contains(target.id))
                    return false;

                for(Vertex v : world.graph.getNeighborsOf(target)) {
                    if((path.getStep(path.getStepCount() - 1) != v.id) && path.contains(v) || evade.contains(v.id)) {
                        return false;
                    }
                }
                return true;
            }

        }, COMPARE_RANDOM);
        return path;
    }
    
    public Path[] getLastBestPaths() {
		return lastBestPaths;
	}

	private static final Comparator<Path> COMPARE_RANDOM = new Comparator<Path>() {
        Random r = new Random();
        @Override
        public int compare(Path p1, Path p2) {
            return r.nextInt(2) - 1;
        }
    };
    
    

}
