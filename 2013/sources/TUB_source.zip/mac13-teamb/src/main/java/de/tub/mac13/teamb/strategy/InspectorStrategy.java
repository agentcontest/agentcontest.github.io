package de.tub.mac13.teamb.strategy;

import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Random;

import de.tub.mac13.teamb.bean.DefaultDecisionBean;
import de.tub.mac13.teamb.ontology.Entity;
import de.tub.mac13.teamb.ontology.Intention;
import de.tub.mac13.teamb.ontology.enums.TeamType;
import de.tub.mac13.teamb.ontology.graph.Path;
import de.tub.mac13.teamb.ontology.graph.Vertex;
import de.tub.mac13.teamb.util.EnvironmentInformation;
import de.tub.mac13.teamb.util.PathFilter;

public class InspectorStrategy extends RandomStrategy {
    // TODO Implement Inspector same as Random

    Random r = new Random();

    public InspectorStrategy(DefaultDecisionBean decider, String username) {
        super(decider, username);
    }

    Path plan = null;
    int planStep = 1;
    @Override
    public Intention decide() {
    	try{
    		if(!world.teamActions.get(world.username).peek().success){
        		plan = null;
        		planStep = 1;
        	}
    	} catch (NullPointerException e){
    		plan = null;
    		planStep = 1;
    	}
    	
        if (world.self.energy <= world.self.maxEnergy * 0.2) {
            return recharge();
        } else if (world.self.health == 0) {
            return super.decide();
        } else {
            Vertex[] neighbors = world.graph.getNeighborsOf(new Vertex(world.self.position));
            if(world.enemyAgents.size() <= 0){
            	return super.decide();
            }
            PriorityQueue<Entity> enemys = new PriorityQueue<>(world.enemyAgents.size(),new Comparator<Entity>() {
            	@Override
            	public int compare(Entity o1, Entity o2) {
            		return Integer.compare(o1.informationState(world.step), o2.informationState(world.step));
            	}
            });
            boolean inspect = false;
            for (Entity e : world.getEnemyAgents()) {
                if (e == null) {
                    continue;
                }
                if (e.team != TeamType.OWN) {
                    if (e.position.id == world.self.position) {
                        inspect = true;
                    } else {
                        for (Vertex v : neighbors) {
                            if (v.id == e.position.id) {
                                inspect = true;
                            }
                        }
                    }
                    enemys.offer(e);
                }
            }
            if (inspect) {
                //FIXME!
                int choice = r.nextInt(10);
                if (choice < 7) {
                	plan = null;
                    return inspect();
                }
            } else if(plan != null) {
            	return followPath();
            } else {
            	final Entity target = enemys.poll();
            	if(target != null){
            		EnvironmentInformation ev = new EnvironmentInformation(world);
            		plan = ev.getPathToNext(new PathFilter() {
						@Override
						public boolean matches(Path elem) {
							return elem.getTarget() == target.position.id;
						}
					});
            		planStep = 1;
            		if(plan != null){
            			return followPath();
            		}
            		
            	}
            }
        }
        return super.decide();
    }

    private Intention followPath() {
    	if(planStep < plan.getStepCount()){
    		if(world.self.energy < plan.getStepCost(planStep)){
    			return recharge();
    		} else if(world.teamActions != null && world.teamActions.get(world.username).peek().success) {
    			return goToVertex(plan.getStep(planStep));
    		} else {
    			return goToVertex(plan.getStep(planStep++));
    		}
    		
    	} else {
    		plan = null;
    		return super.decide();
    	}
	}

	@Override
    public String toString() {
        return "InspectorStrategy";
    }
}
