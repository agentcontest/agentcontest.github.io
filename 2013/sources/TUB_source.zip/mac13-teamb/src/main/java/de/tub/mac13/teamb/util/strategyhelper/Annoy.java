package de.tub.mac13.teamb.util.strategyhelper;

import de.tub.mac13.teamb.ontology.Entity;
import de.tub.mac13.teamb.ontology.World;
import de.tub.mac13.teamb.ontology.enums.TeamType;
import de.tub.mac13.teamb.ontology.graph.Path;
import de.tub.mac13.teamb.ontology.graph.Vertex;
import de.tub.mac13.teamb.util.PathFilter;

import java.util.HashSet;

/**
 * Created with IntelliJ IDEA.
 * User: Sebastian Werner
 * Date: 05.09.13
 * Time: 15:21
 * To change this template use File | Settings | File Templates.
 */
public class Annoy {

    public HashSet<Vertex> findUnprotectedZoneNodes(World w,TeamType team){
        HashSet<Vertex> knowenZoneNodes = new HashSet<>();

        for(Vertex v:w.graph.getVertices()){
            if(v.getTeam() == team){
                knowenZoneNodes.add(v);
            }
        }

        for(Entity e:w.getAllAgents()){
            if(e.team != null && e.team == team){
                if(e.position != null){
                    knowenZoneNodes.remove(e.position);
                }
            }
        }

        return knowenZoneNodes;
    }

    static class UnprotectedZoneFinder extends PathFilter{
        HashSet<Integer> nodes;
        HashSet<Integer> ignore;
        public UnprotectedZoneFinder(HashSet<Vertex> nodes,HashSet<Integer> ignore){

            this.nodes = new HashSet<>();
            this.ignore = ignore;
            for(Vertex v: nodes){
                this.nodes.add(v.id);
            }
        }

        @Override
        public boolean matches(Path p) {
            if(ignore.contains(p.getTarget())){
                return nodes.contains(p.getTarget());
            }
            return false;
        }
    }

    public PathFilter getFilter(World w,TeamType team,HashSet<Integer> ignore){
        return new UnprotectedZoneFinder(findUnprotectedZoneNodes(w,team),ignore);
    }
}
