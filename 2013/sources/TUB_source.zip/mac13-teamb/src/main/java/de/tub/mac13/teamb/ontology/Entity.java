package de.tub.mac13.teamb.ontology;

import de.tub.mac13.teamb.ontology.enums.AgentRole;
import de.tub.mac13.teamb.ontology.enums.StrategyType;
import de.tub.mac13.teamb.ontology.enums.TeamType;
import java.io.Serializable;

import de.tub.mac13.teamb.ontology.graph.Vertex;
import de.tub.mac13.teamb.ontology.graph.Zone;

public class Entity implements Serializable {

    private static final long serialVersionUID = -222804034296112831L;
    public int energy = -1;
    public int health = -1;
    public int maxEnergy = -1;
    public int maxHealth = -1;
    public String name;
    public Vertex position;
    public int id;
    
    public AgentRole role = null;
    public int strength = -1;
    public TeamType team;
    public int visRange = -1;
    public String status = null;
    public Zone myZone = null;
    public int lastUpdate = 0;
    public int lastInspect = 0;
    public StrategyType strategy;

    
    private int hash = -1;
    
    @Override
    public int hashCode() {
    	if(hash == -1){
    		hash = name.hashCode();
    	}
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Entity) {
            return ((Entity) obj).name.equals(this.name);
        }
        return false;
    }

    /**
     * This method tries to assign a value to the quality of information
     * stored in this Object 
     * the returned value is positive if at least some information is up to date.
     * the returned number is less than 0 if non or almost none of the stored
     * information is up to date. 
     * @param step
     * @return
     */
    public int informationState(int step){
    	int state = 6;
    	
    	state-=(step+lastUpdate);
    	state-=(maxHealth==-1)?1:0;
    	state-=(maxEnergy==-1)?1:0;
    	state-=(role==null)?1:0;
    	state-=(strength==-1)?1:0;
    	state-=(visRange==-1)?1:0;
    	
    	return state;
    }
    
    public void merge(Entity e) {
        boolean updateInspect = false;
    	if(this.team == TeamType.NONE){
    		this.team = e.team;
    	} 
        if (e.energy != -1) {
            this.energy = e.energy;
            updateInspect = true;
        }
        if (e.health != -1) {
            this.health = e.health;
            updateInspect = true;
        }
        if (e.maxEnergy != -1) {
            this.maxEnergy = e.maxEnergy;
            updateInspect = true;
        }
        if (e.maxHealth != -1) {
            this.maxHealth = e.maxHealth;
            updateInspect = true;
        }
        this.position = e.position;
        this.role       = e.role;

        if (e.strength != -1) {
            this.strength = e.strength;
            updateInspect = true;
        }
        if (e.visRange != -1) {
            this.visRange = e.visRange;
            updateInspect = true;
        }
        if (e.status != null) {
            this.status = e.status;
        }
        if(this.lastUpdate < e.lastUpdate){
            this.lastUpdate = e.lastUpdate;
        }
        if(updateInspect){
            this.lastInspect = this.lastUpdate;
        }

        // FIXME Entity merge may not be up-to-date?
    }

    @Override
    public String toString() {
        return "Entity[name="+name+",lastUpdate="+lastUpdate+",position="+position+",id="+id+"]";
    }
}
