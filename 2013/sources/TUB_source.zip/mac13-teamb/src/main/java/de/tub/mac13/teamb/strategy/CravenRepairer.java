package de.tub.mac13.teamb.strategy;

import de.tub.mac13.teamb.bean.DefaultDecisionBean;
import de.tub.mac13.teamb.ontology.Agent;
import de.tub.mac13.teamb.ontology.Entity;
import de.tub.mac13.teamb.ontology.Goal;
import de.tub.mac13.teamb.ontology.Intention;
import de.tub.mac13.teamb.ontology.enums.AgentRole;
import de.tub.mac13.teamb.ontology.graph.Path;
import de.tub.mac13.teamb.ontology.graph.Vertex;
import de.tub.mac13.teamb.util.EnvironmentInformation;
import de.tub.mac13.teamb.util.Filter;
import de.tub.mac13.teamb.util.strategyhelper.Evade;

import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: Sebastian Werner
 * Date: 04.09.13
 * Time: 13:05
 * To change this template use File | Settings | File Templates.
 */
public class CravenRepairer extends RandomStrategy {

    final int       PARANOIA = 3;
    final int       STEPS     = 2;
    final double    DECAY   = -0.5;

    Evade evade = new Evade();
    EnvironmentInformation environmentInformation;
    HashSet<Integer> noGoList = new HashSet<>();

    public CravenRepairer(String username, DefaultDecisionBean d) {
        super(d, username);
        environmentInformation = new EnvironmentInformation(world);
    }

    private Goal executePath(Path p){
        if(p != null && p.getStepCount() > 0){
            return new Goal(goToVertex(p.getFirstStep()));
        } else {
            return null;
        }
    }

    private Goal gotRandomNeighbour(){
        Random rand = new Random();
        Goal g = new Goal();
        Vertex[] vertexes = world.graph.getNeighborsOf(world.self.position);
        Vertex id = vertexes[rand.nextInt(vertexes.length)];
        g.setTargetVertex(id.getId());
        g.addFirstIntention(goToVertex(id));
        return g;
    }

    @Override
    public Goal getGoal(){
        if(world.self.energy <= 2){
            return new Goal(recharge());
        }

        if(world.self.health == 0){
            Goal g = executePath(environmentInformation.getPathToNext(FILTER_FIND_REPAIRER));
            if(g != null){
                return g;
            } else {
                getLog().info("Did not find a Repaier! Goodbye World!");
                return new Goal(recharge());
            }
        }


        //collision avoid!
        noGoList.clear();
        for(String agent:world.teamGoals.keySet()){
            if(!agent.matches(world.username)){
                Goal g = world.teamGoals.get(agent);
                noGoList.add(g.getTargetVertex());
            }
        }

        for(Agent agent:world.team.values()){
            if(agent.role == world.self.role && world.self.id < agent.id ){
                if(agent.position == world.self.position){
                   return gotRandomNeighbour();
                }
            }
        }

        PriorityQueue<Agent> agentsToHeal = new PriorityQueue<>(28,new Comparator<Agent>() {
            @Override
            public int compare(Agent o1, Agent o2) {
                return Integer.compare(o1.health,o2.health);
            }
        });

        HashSet<Vertex> reach = evade.getAgentReach(world,world.self,STEPS);
        HashSet<Vertex> agentPos = new HashSet<>();
        //first look if we have a team member near us that could use a repair!
        for(Agent agent:world.team.values()){
            if(agent.id != world.self.id){
                if(agent.role == AgentRole.REPAIRER && agent.health > 0){
                    agentPos.add(new Vertex(agent.position));
                }
            }
        }

        for(Agent agent:world.team.values()){
            if(reach.contains(world.graph.getVertex(agent.position))){
                if(agent.health < agent.maxHealth && !agentPos.contains(agent.position)) {
                    agentsToHeal.offer(agent);
                }
            }
        }


        if(!agentsToHeal.isEmpty()){
            //there is at least one one agent that need a heal
            Agent theLuckOne = agentsToHeal.poll();
            //plan a path to that agent
            Path p = environmentInformation.getPathToPosition(theLuckOne.position);
            if(p != null && p.getStepCount() > 0){
                getLog().info("going to :"+p.getFirstStepCost()+" : I think i am going to heal"+theLuckOne.username);
                Goal goal = new Goal(goToVertex(p.getFirstStep()));
                goal.setTargetVertex(p.getFirstStep());
                return goal;
            } else {
                getLog().info("heal Agent:"+theLuckOne.username);
                Goal goal = new Goal(repair(theLuckOne.username));
                goal.setTargetVertex(world.self.position);
                return goal;
            }
        } else {
            //At this Point we do not need to heal anybody or at least we choose not to


            //calc thread level of all notes
            evade.calculateThread(world,world.self,PARANOIA,DECAY,new Filter<Entity>() {
                @Override
                public boolean matches(Entity elem) {
                    return (elem.role == null || elem.role == AgentRole.SABOTEUR || elem.role == AgentRole.ERRORROLE);
                }
            });
            //check if the thread level of my node is within acceptable means
            double threadLevel = 0;

            PriorityQueue<Vertex> escapeRoute = new PriorityQueue<>(reach.size()+2,new Comparator<Vertex>() {
                @Override
                public int compare(Vertex o1, Vertex o2) {
                    return Double.compare(o1.getHeuristic(),o2.getHeuristic());
                }
            });

            for(Vertex vertex:reach){
                threadLevel+=vertex.getHeuristic();
                if(vertex.id != world.self.id)
                    escapeRoute.add(vertex);
            }
            threadLevel/=reach.size();

            getLog().info("thread Level is:"+threadLevel);
            if(threadLevel < 0.5){
                //evade
                if(!escapeRoute.isEmpty()){
                    getLog().info("evading  to:"+escapeRoute.peek());
                    Path p = environmentInformation.getPathToPosition(escapeRoute.poll());
                    if(p != null && p.getStepCount() > 0){
                        Goal goal = new Goal(goToVertex(p.getFirstStep()));
                        goal.setTargetVertex(p.getFirstStep());
                        return goal;
                    }

                }
            }
        }

        getLog().error("Craven is Using Fallback!");
        return super.getGoal();
    }

    @Override
    public String toString() {
        return "RepairerStrategy";  //To change body of implemented methods use File | Settings | File Templates.
    }
}
