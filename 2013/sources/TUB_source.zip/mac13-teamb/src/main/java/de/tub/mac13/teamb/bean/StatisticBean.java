package de.tub.mac13.teamb.bean;

import java.io.File;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

import de.tub.mac13.teamb.ontology.*;
import org.sercho.masp.space.event.SpaceEvent;
import org.sercho.masp.space.event.SpaceObserver;
import org.sercho.masp.space.event.WriteCallEvent;
import de.dailab.jiactng.agentcore.action.AbstractMethodExposingBean;
import de.dailab.jiactng.agentcore.action.Action;
import de.dailab.jiactng.agentcore.comm.CommunicationAddressFactory;
import de.dailab.jiactng.agentcore.comm.IGroupAddress;
import de.dailab.jiactng.agentcore.comm.message.IJiacMessage;
import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac13.teamb.BTeamStarter;

public class StatisticBean extends AbstractMethodExposingBean {

	@SuppressWarnings("unused")
	private static final String username = "StatisticAgent";
	private Action registerAction;
	/**
	 * The channel where agents of one team share their knowledge.
	 */
	public IGroupAddress teamChannel;
	public long time;
	private Statistic stats;

	public String getTeamChannel() {
		return this.teamChannel.toString();
	}

	public void setTeamChannel(String teamChannel) {
		this.teamChannel = CommunicationAddressFactory
				.createGroupAddress(teamChannel);
	}

	@Override
	public void doInit() throws Exception {
        System.out.println("Statistic Beam Init!");
		super.doInit();
		SpaceObserver<IFact> messageObserver = new SpaceObserver<IFact>() {
			private static final long serialVersionUID = -2109272301459190774L;

			@Override
			public void notify(SpaceEvent<? extends IFact> event) {
				if (event instanceof WriteCallEvent) {
					@SuppressWarnings("rawtypes")
					Object eventObj = ((WriteCallEvent) event).getObject();
					if (eventObj instanceof IJiacMessage) {
						IJiacMessage message = (IJiacMessage) eventObj;
						message = memory.remove(message);
						if (message != null) {
							IFact payload = message.getPayload();
							if (payload instanceof World) {
								if (stats == null) {
									stats = new Statistic((World) payload);
                                    System.out.println("Statistic Beam Started!");
								}
							}  else if (payload instanceof Perception) {

								Perception p = (Perception) payload;
								update(p);
							} else if (payload instanceof Intention) {
								if (stats != null) {
									stats.update((Intention) payload);
								}
							} else if (payload instanceof SimEnd) {
								if (stats != null) {
									simEnd(stats);
                                    SimEnd end = (SimEnd) payload;
                                    System.out.printf("Sim End:\n%s\n",end);
                                    System.out.println("Statistic Beam Restarting!");
									stats = null;
								}
							} else if(payload instanceof Goal){
                                Goal g = (Goal) payload;
                                if(stats != null){
                                    stats.update(g.getFinalIntention());
                                }
                            } else if(payload instanceof Order){
                                //igonre
                            } else {
                                System.out.println(payload);
                            }
						}
					}
				}
			}
		};
		memory.attach(messageObserver);

	}

	protected void simEnd(Statistic stats2) {
		final Statistic stats = stats2;
        new Thread(new Runnable() {

			@Override
			public void run() {
				try {
                    if(BTeamStarter.WRITE_LOG){
                        Date now = new Date();
                        SimpleDateFormat date_format = new SimpleDateFormat("d-M-H-m");
                        String makr = date_format.format(now);
                        final File dir = new File("log"+File.separator+"sim"+makr+File.separator);
                        dir.mkdir();
                        final File f = new File(dir.getPath()+File.separator+"log."+makr+".xml");
                        stats.save(f);
                    }
				} catch (Exception e) {
					if(BTeamStarter.SHOWSTATISTICS)
						e.printStackTrace();
				} finally {
					stats.kill();
				}
			}
		}).start();
	}

	protected void update(Perception p) {
		if (stats != null) {
			stats.update(p);
		}
                
	}

	public void doStart() throws Exception {
		registerAction = memory
				.read(new Action(
						"de.dailab.jiactng.agentcore.comm.ICommunicationBean#joinGroup",
						null, new Class[] { IGroupAddress.class }, null));
		if (registerAction == null) {
			throw new RuntimeException("Could not find Communication...2");
		}

		invoke(registerAction, new Serializable[] { this.teamChannel });
	}

}
