package de.tub.mac13.teamb.ontology.graph;

import de.tub.mac13.teamb.ontology.enums.TeamType;
import java.io.Serializable;

public class Vertex implements Serializable {

    private static final long serialVersionUID = -4190787842462097375L;
    public int value = -1; // -1 if not probed yet
    public TeamType team = TeamType.NONE;
    public int id;
    private double heuristicValue = 0; // for future use
    // shows if this vertex belongs to the best potential zone
    private boolean toDominate = false;

    public Vertex(int id) {
        this.id = id;
    }

    public Vertex(int id, TeamType team) {
        this.id = id;
        this.team = team;
    }

    public Vertex(int id, int value) {
        this.id = id;
        this.value = value;
    }

    public boolean isToDominate(){
        return toDominate;
    }
    
    public void setToDominate(final boolean flag){
        toDominate = flag;
    }
    
    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public int getId() {
        return id;
    }

    public TeamType getTeam() {
        return team;
    }

    public void setTeam(TeamType team) {
        this.team = team;
    }

    private boolean equals(Vertex other) {
        return id == other.getId();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Vertex) {
            return equals((Vertex) obj);
        } else {
            return false;
        }
    }

    public void merge(Vertex other) {
        if (value < 0) {
            this.value = other.value;
        }
        //if(other.team != null)
        this.team = other.team;
    }

    @Override
    public String toString() {
        return Integer.toString(id);
    }
    
    @Override
    public int hashCode() {
    	return id;
    }

    public int getHeuristicValue() {
        return (int) Math.round(heuristicValue);
    }

    public double getHeuristic() {
        return heuristicValue;
    }

    public void setHeuristic(double heuristicValue) {
        this.heuristicValue =  heuristicValue;
    }

    public void setHeuristicValue(int heuristicValue) {
        this.heuristicValue = heuristicValue;
    }
}
