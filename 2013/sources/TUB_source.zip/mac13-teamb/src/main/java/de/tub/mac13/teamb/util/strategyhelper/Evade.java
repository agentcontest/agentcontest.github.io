package de.tub.mac13.teamb.util.strategyhelper;

import de.tub.mac13.teamb.ontology.Agent;
import de.tub.mac13.teamb.ontology.Entity;
import de.tub.mac13.teamb.ontology.World;
import de.tub.mac13.teamb.ontology.graph.Graph;
import de.tub.mac13.teamb.ontology.graph.Vertex;
import de.tub.mac13.teamb.util.Filter;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;

public class Evade {

    public static int LOWER_BOUND = -2;
    public static int UPPER_BOUND =  1;
    public static int RANGE = calcRange();

    private static int calcRange(){
        return Math.abs(Evade.LOWER_BOUND)+Math.abs(Evade.UPPER_BOUND);
    }


    private HashSet<Vertex> reachable(Graph g,Vertex start,int depth,double strength){
        Queue<Vertex> tocheck = new LinkedList<Vertex>();
        tocheck.add(start);
        if(depth <= 0){
            return new HashSet<>(tocheck);
        } else {
            int itterations = 0;

            Vertex scope;
            HashSet<Vertex> visited = new HashSet<Vertex>();
            Queue<Vertex>  frontier = new LinkedList<Vertex>();
            visited.add(tocheck.peek());

            while(!tocheck.isEmpty()){
                if(itterations >= depth){
                    break;
                }
                while(!tocheck.isEmpty()){
                    frontier.offer(tocheck.poll());
                }

                while(!frontier.isEmpty()){
                    scope = frontier.poll();
                    for(Vertex node:g.getNeighborsListOf(scope)){
                        if(!visited.contains(node)){
                            visited.add(node);
                            tocheck.offer(node);
                        }

                    }
                }
                itterations++;
                for(Vertex v:visited){
                    v.setHeuristic(v.getHeuristic()+strength);
                }
            }
            return new HashSet<>(visited);

        }

    }

	private HashSet<Vertex> reachable(Graph g,Vertex start,int depth){
		return reachable(g,start,depth,0);
	}

    public HashSet<Vertex> getEnemyReach(World w,int paranoia){
        HashSet<Vertex> enemyReach = new HashSet<Vertex>();
        for(Entity e:w.enemyAgents.values()){
            if(e.position != null)
                enemyReach.addAll(reachable(w.graph, e.position, paranoia));
        }

        return enemyReach;
    }

    public HashSet<Vertex> getAgentReach(World w,Agent agent,int steps){
        HashSet<Vertex> reach = reachable(w.graph, w.graph.getVertex(agent.position), steps);
        return reach;
    }

    //first compute the reach form this agent given his paranoia level
	//next up compute reach for every enemy 
	//build a subset of nodes form the first 2 sets
	//the sets that are left are "save" to go to
	public LinkedList<Vertex> getSafeNodes(World w,Agent agent,int paranoia,int steps){
		HashSet<Vertex> enemyReach = new HashSet<Vertex>();
		for(Entity e:w.enemyAgents.values()){
			if(e.position != null)
				enemyReach.addAll(reachable(w.graph, e.position, paranoia));
		}
		
		HashSet<Vertex> reach = reachable(w.graph, w.graph.getVertex(agent.position), steps);
		
		for(Vertex n:enemyReach){
			if(reach.contains(n)){
				reach.remove(n);
			}
		}
		
		return new LinkedList<>(reach);
	}

    public void calculateThread(World w,Agent agent,int paranoia){
         calculateThread(w,agent,paranoia,-0.5);
    }
    public void calculateThread(World w,Agent a,int paranoia,double strength){
        calculateThread(w,a,paranoia,strength,null);
    }

    public void calculateThread(World w,Agent agent,int paranoia,double strength,Filter<Entity> entityFilter){
         synchronized (w.graph){
            //reset all heuristics
            for(Vertex v:w.graph.getVertices()){
                v.setHeuristicValue(UPPER_BOUND);
            }

            HashSet<Vertex> enemyReach = new HashSet<Vertex>();
            for(Entity e:w.enemyAgents.values()){
                if(entityFilter != null &&!entityFilter.matches(e)){
                    continue;
                }

                if(e.position != null){
                    enemyReach = reachable(w.graph, e.position, paranoia,strength);

                }

            }

            double MAX = Double.MIN_VALUE;
            double MIN = Double.MAX_VALUE;

            for(Vertex v:w.graph.getVertices()){
                 if(Double.compare(MAX,v.getHeuristic()) == -1 ){
                     MAX = v.getHeuristic();
                 }
                if(Double.compare(MIN,v.getHeuristic()) == 1 ){
                    MIN = v.getHeuristic();
                }
            }



            LOWER_BOUND = (int) Math.round(MIN-0.2);
            UPPER_BOUND = (int) Math.round(MAX+0.2);
            RANGE = calcRange();
             // FIXME auskommentiert System.out.println(MIN+","+MAX+","+RANGE);
            //FIXME Normilize all values a between 0 and 1 i hope
            for(Vertex v:w.graph.getVertices()){
                v.setHeuristic((v.getHeuristic()+Math.abs(LOWER_BOUND))/RANGE);
            }
        }
    }
	
}
