package de.tub.mac13.teamb.ontology;

import java.util.LinkedList;

import de.dailab.jiactng.agentcore.knowledge.IFact;

/**
 * A class representing a short time goal.
 * Contains all intermediate steps as a LinkedList of Intentions.
 * Contains the goal's target, if one exists.
 * 
 * @author Hendrik Heller
 */
public class Goal implements IFact {
	
	private static final long serialVersionUID = 650919609897527312L;
	private LinkedList<Intention> intentions;
	private String targetAgent;
	private int targetVertex;
	private String username;
	
	
	public Goal(LinkedList<Intention> i, String t) {
		this.intentions = i;
		this.targetAgent = t;
	}
	
	public Goal(LinkedList<Intention> i) {
		this.intentions = i;
	}
	
	public Goal(Intention i) {
		LinkedList<Intention> list = new LinkedList<Intention>();
		list.add(i);
		this.intentions = list;
	}
	
	public Goal(Intention i, String t) {
		LinkedList<Intention> list = new LinkedList<Intention>();
		list.add(i);
		this.intentions = list;
	}
	
	public Goal() {
		this.intentions = new LinkedList<Intention>();
	}
	
	public Goal(String t) {
		this.targetAgent = t;
	}
	
	/**
	 * @return the intention
	 */
	public LinkedList<Intention> getIntentions() {
		return intentions;
	}
	/**
	 * @param intention the intention to set
	 */
	public void setIntentionList(LinkedList<Intention> intention) {
		this.intentions = intention;
	}
	
	public void addFirstIntention(Intention i) {
		if(this.intentions != null) {
			this.intentions.addFirst(i);
		}
	}
	
	public void addLastIntention(Intention i) {
		if(this.intentions != null) {
			this.intentions.addLast(i);
		}
	}
	/**
	 * Returns the agent's username the goal is targeted at.
	 * @return the target
	 */
	public String getTargetAgent() {
		return targetAgent;
	}
	/**
	 * @param target the target to set
	 */
	public void setTarget(String target) {
		this.targetAgent = target;
	}
	
	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * @return the targetVertex
	 */
	public int getTargetVertex() {
		return targetVertex;
	}

	/**
	 * @param targetVertex the targetVertex to set
	 */
	public void setTargetVertex(int targetVertex) {
		this.targetVertex = targetVertex;
	}

	/**
	 * Returns the final Intention of the goal.
	 * @return the final Intention or null if there are no Intentions.
	 */
	public Intention getFinalIntention() {
		Intention result = null;
		if(this.intentions != null) {
			result =  this.intentions.getLast();
		}
		return result;
	}
	
	public int getCostsByEnergy(World w) {
		int result = 0;
		
		for(Intention i : this.intentions) {
			if(i.getCost(w) == Integer.MAX_VALUE) {
				result = Integer.MAX_VALUE;
				break;
			} else {
				result += i.getCost(w);
			}
		}
		
		return result;
	}
	
	public int getCostsBySteps() {
		return this.intentions.size();
	}
}
