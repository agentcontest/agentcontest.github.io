package de.tub.mac13.teamb.ontology.graph;

import java.util.Comparator;
import java.util.LinkedList;

import de.tub.mac13.teamb.ontology.World;
import de.tub.mac13.teamb.util.Zone;

public class Path {

    private LinkedList<Integer> path;
    private LinkedList<Integer> shortPath;

    private int start;
    private int target;
    private int cost;
    private World world;
    private Zone zone;

    public Path(int start, World world) {
        this.path = new LinkedList<Integer>();
        this.shortPath = new LinkedList<Integer>();
        this.world = world;
        addStep(start);
    }

    public Path(World world) {
        this.path = new LinkedList<Integer>();
        this.shortPath = new LinkedList<Integer>();
        this.world = world;
    }

    public Path(LinkedList<Integer> path, World world) {
        this.path = path;
        this.world = world;
        if(!path.isEmpty()) {
            this.start = path.getFirst();
            this.target = path.getLast();
        }
        calculateCosts();
        calculateShortPath();
    }

    public Path(LinkedList<Integer> path, int start, int target, World world) {
        this.path = path;
        this.start = start;
        this.target = target;
        this.world = world;
        calculateCosts();
        calculateShortPath();
    }

    /**
     * That's a copy constructor
     * 
     * @param other
     *            Path object to copy
     */
    public Path(Path other) {
        this.path = new LinkedList<Integer>(other.path);
        this.start = other.start;
        this.target = other.target;
        this.cost = other.cost;
        this.world = other.world;
        this.shortPath = new LinkedList<Integer>(other.shortPath);
    }

    private void calculateShortPath() {
        this.shortPath = new LinkedList<>();

        for(int i = 0; i < (this.getPath().size() + 1) / 2; i++) {
            this.shortPath.add(this.getPath().get(i * 2));
        }
    }

    private void calculateCosts() {
        int costs = 0;
        if(path.size() > 1) {
            for(int i = 0; i < path.size() - 1; i++) {
                costs += world.graph.getEdge(path.get(i), path.get(i + 1)).getWeight();
            }
        }
        this.cost = costs;
    }

    public LinkedList<Integer> getPath() {
        return path;
    }

    public int getStart() {
        return start;
    }

    public Vertex getStartVertex() {
        return world.graph.getVertex(start);
    }

    public int getTarget() {
        return target;
    }

    public int getFirstStep() {
        if(path.size() > 1) {
            return path.get(1);
        }
        return path.get(0);
    }

    public int getStep(int number) {
        return path.get(number);
    }

    public int getLastStepCost() {
        return getStepCost(path.size() - 2);
    }

    public int getFirstStepCost() {
        return getStepCost(0);
    }

    public int getStepCost(int number) {
        if(number < path.size() - 1)
            return world.graph.getEdge(path.get(number), path.get(number + 1)).weight;
        else
            return Integer.MAX_VALUE;
    }

    public Vertex getTargetVertex() {
        return world.graph.getVertex(target);
    }

    public int getCost() {
        return cost;
    }
    
    public LinkedList<Integer> getShortPath() {
        return shortPath;
    }

    public int getStepCount() {
        return this.path.size() - 1;
    }

    public boolean addStep(Vertex v) {
        return addStepLast(v);
    }

    public boolean addStep(int id) {
        return addStepLast(id);
    }

    public boolean addStepLast(Vertex v) {
        return addStep(v.id, path.size());
    }

    public boolean addStepLast(int id) {
        return addStep(id, path.size());
    }

    public boolean addStepFirst(Vertex v) {
        return addStep(v.id, 0);
    }

    public boolean addStepFirst(int id) {
        return addStep(id, 0);
    }

    public int getHighestStepCost(){
        int max = Integer.MIN_VALUE;
        for(int i = 0;i<getStepCount();i++){
            max = Math.max(getStepCost(i),max);
        }
        return max;
    }

    public boolean removeStepLast() {
        if(path.size() == 0) {
            return false;
        }

        if(path.size() == 1) {
            path.removeLast();

            target = -1;
            start = -1;
        } else {
            Edge e = null;
            e = world.graph.getEdge(path.getLast(), path.get(path.size() - 2));

            cost -= e.weight;

            path.removeLast();

            target = path.getLast();
        }
        return true;
    }

    private boolean addStep(int id, int position) {
        if(path.size() == 0) {
            path.add(id);
            shortPath.add(id);
            start = id;
            target = id;
        } else {
            Edge e = null;
            if(position == path.size()) {
                e = world.graph.getEdge(path.getLast(), id);
                if(e == null || e.weight == Integer.MAX_VALUE) {
                    return false;
                }
                path.add(id);
                target = id;
                
                if(path.size() % 2 == 1) {
                    shortPath.add(id);
                }
            } else {
                e = world.graph.getEdge(path.getFirst(), id);
                if(e == null || e.weight == Integer.MAX_VALUE) {
                    return false;
                }
                path.addFirst(id);
                start = id;
                this.calculateShortPath();
            }
            cost += e.weight;

        }
        
        
        return true;
    }

    public boolean contains(Vertex v) {
        return contains(v.id);
    }

    public boolean contains(int id) {
        return path.contains(id);
    }

    public static final Comparator<Path> BY_COST = new Comparator<Path>() {

        @Override
        public int compare(Path path1, Path path2) {
            int result = path1.getCost() - path2.getCost();
            if(result == 0) {
                // if same cost, compare by step count
                return path1.getStepCount() - path2.getStepCount();
            }
            return result;
        }
    };

    public static final Comparator<Path> BY_STEPCOUNT = new Comparator<Path>() {

        @Override
        public int compare(Path path1, Path path2) {
            int result = path1.getStepCount() - path2.getStepCount();
            if(result == 0) {
                // if same step count, compare by cost
                return path1.getCost() - path2.getCost();
            }
            return result;
        }
    };

    public static final Comparator<Path> BY_COST_PER_STEP = new Comparator<Path>() {

        @Override
        public int compare(Path path1, Path path2) {
            int s1 = path1.getStepCount();
            int s2 = path2.getStepCount();
            int result = path1.getCost() / (s1 == 0 ? 1 : s1) - path2.getCost() / (s2 == 0 ? 1 : s2);
            if(result == 0) {
                // if same cost per step, compare by step count
                return BY_STEPCOUNT.compare(path1, path2);
            }
            return result;
        }
    };

    public static final Comparator<Path> BY_COST_HEURISTIC = new Comparator<Path>() {

        @Override
        public int compare(Path path1, Path path2) {
            int result = (path1.getCost() + path1.getTargetVertex().getHeuristicValue())
                    - (path2.getCost() + path2.getTargetVertex().getHeuristicValue());
            if(result == 0) {
                // if same cost, compare by step count
                return path1.getStepCount() - path2.getStepCount();
            }
            return result;
        }
    };

    public static final Comparator<Path> BY_BREADTHFIRST = new Comparator<Path>() {
        @Override
        public int compare(Path path1, Path path2) {
            return path1.getStepCount() - path2.getStepCount();
        }
    };

    public static final Comparator<Path> BY_DEPTHFIRST = new Comparator<Path>() {
        @Override
        public int compare(Path path1, Path path2) {
            return path2.getStepCount() - path1.getStepCount();
        }
    };

    @Override
    public boolean equals(Object o) {
        Path other = (Path) o;

        if(this.getStepCount() != other.getStepCount()
                || !((this.start == other.target && this.target == other.start) || (this.start == other.start && this.target == other.target)))
            return false;

        for(Integer i : other.shortPath) {
            if(!this.shortPath.contains(i))
                return false;
        }
        
        return true;
    }

    @Override
    public String toString() {
        StringBuilder str = new StringBuilder();
        return str.append("Path from " + this.start + " to " + this.target + ". costs: " + this.cost + " steps: " + this.getStepCount()).toString();
    }

    public int getZoneValue() {
        return zone.getValue();
    }

    public Zone getZone() {
        return zone;
    }

    public void setZone(Zone zone) {
        this.zone = zone;
    }
}
