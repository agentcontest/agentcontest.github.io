package de.tub.mac13.teamb.connection;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac13.teamb.Constants;
import de.tub.mac13.teamb.ontology.AuthResponse;
import de.tub.mac13.teamb.ontology.Bye;
import de.tub.mac13.teamb.ontology.Entity;
import de.tub.mac13.teamb.ontology.Perception;
import de.tub.mac13.teamb.ontology.SimEnd;
import de.tub.mac13.teamb.ontology.World;
import de.tub.mac13.teamb.ontology.enums.ActionResult;
import de.tub.mac13.teamb.ontology.enums.AgentRole;
import de.tub.mac13.teamb.ontology.enums.TeamType;
import de.tub.mac13.teamb.ontology.graph.Edge;
import de.tub.mac13.teamb.ontology.graph.Vertex;

public class MessageParser {

    private String username;

    public MessageParser(String username) {
        this.username = username;
    }

    public IFact parse(Document message) {
        Element root = message.getDocumentElement();
        
        String messageType = root.getAttribute("type").trim();
        
        if (messageType.equalsIgnoreCase(Constants.MESSAGE_ACTION_REQUEST)) {
            return receivePerception(root);
        }
        if (messageType.equalsIgnoreCase(Constants.MESSAGE_SIM_START)) {
            return receiveSimStart(root);
        }
        if (messageType.equalsIgnoreCase(Constants.MESSAGE_SIM_END)) {
            return receiveSimEnd(root);
        }
        if (messageType.equalsIgnoreCase(Constants.MESSAGE_BYE)) {
            return new Bye();
        }
        if (messageType.equalsIgnoreCase(Constants.MESSAGE_AUTH_RESPONSE)) {
            return receiveAuth(root);
        }

        System.err.println(messageType);
        return null;
    }

    private int getVertexId(String name) {
        try {
            return Integer.parseInt(name.substring(1));
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private IFact receivePerception(Element root) {
        Perception perception = new Perception(username);

        perception.timestamp = Long.parseLong(root.getAttribute("timestamp"));

        NodeList nodes = root.getElementsByTagName("perception");

        Element childPerception = (Element) nodes.item(0);
        perception.id = Integer.parseInt(childPerception.getAttribute("id"));
        perception.deadline = Long.parseLong(childPerception.getAttribute("deadline"));

        Element selfPerception = (Element) childPerception.getElementsByTagName("self").item(0);

        perception.energy = Integer.parseInt(selfPerception.getAttribute("energy"));
        perception.health = Integer.parseInt(selfPerception.getAttribute("health"));
        perception.maxEnergy = Integer.parseInt(selfPerception.getAttribute("maxEnergy"));
        perception.maxEnergyDisabled = Integer.parseInt(selfPerception.getAttribute("maxEnergyDisabled"));
        perception.maxHealth = Integer.parseInt(selfPerception.getAttribute("maxHealth"));
        perception.strength = Integer.parseInt(selfPerception.getAttribute("strength"));
        perception.position = getVertexId(selfPerception.getAttribute("position"));
        perception.visRange = Integer.parseInt(selfPerception.getAttribute("visRange"));
        perception.zoneScore = Integer.parseInt(selfPerception.getAttribute("zoneScore"));
        

        perception.lastAction = selfPerception.getAttribute("lastAction");
        perception.lastActionResult = ActionResult.getByString(selfPerception.getAttribute("lastActionResult"));
        Element teamPerception = (Element) childPerception.getElementsByTagName("team").item(0);

        perception.team.lastStepScore = Integer.parseInt(teamPerception.getAttribute("lastStepScore"));
        perception.team.money = Integer.parseInt(teamPerception.getAttribute("money"));
        perception.team.score = Integer.parseInt(teamPerception.getAttribute("score"));

        Element achievementsPerception = (Element) teamPerception.getElementsByTagName("achievements").item(0);

        if (achievementsPerception != null) {
            NodeList achievements = achievementsPerception.getElementsByTagName("achievement");

            for (int i = 0; i < achievements.getLength(); i++) {
                perception.team.achievements.add(((Element) achievements.item(i)).getAttribute("name"));
            }
        }

        Element visibleVerticesPerception = (Element) childPerception.getElementsByTagName("visibleVertices").item(0);

        if (visibleVerticesPerception != null) {
            NodeList vvpNodes = visibleVerticesPerception.getElementsByTagName("visibleVertex");

            String team;
            if(vvpNodes.getLength() < 300){ //FIXME CRUDE BUGFIX for Huge Zonening BUG!!!
            	
            
	            for (int i = 0; i < vvpNodes.getLength(); i++) {
	                team = ((Element) vvpNodes.item(i)).getAttribute("team");
	                Vertex v = new Vertex(getVertexId(((Element) vvpNodes.item(i)).getAttribute("name")));
	                //System.err.println(team);
	                //if (Constants.TEAM_NAME.equalsIgnoreCase(team)) {
	                if (Constants.TEAM_NAME_TMP.equalsIgnoreCase(team)) {
	                    v.team = TeamType.OWN;
	                    //otherwise all nodes will be enemy nodes witch may be bad for some algorithms? like evade?
	                } else if(team.equalsIgnoreCase("none")) {
	                    v.team = TeamType.NONE;
	                } else {
	                	v.team = TeamType.ENEMY;
	                }
	                perception.add(v);
	            }
            }
        }

        Element visibleEdgesPerception = (Element) childPerception.getElementsByTagName("visibleEdges").item(0);

        if (visibleEdgesPerception != null) {
            NodeList vepNodes = visibleEdgesPerception.getElementsByTagName("visibleEdge");

            for (int i = 0; i < vepNodes.getLength(); i++) {
                Edge e = new Edge(getVertexId(((Element) vepNodes.item(i)).getAttribute("node1")),
                        getVertexId(((Element) vepNodes.item(i)).getAttribute("node2")));
                perception.add(e);
            }
        }

        Element visibleEntitiesPerception = (Element) childPerception.getElementsByTagName("visibleEntities").item(0);

        if (visibleEntitiesPerception != null) {
            NodeList venpNodes = visibleEntitiesPerception.getElementsByTagName("visibleEntity");

            String team;
            for (int i = 0; i < venpNodes.getLength(); i++) {
                team = ((Element) venpNodes.item(i)).getAttribute("team");
                Entity e = new Entity();
                e.name = ((Element) venpNodes.item(i)).getAttribute("name");
                e.position = new Vertex(getVertexId(((Element) venpNodes.item(i)).getAttribute("node")));
                e.status = ((Element) venpNodes.item(i)).getAttribute("status");
                //if (TeamType.OWN.toString().equalsIgnoreCase(team)) {
                if (Constants.TEAM_NAME_TMP.equalsIgnoreCase(team)) {
                    e.team = TeamType.OWN;
                } else {
                    e.team = TeamType.ENEMY;
                }

                perception.add(e);
            }
        }

        Element probedVerticesPerception = (Element) childPerception.getElementsByTagName("probedVertices").item(0);
        
        if (probedVerticesPerception != null) {
            NodeList pvpNodes = probedVerticesPerception.getElementsByTagName("probedVertex");

            for (int i = 0; i < pvpNodes.getLength(); i++) {
                Vertex v = new Vertex(getVertexId(((Element) pvpNodes.item(i)).getAttribute("name")));
                v.value = Integer.parseInt(((Element) pvpNodes.item(i)).getAttribute("value"));

                perception.add(v);
            }
        }

        Element surveyedEdgesPerception = (Element) childPerception.getElementsByTagName("surveyedEdges").item(0);

        if (surveyedEdgesPerception != null) {
            NodeList sepNodes = surveyedEdgesPerception.getElementsByTagName("surveyedEdge");

            for (int i = 0; i < sepNodes.getLength(); i++) {
                Edge e = new Edge(getVertexId(((Element) sepNodes.item(i)).getAttribute("node1")),
                        getVertexId(((Element) sepNodes.item(i)).getAttribute("node2")));
                e.weight = Integer.parseInt(((Element) sepNodes.item(i)).getAttribute("weight"));

                perception.add(e);
            }
        }

        Element inspectedEntitiesPerception = (Element) childPerception.getElementsByTagName("inspectedEntities").item(0);

        if (inspectedEntitiesPerception != null) {
            NodeList iepNodes = inspectedEntitiesPerception.getElementsByTagName("inspectedEntity");

            String team;
            
            for (int i = 0; i < iepNodes.getLength(); i++) {
                team = ((Element) iepNodes.item(i)).getAttribute("team");
                Entity e = new Entity();
                e.energy = Integer.parseInt(((Element) iepNodes.item(i)).getAttribute("energy"));
                e.health = Integer.parseInt(((Element) iepNodes.item(i)).getAttribute("health"));
                e.maxEnergy = Integer.parseInt(((Element) iepNodes.item(i)).getAttribute("maxEnergy"));
                e.maxHealth = Integer.parseInt(((Element) iepNodes.item(i)).getAttribute("maxHealth"));
                e.name = ((Element) iepNodes.item(i)).getAttribute("name");
                e.position = new Vertex(getVertexId(((Element) iepNodes.item(i)).getAttribute("node")));
                e.role = AgentRole.get(((Element) iepNodes.item(i)).getAttribute("role"));
                e.strength = Integer.parseInt(((Element) iepNodes.item(i)).getAttribute("strength"));
                e.visRange = Integer.parseInt(((Element) iepNodes.item(i)).getAttribute("visRange"));
                
                //if (TeamType.OWN.toString().equalsIgnoreCase(team)) {
                if (Constants.TEAM_NAME_TMP.equalsIgnoreCase(team)) {
                    e.team = TeamType.OWN;
                } else {
                    e.team = TeamType.ENEMY;
                }
                perception.add(e);
            }
        }
        
        return perception;
    }

    private IFact receiveSimStart(Element root) {
        World world = new World(username);

        NodeList childs = root.getElementsByTagName("simulation");
        Element childSimulation = (Element) childs.item(0);

        world.edgeCount = Integer.parseInt(childSimulation.getAttribute("edges"));
        world.vertexCount = Integer.parseInt(childSimulation.getAttribute("vertices"));
        world.maxSteps = Integer.parseInt(childSimulation.getAttribute("steps"));
        //FIX might be a source of major bugs ... (paring problems) O.O
        world.self.role = AgentRole.get(childSimulation.getAttribute("role"));

        return world;
    }

    private IFact receiveSimEnd(Element root) {
        SimEnd simEnd = new SimEnd();

        NodeList childs = root.getElementsByTagName("sim-result");
        Element childSimResult = (Element) childs.item(0);

        simEnd.setRanking(childSimResult.getAttribute("ranking"));
        simEnd.setScore(childSimResult.getAttribute("score"));

        return simEnd;
    }

    private IFact receiveAuth(Element root) {
        NodeList nodes = root.getElementsByTagName("authentication");

        String result = ((Element) nodes.item(0)).getAttribute("result");

        if (result.equalsIgnoreCase("ok")) {
            return new AuthResponse(true);
        } else {
            return new AuthResponse(false);
        }
    }
}
