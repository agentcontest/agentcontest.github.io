#!/bin/sh
cd ..
cd common
cd ac13-contest-server
gnome-terminal -e "bash -x startServer.sh" &
gnome-terminal -e "bash -x startMarsMonitor.sh" &
cd ..
cd ..
cd mac13-teamb/dummyteam
gnome-terminal -e "bash -x start.sh" &
