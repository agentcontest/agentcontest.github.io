To run the team, simply type
    ant runA
if your team is the teamA in the simulator, or
    ant runB
otherwise.

In case you want to run this team as team A you also have to rename the file
	asl/mod.loadAgentsA.asl
to
	asl/mod.loadAgents.asl


