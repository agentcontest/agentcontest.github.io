g++ z.cpp -o z -lpthread && ./z r
