#include<stdio.h>
#include<stdlib.h>
#include<sys/socket.h>
//#include<error.h>
#include<string.h>
//#include<sys/types.h>
//#include<netinet/in.h>
#include<arpa/inet.h>
#include<string>
#include<string.h>
#include<iostream>
#include<vector>
#include<stack>
#include<queue>
#include<map>
#include<algorithm>
//#include <pthread.h>
#include <unistd.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
//#include<sys/wait.h>
#include<sys/time.h>
#include<sys/epoll.h>
using namespace std;

#define log_on 0
#define error_on 0


//Should_attack_enermy(zv)


//Node::Set_edge_value() edge value can not be 0
//if some node's nabour are all suveyed then this node do not need to surveyed
//dang1 yu4 dao4 di2 ren2, ru2 guo3 di2 ren2 de neng2liang4 bu2gou4, ze2 pao3

typedef long long LL;
const int oo = 0x3fffffff;



int hand_on=0;



const int max_kuo_area_n=10;
int kuo_area_n=3;
int kuo01=0;
int kuo_step_add=50;



int kuo_area_agent_s[max_kuo_area_n];

int kuo_max_bound_nodes=10;
double kuo_max_nodes_rate=0.1;




int agent_0_conquer_all_map=0;
//int team_A_skip=0;
int team_B_skip=0;

const int max_msg_length =1000000;
const int min_msg_length=1000000;

const int max_agent_n=28;
int enermy_n=max_agent_n;
const int max_node_n=2000;
int agent_n;


int enermy_must_attack[max_agent_n];


int D_e[max_agent_n];

int clocksPerSecond=1000;


string memory_file="memory_file.in";
int memory_on=0;

int perception_id;
int simulation_edges;
int sim_end;

int edge_n=0;


int ts;
int us;
int clock_sign=0;


int last_clock=0;




string string_mission_attack="string_mission_attack";


int clock_s=0;


struct   timeval   time_start,time_stop,time_diff;		
struct   timeval   time_step_a,time_step_b,time_step_c;		

string string_explorer="Explorer";
string string_saboteur="Saboteur";
string string_inspector="Inspector";		
string string_repairer="Repairer";
string string_sentinel="Sentinel";
string string_request_action ="request-action";
string string_version = "version";

string string_visibleVertex="visibleVertex";
string string_disabled="disabled";

string string_visibleEdges="visibleEdges";





string string_encoding = "encoding";
string string_message_timestamp = "message_timestamp";
string string_message_type = "message_type";
string string_perception_deadline = "perception_deadline";
string string_perception_id = "perception_id";
string string_simulation_step = "simulation_step";
string string_self_energy = "self_energy";
string string_self_health = "self_health";
string string_self_lastAction = "self_lastAction";
string string_self_lastActionParam = "self_lastActionParam";
string string_self_lastActionResult = "self_lastActionResult";
string string_self_maxEnergy = "self_maxEnergy";
string string_self_maxEnergyDisabled = "self_maxEnergyDisabled";
string string_self_maxHealth = "self_maxHealth";
string string_self_position = "self_position";
string string_self_strength = "self_strength";
string string_self_visRange = "self_visRange";
string string_self_zoneScore = "self_zoneScore";
string string_team_lastStepScore = "team_lastStepScore";
string string_team_money = "team_money";
string string_team_score = "team_score";
string string_team_zonesScore = "team_zonesScore";
string string_achievement_name = "achievement_name";
string string_visibleVertex_name = "visibleVertex_name";
string string_visibleVertex_team = "visibleVertex_team";
string string_visibleEntity_name = "visibleEntity_name";
string string_visibleEntity_node = "visibleEntity_node";
string string_visibleEntity_status = "visibleEntity_status";
string string_visibleEntity_team = "visibleEntity_team";

string string_probedVertex_name = "probedVertex_name";
string string_probedVertex_value = "probedVertex_value";
		
string string_surveyedEdge_node1 = "surveyedEdge_node1";
string string_surveyedEdge_node2 = "surveyedEdge_node2";
string string_surveyedEdge_weight = "surveyedEdge_weight";

string string_inspectedEntity_energy = "inspectedEntity_energy";
string string_inspectedEntity_health = "inspectedEntity_health";
string string_inspectedEntity_maxEnergy = "inspectedEntity_maxEnergy";
string string_inspectedEntity_name = "inspectedEntity_name";
string string_inspectedEntity_node = "inspectedEntity_node";
string string_inspectedEntity_role = "inspectedEntity_role";
string string_inspectedEntity_strength = "inspectedEntity_strength";
string string_inspectedEntity_team = "inspectedEntity_team";
string string_inspectedEntity_visRange = "inspectedEntity_visRange";
string string_inspectedEntity_maxHealth="inspectedEntity_maxHealth";

string string_survey="survey";
		
string string_timestamp="timestamp";
string string_type="type";
string string_deadline="deadline";
string string_visibleEdge_node1="visibleEdge_node1";
string string_visibleEdge_node2="visibleEdge_node2";
string string_authentication_result="authentication_result";
string string_ok="ok";	


string string_sim_start="sim-start";
string string_simulation_edges="simulation_edges";
string string_simulation_id="simulation_id";
string string_simulation_role="simulation_role";
string string_simulation_steps="simulation_steps";
string string_simulation_vertices="simulation_vertices";
string string_sim_end="sim-end";
string string_sim_result_ranking="sim-result_ranking";
string string_sim_result_score="sim-result_score";

string string_probe="probe";
string string_goto_="goto";
string string_successful="successful";
		
string string_normal="normal";
		
string string_name="name";
string string_energy="energy";
string string_health="health";
string string_max_energy="max_energy";
string string_max_health="max_health";
string string_position="position";
string string_strenth="strenth";
string string_vis_range="vis_range";
string string_team="team";
string string_role="role";
string string_status="status";
string string_node="node";
string string_edge="edge";
string string_agent="agent";
string string_hand="hand";
		
string string_A="A";
string string_B="B";
string string_k="k";
string string_check="check";
string string_edge_value="edge_value";
string string_surveyed_node="surveyed_node";
string string_sight="sight";
string string_noAction="noAction";
string string_Wang_Yuxin="Wang_Yuxin";
string string_recharge="recharge";
string string_attack="attack";
string string_repair="repair";
string string_inspect="inspect";
string string_skip="skip";
		
		
string string_battery="battery";
string string_sensor="sensor";
string string_shield="shield";
string string_sabotageDevice="sabotageDevice";
string string_buy="buy";
string string_wrongParameter="wrongParameter";
string string_failed_limit="failed_limit";
string string_failed_resources="failed_resources";
string string_failed_random="failed_random";
string string_failed_attacked="failed_attacked";
string string_failed_role="failed_role";
string string_failed_status="failed_status";
string string_failed_wrong_param="failed_wrong_param";
		
string string_parry="parry";
string string_useless="useless";
	
string string_mission_kuo="kuo";
		
string string_proxy="proxy";
string string_ip_port_file_name="./ini/ip_port.ini";

		
string string_mission_explorer_min_cost_visit_bound="_ev";
string string_mission_not_explorer_min_cost_visit_bound="nev";
		
		
		
string string_failed_away="";
string string_failed_parry="";
		
		
		
		
string string_alliance_mode="alliance_mode";


	int sim_result_ranking;
	int sim_result_score;
	
int do_not_attack[max_agent_n];

vector<string> can_buy_role;
vector<string> mode;
	



void If_end()
	{
		FILE *F;
		string zs;
		char buff[100];
		
		F=fopen("WYX","r");
		if(fscanf(F,"%s",buff)==EOF)
		{
			fclose(F);
			return;
		}
		zs=buff;
		if(zs=="end" || zs=="re")
		{
			fclose(F);
			printf("Wang Yuxin order end\n");
			exit(0);
		}
	}

void Wait_1_unit()
	{
		usleep(clocksPerSecond);
	}
	
	void Clear_screan()
	{
		system("CLS");
	}
	
#if error_on
void Error(string r)
	{
		cout<<"[error] ["<<r<<"]"<<endl;
//		write("[error] [");
//		write(r);
//		writeln("]");
		exit(0);
	}
#endif
	
	






int Time_subtract(struct timeval *result, struct timeval *x, struct timeval *y)
{
	int nsec;
	if ( x->tv_sec > y->tv_sec )
		return   -1;
	if ((x->tv_sec==y->tv_sec) && (x->tv_usec>y->tv_usec))
		return   -1;
	result->tv_sec = ( y->tv_sec-x->tv_sec );
	result->tv_usec = ( y->tv_usec-x->tv_usec );
	if (result->tv_usec<0)
	{
		result->tv_sec--;
		result->tv_usec+=1000000;
	}
	return   0;
}




#if log_on


struct Log
{
	string file_name;
	void Init(string x)
	{	
		file_name=x;
		
	}	
	
	void Clear()
	{
		FILE *F;
		F=fopen(file_name.c_str(),"w");
		
		#if error_on
		if(F==0)
		{
				cout<<file_name<<endl;
				Error("45u45sisj");
		}
		#endif
			
		if(F!=0)fclose(F);
	}
	

	void write()
	{
		//printf("\n");
		
		FILE *F=fopen(file_name.c_str(),"a");
		fprintf(F,"\n");
		fclose(F);
	}
	/*
	void write(char r)
	{
		printf("%d",int(r));
		
		FILE *F=fopen("z.txt","a");
		fprintf(F,"%c",r);
		fclose(F);
	}
	
	void writeln(char r)
	{
		printf("%d\n",int(r));
		
		FILE *F=fopen("z.txt","a");
		fprintf(F,"%c\n",r);
		fclose(F);
	}
*/
	void write(string r)
	{
		int i,n;
		n=r.length();
	//	for(i=0;i<n;i++)
	//	printf("%c",r[i]);
		
		FILE *F=fopen(file_name.c_str(),"a");		
		for(i=0;i<n;i++)
		fprintf(F,"%c",r[i]);
		fclose(F);
	}
	
	
	void writeln(string r)
	{
		int i,n;
		n=r.length();
	//	for(i=0;i<n;i++)
	//	printf("%c",r[i]);
	//	printf("\n");
	
		
		FILE *F=fopen(file_name.c_str(),"a");		
		for(i=0;i<n;i++)
		fprintf(F,"%c",r[i]);
		fprintf(F,"\n");
		fclose(F);
	}
	
	void writeln_chars(char r[],int rn)
	{
		int i,n;		
		FILE *F=fopen(file_name.c_str(),"a");	
		for(i=0;i<rn;i++)	
		if(r[i])
		fprintf(F,"%c",r[i]);
		fprintf(F,"\n");
		fclose(F);
	}
	
	void write(int r)
	{
	//	printf("%d",r);
		
		FILE *F=fopen(file_name.c_str(),"a");
		fprintf(F,"%d",r);
		fclose(F);
	}
	
	void writeln(int r)
	{
	//	printf("%d\n",r);
		
		FILE *F=fopen(file_name.c_str(),"a");
		fprintf(F,"%d\n",r);
		fclose(F);
	}
};
Log log[max_agent_n];
Log msg_file[max_agent_n];
#endif



///S
string String_int_to_string(int x)
	{
		string ret="";
		if(x==0)return "0";
		if(x<0)return '-'+String_int_to_string(-x);
		
		while(x)
		{
			ret=char(x%10+'0')+ret;
			x/=10;
		}
		return ret;
	}

int String_find(char r[],int xi,char x)
	{
		int i,n;
		n=strlen(r);
		for(i=xi;i<n;i++)
		if(r[i]==x)return i;
		return -1;
	}

bool String_add_until_0(char a[],int &an,char b[],int &bn)
	{
		int i,j;
		int s0=0;
		
		for(i=0;i<bn;i++)
		{
			a[an++]=b[i];
			b[i]=0;
		}		
		bn=0;
		
		for(i=0;i<an;i++)
		{
			if(a[i]==0)
			{
				s0++;
				if(s0)break;
			}
		}
		if(s0<1)return 0;
		
		for(j=i+1;j<an;j++)
		{
			b[bn++]=a[j];
			a[j]=0;
		}
		an=i;
		return 1;
	}

int String_string_to_int(string r)
	{
		int i,ret=0,n=r.length();
		for(i=0;i<n;i++)ret=ret*10+r[i]-'0';
		return ret;
	}

string String_del_lead_space(string r)
	{
		int i;
		string ret="";
		int n=r.length();
		for(i=0;i<n && r[i]==' ';i++);
		for(;i<n;i++)ret+=r[i];
		
		return ret;
	}
	
	string String_join_continue_space(string r)
	{
		int i;
		string ret="";
		int n=r.length();
		
		for(i=0;i<n;i++)
			if(i==0) ret=ret+r[i];
			else if(! (r[i]==' ' && r[i-1]==' ') )ret=ret+r[i];
			
		return ret;
	}

string String_segment(string r,int x)
	{
		r=String_del_lead_space(r);
		r=String_join_continue_space(r);
				
		string ret="";
		int n=r.length(),i,z;
		
		z=0;
		for(i=0;i<x-1;i++)
		{
			for(;z<n && r[z]!=' ';z++);
			z++;
		}
		
		#if error_on
		if(z>=n)
			Error("oijwds8yp9ahio");			
		#endif
		
		for(;z<n && r[z]!=' ';z++)ret=ret+r[z];
		
		return ret;
	}






int Edge_all_see()
{
	if(edge_n==simulation_edges)
		return 1;
		
	#if error_on
	if(edge_n>simulation_edges)
		Error("r9230ut0q43uy");
	#endif
	return 0;
}





bool D_find(int r[],int n,int x)
{
	int i;
	for(i=0;i<n;i++)
	if(r[i]==x)
		return 1;
	return 0;
}

bool D_find(string r[],int n,string x)
{
	int i;
	for(i=0;i<n;i++)
	if(r[i]==x)
		return 1;
	return 0;
}



bool Vector_find(vector<string> &r,string x)
	{
		int i;
		for(i=0;i<r.size();i++)
		if(r[i]==x)return 1;
		return 0;
	}
	
bool Vector_find(vector<int> &r,int x)
	{
		int i;
		for(i=0;i<r.size();i++)
		if(r[i]==x)return 1;
		return 0;
	}


void Vector_leave_last(vector<int>& x)
{
	if(!x.size())
		return;
	int z=x[x.size()-1];
	x.clear();
	x.push_back(z);
}

vector<int> Vector_empty()
{
	vector<int> ret;
	ret.clear();
	return ret;
}






///m
void Memory_clear()
{
	FILE* F=fopen(memory_file.c_str(),"w");
	fclose(F);
}

void Memory_node_value(int x,int y)
{
	FILE* F=fopen(memory_file.c_str(),"a");
		fprintf(F,"v %d %d\n",x,y);
	fclose(F);
}

void Memory_node_surveyed(int x)
{
	FILE* F=fopen(memory_file.c_str(),"a");
		fprintf(F,"s %d\n",x);
	fclose(F);
}

void Memory_node_edge(int x,int y,int z)
{
	FILE* F=fopen(memory_file.c_str(),"a");
		fprintf(F,"e %d %d %d\n",x,y,z);
	fclose(F);
}

void Memory_enermy_role(string a,string b,string c)
{
	FILE* F=fopen(memory_file.c_str(),"a");
		fprintf(F,"r %s %s %s\n",a.c_str(),b.c_str(),("["+c).c_str());
	fclose(F);
}





int node_edge_n[max_node_n];
vector<int> node_edge[max_node_n];
vector<bool> node_edge_is_surveyed[max_node_n];
vector<int> node_edge_value[max_node_n];
bool node_is_probed[max_node_n];
int node_value[max_node_n];
int node_visited[max_node_n];
bool node_is_surveyed[max_node_n];

//tmp
int node_v[max_node_n];
int node_bound[max_node_n];
int node_dis[max_node_n];
bool node_can_kuo[max_node_n];
int node_xu[max_node_n];
int node_ev[max_node_n];
int node_fu_gai[max_node_n];
bool node_yao[max_node_n];
bool node_can_visit[max_node_n][max_agent_n];
bool node_can_visit_through_surveyed_node[max_node_n][max_agent_n];
int node_value_for_agent[max_node_n][max_agent_n];
int node_value_energy_for_agent[max_node_n][max_agent_n];
int node_n=0;

///n

string node_name_int_to_string[max_node_n+1];













///N
int net_s[max_agent_n];//创建套结字
struct   sockaddr_in    net_serverAddr[max_agent_n];

int Net_st(int x,string ip,int Port)
	{	
		net_s[x] = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);//创建一个套节字
		if(net_s[x]==-1)
		{
      		puts("socket failed with error \n");
      		return 0;
   		} 
		net_serverAddr[x].sin_family = AF_INET;
		net_serverAddr[x].sin_port =htons(Port);    
		net_serverAddr[x].sin_addr.s_addr = inet_addr(ip.c_str());//服务器地址IP
			
		cout<<"We are trying to connect to "<<inet_ntoa(net_serverAddr[x].sin_addr)<<":"<<(ntohs(net_serverAddr[x].sin_port))<<"...\n";

		if(connect(net_s[x], (   sockaddr *) &net_serverAddr[x], sizeof(net_serverAddr[x])) == -1)//连接到服务器
		{
			cout<<"Connect failed!\n";
			return 0;
		}
		cout<<"Our connection succeeded.\n";
		return 1;
	}

bool Net_listen(int x,char ret[],int len,int &ret_n,int &ready)
	{
		//log=x;
		int i;
		int n;
		//for(i=0;i<len;i++)
		//	ret[i]=0;
		//ret[0]=0;
		ready=1;
		while(1)
		{
			int z=recv(net_s[x], ret+ret_n, len-ret_n, 0);	
			
			if(z<=0)
			{
				cout<<"z<=0 "<<z<<endl;
				continue;
				exit(0);
			}
					
			//msg_file[agent_pi]->writeln(z);
			//msg_file[agent_pi]->writeln_chars(ret+ret_n,z);
			ret_n+=z;
			return 1;
		}	
		return 1;
	}
	
string Net_send(int x,string r)
	{
		r+='\0';
		//AddLn(r);
		while(1)
		{
			int z=send(net_s[x], r.c_str(), r.length(), 0);						
			if(z<=0)
			{
				continue;	
			}
			break;						
		}
		return "";
	}	




string protocol_order_short[max_agent_n];
string protocol_order[max_agent_n];

void Protocol_init(int x)
	{
		protocol_order[x]="";
		protocol_order_short[x]="";
	}

void Protocol_buy_battery(int x)
	{
		#if log_on
			log[x].write("---------------- protocl Buy_battery() ");
		#endif
	
		string head="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
		
		protocol_order[x]="<message type=\"action\"><action id=\"";
		protocol_order[x]+=String_int_to_string(perception_id);
		protocol_order[x]+="\" type=\"buy\" ";
		protocol_order[x]+="param=\"";
		protocol_order[x]+=string_battery;
		protocol_order[x]+="\"";
		protocol_order[x]+="/></message>";
		protocol_order[x]=head+protocol_order[x];
		protocol_order_short[x]="Buy_battery";
	}
	
void Protocol_buy_sensor(int x)
	{
		#if log_on
		
			log[x].write("---------------- protocl Buy_sensor");	
		#endif
	
		string head="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
		
		protocol_order[x]="<message type=\"action\"><action id=\"";
		protocol_order[x]+=String_int_to_string(perception_id);
		protocol_order[x]+="\" type=\"buy\" ";
		protocol_order[x]+="param=\"";
		protocol_order[x]+=string_sensor;
		protocol_order[x]+="\"";
		protocol_order[x]+="/></message>";
		protocol_order[x]=head+protocol_order[x];
		protocol_order_short[x]="Buy_sensor";
	}
	
	void Protocol_buy_shield(int x)
	{
		#if log_on
		
			log[x].write("---------------- protocl Buy_shield");
		#endif
	
		string head="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
		
		protocol_order[x]="<message type=\"action\"><action id=\"";
		protocol_order[x]+=String_int_to_string(perception_id);
		protocol_order[x]+="\" type=\"buy\" ";
		protocol_order[x]+="param=\"";
		protocol_order[x]+=string_shield;
		protocol_order[x]+="\"";
		protocol_order[x]+="/></message>";
		protocol_order[x]=head+protocol_order[x];
		protocol_order_short[x]="Buy_shield";
	}
	
	void Protocol_buy_sabotageDevice(int x)
	{
		#if log_on
		
			log[x].write("---------------- protocl Buy_sabotageDevice");
		#endif
	
		string zs;
		string head="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
		
		protocol_order[x]="<message type=\"action\"><action id=\"";
		protocol_order[x]+=String_int_to_string(perception_id);
		protocol_order[x]+="\" type=\"buy\" ";
		protocol_order[x]+="param=\"";
		protocol_order[x]+=string_sabotageDevice;
		protocol_order[x]+="\"";
		protocol_order[x]+="/></message>";
		protocol_order[x]=head+protocol_order[x];
		protocol_order_short[x]="Buy_sabotageDevice";
	}

void Protocol_repair(int x,string param)
	{
		#if log_on
		
			log[x].write("---------------- protocl Repair ");
			log[x].writeln(param);
		#endif
	
		string zs;
		string head="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
		
		protocol_order[x]="<message type=\"action\"><action id=\"";
		protocol_order[x]+=String_int_to_string(perception_id);
		protocol_order[x]+="\" type=\"repair\" ";
		protocol_order[x]+="param=\"";
		protocol_order[x]+=param;
		protocol_order[x]+="\"";
		protocol_order[x]+="/></message>";
		protocol_order[x]=head+protocol_order[x];
		protocol_order_short[x]="Repair "+param;
	}

void Protocol_goto(int x,string param)
	{
		#if log_on
			log[x].write("---------------- protocl Goto ");
			log[x].writeln(param);
		#endif
	
		string head="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
		
		protocol_order[x]="<message type=\"action\"><action id=\"";
		protocol_order[x]+=String_int_to_string(perception_id);
		protocol_order[x]+="\" type=\"goto\" ";
		protocol_order[x]+="param=\"";
		protocol_order[x]+=param;
		protocol_order[x]+="\"";
		protocol_order[x]+="/></message>";
		protocol_order[x]=head+protocol_order[x];
		protocol_order_short[x]="Goto "+param;
	}

void Protocol_attack(int x,string param)
	{
		#if log_on
			log[x].write("---------------- protocl Attack ");
			log[x].writeln(param);			
		#endif
	
		string head="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
		
		protocol_order[x]="<message type=\"action\"><action id=\"";
		protocol_order[x]+=String_int_to_string(perception_id);
		protocol_order[x]+="\" type=\"attack\" ";
		protocol_order[x]+="param=\"";
		protocol_order[x]+=param;
		protocol_order[x]+="\"";
		protocol_order[x]+="/></message>";
		protocol_order[x]=head+protocol_order[x];
		protocol_order_short[x]="Attack "+param;
	}

void Protocol_parry(int x)
	{
		#if log_on
			log[x].writeln("---------------- protocl Parry ");
		#endif
		
		string head="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
		
		protocol_order[x]="<message type=\"action\"><action id=\"";
		protocol_order[x]+=String_int_to_string(perception_id);
		protocol_order[x]+="\" type=\"";
		protocol_order[x]+=string_parry;
		protocol_order[x]+="\"/></message>";
		protocol_order[x]=head+protocol_order[x];
		protocol_order_short[x]="Parry";
	}

void Protocol_survey(int x)
	{
		#if log_on
			log[x].writeln("---------------- protocl Survey ");
		#endif
		
		string head="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
		
		protocol_order[x]="<message type=\"action\"><action id=\"";
		protocol_order[x]+=String_int_to_string(perception_id);
		protocol_order[x]+="\" type=\"";
		protocol_order[x]+=string_survey;
		protocol_order[x]+="\"/></message>";
		protocol_order[x]=head+protocol_order[x];
		protocol_order_short[x]="Survey";
	}

void Protocol_inspect(int x,string param)
	{
		#if log_on
			log[x].writeln("---------------- protocl Inspect ");
		#endif
		
		string head="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
		
		protocol_order[x]="<message type=\"action\"><action id=\"";
		protocol_order[x]+=String_int_to_string(perception_id);
		protocol_order[x]+="\" type=\"inspect\" ";
		
		
		protocol_order[x]+="param=\"";
		protocol_order[x]+=param;
		protocol_order[x]+="\"";
		
		protocol_order[x]+="/></message>";
		
		protocol_order[x]=head+protocol_order[x];
		protocol_order_short[x]="Inspect "+param;
	}
	
void Protocol_inspect(int x)
	{
		#if log_on
			log[x].writeln("---------------- protocl Inspect ");
		#endif
		
		string head="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
		
		protocol_order[x]="<message type=\"action\"><action id=\"";
		protocol_order[x]+=String_int_to_string(perception_id);
		protocol_order[x]+="\" type=\"inspect\" ";
		
		
		
		protocol_order[x]+="/></message>";
		
		protocol_order[x]=head+protocol_order[x];
		protocol_order_short[x]="Inspect";
	}

void Protocol_recharge(int x)
	{
		#if log_on
			log[x].writeln("---------------- protocl Recharge ");
		#endif
		
		string head="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
		
		protocol_order[x]="<message type=\"action\"><action id=\"";
		protocol_order[x]+=String_int_to_string(perception_id);
		protocol_order[x]+="\" type=\"recharge\"/></message>";
		protocol_order[x]=head+protocol_order[x];
		protocol_order_short[x]="Recharge";
	}

void Protocol_probe(int x)
	{
		#if log_on
			log[x].writeln("---------------- protocl Probe ");
		#endif
		
		string head="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
		
		protocol_order[x]="<message type=\"action\"><action id=\"";
		protocol_order[x]+=String_int_to_string(perception_id);
		protocol_order[x]+="\" type=\"probe\"/></message>";
		protocol_order[x]=head+protocol_order[x];
		protocol_order_short[x]="Probe";
	}

void Protocol_skip(int x)
	{
		#if log_on
			log[x].writeln("---------------- protocl Skip ");
		#endif
		
		string head="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
		
		protocol_order[x]="<message type=\"action\"><action id=\"";
		protocol_order[x]+=String_int_to_string(perception_id);
		protocol_order[x]+="\" type=\"skip\"/></message>";
		protocol_order[x]=head+protocol_order[x];
		protocol_order_short[x]="Skip";
	}		

void Protocol_auth_request(int x,string username,string password)
	{
		string head="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
		
		protocol_order[x]="<message type=\"auth-request\"><authentication password=\"";
		protocol_order[x]+=password;
		protocol_order[x]+="\" username=\"";
		protocol_order[x]+=username;
		protocol_order[x]+="\"/></message>";
		protocol_order[x]=head+protocol_order[x];
	}

void Protocol_send_order(int x)
	{
		if(protocol_order[x]=="")
			return;
		Net_send(x,protocol_order[x]);
		protocol_order[x]="";
	}

bool Protocol_have_order(int x)
	{
		return protocol_order[x]!="";
	}

///p









string XML_delete_empty_pair(char r[],char xa,char xb)
	{
		
		
		
		int z=0,a,b,flag,i;
		
		
		
		
		while(1)
		{
			a=String_find(r,z,xa);
			b=String_find(r,z,xb);
			
			
			if(a<0)return r;
			
			flag=0;
			for(i=a+1;i<b;i++)
			if(r[i]!=' ')
			{
				flag=1;
				break;
			}
			
			
			if(!flag)
			for(i=a;i<=b;i++)
				r[i]=' ';
			else z=b+1;
		}
		
		#if error_on
		Error("ag933ay4y");
		#endif
	}

void XML_delete_last_end(char r[],int nb)
	{
		string ret;		
		int i;
		
		for(i=nb-1;i>=0;i--)
		if(r[i]=='/')break;
		
		for(i=i-1;i>=0;i--)
		if(r[i]!=' ')break;
		
		if(r[i]!='<')return;
		
		for(i=i-1;i>=0;i--)
		if(r[i]!=' ')break;
		
		nb=i+1;
		r[nb]=0;
	}

string XML_delete_between(char r[],char x,int na,int nb)
	{
		int a,b;
		int i;
		
		while(1)
		{
			a=String_find(r,0,x);
			if(a<0)return r;
			
			b=String_find(r,a+1,x);
		
			
			#if error_on
			if(a>=nb || b>=nb || b<0 || a>=b)
			Error("hga38498uy4y");
			#endif
			
			for(i=a;i<=b;i++)r[i]=' ';
		}		
		
		#if error_on
		Error("arehaerai4y");
		#endif
	}

int XML_f[max_msg_length];

void XML_calc_f(char r[],int nb)
	{	
		int i;
		int ra=0,rb=-1;
		int a;
		int z;
		stack<int> S;
		while(S.size())
			S.pop();
			
		while(1)
		{
			ra=rb+1;
			for(;ra<nb && r[ra]!='<';ra++);
			if(ra>=nb)break;
			S.push(ra);
			
			z=1;
			for(rb=ra+1;rb<nb;rb++)
			if(r[rb]=='<')
			{
				a=rb;
				for(rb=rb+1;rb<nb;rb++)
				if(r[rb]!=' ')break;
				if(r[rb]=='/')
				{
					rb--;
					continue;
				}
				S.push(a);
				z++;
			}
			else if(r[rb]=='/')
			{
				z--;
				for(;rb<nb;rb++)
				if(r[rb]=='>')
					break;
					
				XML_f[S.top()]=rb;
				S.pop();
									
				if(z==0)
					break;
			}			
		}
		
		#if error_on
		if(S.size())
		{			
			Error("oiwhy4390ay");
		}
		#endif
	}


	
	void XML_run(int agent_pi,char r[],int na_x,int nb_x,string name,vector<string>& ret)
	{
		int z,ra,rb,i,j;
		string zs;		
		
		int na=na_x;
		int nb=nb_x;
		
		
				
		
		
		{
			for(ra=na;ra<nb;ra++)
				if(r[ra]=='<')break;
				
			#if error_on
			if(ra<0)
				Error("gah0weyta843y3");
			#endif
			
			for(i=ra+1;i<nb;i++)
			if(r[i]!=' ')break;
			
			for(zs="";i<nb && r[i]!=' ' && r[i]!='/' && r[i]!='=' && r[i]!='>';i++)
				zs=zs+r[i];
			
			name=zs;
			
			
			if(name==string_visibleVertex && agent_pi!=0)
				return;
			
			if(Edge_all_see() && name==string_visibleEdges)
				return;
				
			
			XML_delete_last_end(r,nb);			
		}
				
		
		for(rb=ra;rb<nb;rb++)
		if(r[rb]=='>')break;
		
		for(i=ra;i<rb;i++)
		if(r[i]=='=')
		{
			zs="";
			for(j=i-1;j>=0;j--)
			if(r[j]!=' ')break;
			
			for(;j>=0 && r[j]!=' ' && r[j]!='<' && r[j]!='"';j--)
				zs=r[j]+zs;			
			ret.push_back(name+'_'+zs);
			
			for(j=i+1;j<nb;j++)
			if(r[j]=='"')break;
			
			zs="";
			
			for(j=j+1;j<nb && r[j]!='"';j++)
				zs=zs+r[j];
				
			
			
			
			ret.push_back(zs);
		}		
		
		
		while(1)
		{
			ra=rb+1;
			for(;ra<nb && r[ra]!='<';ra++);
			if(ra>=nb)break;
		
			rb=XML_f[ra];
					
			
			XML_run(agent_pi,r,ra,rb+1,name,ret);
		}
	}
	
	

	void XML_to_vector(int agent_pi,char r[],int rn,vector<string> &ret)
	{
		//log[agent_pi].writeln("----------- XML To_vector(char r[],vector<string> &ret,int tmp[])" 1);
		ret.clear();
		
		int i;				
		int na=0;
		int nb=rn;
		XML_delete_between(r,'?',na,nb);		
		
		XML_delete_empty_pair(r,'<','>');
		
		
		for(i=na;i<nb;i++)
			XML_f[i]=0;	
		
		XML_calc_f(r,nb);
		
		XML_run(agent_pi,r,na,nb,"",ret);
//		ret.clear();
//		To_vector(ret);
		//log[agent_pi].writeln("----------- XML To_vector(char r[],vector<string> &ret,int tmp[])" 2);
	}
	


///n




void Node_set_value(int x,int y)
	{		
		#if error_on
		if(node_is_probed[x])
			Error("493u0jyuytw3yh345y");
		#endif
		
		Memory_node_value(x,y);
		
		node_is_probed[x]=1;
		node_value[x]=y;		
	}	
	
void Node_set_value_without_memory(int x,int y)
	{		
		#if error_on
		if(node_is_probed[x])
			Error("493u0jyuytw3yh345y");
		#endif
				
		node_is_probed[x]=1;
		node_value[x]=y;		
	}	
	
void Node_set_is_surveyed(int x)
{
	if(node_is_surveyed[x])
		return;
	
	Memory_node_surveyed(x);
	
	node_is_surveyed[x]=1;	
}

void Node_set_is_surveyed_without_memory(int x)
{
	if(node_is_surveyed[x])
		return;
	
	node_is_surveyed[x]=1;	
}

void Node_init(int x)
	{
		node_edge_n[x]=0;
		node_edge[x].resize(1);
		node_edge_is_surveyed[x].resize(1);
		node_edge_value[x].resize(1);
		
		node_is_probed[x]=0;
		node_value[x]=1;
		node_visited[x]=0;
		node_is_surveyed[x]=0;
	}
	
bool Node_have_edge(int x,int b)
	{
		int i;
		for(i=1;i<=node_edge_n[x];i++)
		if(node_edge[x][i]==b)
			return 1;
	
		return 0;
	}
	
int Node_add_edge(int x,int b)
	{
		if(Node_have_edge(x,b))return 0;		
		
		
		if(x<b)
			edge_n++;
			
		node_edge_n[x]++;
		node_edge[x].push_back(b);
		
		
		
		node_edge_is_surveyed[x].push_back(0);
		node_edge_value[x].push_back(-1);
		return 1;
	}

bool Node_all_edge_is_surveyed(int x)
{
	int i;
	for(i=1;i<=node_edge_n[x];i++)
	if(!node_edge_is_surveyed[x][i])
		return 0;
	return 1;
}

bool Node_edge_is_surveyed(int x,int b)
	{	
		int z=0,i;
		for(i=1;i<=node_edge_n[x];i++)
		if(node_edge[x][i]==b)
		{
			z=i;
			break;
		}
		
		if(!z)return 0;
		if(!node_edge_is_surveyed[x][z])return 0;
		return 1;
	}
	
	
void Node_add_surveyed_edge(int x,int b,int d)
	{			
		#if error_on
		if(!Node_have_edge(x,b))
		{
			Error("09it409juj;oiser");
		}
		#endif
		
		int i,z=0;
		
		for(i=1;i<=node_edge_n[x];i++)
		if(node_edge[x][i]==b)
		{
			z=i;
			break;
		}
		
		#if error_on
		if(!z)Error("09it409juj;oiser");
		#endif
		
		if(node_edge_is_surveyed[x][z])
		{
			#if error_on
			if(node_edge_value[x][z]<0)Error("8349y4qy");
			if(node_edge_value[x][z]!=d)Error("hifg9u8348");
			#endif
			
			return;
		}
		
		if(x<b)
			Memory_node_edge(x,b,d);
		
		node_edge_is_surveyed[x][z]=1;
		node_edge_value[x][z]=d;
	}

void Node_add_surveyed_edge_without_memory(int x,int b,int d)
	{			
		#if error_on
		if(!Node_have_edge(x,b))
		{
			Error("09it409juj;oiser");
		}
		#endif
		
		int i,z=0;
		
		for(i=1;i<=node_edge_n[x];i++)
		if(node_edge[x][i]==b)
		{
			z=i;
			break;
		}
		
		#if error_on
		if(!z)Error("09it409juj;oiser");
		#endif
		
		if(node_edge_is_surveyed[x][z])
		{
			#if error_on
			if(node_edge_value[x][z]<0)Error("8349y4qy");
			if(node_edge_value[x][z]!=d)Error("hifg9u8348");
			#endif
			
			return;
		}
				
		node_edge_is_surveyed[x][z]=1;
		node_edge_value[x][z]=d;
	}









int Node_name_string_to_int(string& r)
{
	int n=r.length();
	int i;
	
	for(i=0;i<n;i++)
	if('0'<=r[i] && r[i]<='9')
	break;


	int z=0;
	for(;i<n;i++)
	{		
		#if error_on
		if(r[i]<'0' || r[i]>'9')
			Error("943ut9034u");
		#endif
		
		z=z*10+r[i]-'0';
	}

	z++;
	
	#if error_on
	if(z<1 || z>node_n)
		Error("jtr94843q9yhqy");
	#endif
	
	return z;
}




///e
//public
int enermy_attack_level[max_agent_n];

int enermy_perception_id[max_agent_n];
bool enermy_is_inspected[max_agent_n];
int enermy_inspect_time_id[max_agent_n];
string enermy_name[max_agent_n];
int enermy_energy[max_agent_n];
int enermy_health[max_agent_n];
int enermy_maxEnergy[max_agent_n];
int enermy_maxHealth[max_agent_n];
string enermy_role[max_agent_n];
int enermy_strength[max_agent_n];
string enermy_team[max_agent_n];
int enermy_visRange[max_agent_n];


///new
int enermy_inspect_wanted_by[max_agent_n];
int enermy_attack_wanted_by[max_agent_n];







//private
int enermy_killed_time[max_agent_n];
string enermy_node[max_agent_n];
string enermy_status[max_agent_n];
int enermy_status_time_id[max_agent_n];
int enermy_node_time_id[max_agent_n];




int enermy_last_time_perception_id[max_agent_n];
bool enermy_last_time_is_inspected[max_agent_n];
int enermy_last_time_inspect_time_id[max_agent_n];
string enermy_last_time_name[max_agent_n];
int enermy_last_time_energy[max_agent_n];
int enermy_last_time_health[max_agent_n];
int enermy_last_time_maxEnergy[max_agent_n];
int enermy_last_time_maxHealth[max_agent_n];
string enermy_last_time_role[max_agent_n];
int enermy_last_time_strength[max_agent_n];
string enermy_last_time_team[max_agent_n];
int enermy_last_time_visRange[max_agent_n];
int last_time_enermy_agent_n=0;

//new
int enermy_last_time_inspect_wanted_by[max_agent_n];


//private
string enermy_last_time_node[max_agent_n];
string enermy_last_time_status[max_agent_n];
int enermy_last_time_status_time_id[max_agent_n];
int enermy_last_time_node_time_id[max_agent_n];








///m


string agent_team;
string agent_name[max_agent_n];
string agent_password[max_agent_n];
string agent_ip;
int agent_port;

int agent_mission_destination[max_agent_n];
string agent_mission[max_agent_n];	
int agent_mission_param[max_agent_n];

int agent_perception_id[max_agent_n];

int agent_inspect_target_is[max_agent_n];
int agent_attack_target_is[max_agent_n];

string agent_role[max_agent_n];
string agent_position[max_agent_n];
int agent_position_int[max_agent_n];

int agent_step[max_agent_n];
int agent_energy[max_agent_n];
int agent_health[max_agent_n];


int agent_level[max_agent_n];
int agent_used_money[max_agent_n];
	
int agent_can_buy_battery[max_agent_n];
int agent_can_buy_sensor[max_agent_n];
int agent_can_buy_shield[max_agent_n];
int agent_can_buy_sabotageDevice[max_agent_n];



vector<int> agent_vertex_near[max_agent_n];


vector<int> agent_destination[max_agent_n];

int agent_max_energy[max_agent_n];
int agent_max_energy_disabled[max_agent_n];
int agent_max_health[max_agent_n];
int agent_strength[max_agent_n];
int agent_vis_range[max_agent_n];
int agent_zone_score[max_agent_n];
int agent_last_step_score[max_agent_n];
int agent_score[max_agent_n];
int agent_zones_score[max_agent_n];

int agent_auth_msg_n[max_agent_n];
char agent_auth_msg[max_agent_n][min_msg_length];
int agent_sim_msg_n[max_agent_n];
char agent_sim_msg[max_agent_n][min_msg_length];
int agent_buff_n[max_agent_n];
char agent_buff[max_agent_n][max_msg_length];
int agent_net_msg_n[max_agent_n];
char agent_net_msg[max_agent_n][max_msg_length];

int agent_no_action_count[max_agent_n];

string agent_last_action[max_agent_n];
string agent_last_action_param[max_agent_n];
string agent_last_action_result[max_agent_n];

int agent_simulation_step[max_agent_n];
int agent_team_last_step_score[max_agent_n];
int agent_team_money[max_agent_n];
int agent_team_score[max_agent_n];
int agent_team_zones_score[max_agent_n];
	
	int simulation_id;

	vector<string> visible_vertex_name;
	vector<string> visible_vertex_team;
	vector<string> visible_entity_name;
	vector<string> visible_entity_node;
	vector<string> visible_entity_status;
	vector<string> visible_entity_team;
		
	vector<string> visible_edge_node1;
	vector<string> visible_edge_node2;	
	vector<string> achievement_name;
	vector<string> probed_vertex_name;
	vector<int> probed_bertex_value;
	vector<int> surveyed_edge_node1;
	vector<int> surveyed_edge_node2;
	vector<int> surveyed_edge_weight;
	vector<int> inspected_entity_energy;
	vector<int> inspected_entity_health;
	vector<int> inspected_entity_max_energy;
	vector<int> inspected_entity_max_health;
	vector<string> inspected_entity_name;
	vector<string> inspected_entity_node;
	vector<string> inspected_entity_role;
	vector<int> inspected_entity_strength;
	vector<string> inspected_entity_team;
	vector<int> inspected_entity_vis_range;





int simulation_steps;
	


void Enermy_set_role(int x,string xs)
{
	#if error_on
	if(enermy_role[x]!="" && enermy_role[x]!=xs)
		Error("f843ut83yyhgj84y");
	#endif
	
	if(enermy_role[x]==xs)
		return;

	Memory_enermy_role(enermy_name[x],xs,enermy_node[x]);
	
	enermy_role[x]=xs;
	enermy_is_inspected[x]=1;
}




void Inspect_want(int agent_id,int enermy_id)
{
	agent_inspect_target_is[agent_id]=enermy_id;
	enermy_inspect_wanted_by[enermy_id]=agent_id;
}

void Attack_want(int agent_id,int enermy_id)
{
	agent_attack_target_is[agent_id]=enermy_id;
	enermy_attack_wanted_by[enermy_id]=agent_id;
}

int agent_repair_wanted_by[max_agent_n];
int agent_repair_target[max_agent_n];

void Repair_want(int repairer_id,int hurt_id)
{
	agent_repair_wanted_by[hurt_id]=repairer_id;
	agent_repair_target[repairer_id]=hurt_id;
}

void Repair_want_break_by_repairer(int repairer_id)
{
	int hurt_id=agent_repair_target[repairer_id];
	agent_repair_wanted_by[hurt_id]=-1;
	
	#if error_on
	if(hurt_id!=-1)
	if(hurt_id<0 || hurt_id>max_agent_n)
	{
		Error("F*(t438y98a3y");
	}
	#endif
	
	agent_repair_target[repairer_id]=-1;
}

void Attack_want_break_by_agent(int agent_id)
{
	int enermy_id=agent_attack_target_is[agent_id];
	enermy_attack_wanted_by[enermy_id]=-1;
	
	#if error_on
	if(enermy_id!=-1)
	if(enermy_id<0 || enermy_id>max_agent_n)
	{
		Error("j900ta9h05jw");
	}
	#endif
	
	agent_attack_target_is[agent_id]=-1;
}

void Inspect_want_break_by_agent(int agent_id)
{
	int enermy_id=agent_inspect_target_is[agent_id];
	enermy_inspect_wanted_by[enermy_id]=-1;
	
	#if error_on
	if(enermy_id!=-1)
	if(enermy_id<0 || enermy_id>max_agent_n)
	{
		Error("j900ta9h05jw");
	}
	#endif
	
	agent_inspect_target_is[agent_id]=-1;
}

/*
void Inspect_want_break_by_enermy(int enermy_id)
{
	int agent_id=enermy_inspect_wanted_by[enermy_id];
	enermy_inspect_wanted_by[enermy_id]=-1;
	
	#if error_on
	if(agent_id!=-1)
	if(agent_id<0 || agent_id>max_agent_n)
	{
		Error("j900ta9h05jw");
	}
	#endif
	
	agent_inspect_target_is[agent_id]=-1;
}
*/





void Last_time_enermy_update()
{
	int i;	
	for(i=0;i<enermy_n;i++)
	{
		enermy_last_time_perception_id[i]=enermy_perception_id[i];
		enermy_last_time_is_inspected[i]=enermy_is_inspected[i];
		enermy_last_time_inspect_time_id[i]=enermy_inspect_time_id[i];
		enermy_last_time_name[i]=enermy_name[i];
		enermy_last_time_energy[i]=enermy_energy[i];
		enermy_last_time_health[i]=enermy_health[i];
		enermy_last_time_maxEnergy[i]=enermy_maxEnergy[i];
		enermy_last_time_maxHealth[i]=enermy_maxHealth[i];
		enermy_last_time_role[i]=enermy_role[i];
		enermy_last_time_strength[i]=enermy_strength[i];
		enermy_last_time_team[i]=enermy_team[i];
		enermy_last_time_visRange[i]=enermy_visRange[i];

		enermy_last_time_node[i]=enermy_node[i];
		enermy_last_time_status[i]=enermy_status[i];
		enermy_last_time_status_time_id[i]=enermy_status_time_id[i];
		enermy_last_time_node_time_id[i]=enermy_node_time_id[i];
		
		enermy_last_time_inspect_wanted_by[i]=enermy_inspect_wanted_by[i];
	}
	
	last_time_enermy_agent_n=enermy_n;
}




void Enermy_update_node(int x,string a,int b)
{
	enermy_node[x]=a;
	enermy_node_time_id[x]=b;
}


void Enermy_update_status(int x,string a,int b)
{
	if(enermy_status[x]==string_normal && a==string_disabled)
		enermy_killed_time[x]=b;
		
	enermy_status[x]=a;
	enermy_status_time_id[x]=b;
}
	
bool Enermy_node_is(int x,string a,int b)
{
	return enermy_node[x]==a && enermy_node_time_id[x]==b;
}
	
bool Enermy_status_is(int x,string a,int b)
{/*
	if(x<0 || x>=enermy_n)
	{		
		cout<<"Esi "<<x<<' '<<a<<' '<<b<<endl;
		cout<<enermy_status[x]<<endl;
		Error("fgji4gj043yu");	
	}*/
	return enermy_status[x]==a && enermy_status_time_id[x]==b;
}
	
	
bool Enermy_get_node(int x,string &a,int b)
{
	if(b!=enermy_node_time_id[x])return 0;
	a=enermy_node[x];
	return 1;
}
	
bool Enermy_last_known_position(int x,string &ret)
{
	if(enermy_node[x]=="")return 0;
	ret=enermy_node[x];		
	return 1;
}
	
bool Enermy_last_known_status_is(int x,string a)
{
	return enermy_status[x]==a;
}

	
void Enermy_init(int x)
{
	enermy_is_inspected[x]=0;
	enermy_role[x]="";
	enermy_node[x]="";
	enermy_status[x]="";
	enermy_inspect_time_id[x]=enermy_status_time_id[x]=enermy_node_time_id[x]=-1;
	
	enermy_inspect_wanted_by[x]=-1;
	enermy_attack_wanted_by[x]=-1;	
	
	enermy_killed_time[x]=-1;
}	
	


string enermy_team_name="";

	int Enermy_string_to_int(string r)
	{
		int ret=0;
		int n=r.length();
		int i;
		
		enermy_team_name="";
		
		for(i=0;i<n;i++)
		if(r[i]>='0' && r[i]<='9')
			break;
		else
			enermy_team_name+=r[i];
		
		for(;i<n;i++)
			ret=ret*10+r[i]-'0';
			
		return ret-1;
	}
	
	string Enermy_int_to_string(int r)
	{
		#if error_on
		if(r<0 || r>=enermy_n)
			Error("9gfj094uy89hyq");
		#endif
		
		r++;
		
		string ret="";
		while(r)
		{
			ret=char(r%10+'0')+ret;
			r/=10;
		}		
		return enermy_team_name+ret;
	}
	



void Enermy_set_role_without_memory(string sa,string xs,string sc)
{
	int x=Enermy_string_to_int(sa);
	
	if(enermy_role[x]==xs)
		return;
	enermy_role[x]=xs;
	enermy_node[x]=sc;
	enermy_is_inspected[x]=1;	
}











int dijkstra_value[max_node_n];
int dijkstra_mk[max_node_n];
int dijkstra_ps[max_node_n];
int dijkstra_heap[max_node_n];
int dijkstra_fa[max_node_n];


void Dijkstra_update(int r)
	{
		int q=dijkstra_ps [ r ] , p=q>>1;
		while ( p && dijkstra_value[dijkstra_heap[p]] > dijkstra_value[r] ) 
		{
			dijkstra_ps[dijkstra_heap[p]]=q; 
			dijkstra_heap[q]=dijkstra_heap[p];
			q=p;
			p=q>>1;
		}
		dijkstra_heap[q]=r; 
		dijkstra_ps[r]=q;
	}

	int Dijkstra_getmin(int &len)
	{
		int ret=dijkstra_heap[1],p=1,q=2,r=dijkstra_heap[len--];
		while(q<=len) 
		{
			if(q<len && dijkstra_value[dijkstra_heap[q+1]] < dijkstra_value[dijkstra_heap[q]])q++;
			if(dijkstra_value[dijkstra_heap[q]]<dijkstra_value[r]) 
			{
				dijkstra_ps[dijkstra_heap[q]]=p; 
				dijkstra_heap[p]=dijkstra_heap[q];
				p=q; 
				q=p<<1;
			}
			else break;
		}
		dijkstra_heap[p]=r; 
		dijkstra_ps[r]=p;
		return ret;
	}	

	vector<int> Dijkstra_run(int src,int energy)
	{
		vector<int> ret;
		ret.clear();
		
		int n=node_n;		
		int num,len;
		int i,j,u,v,w,flag;
		
		energy/=2;
		
		flag=0;
		for(i=1;i<=n;i++)
		if(node_bound[i]==1)
		{
			flag=1;
			break;
		}
		if(!flag)
		{
			ret.clear();
			return ret;
		}
		
		if(node_bound[src]==1)
		{
			return ret;		
		}
		
		for(i=1;i<=n;i++) 
		{
			dijkstra_value[i]=oo; 
			dijkstra_mk[i]=0;
			dijkstra_ps[i]=0;
		}
		dijkstra_value[src]=0; 
		dijkstra_heap[len=1]=src; 
		dijkstra_ps[src]=1;
		dijkstra_fa[src]=0;
		
		while(1) 
		{
			if(len==0)return ret;
			u=Dijkstra_getmin(len); 
			dijkstra_mk[u]=1;
			
			if(node_bound[u]==1)
			{
				ret.clear();
				
				while(u && u!=src)
				{
					ret.push_back(u);
					u=dijkstra_fa[u];					
				}
				return ret;
			}
			
			for(j=1;j<=node_edge_n[u];j++) 
			{
				v=node_edge[u][j]; 
				w=node_edge_value[u][j];
				
				if(!dijkstra_mk[v] && node_bound[v]!=-1 && dijkstra_value[u]+w+energy < dijkstra_value[v]) 
				{
					if(dijkstra_ps[v]==0)
					{
						dijkstra_heap[++len]=v; 
						dijkstra_ps[v]=len; 
					}
					dijkstra_value[v]=dijkstra_value[u]+w+energy;; 
					dijkstra_fa[v]=u;
					Dijkstra_update(v);
				}
			}
		}
		return ret;
	}

	void Dijkstra_run_calc_value_for_agent(int src,int agent_i,int energy)
	{
		int num,len;
		int n=node_n;
		
		energy/=2;
		
		int i,j,u,v,w,flag;
		for(i=1;i<=n;i++)
			node_value_for_agent[i][agent_i]=oo;
				
		
		for(i=1;i<=n;i++) 
		{
			dijkstra_value[i]=oo; 
			dijkstra_mk[i]=0;
			dijkstra_ps[i]=0;
			dijkstra_fa[i]=0;
		}
		dijkstra_value[src]=0; 
		dijkstra_heap[len=1]=src; 
		dijkstra_ps[src]=1;
		dijkstra_fa[src]=0;
		
		while(1) 
		{
			if(len==0)break;
			u=Dijkstra_getmin(len); 
			dijkstra_mk[u]=1;
		
			for(j=1;j<=node_edge_n[u];j++) 
			{
				v=node_edge[u][j]; 
				w=node_edge_value[u][j];
				//if(!node[u].is_surveyed)
				//	continue;
				
				
				if(!dijkstra_mk[v] && dijkstra_value[u]+w+energy < dijkstra_value[v]) 
				{
					dijkstra_value[v]=dijkstra_value[u]+w+energy; 
			
					
					if(node_bound[v]==-1)continue;
					
					if(dijkstra_ps[v]==0)
					{
						dijkstra_heap[++len]=v; 
						dijkstra_ps[v]=len; 
					}
					
					dijkstra_fa[v]=u;
					Dijkstra_update(v);
				}
			}
		}
		
		for(i=1;i<=n;i++)
			node_value_for_agent[i][agent_i]=dijkstra_value[i];
			
	}


int MM_nx,MM_ny;
vector<int> MM_g[max_node_n];
int MM_sy[max_node_n];
int MM_cx[max_node_n];
int MM_cy[max_node_n];

int MM_path(int u)
{
	int v,i;
	for(i=0;i<MM_g[u].size();i++)
	{
		v=MM_g[u][i];
		if(!MM_sy[v])
		{
			MM_sy[v]=1;
			if(!MM_cy[v] || MM_path(MM_cy[v]))
			{
				MM_cx[u]=v;
				MM_cy[v]=u;
				return 1;
			}
		}
	}
	return 0;
}

int MCPM_pan(vector<int> agent_i,int limit)
{
	int i,j,z,ret=0;
	
	MM_nx=agent_i.size();
	MM_ny=node_n;
	
	for(i=0;i<=MM_nx;i++)
		MM_cx[i]=0;
	
	for(i=0;i<=MM_ny;i++)
		MM_cy[i]=0;
	
	for(i=1;i<=MM_nx;i++)
		MM_g[i].clear();
		
	for(i=1;i<=MM_nx;i++)
	for(j=1;j<=MM_ny;j++)
	{
		z=node_value_for_agent[j][agent_i[i-1]];
		if(z<=limit)
		{
		//	cout<<"p "<<i<<' '<<j<<' '<<z<<' '<<limit<<endl;
			MM_g[i].push_back(j);			
		}
	}
	
	for(i=1;i<=MM_nx;i++)
	if(!MM_cx[i])
	{
		for(j=0;j<=MM_ny;j++)
			MM_sy[j]=0;
		ret+=MM_path(i);
	}
	
	return ret;
}

void MM_run(vector<int> agent_i,vector<int>& ret)
{	
	int a,b,c;
	int i,j;
	int nx,ny;
	int z;
	
	a=oo;
	c=-oo;
	
	nx=agent_i.size();
	ny=node_n;
	
	for(i=0;i<nx;i++)
	for(j=1;j<=ny;j++)
	{
		z=node_value_for_agent[j][agent_i[i]];
		if(z<oo)
		{
			a=min(a,z);
			c=max(c,z);
		}
	}
	
	a--;
	
	int mm=MCPM_pan(agent_i,c);
	//cout<<"MM "<<agent_i.size()<<endl;
	//cout<<mm<<endl;
	
	while(a+1<c)
	{		
		b=(a+c)/2;
		
	//	cout<<a<<' '<<b<<' '<<c<<endl;
		
		if(MCPM_pan(agent_i,b)==mm)
			c=b;
		else
			a=b;
	}
	
	z=MCPM_pan(agent_i,c);
//	cout<<"c "<<c<<endl;
//	cout<<z<<endl;
	
	
	ret.clear();
	for(i=0;i<agent_i.size();i++)
	if(MM_cx[i+1])
	{
		ret.push_back(MM_cx[i+1]);
	}
	else
	{
		int da=-1,dj=0;
		for(j=1;j<=node_n;j++)
		{
			z=node_value_for_agent[j][agent_i[i]];
			if(z>=oo)	
				continue;
			
			if(da>=0 && da>z)
				continue;
			
			da=z;
			dj=j;
		}
		
		ret.push_back(dj);
	}	
	
	
	
	#if error_on
	if(agent_i.size()!=ret.size())
		Error("fggj034yuqy");
	
	for(j=0;j<ret.size();j++)
	if(ret[j]==-1)
	{
		Error("0r9t439uqyj4");
	}
	#endif
	
	
	
	
	
//	for(i=0;i<ret.size();i++)
//	cout<<"i "<<i<<' '<<agent_i[i]<<' '<<ret[i]<<' '<<node_value_for_agent[ret[i]][agent_i[i]]<<endl;
//	cout<<"////////////////////"<<endl;
	//Error("jvjjr0hu");
	
	return;
	
	
	
	
}

void Maximum_cost_perfect_matching(vector<int> agent_i,vector<int> &ret)
{
	int nx , ny , match;
	int i,j;
	int z;
	
	
	nx=node_n;
	ny=agent_i.size();
		
	ret.resize(ny);
		
	for(i=1;i<=nx;i++)
		node_v[i]=0;
			
	for(j=0;j<ny;j++)
		ret[j]=-1;
		/*
		for(j=0;j<ny;j++)
		{
			for(i=1;i<=nx;i++)
			if(!node_v[i] && node_value_for_agent[i][agent_i[j]]==0)
			if(ret[j]<0)
			{
				ret[j]=i;
				break;
			}
			if(ret[j]>=0)
			{
				node_v[ret[j]]=1;				
			}
		}
		
		for(i=0;i<ny;i++)
		for(j=i+1;j<ny;j++)
		if(ret[i]>=0 && ret[i]==ret[j])
		{
			#if error_on
			Error("89u43gw");
			#endif
		}*/	
		
		
	for(j=0;j<ny;j++)
	if(ret[j]<0)
	{
		for(i=1;i<=nx;i++)
		if(!node_v[i] && node_value_for_agent[i][agent_i[j]]<oo)
		{
			if(ret[j]<0 || node_value_for_agent[i][agent_i[j]]<node_value_for_agent[ret[j]][agent_i[j]])
				ret[j]=i;
		}
				
		if(ret[j]>=0)
		{
			node_v[ret[j]]=1;				
		}
		else
		{			
			for(i=1;i<=nx;i++)
			if(node_value_for_agent[i][agent_i[j]]<oo)
			if(ret[j]<0 || node_value_for_agent[i][agent_i[j]]<node_value_for_agent[ret[j]][agent_i[j]])
				ret[j]=i;
		}
	}
		
		/*for(j=0;j<ny;j++)
		{
			int s=0;
			for(i=1;i<=nx;i++)
			if(node_value_for_agent[i][agent_i[j]]<oo)s++;
		}*/
		
	#if error_on
	for(j=0;j<ny;j++)
	if(ret[j]==-1)
	{
		Error("0r9t439uqyj4");
	}
	#endif
				
		/*cx.resize(nx+1);
		cy.resize(ny+1);
		sx.resize(nx+1);
		sy.resize(ny+1);
		lx.resize(nx+1);
		ly.resize(ny+1);
		KuhnMunkres(agent_i,node);*/
}



void Maximum_cost_perfect_matching_agent_can_void(vector<int> agent_i,vector<int> &ret)
{
	int nx , ny , match;
	int i,j;
	nx=node_n;
	ny=agent_i.size();
		
	ret.resize(ny);
		
	for(i=1;i<=nx;i++)
		node_v[i]=0;
			
	for(j=0;j<ny;j++)
		ret[j]=-1;
		/*
		for(j=0;j<ny;j++)
		{
			for(i=1;i<=nx;i++)
			if(!node_v[i] && node_value_for_agent[i][agent_i[j]]==0)
			if(ret[j]<0)
			{
				ret[j]=i;
				break;
			}
			if(ret[j]>=0)
			{
				node_v[ret[j]]=1;				
			}
		}
		
		for(i=0;i<ny;i++)
		for(j=i+1;j<ny;j++)
		if(ret[i]>=0 && ret[i]==ret[j])
		{
			#if error_on
			Error("89u43gw");
			#endif
		}*/
		
		
		
	for(j=0;j<ny;j++)
	if(ret[j]<0)
	{
		for(i=1;i<=nx;i++)
		if(!node_v[i] && node_value_for_agent[i][agent_i[j]]<oo)
		{
			if(ret[j]<0 || node_value_for_agent[i][agent_i[j]]<node_value_for_agent[ret[j]][agent_i[j]])
				ret[j]=i;
		}
				
		if(ret[j]>=0)
		{
			node_v[ret[j]]=1;				
		}
	}
	
	int s=0;
	for(j=0;j<ny;j++)
	if(ret[j]!=-1)
		s++;
	
	#if error_on
	if(!s)
		Error("9340jgahg34hg");
	#endif
				
		/*cx.resize(nx+1);
		cy.resize(ny+1);
		sx.resize(nx+1);
		sy.resize(ny+1);
		lx.resize(nx+1);
		ly.resize(ny+1);
		KuhnMunkres(agent_i,node);*/
}








int bfs_value[max_node_n];
int bfs_heap[max_node_n];
int bfs_fa[max_node_n];
///b
	vector<int> Bfs_run(int src)
	{
		
		vector<int> ret;
		ret.clear();
		int n=node_n;
				
		int i,j,a,b,z,w,flag;
		
		flag=0;
		for(i=1;i<=n;i++)
		if(node_bound[i]==1)
		{
			flag=1;
			break;
		}
		if(!flag)
		{
			ret.clear();
			return ret;
		}

		
		queue<int> q;
		while(q.size())q.pop();
		
		
		for(i=1;i<=n;i++)
		{
			node_dis[i]=-1;
			node_v[i]=0;
			bfs_fa[i]=-1;
		}
		
		
		node_v[src]=1;
		q.push(src);
		node_dis[src]=0;
		bfs_fa[src]=0;
		
		while(q.size())
		{
			a=q.front();
			q.pop();
			for(i=1;i<=node_edge_n[a];i++)
			{
				b=node_edge[a][i];
				if(node_v[b])continue;
				
				if(node_dis[b]!=-1 && node_dis[b]<=node_dis[a]+1)continue;
				node_dis[b]=node_dis[a]+1;
				node_v[b]=1;
				bfs_fa[b]=a;
				if(node_bound[b]==1)continue;
				q.push(b);
			}			
		}
		
		z=-1;
		for(i=1;i<=n;i++)
		if(node_bound[i]==1 && node_v[i])
		if(z<0 || node_dis[i]<node_dis[z])z=i;
		
		if(node_dis[z]<0)
		{
			ret.clear();
			return ret;
		}
		
		#if error_on		
		if(node_dis[z]<0)Error("8yu95oihyayha");
		#endif
		
		while(z && z!=src)
		{
			ret.push_back(z);
			z=bfs_fa[z];					
		}
		
		return ret;
	}



///k2
/*
int k2_v[max_node_n];
int k2_in[max_agent_n];
int k2_in_n;

void K2_update_value(int x)
{
	if(k2_v[x])
		return;

	for(i=1;i<=node_edge_n[x];i++)
	{
		a=node_edge[x][i];
		for(j=1;j<=node_edge_n[a];j++)
		{
			b=node_edge[a][j];
			if(b==x)
				return;
			
			if(
		}
	}
}

vector<int> node_near_2[max_node_n];

void K2_value(int a,int b)
{
	int ret=k2_value[a]+k2_value[b];
	
	for
}

void Node_near_2(int root,int x,int deep)
{
	int i,z;
	
	for(i=0;i<node_near_2[root].size();i++)
	if(node_near_2[root][i]==x)
		return;
		
	node_near[root].push_back(x);
	
	if(deep<2)
	for(i=1;i<=node_edge_n[x];i++)
	{
		z=node_edge[x][i];
		Node_near_2(root,z,deep+1);
	}
	
	for(i=1;i<=node_n;i++)
	for(j=0;j<node_near_2[i].size();j++)
	{
		a=i;
		b=node_near_2[i][j];
		
		K2_value(a,b);
	}
}

void K2_run()
{
	for(i=1;i<=n;i++)
		Node_near_2(i,i,0);

	for(i=1;i<=n;i++)
		k2_v[i]=0;
	k2_in_n=0;
	
	for(i=1;i<=n;i++)
		k2_value[i]=node_value[i];	
	
	for(i=1;i<=n;i++)
	
}
*/


///k



int kuo_d_n[max_kuo_area_n];
int kuo_d_da[max_kuo_area_n][max_node_n];
int kuo_d_root[max_kuo_area_n][max_node_n];
vector<int> kuo_d_d[max_kuo_area_n][max_node_n];
vector<int> kuo_d_inside_node[max_kuo_area_n][max_node_n];
int kuo_start[max_kuo_area_n];
int kuo_last_best_root[max_kuo_area_n];



void Kuo_d_st(int A,int x)
	{
		kuo_d_da[A][x]=-1;
		kuo_d_root[A][x]=-1;
		kuo_d_d[A][x].clear();
		kuo_d_inside_node[A][x].clear();
	}	
	
void Kuo_d_write(int A,int x)
	{	
		int i;
		cout<<kuo_d_d[A][x].size()<<' '<<kuo_d_root[A][x]<<' '<<kuo_d_da[A][x]<<endl;
		cout<<"    ";
		for(i=0;i<kuo_d_d[A][x].size();i++)
			cout<<node_name_int_to_string[ kuo_d_d[A][x][i] ]<<' ';
		cout<<endl;
	}
	
void Kuo_d_update(int A,int x,vector<int> &xr,int sd,int x_root,vector<int>& inside_node)
	{
		int i;
		
		#if error_on
		if(x==0)
			Error("rj943tu8304yuh");
		#endif
		
		if(kuo_d_n[A]<x)
			kuo_d_n[A]=x;
		
		if(sd>kuo_d_da[A][x])
		{
			kuo_d_da[A][x]=sd;
			kuo_d_d[A][x]=xr;
			kuo_d_root[A][x]=x_root;			
			kuo_d_inside_node[A][x]=inside_node;
		}		
	}










///private

void Kuo_del(int A,int x,int &sn,int &sd,int &sb,vector<int>& inside_node)
	{
		int i,j,z;
		int flag;
		int n=node_n;
		
		for(i=1;i<=node_edge_n[x];i++)
		{
			z=node_edge[x][i];
			
			#if error_on
			if(node_ev[z])
				Error("mnfg9384yuqw9yu4");
			#endif
			
			if(node_v[z])
				continue;
			sn++;
			sd+=node_value[z];
			node_v[z]=1;
		}
		node_v[x]=2;
		inside_node.push_back(x);
		
			
		for(i=1;i<=n;i++)
		if(node_v[i]==1)
		{
			flag=0;
			for(j=1;j<=node_edge_n[i];j++)
			{
				z=node_edge[i][j];
				if(node_v[z])
					continue;
				flag=1;
				break;
			}						
			if(!flag)
			{
				node_v[i]=2;
				inside_node.push_back(i);
			}
		}
		
		sb=0;
		for(i=1;i<=n;i++)
		if(node_v[i]==1 || node_v[i]==3)
			sb++;
	}

void Kuo_add(int A,int x,int &sn,int &sd,int &sb,vector<int>& inside_node)
	{
		int i,j,z;
		int flag;
		int n=node_n;
		
		for(i=1;i<=node_edge_n[x];i++)
		{
			z=node_edge[x][i];
			if(node_ev[z])
				continue;
			if(node_v[z])
				continue;
			sn++;
			sd+=node_value[z];
			node_v[z]=1;
		}
		
		node_v[x]=3;
	
		for(i=1;i<=n;i++)
		if(node_v[i]==1)
		{
			flag=0;
			for(j=1;j<=node_edge_n[i];j++)
			{
				z=node_edge[i][j];
				if(node_v[z])
					continue;
				flag=1;
				break;
			}
			
			if(!flag)
			{
				node_v[i]=2;
				inside_node.push_back(i);
			}
		}
		
		sb=0;
		for(i=1;i<=n;i++)
		if(node_v[i]==1 || node_v[i]==3)
			sb++;
	}

void Kuo_fu_gai(int A,int x)
	{
		int i;
		node_fu_gai[x]++;
		for(i=1;i<=node_edge_n[x];i++)
		node_fu_gai[node_edge[x][i]]++;
	}
	
	void Kuo_del_da(int x)
	{
		int i;
		int z;
		string zs;
		
		if(node_fu_gai[x]-1<2)return;
		for(i=1;i<=node_edge_n[x];i++)
		if(node_v[node_edge[x][i]]==1 || node_v[node_edge[x][i]]==3)
		if(node_can_kuo[node_edge[x][i]] && !node_yao[node_edge[x][i]] && node_fu_gai[node_edge[x][i]]-1<2)return;
		
		#if error_on
		for(i=1;i<=node_edge_n[x];i++)
		if(node_ev[node_edge[x][i]]==1)
		{			
			Error("t430auyah");
		}
		#endif
		
		node_fu_gai[x]--;
		for(i=1;i<=node_edge_n[x];i++)
		node_fu_gai[node_edge[x][i]]--;
		node_yao[x]=0;
	}

void Kuo_update_da(int A,int sd,int x,vector<int>& inside_node)
	{
		int i;
		int n=node_n;
		int kong=0;
		vector<int> d;
		d.clear();
		int start;
		
		for(i=1;i<=n;i++)
		{
			node_fu_gai[i]=0;
			node_yao[i]=0;
		}
		
		///z
		
		
		if(kuo01)
		{
			for(i=1;i<=n;i++)
			if(node_v[i]==1 || node_v[i]==3)
			if(!node_can_kuo[i])
			{
			//	d.push_back(i);
				Kuo_fu_gai(A,i);
				node_yao[i]=1;
			}
		
			for(i=1;i<=n;i++)
			if(node_v[i]==1 || node_v[i]==3)
			if(node_can_kuo[i])
				if(node_fu_gai[i]<2)
				{
				//	d.push_back(i);
					Kuo_fu_gai(A,i);
					node_yao[i]=1;
				}
			
			for(i=1;i<=n;i++)
			if(node_v[i]==1 || node_v[i]==3)
			if(node_can_kuo[i] && node_yao[i])
				Kuo_del_da(i);			
		}
		else
		{
			for(i=1;i<=n;i++)
			if(node_v[i]==1 || node_v[i]==3)
				node_yao[i]=1;
		
		}
		
		for(i=1;i<=n;i++)
		if(node_yao[i])d.push_back(i);
		
		#if error_on
		if(!d.size())
			Error("3u4jy4ah4y");
		#endif
		
		Kuo_d_update(A,d.size(),d,sd,x,inside_node);
		 
	/*	
		if(sd>da)
		{
			da=sd;
			d.clear();
			for(i=1;i<=n;i++)
			if(node_v[i]==1 || node_v[i]==3)
				Add(i);
			root=x;
		}	*/	
	}


void Kuo_xkuo(int A,int x)
	{
		int i,j,z;
		int sn,sd,sb;
		int flag;
		int n=node_n;
		vector<int> inside_node;
		inside_node.clear();	
	
		if(node_ev[x])return;
	
		for(i=1;i<=n;i++)
			node_v[i]=0;
	
		node_v[x]=1;	
		sn=1;
		sd=node_value[x];
		sb=1;
		Kuo_update_da(A,sd,x,inside_node);
	
		
		while(1)
		{
			if(sn >= kuo_max_nodes_rate*node_n)
				break;
		
			for(i=1;i<=n;i++)
				node_xu[i]=0;
		
			for(i=1;i<=n;i++)
			if(node_v[i]==1)
			{			
				for(j=1;j<=node_edge_n[i];j++)
				{
					z=node_edge[i][j];
					if(node_v[z] || node_ev[z])
						continue;
					node_xu[i]++;
				}
				if(node_xu[i] && !node_can_kuo[i])
					node_xu[i]++;			
			}
		
			z=-1;
			for(i=1;i<=n;i++)
			if(node_v[i]==1 && node_can_kuo[i])
			{
				if(z<0 || node_xu[i]<node_xu[z])z=i;				
			}
		
			if(z<0)
			{
				for(i=1;i<=n;i++)
				if(node_v[i]==1 && !node_can_kuo[i])
				if(node_xu[i])
				{
					if(z<0 || node_xu[i]<node_xu[z])z=i;				
				}
			}
		
			
			if(z<0)break;
			
			
			//if(x==kuo_d[0].root)
			#if error_on
			if(z>node_n)
				Error("wjgghjhaoirj");
			#endif
			
			//log->writeln(z);
		
			if(node_can_kuo[z])
				Kuo_del(A,z,sn,sd,sb,inside_node);	
			else
				Kuo_add(A,z,sn,sd,sb,inside_node);
			Kuo_update_da(A,sd,x,inside_node);				
		}
		//log->writeln("-----------xkuo 2");	
	}




///public






void Kuo_init(int A)
	{
		kuo_start[A]=1;
	}

void Kuo_write(int A)
	{	
		int i;
		for(i=1;i<=kuo_d_n[A];i++)
		{
			printf("n=%d\n",i);
				Kuo_d_write(A,i);
			puts("");
		}
	}


	
///k
void Kuo_run(int A,int max_use_agent)
	{
		int i,j;
		int B;
		string zs;
		int n=node_n;
		int z;
		
		int flag;
		
		
		
		kuo_last_best_root[A]=-1;		
		if(kuo_d_n[A] && kuo_d_da[A][0]>=0)
		{
			kuo_last_best_root[A]=kuo_d_root[A][0];
		}
		
		kuo_d_n[A]=0;
		Kuo_d_st(A,0);
			
		for(i=1;i<=n;i++)
		{
			//kuo_d[i].st();		
			node_ev[i]=1;
			node_can_kuo[i]=0;
		}
		
		for(i=1;i<=n;i++)
		if(node_is_surveyed[i])
		{
			node_can_kuo[i]=1;
			node_ev[i]=0;
		}
		
		flag=0;
		for(i=0;i<enermy_n;i++)
		{
			///z			
			if(Enermy_last_known_status_is(i,string_disabled))
				continue;
			if(!Enermy_last_known_position(i,zs))
				continue;
			z=Node_name_string_to_int(zs);
			node_ev[z]=1;
			
		//	cout<<i<<' '<<zs<<endl;
			
			flag=1;
		}
		
		if(!flag)
		{
			for(i=0;i<enermy_n;i++)
			{
				///z
				if(enermy_role[i]!=string_repairer)
					continue;
				if(!Enermy_last_known_position(i,zs))
					continue;
				z=Node_name_string_to_int(zs);
				node_ev[z]=1;
				flag=1;
			}
		}
		
		if(!flag)
		{
			for(i=0;i<enermy_n;i++)
			{
				if(!Enermy_last_known_position(i,zs))
					continue;
				z=Node_name_string_to_int(zs);
				node_ev[z]=1;
				flag=1;
			}
		}
		
		for(B=0;B<kuo_area_n;B++)
		if(B!=A && kuo_d_d[B][0].size())
		{
			for(i=0;i<kuo_d_d[B][0].size();i++)
			{
		//		cout<<"bound: "<<A<<' '<<B<<' '<<kuo_d_d[B][0][i]<<endl;
				node_ev[kuo_d_d[B][0][i]]=2;
			}
				
			for(i=0;i<kuo_d_inside_node[B][0].size();i++)
			{
		//		cout<<"inside: "<<A<<' '<<B<<' '<<kuo_d_inside_node[B][0][i]<<endl;
				node_ev[kuo_d_inside_node[B][0][i]]=2;			
			}
		}
		
		for(i=1;i<=n;i++)
		if(node_ev[i])
		{
			node_can_kuo[i]=0;
			for(j=1;j<=node_edge_n[i];j++)
			{
				node_can_kuo[node_edge[i][j]]=0;
			}			
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		if(kuo_last_best_root[A]>=1)
		{
			Kuo_xkuo(A,kuo_last_best_root[A]);
		}
		
		for(i=1;i<=kuo_step_add;i++)
		{
			Kuo_xkuo(A,kuo_start[A]);
			kuo_start[A]++;
			if(kuo_start[A]==n+1)
				kuo_start[A]=1;
		}
				
		z=-1;
		for(i=min(int(kuo_d_n[A]),max_use_agent);i>=3;i--)
		{					
			if(kuo_d_da[A][i]>=0)
			{
				z=i;
				break;
			}
		}
		
		if(z>=0)
		{			
			kuo_d_da[A][0]=kuo_d_da[A][z];
			kuo_d_root[A][0]=kuo_d_root[A][z];
			kuo_d_d[A][0]=kuo_d_d[A][z];
			kuo_d_inside_node[A][0]=kuo_d_inside_node[A][z];
		}
		
		for(i=1;i<=kuo_d_n[A];i++)
			Kuo_d_st(A,i);		
	}
	
	

///k













void Agent_can_visit_node(int x)
	{
		#if log_on
			log[x].writeln("Can_visit_node(vector<bool> &d) 1");
		#endif
		
		int i,j,k;
		int a,b;
		int n=node_n;
		for(i=0;i<=n;i++)
			node_can_visit[i][x]=0;
		
		queue<int> q;
		while(q.size())
			q.pop();
		
		q.push(agent_position_int[x]);
		node_can_visit[agent_position_int[x]][x]=1;
		
		while(q.size())
		{
			a=q.front();
			q.pop();
			for(i=1;i<=node_edge_n[a];i++)
			{
				b=node_edge[a][i];
				if(node_can_visit[b][x])continue;
				node_can_visit[b][x]=1;
				q.push(b);
			}
		}
		
		/*for(i=1;i<=n;i++)
		if(d[i])
		{
			log[agent_pi].write(i);
			log[agent_pi].write(" ");
			log[agent_pi].writeln(name.Int_to_string(i));
		}*/
		
		#if log_on
			log[x].writeln("Can_visit_node(vector<bool> &d) 2");
		#endif
	}




void Agent_can_visit_through_surveyed_node(int x)
	{
		#if log_on
			log[x].writeln("Can_visit_through_surveyed_node(vector<bool> &d) 1");
		#endif
		
		int i,j,k;
		int a,b;
		int n=node_n;
		for(i=0;i<=n;i++)
			node_can_visit_through_surveyed_node[i][x]=0;
		
		queue<int> q;
		while(q.size())
			q.pop();
		
		q.push(agent_position_int[x]);
		node_can_visit_through_surveyed_node[agent_position_int[x]][x]=1;
		
		
		
		while(q.size())
		{
			a=q.front();
			q.pop();
			for(i=1;i<=node_edge_n[a];i++)
			{
				b=node_edge[a][i];
				if(node_can_visit_through_surveyed_node[b][x])continue;				
				node_can_visit_through_surveyed_node[b][x]=1;
				if(!node_is_surveyed[b])continue;
				q.push(b);
			}
		}
		
		
		#if log_on
			log[x].writeln("Can_visit_through_surveyed_node(vector<bool> &d) 2");
		#endif
	}



int agent_have_auth_msg[max_agent_n];
int agent_have_sim_msg[max_agent_n];
int agent_net_msg_signal_ready[max_agent_n];
int agent_net_msg_signal_done[max_agent_n];
int agent_net_msg_signal_start[max_agent_n];

// 缓冲区相关数据结构
pthread_mutex_t agent_pr_lock[max_agent_n]; /* 互斥体lock 用于对缓冲区的互斥操作 */
pthread_cond_t agent_pr_net_msg_signal_start[max_agent_n];
int agent_pr_thread_start[max_agent_n];
	




///agent private
bool Agent_have_pain_in_the_ass(int agent_pi)
	{		
		return agent_health[agent_pi]<agent_max_health[agent_pi];
	}



vector<int> Agent_go_to_not_occupy_max_value_node(int agent_pi)
	{
		#if log_on
		log[agent_pi].writeln("------------------Agent_go_to_not_occupy_max_value_node(agent_pi) 1");
		#endif
		
		vector<int> ret;
		ret.clear();
		
		int i;
		int z;
		int flag;
		
		int n=node_n;
		for(i=1;i<=n;i++)
		{
			node_v[i]=0;
			node_bound[i]=0;
		}
		
		for(i=0;i<agent_n;i++)
		{
			if(i==agent_pi)
				continue;
			if((agent_health[i])==0)
				continue;
			node_v[agent_position_int[i]]=1;			
		}
		
		z=-1;
		for(i=1;i<=n;i++)
		if(!node_v[i])
		{
			if(z<0 || node_value[z]<node_value[i])
				z=i;
		}
		
		if(z<0)
		{
			#if log_on
			log[agent_pi].writeln("------------------Agent_go_to_not_occupy_max_value_node(agent_pi) 3");
			#endif
			
			return Vector_empty();
		}
			
		if(node_value[z]<=node_value[agent_position_int[agent_pi]])
		{
			flag=0;
			for(i=0;i<agent_n;i++)
			{
				if(i==agent_pi)
					continue;
				if(agent_health[i]==0)
					continue;
				if(agent_position_int[i]!=agent_position_int[agent_pi])
					continue;
				if(agent_level[i]>agent_level[agent_pi])
					continue;
					
				flag=1;
			}
			
			if(!flag)
			{
				#if log_on
				log[agent_pi].writeln("------------------Agent_go_to_not_occupy_max_value_node(agent_pi) 4");
				#endif
				return Vector_empty();
			}
		}
		
		
		for(i=1;i<=n;i++)
		if(!node_v[i] && node_value[i]==node_value[z])
			node_bound[i]=1;
		
		
		
		ret = Dijkstra_run(agent_position_int[agent_pi],agent_max_energy[agent_pi]);	
		
		
		#if log_on
		log[agent_pi].writeln(ret.size());
		#endif
		
		#if error_on
		if(ret.size()==0)
		{
			Error("jy0943uy45ae3aher");
		}
		#endif
		
		#if log_on
		log[agent_pi].writeln("------------------Agent_go_to_not_occupy_max_value_node(agent_pi) 2");
		#endif
		return ret;				
	}
	
	
	int Should_repair_friend(vector<int> &r)
	{
		int z=rand()%r.size();
		return r[z];
	}
	
	int Should_attack_enermy(vector<int> &r)
	{
		int z=rand()%r.size();
		return r[z];
	}
	
	bool We_know_all_saboteur()
	{
		int sa=0;
		int sb=0;
		int i;
		for(i=0;i<agent_n;i++)
		if(agent_role[i]==string_saboteur)
			sa++;
		for(i=0;i<enermy_n;i++)
		if(enermy_role[i]==string_saboteur)
			sb++;
			
		#if error_on
		if(sa<sb)
			Error("jgireyh9s8rhgas");
		#endif
		
		return sb==sa;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	bool Agent_can_buy(int agent_pi)
	{
		return agent_can_buy_battery[agent_pi] || agent_can_buy_sensor[agent_pi] ||	agent_can_buy_shield[agent_pi] ||	agent_can_buy_sabotageDevice[agent_pi];
	}
	
	bool Agent_I_am_not_use_max_money(int agent_pi)
	{
		#if log_on
		log[agent_pi].writeln("-------------- I_use_lowest_money() 1");
		#endif
		
		int a=oo;
		int b=0;
		int i;
		if(!Agent_can_buy(agent_pi))
		{
			#if log_on
			log[agent_pi].writeln("---------------- I can not buy");
			#endif
			return 0;
		}
				
		for(i=0;i<agent_n;i++)
		{
			if(!Agent_can_buy(i))
				continue;
			a=min(a,agent_used_money[i]);
			b=max(b,agent_used_money[i]);
		}
		
		#if log_on
		log[agent_pi].write("min used money = ");
		log[agent_pi].writeln(a);
		
		log[agent_pi].write("max used money = ");
		log[agent_pi].writeln(b);
		#endif
		
		if(a==agent_used_money[agent_pi])
			return 1;
		if(agent_used_money[agent_pi]<b)
			return 1;
		return 0;
	}
	
	

	void Agent_do_order(int agent_pi,vector<string> r)
	{
		if(r[0]==string_repair)
			Protocol_repair(agent_pi,r[1]);
		else if(r[0]==string_goto_)
			Protocol_goto(agent_pi,r[1]);
		else if(r[0]==string_attack)
			Protocol_attack(agent_pi,r[1]);
		else if(r[0]==string_survey)
			Protocol_survey(agent_pi);
		else if(r[0]==string_inspect)
			Protocol_inspect(agent_pi,r[1]);
		else if(r[0]==string_recharge)
			Protocol_recharge(agent_pi);
		else if(r[0]==string_probe)
			Protocol_probe(agent_pi);
		else if(r[0]==string_skip)
			Protocol_skip(agent_pi);
		#if error_on
		else
			Error("fjsiga9rgha");
		#endif
	}

	
	
	int Agent_get_infor(int agent_pi)
	{
		#if log_on
		log[agent_pi].writeln("---------------------Get_infor() 1");
		#endif
		
		string zs;
		vector<string> zv;
		int i,j;
		
		
		XML_to_vector(agent_pi,agent_net_msg[agent_pi],agent_net_msg_n[agent_pi],zv);
		
		
		#if log_on
		log[agent_pi].write("xml to vector size  = ");
		log[agent_pi].writeln(zv.size());
		#endif
		
		
		for(i=0;i<agent_net_msg_n[agent_pi];i++)
			agent_net_msg[agent_pi][i]=0;
		agent_net_msg_n[agent_pi]=0;
		
		#if error_on
		if(zv.size()%2)
			Error("aeyua84uya34");
		#endif
		
		for(i=0;i<zv.size();i+=2)
		{
			#if error_on
			if(i+1>=zv.size())
				Error("GJW94WJHw3943");
			#endif
				
			if(zv[i]==string_visibleVertex_name)
			{
				#if error_on
				if(agent_pi!=0)
					Error("jr90243ut0893qyhyh");
				#endif
				
				visible_vertex_name.push_back(zv[i+1]);
				continue;
			}
			
			if(zv[i]==string_visibleVertex_team)
			{
				#if error_on
				if(agent_pi!=0)
					Error("rj09u693uyyhjhja");
				#endif
				
				visible_vertex_team.push_back(zv[i+1]);
				continue;
			}
			
			if(zv[i]==string_visibleEdge_node1)
			{
				#if error_on
				if(Edge_all_see())
					Error("94ut834y3yhq");
				#endif
			
				visible_edge_node1.push_back(zv[i+1]);
				continue;
			}
			
			if(zv[i]==string_visibleEdge_node2)
			{
				#if error_on
				if(Edge_all_see())
					Error("j90t4wu54quq");
				#endif
					
				visible_edge_node2.push_back(zv[i+1]);
				continue;
			}
			
			
			
			
			
			
			
			
			
			
			
			
			if(zv[i]==string_message_timestamp) 
				continue;
						
			if(zv[i]==string_message_type) 
			{
				if(zv[i+1]==string_request_action)continue;
				
				if(zv[i+1]==string_sim_end)
				{
					sim_end=1;
					continue;
				}
				
				#if error_on
				Error("iga9834yu98qayu");
				#endif
				
				continue;
			}
			
			if(zv[i]==string_sim_result_ranking)
			{
				sim_result_ranking=String_string_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==string_sim_result_score)
			{
				sim_result_score=String_string_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==string_perception_deadline) 
			{				
				continue;
			}
						
			if(zv[i]==string_perception_id) 
			{
				agent_perception_id[agent_pi]=String_string_to_int(zv[i+1]);
				perception_id=max(perception_id,agent_perception_id[agent_pi]);
			//	net_file.Set_perception_id(perception_id);
				continue;
			}
			
			if(zv[i]==string_simulation_step) 
			{
				agent_simulation_step[agent_pi]=String_string_to_int(zv[i+1]);
				continue;
			}
							
			if(zv[i]==string_self_energy) 
			{
				agent_energy[agent_pi] = String_string_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==string_self_health) 
			{
				agent_health[agent_pi] = String_string_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==string_self_lastAction) 
			{
				agent_last_action[agent_pi] = zv[i+1];
				continue;
			}
			
			if(zv[i]==string_self_lastActionParam) 
			{
				agent_last_action_param[agent_pi] = zv[i+1];
				continue;
			}
			
			if(zv[i]==string_self_lastActionResult) 
			{
				agent_last_action_result[agent_pi] = zv[i+1];
				continue;
			}
			
			if(zv[i]==string_self_maxEnergy)
			{
				agent_max_energy[agent_pi] = String_string_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==string_self_maxEnergyDisabled)
			{
				agent_max_energy_disabled[agent_pi] = String_string_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==string_self_maxHealth)
			{
				agent_max_health[agent_pi] = String_string_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==string_self_position) 
			{				
				agent_position[agent_pi] = zv[i+1];
				agent_position_int[agent_pi]=Node_name_string_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==string_self_strength)
			{
				agent_strength[agent_pi] = String_string_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==string_self_visRange)
			{
				agent_vis_range[agent_pi] = String_string_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==string_self_zoneScore)
			{
				agent_zone_score[agent_pi] = String_string_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==string_team_lastStepScore)
			{
				agent_team_last_step_score[agent_pi] = String_string_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==string_team_money)
			{
				agent_team_money[agent_pi] = String_string_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==string_team_score)
			{
				agent_team_score[agent_pi] = String_string_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==string_team_zonesScore)
			{
				agent_team_zones_score[agent_pi] = String_string_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==string_achievement_name)
			{
				achievement_name.push_back(zv[i+1]);
				continue;
			}
			
			
			
			if(zv[i]==string_visibleEntity_name)
			{
				visible_entity_name.push_back(zv[i+1]);
				continue;
			}
			
			if(zv[i]==string_visibleEntity_team)
			{
				visible_entity_team.push_back(zv[i+1]);
				continue;
			}
			
			if(zv[i]==string_visibleEntity_node)
			{
				visible_entity_node.push_back(zv[i+1]);
				continue;
			}
			
			if(zv[i]==string_visibleEntity_status)
			{
				visible_entity_status.push_back(zv[i+1]);
				continue;
			}
						
			if(zv[i]==string_probedVertex_name)
			{				
				probed_vertex_name.push_back(zv[i+1]);
				continue;
			}
			
			if(zv[i]==string_probedVertex_value)
			{				
				probed_bertex_value.push_back(String_string_to_int(zv[i+1]));
				continue;
			}
			
			if(zv[i]==string_surveyedEdge_node1)
			{				
				surveyed_edge_node1.push_back(Node_name_string_to_int(zv[i+1]));
				continue;
			}
			
			if(zv[i]==string_surveyedEdge_node2)
			{			
				surveyed_edge_node2.push_back(Node_name_string_to_int(zv[i+1]));	
				continue;
			}
			
			if(zv[i]==string_surveyedEdge_weight)
			{			
				surveyed_edge_weight.push_back(String_string_to_int(zv[i+1]));	
				continue;
			}
			
			if(zv[i]==string_inspectedEntity_energy)
			{			
				inspected_entity_energy.push_back(String_string_to_int(zv[i+1]));	
				continue;
			}
			
			if(zv[i]==string_inspectedEntity_health)
			{			
				inspected_entity_health.push_back(String_string_to_int(zv[i+1]));	
				continue;
			}
			
			if(zv[i]==string_inspectedEntity_maxEnergy)
			{			
				inspected_entity_max_energy.push_back(String_string_to_int(zv[i+1]));	
				continue;
			}
			
			if(zv[i]==string_inspectedEntity_maxHealth)
			{			
				inspected_entity_max_health.push_back(String_string_to_int(zv[i+1]));	
				continue;
			}
			
			if(zv[i]==string_inspectedEntity_name)
			{			
				inspected_entity_name.push_back(zv[i+1]);	
				continue;
			}
			
			if(zv[i]==string_inspectedEntity_node)
			{			
				inspected_entity_node.push_back(zv[i+1]);	
				continue;
			}
			
			if(zv[i]==string_inspectedEntity_role)
			{			
				inspected_entity_role.push_back(zv[i+1]);	
				continue;
			}
			
			if(zv[i]==string_inspectedEntity_strength)
			{			
				inspected_entity_strength.push_back(String_string_to_int(zv[i+1]));	
				continue;
			}
			
			if(zv[i]==string_inspectedEntity_team)
			{			
				inspected_entity_team.push_back(zv[i+1]);	
				continue;
			}
			
			if(zv[i]==string_inspectedEntity_visRange)
			{			
				inspected_entity_vis_range.push_back(String_string_to_int(zv[i+1]));	
				continue;
			}
			
			#if error_on
			{
				Error("834uwy3haGHWOEha");
			}
			#endif
		}
		
		#if log_on
		log[agent_pi].writeln("---------------------Get_infor 2");
		#endif
	}
	
	
	
	
	
	
	
	/*
	int Friend_hear_has_pain_in_the_ass(string &ret)
	{
		#if log_on
			log[agent_pi].writeln("Friend_hear_has_pain_in_the_ass() 1");
		#endif
	
		int i,z;
		string zs;
		ret="";
		for(i=0;i<visible_entity_name.size();i++)
		{	
			if(visible_entity_team[i]!=team)continue;
//			if(visible_entity_status[i]==string_disabled)continue;
			if(Node_name_string_to_int(visible_entity_node[i])!=position)continue;

			if(!friend_agents.Have_pain_in_the_ass(zs))continue;
			ret=visible_entity_name[i];
		
			#if log_on
				log[agent_pi].writeln("Friend_hear_has_pain_in_the_ass() 2");
			#endif
			return 1;
		}
	
		#if log_on
			log[agent_pi].writeln("Friend_hear_has_pain_in_the_ass() 3");
		#endif
		return 0;
	}*/
	/*
	int On_friend_pain_ass(string &ret)
	{
		#if log_on
			log[agent_pi].writeln("On_friend_ass() 1");
		#endif
		int i;
		ret="";
		for(i=0;i<agent_p.size();i++)
		{	
			if(agent_p[i]->position!=position)
				continue;
				
			if(!agent_p[i]->Have_pain_in_the_ass())
				continue;
				
			if(agent_p[i]->agent_name==agent_name)
				continue;
				
			#if log_on
				log[agent_pi].writeln("On_friend_ass() 2");
			#endif
			
			ret=agent_p[i]->agent_name;
			return 1;
		}
		
		#if log_on
			log[agent_pi].writeln("On_friend_ass() 3");
		#endif
		return 0;
	}*/
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*
	stack<int> Not_explorer_min_cost_visit_bound()
	{
		#if log_on
			log[agent_pi].writeln("=======================Not_explorer_min_cost_visit_bound()");
		#endif
		
		
		int i,j,b,z;
		string zs;
		int n=node_n;
		
		
		for(i=1;i<=n;i++)node_bound[i]=-1;
		for(i=1;i<=n;i++)
		if(node_is_surveyed[i])node_bound[i]=0;
		
		for(i=1;i<=n;i++)
		if(node_bound[i]==-1)
		{
			for(j=1;j<=node_edge_n[i];j++)
			{
				b=node_edge[i][j];
				if(node_bound[b]==0)
				{
					node_bound[i]=1;
					break;
				}
			}
		}
		
		

		
		stack<int> ret= Dijkstra_run(position_int);
		
		
		//d_stack.Write(ret);
	
		#if log_on
			log[agent_pi].writeln("=======================Not_explorer_min_cost_visit_bound()2");
		#endif
		return ret;
	}*/
	
	
	vector<int> Agent_mission_explorer_min_cost_visit_bound(int agent_pi,int destination)
	{
		#if log_on
			log[agent_pi].writeln("=======================Min_cost_visit_bound()");
		#endif
		
		vector<int> ret;
		int i,j,b,z;
		string zs;
		int n=node_n;
		int flag=0;
		
	//	mission=cc.mission_explorer_min_cost_visit_bound;		
		
		for(i=1;i<=n;i++)node_bound[i]=-1;
		for(i=1;i<=n;i++)
		if(node_is_probed[i] && node_is_surveyed[i])node_bound[i]=0;
		
		for(i=1;i<=n;i++)
		if(i==destination)
		if(node_bound[i]==-1)
		{
			for(j=1;j<=node_edge_n[i];j++)
			{
				b=node_edge[i][j];
				if(node_bound[b]==0)
				{
					flag=1;
					node_bound[i]=1;
					break;
				}
			}
		}
		
		if(destination==agent_position_int[agent_pi] || node_bound[agent_position_int[agent_pi]]==1)
		{
			ret.clear();
			ret.push_back(agent_position_int[agent_pi]);
			return ret;
		}
		
		#if error_on
		if(!flag)
		{
			Error("ioery894s5y8943y");
		}
		#endif

		ret = Dijkstra_run(agent_position_int[agent_pi],agent_max_energy[agent_pi]);	
		
		
		#if log_on			
			log[agent_pi].writeln("=======================Min_cost_visit_bound()");
		#endif
		
		return ret;
	}
	
	int Agent_have_not_surveyed_node(int agent_pi)
	{
		#if log_on
			log[agent_pi].writeln("=======================Agent_have_not_surveyed_node(agent_pi)");
		#endif
		
		int ret=0;
		int i,j,b,z;
		string zs;
		int n=node_n;
					
		
		for(i=1;i<=n;i++)
		if(!node_is_surveyed[i])
			ret++;
			
		#if log_on	
			log[agent_pi].writeln("=======================Agent_have_not_surveyed_node(agent_pi)");
		#endif
		return ret;
	}
	
	int Agent_have_not_probed_node(int agent_pi)
	{
		#if log_on
			log[agent_pi].writeln("=======================Agent_have_not_probed_node(agent_pi)");
		#endif
		
		int ret=0;
		int i,j,b,z;
		string zs;
		int n=node_n;
					
		
		for(i=1;i<=n;i++)
		if(!node_is_probed[i])
			ret++;
			
		#if log_on	
			log[agent_pi].writeln("=======================Agent_have_not_probed_node(agent_pi)");
		#endif
		return ret;
	}
	
	/*stack<int> Explorer_min_cost_visit_bound()
	{
		#if log_on
			log[agent_pi].writeln("=======================Min_cost_visit_bound()");
		#endif
		stack<int> ret;
		int i,j,b,z;
		string zs;
		int n=node_n;
					
		
		for(i=1;i<=n;i++)node_bound[i]=-1;
		for(i=1;i<=n;i++)
		if(node_is_probed[i] && node_is_surveyed[i])node_bound[i]=0;
		
		for(i=1;i<=n;i++)
		if(node_bound[i]==-1)
		{
			for(j=1;j<=node_edge_n[i];j++)
			{
				b=node_edge[i][j];
				if(node_bound[b]==0)
				{
					node_bound[i]=1;
					break;
				}
			}
		}
		

		
		ret = Dijkstra_run(agent_position_int[agent_pi],node);
	
		#if log_on			
			log[agent_pi].writeln("=======================Min_cost_visit_bound()");
		#endif
		return ret;
	}*/
	
	void Agent_learn_from_sight(int agent_pi)
	{
		#if log_on
			log[agent_pi].writeln("---------------------Learn_from_sight()1");
		#endif
		int i,a,b,c,z;
		string sa,sb;
		string zs;
		
		for(i=0;i<enermy_n;i++)
		{
			enermy_perception_id[i]=perception_id;
		}
		
		i=agent_pi;
		{
			agent_level[agent_pi]=i;
			if(agent_role[i]==string_saboteur)
			{
				agent_level[agent_pi]+=100;
			}
			if(agent_role[i]==string_repairer) 
			{
				agent_level[agent_pi]+=100;
			}
		}
		
		agent_can_buy_battery[agent_pi]=1;
		agent_can_buy_sensor[agent_pi]=1;
		agent_can_buy_shield[agent_pi]=1;
		agent_can_buy_sabotageDevice[agent_pi]=1;
		
		if(agent_role[agent_pi]==string_explorer)
		{
			agent_can_buy_sabotageDevice[agent_pi]=0;
		}
		else if(agent_role[agent_pi]==string_saboteur) 
		{
		}
		else if(agent_role[agent_pi]==string_repairer) 
		{
			agent_can_buy_sabotageDevice[agent_pi]=0;
		}
		else if(agent_role[agent_pi]==string_inspector)
		{
			agent_can_buy_sabotageDevice[agent_pi]=0;
		}
		else
		{
			agent_can_buy_sabotageDevice[agent_pi]=0;
		}
		
		if(!Vector_find(can_buy_role,agent_role[agent_pi]))
		{
			#if log_on
			for(i=0;i<can_buy_role.size();i++)
				log[agent_pi].writeln(can_buy_role[i]);
			log[agent_pi].writeln(agent_role[agent_pi]);
			log[agent_pi].writeln("-------------- I am not can buy money role");
			#endif
			
			agent_can_buy_battery[agent_pi]=0;
			agent_can_buy_sensor[agent_pi]=0;
			agent_can_buy_shield[agent_pi]=0;
			agent_can_buy_sabotageDevice[agent_pi]=0;
		}
		
		
		
		

		
		for(i=0;i<visible_edge_node1.size();i++)
		{
			sa=visible_edge_node1[i];
			sb=visible_edge_node2[i];
			a=Node_name_string_to_int(sa);
			b=Node_name_string_to_int(sb);
			Node_add_edge(a,b);
			Node_add_edge(b,a);
		}
		
		
		z=agent_position_int[agent_pi];
			node_visited[z]=1;
		
		
		for(i=0;i<surveyed_edge_node1.size();i++)
		{
			a=surveyed_edge_node1[i];
			b=surveyed_edge_node2[i];
			c=surveyed_edge_weight[i];
			Node_add_surveyed_edge(a,b,c);
			Node_add_surveyed_edge(b,a,c);
		}
		
		for(i=0;i<probed_vertex_name.size();i++)
		{
			a=Node_name_string_to_int(probed_vertex_name[i]);
			b=probed_bertex_value[i];
			
			if(!node_is_probed[a])
				Node_set_value(a,b);
		}
		
		for(i=0;i<visible_entity_name.size();i++)
		if(visible_entity_name[i]==agent_name[agent_pi])
		{
			agent_team=visible_entity_team[i];
			//status=visible_entity_status[i];
		}
		
		for(i=0;i<visible_entity_name.size();i++)
		{
			if(visible_entity_team[i]==agent_team)
				continue;
				
			zs=visible_entity_name[i];
			z=Enermy_string_to_int(zs);			
			enermy_name[z]=zs;
			Enermy_update_node(z,visible_entity_node[i],perception_id);
			Enermy_update_status(z,visible_entity_status[i],perception_id);
		}
		
		
		for(i=0;i<inspected_entity_name.size();i++)
		{
			zs=inspected_entity_name[i];
			z=Enermy_string_to_int(zs);
			enermy_is_inspected[z]=1;
			enermy_inspect_time_id[z]=perception_id;
			
			enermy_name[z]=inspected_entity_name[i];
			enermy_energy[z]=inspected_entity_energy[i];
			enermy_health[z]=inspected_entity_health[i];
			enermy_maxEnergy[z]=inspected_entity_max_energy[i];
			enermy_maxHealth[z]=inspected_entity_max_health[i];
			Enermy_update_node(z,inspected_entity_node[i],perception_id);
			
			Enermy_set_role(z,inspected_entity_role[i]);
			
			enermy_strength[z]=inspected_entity_strength[i];
			enermy_team[z]=inspected_entity_team[i];
			enermy_visRange[z]=inspected_entity_vis_range[i];			
		}

		#if log_on		
			log[agent_pi].writeln("---------------------Learn_from_sight() 2");
		#endif
	}











int Agent_on_saboteur_enermy_ass(int agent_pi)
	{
		#if log_on
				log[agent_pi].writeln("Agent_on_saboteur_enermy_ass(agent_pi) 1");
		#endif
		
		int i;
		string zs;
		int z;
		
		for(i=0;i<enermy_n;i++)
		{			
			if(Enermy_status_is(i,string_disabled,perception_id))
				continue;
				
			if(!Enermy_get_node(i,zs,perception_id))
				continue;
				
			if(zs!=agent_position[agent_pi])
				continue;	
				
			if(enermy_role[i]!=string_saboteur)
				continue;
			
			#if log_on
				log[agent_pi].writeln("Agent_on_saboteur_enermy_ass(agent_pi) 2");
			#endif
			return 1;
		}
		
		#if log_on
			log[agent_pi].writeln("Agent_on_saboteur_enermy_ass(agent_pi) 3");
		#endif
		return 0;
	}






bool Agent_on_repairer_ass(int agent_pi)
	{
		#if log_on
		log[agent_pi].writeln("--------- Agent_on_repairer_ass(agent_pi)1");
		#endif
		
		int i,z;
		for(i=0;i<agent_n;i++)
		{
			if(agent_role[i]!=string_repairer)
				continue;
			if(i==agent_pi)
				continue;
			if(agent_health[i]==0)
				continue;	
			
			z=agent_position_int[i];
			if(z!=agent_position_int[agent_pi])
				continue;
			
			#if log_on
			log[agent_pi].write("--------- Agent_on_repairer_ass(agent_pi)2 ");
			#endif
			return 1;
		}
		#if log_on
		log[agent_pi].writeln("--------- Agent_on_repairer_ass(agent_pi)3");
		#endif
		return 0;
	}
	
	int Agent_on_uninspected_enermy_ass(int agent_pi)
	{
		#if log_on
				log[agent_pi].writeln(" Near_uninspected_enermy_ass(string &ret) 1");
		#endif
		
		int ret;
		int i;
		string zs;
		int z;
		ret=0;
		
		
		for(i=0;i<enermy_n;i++)
		{
			if(enermy_is_inspected[i])
				continue;
			
			if(!Enermy_get_node(i,zs,perception_id))
				continue;
				
			if(zs==agent_position[agent_pi])
			{
				ret=1;
				
				
				#if log_on
					log[agent_pi].writeln(" Near_uninspected_enermy_ass(string &ret) 2");
				#endif
				
				break;
			}
			/*
			z=Node_name_string_to_int(zs);
			
			if(!d_vector.Find(vertex_near,z))
				continue;
			
			ret=1;
			enermy_id=i;*/
			
			
			
		}			
		
		#if log_on
			log[agent_pi].writeln("Near_uninspected_enermy_ass(string &ret) 3");
		#endif
		return ret;
	}
	
	bool Agent_near_repairer_ass(int agent_pi,string &ret)
	{
		#if log_on
		log[agent_pi].writeln("--------- Near_repairer_ass(string &ret)1");
		#endif
		
		int i,z;
		for(i=0;i<agent_n;i++)
		{
			if(agent_role[i]!=string_repairer)
				continue;
			if(i==agent_pi)
				continue;
			if(agent_health[i]==0)
				continue;	
			
			z=agent_position_int[i];
			if(!Vector_find(agent_vertex_near[agent_pi],z))
				continue;
				
			ret=agent_position[i];
			#if log_on
			log[agent_pi].write("--------- Near_repairer_ass(string &ret)2 = ");
			log[agent_pi].writeln(ret);
			#endif
			
			return 1;
		}
		
		#if log_on
		log[agent_pi].writeln("--------- Near_repairer_ass(string &ret)3");
		#endif
		
		return 0;
	}
	
	
	
	bool Agent_find_repairer(int agent_pi)
	{
		#if log_on
		log[agent_pi].writeln("Agent_find_repairer(agent_pi) 1");
		#endif
		
		int i,z;
		string zs;
		int ret=0;
				
		for(i=0;i<agent_n;i++)
		{
			if(agent_role[i]!=string_repairer)
				continue;
			if(i==agent_pi)
				continue;
			if(agent_health[i]==0)
				continue;	
			
			z=agent_position_int[i];
			if(!node_can_visit[z][agent_pi])
				continue;
			
			#if log_on
			log[agent_pi].write("--------- repairer is reachable : ");
			log[agent_pi].writeln(agent_name[agent_pi]);
			#endif
			ret=1;
		}
		return ret;						
	}
	
	bool Agent_repairer_is_reachable_by_surveyed_position(int agent_pi)
	{
		#if log_on
			log[agent_pi].writeln("Agent_repairer_is_reachable_by_surveyed_position(agent_pi) 1");
		#endif
		
		int i,flag,z;
		string zs;
		int ret=0;
	
		
		
		for(i=0;i<agent_n;i++)
		{	
			if(agent_role[i]!=string_repairer)
				continue;
			if(i==agent_pi)
				continue;
			if(agent_health[i]==0)
				continue;	
				
			z=agent_position_int[i];
			if(!node_can_visit_through_surveyed_node[z][agent_pi])
				continue;
				
			#if log_on
			log[agent_pi].write("Agent_repairer_is_reachable_by_surveyed_position(agent_pi) = ");
			log[agent_pi].writeln(agent_name[i]);
			#endif
			
			ret=1;
		}
		return ret;
	}
	
	vector<int> Agent_go_to_reachable_repairer_by_surveyed_position(int agent_pi)
	{
		#if log_on
			log[agent_pi].writeln("Agent_go_to_reachable_repairer_by_surveyed_position(agent_pi) 1");
		#endif
		
		int i,flag,z;
		string zs;
		int n=node_n;
		
		
		for(i=1;i<=n;i++)node_bound[i]=-1;
		for(i=1;i<=n;i++)
		if(node_is_surveyed[i])node_bound[i]=0;
				
		
		for(i=0;i<agent_n;i++)
		{	
			if(agent_role[i]!=string_repairer)
				continue;
			if(i==agent_pi)
				continue;
			if(agent_health[i]==0)
				continue;	
				
			z=agent_position_int[i];
			if(!node_can_visit_through_surveyed_node[z][agent_pi])
				continue;	
			node_bound[z]=1;
		}
		
		vector<int> ret=Dijkstra_run(agent_position_int[agent_pi],agent_max_energy[agent_pi]);
		

		#if log_on		
			log[agent_pi].writeln("Agent_go_to_reachable_repairer_by_surveyed_position(agent_pi) 2");
		#endif
		
		return ret;
	}
	
	
	vector<int> Agent_go_to_unkown_place_near_uninspected_notwanted_enermy(int agent_pi)
	{
		#if log_on
			log[agent_pi].writeln("Go_to_unkown_place_near_uninspected_enermy() 1");
		#endif
		
		int i,j,a,b,z,w;
		string zs;
		int n=node_n;
				
		for(i=1;i<=n;i++)node_bound[i]=-1;
		for(i=1;i<=n;i++)
		if(!node_is_surveyed[i])node_bound[i]=0;
		
		
		queue<int> q;
		while(q.size())q.pop();
		for(i=1;i<=n;i++)
		{
			node_dis[i]=-1;
			node_v[i]=0;
		}
				
		//for(i=0;i<enermy_n;i++)
		{
			i=agent_inspect_target_is[agent_pi];
			
			if(Enermy_get_node(i,zs,perception_id))
			{
			}
			#if error_on
			else
				Error("fjogj3045yu");
			#endif
			
				
			int znode=Node_name_string_to_int(zs);									
			
			if(node_can_visit[znode][agent_pi])
			{
			}
			#if error_on
			else
				Error("h-5uie-0u5hj");
				
			if(enermy_is_inspected[i])
				Error("jgj93yuw9uy");
			#endif
			
				
			node_dis[znode]=0;
			q.push(znode);
			node_v[znode]=1;
		}
		
		while(q.size())
		{
			if(node_v[agent_position_int[agent_pi]])
				break;
				
			a=q.front();
			q.pop();
			for(i=1;i<=node_edge_n[a];i++)
			{
				if(node_v[agent_position_int[agent_pi]])
					break;
				
				b=node_edge[a][i];
				if(node_v[b])continue;
				//if(node_bound[b]==-1)continue;				
				if(node_dis[b]!=-1 && node_dis[b]<=node_dis[a]+1)continue;
				node_dis[b]=node_dis[a]+1;
				node_v[b]=1;
				q.push(b);
			}			
		}
		
		int da=-1,cost;
		for(i=1;i<=node_edge_n[agent_position_int[agent_pi]];i++)
		{
			z=node_edge[agent_position_int[agent_pi]][i];
			w=node_edge_value[agent_position_int[agent_pi]][i];
			
			if(node_bound[z]==0 && node_v[z])
			{
				if(da<0)
				{
					da=z;
					cost=w;
					continue;
				}
				if(node_dis[da]<node_dis[z])continue;
				if(node_dis[da]==node_dis[z] && cost<w)continue;
				da=z;
				cost=w;
			}
		}
		
		#if error_on
		if(da==-1)
		{
			Error("wgya4u4a3us "+agent_name[agent_pi]);
		}	
		#endif
		
		vector<int> ret;
		ret.clear();
		ret.push_back(da);
		
		#if log_on
			log[agent_pi].writeln("Go_to_unkown_place_near_uninspected_enermy() 2");
		#endif
		return ret;
	}
	
	vector<int> Agent_go_to_uninspected_notwanted_enermy_near_known_place(int agent_pi)
	{
		#if log_on
			log[agent_pi].writeln("Agent_go_to_enermy_near_known_place(agent_pi) 1");
		#endif
	
		int i,j,a,b,z;
		string zs;
		int n=node_n;
				
		for(i=1;i<=n;i++)node_bound[i]=-1;
		
		for(i=1;i<=n;i++)
		if(node_is_surveyed[i] && node_can_visit_through_surveyed_node[i][agent_pi])node_bound[i]=0;
		
	

		
		queue<int> q;
		while(q.size())q.pop();
		
		for(i=1;i<=n;i++)
		{
			node_dis[i]=-1;
			node_v[i]=0;
		}
		
		//for(i=0;i<enermy_n;i++)
		{		
			i=agent_inspect_target_is[agent_pi];
				
			if(Enermy_get_node(i,zs,perception_id))
			{
			}
			#if error_on
			else
				Error("f0iwj409yu3ay");
			#endif
				
			z=Node_name_string_to_int(zs);
			
			if(node_can_visit[z][agent_pi])
			{
			}
			#if error_on
			else
				Error("mgroigm85yuw");
				
			if(enermy_is_inspected[i])
				Error("fm34uyq04yjgh");
			#endif
			
				
			node_dis[z]=0;
			q.push(z);
			node_v[z]=1;
		}
				
		while(q.size())
		{
			a=q.front();
			q.pop();
			for(i=1;i<=node_edge_n[a];i++)
			{
				b=node_edge[a][i];
				if(node_v[b])
					continue;
				
				if(node_dis[b]!=-1 && node_dis[b]<=node_dis[a]+1)
					continue;
					
				node_dis[b]=node_dis[a]+1;
				node_v[b]=1;
				
				if(node_bound[b]==0)
					continue;
					
				q.push(b);		
			}			
		}
		
		z=-1;
		for(i=1;i<=n;i++)
		if(node_bound[i]==0 && node_v[i])
		if(z<0 || node_dis[i]<node_dis[z])z=i;
		
		#if error_on
		if(z<0)
			Error("djgarei0934ya "+agent_name[agent_pi]);
		#endif
		
		for(i=1;i<=n;i++)
		if(node_bound[i]==0 && node_v[i])
		if(node_dis[i]==node_dis[z])node_bound[i]=1;
		
		#if error_on
		if(node_dis[z]<0)
			Error("09834uty983wqh4yw3y");
		#endif
		
		vector<int> ret;
		ret.clear();
		
		ret = Dijkstra_run(agent_position_int[agent_pi],agent_max_energy[agent_pi]);	
		
		
		#if log_on
			log[agent_pi].writeln("Agent_go_to_enermy_near_known_place(agent_pi) 2");
		#endif
		
		return ret;
	}
	
	bool Agent_on_the_edge_of_survey_zone_near_uninspected_notwanted_enermy(int agent_pi)
	{
		#if log_on
			log[agent_pi].writeln("Agent_on_the_edge_of_survey_zone_near_uninspected_notwanted_enermy(agent_pi) 1");
		#endif
		
		int i,j,a,b,z;
		string zs;
		int n=node_n;
				
		for(i=1;i<=n;i++)node_bound[i]=-1;
		
		for(i=1;i<=n;i++)
		if(node_is_surveyed[i] && node_can_visit_through_surveyed_node[i][agent_pi])node_bound[i]=0;
		
	

		
		queue<int> q;
		while(q.size())q.pop();
		
		for(i=1;i<=n;i++)
		{
			node_dis[i]=-1;
			node_v[i]=0;
		}
		
		//for(i=0;i<enermy_n;i++)
		{
			i=agent_inspect_target_is[agent_pi];
										
			if(Enermy_get_node(i,zs,perception_id))
			{
			}
			#if error_on
			else
				Error("gnreohg9yj3");
			#endif
				
			z=Node_name_string_to_int(zs);
			
			if(node_can_visit[z][agent_pi])
			{
			}
			#if error_on
			else
				Error("fwgfj4guy4");
			
				
			if(enermy_is_inspected[i])
				Error("mvroir0h94w5u");
			#endif
			
				
			node_dis[z]=0;
			q.push(z);
			node_v[z]=1;
		}
		
			
		
		while(q.size())
		{
			a=q.front();
			q.pop();
			for(i=1;i<=node_edge_n[a];i++)
			{
				b=node_edge[a][i];
				if(node_v[b])
					continue;
				
				if(node_dis[b]!=-1 && node_dis[b]<=node_dis[a]+1)
					continue;
					
				node_dis[b]=node_dis[a]+1;
				node_v[b]=1;
				
				if(node_bound[b]==0)
					continue;
					
				q.push(b);		
			}			
		}
		
		
		z=-1;
		for(i=1;i<=n;i++)
		if(node_bound[i]==0 && node_v[i])
		if(z<0 || node_dis[i]<node_dis[z])z=i;
		
		#if error_on
		if(z<0)
			Error("hj8s934y0s4pyuha");
		#endif
		
		for(i=1;i<=n;i++)
		if(node_bound[i]==0 && node_v[i])
		if(node_dis[i]==node_dis[z])node_bound[i]=1;
		
		#if error_on
		if(node_dis[z]<0)
			Error("s45i65ytsw45i");
		#endif
			
		#if log_on
			log[agent_pi].writeln("On_the_edge_of_survey_zone_near_uninspected_enermy() 2");
		#endif
			
		return node_dis[agent_position_int[agent_pi]]==node_dis[z];	
	}
	
	vector<int> Agent_go_to_uninspected_enermy(int agent_pi)
	{
		#if log_on
			log[agent_pi].writeln("Agent_go_to_uninspected_enermy(agent_pi) 1");
		#endif
	
		int i,j,b,z;
		string zs;
		int n=node_n;
		
		
		for(i=1;i<=n;i++)node_bound[i]=-1;
		for(i=1;i<=n;i++)
		if(node_is_surveyed[i])node_bound[i]=0;
		
		
		//for(i=0;i<enermy_n;i++)
		{
			i=agent_inspect_target_is[agent_pi];
										
			if(Enermy_get_node(i,zs,perception_id))
			{
			}
			#if error_on
			else
				Error("j9fg4jg40ayu4y");
			#endif
				
			z=Node_name_string_to_int(zs);
			
			if(node_can_visit_through_surveyed_node[z][agent_pi])
			{
			}
			#if error_on
			else
				Error("gnrjyu945uwh");
			
			if(enermy_is_inspected[i])
				Error("nvreuy0w45uy");			
			#endif
				
			node_bound[z]=1;
		}

	
		vector<int> ret;
		
		ret = Dijkstra_run(agent_position_int[agent_pi],agent_max_energy[agent_pi]);	
		
	
		#if log_on		
			log[agent_pi].writeln("Agent_go_to_uninspected_enermy(agent_pi) 2");
		#endif

		return ret;
	}
	
	int Agent_uninspected_notwanted_enermy_can_visit_through_surveyed_node(int agent_pi)
	{
		#if log_on
			log[agent_pi].writeln("Uninspected_nermy_can_visit_through_surveyed_node() 1");
		#endif
	
		int i,flag,z;
		string zs;
		
		//for(i=0;i<enermy_n;i++)
		{
			i=agent_inspect_target_is[agent_pi];
						
			if(Enermy_get_node(i,zs,perception_id))
			{
			}
			#if error_on
			else
				Error("vrenryh0w48jy");
			#endif
				
			z=Node_name_string_to_int(zs);
			
			if(!node_can_visit_through_surveyed_node[z][agent_pi])
				return 0;
				
			#if error_on				
			if(enermy_is_inspected[i])
				Error("fj090439uyyjuh");
			#endif
			
			
			#if log_on			
				log[agent_pi].writeln("Uninspected_nermy_can_visit_through_surveyed_node() 2");
			#endif
			return 1;
		}
				
		#if log_on
			log[agent_pi].writeln("Uninspected_nermy_can_visit_through_surveyed_node() 3");
		#endif
	
	}
	
	bool Agent_on_the_edge_of_survey_zone_near_repairer(int agent_pi)
	{
		#if log_on
			log[agent_pi].writeln("Agent_on_the_edge_of_survey_zone_near_repairer(agent_pi) 1");	
		#endif
		
		int i,j,a,b,z;
		string zs;
		int n=node_n;
		
		
		for(i=1;i<=n;i++)node_bound[i]=-1;
				
		for(i=1;i<=n;i++)
		if(node_is_surveyed[i] && node_can_visit_through_surveyed_node[i][agent_pi])node_bound[i]=0;
		
		

		
		queue<int> q;
		while(q.size())q.pop();
		
		for(i=1;i<=n;i++)
		{
			node_dis[i]=-1;
			node_v[i]=0;
		}
	
		
		for(i=0;i<agent_n;i++)
		{			
			if(agent_role[i]!=string_repairer)
				continue;
			if(i==agent_pi)
				continue;
			if(agent_health[i]==0)
				continue;	
				
			z=agent_position_int[i];
						
			if(!node_can_visit[z][agent_pi])
				continue;
									
			node_dis[z]=0;
			q.push(z);
			node_v[z]=1;
		}
		
		
		while(q.size())
		{
			a=q.front();
			q.pop();
			for(i=1;i<=node_edge_n[a];i++)
			{
				b=node_edge[a][i];
				if(node_v[b])
					continue;
				
				if(node_dis[b]!=-1 && node_dis[b]<=node_dis[a]+1)
					continue;
					
				node_dis[b]=node_dis[a]+1;
				node_v[b]=1;
				
				if(node_bound[b]==0)
					continue;
					
				q.push(b);		
			}			
		}
		
		
		z=-1;
		for(i=1;i<=n;i++)
		if(node_bound[i]==0 && node_v[i])
		if(z<0 || node_dis[i]<node_dis[z])z=i;
		
		if(z<0)
		{
			return 0;
		}
		
		for(i=1;i<=n;i++)
		if(node_bound[i]==0 && node_v[i])
		if(node_dis[i]==node_dis[z])node_bound[i]=1;
		
		#if error_on
		if(node_dis[z]<0)
			Error("s45i65ytsw45i");
		#endif
			
		#if log_on
			log[agent_pi].writeln("Agent_on_the_edge_of_survey_zone_near_repairer(agent_pi) 2");
		#endif
			
		return node_dis[agent_position_int[agent_pi]]==node_dis[z];	
	}
	
	
	
	
	
	
	
	double Agent_low_energy_rate(int agent_pi)
	{
		if(agent_health[agent_pi]==0)
			return 0.5;
		else
			return 0.5;
	}

	int Agent_can_go_to(int agent_pi,int x)
	{
		int i;
		#if error_on
		if(x==agent_position_int[agent_pi])
			Error("9r032utqyh4aehga");
		#endif
		
		for(i=0;i<agent_vertex_near[agent_pi].size();i++)
		if(agent_vertex_near[agent_pi][i]==x)return 1;
		
		#if log_on
			log[agent_pi].writeln("Can_go_to(int x)1: ");
		
		log[agent_pi].writeln(x);
		for(i=0;i<agent_vertex_near[agent_pi].size();i++)
		{
			log[agent_pi].write(agent_vertex_near[agent_pi][i]);
			log[agent_pi].write(" ");			
		}
		log[agent_pi].writeln("");
		
		
		log[agent_pi].writeln(node_name_int_to_string[x]);
		for(i=0;i<agent_vertex_near[agent_pi].size();i++)
		{
			log[agent_pi].write(node_name_int_to_string[agent_vertex_near[agent_pi][i]]);
			log[agent_pi].write(" ");			
		}
		log[agent_pi].writeln("");
		#endif
		
		return 0;
	}


///z
	vector<int> Agent_mission_kuo(int agent_pi,int destination)
	{
		#if log_on
			log[agent_pi].writeln("=======================Mission_kuo(int destination)");
		#endif
		
		vector<int> ret;
		int i,j,b,z;
		string zs;
		int n=node_n;
		
		
		for(i=1;i<=n;i++)node_bound[i]=-1;
		for(i=1;i<=n;i++)
		if(node_is_surveyed[i])node_bound[i]=0;
		
		for(i=1;i<=n;i++)
		if(i==destination)
		{
			node_bound[i]=1;
		}
		
		if(destination==agent_position_int[agent_pi] || node_bound[agent_position_int[agent_pi]]==1)
		{
			ret.clear();
			ret.push_back(agent_position_int[agent_pi]);
			return ret;
		}

				
		
		ret = Dijkstra_run(agent_position_int[agent_pi],agent_max_energy[agent_pi]);	
		
		
		#if error_on
		if(ret.size()==0)
		{
			Error("34uri:G348a9y");
		}
		#endif
	
		#if log_on
			log[agent_pi].writeln("=======================Mission_kuo(int destination)2");
		#endif
		return ret;
	}

vector<int> Agent_mission_not_explorer_min_cost_visit_bound(int agent_pi,int destination)
	{
		#if log_on
			log[agent_pi].writeln("=======================Mission_not_explorer_min_cost_visit_bound(int destination)");
		#endif
		
		vector<int> ret;
		int i,j,b,z;
		string zs;
		int n=node_n;
		
		
		for(i=1;i<=n;i++)node_bound[i]=-1;
		for(i=1;i<=n;i++)
		if(node_is_surveyed[i])node_bound[i]=0;
		
		for(i=1;i<=n;i++)
		if(i==destination)
		if(node_bound[i]==-1)
		{
			for(j=1;j<=node_edge_n[i];j++)
			{
				b=node_edge[i][j];
				if(node_bound[b]==0)
				{
					node_bound[i]=1;
					break;
				}
			}
		}
		
		if(destination==agent_position_int[agent_pi] || node_bound[agent_position_int[agent_pi]]==1)
		{
			ret.clear();
			ret.push_back(agent_position_int[agent_pi]);
			return ret;
		}
		
		
		ret = Dijkstra_run(agent_position_int[agent_pi],agent_max_energy[agent_pi]);	
		
	
		#if log_on
			log[agent_pi].writeln("=======================Mission_not_explorer_min_cost_visit_bound(int destination)2");
		#endif
		
		return ret;
	}

vector<int> Agent_go_to_reachable_friend_by_surveyed_position(int agent_pi)
	{
		#if log_on
			log[agent_pi].writeln("Agent_go_to_reachable_friend_by_surveyed_position(agent_pi) 1");
		#endif
		int i,flag,z;
		string zs;
		int n=node_n;
		
		
		for(i=1;i<=n;i++)node_bound[i]=-1;
		for(i=1;i<=n;i++)
		if(node_is_surveyed[i])node_bound[i]=0;
		
		
		for(i=0;i<agent_n;i++)
		{	
			if(i==agent_pi)
				continue;
			
			if(!Agent_have_pain_in_the_ass(i))
				continue;
				
			z=agent_position_int[i];
			if(!node_can_visit_through_surveyed_node[z][agent_pi])
				continue;	
			node_bound[z]=1;
		}
		
		vector<int> ret;

		
		ret = Dijkstra_run(agent_position_int[agent_pi],agent_max_energy[agent_pi]);	
		
		
		#if log_on		
			log[agent_pi].writeln("Agent_go_to_reachable_friend_by_surveyed_position(agent_pi) 2");
		#endif
		
		return ret;
	}
	
	int Agent_pain_friend_is_reachable_by_surveyed_position(int agent_pi)
	{
		#if log_on
			log[agent_pi].writeln("Agent_pain_friend_is_reachable_by_surveyed_position(agent_pi) 1");
		#endif
		int i,flag,z;
		string zs;
				
		for(i=0;i<agent_n;i++)
		{	
			if(!Agent_have_pain_in_the_ass(i))
				continue;
			
			if(i==agent_pi)
				continue;
				
			z=agent_position_int[i];
			if(!node_can_visit_through_surveyed_node[z][agent_pi])
				continue;
			return 1;
		}
		return 0;
	}
	
	vector<int> Agent_go_to_unkown_place_near_repairer_with_smallest_edge(int agent_pi)
	{
		#if log_on
			log[agent_pi].writeln("Go_to_unkown_place_near_repairer_with_smallest_edge() 1");
		#endif
		int i,j,a,b,z,w;
		string zs;
		int n=node_n;
		
		
		for(i=1;i<=n;i++)node_bound[i]=-1;
		for(i=1;i<=n;i++)
		if(!node_is_surveyed[i])node_bound[i]=0;
		
		
		queue<int> q;
		while(q.size())q.pop();
		for(i=1;i<=n;i++)
		{
			node_dis[i]=-1;
			node_v[i]=0;
		}
				
		for(i=0;i<agent_n;i++)		
		{	
			if(agent_role[i]!=string_repairer)
				continue;
			if(i==agent_pi)
				continue;
			if(agent_health[i]==0)
				continue;
				
			z=agent_position_int[i];		
			
			if(!node_can_visit[z][agent_pi])
				continue;
			
			node_dis[z]=0;
			q.push(z);
			node_v[z]=1;
		}
		
		
		while(q.size())
		{
			if(node_v[agent_position_int[agent_pi]])
				break;
				
			a=q.front();
			q.pop();
			for(i=1;i<=node_edge_n[a];i++)
			{
				if(node_v[agent_position_int[agent_pi]])
					break;
				
				b=node_edge[a][i];
				if(node_v[b])continue;
				//if(node_bound[b]==-1)continue;
				if(node_dis[b]!=-1 && node_dis[b]<=node_dis[a]+1)continue;
				node_dis[b]=node_dis[a]+1;
				node_v[b]=1;
				q.push(b);
			}			
		}
		
		int da=-1;
		for(i=1;i<=node_edge_n[agent_position_int[agent_pi]];i++)
		{
			z=node_edge[agent_position_int[agent_pi]][i];
			
			if(node_bound[z]==0 && node_v[z])
			{
				if(da<0)
				{
					da=z;
					continue;
				}
				if(node_dis[da]<node_dis[z])continue;
				da=z;
			}
		}

		#if error_on
		if(da==-1)
		{
			Error("wa3e6rdsuus4");
		}	
		#endif
		
		vector<int> ret;
		ret.clear();
		ret.push_back(da);
	
		#if log_on	
			log[agent_pi].writeln("Go_to_unkown_place_near_repairer_with_smallest_edge() 2");
		#endif
		return ret;
	}
	
	vector<int> Agent_go_to_unkown_place_near_friend(int agent_pi)
	{
		#if log_on
			log[agent_pi].writeln("Agent_go_to_unkown_place_near_friend(agent_pi) 1");
		#endif
		int i,j,a,b,z,w;
		string zs;
		int n=node_n;
		
		
		for(i=1;i<=n;i++)node_bound[i]=-1;
		for(i=1;i<=n;i++)
		if(!node_is_surveyed[i])node_bound[i]=0;
		
		
		queue<int> q;
		while(q.size())q.pop();
		for(i=1;i<=n;i++)
		{
			node_dis[i]=-1;
			node_v[i]=0;
		}
				
		for(i=0;i<agent_n;i++)		
		{	
			if(i==agent_pi)
				continue;
			
			if(!Agent_have_pain_in_the_ass(i))
				continue;
				
			z=agent_position_int[i];		
			
			if(!node_can_visit[z][agent_pi])
				continue;
			
			node_dis[z]=0;
			q.push(z);
			node_v[z]=1;
		}
		
		
		while(q.size())
		{
			if(node_v[agent_position_int[agent_pi]])
				break;
					
			a=q.front();
			q.pop();
			for(i=1;i<=node_edge_n[a];i++)
			{
				if(node_v[agent_position_int[agent_pi]])
					break;
					
				b=node_edge[a][i];
				if(node_v[b])continue;
				
				//if(node_bound[b]==-1)continue;
				if(node_dis[b]!=-1 && node_dis[b]<=node_dis[a]+1)continue;
				node_dis[b]=node_dis[a]+1;
				node_v[b]=1;
				q.push(b);
			}			
		}
		
		int da=-1,cost;
		for(i=1;i<=node_edge_n[agent_position_int[agent_pi]];i++)
		{
			z=node_edge[agent_position_int[agent_pi]][i];
			w=node_edge_value[agent_position_int[agent_pi]][i];
			
			if(node_bound[z]==0 && node_v[z])
			{
				if(da<0)
				{
					da=z;
					cost=w;
					continue;
				}
				if(node_dis[da]<node_dis[z])continue;
				if(node_dis[da]==node_dis[z] && cost<w)continue;
				da=z;
				cost=w;
			}
		}

		#if error_on
		if(da==-1)
		{
			Error("ghruw4587ayh4");
		}	
		#endif
		
		vector<int> ret;
		ret.clear();
		ret.push_back(da);
	
		#if log_on	
			log[agent_pi].writeln("Agent_go_to_unkown_place_near_friend(agent_pi) 2");
		#endif
		return ret;
	}
	
	bool Agent_on_the_edge_of_survey_zone_near_friend(int agent_pi)
	{
		#if log_on
			log[agent_pi].writeln("Agent_on_the_edge_of_survey_zone_near_friend(agent_pi) 1");
		#endif
	
		int i,j,a,b,z;
		string zs;
		int n=node_n;
		
		
		for(i=1;i<=n;i++)node_bound[i]=-1;
				
		for(i=1;i<=n;i++)
		if(node_is_surveyed[i] && node_can_visit_through_surveyed_node[i][agent_pi])node_bound[i]=0;
		
	

		
		queue<int> q;
		while(q.size())q.pop();
		
		for(i=1;i<=n;i++)
		{
			node_dis[i]=-1;
			node_v[i]=0;
		}
	
		
		for(i=0;i<agent_n;i++)
		{			
			if(i==agent_pi)
				continue;
			if(!Agent_have_pain_in_the_ass(i))
				continue;
				
			z=agent_position_int[i];
						
			if(!node_can_visit[z][agent_pi])
				continue;
									
			node_dis[z]=0;
			q.push(z);
			node_v[z]=1;
		}
		
		
		while(q.size())
		{
			a=q.front();
			q.pop();
			for(i=1;i<=node_edge_n[a];i++)
			{
				b=node_edge[a][i];
				if(node_v[b])
					continue;
				
				if(node_dis[b]!=-1 && node_dis[b]<=node_dis[a]+1)
					continue;
					
				node_dis[b]=node_dis[a]+1;
				node_v[b]=1;
				
				if(node_bound[b]==0)
					continue;
					
				q.push(b);		
			}			
		}
		
		
		z=-1;
		for(i=1;i<=n;i++)
		if(node_bound[i]==0 && node_v[i])
		if(z<0 || node_dis[i]<node_dis[z])z=i;
		
		if(z<0)
		{
			return 0;
		}
		
		for(i=1;i<=n;i++)
		if(node_bound[i]==0 && node_v[i])
		if(node_dis[i]==node_dis[z])node_bound[i]=1;
		
		#if error_on
		if(node_dis[z]<0)
			Error("s45i65ytsw45i");
		#endif
			
		#if log_on
			log[agent_pi].writeln("Agent_on_the_edge_of_survey_zone_near_friend(agent_pi) 2");
		#endif
			
		return node_dis[agent_position_int[agent_pi]]==node_dis[z];	
	}

	bool Agent_on_the_edge_of_survey_zone_near_enermy(int agent_pi)
	{
		#if log_on
			log[agent_pi].writeln("Agent_on_the_edge_of_survey_zone_near_enermy(agent_pi) 1");
		#endif
	
		int i,j,a,b,z;
		string zs;
		int n=node_n;
				
		for(i=1;i<=n;i++)node_bound[i]=-1;
		
		for(i=1;i<=n;i++)
		if(node_is_surveyed[i] && node_can_visit_through_surveyed_node[i][agent_pi])node_bound[i]=0;
		
	

		
		queue<int> q;
		while(q.size())q.pop();
		
		for(i=1;i<=n;i++)
		{
			node_dis[i]=-1;
			node_v[i]=0;
		}
		
		
		///s
		{
			i=agent_attack_target_is[agent_pi];
			/*
			if(i<0)
				Error("jf9we0ut34uyu3y");
			
			#if error_on
			if(do_not_attack[i])
				Error("0903jhja4yuyu");
			#endif
			*/
			if(!Enermy_status_is(i,string_disabled,perception_id))
			{
			}
			#if error_on
			else
				Error("90ymglngeoahiohpa");
			#endif
			
			
			if(Enermy_get_node(i,zs,perception_id))
			{
			}
			#if error_on
			else
				Error("9t49tjerhfdlb");
			#endif
				
			z=Node_name_string_to_int(zs);
			
			if(node_can_visit[z][agent_pi])
			{
			}
			#if error_on
			else
				Error("j9tjgj090syju5");
			#endif
				
			node_dis[z]=0;
			q.push(z);
			node_v[z]=1;
		}
		
		
		/*
		for(i=0;i<enermy_n;i++)
		{
			if(do_not_attack[i])
				continue;
			
			if(Enermy_status_is(i,string_disabled,perception_id))
				continue;
				
			if(!Enermy_get_node(i,zs,perception_id))
				continue;
				
			z=Node_name_string_to_int(zs);
			
			if(!node_can_visit[z][agent_pi])
				continue;
				
			node_dis[z]=0;
			q.push(z);
			node_v[z]=1;
		}*/
				
		
		while(q.size())
		{
			a=q.front();
			q.pop();
			for(i=1;i<=node_edge_n[a];i++)
			{
				b=node_edge[a][i];
				if(node_v[b])
					continue;
				
				if(node_dis[b]!=-1 && node_dis[b]<=node_dis[a]+1)
					continue;
					
				node_dis[b]=node_dis[a]+1;
				node_v[b]=1;
				
				if(node_bound[b]==0)
					continue;
					
				q.push(b);		
			}			
		}
		
		
		z=-1;
		for(i=1;i<=n;i++)
		if(node_bound[i]==0 && node_v[i])
		if(z<0 || node_dis[i]<node_dis[z])z=i;
		
		if(z<0)
		{
			return 0;
		}
		
		for(i=1;i<=n;i++)
		if(node_bound[i]==0 && node_v[i])
		if(node_dis[i]==node_dis[z])node_bound[i]=1;
		
		#if error_on
		if(node_dis[z]<0)
			Error("s45i65ytsw45i");
		#endif
			
		#if log_on
			log[agent_pi].writeln("Agent_on_the_edge_of_survey_zone_near_enermy(agent_pi) 2");
		#endif
			
		return node_dis[agent_position_int[agent_pi]]==node_dis[z];	
	}
	
	
	vector<int> Agent_go_to_unkown_place_near_enermy(int agent_pi)
	{
		#if log_on
			log[agent_pi].writeln("Agent_go_to_unkown_place_near_enermy(agent_pi) 1");
		#endif
	
		int i,j,a,b,z,w;
		string zs;
		int n=node_n;
				
		for(i=1;i<=n;i++)node_bound[i]=-1;
		for(i=1;i<=n;i++)
		if(!node_is_surveyed[i])node_bound[i]=0;
		
		
		queue<int> q;
		while(q.size())q.pop();
		for(i=1;i<=n;i++)
		{
			node_dis[i]=-1;
			node_v[i]=0;
		}
		
		
		///s
		
		{
			i=agent_attack_target_is[agent_pi];
			/*
			if(i<0)
				Error("f0i4ug432u3yq");
			*/
			#if error_on
			if(do_not_attack[i])
				Error("jjjg8gureug43");
			
			if(Enermy_status_is(i,string_disabled,perception_id))
				Error("gjrjberbjh8s5");
			#endif
				
			if(Enermy_get_node(i,zs,perception_id))
			{
			}
			#if error_on
			else
				Error("vmfdbmrij9h35");
			#endif
				
			z=Node_name_string_to_int(zs);
			
			if(node_can_visit[z][agent_pi])
			{
			}
			#if error_on
			else
				Error("vdsivirg09h5");
			#endif
			
			node_bound[z]=1;
			
			node_dis[z]=0;
			q.push(z);
			node_v[z]=1;
		}
		
		/*
		for(i=0;i<enermy_n;i++)
		{
			if(do_not_attack[i])
				continue;
			
			if(Enermy_status_is(i,string_disabled,perception_id))
				continue;
				
			if(!Enermy_get_node(i,zs,perception_id))
				continue;
				
			z=Node_name_string_to_int(zs);
			
			if(!node_can_visit[z][agent_pi])
				continue;
				
			node_bound[z]=1;
			
			node_dis[z]=0;
			q.push(z);
			node_v[z]=1;
		}*/
		
		
		while(q.size())
		{
			if(node_v[agent_position_int[agent_pi]])
				break;
				
			a=q.front();
			q.pop();
			for(i=1;i<=node_edge_n[a];i++)
			{
				if(node_v[agent_position_int[agent_pi]])
					break;
				
				b=node_edge[a][i];
				if(node_v[b])continue;
				//if(node_bound[b]==-1)continue;				
				if(node_dis[b]!=-1 && node_dis[b]<=node_dis[a]+1)continue;
				node_dis[b]=node_dis[a]+1;
				node_v[b]=1;
				q.push(b);
			}			
		}
		
		int da=-1,cost;
		for(i=1;i<=node_edge_n[agent_position_int[agent_pi]];i++)
		{
			z=node_edge[agent_position_int[agent_pi]][i];
			w=node_edge_value[agent_position_int[agent_pi]][i];
			if(node_bound[z]==0 && node_v[z])
			{
				if(da<0)
				{
					da=z;
					cost=w;
					continue;
				}
				if(node_dis[da]<node_dis[z])continue;
				if(node_dis[da]==node_dis[z] && cost<w)continue;
				da=z;
				cost=w;
			}
		}

		#if error_on
		if(da==-1)
		{
			Error("erusrjus "+agent_name[agent_pi]);
		}	
		#endif
		
		vector<int> ret;
		ret.clear();
		ret.push_back(da);
		
		#if log_on
			log[agent_pi].writeln("Agent_go_to_unkown_place_near_enermy(agent_pi) 2");
		#endif
		return ret;
	}
	
	vector<int> Agent_go_to_edge_of_surveyed_zone_near_repairer_place_with_smallest_edge(int agent_pi)
	{
		#if log_on
			log[agent_pi].writeln("Agent_go_to_edge_of_surveyed_zone_near_repairer_place_with_smallest_edge(agent_pi) 1");
		#endif
	
		int i,flag,z;
		int a,b;
		string zs;
		int n=node_n;
			
		for(i=1;i<=n;i++)node_bound[i]=-1;
				
		for(i=1;i<=n;i++)
		if(node_is_surveyed[i] && node_can_visit_through_surveyed_node[i][agent_pi])node_bound[i]=0;
		
		queue<int> q;
		while(q.size())q.pop();
		
		for(i=1;i<=n;i++)
		{
			node_dis[i]=-1;
			node_v[i]=0;
		}
		
		
		for(i=0;i<agent_n;i++)
		{
			if(agent_role[i]!=string_repairer)
				continue;
			if(i==agent_pi)
				continue;
			if(agent_health[i]==0)
				continue;
			z=(agent_position_int[i]);
			
			
			if(!node_can_visit[z][agent_pi])continue;
			node_dis[z]=0;
			q.push(z);
			node_v[z]=1;
		}
		
		while(q.size())
		{
			a=q.front();
			q.pop();
			for(i=1;i<=node_edge_n[a];i++)
			{
				b=node_edge[a][i];
				if(node_v[b])
					continue;
				
				if(node_dis[b]!=-1 && node_dis[b]<=node_dis[a]+1)
					continue;
					
				node_dis[b]=node_dis[a]+1;
				node_v[b]=1;
				
				if(node_bound[b]==0)
					continue;
					
				q.push(b);		
			}			
		}
		
		
		z=-1;
		for(i=1;i<=n;i++)
		if(node_bound[i]==0 && node_v[i])
		if(z<0 || node_dis[i]<node_dis[z])z=i;
		
		#if error_on
		if(z<0)
			Error("56a45trj65");
		#endif
		
		for(i=1;i<=n;i++)
		if(node_bound[i]==0 && node_v[i])
		if(node_dis[i]==node_dis[z])node_bound[i]=1;
		
		#if error_on
		if(node_dis[z]<0)
			Error("7oru55ixty987q34");
		#endif

	
		vector<int> ret;
		ret = Bfs_run(agent_position_int[agent_pi]);	
		#if log_on	
			log[agent_pi].writeln("Agent_go_to_edge_of_surveyed_zone_near_repairer_place_with_smallest_edge(agent_pi) 2");
		#endif
		
		return ret;
	}
	
	vector<int> Agent_go_to_edge_of_surveyed_zone_near_friend_place(int agent_pi)
	{
		#if log_on
			log[agent_pi].writeln("Agent_go_to_edge_of_surveyed_zone_near_friend_place(agent_pi) 1");
		#endif
	
		int i,flag,z;
		int a,b;
		string zs;
		int n=node_n;
				
		for(i=1;i<=n;i++)node_bound[i]=-1;
		
		for(i=1;i<=n;i++)
		if(node_is_surveyed[i] && node_can_visit_through_surveyed_node[i][agent_pi])node_bound[i]=0;
		
		queue<int> q;
		while(q.size())q.pop();
		
		for(i=1;i<=n;i++)
		{
			node_dis[i]=-1;
			node_v[i]=0;
		}
		
		
		for(i=0;i<agent_n;i++)
		{
			if(i==agent_pi)
				continue;
			
			if(!Agent_have_pain_in_the_ass(i))
				continue;
				
			z=agent_position_int[i];
			
			if(!node_can_visit[z][agent_pi])continue;
			node_dis[z]=0;
			q.push(z);
			node_v[z]=1;
		}
		
		
		while(q.size())
		{
			a=q.front();
			q.pop();
			for(i=1;i<=node_edge_n[a];i++)
			{
				b=node_edge[a][i];
				if(node_v[b])
					continue;
				
				if(node_dis[b]!=-1 && node_dis[b]<=node_dis[a]+1)
					continue;
					
				node_dis[b]=node_dis[a]+1;
				node_v[b]=1;
				
				if(node_bound[b]==0)
					continue;
					
				q.push(b);		
			}			
		}
		
		z=-1;
		for(i=1;i<=n;i++)
		if(node_bound[i]==0 && node_v[i])
		if(z<0 || node_dis[i]<node_dis[z])z=i;
		
		#if error_on
		if(z<0)
			Error("56a45trj65");
		#endif
		
		for(i=1;i<=n;i++)
		if(node_bound[i]==0 && node_v[i])
		if(node_dis[i]==node_dis[z])node_bound[i]=1;
		
		#if error_on
		if(node_dis[z]<0)
			Error("7oru55ixty987q34");
		#endif

	
		vector<int> ret;
		
		
		ret = Dijkstra_run(agent_position_int[agent_pi],agent_max_energy[agent_pi]);	
		
		
		#if log_on	
			log[agent_pi].writeln("Agent_go_to_edge_of_surveyed_zone_near_friend_place(agent_pi) 2");
		#endif
		
		return ret;
	}
	
	
	
	
	
	
	
	
	
	
	
	vector<int> Agent_go_to_enermy_near_known_place(int agent_pi)
	{
		#if log_on
			log[agent_pi].writeln("Agent_go_to_enermy_near_known_place(agent_pi) 1");
		#endif
		
		int i,j,a,b,z;
		string zs;
		int n=node_n;
				
		for(i=1;i<=n;i++)node_bound[i]=-1;
		
		for(i=1;i<=n;i++)
		if(node_is_surveyed[i] && node_can_visit_through_surveyed_node[i][agent_pi])node_bound[i]=0;
		
	

		
		queue<int> q;
		while(q.size())q.pop();
		
		for(i=1;i<=n;i++)
		{
			node_dis[i]=-1;
			node_v[i]=0;
		}
		///s
		
		{			
			i=agent_attack_target_is[agent_pi];
			/*
			if(i<0)
				Error("Fj94w30tu34yqy");
			*/
			#if error_on
			if(do_not_attack[i])
				Error("j09rgjgje9uy");
				
			if(Enermy_status_is(i,string_disabled,perception_id))
				Error("jjbfmbptjodj");
			#endif
				
			if(Enermy_get_node(i,zs,perception_id))
			{
			}
			#if error_on
			else
				Error("mvdfoifjh9shr");
			#endif
				
			z=Node_name_string_to_int(zs);
			
			if(node_can_visit[z][agent_pi])
			{
			}
			#if error_on
			else
				Error("jmfdbmoirhjh5");
			#endif
				
			node_dis[z]=0;
			q.push(z);
			node_v[z]=1;
		}
		
		/*
		for(i=0;i<enermy_n;i++)
		{			
			if(do_not_attack[i])
				continue;
				
			if(Enermy_status_is(i,string_disabled,perception_id))
				continue;
				
			if(!Enermy_get_node(i,zs,perception_id))
				continue;
				
			z=Node_name_string_to_int(zs);
			
			if(!node_can_visit[z][agent_pi])
				continue;
				
			node_dis[z]=0;
			q.push(z);
			node_v[z]=1;
		}*/
				
		
		while(q.size())
		{
			a=q.front();
			q.pop();
			for(i=1;i<=node_edge_n[a];i++)
			{
				b=node_edge[a][i];
				if(node_v[b])
					continue;
				
				if(node_dis[b]!=-1 && node_dis[b]<=node_dis[a]+1)
					continue;
					
				node_dis[b]=node_dis[a]+1;
				node_v[b]=1;
				
				if(node_bound[b]==0)
					continue;
					
				q.push(b);		
			}			
		}
		
		z=-1;
		for(i=1;i<=n;i++)
		if(node_bound[i]==0 && node_v[i])
		if(z<0 || node_dis[i]<node_dis[z])z=i;
		
		#if error_on
		if(z<0)
			Error("djgarei0934ya");
		#endif
		
		for(i=1;i<=n;i++)
		if(node_bound[i]==0 && node_v[i])
		if(node_dis[i]==node_dis[z])node_bound[i]=1;
		
		#if error_on
		if(node_dis[z]<0)
			Error("09834uty983wqh4yw3y");
		#endif
		
		vector<int> ret;
		ret.clear();
		
		
		
		
		ret = Dijkstra_run(agent_position_int[agent_pi],agent_max_energy[agent_pi]);	
		
		
		
		#if log_on
			log[agent_pi].writeln("Agent_go_to_enermy_near_known_place(agent_pi) 2");
		#endif
		return ret;
	}
	
	int Agent_enermy_can_visit_through_surveyed_node(int agent_pi)
	{
		#if log_on
			log[agent_pi].writeln("Agent_enermy_can_visit_through_surveyed_node(agent_pi) 1");
		#endif
	
		int i,flag,z;
		string zs;
		
		///s
		if(agent_attack_target_is[agent_pi]>=0)
		{
			i=agent_attack_target_is[agent_pi];
			/*
			if(i<0)
				Error("jf94309yu3490yyuj");
			*/
			#if error_on
				if(Enermy_status_is(i,string_disabled,perception_id))
					Error("f90u039yu0hj");
			#endif
				
				if(Enermy_get_node(i,zs,perception_id))
				{
				}
				#if error_on
				else
					Error("j89u58y3qhyq4");
				#endif
			
				z=Node_name_string_to_int(zs);
				if(!node_can_visit_through_surveyed_node[z][agent_pi])
					return 0;
					
				return 1;
		}
		/*
		for(i=0;i<enermy_n;i++)
		{
			if(do_not_attack[i])
				continue;
			if(Enermy_status_is(i,string_disabled,perception_id))
				continue;
				
			if(!Enermy_get_node(i,zs,perception_id))
				continue;
			
			z=Node_name_string_to_int(zs);
			if(!node_can_visit_through_surveyed_node[z][agent_pi])
				continue;
						
			#if log_on	
				log[agent_pi].writeln("Agent_enermy_can_visit_through_surveyed_node(agent_pi) 2");
			#endif
				
			return 1;
		}*/
		
		
		#if log_on
			log[agent_pi].writeln("Agent_enermy_can_visit_through_surveyed_node(agent_pi) 3");
		#endif
		return 0;
	}
	
	int Agent_on_friend_pain_ass(int agent_pi,vector<int> &ret)
	{
		#if log_on
			log[agent_pi].writeln("On_friend_pain_ass(vector<int> &ret) 1");
		#endif
		
		int i;
		ret.clear();
		for(i=0;i<agent_n;i++)
		{	
			if(agent_position[i]!=agent_position[agent_pi])
				continue;
				
			if(!Agent_have_pain_in_the_ass(i))
				continue;
				
			if(i==agent_pi)
				continue;
				
			#if log_on
				log[agent_pi].writeln("On_friend_pain_ass(vector<int> &ret) 2");
			#endif
			
			ret.push_back(i);
		}
		
		#if log_on
			log[agent_pi].writeln("On_friend_pain_ass(vector<int> &ret) 3");
		#endif
		return ret.size();
	}
	
	int Agent_on_saboteur_friend_ass(int agent_pi)
	{
		#if log_on
				log[agent_pi].writeln("On_saboteur_friend_ass() 1");
		#endif
	
		int i;
		string zs;
		//z
		for(i=0;i<agent_n;i++)
		{	
			if(agent_health[i]==0)
				continue;
			
			if(i==agent_pi)
				continue;
				
			if(agent_role[i]!=string_saboteur)
				continue;
				
			if(agent_position_int[i]!=agent_position_int[agent_pi])
				continue;				
			
			#if log_on
				log[agent_pi].writeln("On_saboteur_friend_ass() 2");
			#endif
			return 1;
		}
		
		#if log_on
			log[agent_pi].writeln("On_saboteur_friend_ass() 3");
		#endif
		return 0;
	}
	
	
	int Agent_must_not_on_saboteur_enermy_ass(int agent_pi)
	{
		#if log_on
				log[agent_pi].writeln("Must_not_Agent_on_saboteur_enermy_ass(agent_pi) 1");
		#endif
		
		int i;
		string zs;
		int z;
		int ret=0;
		
		if(Agent_on_saboteur_enermy_ass(agent_pi))
			return 0;
			
		for(i=0;i<enermy_n;i++)
		{			
			if(Enermy_status_is(i,string_disabled,perception_id))
				continue;
				
			if(!Enermy_get_node(i,zs,perception_id))
				continue;
				
			if(zs!=agent_position[agent_pi])
				continue;
				
			if(enermy_role[i]!="")
				continue;
			
			#if log_on
				log[agent_pi].writeln("Agent_on_saboteur_enermy_ass(agent_pi) 2");
			#endif
			ret++;
		}
			
		if(!ret)
			return 0;

			
		if(!We_know_all_saboteur())
			return 0;
		
		#if log_on
			log[agent_pi].writeln("Must_not_Agent_on_saboteur_enermy_ass(agent_pi) 3");
		#endif
		return 1;
	}
	
	
	int Agent_near_enermy_ass(int agent_pi,int &enermy_should_attack)
	{
		#if log_on
				log[agent_pi].writeln("Near_enermy_ass() 1");
		#endif
		
		int i;
		string zs;
		for(i=0;i<enermy_n;i++)
		{	
			if(Enermy_status_is(i,string_disabled,perception_id))
				continue;
				
			if(!Enermy_get_node(i,zs,perception_id))
				continue;
			
			///xx3
			if(zs!=agent_position[agent_pi] && !Vector_find(agent_vertex_near[agent_pi],Node_name_string_to_int(zs)))
				continue;			
			
			#if log_on
				log[agent_pi].writeln("Near_enermy_ass() 2");
			#endif
				
			enermy_should_attack=i;
			return 1;
		}
		
		#if log_on
			log[agent_pi].writeln("Near_enermy_ass() 3");
		#endif
		return 0;
	}
	
	int Agent_on_enermy_ass(int agent_pi)
	{
		#if log_on
				log[agent_pi].writeln("On_enermy_ass() 1");
		#endif
	
		int i;
		string zs;
				
		for(i=0;i<enermy_n;i++)
		{	
			if(Enermy_status_is(i,string_disabled,perception_id))
				continue;
				
			if(!Enermy_get_node(i,zs,perception_id))
				continue;
			
			if(zs!=agent_position[agent_pi])
				continue;
			
			#if log_on
				log[agent_pi].writeln("On_enermy_ass() 2");
			#endif
			return 1;
		}
		
		#if log_on
			log[agent_pi].writeln("On_enermy_ass() 3");
		#endif
		return 0;
	}
	
	int Agent_on_enermy_ass(int agent_pi,vector<int> &ret)
	{
		#if log_on
				log[agent_pi].writeln("On_enermy_ass(string &ret) 1");
		#endif
		
		int i;
		ret.clear();
		
		///s
		if(agent_attack_target_is[agent_pi]>=0)
		{
			i=agent_attack_target_is[agent_pi];
			/*
			if(i<0)
				Error("jf0493u709uyq");
			*/
			#if error_on
				if(Enermy_status_is(i,string_disabled,perception_id))
					Error("904uy03y3y");
			#endif
			
			
			if(!Enermy_node_is(i,agent_position[agent_pi],perception_id))
				return 0;
				
			ret.push_back(i);
			return 1;				
		}
		
		
		for(i=0;i<enermy_n;i++)
		{
			if(Enermy_status_is(i,string_disabled,perception_id))
				continue;
			if(!Enermy_node_is(i,agent_position[agent_pi],perception_id))
				continue;
			if(do_not_attack[i])
				continue;			
			ret.push_back(i);
		}
		#if log_on
			log[agent_pi].writeln("On_enermy_ass(string &ret) 3");
		#endif
		
		return ret.size();
	}
	
	vector<int> Agent_go_to_enermy(int agent_pi)
	{
		#if log_on
			log[agent_pi].writeln("Agent_go_to_enermy(agent_pi) 1");
		#endif
		
		int i,j,b,z;
		string zs;
		int n=node_n;
		
		
		for(i=1;i<=n;i++)node_bound[i]=-1;
		for(i=1;i<=n;i++)
		if(node_is_surveyed[i])node_bound[i]=0;
		
		///s
		
		i=agent_attack_target_is[agent_pi];
		/*
		if(i<0)
			Error("JF97t309yuqy");
		*/
		#if error_on
		if(do_not_attack[i])
			Error("0y-y3jgahgghag");
						
		if(Enermy_status_is(i,string_disabled,perception_id))
			Error("0939yjjyhjaha");
		#endif	
		
			
		if(Enermy_get_node(i,zs,perception_id))
		{
		}
		#if error_on
		else
			Error("kbm-4509iyuwjuhj");
		#endif
			
		z=Node_name_string_to_int(zs);
			
		if(node_can_visit_through_surveyed_node[z][agent_pi])
		{
		}
		#if error_on
		else
			Error("9403uy3auahrea");
		#endif
		
		node_bound[z]=1;
		
		/*
			for(i=0;i<enermy_n;i++)
			{
				if(do_not_attack[i])
					continue;
			
				if(Enermy_status_is(i,string_disabled,perception_id))
					continue;
				
				if(!Enermy_get_node(i,zs,perception_id))
					continue;
				
				z=Node_name_string_to_int(zs);
			
				if(!node_can_visit_through_surveyed_node[z][agent_pi])continue;
				node_bound[z]=1;
			}
		*/
	
		vector<int> ret;
		
		ret = Dijkstra_run(agent_position_int[agent_pi],agent_max_energy[agent_pi]);	
		
	
		#if log_on		
			log[agent_pi].writeln("Agent_go_to_enermy(agent_pi) 2");
		#endif

		return ret;
	}
	
	bool Agent_find_uninspected_enermy(int agent_pi)
	{
		#if log_on
		log[agent_pi].writeln("Agent_find_uninspected_enermy(agent_pi) 1");
		#endif
		
		int i;
		int z;
		string zs;
		
				
		//for(i=0;i<enermy_n;i++)
		{
			i=agent_inspect_target_is[agent_pi];			
			if(i<0)
				return 0;
			
			if(Enermy_get_node(i,zs,perception_id))
			{
			}
			#if error_on
			else
			{
				cout<<i<<' '<<agent_pi<<' '<<Enermy_get_node(i,zs,perception_id)<<' '<<zs<<endl;
				Error("vreriohgj053uh");
			}
			#endif
				
			z=Node_name_string_to_int(zs);
			
			if(!node_can_visit[z][agent_pi])
				return 0;
				
			#if error_on				
			if(enermy_is_inspected[i])
			{
				cout<<i<<' '<<agent_pi<<endl;
				Error("jfemowigj438y");
			}
			#endif
				
			return 1;
			#if log_on
			log[agent_pi].writeln(enermy_name[i]);
			#endif
		}
		
		#if log_on
		log[agent_pi].writeln("Agent_find_uninspected_enermy(agent_pi) 2");
		#endif
		
		
		return 0;
	}
	
	bool Agent_find_enermy(int agent_pi)
	{
		#if log_on
		log[agent_pi].writeln("Agent_find_enermy(agent_pi) 1");
		#endif
		
		int i;
		int z;
		string zs;
		int ret;
		
		if(agent_attack_target_is[agent_pi]>=0)
		{
			i=agent_attack_target_is[agent_pi];
			/*
			if(i<0)
				Error("fj94utq9y4yjy54y");
					*/	
			if(!Enermy_status_is(i,string_disabled,perception_id))
			{
			}
			#if error_on
			else
				Error("90tu94jtajhaga");
			#endif
				
			if(Enermy_get_node(i,zs,perception_id))
			{
			}
			#if error_on
			else
				Error("i99h3tht3ha34y39:");
			#endif
				
			z=Node_name_string_to_int(zs);
			
			
			if(node_can_visit[z][agent_pi])
				return 1;
		}	
		/*
		for(i=0;i<enermy_n;i++)
		{			
			if(do_not_attack[i])
				continue;
			
			if(Enermy_status_is(i,string_disabled,perception_id))
				continue;
				
			if(!Enermy_get_node(i,zs,perception_id))
				continue;
				
			z=Node_name_string_to_int(zs);
			
			
			if(!node_can_visit[z][agent_pi])
				continue;
			
			#if log_on
			log[agent_pi].writeln(enermy_name[i]);
			#endif
		}
		
		for(i=0;i<enermy_n;i++)
		{			
			if(do_not_attack[i])
				continue;
			
			if(Enermy_status_is(i,string_disabled,perception_id))
				continue;
				
			if(!Enermy_get_node(i,zs,perception_id))
				continue;
				
			z=Node_name_string_to_int(zs);
			
			if(!node_can_visit[z][agent_pi])
				continue;
				
			return 1;
		}*/	
		return 0;
	}
	
	
	
	bool Agent_find_friend_has_pain_in_the_ass(int agent_pi)
	{
		#if log_on
		log[agent_pi].writeln("Agent_find_friend_has_pain_in_the_ass(agent_pi) 1");
		#endif
		
		int i,z;
		string zs;
		
		
		for(i=0;i<agent_n;i++)
		{
			if(i==agent_pi)
				continue;
				
			if(!Agent_have_pain_in_the_ass(i))
				continue;
				
			if(!node_can_visit[agent_position_int[i]][agent_pi])
				continue;
				
			#if log_on
			log[agent_pi].writeln(agent_name[i]);
			#endif			
		}
		
		#if log_on
		log[agent_pi].writeln("Agent_find_friend_has_pain_in_the_ass(agent_pi) 1");
		#endif
		
		
		for(i=0;i<agent_n;i++)
		{
			if(i==agent_pi)
				continue;
				
			if(!Agent_have_pain_in_the_ass(i))
				continue;
				
			if(!node_can_visit[agent_position_int[i]][agent_pi])
				continue;
				
			return 1;
		}
		
		return 0;						
	}
	
	
	
	
	
















///ri
	int Agent_run_mission_inspector(int agent_pi)
	{
		#if log_on
		log[agent_pi].writeln("---------------------Run_mission_inspector() 1");
		#endif
		
		int z;
		string zs;
		
		if(agent_mission[agent_pi]==string_mission_kuo)
		{
			agent_destination[agent_pi]=Agent_mission_kuo(agent_pi,agent_mission_destination[agent_pi]);
			Vector_leave_last(agent_destination[agent_pi]);
		}
		
		if(agent_mission[agent_pi]==string_mission_not_explorer_min_cost_visit_bound)
		{
			agent_destination[agent_pi]=Agent_mission_not_explorer_min_cost_visit_bound(agent_pi,agent_mission_destination[agent_pi]);
			Vector_leave_last(agent_destination[agent_pi]);
		}
		if(agent_destination[agent_pi].size())
		{
			z=agent_destination[agent_pi][agent_destination[agent_pi].size()-1];
			
			if(z==agent_position_int[agent_pi])
			{
				Protocol_recharge(agent_pi);				
			}
			else
			{
				
				if(Agent_can_go_to(agent_pi,z))
				{
				}
				#if error_on
				else
				Error("08 9y6089jhsrousy45");
				#endif
				
				
				zs=node_name_int_to_string[z];
				Protocol_goto(agent_pi,zs);			
			}
		}
		else
		{
			#if error_on
			Error("08uy398uy35aoj");
			#endif
		}
		
		#if log_on
		log[agent_pi].writeln("---------------------Run_mission_inspector() 2");
		#endif
		return 1;
	}

int Agent_run_inspector(int agent_pi)
	{
		#if log_on
		log[agent_pi].writeln("---------------------Run_inspector");
		#endif
		
		
		int i;
		int z;
		int rethink=0;
		string zs;
					
			
			
			
			
			//if(agent_name[0]=='b' && agent_name=="b3")
	//		write();
			
			//Protocol_survey(agent_pi);
			//continue;
			
			while(1)
			{						
				agent_destination[agent_pi].clear();
				
				if(agent_energy[agent_pi] <= int(agent_max_energy[agent_pi] * Agent_low_energy_rate(agent_pi)))
				{
					Protocol_recharge(agent_pi);
					break;
				}
				
				if(agent_health[agent_pi]==0)
				{
					agent_mission[agent_pi]="";	
					agent_mission_destination[agent_pi]=-1;
					
					if(!node_is_surveyed[agent_position_int[agent_pi]])
					{
						Protocol_recharge(agent_pi);
						break;
					}
				
					if(Agent_on_repairer_ass(agent_pi))
					{
						Protocol_recharge(agent_pi);
						break;
					}
					
					if(Agent_near_repairer_ass(agent_pi,zs))
					{
						#if log_on
						log[agent_pi].writeln("Near_repairer_ass() ");
						#endif
						
						Protocol_goto(agent_pi,zs);
						break;
					}
										
					if(Agent_find_repairer(agent_pi))
					{
						#if log_on
						log[agent_pi].writeln("report to WYX : find repairer");
						#endif
						
						if(Agent_repairer_is_reachable_by_surveyed_position(agent_pi))
						{
							#if log_on
							log[agent_pi].writeln("report to WYX : Repairer is in surveyed reachable node");						
							#endif
							
							agent_destination[agent_pi]=Agent_go_to_reachable_repairer_by_surveyed_position(agent_pi);
							Vector_leave_last(agent_destination[agent_pi]);
						}
						else
						{
							#if log_on
							log[agent_pi].writeln("report to WYX : Repairer is not in surveyed reachable node");
							#endif
							
							if(!Agent_on_the_edge_of_survey_zone_near_repairer(agent_pi))
							{
								#if log_on
								log[agent_pi].writeln("report to WYX : I am not on the edge of the surveyd zone near repairer. I will go to edge of the surveyd zone near pain friend.");	
								#endif
								
								agent_destination[agent_pi]=Agent_go_to_edge_of_surveyed_zone_near_repairer_place_with_smallest_edge(agent_pi);
								Vector_leave_last(agent_destination[agent_pi]);
							}								
							else
							{	
								#if log_on
								log[agent_pi].writeln("report to WYX : I am on the edge of the surveyd zone. I will recharge and wait repairer.");	
								#endif
								
								//destination=Go_to_unkown_place_near_repairer_with_smallest_edge()
								//Vector_leave_last(destination);
								Protocol_recharge(agent_pi);
								break;
							}
						}
					}
					
					if(agent_destination[agent_pi].size())
					{
						z=agent_destination[agent_pi][agent_destination[agent_pi].size()-1];
				
						if(Agent_can_go_to(agent_pi,z))
						{
						}
						#if error_on
						else
							Error("g09uy894yaq4jy4");
						#endif
						
						zs=node_name_int_to_string[z];
						Protocol_goto(agent_pi,zs);
						
						break;
					}			
			
					Protocol_recharge(agent_pi);					
					break;
				}			
				
				
				
				if(agent_health[agent_pi]<agent_max_health[agent_pi])
				{
					agent_mission[agent_pi]="";	
					agent_mission_destination[agent_pi]=-1;
		
					if(!node_is_surveyed[agent_position_int[agent_pi]])
					{
						Protocol_survey(agent_pi);
						break;
					}					
					
					if(Agent_on_repairer_ass(agent_pi))
					{
						Protocol_recharge(agent_pi);
						break;
					}
					
					if(Agent_near_repairer_ass(agent_pi,zs))
					{
						#if log_on
						log[agent_pi].writeln("Near_repairer_ass() ");
						#endif
						
						Protocol_goto(agent_pi,zs);
						break;
					}
										
					if(Agent_find_repairer(agent_pi))
					{
						#if log_on
						log[agent_pi].writeln("report to WYX : find repairer");
						#endif
						
						if(Agent_repairer_is_reachable_by_surveyed_position(agent_pi))
						{
							#if log_on
							log[agent_pi].writeln("report to WYX : Repairer is in surveyed reachable node");						
							#endif
							
							agent_destination[agent_pi]=Agent_go_to_reachable_repairer_by_surveyed_position(agent_pi);
							Vector_leave_last(agent_destination[agent_pi]);
						}
						else
						{
							#if log_on
							log[agent_pi].writeln("report to WYX : Repairer is not in surveyed reachable node");
							#endif
							
							if(!Agent_on_the_edge_of_survey_zone_near_repairer(agent_pi))
							{
								#if log_on
								log[agent_pi].writeln("report to WYX : I am not on the edge of the surveyd zone near repairer. I will go to edge of the surveyd zone near pain friend.");	
								#endif
								
								agent_destination[agent_pi]=Agent_go_to_edge_of_surveyed_zone_near_repairer_place_with_smallest_edge(agent_pi);
								Vector_leave_last(agent_destination[agent_pi]);
							}								
							else
							{	
								#if log_on
								log[agent_pi].writeln("report to WYX : I am on the edge of the surveyd zone. I will recharge and wait repairer.");	
								#endif
								
								//destination=Go_to_unkown_place_near_repairer_with_smallest_edge()
								//Vector_leave_last(destination);
								Protocol_recharge(agent_pi);
								break;
							}
						}
					}
					
					if(agent_destination[agent_pi].size())
					{
						z=agent_destination[agent_pi][agent_destination[agent_pi].size()-1];
				
						if(Agent_can_go_to(agent_pi,z))
						{
						}
						#if error_on
						else
							Error("g09uy894yaq4jy4");
						#endif
						
						zs=node_name_int_to_string[z];
						Protocol_goto(agent_pi,zs);
						
						break;
					}			
			
					Protocol_recharge(agent_pi);					
					break;
				}	
				
				
				if(Agent_on_uninspected_enermy_ass(agent_pi))
				{
					Protocol_inspect(agent_pi);
					break;
				}			
			
				if(!node_is_surveyed[agent_position_int[agent_pi]])
				{
					Protocol_survey(agent_pi);
					break;
				}
			
				if(Agent_have_pain_in_the_ass(agent_pi))
				{
					if(Agent_on_repairer_ass(agent_pi))
					{
						Protocol_recharge(agent_pi);
						break;
					}
				}
				
				
				if(!agent_destination[agent_pi].size())
				{
					if(Agent_find_uninspected_enermy(agent_pi))
					{
						#if log_on
						log[agent_pi].writeln("report to WYX : find uninspected enermy");
						#endif
						
						if(Agent_uninspected_notwanted_enermy_can_visit_through_surveyed_node(agent_pi))
						{
							///xx7
							#if log_on
							log[agent_pi].writeln("report to WYX : uninspected enermy is in surveyed reachable node");
							#endif
							
							agent_destination[agent_pi]=Agent_go_to_uninspected_enermy(agent_pi);	
							Vector_leave_last(agent_destination[agent_pi]);
						}
						else
						{
							#if log_on
							log[agent_pi].writeln("report to WYX : uninspected enermy is not in surveyed reachable node");
							#endif
							
							if(!Agent_on_the_edge_of_survey_zone_near_uninspected_notwanted_enermy(agent_pi))
							{
								#if log_on
								log[agent_pi].writeln("report to WYX : I am not on the edge of the surveyd zone near uninspected enermy. I will go to edge of the surveyd zone near uninspected enermy.");	
								#endif
								
								agent_destination[agent_pi]=Agent_go_to_uninspected_notwanted_enermy_near_known_place(agent_pi);
								Vector_leave_last(agent_destination[agent_pi]);
							}
							else
							{	
								#if log_on
								log[agent_pi].writeln("report to WYX : I am on the edge of the surveyd zone. I will go to unkown place.");
								#endif
								
								agent_destination[agent_pi]=Agent_go_to_unkown_place_near_uninspected_notwanted_enermy(agent_pi);
								Vector_leave_last(agent_destination[agent_pi]);
							}
						}
					}
				}				
			
				if(!agent_destination[agent_pi].size())
				if(Agent_have_not_surveyed_node(agent_pi))
				{
					agent_mission[agent_pi]=string_mission_not_explorer_min_cost_visit_bound;
					return 1;
					{
					//	agent_destination[agent_pi]=Not_explorer_min_cost_visit_bound();
					//	Vector_leave_last(agent_destination[agent_pi]);
					}
				}
				
				if(!agent_destination[agent_pi].size())
				{
					agent_mission[agent_pi]=string_mission_kuo;
					return 1;
					/*if(On_occupy_max_kuo_node())
					{						
						Protocol_recharge(agent_pi);
						break;
					}
					agent_destination[agent_pi]=Go_to_not_occupy_max_kuo_node();
					Vector_leave_last(agent_destination[agent_pi]);		*/
				}
			
				if(!agent_destination[agent_pi].size())
				{
					agent_destination[agent_pi]=Agent_go_to_not_occupy_max_value_node(agent_pi);
					Vector_leave_last(agent_destination[agent_pi]);
				}
			
				if(agent_destination[agent_pi].size())
				{
					z=agent_destination[agent_pi][agent_destination[agent_pi].size()-1];
				
					if(Agent_can_go_to(agent_pi,z))
					{
					}
					#if error_on
					else
					{
						Error("54ue75dikis445i");
					}
					#endif
					
					
					zs=node_name_int_to_string[z];
					Protocol_goto(agent_pi,zs);
					
					break;
				}
			
				Protocol_recharge(agent_pi);	
				break;
			}
		return 1;
	}











void Agent_del_useless_infor(vector<string> &r)
	{
		vector<string> d;
		int i;
		
		d.clear();
		for(i=0;i<r.size();i+=2)
		{
			if(r[i]==string_version)continue;
			if(r[i]==string_encoding)continue;
			if(r[i]==string_timestamp)continue;
			if(r[i]==string_type)continue;
			if(r[i]==string_deadline)continue;
		
			d.push_back(r[i]);
			
			#if error_on
			if(i+1>=r.size())
				Error("GWOHE9y4jhw4wreah");
			#endif
			
			d.push_back(r[i+1]);
		}
		
		r=d;
	}





















///agent public
	int Agent_init(int x,int x_clear_flag)
	{		
		int i;		
		
		agent_mission[x]="";	
		agent_mission_destination[x]=-1;
		
		agent_inspect_target_is[x]=-1;
		agent_attack_target_is[x]=-1;
		
		//memset(agent_auth_msg[x],0,sizeof(agent_auth_msg[x]));
		//	agent_auth_msg_n[x]=0;
		
		//memset(agent_sim_msg[x],0,sizeof(agent_sim_msg[x]));
		//	agent_sim_msg_n[x]=0;
			
		memset(agent_net_msg[x],0,sizeof(agent_net_msg[x]));
			agent_net_msg_n[x]=0;
			
		agent_buff_n[x]=0;
		memset(agent_buff[x],0,sizeof(agent_buff[x]));
		
		
		
		agent_have_auth_msg[x]=0;
		agent_have_sim_msg[x]=0;
		
		pthread_mutex_init(&(agent_pr_lock[x]), NULL);
		pthread_cond_init(&(agent_pr_net_msg_signal_start[x]),NULL);
		agent_pr_thread_start[x]=0;
	
		agent_net_msg_signal_done[x]=0;
		agent_net_msg_signal_ready[x]=0;
		agent_net_msg_signal_start[x]=0;
		
		agent_no_action_count[x]=0;
		
		agent_used_money[x]=0;
		
		agent_can_buy_battery[x]=1;
		agent_can_buy_sensor[x]=1;
		agent_can_buy_shield[x]=1;
		agent_can_buy_sabotageDevice[x]=1;
		
		
		
		
		if(Net_st(x,agent_ip,agent_port))
		{
		}
		#if error_on
		else
			Error("tj94838ya9y4");
		#endif
		
		#if log_on
		log[x].Init("./log/"+agent_name[x]+".log");
		log[x].Clear();			
		msg_file[x].Init("./msg/"+agent_name[x]+".log");
		msg_file[x].Clear();
		#endif
		
		Protocol_init(x);
		
		return 1;
	}
	
	int Agent_init2(int agent_pi)
	{
//		first_debug_pain=1;
		
		int i;		
		
		agent_inspect_target_is[agent_pi]=-1;
		agent_attack_target_is[agent_pi]=-1;
		
		agent_mission[agent_pi]="";	
		agent_mission_destination[agent_pi]=-1;
		
		agent_have_auth_msg[agent_pi]=1;	
		
		agent_no_action_count[agent_pi]=0;
		
		agent_used_money[agent_pi]=0;
		
		agent_can_buy_battery[agent_pi]=1;
		agent_can_buy_sensor[agent_pi]=1;
		agent_can_buy_shield[agent_pi]=1;
		agent_can_buy_sabotageDevice[agent_pi]=1;
		
		#if log_on					
		log[agent_pi].Init("./log/"+agent_name[agent_pi]+".log");
		msg_file[agent_pi].Init("./msg/"+agent_name[agent_pi]+".log");
		#endif
		
		
		Protocol_init(agent_pi);	
		return 1;
	}
	
	
	
///s
	int Agent_sim_start(int agent_pi)
	{
		string zs;
		vector<string> zv;
		int i;
		
		XML_to_vector(agent_pi,agent_sim_msg[agent_pi],agent_sim_msg_n[agent_pi],zv);
		Agent_del_useless_infor(zv);
		for(i=0;i<agent_sim_msg_n[agent_pi];i++)
			agent_sim_msg[agent_pi][i]=0;
		agent_sim_msg_n[agent_pi]=0;
		
		#if error_on
		if(zv.size()%2)Error("0uu349rear");
		#endif
		
		for(i=0;i<zv.size();i+=2)
		{
			if(zv[i]==string_message_timestamp)continue;
			if(zv[i]==string_message_type)
			{
				if(zv[i+1]==string_sim_start)
				{
					break;
				}
				break;
			}
		}
		
		
		for(i=0;i<zv.size();i+=2)
		{
			if(zv[i]==string_message_timestamp)continue;
			if(zv[i]==string_message_type)
			{
				if(zv[i+1]==string_sim_start)
					continue;
				return 1;
			}
				
			if(zv[i]==string_simulation_edges)
			{
				simulation_edges=String_string_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==string_simulation_id)
			{
				simulation_id=String_string_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==string_simulation_role)
			{
				agent_role[agent_pi]=zv[i+1];
				continue;
			}
			
			if(zv[i]==string_simulation_steps)
			{
				simulation_steps=String_string_to_int(zv[i+1]);
				continue;
			}
			
			///i
			if(zv[i]==string_simulation_vertices)
			{
				node_n=String_string_to_int(zv[i+1]);						
				
				for(i=1;i<=node_n;i++)
					Node_init(i);
				
				continue;
			}
			
			#if error_on
			Error("94e0809uyh5zreh");
			#endif
		}
	
		return 1;	
	}
	
	
	
	int Agent_auth_request(int agent_pi)
	{
		string zs;
		vector<string> zv;
		int i;
		//protocol[agent_pi].Auth_request(agent_name,agent_password);		
		
		//Listen();
		XML_to_vector(agent_pi,agent_auth_msg[agent_pi],agent_auth_msg_n[agent_pi],zv);
		
		for(i=0;i<agent_auth_msg_n[agent_pi];i++)
			agent_auth_msg[agent_pi][i]=0;
		agent_auth_msg_n[agent_pi]=0;
		
		Agent_del_useless_infor(zv);
		
		#if error_on
		if(zv.size()%2)	
			Error("9u054hyjwosh");
		#endif
		
		for(i=0;i<zv.size();i+=2)
		{
			if(zv[i]==string_message_timestamp)continue;
			if(zv[i]==string_message_type)continue;
			if(zv[i]==string_authentication_result)
			{
				zs=zv[i+1];
				if(zs==string_ok)
				{
					printf("%s ok\n",agent_name[agent_pi].c_str());
					return 1;			

				}
				#if error_on
				else 
					Error("[wrong] [id and password are wrong]\n");
				#endif
			}
		}
		return 0;
	}
	
	








void Agent_write(int agent_pi)
	{
		int i,z;
		
		printf("%4.d ",perception_id);
		
		printf("%c%c ",agent_role[agent_pi][0],agent_role[agent_pi][1]);
		
		if(!agent_pi)
			printf(" 0 ");
		else 
			printf("%2.d ",agent_pi);
			
		if(!agent_health[agent_pi])
			printf(" 0 ");
		else
			printf("%2.d ",agent_health[agent_pi]);
			
		if(agent_mission[agent_pi]=="")
			printf("    ");
		else
			printf("%s ",agent_mission[agent_pi].c_str());
			
		if(agent_no_action_count[agent_pi]==0)
			printf(" 0 ");
		else
			printf("%2.d ",agent_no_action_count[agent_pi]);
		printf("%s %s",agent_last_action[agent_pi].c_str(),agent_last_action_param[agent_pi].c_str());
	
		z=20-agent_last_action[agent_pi].length()-agent_last_action_param[agent_pi].length()-1;
		for(i=0;i<z;i++)
			putchar(' ');
			
		printf("%s",agent_last_action_result[agent_pi].c_str());
		z=16-agent_last_action_result[agent_pi].length();
		for(i=0;i<z;i++)
			putchar(' ');
	
		printf("%s\n",protocol_order_short[agent_pi].c_str());
	
		//printf("last_action = %s\n",last_action.c_str());
		//printf("last_action_result = %s\n",last_action_result.c_str());		
		
		
		#if log_on
		log[agent_pi].writeln("[step state =========================");
		log[agent_pi].write("id = ");
		log[agent_pi].writeln(perception_id);
		
		log[agent_pi].write("name = ");
		log[agent_pi].writeln(agent_name[agent_pi]);
		
		log[agent_pi].write("role = ");
		log[agent_pi].writeln(agent_role[agent_pi]);
		
		log[agent_pi].write("step = ");
		log[agent_pi].writeln(agent_step[agent_pi]);
		
		log[agent_pi].write("energy = ");
		log[agent_pi].writeln(agent_energy[agent_pi]);
		
		log[agent_pi].write("health = ");
		log[agent_pi].writeln(agent_health[agent_pi]);
		
		log[agent_pi].write("last_action = ");
		log[agent_pi].writeln(agent_last_action[agent_pi]);
		
		log[agent_pi].write("last_action_param = ");
		log[agent_pi].writeln(agent_last_action_param[agent_pi]);
		
		log[agent_pi].write("last_action_result = ");
		log[agent_pi].writeln(agent_last_action_result[agent_pi]);
		
		log[agent_pi].write("max_energy = ");
		log[agent_pi].writeln(agent_max_energy[agent_pi]);
		
		log[agent_pi].write("max_energy_disabled = ");
		log[agent_pi].writeln(agent_max_energy_disabled[agent_pi]);
		
		log[agent_pi].write("max_health = ");
		log[agent_pi].writeln(agent_max_health[agent_pi]);
		
		log[agent_pi].write("position = ");
		log[agent_pi].write(agent_position_int[agent_pi]);
		log[agent_pi].writeln(" "+agent_position[agent_pi]);
		
		log[agent_pi].write("strength = ");
		log[agent_pi].writeln(agent_strength[agent_pi]);
		
		log[agent_pi].write("vis_range = ");
		log[agent_pi].writeln(agent_vis_range[agent_pi]);
		
		log[agent_pi].write("team money = ");
		log[agent_pi].writeln(agent_team_money[agent_pi]);
		
		log[agent_pi].write("used money = ");
		log[agent_pi].writeln(agent_used_money[agent_pi]);
		
		log[agent_pi].write("can_buy_battery = ");
		log[agent_pi].writeln(agent_can_buy_battery[agent_pi]);
		
		log[agent_pi].write("can_buy_sensor = ");
		log[agent_pi].writeln(agent_can_buy_sensor[agent_pi]);
		
		log[agent_pi].write("can_buy_shield = ");
		log[agent_pi].writeln(agent_can_buy_shield[agent_pi]);
		
		log[agent_pi].write("can_buy_sabotageDevice = ");
		log[agent_pi].writeln(agent_can_buy_sabotageDevice[agent_pi]);
		#endif
		
		
		
		int a,b,j;
		int n=node_n;
		z=0;
		for(i=1;i<=n;i++)
		if(node_is_surveyed[i])
			z++;
		
		#if log_on
		log[agent_pi].write("surveyed node / all node number = ");
		log[agent_pi].write(z);
		log[agent_pi].write(" / ");
		log[agent_pi].writeln(n);
		#endif
		
		
		a=b=0;
		for(i=1;i<=n;i++)
		{
			for(j=1;j<=node_edge_n[i];j++)
			{
				b++;
				if(node_edge_is_surveyed[i][j])
					a++;
			}
		}
		
		#if log_on
		log[agent_pi].write("surveyed edge / all edge number = ");
		log[agent_pi].write(a);
		log[agent_pi].write(" / ");
		log[agent_pi].writeln(b);
		#endif
		
		
		
		a=b=0;
		for(i=1;i<=n;i++)
		{			
			b++;
			if(node_is_probed[i])
				a++;
		}
		
		#if log_on
		log[agent_pi].write("probed node / all node number = ");
		log[agent_pi].write(a);
		log[agent_pi].write(" / ");
		log[agent_pi].writeln(b);
		
		
		
		
		a=b=0;
		for(i=0;i<agent_n;i++)
		{			
			if(Agent_have_pain_in_the_ass(i))
				a++;
			b++;
		}
		
		log[agent_pi].write("repaiered agent / all pain agent number = ");
		log[agent_pi].write(a);
		log[agent_pi].write(" / ");
		log[agent_pi].writeln(b);
		
		a=b=0;
		for(i=0;i<enermy_n;i++)
		{			
			if(enermy_is_inspected[i])
				a++;
			b++;
		}
		
		log[agent_pi].write("inspected enermy agent / all seen agent number = ");
		log[agent_pi].write(a);
		log[agent_pi].write(" / ");
		log[agent_pi].writeln(b);
		
		log[agent_pi].write("visible entity number = ");
		log[agent_pi].writeln(visible_entity_name.size());
		log[agent_pi].writeln("]step state =========================");
		log[agent_pi].write();
		
		#endif
	}

///c
	void Agent_calc_value_for_agent_in_kuo_mission(int A,int agent_pi)
	{
		#if log_on
			log[agent_pi].writeln("Calc_value_for_agent_in_kuo_mission() 1");
		#endif
		int i,j,b,z;
		string zs;
		int s=0;
		int n=node_n;
		
				
		for(i=1;i<=n;i++)
			node_bound[i]=-1;
		for(i=1;i<=n;i++)
		if(node_is_surveyed[i])node_bound[i]=0;
		
		
		Dijkstra_run_calc_value_for_agent(agent_position_int[agent_pi],agent_pi,agent_max_energy[agent_pi]);
		
		
		for(i=1;i<=n;i++)
		node_v[i]=0;
		
		for(i=0;i<kuo_d_d[A][0].size();i++)
		node_v[kuo_d_d[A][0][i]]=1;
		
		for(i=1;i<=n;i++)
		if(node_v[i])
		{
			node_bound[i]=1;
			s++;
		}
		
		if(node_bound[agent_position_int[agent_pi]]<0)
		{
			node_bound[agent_position_int[agent_pi]]=1;
			s++;
		}
		
		for(i=1;i<=n;i++)
		if(node_bound[i]!=1)
		node_value_for_agent[i][agent_pi]=oo;
		
		int flag=0;
		s=0;
		for(i=1;i<=n;i++)
		if(node_value_for_agent[i][agent_pi]<oo)
		{
			flag=1;
			s++;
		}
		
		#if error_on
		if(!flag)
		{			
			Error("j4t43a8yujrga");
		}
		#endif
		
		#if log_on
			log[agent_pi].writeln("Calc_value_for_agent_in_kuo_mission() 2");
		#endif
	}
	
	void Agent_calc_value_for_agent_in_servey_mission(int agent_pi)
	{
		#if log_on
			log[agent_pi].writeln("Calc_value_for_agent_in_servey_mission() 1");
		#endif
		int i,j,b,z;
		string zs;
		int n=node_n;
				
		for(i=1;i<=n;i++)
			node_bound[i]=-1;
		for(i=1;i<=n;i++)
		if(node_is_surveyed[i] && node_can_visit_through_surveyed_node[i][agent_pi])
		{
			node_bound[i]=0;
		}
			
						
		
		Dijkstra_run_calc_value_for_agent(agent_position_int[agent_pi],agent_pi,agent_max_energy[agent_pi]);
		
		
		for(i=1;i<=n;i++)
		if(node_bound[i]==-1 && node_can_visit_through_surveyed_node[i][agent_pi])
		{
			for(j=1;j<=node_edge_n[i];j++)
			{
				b=node_edge[i][j];
				if(node_bound[b]==0)
				{
					node_bound[i]=1;
					break;
				}
			}
		}
		
		for(i=1;i<=n;i++)
		if(node_bound[i]!=1)
		node_value_for_agent[i][agent_pi]=oo;
				
		#if log_on
			log[agent_pi].writeln("Calc_value_for_agent_in_servey_mission() 2");
		#endif
	}

void Agent_calc_value_for_agent_in_probe_mission(int agent_pi)
	{
		#if log_on
			log[agent_pi].writeln("Calc_value_for_agent_in_probe_mission() 1");
		#endif
		int i,j,b,z;
		string zs;
		int n=node_n;
				
		for(i=1;i<=n;i++)
			node_bound[i]=-1;
		for(i=1;i<=n;i++)
		if(node_is_probed[i] && node_is_surveyed[i] && node_can_visit_through_surveyed_node[i][agent_pi])node_bound[i]=0;
		
				
		
		Dijkstra_run_calc_value_for_agent(agent_position_int[agent_pi],agent_pi,agent_max_energy[agent_pi]);
		
		
		for(i=1;i<=n;i++)
		if(node_bound[i]==-1 && node_can_visit_through_surveyed_node[i][agent_pi])
		{
			for(j=1;j<=node_edge_n[i];j++)
			{
				b=node_edge[i][j];
				if(node_bound[b]==0)
				{
					node_bound[i]=1;
					break;
				}
			}
		}
		
		
		for(i=1;i<=n;i++)
		if(node_bound[i]!=1)
		node_value_for_agent[i][agent_pi]=oo;
			
		#if log_on
			log[agent_pi].writeln("Calc_value_for_agent_in_probe_mission() 2");
		#endif
	}
	


void Agent_arrange_mission_explorer_min_cost_visit_bound(int agent_pi)
	{
		#if log_on
			log[agent_pi].writeln("=======================Arrange_mission_explorer_min_cost_visit_bound()");
		#endif
		
		int i,j,b,z;
		string zs;
		vector<int> agent_in_mission;
		vector<int> mission_node;
		mission_node.clear();
		agent_in_mission.clear();
		
		
		{
		
			for(i=0;i<agent_n;i++)
			{
				if(agent_mission[i]!=string_mission_explorer_min_cost_visit_bound)			
					continue;
			
				agent_in_mission.push_back(i);
				Agent_calc_value_for_agent_in_probe_mission(i);
			}
		}
				
		Maximum_cost_perfect_matching(agent_in_mission,mission_node);
		
		#if error_on
		if(mission_node.size()!=agent_in_mission.size())
		Error("pioeruy98s5rhg");
		#endif
		
		for(i=0;i<agent_in_mission.size();i++)
		{
			agent_mission_destination[agent_in_mission[i]]=mission_node[i];
		}
		
		#if log_on			
			log[agent_pi].writeln("=======================Arrange_mission_explorer_min_cost_visit_bound()");
		#endif
	}

void Agent_arrange_mission_not_explorer_min_cost_visit_bound(int agent_pi)
	{
		#if log_on
			log[agent_pi].writeln("=======================Arrange_mission_not_explorer_min_cost_visit_bound() 1");
		#endif
		
		int i,j,b,z;
		string zs;
		vector<int> agent_in_mission;
		vector<int> mission_node;
		agent_in_mission.clear();
		
		for(i=0;i<agent_n;i++)
		{
			if(agent_mission[i]!=string_mission_not_explorer_min_cost_visit_bound)			
				continue;
			
			agent_in_mission.push_back(i);
			Agent_calc_value_for_agent_in_servey_mission(i);
		}
				
		Maximum_cost_perfect_matching(agent_in_mission,mission_node);
		
		#if error_on
		if(mission_node.size()!=agent_in_mission.size())
		Error("e4us548445u743q");
		#endif
		
		for(i=0;i<agent_in_mission.size();i++)
		{
			agent_mission_destination[agent_in_mission[i]]=mission_node[i];
		}
		
		#if log_on			
			log[agent_pi].writeln("=======================Arrange_mission_not_explorer_min_cost_visit_bound() 2");
		#endif
	}

void Agent_arrange_mission_kuo(int A,int agent_pi)
	{
		#if log_on
			log[agent_pi].writeln("=======================Arrange_mission_kuo() 1");
		#endif

		int i,j,b,z;
		string zs;
		vector<int> agent_in_mission;
		vector<int> mission_node;
		agent_in_mission.clear();
		
		if(kuo_d_d[A][0].size()==0)
		{
			for(i=0;i<agent_n;i++)
			{
				if(agent_mission[i]!=string_mission_kuo)			
					continue;
					
				if(agent_mission_param[i]!=A)
					continue;
				
			
				agent_in_mission.push_back(i);
				mission_node.push_back(agent_position_int[i]);
			}
		}
		else
		for(i=0;i<agent_n;i++)
		{
			if(agent_mission[i]!=string_mission_kuo)			
				continue;
				
			if(agent_mission_param[i]!=A)
				continue;
			
			agent_in_mission.push_back(i);
			Agent_calc_value_for_agent_in_kuo_mission(A,i);
		}
		
		
		
		MM_run(agent_in_mission,mission_node);
		
		#if error_on
		if(mission_node.size()!=agent_in_mission.size())
		Error("e4us548445u743q");
		#endif
		/*
		cout<<A<<endl;
		for(i=0;i<agent_in_mission.size();i++)
			cout<<agent_in_mission[i]<<' '<<mission_node[i]<<endl;
		*/
		for(i=0;i<agent_in_mission.size();i++)
		{
			agent_mission_destination[agent_in_mission[i]]=mission_node[i];
		}
		
		#if log_on			
			log[agent_pi].writeln("=======================Arrange_mission_kuo() 2");
		#endif
	}
	


	#if log_on	
	void Agent_write_net_msg(int agent_pi,char r[],int rn)
	{
		msg_file[agent_pi].writeln(rn);
		msg_file[agent_pi].writeln_chars(r,rn);
	}
	#endif


	
void Agent_listen(int agent_pi)
	{
		//net_msg_signal_ready=1;
	//	net_msg_signal_ready=1;
		
		int i;
		
		
		if(!agent_have_auth_msg[agent_pi])
		{			
			while(Net_listen(agent_pi,agent_buff[agent_pi],max_msg_length,agent_buff_n[agent_pi],agent_net_msg_signal_ready[agent_pi]))	
			{			
				if(String_add_until_0(agent_auth_msg[agent_pi],agent_auth_msg_n[agent_pi],agent_buff[agent_pi],agent_buff_n[agent_pi]))
					break;
			}

			
			agent_have_auth_msg[agent_pi]=1;
			
			#if log_on
			Agent_write_net_msg(agent_pi,agent_auth_msg[agent_pi],agent_auth_msg_n[agent_pi]);	
			#endif
		}
		
		if(!agent_have_sim_msg[agent_pi])
		{
			while(Net_listen(agent_pi,agent_buff[agent_pi],min_msg_length,agent_buff_n[agent_pi],agent_net_msg_signal_ready[agent_pi]))
				if(String_add_until_0(agent_sim_msg[agent_pi],agent_sim_msg_n[agent_pi],agent_buff[agent_pi],agent_buff_n[agent_pi]))
					break;
					
			agent_have_sim_msg[agent_pi]=1;
			
			#if log_on
			Agent_write_net_msg(agent_pi,agent_sim_msg[agent_pi],agent_sim_msg_n[agent_pi]);
			#endif
		}
		
		while(1)
		{
			///z
			while(Net_listen(agent_pi,agent_buff[agent_pi],max_msg_length,agent_buff_n[agent_pi],agent_net_msg_signal_ready[agent_pi]))
			{
				if(String_add_until_0(agent_net_msg[agent_pi],agent_net_msg_n[agent_pi],agent_buff[agent_pi],agent_buff_n[agent_pi]))
					break;
					
					
			}		
			
			
			
			#if log_on
			Agent_write_net_msg(agent_pi,agent_net_msg[agent_pi],agent_net_msg_n[agent_pi]);
			#endif
			
			if(agent_buff_n[agent_pi]==0)
				break;
			
			while(1)
			{
				for(i=0;i<agent_net_msg_n[agent_pi];i++)
					agent_net_msg[agent_pi][i]=0;
				agent_net_msg_n[agent_pi]=0;
				if(!String_add_until_0(agent_net_msg[agent_pi],agent_net_msg_n[agent_pi],agent_buff[agent_pi],agent_buff_n[agent_pi]))
					break;
		//		Write_net_msg(net_msg,net_msg_n);
			}
		}	
	}
	












///rr	
	int Agent_run_mission_repairer(int agent_pi)
	{
		int z;
		string zs;
		
		if(agent_mission[agent_pi]==string_mission_kuo)
		{
			agent_destination[agent_pi]=Agent_mission_kuo(agent_pi,agent_mission_destination[agent_pi]);
			Vector_leave_last(agent_destination[agent_pi]);
		}
		
		if(agent_mission[agent_pi]==string_mission_not_explorer_min_cost_visit_bound)
		{
			agent_destination[agent_pi]=Agent_mission_not_explorer_min_cost_visit_bound(agent_pi,agent_mission_destination[agent_pi]);
			Vector_leave_last(agent_destination[agent_pi]);
		}
		if(agent_destination[agent_pi].size())
		{
			z=agent_destination[agent_pi][agent_destination[agent_pi].size()-1];
				
			if(z==agent_position_int[agent_pi])
			{
				Protocol_recharge(agent_pi);				
			}
			else
			{
				
				if(Agent_can_go_to(agent_pi,z))
				{
				}
				#if error_on
				else				
				Error("08 9y6089jhsrousy45");
				#endif
				
				zs=node_name_int_to_string[z];
				Protocol_goto(agent_pi,zs);			
			}	
		}
		else
		{
			#if error_on
			Error("34y335uaqgw3eur8");
			#endif
		}
		return 1;
	}
	
	int Agent_run_repairer(int agent_pi)
	{
		#if log_on
		log[agent_pi].writeln("---------------------Run_repairer()	");
		#endif
		
		int i;
		int z;
		int rethink=0;
		string zs;
		vector<int> zv;		
			//if(agent_name[0]=='b' && agent_name=="b3")
			//write();
			
			//Protocol_survey(agent_pi);
			//continue;
			
			while(1)			
			{			
				//z
				/*
				protocol[agent_pi].Parry();
					break;
					
				if(energy ==0)
				{
					Protocol_recharge(agent_pi);
					break;
				}
				*/
				
				
				/*
				if(On_enermy_ass())
				{
					if(Agent_on_saboteur_enermy_ass(agent_pi))
					if(!On_saboteur_friend_ass())
					{
						protocol[agent_pi].Parry();
						break;
					}
				
					if(!Must_not_Agent_on_saboteur_enermy_ass(agent_pi))
					if(Have_not_parryed_unkown_role_enermy_on_ass())
					{
						protocol[agent_pi].Parry();
						break;
					}
				}
				*/
				
				agent_destination[agent_pi].clear();
				
				if(agent_energy[agent_pi] <= int(agent_max_energy[agent_pi] * Agent_low_energy_rate(agent_pi)))
				{
					Protocol_recharge(agent_pi);
					break;
				}
				/*
				protocol[agent_pi].Parry();
				break;
				*/
			/*	if(agent_health[agent_pi]==0)
				{
					agent_mission[agent_pi]="";	
					agent_mission_destination[agent_pi]=-1;
		
					if(Agent_on_friend_pain_ass(agent_pi,zv))
					{				
						z=Should_repair_friend(zv);
						zs=agent_name[z];
						Protocol_repair(agent_pi,zs);
						break;
					}
			
					
					
					if(!node_is_surveyed[agent_position_int[agent_pi]])
					{
						Protocol_recharge(agent_pi);
						break;
					}
				
					if(Agent_on_repairer_ass(agent_pi))
					{
						Protocol_recharge(agent_pi);
						break;
					}
					
					if(Agent_near_repairer_ass(agent_pi,zs))
					{
						#if log_on
						log[agent_pi].writeln("Near_repairer_ass() ");
						#endif
						
						Protocol_goto(agent_pi,zs);
						break;
					}
										
					if(Agent_find_repairer(agent_pi))
					{
						#if log_on
						log[agent_pi].writeln("report to WYX : find repairer");
						#endif
						
						if(Agent_repairer_is_reachable_by_surveyed_position(agent_pi))
						{
							#if log_on
							log[agent_pi].writeln("report to WYX : Repairer is in surveyed reachable node");						
							#endif
							
							agent_destination[agent_pi]=Agent_go_to_reachable_repairer_by_surveyed_position(agent_pi);
							Vector_leave_last(agent_destination[agent_pi]);
						}
						else
						{
							#if log_on
							log[agent_pi].writeln("report to WYX : Repairer is not in surveyed reachable node");
							#endif
							
							if(!Agent_on_the_edge_of_survey_zone_near_repairer(agent_pi))
							{
								#if log_on
								log[agent_pi].writeln("report to WYX : I am not on the edge of the surveyd zone near repairer. I will go to edge of the surveyd zone near pain friend.");	
								#endif
								
								agent_destination[agent_pi]=Agent_go_to_edge_of_surveyed_zone_near_repairer_place_with_smallest_edge(agent_pi);
								Vector_leave_last(agent_destination[agent_pi]);
							}								
							else
							{	
								#if log_on
								log[agent_pi].writeln("report to WYX : I am on the edge of the surveyd zone. I will recharge and wait repairer.");	
								#endif
								
								//agent_destination[agent_pi]=Go_to_unkown_place_near_repairer_with_smallest_edge()
								//Vector_leave_last(agent_destination[agent_pi]);
								Protocol_recharge(agent_pi);
								break;
							}
						}
					}
					
					if(agent_destination[agent_pi].size())
					{
						z=agent_destination[agent_pi][agent_destination[agent_pi].size()-1];
				
						if(Agent_can_go_to(agent_pi,z))
						{
						}
						#if error_on
						else
							Error("g09uy894yaq4jy4");
						#endif
						
						zs=node_name_int_to_string[z];
						Protocol_goto(agent_pi,zs);
						break;
					}
			
					Protocol_recharge(agent_pi);					
					break;
				}			
				
				
				
				if(agent_health[agent_pi]<agent_max_health[agent_pi])
				{
					agent_mission[agent_pi]="";	
					agent_mission_destination[agent_pi]=-1;
		
					if(Agent_on_friend_pain_ass(agent_pi,zv))
					{				
						z=Should_repair_friend(zv);
						zs=agent_name[z];
						Protocol_repair(agent_pi,zs);
						break;
					}
			
					
					if(!node_is_surveyed[agent_position_int[agent_pi]])
					{
						Protocol_survey(agent_pi);
						break;
					}
					
					
					if(Agent_on_repairer_ass(agent_pi))
					{
						Protocol_recharge(agent_pi);
						break;
					}
					
					if(Agent_near_repairer_ass(agent_pi,zs))
					{
						#if log_on
						log[agent_pi].writeln("Near_repairer_ass() ");
						#endif
						
						Protocol_goto(agent_pi,zs);
						break;
					}
										
					if(Agent_find_repairer(agent_pi))
					{
						#if log_on
						log[agent_pi].writeln("report to WYX : find repairer");
						#endif
						
						if(Agent_repairer_is_reachable_by_surveyed_position(agent_pi))
						{
							#if log_on
							log[agent_pi].writeln("report to WYX : Repairer is in surveyed reachable node");						
							#endif
							
							agent_destination[agent_pi]=Agent_go_to_reachable_repairer_by_surveyed_position(agent_pi);
							Vector_leave_last(agent_destination[agent_pi]);
						}
						else
						{
							#if log_on
							log[agent_pi].writeln("report to WYX : Repairer is not in surveyed reachable node");
							#endif
							
							if(!Agent_on_the_edge_of_survey_zone_near_repairer(agent_pi))
							{
								#if log_on
								log[agent_pi].writeln("report to WYX : I am not on the edge of the surveyd zone near repairer. I will go to edge of the surveyd zone near pain friend.");
								#endif
																
								agent_destination[agent_pi]=Agent_go_to_edge_of_surveyed_zone_near_repairer_place_with_smallest_edge(agent_pi);
								Vector_leave_last(agent_destination[agent_pi]);
							}								
							else
							{	
								#if log_on
								log[agent_pi].writeln("report to WYX : I am on the edge of the surveyd zone. I will recharge and wait repairer.");	
								#endif
								
								//agent_destination[agent_pi]=Go_to_unkown_place_near_repairer_with_smallest_edge()
								//Vector_leave_last(agent_destination[agent_pi]);
								Protocol_recharge(agent_pi);
								break;
							}
						}
					}
					
					if(agent_destination[agent_pi].size())
					{
						z=agent_destination[agent_pi][agent_destination[agent_pi].size()-1];
				
						if(Agent_can_go_to(agent_pi,z))
						{
						}
						#if error_on
						else
							Error("g09uy894yaq4jy4");
						#endif
				
						zs=node_name_int_to_string[z];
						Protocol_goto(agent_pi,zs);
						break;
					}		
			
					Protocol_recharge(agent_pi);					
					break;
				}	
				*/
				
				//////
				if(Agent_on_friend_pain_ass(agent_pi,zv))
				{				
					z=Should_repair_friend(zv);
					zs=agent_name[z];
					Protocol_repair(agent_pi,zs);
					break;
				}
			
				if(!node_is_surveyed[agent_position_int[agent_pi]])
				{
					Protocol_survey(agent_pi);
					break;
				}
			
				if(!agent_destination[agent_pi].size())
				{
					////
					if(Agent_find_friend_has_pain_in_the_ass(agent_pi))
					{
						#if log_on
						log[agent_pi].writeln("report to WYX : find pain friend");
						#endif
						
						if(Agent_pain_friend_is_reachable_by_surveyed_position(agent_pi))
						{
							#if log_on
							log[agent_pi].writeln("report to WYX : pain friend is in surveyed reachable node");						
							#endif
							
							agent_destination[agent_pi]=Agent_go_to_reachable_friend_by_surveyed_position(agent_pi);
							Vector_leave_last(agent_destination[agent_pi]);
						}
						else
						{
							#if log_on
							log[agent_pi].writeln("report to WYX : pain friend is not in surveyed reachable node");
							#endif
							
							if(!Agent_on_the_edge_of_survey_zone_near_friend(agent_pi))
							{
								#if log_on
								log[agent_pi].writeln("report to WYX : I am not on the edge of the surveyd zone near pain friend. I will go to edge of the surveyd zone near pain friend.");	
								#endif
								
								agent_destination[agent_pi]=Agent_go_to_edge_of_surveyed_zone_near_friend_place(agent_pi);
								Vector_leave_last(agent_destination[agent_pi]);
							}	
							
							else
							{	
								#if log_on
								log[agent_pi].writeln("report to WYX : I am on the edge of the surveyd zone. I will go to unkown place and find pain friend.");	
								#endif
								
								agent_destination[agent_pi]=Agent_go_to_unkown_place_near_friend(agent_pi);
								Vector_leave_last(agent_destination[agent_pi]);
							}
						}
					}
				}
				
				if(!agent_destination[agent_pi].size())
				if(Agent_have_not_surveyed_node(agent_pi))
						{
							#if log_on
							log[agent_pi].writeln("report to WYX : I can not find enermy. I will explorer map.");
							#endif
							
							agent_mission[agent_pi]=string_mission_not_explorer_min_cost_visit_bound;
							return 1;
						//	agent_destination[agent_pi]=Not_explorer_min_cost_visit_bound();
						//	Vector_leave_last(agent_destination[agent_pi]);
						}
				
				/*
				if(!agent_destination[agent_pi].size())
				{
					if(On_occupy_max_kuo_node())
					{						
						Protocol_recharge(agent_pi);
						break;
					}
					agent_destination[agent_pi]=Go_to_not_occupy_max_kuo_node();
					Vector_leave_last(agent_destination[agent_pi]);		
				}*/
			
				if(!agent_destination[agent_pi].size())
				{
					agent_destination[agent_pi]=Agent_go_to_not_occupy_max_value_node(agent_pi);
					
					Vector_leave_last(agent_destination[agent_pi]);
				}
			
				if(agent_destination[agent_pi].size())
				{
				
				
					z=agent_destination[agent_pi][agent_destination[agent_pi].size()-1];
				
					if(Agent_can_go_to(agent_pi,z))
					{
					}
					#if error_on
					else
					{
						Error("g09uy894yaq4jy4");
					}
					#endif
					
					zs=node_name_int_to_string[z];
					Protocol_goto(agent_pi,zs);
					break;
				}
				
				Protocol_recharge(agent_pi);	
				break;		
			}
		return 1;
	}


	///rs
	int Agent_run_mission_sentinel(int agent_pi)
	{
		int z;
		string zs;
		
		if(agent_mission[agent_pi]==string_mission_kuo)
		{
			agent_destination[agent_pi]=Agent_mission_kuo(agent_pi,agent_mission_destination[agent_pi]);
			Vector_leave_last(agent_destination[agent_pi]);
		}
		
		if(agent_mission[agent_pi]==string_mission_not_explorer_min_cost_visit_bound)
		{
			agent_destination[agent_pi]=Agent_mission_not_explorer_min_cost_visit_bound(agent_pi,agent_mission_destination[agent_pi]);
			Vector_leave_last(agent_destination[agent_pi]);
		}
		if(agent_destination[agent_pi].size())
		{
			z=agent_destination[agent_pi][agent_destination[agent_pi].size()-1];
				
			if(z==agent_position_int[agent_pi])
			{
				Protocol_recharge(agent_pi);				
			}
			else
			{
				
				if(Agent_can_go_to(agent_pi,z))
				{
				}
				#if error_on
				else
				Error("08 9y6089jhsrousy45");
				#endif
				
				zs=node_name_int_to_string[z];
				Protocol_goto(agent_pi,zs);			
			}		
		}
		else
		{
			#if error_on
			Error("45o86s72w8");
			#endif
		}
		return 1;
	}
	
	int Agent_run_sentinel(int agent_pi)
	{	
		#if log_on
		log[agent_pi].writeln("---------------------Run_Sentinel");
		#endif
		
		int i;
		int z;
		int rethink=0;
		string zs;
		
			
			//if(agent_name[0]=='b' && agent_name=="b3")
			//write();
			
			//Protocol_survey(agent_pi);
			//continue;
			
			while(1)
			{				
				agent_destination[agent_pi].clear();
										
				if(agent_energy[agent_pi] <= int(agent_max_energy[agent_pi] * Agent_low_energy_rate(agent_pi)))
				{
					Protocol_recharge(agent_pi);
					break;
				}
				
				if(agent_health[agent_pi]==0)
				{
					agent_mission[agent_pi]="";	
					agent_mission_destination[agent_pi]=-1;
		
					if(!node_is_surveyed[agent_position_int[agent_pi]])
					{
						Protocol_recharge(agent_pi);
						break;
					}
				
					if(Agent_on_repairer_ass(agent_pi))
					{
						Protocol_recharge(agent_pi);
						break;
					}
					
					if(Agent_near_repairer_ass(agent_pi,zs))
					{
						#if log_on
						log[agent_pi].writeln("Near_repairer_ass() ");
						#endif
						
						Protocol_goto(agent_pi,zs);
						break;
					}
										
					if(Agent_find_repairer(agent_pi))
					{
						#if log_on
						log[agent_pi].writeln("report to WYX : find repairer");
						#endif
						
						if(Agent_repairer_is_reachable_by_surveyed_position(agent_pi))
						{
							#if log_on
							log[agent_pi].writeln("report to WYX : Repairer is in surveyed reachable node");						
							#endif
							
							agent_destination[agent_pi]=Agent_go_to_reachable_repairer_by_surveyed_position(agent_pi);
							Vector_leave_last(agent_destination[agent_pi]);
						}
						else
						{
							#if log_on							
							log[agent_pi].writeln("report to WYX : Repairer is not in surveyed reachable node");
							#endif
							
							if(!Agent_on_the_edge_of_survey_zone_near_repairer(agent_pi))
							{
								#if log_on
								log[agent_pi].writeln("report to WYX : I am not on the edge of the surveyd zone near repairer. I will go to edge of the surveyd zone near pain friend.");	
								#endif
								
								agent_destination[agent_pi]=Agent_go_to_edge_of_surveyed_zone_near_repairer_place_with_smallest_edge(agent_pi);
								Vector_leave_last(agent_destination[agent_pi]);
							}								
							else
							{	
								#if log_on
								log[agent_pi].writeln("report to WYX : I am on the edge of the surveyd zone. I will recharge and wait repairer.");	
								#endif
								
								//agent_destination[agent_pi]=Go_to_unkown_place_near_repairer_with_smallest_edge()
								//Vector_leave_last(agent_destination[agent_pi]);
								Protocol_recharge(agent_pi);
								break;
							}
						}
					}
					
					if(agent_destination[agent_pi].size())
					{
						z=agent_destination[agent_pi][agent_destination[agent_pi].size()-1];
				
						if(Agent_can_go_to(agent_pi,z))
						{
						}
						#if error_on
						else
							Error("g09uy894yaq4jy4");
						#endif
						
						zs=node_name_int_to_string[z];
						Protocol_goto(agent_pi,zs);
						break;
					}		
			
					Protocol_recharge(agent_pi);					
					break;
				}			
				
				
				
				if(agent_health[agent_pi]<agent_max_health[agent_pi])
				{
					agent_mission[agent_pi]="";	
					agent_mission_destination[agent_pi]=-1;
		
					if(!node_is_surveyed[agent_position_int[agent_pi]])
					{
						Protocol_survey(agent_pi);
						break;
					}
					
					
					if(Agent_on_repairer_ass(agent_pi))
					{
						Protocol_recharge(agent_pi);
						break;
					}
					
					if(Agent_near_repairer_ass(agent_pi,zs))
					{
						#if log_on
						log[agent_pi].writeln("Near_repairer_ass() ");
						#endif
						
						Protocol_goto(agent_pi,zs);
						break;
					}
										
					if(Agent_find_repairer(agent_pi))
					{
						#if log_on
						log[agent_pi].writeln("report to WYX : find repairer");
						#endif
						
						if(Agent_repairer_is_reachable_by_surveyed_position(agent_pi))
						{
							#if log_on
							log[agent_pi].writeln("report to WYX : Repairer is in surveyed reachable node");						
							#endif
							
							agent_destination[agent_pi]=Agent_go_to_reachable_repairer_by_surveyed_position(agent_pi);
							Vector_leave_last(agent_destination[agent_pi]);
						}
						else
						{
							#if log_on
							log[agent_pi].writeln("report to WYX : Repairer is not in surveyed reachable node");
							#endif
							
							if(!Agent_on_the_edge_of_survey_zone_near_repairer(agent_pi))
							{
								#if log_on
								log[agent_pi].writeln("report to WYX : I am not on the edge of the surveyd zone near repairer. I will go to edge of the surveyd zone near pain friend.");	
								#endif
								
								agent_destination[agent_pi]=Agent_go_to_edge_of_surveyed_zone_near_repairer_place_with_smallest_edge(agent_pi);
								Vector_leave_last(agent_destination[agent_pi]);
							}								
							else
							{	
								#if log_on
								log[agent_pi].writeln("report to WYX : I am on the edge of the surveyd zone. I will recharge and wait repairer.");	
								#endif
								
								//agent_destination[agent_pi]=Go_to_unkown_place_near_repairer_with_smallest_edge()
								//Vector_leave_last(agent_destination[agent_pi]);
								Protocol_recharge(agent_pi);
								break;
							}
						}
					}
					
					if(agent_destination[agent_pi].size())
					{
						z=agent_destination[agent_pi][agent_destination[agent_pi].size()-1];
				
						if(Agent_can_go_to(agent_pi,z))
						{
						}
						#if error_on
						else
							Error("g09uy894yaq4jy4");
						#endif
						
						zs=node_name_int_to_string[z];
						Protocol_goto(agent_pi,zs);
						break;
					}		
			
					Protocol_recharge(agent_pi);					
					break;
				}	
			
				if(!node_is_surveyed[agent_position_int[agent_pi]])
				{
					Protocol_survey(agent_pi);
					break;
				}
			
				if(!agent_destination[agent_pi].size())
				if(Agent_have_not_surveyed_node(agent_pi))
				{
					agent_mission[agent_pi]=string_mission_not_explorer_min_cost_visit_bound;
					return 1;
					{
					//	agent_destination[agent_pi]=Not_explorer_min_cost_visit_bound();
					//	Vector_leave_last(agent_destination[agent_pi]);
					}
				}
				
				if(!agent_destination[agent_pi].size())
				{
					agent_mission[agent_pi]=string_mission_kuo;
					return 1;
					/*
					if(On_occupy_max_kuo_node())
					{						
						Protocol_recharge(agent_pi);
						break;
					}
					agent_destination[agent_pi]=Go_to_not_occupy_max_kuo_node();
					Vector_leave_last(agent_destination[agent_pi]);		*/
				}
				
				if(!agent_destination[agent_pi].size())
				{
					agent_destination[agent_pi]=Agent_go_to_not_occupy_max_value_node(agent_pi);
					Vector_leave_last(agent_destination[agent_pi]);
				}
							
				if(agent_destination[agent_pi].size())
				{
					z=agent_destination[agent_pi][agent_destination[agent_pi].size()-1];
				
					if(Agent_can_go_to(agent_pi,z))
					{
					}
					#if error_on
					else
						Error("g09uy894yaq4jy4");
					#endif
					
					zs=node_name_int_to_string[z];
					Protocol_goto(agent_pi,zs);
					break;
				}
			
				Protocol_recharge(agent_pi);	
				break;
			}
		return 1;
	}

	///rs
	int Agent_run_mission_saboteur(int agent_pi)
	{
		int z;
		string zs;
		
		if(agent_mission[agent_pi]==string_mission_attack)
		{
			///xxx
		}
		
		if(agent_mission[agent_pi]==string_mission_kuo)
		{
			agent_destination[agent_pi]=Agent_mission_kuo(agent_pi,agent_mission_destination[agent_pi]);
			Vector_leave_last(agent_destination[agent_pi]);
		}
		
		if(agent_mission[agent_pi]==string_mission_not_explorer_min_cost_visit_bound)
		{
			agent_destination[agent_pi]=Agent_mission_not_explorer_min_cost_visit_bound(agent_pi,agent_mission_destination[agent_pi]);
			Vector_leave_last(agent_destination[agent_pi]);
		}
		if(agent_destination[agent_pi].size())
		{
			z=agent_destination[agent_pi][agent_destination[agent_pi].size()-1];
				
			if(z==agent_position_int[agent_pi])
			{
				Protocol_recharge(agent_pi);				
			}
			else
			{
				
				if(Agent_can_go_to(agent_pi,z))
				{
				}
				#if error_on
				else
				Error("08 9y6089jhsrousy45");
				#endif
				
				zs=node_name_int_to_string[z];
				Protocol_goto(agent_pi,zs);			
			}		
		}
		else
		{
			#if error_on
			Error("43y6id7ii65");
			#endif
		}
		return 1;
	}
		
	int Agent_run_saboteur(int agent_pi)	
	{
		#if log_on
		log[agent_pi].writeln("---------------------Run_saboteur()	");
		#endif
		
		int i;
		int z;
		int rethink=0;
		string zs;
		int clock_a=0,clock_b;
		vector<int> zv;
		
			//clock_b=clock()-clock_a;
			//clock_a=clock();
			
		//	d_file.Writeln_file("clock.txt","w",perception_id);
			
									
			
//			write();
						
			ts=us=0;
			
			
			if(agent_last_action[agent_pi]==string_noAction)
				agent_no_action_count[agent_pi]++;
			
			while(1)
			{
				agent_destination[agent_pi].clear();
				
						
				
								
				if(agent_energy[agent_pi] <= int(agent_max_energy[agent_pi] * Agent_low_energy_rate(agent_pi)))
				{
					Protocol_recharge(agent_pi);
					break;
				}
				
				
				if(agent_health[agent_pi]==0)
				{
					agent_mission[agent_pi]="";	
					agent_mission_destination[agent_pi]=-1;
		
					if(!node_is_surveyed[agent_position_int[agent_pi]])
					{
						Protocol_recharge(agent_pi);
						break;
					}
				
					if(Agent_on_repairer_ass(agent_pi))
					{
						Protocol_recharge(agent_pi);
						break;
					}
					
					if(Agent_near_repairer_ass(agent_pi,zs))
					{
						#if log_on
						log[agent_pi].writeln("Near_repairer_ass() ");
						#endif
						
						Protocol_goto(agent_pi,zs);
						break;
					}
										
					if(Agent_find_repairer(agent_pi))
					{
						#if log_on
						log[agent_pi].writeln("report to WYX : find repairer");
						#endif
						
						if(Agent_repairer_is_reachable_by_surveyed_position(agent_pi))
						{
							#if log_on
							log[agent_pi].writeln("report to WYX : Repairer is in surveyed reachable node");						
							#endif
							
							agent_destination[agent_pi]=Agent_go_to_reachable_repairer_by_surveyed_position(agent_pi);
							Vector_leave_last(agent_destination[agent_pi]);
						}
						else
						{
							#if log_on
							log[agent_pi].writeln("report to WYX : Repairer is not in surveyed reachable node");
							#endif
							
							if(!Agent_on_the_edge_of_survey_zone_near_repairer(agent_pi))
							{
								#if log_on
								log[agent_pi].writeln("report to WYX : I am not on the edge of the surveyd zone near repairer. I will go to edge of the surveyd zone near pain friend.");	
								#endif
								
								agent_destination[agent_pi]=Agent_go_to_edge_of_surveyed_zone_near_repairer_place_with_smallest_edge(agent_pi);
								Vector_leave_last(agent_destination[agent_pi]);
							}								
							else
							{	
								#if log_on
								log[agent_pi].writeln("report to WYX : I am on the edge of the surveyd zone. I will recharge and wait repairer.");	
								#endif
								
								//agent_destination[agent_pi]=Go_to_unkown_place_near_repairer_with_smallest_edge()
								//Vector_leave_last(agent_destination[agent_pi]);
								Protocol_recharge(agent_pi);
								break;
							}
						}
					}
					
					
					if(agent_destination[agent_pi].size())
					{
						z=agent_destination[agent_pi][agent_destination[agent_pi].size()-1];
				
						if(Agent_can_go_to(agent_pi,z))
						{
						}
						#if error_on
						else
							Error("g09uy894yaq4jy4");
						#endif
				
						zs=node_name_int_to_string[z];
						Protocol_goto(agent_pi,zs);
						
						break;
					}			
			
					Protocol_recharge(agent_pi);					
					break;
				}			
				
				
				/*
				if(agent_health[agent_pi]<agent_max_health[agent_pi])
				{
					agent_mission[agent_pi]="";	
					agent_mission_destination[agent_pi]=-1;
		
					if(Agent_on_enermy_ass(agent_pi,zv))
					{
						z=Should_attack_enermy(zv);
						zs=enermy_name[z];
						Protocol_attack(agent_pi,zs);
						break;
					}
					
					if(!node_is_surveyed[agent_position_int[agent_pi]])
					{
						Protocol_survey(agent_pi);
						break;
					}
					
					
					if(Agent_on_repairer_ass(agent_pi))
					{
						Protocol_recharge(agent_pi);
						break;
					}
					
					if(Agent_near_repairer_ass(agent_pi,zs))
					{
						#if log_on
						log[agent_pi].writeln("Near_repairer_ass() ");
						#endif
						
						Protocol_goto(agent_pi,zs);
						break;
					}
										
					if(Agent_find_repairer(agent_pi))
					{
						#if log_on
						log[agent_pi].writeln("report to WYX : find repairer");
						#endif
						
						if(Agent_repairer_is_reachable_by_surveyed_position(agent_pi))
						{
							#if log_on
							log[agent_pi].writeln("report to WYX : Repairer is in surveyed reachable node");						
							#endif
							
							agent_destination[agent_pi]=Agent_go_to_reachable_repairer_by_surveyed_position(agent_pi);
							Vector_leave_last(agent_destination[agent_pi]);
						}
						else
						{
							#if log_on
							log[agent_pi].writeln("report to WYX : Repairer is not in surveyed reachable node");
							#endif
							
							if(!Agent_on_the_edge_of_survey_zone_near_repairer(agent_pi))
							{
								#if log_on
								log[agent_pi].writeln("report to WYX : I am not on the edge of the surveyd zone near repairer. I will go to edge of the surveyd zone near pain friend.");	
								#endif
								
								agent_destination[agent_pi]=Agent_go_to_edge_of_surveyed_zone_near_repairer_place_with_smallest_edge(agent_pi);
								Vector_leave_last(agent_destination[agent_pi]);
							}								
							else
							{	
								#if log_on
								log[agent_pi].writeln("report to WYX : I am on the edge of the surveyd zone. I will recharge and wait repairer.");	
								#endif
								
								//agent_destination[agent_pi]=Go_to_unkown_place_near_repairer_with_smallest_edge()
								//Vector_leave_last(agent_destination[agent_pi]);
								Protocol_recharge(agent_pi);
								break;
							}
						}
					}
					
					
					if(agent_destination[agent_pi].size())
					{
						z=agent_destination[agent_pi][agent_destination[agent_pi].size()-1];
				
						if(Agent_can_go_to(agent_pi,z))
						{
						}
						#if error_on
						else
							Error("g09uy894yaq4jy4");
						#endif
				
						zs=node_name_int_to_string[z];
						Protocol_goto(agent_pi,zs);
						
						break;
					}			
			
					Protocol_recharge(agent_pi);					
					break;
				}	*/
				
							
				///xx4
				/*
				if(Near_enermy_ass(z))
				{
					zs=enermy_agent[z].name;
					Protocol_attack(agent_pi,zs);
					break;
				}*/
				
				if(Agent_on_enermy_ass(agent_pi,zv))
				{
					z=Should_attack_enermy(zv);
					zs=enermy_name[z];
					Protocol_attack(agent_pi,zs);
					break;
				}
				
				if(agent_name[agent_pi][0]!='b')
				if(agent_team_money[agent_pi])
				{
					#if log_on
					log[agent_pi].writeln("============== team have money");
					#endif
					
					if(Agent_I_am_not_use_max_money(agent_pi))
					{
						#if log_on
						log[agent_pi].writeln("============== I_use_lowest_money()");
						#endif
						
						if(agent_can_buy_shield[agent_pi])
						if(!agent_can_buy_sabotageDevice[agent_pi] || agent_max_health[agent_pi]<agent_strength[agent_pi])
						{
							Protocol_buy_shield(agent_pi);
							break;
						}
					
						if(agent_can_buy_sabotageDevice[agent_pi])
						{
							Protocol_buy_sabotageDevice(agent_pi);
							break;
						}
					}
					#if log_on
					else
						log[agent_pi].writeln("============== I am not use_lowest_money or I can not buy ()");
					#endif
				}
			
				if(!node_is_surveyed[agent_position_int[agent_pi]])
				{
					Protocol_survey(agent_pi);
					break;
				}
				
								
				if(Agent_have_pain_in_the_ass(agent_pi))
				{
					if(Agent_on_repairer_ass(agent_pi))
					{
						Protocol_recharge(agent_pi);
						break;
					}
				}
				
				
				
				
				//rs
				if(!agent_destination[agent_pi].size())
				if(agent_attack_target_is[agent_pi]>=0)
				{					
					if(Agent_find_enermy(agent_pi))
					{
						#if log_on
						log[agent_pi].writeln("report to WYX : find enermy");
						#endif
						
						if(Agent_enermy_can_visit_through_surveyed_node(agent_pi))
						{
							#if log_on
							log[agent_pi].writeln("report to WYX : enermy is in surveyed reachable node");
							#endif
							
							agent_destination[agent_pi]=Agent_go_to_enermy(agent_pi);	
							Vector_leave_last(agent_destination[agent_pi]);
						}
						else
						{
							#if log_on
							log[agent_pi].writeln("report to WYX : enermy is not in surveyed reachable node");
							#endif
							
							if(!Agent_on_the_edge_of_survey_zone_near_enermy(agent_pi))
							{
								#if log_on
								log[agent_pi].writeln("report to WYX : I am not on the edge of the surveyd zone near enermy. I will go to edge of the surveyd zone near enermy.");	
								#endif
								
								agent_destination[agent_pi]=Agent_go_to_enermy_near_known_place(agent_pi);
								Vector_leave_last(agent_destination[agent_pi]);
							}
							else
							{	
								#if log_on
								log[agent_pi].writeln("report to WYX : I am on the edge of the surveyd zone. I will go to unkown place.");
								#endif
								
								agent_destination[agent_pi]=Agent_go_to_unkown_place_near_enermy(agent_pi);
								Vector_leave_last(agent_destination[agent_pi]);
							}
						}
					}
				}
				
				if(!agent_destination[agent_pi].size())
				if(Agent_have_not_surveyed_node(agent_pi))
						{
							#if log_on
							log[agent_pi].writeln("report to WYX : I can not find enermy. I will explorer map.");
							#endif
							
							agent_mission[agent_pi]=string_mission_not_explorer_min_cost_visit_bound;
							return 1;
						//	agent_destination[agent_pi]=Not_explorer_min_cost_visit_bound();
						//	Vector_leave_last(agent_destination[agent_pi]);
						}
				
				/*
				if(!agent_destination[agent_pi].size())
				{
					if(On_occupy_max_kuo_node())
					{
						Protocol_recharge(agent_pi);
						break;
					}
					agent_destination[agent_pi]=Go_to_not_occupy_max_kuo_node();
					Vector_leave_last(agent_destination[agent_pi]);		
				}*/
				
				if(!agent_destination[agent_pi].size())
				{
					agent_destination[agent_pi]=Agent_go_to_not_occupy_max_value_node(agent_pi);
					Vector_leave_last(agent_destination[agent_pi]);
				}
			
				if(agent_destination[agent_pi].size())
				{
					z=agent_destination[agent_pi][agent_destination[agent_pi].size()-1];
				
					if(Agent_can_go_to(agent_pi,z))
					{
					}
					#if error_on
					else
						Error("g09uy894yaq4jy4");
					#endif
				
					zs=node_name_int_to_string[z];
					Protocol_goto(agent_pi,zs);
					
					break;
				}			
			
				Protocol_recharge(agent_pi);	
				break;
			}	
		return 1;
	}

	///re
	int Agent_run_mission_explorer(int agent_pi)
	{
		int z;
		string zs;
		
		if(agent_mission[agent_pi]==string_mission_kuo)
		{
			agent_destination[agent_pi]=Agent_mission_kuo(agent_pi,agent_mission_destination[agent_pi]);
			Vector_leave_last(agent_destination[agent_pi]);
		}
		
		if(agent_mission[agent_pi]==string_mission_explorer_min_cost_visit_bound)
		{
			agent_destination[agent_pi]=Agent_mission_explorer_min_cost_visit_bound(agent_pi,agent_mission_destination[agent_pi]);
			Vector_leave_last(agent_destination[agent_pi]);
		}
		if(!agent_destination[agent_pi].size())
		{
			if(agent_mission[agent_pi]==string_mission_not_explorer_min_cost_visit_bound)
			{
				agent_destination[agent_pi]=Agent_mission_not_explorer_min_cost_visit_bound(agent_pi,agent_mission_destination[agent_pi]);
				Vector_leave_last(agent_destination[agent_pi]);
			}
		}
		if(agent_destination[agent_pi].size())
		{
			z=agent_destination[agent_pi][agent_destination[agent_pi].size()-1];
				
			if(z==agent_position_int[agent_pi])
			{
				Protocol_recharge(agent_pi);				
			}
			else
			{
				
				if(Agent_can_go_to(agent_pi,z))
				{
				}
				#if error_on
				else
					Error("08 9y6089jhsrousy45");
				#endif
				
				zs=node_name_int_to_string[z];
				Protocol_goto(agent_pi,zs);			
			}	
		}
		else
		{
			#if error_on
			Error("y9834yhj45euhy5s4r");
			#endif
		}
		return 1;
	}
	
	int Agent_run_explorer(int agent_pi)
	{
		#if log_on
		log[agent_pi].writeln("---------------------Run_explorer()");;
		#endif
		
		int i;
		int z;
		int rethink=0;
		string zs;
		
			
		//	if(agent_name[0]=='b' && agent_name=="b3")
	//		write();
			
			//Protocol_survey(agent_pi);
			//continue;
			
			while(1)
			{					
				agent_destination[agent_pi].clear();
							
				if(agent_energy[agent_pi] <= int(agent_max_energy[agent_pi] * Agent_low_energy_rate(agent_pi)))
				{
					Protocol_recharge(agent_pi);
					break;
				}
				
				if(agent_health[agent_pi]==0)
				{
					agent_mission[agent_pi]="";	
					agent_mission_destination[agent_pi]=-1;
					
					if(!node_is_surveyed[agent_position_int[agent_pi]])
					{
						Protocol_recharge(agent_pi);
						break;
					}
				
					if(Agent_on_repairer_ass(agent_pi))
					{
						Protocol_recharge(agent_pi);
						break;
					}
					
					if(Agent_near_repairer_ass(agent_pi,zs))
					{
						#if log_on
						log[agent_pi].writeln("Near_repairer_ass() ");
						#endif
						
						Protocol_goto(agent_pi,zs);
						break;
					}
										
					if(Agent_find_repairer(agent_pi))
					{
						#if log_on
						log[agent_pi].writeln("report to WYX : find repairer");
						#endif
						
						if(Agent_repairer_is_reachable_by_surveyed_position(agent_pi))
						{
							#if log_on
							log[agent_pi].writeln("report to WYX : Repairer is in surveyed reachable node");						
							#endif
							
							agent_destination[agent_pi]=Agent_go_to_reachable_repairer_by_surveyed_position(agent_pi);
							Vector_leave_last(agent_destination[agent_pi]);
						}
						else
						{
							#if log_on
							log[agent_pi].writeln("report to WYX : Repairer is not in surveyed reachable node");
							#endif
							
							if(!Agent_on_the_edge_of_survey_zone_near_repairer(agent_pi))
							{
								#if log_on
								log[agent_pi].writeln("report to WYX : I am not on the edge of the surveyd zone near repairer. I will go to edge of the surveyd zone near pain friend.");	
								#endif
								
								agent_destination[agent_pi]=Agent_go_to_edge_of_surveyed_zone_near_repairer_place_with_smallest_edge(agent_pi);
								Vector_leave_last(agent_destination[agent_pi]);
							}								
							else
							{	
								#if log_on
								log[agent_pi].writeln("report to WYX : I am on the edge of the surveyd zone. I will recharge and wait repairer.");	
								#endif
								
								//agent_destination[agent_pi]=Go_to_unkown_place_near_repairer_with_smallest_edge()
								//Vector_leave_last(agent_destination[agent_pi]);
								Protocol_recharge(agent_pi);
								break;
							}
						}
					}
					
					if(agent_destination[agent_pi].size())
					{
						z=agent_destination[agent_pi][agent_destination[agent_pi].size()-1];
				
						if(Agent_can_go_to(agent_pi,z))
						{
						}
						#if error_on
						else
							Error("g09uy894yaq4jy4");
						#endif
				
						zs=node_name_int_to_string[z];
						Protocol_goto(agent_pi,zs);
						
						break;
					}			
			
					Protocol_recharge(agent_pi);					
					break;
				}			
				
				
				
				if(agent_health[agent_pi]<agent_max_health[agent_pi])
				{
					agent_mission[agent_pi]="";	
					agent_mission_destination[agent_pi]=-1;
		
					if(!node_is_surveyed[agent_position_int[agent_pi]])
					{
						Protocol_survey(agent_pi);
						break;
					}
					
					
					if(Agent_on_repairer_ass(agent_pi))
					{
						Protocol_recharge(agent_pi);
						break;
					}
					
					if(Agent_near_repairer_ass(agent_pi,zs))
					{
						#if log_on
						log[agent_pi].writeln("Near_repairer_ass() ");
						#endif
						
						Protocol_goto(agent_pi,zs);
						break;
					}
										
					if(Agent_find_repairer(agent_pi))
					{
						#if log_on
						log[agent_pi].writeln("report to WYX : find repairer");
						#endif
						
						if(Agent_repairer_is_reachable_by_surveyed_position(agent_pi))
						{
							#if log_on
							log[agent_pi].writeln("report to WYX : Repairer is in surveyed reachable node");						
							#endif
							
							agent_destination[agent_pi]=Agent_go_to_reachable_repairer_by_surveyed_position(agent_pi);
							Vector_leave_last(agent_destination[agent_pi]);
						}
						else
						{
							#if log_on
							log[agent_pi].writeln("report to WYX : Repairer is not in surveyed reachable node");
							#endif
							
							if(!Agent_on_the_edge_of_survey_zone_near_repairer(agent_pi))
							{
								#if log_on
								log[agent_pi].writeln("report to WYX : I am not on the edge of the surveyd zone near repairer. I will go to edge of the surveyd zone near pain friend.");	
								#endif
								
								agent_destination[agent_pi]=Agent_go_to_edge_of_surveyed_zone_near_repairer_place_with_smallest_edge(agent_pi);
								Vector_leave_last(agent_destination[agent_pi]);
							}								
							else
							{	
								#if log_on
								log[agent_pi].writeln("report to WYX : I am on the edge of the surveyd zone. I will recharge and wait repairer.");	
								#endif
								
								//agent_destination[agent_pi]=Go_to_unkown_place_near_repairer_with_smallest_edge()
								//Vector_leave_last(agent_destination[agent_pi]);
								Protocol_recharge(agent_pi);
								break;
							}
						}
					}
					
					if(agent_destination[agent_pi].size())
					{
						z=agent_destination[agent_pi][agent_destination[agent_pi].size()-1];
				
						if(Agent_can_go_to(agent_pi,z))
						{
						}
						#if error_on
						else
							Error("g09uy894yaq4jy4");
						#endif
				
						zs=node_name_int_to_string[z];
						Protocol_goto(agent_pi,zs);
						
						break;
					}			
			
					Protocol_recharge(agent_pi);					
					break;
				}	
			
				if(!node_is_probed[agent_position_int[agent_pi]])
				{
					Protocol_probe(agent_pi);
					break;
				}
			
				if(!node_is_surveyed[agent_position_int[agent_pi]])
				{
					Protocol_survey(agent_pi);
					break;
				}
			
				if(!agent_destination[agent_pi].size())
				if(Agent_have_not_probed_node(agent_pi))
				{		
					agent_mission[agent_pi]=string_mission_explorer_min_cost_visit_bound;	
					return 1;
					//agent_destination[agent_pi]=Explorer_min_cost_visit_bound();
					//Vector_leave_last(agent_destination[agent_pi]);
				}
				
				if(!agent_destination[agent_pi].size())
				{
					agent_mission[agent_pi]=string_mission_kuo;
					return 1;
					/*
					if(On_occupy_max_kuo_node())
					{						
						Protocol_recharge(agent_pi);
						break;
					}
					agent_destination[agent_pi]=Go_to_not_occupy_max_kuo_node();
					Vector_leave_last(agent_destination[agent_pi]);		*/
				}
				
				if(!agent_destination[agent_pi].size())
				{
					agent_destination[agent_pi]=Agent_go_to_not_occupy_max_value_node(agent_pi);
					Vector_leave_last(agent_destination[agent_pi]);					
				}
			
				if(agent_destination[agent_pi].size())
				{
					z=agent_destination[agent_pi][agent_destination[agent_pi].size()-1];
				
					if(Agent_can_go_to(agent_pi,z))
					{
					}
					#if error_on
					else
						Error("g09uy894yaq4jy4");
					#endif
					
					zs=node_name_int_to_string[z];
					Protocol_goto(agent_pi,zs);
					
					break;
				}
				
				Protocol_recharge(agent_pi);	
				break;
			}
		return 1;
	}



int Agent_deal_last_action_result(int agent_pi)
	{
	//	log[agent_pi].writeln("-------------Deal_last_action_result() 1");
		string zs;
		int z;
		
		while(1)
		{
			if(agent_last_action_result[agent_pi]==string_failed_random)
				break;
			if(agent_last_action_result[agent_pi]==string_failed_attacked)
				break;
			
			#if error_on
			if(agent_last_action_result[agent_pi]==string_failed_role)
				Error("fgjer98ahgar");
			if(agent_last_action_result[agent_pi]==string_failed_status)
				Error("fjwehgwhgpaher");
			if(agent_last_action_result[agent_pi]==string_failed_wrong_param)	
				Error("gjewryga89ga");
			#endif
			
			
			if(agent_last_action_result[agent_pi]==string_failed_away)
				break;
			if(agent_last_action_result[agent_pi]==string_failed_parry)
				break;
			if(agent_last_action_result[agent_pi]==string_failed_resources)
				break;
			if(agent_last_action[agent_pi]==string_skip)
				break;
				
				
			if(agent_last_action[agent_pi]==string_recharge)
				break;
				
			if(agent_last_action[agent_pi]==string_repair)
				break;
				
			if(agent_last_action[agent_pi]==string_attack)
				break;
				
			if(agent_last_action[agent_pi]==string_inspect)
				break;
				
			if(agent_last_action[agent_pi]==string_noAction)
			{
				///z
				break;
			}
				

				
			if(agent_last_action[agent_pi]==string_goto_ && agent_last_action_result[agent_pi]==string_successful)
			{
				z=Node_name_string_to_int(agent_last_action_param[agent_pi]);
				if(agent_destination[agent_pi].size())
				if(agent_destination[agent_pi][agent_destination[agent_pi].size()-1]==z)
					agent_destination[agent_pi].pop_back();
				break;
			}
		
			if(agent_last_action[agent_pi]==string_survey)
			{
				if(agent_last_action_result[agent_pi]==string_successful)
					Node_set_is_surveyed(agent_position_int[agent_pi]);
//					node_is_surveyed[agent_position_int[agent_pi]]=1;
				break;
			}
		
			if(agent_last_action[agent_pi]==string_probe)
			{
				break;
			}
			
			if(agent_last_action[agent_pi]==string_buy)
			{
				if(agent_last_action_result[agent_pi]==string_failed_resources)
					break;
		
				if(agent_last_action_result[agent_pi]==string_successful)
				{
					agent_used_money[agent_pi]++;
					break;
				}
				
				#if error_on
				if(agent_last_action_result[agent_pi]==string_wrongParameter)
					Error("8a9eyap9ajhahg");
				#endif
				
				if(agent_last_action_result[agent_pi]==string_failed_limit)
				{
					if(agent_last_action_param[agent_pi]==string_battery)
					{
						agent_can_buy_battery[agent_pi]=0;
						break;
					}
					if(agent_last_action_param[agent_pi]==string_sensor)
					{
						agent_can_buy_sensor[agent_pi]=0;
						break;
					}
					if(agent_last_action_param[agent_pi]==string_shield)
					{
						agent_can_buy_shield[agent_pi]=0;
						break;
					}
					if(agent_last_action_param[agent_pi]==string_sabotageDevice)
					{
						agent_can_buy_sabotageDevice[agent_pi]=0;
						break;
					}
					
					#if error_on
					Error("jg089yspyh");
					#endif
				}
				#if error_on
				Error("gjoierhy98swyh");
				#endif	
					
				break;
			}
			
			cout<<agent_name[agent_pi]<<endl;
			cout<<agent_last_action[agent_pi]<<endl;
			cout<<agent_last_action_param[agent_pi]<<endl;
			cout<<agent_last_action_result[agent_pi]<<endl;			
			#if error_on
			Error("984yu89sgjarh");
			#endif
		}
	//	log[agent_pi].writeln("-------------Deal_last_action_result() 2");
		return 1;
	}	

int Agent_prepare(int agent_pi)
	{			
		#if log_on
			log[agent_pi].writeln("---------------------Prepare() 1");
		#endif
		
		int i,a,b;
		
		
				
			visible_vertex_name.clear();
			visible_vertex_team.clear();
			visible_edge_node1.clear();
			visible_edge_node2.clear();
			visible_entity_name.clear();
			visible_entity_node.clear();
			visible_entity_status.clear();
			visible_entity_team.clear();
			visible_edge_node1.clear();
			visible_edge_node2.clear();	
			achievement_name.clear();
			probed_vertex_name.clear();
			probed_bertex_value.clear();
			surveyed_edge_node1.clear();
			surveyed_edge_node2.clear();
			surveyed_edge_weight.clear();
			inspected_entity_energy.clear();
			inspected_entity_health.clear();
			inspected_entity_max_energy.clear();
			inspected_entity_max_health.clear();
			inspected_entity_name.clear();
			inspected_entity_node.clear();
			inspected_entity_role.clear();
			inspected_entity_strength.clear();
			inspected_entity_team.clear();
			inspected_entity_vis_range.clear();
		
		
			agent_vertex_near[agent_pi].clear();
			
		
		Agent_get_infor(agent_pi);
		
		a=agent_position_int[agent_pi];
		for(i=1;i<=node_edge_n[a];i++)
		{
			b=node_edge[a][i];
			agent_vertex_near[agent_pi].push_back(b);
		}
		
		
			
		if(Agent_deal_last_action_result(agent_pi))
		{
		}
		#if error_on
		else
			Error("ew9rugy8ayg");
		#endif
		
		
		
		Agent_learn_from_sight(agent_pi);
		
		#if log_on
			log[agent_pi].writeln("---------------------Prepare() 2");
		#endif
		return 1;
	}

int Agent_run_mission(int agent_pi)
	{
		if(agent_mission[agent_pi]=="")
			return 0;
		if(agent_mission_destination[agent_pi]<0)
			return 0;
		if(Protocol_have_order(agent_pi))
			return 0;
		agent_destination[agent_pi].clear();
		
		if(agent_role[agent_pi]==string_explorer)
			Agent_run_mission_explorer(agent_pi);
	//	else if(agent_role[agent_pi]==string_saboteur) 
	//		Run_saboteur();
		else if(agent_role[agent_pi]==string_repairer) 
			Agent_run_mission_repairer(agent_pi);
		else if(agent_role[agent_pi]==string_inspector)
			Agent_run_mission_inspector(agent_pi);
		else
			Agent_run_mission_sentinel(agent_pi);
		return 1;
	}
	
int Agent_run(int agent_pi)
	{					
		if(sim_end)
		{
			return 0;
		}
		/*
		if(agent_0_conquer_all_map)
		{
			write();
			Protocol_recharge(agent_pi);
			return 1;
		}*/
		
		if(team_B_skip)
		if(agent_name[agent_pi][0]=='b')
		{
			Agent_write(agent_pi);
			Protocol_skip(agent_pi);
			return 1;
		}
		
		
		agent_destination[agent_pi].clear();
		
		if(agent_mission[agent_pi]==string_mission_not_explorer_min_cost_visit_bound)
		if(!Agent_have_not_surveyed_node(agent_pi))
		{
			agent_mission[agent_pi]="";
			agent_mission_destination[agent_pi]=-1;
		}
		
		if(agent_mission[agent_pi]==string_mission_explorer_min_cost_visit_bound)
		if(!Agent_have_not_probed_node(agent_pi))
		{
			agent_mission[agent_pi]="";
			agent_mission_destination[agent_pi]=-1;
		}
		
		if(agent_role[agent_pi]==string_explorer)
			Agent_run_explorer(agent_pi);
		else if(agent_role[agent_pi]==string_saboteur) 
			Agent_run_saboteur(agent_pi);
		else if(agent_role[agent_pi]==string_repairer) 
			Agent_run_repairer(agent_pi);
		else if(agent_role[agent_pi]==string_inspector)
			Agent_run_inspector(agent_pi);
		else
			Agent_run_sentinel(agent_pi);
		//return Random_explorer();		
		return 1;
	}


///a






void *thread_listen_main(void *arg)
{
	int *p;
	p=(int*)arg;
	


	
	while(1)
	{
		pthread_mutex_lock(&(agent_pr_lock[*p]));
		agent_pr_thread_start[*p]=1;
		pthread_cond_wait(&(agent_pr_net_msg_signal_start[*p]), &(agent_pr_lock[*p]));
		
		agent_pr_thread_start[*p]=0;
		
		pthread_cond_init(&(agent_pr_net_msg_signal_start[*p]), NULL);
		
		agent_net_msg_signal_done[*p]=0;
		agent_net_msg_signal_start[*p]=0;
		pthread_mutex_unlock(&(agent_pr_lock[*p]));	
		
		
		Agent_listen(*p);	
			
		agent_net_msg_signal_done[*p]=1;	
	}	
	
	return((void *)0);
}


void *thread_send_main(void *arg)
{
	int *p;
	p=(int*)arg;
	
	Protocol_send_order(*p);	
	
	return((void *)0);
}












int Agent_0_conquer_all_map()
{
	int i;
	int z;
	
	#if error_on
	if(!sim_end && visible_vertex_name.size()==0)
		Error("j94utayh38yw");
	#endif
		
	if(visible_vertex_name.size()< node_n*0.9)
		return 0;
	
	return 1;
}










void Read_agent_name_password(string agent_name_password_ini_file)
{
	int i;
	vector<string> info;
	string zs;
	char r[100];
	FILE* F=fopen(agent_name_password_ini_file.c_str(),"r");
		
	info.clear();
	
	while(fscanf(F,"%s",r)!=EOF)
	{
		zs=r;
		info.push_back(zs);
	}
	
	fclose(F);
	
	#if error_on
	if(info.size()%2)
		Error("4u90yjserhjasi");
	#endif
			
	for(i=0;i<info.size();i+=2)
	{
		#if error_on
		if(D_find(agent_name,agent_n,info[i]))
		{
			Error("u8yw94ypwjy");
		}
		#endif
		
		agent_name[agent_n]=info[i];
		agent_password[agent_n]=info[i+1];
		agent_n++;
	}
}

void Read_agent_ip_port(string string_ip_port_file_name)
{
	int i;
	string zs;
	char r[100];
	FILE* F=fopen(string_ip_port_file_name.c_str(),"r");
	
	#if error_on
	if(!F)
		Error("943u894y4yh");
	#endif
	
	if(fscanf(F,"%s",r)!=EOF)
		agent_ip=r;
	#if error_on
	else
		Error("908643yhohgaog");
	#endif
	
	
	if(fscanf(F,"%d",&agent_port)!=EOF)
	{
	}
	#if error_on
	else
		Error("0956h2q53grgye89y");
	#endif
	
	fclose(F);
}

void Agents_listen()
{
	int i;
	for(i=0;i<agent_n;i++)
		Agent_listen(i);
}









///m


void Memory_read()
{
	char buff[10];
	FILE* F=fopen(memory_file.c_str(),"r");
	int a,b,c;
	int s=0;
	string sa,sb,sc;
	
	while(fscanf(F,"%s",buff)!=EOF)
	{
		if(buff[0]=='e')
		{
			fscanf(F,"%d%d%d",&a,&b,&c);
			Node_add_edge(a,b);
			Node_add_edge(b,a);
			
			Node_add_surveyed_edge_without_memory(a,b,c);
			Node_add_surveyed_edge_without_memory(b,a,c);
			continue;
		}
		
		if(buff[0]=='v')
		{
			fscanf(F,"%d%d",&a,&b);
			Node_set_value_without_memory(a,b);
			continue;
		}	
		
		if(buff[0]=='s')
		{
			fscanf(F,"%d",&a);
			Node_set_is_surveyed_without_memory(a);
			continue;
		}
		
		if(buff[0]=='r')
		{
			fscanf(F,"%s",buff);
			sa=buff;
			fscanf(F,"%s",buff);
			sb=buff;
			fscanf(F,"%s",buff);
			sc=buff+1;			
			Enermy_set_role_without_memory(sa,sb,sc);
		}
	}
	fclose(F);
}











int s=0;







void Rand()
{
	int i;
	
	for(i=0;i<agent_n;i++)
		enermy_must_attack[i]=0;
	for(i=0;i<agent_n;i++)
	if(rand()%300==0)
		enermy_must_attack[i]=1;		
}	

int Agent_saboteur_free()
{
	int i;
	int ret=-1;
	
	for(i=0;i<agent_n;i++)
	{
		if(agent_role[i]!=string_saboteur)
			continue;
		
		if(agent_attack_target_is[i]>=0)
			continue;
			
		if(agent_health[i]==0)
			continue;
		ret=i;
		return ret;
	}
	return ret;
}

int Agent_saboteur_not_must_not_free()
{
	int i;
	int ret=-1;
	
	for(i=0;i<agent_n;i++)
	{
		if(agent_role[i]!=string_saboteur)
			continue;
		
		if(agent_attack_target_is[i]<0)
			continue;
			
		if(agent_health[i]==0)
			continue;
			
		if(enermy_must_attack[ agent_attack_target_is[i] ])
			continue;
		
		ret=i;
		return ret;
	}
	return ret;
}

int tmp_id[max_agent_n];

bool cmp_oldest_killed_enermy(int a,int b)
{
	return enermy_killed_time[a]<enermy_killed_time[b];
}

void Agent_attack()
{
	int i,j;
	int z;
	string zs;
	int ag;
	
	//zz
	
	for(i=0;i<agent_n;i++)
	{
		if(agent_role[i]!=string_saboteur)
			continue;
		
		if(agent_attack_target_is[i]<0)
			continue;
		
		if(agent_health[i]==0)
		{
			Attack_want_break_by_agent(i);
			continue;
		}
			
		if(do_not_attack[ agent_attack_target_is[i] ])
		{
			Attack_want_break_by_agent(i);
			continue;
		}
			
		if(enermy_status[agent_attack_target_is[i]]==string_disabled)
		{
			Attack_want_break_by_agent(i);
			continue;
		}
			
		if(!Enermy_get_node(agent_attack_target_is[i],zs,perception_id))
		{
			Attack_want_break_by_agent(i);
			continue;
		}
	}
	
	
	
	for(i=0;i<enermy_n;i++)
	{
		if(!enermy_must_attack[i])
			continue;
			
		if(enermy_attack_wanted_by[i]>=0)
			continue;
			
		if(do_not_attack[i])
			continue;
		
		if(enermy_status[i]!=string_normal)
			continue;
			
		if(!Enermy_get_node(i,zs,perception_id))
			continue;
				
		z=Node_name_string_to_int(zs);
		
		ag=Agent_saboteur_free();
		if(ag<0)
		{
			ag=Agent_saboteur_not_must_not_free();
			if(ag<0)
				return;
			
			Attack_want_break_by_agent(ag);			
		}
			
		Attack_want(ag,i);
	}
	
	if(Agent_saboteur_free()<0)
		return;
	
	for(i=0;i<enermy_n;i++)
		tmp_id[i]=i;
		
	sort(tmp_id,tmp_id+enermy_n,cmp_oldest_killed_enermy);
	
	for(j=0;j<enermy_n;j++)
	{
		i=tmp_id[j];
		
		if(enermy_attack_wanted_by[i]>=0)
			continue;
			
		if(do_not_attack[i])
			continue;
		
		if(enermy_status[i]!=string_normal)
			continue;
			
		if(!Enermy_get_node(i,zs,perception_id))
			continue;
		
		z=Node_name_string_to_int(zs);
		
		ag=Agent_saboteur_free();
		if(ag<0)
			return;
			
		Attack_want(ag,i);
	}	
}		









int Agent_inspector_free()
{
	int i;
	int ret=-1;
	
	for(i=0;i<agent_n;i++)
	{
		if(agent_role[i]!=string_inspector)
			continue;
		
		if(agent_inspect_target_is[i]>=0)
			continue;
			
		if(agent_health[i]==0)
			continue;
		ret=i;
		return ret;
	}
	return ret;
}


void Agent_inspect()
{
	int i,j;
	int z;
	string zs;
	int ag;
	int s=0;
	
	//zz
	
	for(i=0;i<agent_n;i++)
	{
		if(agent_role[i]!=string_inspector)
			continue;
		
		if(agent_inspect_target_is[i]<0)
			continue;
		
		if(agent_health[i]==0)
		{
			Inspect_want_break_by_agent(i);
			continue;
		}
		
		if(enermy_is_inspected[ agent_inspect_target_is[i] ])
		{
			Inspect_want_break_by_agent(i);
			continue;
		}
						
		if(!Enermy_get_node(agent_inspect_target_is[i],zs,perception_id))
		{
			Inspect_want_break_by_agent(i);
			continue;
		}
	}
	
	
		
	if(Agent_inspector_free()<0)
		return;
		
	for(i=0;i<enermy_n;i++)
	{
		if(enermy_inspect_wanted_by[i]>=0)
			continue;
								
		if(!Enermy_get_node(i,zs,perception_id))
			continue;
			
		if(enermy_is_inspected[i])
			continue;
		
		z=Node_name_string_to_int(zs);
		
		ag=Agent_inspector_free();
		if(ag<0)
			return;
			
		Inspect_want(ag,i);
	}	
}		


void Smart_survey()
{
	int i;
	//zz
	for(i=1;i<=node_n;i++)
	if(!node_is_surveyed[i])
	if(node_visited[i] && Node_all_edge_is_surveyed(i))
	{
		Node_set_is_surveyed(i);
	}
}

void Hand_run()
{
	char buff[1000];
	int z;
	int x,y;
	int i;
	
	for(i=0;i<agent_n;i++)
		Protocol_recharge(i);
	
	FILE* F=fopen("h.in","r");
	if(fscanf(F,"%d%s",&x,buff)==EOF)
	{		
		fclose(F);
		return;
	}
	
	x--;
	while(1)
	{
		if(strcmp(buff,"g")==0)
		{
			fscanf(F,"%s",buff);
			Protocol_goto(x,buff);
			break;
		}
		
		if(strcmp(buff,"a")==0)
		{
			fscanf(F,"%s",buff);
			Protocol_attack(x,buff);
			break;
		}
		
		
		
		break;
	}
			
	fclose(F);
	
	F=fopen("h.in","w");
	fclose(F);
}


///wa
class Wang_Yuxin_class
{
public:	
	void Init(string agent_name_password_ini_file,int x_clear_flag)
	{		
		int i;
		int A;
		
		for(i=0;i<enermy_n;i++)
			Enermy_init(i);
					
		if(!memory_on)
			Memory_clear();
		
		sim_end=0;
		
		for(A=0;A<kuo_area_n;A++)
		for(i=0;i<max_node_n;i++)
			Kuo_d_st(A,i);		
			
		for(A=0;A<kuo_area_n;A++)
			kuo_d_n[A]=0;
		
		for(A=0;A<kuo_area_n;A++)
			Kuo_init(A);	
				
		clear_flag=x_clear_flag;
		
		
		vector<string> info;		
		node_n=0;
		edge_n=0;
				
		
		agent_n=0;
		
		/////
		Read_agent_name_password(agent_name_password_ini_file);
		
		
		string zs=(agent_name[0]);
		zs=zs[0];
		
		#if log_on
		log.Init("./log/"+zs+"WYX.log");
			log.Clear();
		#endif
		
		Read_agent_ip_port(string_ip_port_file_name);				
		
		
		
		for(i=0;i<agent_n;i++)
		if(Agent_init(i,clear_flag))
		{
		}
		#if error_on
		else
			Error("jw9et9ayte");
		#endif
		
	
		vector<int> pid;
		pid.resize(agent_n);
		
		vector<pthread_t> tid;
		tid.resize(agent_n);
		
		Thread_listen();
		All_net_msg_signal_start();
		
		Wait_all_net_msg_signal_ready();
		
		for(i=0;i<agent_n;i++)
		{
			Protocol_auth_request(i,agent_name[i],agent_password[i]);
		}
		
		Thread_send();
			
			
		Wait_all_auth_msg();
				
		Wait_all_net_msg_signal_ready();
		
		
		for(i=0;i<agent_n;i++)
		{
			if(Agent_auth_request(i))
			{
			}
			#if error_on
			else
				Error("a475ke7oi5");	
			#endif
		}
		
		Wait_all_sim_msg();
		
		for(i=0;i<agent_n;i++)		
		{
			if(Agent_sim_start(i))
				printf("%s sim start\n",agent_name[i].c_str());
			#if error_on
			else				
				Error("a3y45a3ui");
			#endif
		}
		
		
		Wait_all_net_msg_signal_done();		
	}	
	
	void Init2()
	{		
		sim_end=0;
		
		int i;	
		int A;
		
		for(i=0;i<enermy_n;i++)
			Enermy_init(i);
			
		
		if(!memory_on)
			Memory_clear();
		
		for(A=0;A<kuo_area_n;A++)
		for(i=0;i<max_node_n;i++)
			Kuo_d_st(A,i);		
			
		for(A=0;A<kuo_area_n;A++)
			kuo_d_n[A]=0;
		
		for(A=0;A<kuo_area_n;A++)
			Kuo_init(A);	
			
			
		
			
		node_n=0;	
		edge_n=0;
		
		
		
						
		
		string zs=(agent_name[0]);
		zs=zs[0];
		
		#if log_on
		log.Init("./log/"+zs+"WYX.log");
			log.Clear();
		#endif
		
				
		for(i=0;i<agent_n;i++)
		if(Agent_init2(i))
		{
		}
		#if error_on
		else
			Error("aewhrarjar");
		#endif
	
		for(i=0;i<agent_n;i++)		
		{
			if(Agent_sim_start(i))
				cout<<agent_name[i]<<" sim start"<<endl;	
			#if error_on			
			else
				Error("a3y45a3ui");
			#endif
		}		
	}	
	
	
	void Thread_listen()
	{
		int i;
		vector<pthread_t> tid;
		tid.resize(agent_n);
		
		for(i=0;i<agent_n;i++)
		if(!pthread_create(&tid[i], NULL, thread_listen_main,&D_e[i]))
		{
		}
		#if error_on
		else
			Error("jg589098u43e98yu34");
		#endif
			
		//for(i=0;i<agent_n;i++)
		//	pthread_join(tid[i],0);
	}
	
	void Thread_send()
	{
		int i;
		vector<pthread_t> tid;
		tid.resize(agent_n);
				
		for(i=0;i<agent_n;i++)
		if(!pthread_create(&tid[i], NULL, thread_send_main,&D_e[i]))
		{
		}
		#if error_on
		else
			Error("jg589098u43e98yu34");
		#endif
			
		for(i=0;i<agent_n;i++)
			pthread_join(tid[i],0);
	}
	
	void All_net_msg_signal_start()
	{	
		int i;
		int z;
		for(i=0;i<agent_n;i++)
		{
		//	pthread_mutex_lock(&agent[i].pr.lock);
			z=0;
			
			while(!agent_pr_thread_start[i])
			{
				Wait_1_unit();
			}
			agent_pr_thread_start[i]=0;
			agent_net_msg_signal_start[i]=1;
			//pthread_mutex_lock(&agent[i].pr.lock);
			pthread_cond_signal(&agent_pr_net_msg_signal_start[i]);
			//pthread_mutex_unlock(&agent[i].pr.lock);
		}	
	}
	
	void Wait_all_auth_msg()
	{
		int i;
		int z;
		for(i=0;i<agent_n;i++)
		{
			while(!agent_have_auth_msg[i])
			{
				Wait_1_unit();
			}
		}
	}
	
	void Wait_all_sim_msg()
	{
		int i;
		int z;
		for(i=0;i<agent_n;i++)
		{
			while(!agent_have_sim_msg[i])
			{
				Wait_1_unit();
			}
		}
	}
	
	void Wait_all_thread_start()
	{
		int i;
		int z;
		for(i=0;i<agent_n;i++)
		{
			while(!agent_pr_thread_start[i])
			{
				Wait_1_unit();
			}
		}
	}
	
	void Wait_all_net_msg_signal_ready()
	{
		int i,j;
		int z=0;
		for(i=0;i<agent_n;i++)
		while(!agent_net_msg_signal_ready[i])
		{
			Wait_1_unit();
			z++;
			
		}
		
		for(i=0;i<agent_n;i++)
		agent_net_msg_signal_ready[i]=0;
	}
	
	void Wait_all_net_msg_signal_done()
	{

		int i;
		
		for(i=0;i<agent_n;i++)
		while(!agent_net_msg_signal_done[i])
		{
			Wait_1_unit();
		}
		
		
		for(i=0;i<agent_n;i++)
			agent_net_msg_signal_done[i]=0;
	}
		
	///r///
	int Run()
	{
		int i;
		int j;
		int z;
		int zi=0;
		string zs;
		int A;
		
		vector<int> pid;
		pid.resize(agent_n);
		
		
		if(memory_on)
		{
			Memory_read();			
		}
			
		
		int first=0;
		
	
		while(1)
		{		
			gettimeofday(&time_step_a,0);
					
			gettimeofday(&time_start,0);

			
			
		
			for(i=0;i<agent_n;i++)
			{
				if(agent_role[i]==string_sentinel)			
				{
					agent_mission_param[i]=0;
				}
				if(agent_role[i]==string_inspector)
				{
					agent_mission_param[i]=1;	
				}
				if(agent_role[i]==string_explorer)
				{
					agent_mission_param[i]=2;
				}
			}
			
			

			
			
					
			

			while(1)	
			{
				if(sim_end)
				{
					Init2();							
				}			
				/*				
				if(rand()%300==0)
				{
					cc.kuo01=rand()%2;
					if(rand()%2)
					{
						cc.can_buy_role.clear();
						cc.can_buy_role.push_back(string_saboteur);
					}
					else
						cc.can_buy_role.clear();
				}*/
				
				Last_time_enermy_update();
				
				
				
				
				/*
				for(i=0;i<agent_n;i++)
					agent[i].Write_net_msg();
				*/
							
			
				for(i=0;i<agent_n;i++)
				{				
					if(Agent_prepare(i))						
					{
						#if log_on
						log.writeln("if(!agent[i].Prepare()) "+agent_name[i]);
						#endif
					}
					#if error_on
					else
						Error("tj9304yyha");
					#endif
					
					
					if(i==0)
					{
						agent_0_conquer_all_map=Agent_0_conquer_all_map();
											
						if(agent_0_conquer_all_map)
						{
							cout<<"agent_0_conquer_all_map = "<<agent_0_conquer_all_map<<endl;
						}
					}
				}
				
				
				if(sim_end)
				{
					printf("sim-result ranking = %d\n",sim_result_ranking);
					printf("sim-result score = %d\n",sim_result_score);
					
					
					for(i=0;i<agent_n;i++)
					{
						agent_have_sim_msg[i]=0;
					}	
					break;
				}
				
				gettimeofday(&time_stop,0);
				Time_subtract(&time_diff,&time_start,&time_stop);
				
				
				
				
				perception_id=0;
				for(i=0;i<agent_n;i++)
				perception_id=max(perception_id,agent_perception_id[i]);
				
				
				Smart_survey();
				
				
				Rand();
				Agent_attack();
				Agent_inspect();
				
				
				for(i=0;i<agent_n;i++)
				if(agent_attack_target_is[i]>=0)
				{
					cout<<"------------------------sabo want = "<<i<<' '<<agent_attack_target_is[i]<<endl;
				}
				
				/*
				while(1)
				{
					for(i=0;i<agent_n;i++)
					if(agent[i].perception_id<perception_id)
						re_listen[i]=1;
					else
						re_listen[i]=0;
				}*/
				/*
				if(!clear_flag && !first)
				{
					first=1;
					continue;
				}*/
			
				//agent[0].Share_visible_entity();
				//log[agent_pi].writeln("agent[0].Share_visible_entity();");
			
				//All_agent_write_log("Share_visible_entity() 2");
				
				
				
				
					for(i=0;i<agent_n;i++)
					{
						Agent_can_visit_node(i);	
						Agent_can_visit_through_surveyed_node(i);
					}
				
				
				
				
				
				/*
					///clear desire
					for(i=0;i<agent_n;i++)
					{
						agent_inspect_target_is[i]=-1;
					}
				
					for(i=0;i<enermy_n;i++)				
						enermy_inspect_wanted_by[i]=-1;
				*/
				
				
				
				/*
				///xx0
				
				vector<int> agent_in_mission;
				vector<int> mission_node;
				mission_node.clear();
				agent_in_mission.clear();
					
			
				for(i=0;i<agent_n;i++)
				if(agent_role[i]==string_inspector)
				{
					
					string zs;
					int n=node_n;
				
					for(j=1;j<=n;j++)
					node[j].bound=-1;
		
					for(j=1;j<=n;j++)
					if(node[j].is_surveyed)
						node[j].bound=0;
						
					Dijkstra_run_calc_value_for_agent(agent_position_int[i],,i);
					
					
					for(j=1;j<=n;j++)
					node[j].v=0;
					
					for(j=0;j<enermy_n;j++)
					{
						if(!Enermy_get_node(j,zs,perception_id))
						{
							continue;
						}
				
						z=Node_name_string_to_int(zs);
			
						if(!node[z].can_visit[i])
						{
							continue;
						}
				
						if(enermy_is_inspected[j])
						{
							continue;
						}
				
						node_v[z]=1;
					}
					
					
					for(j=1;j<=n;j++)
					if(!node[j].v)
					node[j].value_for_agent[i]=oo;
					
					int flag=0;
					for(j=1;j<=n;j++)
					if(node[j].value_for_agent[i]<oo)
					{
						flag=1;
						break;
					}
					
					if(flag)					
						agent_in_mission.push_back(i);
				}
				
				Maximum_cost_perfect_matching_agent_can_void(agent_in_mission,mission_node);
		
				if(mission_node.size()!=agent_in_mission.size())
					Error("56idk86rk6l");
		
				for(i=0;i<agent_in_mission.size();i++)
				if(mission_node[i]!=-1)
				{
					agent[agent_in_mission[i]].mission_destination=mission_node[i];
				}
				*/
				
				
				if(hand_on)
					Hand_run();
				else
				{
					for(i=0;i<agent_n;i++)
					{
					//	cout<<"agent : "<<i<<" run"<<1<<endl;
						#if log_on
						log.writeln("agent[i].Run(); 1 "+agent_name[i]);
						#endif
					
						Agent_run(i);
					
						#if log_on
						log.writeln("agent[i].Run(); 2 "+agent_name[i]);
						#endif
					//	cout<<"agent : "<<i<<" run"<<2<<endl;
					}
					
					{
							z=0;
							for(i=0;i<agent_n;i++)
							if(agent_mission[i]==string_mission_kuo)z++;
						
							z=min(z,kuo_max_bound_nodes);
						
							for(i=0;i<kuo_area_n;i++)
							kuo_area_agent_s[i]=0;
					
					
							for(A=0;A<kuo_area_n;A++)
							for(i=0;i<agent_n;i++)
							if(agent_mission[i]==string_mission_kuo && agent_mission_param[i]==A)
								kuo_area_agent_s[A]++;
					
							if(z)
							{
								for(A=0;A<kuo_area_n;A++)
								{							
									if(kuo_area_agent_s[A])
										Kuo_run(A,kuo_area_agent_s[A]);
									
								/*	cout<<"area = "<<A<<endl;
									cout<<"area have agents = "<<kuo_d_d[A][0].size()<<endl;
									cout<<"area root = "<<kuo_d_root[A][0]<<endl;
									cout<<"area da = "<<kuo_d_da[A][0]<<endl;							
									for(i=0;i<kuo_d_d[A][0].size();i++)
										cout<<kuo_d_d[A][0][i]<<' ';
									cout<<endl;
								
									cout<<"area inside_node = "<<kuo_d_inside_node[A][0].size()<<endl;
									for(i=0;i<kuo_d_inside_node[A][0].size();i++)
										cout<<kuo_d_inside_node[A][0][i]<<' ';								
									cout<<endl;*/
								}
							}
						
						
							#if error_on
							//Error("90thignhrnb83q47gy");
							#endif
						
							//zz
							//for(i=0;i<=kuo_d_n;i++)
							//	Kuo_d_write(i);
						
						
						
						
						
						
						
							for(A=0;A<kuo_area_n;A++)
							for(i=0;i<agent_n;i++)
							if(agent_mission[i]==string_mission_kuo && agent_mission_param[i]==A)
							{
								#if log_on
								log.writeln("agent[i].Arrange_mission_kuo(); 1 "+agent_name[i]);
								#endif
							
								Agent_arrange_mission_kuo(A,i);
							
								#if log_on
								log.writeln("agent[i].Arrange_mission_kuo(); 2 "+agent_name[i]);
								#endif
								break;
							}
				
							for(i=0;i<agent_n;i++)
							if(agent_mission[i]==string_mission_explorer_min_cost_visit_bound)
							{
								#if log_on
								log.writeln("agent[i].Arrange_mission_explorer_min_cost_visit_bound(); 1 "+agent_name[i]);
								#endif
							
								Agent_arrange_mission_explorer_min_cost_visit_bound(i);
							
								#if log_on
								log.writeln("agent[i].Arrange_mission_explorer_min_cost_visit_bound(); 2 "+agent_name[i]);
								#endif
								break;
							}
				
							for(i=0;i<agent_n;i++)
							if(agent_mission[i]==string_mission_not_explorer_min_cost_visit_bound)
							{
								#if log_on
								log.writeln("agent[i].Arrange_mission_not_explorer_min_cost_visit_bound(); 1 "+agent_name[i]);
								#endif
							
								Agent_arrange_mission_not_explorer_min_cost_visit_bound(i);
							
								#if log_on
								log.writeln("agent[i].Arrange_mission_not_explorer_min_cost_visit_bound(); 2 "+agent_name[i]);
								#endif
								break;
							}
				
							for(i=0;i<agent_n;i++)
							{
								#if log_on
								log.writeln("agent[i].Run_mission(); 1 "+agent_name[i]);
								#endif
							
								Agent_run_mission(i);
							
								#if log_on
								log.writeln("agent[i].Run_mission(); 2 "+agent_name[i]);
								#endif
							}
					}
				}
				
				
				
				
				
					
			/*	for(i=0;i<agent_n;i++)
				for(j=i+1;j<agent_n;j++)
				if(agent[i].mission!="" && agent[i].mission==agent[j].mission && agent[i].mission_destination>=0 && agent[i].mission_destination==agent[j].mission_destination)
				{
					cout<<i<<' '<<agent[i].agent_name<<' '<<agent[i].mission<<' '<<agent[i].mission_destination<<endl;
					
					cout<<j<<' '<<agent[j].agent_name<<' '<<agent[j].mission<<' '<<agent[j].mission_destination<<endl;
					Error("fgio43hy98734ty8934y");					
				}*/
				
				break;
			}
			
			
			All_net_msg_signal_start();
			
			#if log_on
			log.writeln("All_net_msg_signal_start();");
			#endif
			
			Wait_all_net_msg_signal_ready();
			
			
			
			
			#if log_on
			log.writeln("Wait_all_net_msg_signal_ready();");
			#endif
			
						
			Thread_send();
			
			
			
			#if log_on
			log.writeln("Thread_send();");
			#endif
			
			Wait_all_net_msg_signal_done();
			
			#if log_on
			log.writeln("Wait_all_net_msg_signal_done();");
			#endif
			
			
			write();
			
			
			gettimeofday(&time_step_b,0);
			Time_subtract(&time_step_c,&time_step_a,&time_step_b);
			printf("step time = %d\n",time_step_c.tv_usec);		
			
			cout<<"--------"<<endl;				
		}
		return 1;
	}
private:
	////w	
	void write()
	{
		string zs;
		int max_l=0,min_l=oo;
		int i;
		
		printf("ol ai stat node want attack_want\n");
		for(i=0;i<enermy_n;i++)
		{
			zs=enermy_name[i];
			max_l=max(max_l,int(zs.length()));
			min_l=min(min_l,int(zs.length()));
		}
		
		for(i=0;i<enermy_n;i++)
		{
		//	if(enermy_agent[i].role!=string_saboteur)
		//		continue;
			//if(!enermy_agent.Status_is(cc.normal,perception_id))
			//	continue;
			if(enermy_role[i]=="")
			printf("-- ");
			else printf("%c%c ",enermy_role[i][0],enermy_role[i][1]);
			if(i==0)
				printf(" 0 ");
				else
			printf("%2.d ",i);
			
			if(Enermy_status_is(i,string_normal,perception_id))
				printf(" nor ");
			else if(Enermy_status_is(i,string_disabled,perception_id))
				printf(" dis ");
			else if(Enermy_last_known_status_is(i,string_normal))
				printf("-nor ");
			else if(Enermy_last_known_status_is(i,string_disabled))
				printf("-dis ");
			else
				printf(" --- ");
			
			if(Enermy_get_node(i,zs,perception_id))
			{
				printf("%4.d ",Node_name_string_to_int(zs));
			}
			else
			{
				if(Enermy_last_known_position(i,zs))
					printf("%4.d ",-Node_name_string_to_int(zs));
				else
					printf("---- ");
			}
			
			if(enermy_inspect_wanted_by[i]>=0)
			{
				if(enermy_inspect_wanted_by[i]==0)
					printf("   0");
				else
					printf("%4d",enermy_inspect_wanted_by[i]);
			}
			else
				printf("    ");
					
			if(enermy_attack_wanted_by[i]>=0)
			{
				if(enermy_attack_wanted_by[i]==0)
					printf("           0");
				else
					printf("%12d",enermy_attack_wanted_by[i]);
			}
			else 
				printf("            ");
				
			puts("");
		}
		
		
		
		printf("p_id ol ai hp mis no last_action         result          order\n");
		for(i=0;i<agent_n;i++)
			Agent_write(i);			
		
		
		////xxx
		{
			int z=0;
			for(i=1;i<=node_n;i++)
			if(node_is_probed[i])
				z++;
			
			printf("probed = %d / %d = %lf\n",z,node_n,z/double(node_n));
			
			//if(z==node_n)
			//	Error("f894ut834y8hy");			
			
			z=0;
			for(i=1;i<=node_n;i++)
			if(node_is_surveyed[i])
				z++;
			
			printf("surveyed = %d / %d = %lf\n",z,node_n,z/double(node_n));
			
			
						
			z=0;
			for(i=0;i<enermy_n;i++)
			if(enermy_is_inspected[i])
				z++;
			
			printf("inspected = %d / %d = %lf\n",z,enermy_n,z/double(enermy_n));
			printf("edge_n/ = %d / %d = %lf\n",edge_n,simulation_edges,edge_n/double(simulation_edges));
		}	

		printf("prepare time = %d\n",time_diff.tv_usec);
		
		clock_s++;
		cout<<"time of a step = "<<int(clock())-last_clock<<endl;
		last_clock=clock();
		cout<<"time/step = "<<clock()/double(clock_s)<<endl;		
	}
	
	
	int have_history_memory;
	#if log_on
	Log log;
	#endif

	int clear_flag;
}Wang_Yuxin;




///f
struct Free_memory
{
	~Free_memory()
	{
		int i;
		int A;
		
		for(i=0;i<agent_n;i++)			
			close(net_s[i]);
		
		for(i=0;i<max_node_n;i++)
		{
			node_edge_value[i].clear();
			node_edge[i].clear();				
			node_edge_is_surveyed[i];	
			
			for(A=0;A<kuo_area_n;A++)
				kuo_d_d[A][i].clear();		
		}				
	}
}free_memory;









int main(int argc,char *argv[])
{
	/*int size=1024*1024*1024;
	char *p = (char*)malloc(size) + size;
	asm("movl %0, %%esp\n" :: "r"(p));
	*/
	srand(1);
	
	int i,j;
	string zs;
	string zs0;
	vector<string> zv;
	vector<string> A;
	char buff[1000];
	
	system("mkdir log");
	system("mkdir msg");
	
	cout<<(argc);
	for(i=0;i<argc;i++)
		cout<<argv[i]<<endl;
	
	//if(argc<2)return 0;
	
	for(i=0;i<max_agent_n;i++)
		D_e[i]=i;


	for(i=1;i<=max_node_n;i++)
	{
		int z;
		
		zs="";
		z=i-1;
		if(z==0)
		{
			zs="0";
		}		
		else
		{
			while(z)
			{
				zs=char(z%10+'0')+zs;
				z/=10;
			}
		}
		
		node_name_int_to_string[i]="v"+zs;
	}

	for(i=0;i<agent_n;i++)
		do_not_attack[i]=0;


	
	mode.clear();
	mode.push_back(string_alliance_mode);
	
	can_buy_role.clear();
		//if(rand()%2)
		//	can_buy_role.push_back(saboteur);
	//	can_buy_role.push_back(repairer);








	
	
	///A
	if(argc == 1)
	{
		cout<<"A team start"<<endl;
		
		memory_file="A_"+memory_file;
		
		memory_on=0;				
		Memory_clear();
		
		int i;
		int flag=1;
		/*
		if(argc==3)
		{
			zs=argv[2];
			if(zs=="init")
				flag=1;
		}*/
		cout<<flag<<endl;
		Wang_Yuxin.Init("./ini/team_A_agent.ini",flag);
		
		
		Wang_Yuxin.Run();
		return 0;
	}
	
	zs=argv[1];
	
	
	
	if(zs=="r")
	{
		cout<<"A team start"<<endl;
		
		memory_file="A_"+memory_file;
		
		int i;
		int flag=1;
		
		memory_on=1;
		
		/*
		if(argc==3)
		{
			zs=argv[2];
			if(zs=="init")
				flag=1;
		}*/
		cout<<flag<<endl;
		Wang_Yuxin.Init("./ini/team_A_agent.ini",flag);
		
		
		Wang_Yuxin.Run();
		return 0;
	}
	
	if(zs=="h")
	{
		Hand_run();
		return 0;
	}
	
	
	if(zs==string_B)
	{
		cout<<"B team start"<<endl;
		
		memory_file="B_"+memory_file;
		
		int i;
		int flag=0;
		
		if(argc==3)
		{
			zs=argv[2];
			if(zs=="init")
				flag=1;
		}
		
		Wang_Yuxin.Init("./ini/team_B_agent.ini",flag);
		Wang_Yuxin.Run();//m
		return 0;
	}
	
	if(zs==string_k)
	{
		return 0;
	}
	
	if(zs==string_check)
	{
		cout<<"check file = "<<argv[2]<<endl;
		
		FILE *F=fopen(argv[2],"r");
		map<string,int> Dm;
		char rs[1000];
		int line=0;
		int da=0,db=0;
		int z;
		while(fgets(rs,1000,F)!=0)
		{
			line++;
			db++;
			int n=strlen(rs);
			z=0;
			zs=String_segment(rs,1);
			if(zs==string_sight)continue;
			
			for(i=n-1;i>=0;i--)
			{
				if(rs[i]==' ')z++;
				if(z==2)break;
			}
			rs[i]=0;
			zs=rs;
			
			if(Dm[zs])
			{
				cout<<zs+" "<<Dm[zs]<<' '<<line<<endl;
				continue;
			}
			
			da++;
			Dm[zs]=line;
		}
		cout<<"check finished, value = "<<da<<" / "<<db<<endl;
		fclose(F);
		return 0;
	}

	if(zs=="z")
	{
		int i,z;
		int d=1000000;
		for(i=0;i<100;i++)
		{
			while(1)
			{
				z=clock();
				if(z>=i*d && z<(i+1)*d)
				{
					printf("%d %d\n",i,z);
					break;
				}
			}
		}
		return 0;
	}	
	return 0;
}












































