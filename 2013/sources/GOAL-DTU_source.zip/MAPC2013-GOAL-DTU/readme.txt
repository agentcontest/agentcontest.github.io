﻿Multi-Agent Programming Contest 2013 - GOAL-DTU

Participants from DTU Compute:

- Jørgen Villadsen - Supervisor - Associate professor

- Andreas Schmidt Jensen

- Nicolai Christian Christensen

- Andreas Viktor Hess

- Jannick Boese Johnsen

- Øyvind Grønland Woller

- Philip Bratt Ørum

Algorithms, Logic and Graphs Section
Department of Applied Mathematics and Computer Science
Technical University of Denmark

http://www2.compute.dtu.dk/~jovi/MAS/

----------

Uses GOAL SVN revision 6417 with changes to Run.java in src/goal/tools as in diff file

Uses EISMASSim 2.1 wth changes to EnvironmentInterface.java and Mars2013Entity.java in massim/eismassim as in diff files
