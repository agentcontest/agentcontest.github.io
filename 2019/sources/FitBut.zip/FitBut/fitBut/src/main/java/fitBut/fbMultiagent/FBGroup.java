package fitBut.fbMultiagent;

import fitBut.agents.FBAgent;
import fitBut.fbEnvironment.FBGroupMap;
import fitBut.fbEnvironment.FBMap;
import fitBut.fbEnvironment.FBMapLayer;
import fitBut.fbEnvironment.FBMapPlain;
import fitBut.fbEnvironment.utils.Direction;
import fitBut.fbPerceptionModule.data.BlockType;
import fitBut.fbReasoningModule.fbGoals.FBGoal;
import fitBut.fbReasoningModule.fbGoals.FBGoalHoard;
import fitBut.fbReasoningModule.fbGoals.fbMultiGoals.FBGoalAssembleTasks;
import fitBut.fbReasoningModule.fbGoals.fbMultiGoals.FBGoalExplore;
import fitBut.utils.Point;
import fitBut.utils.exceptions.ShouldNeverHappen;
import fitBut.utils.logging.HorseRider;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class FBGroup {
    private static final String TAG = "FBGroup";
    private final FBGroupMap groupMap;
    private FBAgent groupFounder;

    private ConcurrentHashMap<FBAgent, Point> memberShift;
    private boolean active = true;
    private FBMapPlain reserveMap;
    private int lastStep = -1;
    private FBMapPlain groupMapSnapshot = null;
    private ConcurrentHashMap<FBTask, Integer> taskWorkedOnIndex;

    private String getFounderName() {
        return groupFounder.getName();
    }

    void printGroup() {
        StringBuilder groupInfo = new StringBuilder("Founder: " + groupFounder.getName() + "\nMembers: ");

        for (FBAgent agent : memberShift.keySet()) {
            groupInfo.append(agent.getName())
                    .append(": ").append(memberShift.get(agent)).append(", ");
        }
        HorseRider.inquire(TAG, "printGroup: " + groupInfo);
    }

    public FBGroup(FBAgent agent) {
        groupFounder = agent;
        memberShift = new ConcurrentHashMap<>();
        groupMap = new FBGroupMap(this);
        memberShift.put(agent, new Point(0, 0));
    }

    void setInactive() {
        active = false;
    }

    public boolean isActive() {
        return active;
    }

    int getGroupSize() {
        return memberShift.size();
    }

    void registerNewMember(FBAgent fromAgent, FBAgent newAgent, Point vector) {
        Point shiftVector = new Point(vector);
        shiftVector.translate(-newAgent.getLocalPosition().x, -newAgent.getLocalPosition().y); //remove agent difference
        shiftVector.translate(fromAgent.getLocalPosition().x, fromAgent.getLocalPosition().y); //add new origin

        newAgent.setGroup(this);
        memberShift.put(newAgent, shiftVector);
    }

    void importGroup(FBAgent fromAgent, FBAgent otherGroupAgent, Point vector) {
        Point shiftVector = new Point(vector);
        shiftVector.translate(-otherGroupAgent.getLocalPosition().x, -otherGroupAgent.getLocalPosition().y); //remove agent difference
        shiftVector.translate(-otherGroupAgent.getGroupMemberShift().x, -otherGroupAgent.getGroupMemberShift().y);
        shiftVector.translate(fromAgent.getGroupMemberShift().x, fromAgent.getGroupMemberShift().y); //add new origin
        shiftVector.translate(fromAgent.getLocalPosition().x, fromAgent.getLocalPosition().y); //add new origin

        ConcurrentHashMap<FBAgent, Point> otherGroup = otherGroupAgent.getGroup().getMembers();
        otherGroupAgent.getGroup().setInactive();
        for (FBAgent transientMember : otherGroup.keySet()) {
            Point point = otherGroup.get(transientMember);
            Point newGroupMemberShift = new Point(shiftVector);
            newGroupMemberShift.translate(point.x, point.y);
            memberShift.put(transientMember, newGroupMemberShift);
            transientMember.setGroup(this);
        }
    }

    public ConcurrentHashMap<FBAgent, Point> getMembers() {
        return memberShift;
    }

    public Point getShift(FBAgent fbAgent) {
        return memberShift.getOrDefault(fbAgent, new Point(0, 0));
    }

    /**
     * translation from perception to perception
     *
     * @param fromAgent agent seeing
     * @param toAgent   agent receiving
     * @param point     position relative to origin agent
     * @return point translated relative to receiving agent
     */
    private static Point translateEyeToEye(FBAgent fromAgent, FBAgent toAgent, Point point) {
        return translate(fromAgent, toAgent, point.sub(fromAgent.getLocalPosition()).add(toAgent.getLocalPosition()));
    }

    /**
     * non-modifying variant of translateEyeToEye
     *
     * @param fromAgent agent seeing
     * @param toAgent   agent receiving
     * @param point     position relative to origin agent
     * @return new point relative to receiving agent
     */
    public static Point getTranslatedEyeToEye(FBAgent fromAgent, FBAgent toAgent, Point point) {
        return translateEyeToEye(fromAgent, toAgent, new Point(point));
    }

    /**
     * translation from map to map
     *
     * @param fromAgent origin agent
     * @param toAgent   receiving agent
     * @param point     position in origin agent coordination system
     * @return point receiving agent point
     */
    public static Point translate(FBAgent fromAgent, FBAgent toAgent, Point point) {
        if (fromAgent.getGroup() != toAgent.getGroup()) {
            HorseRider.yell(TAG, "translate: Trying to shift between two different groups! " +
                    fromAgent.getName() + " (group of " + fromAgent.getGroup().groupFounder + ") " +
                    toAgent.getName() + " (group of " + toAgent.getGroup().groupFounder + ") ");
        }
        return point.add(fromAgent.getGroupMemberShift()).sub(toAgent.getGroupMemberShift());
    }

    public void printMap() {
        groupMap.printMap();
    }

    public FBMap getGroupMapSnapshot() {
        if (groupMapSnapshot == null) {
            printGroup();
            groupMap.printMap();
            throw new ShouldNeverHappen(TAG + "getGroupMapSnapshot: null" + getName() + "");
        }
        return groupMapSnapshot;
    }

    public String getName() {
        StringBuilder names = new StringBuilder();
        for (FBAgent agent : getMembers().keySet()) {
            names.append(agent.getName()).append(" ");
        }
        return "Group of " + getFounderName() + ": " + names;
    }

    public void runDecisions(int step) {
        this.groupMapSnapshot = this.groupMap.getMapSnapshot(0);
        groupMapSnapshot.printMap();
        Set<FBAgent> undecided = new HashSet<>();
        getMembers().keySet().forEach(fbAgent -> {
            if (!fbAgent.isBusy()) undecided.add(fbAgent);
        });


        // lets assemble tasks
        HorseRider.inquire(TAG, "runDecisions: " + getName() + "go assemble task");
        HashMap<FBAgent, FBGoal> plans = new FBGoalAssembleTasks(this).makeGoals(undecided, groupMapSnapshot);
        taskAndCheckAgents(step, undecided, plans);

        //hoard
        Iterator<FBAgent> iterator = undecided.iterator();
        while (iterator.hasNext()) {
            FBAgent agent = iterator.next();
            FBGoal goalHoard = new FBGoalHoard();
            if (goalHoard.makePlan(agent) != null) {
                agent.addOrder(goalHoard); // set order
                iterator.remove();
            }
        }

        // explore unknown terrain or oldest
        int oldestToBeUsed = 0;
        while (undecided.size() > 0) {
            if (oldestToBeUsed > step) {
                HorseRider.warn(TAG, "runDecisions: run out of steps to trim! " + undecided + " without decision.");
                break;
            }
            HorseRider.challenge(TAG, "runDecisions: " + getName() + " step: " + step + ", get plans for: " + undecided.size() + " map trim: " + oldestToBeUsed);

            FBMapPlain snapshotMap;
            if (oldestToBeUsed > 0) {
                snapshotMap = groupMapSnapshot.getMapSnapshot(oldestToBeUsed);
            } else {
                snapshotMap = groupMapSnapshot;
            }
            snapshotMap.printMap();
            oldestToBeUsed = Math.max(oldestToBeUsed, getStep() - 50);
            oldestToBeUsed += 50;

            taskAndCheckAgents(step, undecided, new FBGoalExplore().makeGoals(undecided, snapshotMap));
        }

        for (FBAgent agent : getMembers().keySet()) {
            agent.informNoMoreGroupDecisions();
        }
    }

    private void taskAndCheckAgents(int step, Set<FBAgent> undecided, HashMap<FBAgent, FBGoal> plans) {
        Iterator<FBAgent> iterator = undecided.iterator();
        while (iterator.hasNext()) {
            FBAgent agent = iterator.next();
            FBGoal goalPlan = plans.get(agent);
            //HorseRider.challenge(TAG, "runDecisions: roam "+agent+" (" + getName() + ") step: " + step + "\n goalPlan: " + goalPlan);
            if (goalPlan != null) {
                HorseRider.challenge(TAG, "runDecisions: roaming : " + agent + " " + goalPlan);
                agent.addOrder(goalPlan); // set order for planned agents
                iterator.remove();
            } else {
                if (agent.isStepTimedOut(step)) { // agent has timed out
                    HorseRider.inquire(TAG, "runDecisions: agent: " + agent.getName() + " removed from decision queue");
                    iterator.remove();
                }
            }
        }
    }

    private void newStep() {
        reserveMap = new FBMapPlain(getName() + "reserved");
        taskWorkedOnIndex = new ConcurrentHashMap<>();
    }

    private boolean checkStep(int step) {
        if (step < lastStep) {
            return false;
        } else if (step > lastStep) {
            lastStep = step;
            newStep();
        }
        return true;
    }

    public synchronized boolean reserveFuture(FBMapLayer future, int step) {
        if (!checkStep(step)) {
            HorseRider.yell(TAG, "reserveStructure: " + future + " reporting with info from previous step: " + step + " vs " + lastStep);
            return false;
        }

        if (FBMap.mergeAble(reserveMap, future)) {
            reserveMap.importLayer(future);
            HorseRider.challenge(TAG, "reserveFuture: merge able " + reserveMap.getName() + " and " + future.getName());
            reserveMap.printMap();
            future.printMap();
            return true;
        } else {
            HorseRider.inquire(TAG, "reserveFuture: can't merge \n" + future + "\nin to\n" + reserveMap);
        }
        //reserveMap.printMap();
        return false;
    }

    public boolean outOfSync(int step) {
        if (!checkStep(step)) {
            HorseRider.yell(TAG, "outOfSync: reporting with info from previous step: " + step + " vs " + lastStep);
            return true;
        }
        return false;
    }

    public ConcurrentHashMap<FBTask, Integer> getTaskWorkedOnIndex(int step) {
        checkStep(step);
        return this.taskWorkedOnIndex;
    }

    public int getStep() {
        return lastStep;
    }

    public boolean isPossibleBorder(Point position, Direction plannedDirection) {

        FBMap.Border b = new FBMap.Border();
        b.addBorder(position, plannedDirection);
        for (FBAgent member : memberShift.keySet()) {
            if (b.isOutside(member.getPosition())) return false;
        }
        return true;
    }

    //todo:
    public boolean isBlockInteresting(@SuppressWarnings("unused") BlockType blockType) {
        return true;
    }

}

