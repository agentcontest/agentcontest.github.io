package fitBut.fbActions;

import fitBut.agents.FBAgent;
import fitBut.agents.FBSimAgent;
import fitBut.fbEnvironment.FBBody;
import fitBut.fbEnvironment.FBCells.objects.FBBlockObject;
import fitBut.fbEnvironment.utils.Rotation;
import fitBut.fbMultiagent.FBTask;
import fitBut.fbPerceptionModule.data.ActionResult;
import fitBut.fbReasoningModule.fbGoals.FBGoalSplit;
import fitBut.utils.Point;
import fitBut.utils.logging.HorseRider;
import eis.iilang.Action;
import eis.iilang.Identifier;
import eis.iilang.Numeral;

import java.util.HashSet;

public class FBConnect extends FBAction {

    private static final String TAG = "FBConnect";
    private final Point pointTo;
    private final FBAgent partner;
    private Point pointFrom;
    private String partnerName;
    private final Point disconnectFrom;
    private final Point disconnectTo;
    private FBTask task;

    @Override
    public Action getEisAction() {
        return new Action("connect", new Identifier(partnerName), new Numeral(pointFrom.x), new Numeral(pointFrom.y));
    }

    @Override
    public void succeededEffect(FBAgent agent) {
        HorseRider.inquire(TAG, "succeededEffect: connecting " + pointFrom + " to " + pointTo);
        Point agentPosition = agent.getPosition();
        Point attachingFrom = agentPosition.sum(pointFrom);
        Point attachingTo = agentPosition.sum(pointTo);


        FBBlockObject fromBlockObject = agent.getMap().getBlockObjectAt(attachingFrom);
        FBBlockObject toBlockObject = agent.getMap().getBlockObjectAt(attachingTo);

        if (fromBlockObject != null && toBlockObject != null) {
            HashSet<Point> list = new HashSet<>();
            list.add(attachingTo.diff(partner.getPosition()));
            FBBody partnerBody = partner.getBody().getClone();
            attachLinkedNeighbours(agent, partnerBody, attachingFrom, list);
            setDisconnectOutsideOfTask(agent);
        } else {
            HorseRider.yell(TAG, "succeededEffect: connecting blocks not present! " + fromBlockObject + " " + toBlockObject);
        }
    }

    private void setDisconnectOutsideOfTask(FBAgent agent) {
        agent.addOrder(new FBGoalSplit(disconnectFrom, disconnectTo, task));
        agent.getGroup().getTaskWorkedOnIndex(agent.getStep()).put(task, 1);
        agent.setBusy();
    }

    private void attachLinkedNeighbours(FBAgent agent, FBBody partnerBody, Point source, HashSet<Point> linked) {
        for (Point link : linked) {
            Point point = partner.getPosition().sum(link);
            FBBlockObject blockObject = agent.getMap().getBlockObjectAt(point);
            if (blockObject != null) {
                if (blockObject.isNotAttachedTo(agent)) { //attach partner blocks
                    blockObject.addAttachedTo(agent);
                    HorseRider.inquire(TAG, "attachLinkedNeighbours: " + agent + " linking " + source.diff(agent.getPosition()) + " " + point.diff(agent.getPosition()) +
                            " (" + source + " " + point + ")");
                    agent.getBody().addCell(source.diff(agent.getPosition()), point.diff(agent.getPosition()), (FBBlockObject) blockObject.getClone());
                    attachLinkedNeighbours(agent, partnerBody, point, partnerBody.getLinked(point.diff(partner.getPosition())));
                }
            }
        }
    }

    @Override
    public FBSimAgent simulate(FBAgent agent) {
        return FBSimAgent.getNewSimAgent(agent, Point.zero(), Rotation.NULL);
    }

    @Override
    public void getAgentActionFeedback(ActionResult lastActionResult, FBAgent fbAgent) {
        switch (lastActionResult) {
            case SUCCESS:
                succeededEffect(fbAgent);
                break;
            case FAILED_RANDOM:
                break;
            case FAILED_PARAMETER:
                HorseRider.yell(TAG, "getAgentActionFeedback: FAILED_PARAMETER action: " + fbAgent + "First parameter is not an agent of the same team OR x and y cannot be parsed to valid integers.");
                break;
            case FAILED_PARTNER:
                HorseRider.yell(TAG, "getAgentActionFeedback: FAILED_PARTNER action: " + fbAgent + "The partner's action is not connect OR failed randomly OR has wrong parameters.");
                break;
            case FAILED_TARGET:
                HorseRider.yell(TAG, "getAgentActionFeedback: FAILED_TARGET action: " + fbAgent + "At least one of the specified blocks is not at the given position or not attached to the agent or already attached to the other agent.");
                break;
            case FAILED:
                HorseRider.yell(TAG, "getAgentActionFeedback: FAILED action: " + fbAgent + " The given positions are too far apart OR one agent is already attached to the other (or through other blocks), or connecting both blocks would violate the size limit for connected structures.");
                fbAgent.addOrder(new FBGoalSplit(disconnectFrom, disconnectTo, task));
                break;
            default:
                HorseRider.yell(TAG, "getAgentActionFeedback: FAILED action: " + fbAgent + " " + lastActionResult);
                break;
        }
    }

    public FBConnect(FBAgent partner, Point point, Point pointTo, Point disconnectFrom, Point disconnectTo, FBTask task) {
        //super(ei);
        this.pointFrom = point;
        this.pointTo = pointTo;
        partnerName = partner.getName();
        this.partner = partner;
        this.disconnectFrom = disconnectFrom;
        this.disconnectTo = disconnectTo;
        this.task = task;
    }

}


