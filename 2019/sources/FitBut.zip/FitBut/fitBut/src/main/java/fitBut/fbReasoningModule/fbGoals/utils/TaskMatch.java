package fitBut.fbReasoningModule.fbGoals.utils;

import fitBut.agents.FBAgent;
import fitBut.fbEnvironment.FBBody;
import fitBut.fbEnvironment.FBCells.objects.FBBlockObject;
import fitBut.fbEnvironment.utils.Rotation;
import fitBut.fbMultiagent.FBTask;
import fitBut.fbPerceptionModule.data.BlockType;
import fitBut.utils.Point;
import fitBut.utils.PointAndDir;

import java.util.*;

/**
 * @author : Vaclav Uhlir
 * @since : 8.10.2019
 **/
public class TaskMatch {

    //todo: move to its own decision-type class
    public static ArrayList<TaskMatchStructure> completeness(FBTask task, FBAgent agent) {
        ArrayList<TaskMatchStructure> matches = new ArrayList<>();
        HashMap<Point, FBBlockObject> agentBody = agent.getBody().getBodyBlocks();
        if (agentBody.isEmpty()) { // agent doesn't have body
            return matches;
        }

        HashMap<Point, BlockType> taskBody = task.getTaskBody();
        HashMap<PointAndDir, HashSet<Point>> indexed = new HashMap<>(); //offset and point

        for (Point taskPoint : taskBody.keySet()) { // for all point in task
            BlockType taskBlockType = taskBody.get(taskPoint);
            for (Point bodyPoint : agentBody.keySet()) { // for all body cells
                BlockType bodyBlockType = agentBody.get(bodyPoint).getBlockType();
                if (bodyBlockType.equals(taskBlockType)) {     // found same block
                    //lets check if neighbors correspond
                    for (Rotation rotation : Rotation.fourDirections()) {
                        Point matchCenterPoint = bodyPoint.getRotated(rotation).diff(taskPoint);
                        PointAndDir index = new PointAndDir(matchCenterPoint, rotation.clockDirection());
                        indexed.computeIfAbsent(index, pointAndDir -> new HashSet<>());
                        HashSet<Point> offsetIndex = indexed.get(index);
                        if (offsetIndex.contains(taskPoint)) continue; //indexed
                        offsetIndex.add(taskPoint);
                        TaskMatchStructure hit = new TaskMatchStructure(task, agent, taskPoint, bodyPoint, rotation);
                        checkLinkedNeighbours(agent.getBody(), agentBody, taskBody, bodyPoint, offsetIndex, rotation, hit, matchCenterPoint);
                        hit.setHitRatioTo(taskBody.size());
                        matches.add(hit);
                    }
                }
            }
        }
        return matches;
    }

    private static void checkLinkedNeighbours(FBBody body, HashMap<Point, FBBlockObject> agentBody, HashMap<Point, BlockType> taskBody, Point bodyPoint,
                                              HashSet<Point> indexed, Rotation rotation, TaskMatchStructure hit, Point matchCenterPoint) {
        for (Point connectedBlock : body.getLinked(bodyPoint)) {
            Point taskPoint = matchCenterPoint.sum(connectedBlock.getRotated(rotation));
            if (indexed.contains(taskPoint)) continue; //indexed
            indexed.add(taskPoint);
            if (taskBody.get(taskPoint) != null && agentBody.get(connectedBlock) != null &&
                    taskBody.get(taskPoint).equals(
                            agentBody.get(connectedBlock).getBlockType())) {
                hit.addHit(taskPoint);
                checkLinkedNeighbours(body, agentBody, taskBody, connectedBlock, indexed, rotation, hit, matchCenterPoint);
            }
        }
    }

    public static class TaskMatchStructure {
        private final FBTask task;
        private final FBAgent agent;
        private final Point taskPoint;
        private final Point bodyPoint;
        private final Rotation rotation;
        private final HashSet<Point> hits;
        private double hitRatio;

        TaskMatchStructure(FBTask task, FBAgent agent, Point taskPoint, Point bodyPoint, Rotation rotation) {
            this.task = task;
            this.agent = agent;
            this.taskPoint = taskPoint;
            this.bodyPoint = bodyPoint;
            this.rotation = rotation;
            this.hits = new HashSet<>();
            this.hits.add(taskPoint);
        }

        void addHit(Point hitPoint) {
            this.hits.add(hitPoint);
        }

        public int getCount() {
            return hits.size();
        }

        void setHitRatioTo(int hitRatioTo) {
            this.hitRatio = (double) getCount() / (double) hitRatioTo;
        }

        public double getHitRatio() {
            return hitRatio;
        }

        public FBTask getTask() {
            return this.task;
        }

        public Rotation getRotation() {
            return rotation;
        }

        public FBAgent getAgent() {
            return agent;
        }

        public HashSet<Point> getHits() {
            return this.hits;
        }

        public Point bodyEquivalentOf(Point taskPoint) {
            return bodyPoint.sum(taskPoint.diff(this.taskPoint).getRotated(rotation));
        }

        public Point taskEquivalentOf(Point bodyPoint) {
            return this.taskPoint.sum(bodyPoint.diff(this.bodyPoint).getRotated(rotation.mirrored()));
        }

        public int getNameHash() {
            return (task.getName() + agent.getName()).hashCode();
        }
    }
}
