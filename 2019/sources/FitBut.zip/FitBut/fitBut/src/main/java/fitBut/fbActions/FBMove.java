package fitBut.fbActions;

import fitBut.agents.FBAgent;
import fitBut.agents.FBSimAgent;
import fitBut.fbEnvironment.utils.Direction;
import fitBut.fbEnvironment.utils.Rotation;
import fitBut.fbPerceptionModule.data.ActionResult;
import fitBut.utils.logging.HorseRider;
import eis.iilang.Action;
import eis.iilang.Identifier;

import fitBut.utils.Point;


public class FBMove extends fitBut.fbActions.FBAction {
    private static final String TAG = "FBMove";
    private final Direction direction;


    public FBMove(int x, int y) {
        direction = Direction.getDirectionFromXY(x, y);
    }

    private Direction getPlannedDirection() {
        return direction;
    }

    @Override
    public Action getEisAction() {
        return new Action("move", new Identifier(direction.getText()));
    }

    @Override
    public void getAgentActionFeedback(ActionResult lastActionResult, FBAgent fbAgent) {
        switch (lastActionResult) {
            case SUCCESS:
                succeededEffect(fbAgent);
                break;
            case FAILED_FORBIDDEN:
                hitBorder(fbAgent);
                break;
            case FAILED_RANDOM:
                break;
            case FAILED_PATH://content moved to after step
                /*if (checkIfBodyFoundBorder(fbAgent)) {
                    //hitBorder(fbAgent);
                } else {
                    HorseRider.yell(TAG, "getAgentActionFeedback: FAILED action: " + fbAgent + " " + lastActionResult);
                }*/
                break;
            default:
                HorseRider.yell(TAG, "getAgentActionFeedback: FAILED action: " + fbAgent + " " + lastActionResult);
                break;
        }
    }

    @Override
    public void getAgentActionFeedbackReeval(ActionResult lastActionResult, FBAgent fbAgent) {
        if (lastActionResult == ActionResult.FAILED_PATH) {
            if (checkIfBodyFoundBorder(fbAgent)) {
                hitBorder(fbAgent);
            } else {
                HorseRider.yell(TAG, "getAgentActionFeedbackReeval: FAILED action: " + fbAgent + " " + lastActionResult);
            }
        }
    }

    private void hitBorder(FBAgent fbAgent) {
        HorseRider.challenge(TAG, "hitBorder: " + fbAgent);
        if (fbAgent.getGroup().isPossibleBorder(fbAgent.getPosition(), getPlannedDirection())) {
            if (fbAgent.getBody().getList().isEmpty()) {
                fbAgent.getLocalMap().setBorder(fbAgent.getLocalPosition(), getPlannedDirection());
            } else {
                Point moveVector = getPlannedDirection().getVector();
                Point min = new Point(0, 0);
                Point max = new Point(0, 0);
                for (Point point : fbAgent.getBody().getList()) {
                    min = Point.min(min, point);
                    max = Point.max(max, point);
                }
                if (Point.isPositive(moveVector)) {
                    fbAgent.getLocalMap().setBorder(fbAgent.getLocalPosition().sum(max), getPlannedDirection());
                } else {
                    fbAgent.getLocalMap().setBorder(fbAgent.getLocalPosition().sum(min), getPlannedDirection());
                }
            }
        }
    }

    /**
     * checks if body have space to move
     *
     * @param fbAgent agent owning body
     * @return true if body has no reason to not move
     */
    private boolean checkIfBodyFoundBorder(FBAgent fbAgent) {
        if (fbAgent.getBody().getList().isEmpty()) return false;
        Point moveVector = getPlannedDirection().getVector();
        boolean hitUnknown = fbAgent.getLocalMap().isTraversableAt(
                fbAgent.getLocalPosition().sum(moveVector),
                fbAgent.getBody().getList(),
                Rotation.NULL,
                fbAgent.getBody().getShiftedList(fbAgent.getLocalPosition()));
        if (hitUnknown) {
            HorseRider.warn(TAG, "checkIfBodyFoundBorder: " + fbAgent + " hit something " + fbAgent.getBody());
        }
        return hitUnknown;
    }

    @Override
    public void succeededEffect(FBAgent agent) {
        agent.updateMapPosition(direction.getVector());
    }

    @Override
    public FBSimAgent simulate(FBAgent agent) {

        Point moveVector = getPlannedDirection().getVector();

        return FBSimAgent.getNewSimAgent(agent, moveVector, Rotation.NULL);
    }


    public FBMove(Direction direction) {
        this.direction = direction;
    }

}
