package fitBut.utils;

import fitBut.fbEnvironment.utils.Direction;
import fitBut.fbEnvironment.utils.Rotation;
import fitBut.utils.logging.HorseRider;

import static fitBut.fbEnvironment.utils.Direction.*;

/**
 * @author : Vaclav Uhlir
 * @since : 16/09/2019
 **/

public class Point extends java.awt.Point {
    private static final int NUM_ALIGN = 2;
    private static final String TAG = "Point";

    public Point(int x, int y) {
        super(x, y);
    }

    public Point(Point vector) {
        super(vector.x, vector.y);
    }

    public static Point zero() {
        return new Point(0, 0);
    }

    public static Point min(Point point1, Point point2) {
        return new Point(Math.min(point1.x, point2.x), Math.min(point1.y, point2.y));
    }

    public static Point max(Point point1, Point point2) {
        return new Point(Math.max(point1.x, point2.x), Math.max(point1.y, point2.y));
    }

    public static boolean isPositive(Point vector) {
        return vector.x >= 0 && vector.y >= 0;
    }

    public Point add(Point point) {
        this.x += point.x;
        this.y += point.y;
        return this;
    }

    public Point sub(Point point) {
        this.x -= point.x;
        this.y -= point.y;
        return this;
    }

    public int distance(Point b) {
        return (Math.abs(this.x - b.x) + Math.abs(this.y - b.y)); // Manhattan
    }


    @Override
    public String toString() {
        String xs = "" + x;
        String ys = "" + y;
        return "[" + " ".repeat(Math.max(0, NUM_ALIGN - xs.length())) + xs +
                "," + " ".repeat(Math.max(0, NUM_ALIGN - ys.length())) + ys + "]";
    }

    public void translate(Point vector) {
        this.add(vector);
    }

    /**
     * new difference vector
     *
     * @param diffTo target
     * @return vector
     */
    public Point diff(Point diffTo) {
        return new Point(this.x - diffTo.x, this.y - diffTo.y);
    }

    /**
     * new sum vector
     *
     * @param point target
     * @return vector
     */
    public Point sum(Point point) {
        return new Point(this.x + point.x, this.y + point.y);
    }

    /**
     * gets Majority direction
     *
     * @return Direction
     */
    public Direction getDirection() {
        if (x < 0 && Math.abs(x) > Math.abs(y)) {
            return W;
        } else if (x > 0 && Math.abs(x) > Math.abs(y)) {
            return E;
        } else if (y < 0) {
            return N;
        } else if (y > 0) {
            return S;
        } else {
            HorseRider.yell(TAG, "getRotation: wrong direction x:" + x + " y:" + y);
            return __UNKNOWN;
        }

    }

    public Point getRotated(Rotation rotation) {
        return new Point(this).rotate(rotation);
    }

    @SuppressWarnings("SuspiciousNameCombination")
    public Point rotate(Rotation rotation) {
        int temp;
        switch (rotation) {
            case CW:
                temp = x;
                this.x = -y;
                this.y = temp;
                break;
            case CCW:
                temp = x;
                this.x = y;
                this.y = -temp;
                break;
            case OPPOSITE:
                this.x = -x;
                this.y = -y;
                break;
            case NULL:
            case __UNKNOWN:
                break;
        }
        return this;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Point) {
            Point pt = (Point) obj;
            return (x == pt.x) && (y == pt.y);
        }
        return super.equals(obj);
    }

    public int size() {
        return Math.abs(x) + Math.abs(y);
    }
}
