package fitBut.agents;

import fitBut.fbEnvironment.FBCells.objects.FBBlockObject;
import fitBut.fbEnvironment.FBCells.objects.FBCellObject;
import fitBut.fbEnvironment.FBMap;
import fitBut.fbEnvironment.FBMapLayer;
import fitBut.fbEnvironment.utils.FBObjectType;
import fitBut.fbEnvironment.utils.Rotation;
import fitBut.fbReasoningModule.fbGoals.utils.PlanHelper;
import fitBut.utils.Point;
import fitBut.utils.exceptions.ShouldNeverHappen;
import fitBut.utils.logging.HorseRider;

/**
 * @author : Vaclav Uhlir
 * @since : 06/10/2019
 **/

public class FBSimAgent extends FBAgent {
    private static final String TAG = "FBSimAgent";
    private int simStep;
    private FBAgent originAgent;

    public FBSimAgent(FBAgent parent, int simStep) {
        super();
        this.name = parent.getName();
        this.map = new FBMapLayer(getName() + " sim " + simStep + " :", parent.getMap());
        this.simStep = simStep;
        this.originAgent = parent;
    }

    @Override
    public FBMap getMap() {
        return map;
    }

    /**
     * create new simulation agent based on parent
     *
     * @param agent      parent
     * @param moveVector move vector
     * @param rotation   rotation
     * @return new agent
     */
    public static FBSimAgent getNewSimAgent(FBAgent agent, Point moveVector, Rotation rotation) {
        FBSimAgent simAgent;

        if (agent instanceof FBSimAgent) {
            simAgent = new FBSimAgent(((FBSimAgent) agent).getOriginAgent(), agent.getStep() + 1);
        } else {
            simAgent = new FBSimAgent(agent, agent.getStep() + 1);
        }

        //agent block
        FBCellObject agentBlock = agent.getMap().getNodeFirstByType(agent.getPosition(), FBObjectType.__FBAgent);
        Point newPos = agent.getPosition().sum(moveVector);

        simAgent.setMapPosition(newPos);
        if (agentBlock == null) { //TODO: this should not happen -> debug
            for (Point neighbour : PlanHelper.generateDirections(agent.getPosition(), 0)) { // check all four side cells
                HorseRider.warn(TAG, "getNewSimAgent: " + agent.getName() + " agents around: " + neighbour +
                        agent.getMap().getNodeFirstByType(neighbour, FBObjectType.__FBAgent));
            }
            HorseRider.yell(TAG, " getNewSimAgent: " + agent.getName() + " self agent not on " + agent.getPosition() + " in map:\n" + agent.getMap());
            return simAgent;
        }
        simAgent.getMap().addCellObject(newPos, agentBlock, agent.getStep() + 1);

        //body
        addLinkedBlocks(simAgent, agent, Point.zero(), newPos, rotation);
        //simAgent.setBody(agent.getBody().getRotatedBody(rotation));
        return simAgent;
    }

    private static void addLinkedBlocks(FBSimAgent simAgent, FBAgent agent, Point source, Point newPos, Rotation rotation) {
        for (Point bodyPart : agent.getBody().getLinked(source)) {
            if (bodyPart.equals(Point.zero())) continue;
            if (simAgent.getBody().getList().contains(bodyPart)) continue;
            FBBlockObject bodyBlock = agent.getBody().getBodyBlocks().get(bodyPart);//.getBlockObjectAt(agent.getPosition().sum(bodyPart));
            if (bodyBlock == null) {
                throw new ShouldNeverHappen(TAG + " getNewSimAgent: " + agent.getName() + " bodyBlock null");
            }
            simAgent.getBody().addCell(source, bodyPart, bodyBlock);
            simAgent.getMap().addCellObject(newPos.sum(bodyPart.getRotated(rotation)), bodyBlock, agent.getStep() + 1);
            addLinkedBlocks(simAgent, agent, bodyPart, newPos, rotation);
        }
    }

    @Override
    public Point getPosition() {
        return getLocalPosition();
    }

    @Override
    public int getStep() {
        return this.simStep;
    }

    private FBAgent getOriginAgent() {
        return originAgent;
    }

    public FBMapLayer getMapLayer() {
        return (FBMapLayer) this.map;
    }
}
