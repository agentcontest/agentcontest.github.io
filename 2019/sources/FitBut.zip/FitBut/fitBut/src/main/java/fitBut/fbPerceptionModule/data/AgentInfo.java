package fitBut.fbPerceptionModule.data;

/**
 * @author : Vaclav Uhlir
 * @since : 12.9.2019
 **/
public class AgentInfo {

    private String name = "Unknown";
    private int vision;
    private int energy;
    private boolean disabled;
    private String team;

    public void setTeam(String team) {
        this.team = team;
    }

    public String getTeam() {
        return team;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setVision(int vision) {
        this.vision = vision;
    }

    public int getVision() {
        return vision;
    }

    public void setEnergy(int energy) {
        this.energy = energy;
    }

    public int getEnergy() {
        return energy;
    }

    public void setDisabled(boolean disabled) {
        this.disabled = disabled;
    }

    public boolean getDisabled() {
        return disabled;
    }
}
