package fitBut.utils;

/**
 * @author : Vaclav Uhlir
 * @since : 13.10.2019
 **/
public class FBConstants {
    public static final int MAX_TASK_COUNT = 50;
    public static final int HOARD_LIMIT = 1;
    public static final int MAP_SPACER_SIZE = 3;
    public static final int TIME_RESERVE = 50;
    public static final int MAX_SIM_JOIN_STEP = 15;
}
