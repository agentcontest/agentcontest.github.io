package fitBut.agents;


import fitBut.MailService;
import fitBut.fbActions.*;
import fitBut.fbEnvironment.FBBody;
import fitBut.fbEnvironment.FBMap;
import fitBut.fbEnvironment.FBMapPlain;
import fitBut.fbMultiagent.FBGroup;
import fitBut.fbMultiagent.FBTask;
import fitBut.fbPerceptionModule.FBPerceptsProcessorV2;
import fitBut.fbPerceptionModule.data.AgentInfo;
import fitBut.fbPerceptionModule.data.SimInfo;
import fitBut.fbReasoningModule.fbGoals.*;
import fitBut.fbReasoningModule.fbGoals.utils.PrioritySelector;
import fitBut.utils.Point;
import fitBut.utils.exceptions.ShouldNeverHappen;
import fitBut.utils.logging.HorseRider;
import eis.iilang.Action;
import eis.iilang.Percept;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.TreeMap;

import static fitBut.utils.FBConstants.TIME_RESERVE;

public class FBAgent extends Agent {
    private static final String TAG = "FBAgent";
    private final FBPerceptsProcessorV2 perceptsProcessor = new FBPerceptsProcessorV2();
    private final AgentInfo agentInfo = new AgentInfo();
    private final SimInfo simInfo = new SimInfo();

    private FBGroup group;
    FBMap map;

    private Point agentMapPos = new Point(0, 0);

    private FBGoal stepAction = null;
    private FBGoal lastAction = null;
    private FBBody agentBody = new FBBody(this);
    private TreeMap<Integer, FBGoal> goalPool = null;
    private boolean groupDecisionsDone = false;
    private boolean agentDecisionsDone = false;
    private boolean multiaAgentConnectionFlag = false;
    private boolean busy;

    /**
     * test agent boot
     *
     * @param name test name
     */
    public FBAgent(String name) {
        super(name, new MailService());
        HorseRider.yell(TAG, "FBAgent: !!!!!!!!!! TESTING BOOT !!!!!!!!!!!");
        agentInfo.setName(name);
        agentInfo.setVision(5);
        map = new FBMapPlain(name);
        group = new FBGroup(this);
    }

    /**
     * constructor for SimAgent
     */
    public FBAgent() {
        if (!(this instanceof FBSimAgent)) {
            throw new ShouldNeverHappen(TAG + " FBAgent: " + this.getName() + " this constructor is reserved for virtual agents");
        }
    }

    public FBGroup getGroup() {
        return (group);
    }

    public FBMap getLocalMap() {
        return (map);
    }

    public FBMap getMap() {
        if (this.getGroup().isActive()) {
            try {
                return getGroup().getGroupMapSnapshot();
            } catch (ShouldNeverHappen h) {
                HorseRider.yell(TAG, "getMap: didn't get group map ", h);
                return getLocalMap();
            }
        } else {
            throw new ShouldNeverHappen(TAG + " getMap: " + getName() + " ");
        }

    }

    /**
     * runs check on seen entities in local map
     *
     * @return list of position
     */
    public HashSet<Point> getSeeingFriendlies() {
        return map.getSeeingAgents(getLocalPosition(), agentInfo.getVision());
    }

    /**
     * agent position translation
     *
     * @param vector movement
     */
    public void updateMapPosition(Point vector) {
        agentMapPos.translate(vector);
    }

    /**
     * current position af agent on its map
     *
     * @return position
     */
    public Point getLocalPosition() {
        return agentMapPos;
    }

    public void setMapPosition(Point point) {
        agentMapPos = point;
    }

    public void setGroup(FBGroup fbGroup) {
        this.group = fbGroup;
    }

    public int getStep() {
        return simInfo.getStep();
    }

    public Point getGroupMemberShift() {
        return this.getGroup().getShift(this);
    }

    public Point getPosition() {
        Point point = new Point(getLocalPosition());
        if (this.getGroup().isActive()) {
            point.translate(getGroupMemberShift().x, getGroupMemberShift().y);
        } else {
            throw new ShouldNeverHappen(TAG + " getPosition: " + getName() + " ");
        }
        return point;
    }

    public AgentInfo getAgentInfo() {
        return agentInfo;
    }

    @Override
    public void handleMessage(Percept message, String sender) {
    }

    /**
     * @param step in question
     * @return true if agent is already in higher step
     * or if action was set (probably by priority Action)
     */
    @Override
    public boolean isStepTimedOut(int step) {
        return simInfo.getStep() > step || stepAction != null;
    }

    @Override
    public Action step() {
        //set up new step
        stepInit();

        //get percepts
        Collection<Percept> percepts = getPercepts();

        //read percepts
        perceptsProcessor.processPercepts(percepts);

        //evaluate last action (like step)
        if (lastAction != null) {
            if (lastAction.getAction().getClass().toString().equals(FBAction.getActionClassFromString(simInfo.getLastAction()))) {
                lastAction.getAction().getAgentActionFeedback(simInfo.getLastActionResult(), this);
            } else {
                HorseRider.yell(TAG, "step: " + getName() + " last action mismatch:" +
                        " agent: " + lastAction.getAction().getClass() +
                        " sim: " + FBAction.getActionClassFromString(simInfo.getLastAction()) + "(" + simInfo.getLastAction() + ")");
            }
        }

        HorseRider.inquire(TAG, "action:  +++ in step " + simInfo.getStep() +
                " agent " + agentInfo.getName() + " is at " + getLocalPosition() +
                "\nwith body:\n" + getBody());

        // update map based on perceptions
        perceptsProcessor.runMapUpdate(map, this);

        //second action eval (with new map data)
        if (lastAction != null) {
            if (lastAction.getAction().getClass().toString().equals(FBAction.getActionClassFromString(simInfo.getLastAction()))) {
                lastAction.getAction().getAgentActionFeedbackReeval(simInfo.getLastActionResult(), this);
            }
        }

        //check agent body
        agentBody.checkIntegrity(map, getLocalPosition());


        //report finished first stage
        new Thread(() -> mailbox.reportIn(this, simInfo.getStep())).start();


        //local decisions
        if (agentInfo.getDisabled()) {
            // agent is disabled and won't do anything this step
            HorseRider.warn(TAG, "action: " + agentInfo.getName() + " is disabled at " + getLocalPosition());
            addOrder(new FBGoalDoNothing());
            getBody().dropAll();
            setBusy();
        } else {
            // run local decision
            runLocalDecision();
        }
        informNoMoreAgentDecisions();


        //pause until timeout or decision
        while (this.stepAction == null && simInfo.getDeadline() > (System.currentTimeMillis() + TIME_RESERVE)) {
            try {
                //HorseRider.challenge(TAG, "action: " + getName() + "\ntime: "+System.currentTimeMillis()+" + "+ TIME_RESERVE +"\nutil: "+simInfo.getDeadline());
                Thread.sleep(TIME_RESERVE / 2);
                //todo: lock.wait(10);
            } catch (InterruptedException e) {
                e.printStackTrace();
                HorseRider.yell(TAG, "action: " + getName() + " has been sleep interrupted ", e);
            }
        }

        //time is out
        if (this.stepAction == null) {
            setOrderFromBackup();
            HorseRider.yell(TAG, "action: " + getName() +
                    " running out of time! Defaulting to action: " + stepAction.getAction().getEisAction().toProlog() +
                    "\ntime: " + System.currentTimeMillis() + "\nutil: " + simInfo.getDeadline());
        }
        HorseRider.inform(TAG, "step: " + getStep() + " " + getName() + " returning action " + stepAction.getAction().getEisAction().toProlog() + " \tfrom goal " + stepAction);

        lastAction = stepAction;
        return stepAction.getAction().getEisAction();
    }

    /**
     * local decisions set
     */
    private void runLocalDecision() {
        //dodge clear actions
        FBGoal goalDodge = new FBGoalDodge();
        if (goalDodge.makePlan(this) != null) {
            addOrder(goalDodge);
        }
        /* hoarding is now run from group
        if(getGroup().getMembers().size()>1) {
            FBGoal goalHoard = new FBGoalHoard();
            if (goalHoard.makePlan(this) != null) {
                addOrder(goalHoard); // set order
            }
        }*/

        //go near submit //todo: don't use group map here!
        FBGoalGoNearSubmit goalFBGoalGoNearSubmit = new FBGoalGoNearSubmit();
        if (goalFBGoalGoNearSubmit.makePlan(this) != null) {
            addOrder(goalFBGoalGoNearSubmit);
        }

        //clear obstacles
        FBGoal goalDig = new FBGoalDig();
        if (goalDig.makePlan(this) != null) {
            addOrder(goalDig);
        }

    }

    private void stepInit() {
        stepAction = null;
        goalPool = null;
        groupDecisionsDone = false;
        agentDecisionsDone = false;
        multiaAgentConnectionFlag = false;
        busy = false;
    }

    private FBGoal getActionFromPool() {
        if (goalPool != null && !goalPool.isEmpty()) {
            return goalPool.pollLastEntry().getValue();
        } else {
            return new FBGoalDoNothing();
        }
    }

    public FBAgent(String name, MailService service) {
        super(name, service);

        map = new FBMapPlain(name);
        group = new FBGroup(this);

        perceptsProcessor.setAgentInfo(agentInfo);
        perceptsProcessor.setSimInfo(simInfo);
    }

    /**
     * tries to set goal based on reservation system approval
     *
     * @param goal current wanted goal
     * @return true if order was set or no order will be needed
     */
    private synchronized boolean setOrder(FBGoal goal) {
        if (!group.outOfSync(getStep())) {
            if (multiaAgentConnectionFlag && (
                    goal.getAction() instanceof FBMove ||
                            goal.getAction() instanceof FBRotate)) {
                HorseRider.warn(TAG, "setOrder: " + getName() + " trying to move while connected to other agents! " + goal);
                return false;
            }
            if (!group.reserveFuture(goal.getFuture(this), getStep())) {
                HorseRider.warn(TAG, "reserveRotate: " + this + " failed to reserve structure for order " + goal);
                FBAction action = goal.getAction();
                if (action instanceof FBConnect ||
                        action instanceof FBDetach ||
                        action instanceof FBDisconnect ||
                        action instanceof FBSkip ||
                        action instanceof FBSubmit) { //action which can be tried without reservation //todo: add notice to actions in conflict
                    HorseRider.inquire(TAG, "setOrder: " + getName() + " is submitting conflict order" + goal);
                    this.stepAction = goal;
                    return true;
                }
                return false;
            }
            HorseRider.inquire(TAG, "setOrder: " + getName() + " has order " + goal);
            this.stepAction = goal;
        } else {
            HorseRider.yell(TAG, "setOrder: agent " + this + " out of sync " + getStep());
        }
        return true;
    }

    public FBBody getBody() {
        return this.agentBody;
    }

    @Override
    public String toString() {
        return getName() + " " + getLocalPosition() + "/" + getPosition();
    }

    /**
     * adds order to the queue based on priority
     *
     * @param goal order
     */
    public void addOrder(FBGoal goal) {
        addPriorityOrder(goal, PrioritySelector.getBasePriority(goal));
    }

    /**
     * adds order with specific priority
     *
     * @param goal     order
     * @param priority specific int
     */
    private void addPriorityOrder(FBGoal goal, int priority) {
        if (goalPool == null) {
            goalPool = new TreeMap<>();
        }
        goalPool.put(priority, goal); //todo: change from tree to priority queue
        HorseRider.inquire(TAG, "addOrder: " + getName() + " has backup order " + goal +
                " with priority: " + priority);
    }

    public void informNoMoreGroupDecisions() {
        groupDecisionsDone = true;
        selectDecision();
    }

    private void informNoMoreAgentDecisions() {
        agentDecisionsDone = true;
        selectDecision();
    }

    private void selectDecision() {
        if (stepAction == null && agentDecisionsDone && groupDecisionsDone) {
            setOrderFromBackup();
        }
    }

    private void setOrderFromBackup() {
        boolean needOrder = true;
        while (needOrder) {
            needOrder = !setOrder(getActionFromPool());
        }
    }

    public HashMap<String, FBTask> getTasks() {
        return simInfo.getTaskList();
    }

    public void setMultipleAgentsOnBlock(int step) {
        if (isStepTimedOut(step)) {
            HorseRider.warn(TAG, "setMultipleAgentsOnBlock: info out of step: " + step + " in " + simInfo.getStep());
        } else {
            multiaAgentConnectionFlag = true;
        }
    }

    public boolean hasMultipleAgentsOnBlock() {
        return multiaAgentConnectionFlag;
    }

    public void setBusy() {
        this.busy = true;
    }

    public boolean isBusy() {
        return busy;
    }

    public void setBody(FBBody newBody) {
        this.agentBody = newBody;
    }

}
