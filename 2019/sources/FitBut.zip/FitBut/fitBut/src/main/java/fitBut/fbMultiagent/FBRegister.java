package fitBut.fbMultiagent;

import fitBut.agents.FBAgent;
import fitBut.utils.logging.HorseRider;
import fitBut.utils.Point;

import java.util.ArrayList;
import java.util.HashMap;

public class FBRegister {
    private static final String TAG = "FBRegister";
    private ArrayList<FBAgent> agentList = new ArrayList<>();
    private int lastStep = -1;
    private int reportedNum = 0;

    public void registerNewAgent(FBAgent fbAgent) {
        agentList.add(fbAgent);
    }

    /**
     * waits for all agents to finish percepts, last agent does sync and returns true
     *
     * @param fbAgent agent reporting
     * @param step    agent's step
     * @return true if all agents are synced
     */
    public synchronized boolean reportIn(FBAgent fbAgent, int step) {
        if (step > lastStep) { // new step
            reportedNum = 1;
            lastStep = step;
            HorseRider.inquire(TAG, "reportIn: " + fbAgent.getName() + " " + step + " " + reportedNum + "/" + agentList.size());
        } else if (step < lastStep) {
            HorseRider.yell(TAG, "reportIn: " + fbAgent.getName() + " reporting with info from previous step: " + step + " vs " + lastStep);
        } else {
            reportedNum++;
            HorseRider.inquire(TAG, "reportIn: " + fbAgent.getName() + " " + step + " " + reportedNum + "/" + agentList.size());
            if (reportedNum == agentList.size()) { // this agent is last to report
                runPostReport(fbAgent);
                return true;
            }
        }
        return false;
    }

    private void runPostReport(FBAgent fbAgent) {
        HashMap<Point, ArrayList<FBAgent>> seeingAgentList = new HashMap<>();
        for (FBAgent agent : agentList) {                         // for all agents
            for (Point agentPoint : agent.getSeeingFriendlies()) {   // get seen friend
                if (!seeingAgentList.containsKey(agentPoint)) {       // no one on this vector
                    ArrayList<FBAgent> agentOnPointList = new ArrayList<>();
                    agentOnPointList.add(agent);
                    seeingAgentList.put(agentPoint, agentOnPointList);
                } else {                                              // seeing more on same vector
                    seeingAgentList.get(agentPoint).add(agent);
                }
            }
        }

        for (Point vector : seeingAgentList.keySet()) {
            //HorseRider.challenge(TAG, "reportIn: seeing: "+pVector+" "+seeingAgentList.get(pVector).size());
            Point pVector = new Point(vector);
            if (seeingAgentList.get(pVector).size() == 1) { // got a see-one
                Point rVector = new Point(-pVector.x, -pVector.y);
                if (seeingAgentList.containsKey(rVector) && seeingAgentList.get(rVector).size() == 1) { // just checking
                    FBAgent agent1 = seeingAgentList.get(pVector).get(0);
                    FBAgent agent2 = seeingAgentList.get(rVector).get(0);
                    if (agent1.getGroup() == agent2.getGroup()) {
                        continue;
                    }
                    /*HorseRider.warn(TAG, "reportIn: " + agent1.getName() + " " + agent1.getLocalPosition() +
                            "\n" + agent2.getName() + " " + agent2.getLocalPosition());*/
                    if (agent1.getGroup().isActive()) {
                        if (agent2.getGroup().isActive()) {
                            if (agent1.getGroup().getGroupSize() >= agent1.getGroup().getGroupSize()) {
                                agent1.getGroup().importGroup(agent1, agent2, pVector);
                            } else {
                                agent2.getGroup().importGroup(agent2, agent1, rVector);
                            }
                        } else {
                            agent1.getGroup().registerNewMember(agent1, agent2, pVector);
                        }
                    } else if (agent2.getGroup().isActive()) {
                        agent2.getGroup().registerNewMember(agent2, agent1, rVector);
                    } else {
                        agent2.getGroup().setInactive();
                        agent1.getGroup().registerNewMember(agent1, agent2, pVector);
                    }
                    HorseRider.inquire(TAG, "reportIn: Got match! " +
                            agent1.getName() + " " + agent2.getName() +
                            " " + pVector);
                    HorseRider.challenge(TAG, "reportIn2: " + agent1.getName() + " " + agent1.getLocalPosition() +
                            "\n" + agent2.getName() + " " + agent2.getLocalPosition());

                    if (agent1.getGroup().isActive()) {
                        HorseRider.challenge(TAG, "runPostReport: GROUP  MAP!");
                        agent1.getGroup().printGroup();
                        agent1.getGroup().printMap();
                    }

                } else {
                    HorseRider.yell(TAG, "reportIn: " + fbAgent.getName() +
                            " ERROR xkcd.com/2200 on agent sync \n" + pVector + "\n" +
                            rVector + " recorded " + seeingAgentList.containsKey(rVector) + ", is only: " +
                            (seeingAgentList.containsKey(rVector) && seeingAgentList.get(rVector).size() == 1));
                }
            }
        }

    }
}
