package fitBut.fbReasoningModule.fbGoals.fbMultiGoals;

import fitBut.agents.Agent;
import fitBut.agents.FBAgent;
import fitBut.fbEnvironment.FBMapPlain;
import fitBut.fbMultiagent.FBGroup;
import fitBut.fbMultiagent.FBTask;
import fitBut.fbPerceptionModule.data.BlockType;
import fitBut.fbReasoningModule.fbGoals.FBGoal;
import fitBut.fbReasoningModule.fbGoals.FBGoalGoSubmit;
import fitBut.fbReasoningModule.fbGoals.utils.PlanHelper;
import fitBut.fbReasoningModule.fbGoals.utils.TaskMatch;
import fitBut.utils.FBConstants;
import fitBut.utils.Point;
import fitBut.utils.PointAndDir;
import fitBut.utils.logging.HorseRider;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import static fitBut.fbReasoningModule.fbGoals.utils.TaskMatch.completeness;

/**
 * @author : Vaclav Uhlir
 * @since : 8.10.2019
 **/
public class FBGoalAssembleTasks extends FBMultiGoal {
    private static final String TAG = "FBGoalAssembleTasks";
    private FBMapPlain snapshotMap;
    private ConcurrentHashMap<FBTask, Integer> taskWorkedOnIndex;

    public FBGoalAssembleTasks(FBGroup fbGroup) {
        super();
        taskWorkedOnIndex = fbGroup.getTaskWorkedOnIndex(fbGroup.getStep());
    }

    @Override
    public HashMap<FBAgent, FBGoal> makeGoals(Set<FBAgent> agents, FBMapPlain snapshotMap) {
        HashMap<FBAgent, FBGoal> agentPlans = new HashMap<>();
        this.snapshotMap = snapshotMap;
        if (agents.isEmpty()) {
            return agentPlans;
        }

        // check if we have any tasks to fulfill
        HashMap<String, FBTask> allTasks = agents.iterator().next().getTasks();
        if (allTasks.isEmpty()) {
            return agentPlans;
        }
        HashMap<String, FBTask> tasks = filterTasks(agents, allTasks);
        //check if some agent is ready to submit and eval completeness
        ArrayList<TaskMatch.TaskMatchStructure> agentTaskPossibilities = getAgentTaskCompleteness(agents, agentPlans, tasks);


        // Assemble
        agentTaskPossibilities.sort(Comparator.comparingInt(TaskMatch.TaskMatchStructure::getNameHash));
        agentTaskPossibilities.sort(Comparator.comparingDouble(TaskMatch.TaskMatchStructure::getHitRatio).reversed());
        //HorseRider.challenge(TAG, "makeGoals: " + agents + " pre assemble " + agentTaskPossibilities.size());
        ArrayList<PlanOption> options = new ArrayList<>();
        for (TaskMatch.TaskMatchStructure task : agentTaskPossibilities) { // for all matches //todo select based on some other value not just biggest hit
            if (agentPlans.get(task.getAgent()) != null) continue; // agent has plan
            if (task.getHits().contains(new Point(0, 1)) &&
                    task.bodyEquivalentOf(Point.zero()).equals(Point.zero())) { //TODO: TMP? limits building from first point only !!!!
                /*HorseRider.challenge(TAG, "makeGoals: " + agents +
                        "\n assemble find supplements for " + task.getTask() + task.getAgent());*/
                options.addAll(connectSupplementAgent(task, agentTaskPossibilities, agentPlans));
            }

            if (checkIfDone(agents, agentPlans)) break; //we are done
        }
        //HorseRider.challenge(TAG, "makeGoals: " + agents + " mid assemble");

        //options done lets find best values //todo this gets best to assemble not best to submit :/
        options.sort(Comparator.comparingInt(PlanOption::getNameHash));
        options.sort(Comparator.comparingInt(PlanOption::getPlanSize));
        options.sort(Comparator.comparingDouble(PlanOption::getValue).reversed());
        for (PlanOption option : options) {
            boolean skip = false;
            if (taskWorkedOnIndex.containsKey(option.task)) continue;  // task is worked on by somebody else
            for (FBAgent agent : option.agents) {
                if (agentPlans.containsKey(agent)) {
                    skip = true; // agent has plan
                    break;
                }
            }
            if (skip) continue;
            /*HorseRider.challenge(TAG, "makeGoals: selected option:"+
                    "\nplan " + option.taskBase.getAgent().getBody() +
                    "\nwith " + option.taskConnecting.getAgent().getBody() +
                    "\nto " + option.task +
                    "\nas " + option.plans);*/

            taskWorkedOnIndex.put(option.task, option.plans.size());
            agentPlans.putAll(option.plans);
        }

        //HorseRider.challenge(TAG, "makeGoals: " + agents + " post assemble");
        return agentPlans;
    }

    private boolean checkIfDone(Set<FBAgent> agents, HashMap<FBAgent, FBGoal> agentPlans) {
        int goalsSet = 0;
        for (Map.Entry<FBAgent, FBGoal> entry : agentPlans.entrySet()) {
            FBGoal fbGoal = entry.getValue();
            if (fbGoal != null) goalsSet++;
        }
        return agents.size() == goalsSet;
    }

    private HashMap<String, FBTask> filterTasks(Set<FBAgent> agents, HashMap<String, FBTask> allTasks) {
        ArrayList<TaskInterest> taskInterests = new ArrayList<>();

        HashMap<BlockType, Integer> blocksAvailable = getAvailableBlocks(agents);
        for (FBTask task : allTasks.values()) {
            boolean neededBlocksAvailable = true;
            HashMap<BlockType, Integer> needed = task.getTypesNeeded();
            for (Map.Entry<BlockType, Integer> entry : needed.entrySet()) {
                BlockType blockType = entry.getKey();
                Integer integer = entry.getValue();
                if (blocksAvailable.getOrDefault(blockType, 0) < integer) {
                    HorseRider.challenge(TAG, "filterTasks: task " + task.getName() +
                            " agents " + agents +
                            " missing blocks: " + blockType +
                            " available: " + blocksAvailable +
                            " blocks needed: " + needed);
                    neededBlocksAvailable = false;
                }
            }
            if (!neededBlocksAvailable) {
                HorseRider.challenge(TAG, "filterTasks: task " + task.getName() + " trimmed (not enough blocks)");
                continue;
            }
            if (task.getReward() <= 0) {
                HorseRider.challenge(TAG, "filterTasks: task " + task.getName() + " trimmed (no reward) ");
                continue;
            }

            TaskInterest taskInterest = new TaskInterest();
            taskInterest.task = task;
            taskInterest.value = ((double) task.getReward()) / (task.getBodySize()) / (task.getBodySize()) / (task.getBodySize()); // TODO: ?smaller better?
            taskInterests.add(taskInterest);
        }
        taskInterests.sort(Comparator.comparingInt(TaskInterest::getNameHash));
        taskInterests.sort(Comparator.comparingDouble(TaskInterest::getValue).reversed());
        HashMap<String, FBTask> filtered = new HashMap<>();
        for (int i = 0; i < Math.min(FBConstants.MAX_TASK_COUNT, taskInterests.size()); i++) { // TODO: make smarter limiter
            filtered.put(taskInterests.get(i).task.getName(), taskInterests.get(i).task);
        }
        if (filtered.size() != allTasks.size()) {
            HorseRider.warn(TAG, "filterTasks: task trimming from " + allTasks.size() + " to " + filtered.size());
        }
        return filtered;
    }

    private HashMap<BlockType, Integer> getAvailableBlocks(Set<FBAgent> agents) {
        HashMap<BlockType, Integer> blocksAvailable = new HashMap<>();
        for (FBAgent agent : agents) {
            HashMap<BlockType, Integer> agentBlocks = agent.getBody().getAvailableBlocks();
            agentBlocks.forEach((blockType, count) ->
                    blocksAvailable.put(
                            blockType,
                            blocksAvailable.getOrDefault(blockType, 0) + count));
        }
        return blocksAvailable;
    }

    private ArrayList<TaskMatch.TaskMatchStructure> getAgentTaskCompleteness(Set<FBAgent> agents, HashMap<FBAgent, FBGoal> agentPlans, HashMap<String, FBTask> tasks) {
        ArrayList<TaskMatch.TaskMatchStructure> agentTaskPossibilities = new ArrayList<>();
        for (FBAgent agent : agents) {
            ArrayList<TaskMatch.TaskMatchStructure> taskCompleteness = new ArrayList<>();
            for (FBTask task : tasks.values()) {
                // get task completeness
                taskCompleteness.addAll(completeness(task, agent));
            }

            // go submit assembled tasks
            if (!taskCompleteness.isEmpty()) {
                //todo find most valuable task - not only most complete
                taskCompleteness.sort(Comparator.comparingInt(TaskMatch.TaskMatchStructure::getNameHash));
                taskCompleteness.sort(Comparator.comparingDouble(TaskMatch.TaskMatchStructure::getHitRatio).reversed());
                for (TaskMatch.TaskMatchStructure hit : taskCompleteness) {
                    //HorseRider.challenge(TAG, "getAgentTaskCompleteness: " + agent + " " + hit.getTask() + " " + hit.getHitRatio());
                    if (hit.getCount() == hit.getTask().getTaskBody().size()) { //task is done
                        //HorseRider.challenge(TAG, "getAgentTaskCompleteness: " + agent + " " + hit.getTask() + " is DONE !!!!!!!!!!!!!!!!!!");
                        //if (hit.getTaskPoint().getRotated(hit.getRotation()).equals(hit.getBodyPoint())) {  // task is positioned
                        //noinspection StatementWithEmptyBody
                        if (hit.bodyEquivalentOf(Point.zero()).equals(Point.zero())) {  // task is positioned
                            //HorseRider.challenge(TAG, "getAgentTaskCompleteness: " + agent + " " + hit.getTask() + " is positioned !!!!!!!!!!!!!!!!!!");
                            FBGoal submit = new FBGoalGoSubmit(agent, hit.getTask(), hit.getRotation());
                            if (submit.getPlan() != null) {
                                //HorseRider.challenge(TAG, "getAgentTaskCompleteness: " + agent + " " + hit.getTask() + " is and has plan !!!!!!!!!!!!!!!!!!");
                                commitToPlan(agentPlans, agent, hit.getTask(), submit);
                                // todo: what if more agent can submit the task and the other is closer?
                                break;
                            }
                        } else {
                            //TODO: reposition to submit
                        }
                    }
                }
            }
            //add un assembled to queue
            if (!agentPlans.containsKey(agent)) { // does not have plan
                agentTaskPossibilities.addAll(taskCompleteness);
            }
        }
        return agentTaskPossibilities;
    }

    private void commitToPlan(HashMap<FBAgent, FBGoal> agentPlans, FBAgent agent, FBTask task, FBGoal plan) {
        agentPlans.put(agent, plan);
        agent.addOrder(plan);
        taskWorkedOnIndex.put(task, 1);
    }

    //TODO: queue all needed agents?
    //todo: take into account distance
    private ArrayList<PlanOption> connectSupplementAgent(TaskMatch.TaskMatchStructure mostPromisingTask, ArrayList<TaskMatch.TaskMatchStructure> agentTaskPossibilities, HashMap<FBAgent, FBGoal> agentPlans) {
        ArrayList<PlanOption> options = new ArrayList<>();
        for (TaskMatch.TaskMatchStructure taskHit : agentTaskPossibilities) {
            if (taskHit.getTask().equals(mostPromisingTask.getTask())) { // same task
                if (taskHit.getAgent() == mostPromisingTask.getAgent()) continue; //skip already used agent
                if (agentPlans.containsKey(taskHit.getAgent())) continue; // agent has plan
                if (agentPlans.containsKey(mostPromisingTask.getAgent())) continue; // agent has plan
                if (taskWorkedOnIndex.containsKey(taskHit.getTask())) continue;  // task is worked on by somebody else
                if (mostPromisingTask.getAgent().getPosition().distance(taskHit.getAgent().getPosition()) > FBConstants.MAX_SIM_JOIN_STEP)
                    continue;
                PointAndDir[] connectionPoint = findConnection(mostPromisingTask, taskHit);
                if (connectionPoint != null) {
                    FBJoinBodies joinJob = new FBJoinBodies(mostPromisingTask, taskHit, connectionPoint);
                    //HorseRider.challenge(TAG, "connectSupplementAgent: get body Join: " + joinJob);
                    HashSet<FBAgent> agents = new HashSet<>();
                    agents.add(taskHit.getAgent());
                    agents.add(mostPromisingTask.getAgent());
                    HashMap<FBAgent, FBGoal> plans = joinJob.makeGoals(agents, snapshotMap);
                    //HorseRider.challenge(TAG, "connectSupplementAgent: get body Join: " + plans);
                    if (plans != null && plans.get(taskHit.getAgent()) != null) {                // new plans
                        //HorseRider.challenge(TAG, "connectSupplementAgent: plan " + mostPromisingTask.getAgent().getBody() + " to " + taskHit.getAgent().getBody() + " for " + taskHit.getTask() + " as " + plans);
                        //int planSize = plans.get(mostPromisingTask.getAgent()).getPlan().planSize();
                        PlanOption planOption = new PlanOption();
                        planOption.task = mostPromisingTask.getTask();
                        planOption.agents = agents;
                        planOption.plans = plans;
                        planOption.planSize = plans.get(mostPromisingTask.getAgent()).getPlan().size();
                        planOption.joinedRatio = mostPromisingTask.getHitRatio() + taskHit.getHitRatio();
                        //TODO: add task value and completeness
                        options.add(planOption);
                    }
                }

            }
        }
        return options;
    }

    /**
     * gets non overlapping but connecting and on the edge
     *
     * @param taskBase       starting structure
     * @param taskSupplement connecting structure
     * @return point and direction of connection or null
     */
    private PointAndDir[] findConnection(TaskMatch.TaskMatchStructure taskBase, TaskMatch.TaskMatchStructure taskSupplement) {
        HashSet<Point> sumHitPoints = new HashSet<>();
        sumHitPoints.addAll(taskSupplement.getHits());
        sumHitPoints.addAll(taskBase.getHits());
        if (sumHitPoints.size() == taskSupplement.getCount() + taskBase.getCount()) { // not overlapping
            //lets find neighbouring fields
            for (Point neighbour : PlanHelper.generateDirections()) { // four vectors
                Point hit = null;
                boolean conflict = false;
                for (Point newHitPoint : taskSupplement.getHits()) {
                    if (taskBase.getHits().contains(newHitPoint.diff(neighbour))) {
                        //found it
                        hit = newHitPoint.diff(neighbour);
                        Point neededToBeFreeInSupplement = taskSupplement.bodyEquivalentOf(newHitPoint).diff(neighbour);//.getRotated(taskSupplement.getRotation().mirrored()));
                        Point neededToBeFreeInMost = taskBase.bodyEquivalentOf(newHitPoint);//.diff(neighbour.getRotated(taskSupplement.getRotation().mirrored()));
                        if (neededToBeFreeInSupplement.equals(Point.zero()) ||
                                taskSupplement.getAgent().getBody().getList().contains(neededToBeFreeInSupplement)) {
                            conflict = true; //joining place not accessible in supplement
                        } else if (neededToBeFreeInMost.equals(Point.zero()) ||
                                taskBase.getAgent().getBody().getList().contains(neededToBeFreeInMost)) {
                            conflict = true; //joining place not accessible in most
                            //todo: remove conflict?
                        }
                    }
                }
                if (hit != null && !conflict) {
                    //todo check if something is not interfering elsewhere ? ->skip
                    //todo: find disconnect point an propagate it with connect point
                    HashSet<Point> checked = new HashSet<>();
                    checked.add(Point.zero());
                    PointAndDir disconnect = findConnectionBeforeTask(Point.zero(), taskSupplement, checked);
                    if (disconnect == null) return null;
                    return new PointAndDir[]{new PointAndDir(hit, neighbour.getDirection()), disconnect};
                }
            }
        }
        return null;
    }

    private PointAndDir findConnectionBeforeTask(Point source, TaskMatch.TaskMatchStructure taskSupplement, HashSet<Point> checked) {
        PointAndDir disconnect = null;
        for (Point blockPoint : taskSupplement.getAgent().getBody().getLinked(source)) {
            if (checked.contains(blockPoint)) continue;
            checked.add(blockPoint);
            PointAndDir foundDisconnect;
            if (taskSupplement.getHits().contains(taskSupplement.taskEquivalentOf(blockPoint))) { // source is connected to block in task
                foundDisconnect = new PointAndDir(taskSupplement.taskEquivalentOf(blockPoint),
                        taskSupplement.taskEquivalentOf(source).diff(taskSupplement.taskEquivalentOf(blockPoint)).getDirection());
            } else {
                foundDisconnect = findConnectionBeforeTask(blockPoint, taskSupplement, checked);
            }
            if (disconnect != null && foundDisconnect != null) {
                HorseRider.yell(TAG, "findConnectionBeforeTask: " + taskSupplement.getAgent() +
                        " cyclic connection? " + taskSupplement + " " + source + " " + blockPoint +
                        " " + disconnect + " " + taskSupplement.getAgent().getBody());
            } else if (foundDisconnect != null) {
                disconnect = foundDisconnect;
            }

        }
        return disconnect;
    }

    private static class PlanOption {
        double joinedRatio;
        HashMap<FBAgent, FBGoal> plans;
        FBTask task;
        HashSet<FBAgent> agents;
        int planSize;

        double getValue() {
            return joinedRatio * task.getReward();// / planSize; //TODO: re-eval;
        }

        int getNameHash() {
            return ("" + this.task.getName() + agents.stream().map(Agent::getName).collect(Collectors.joining(""))).hashCode();
        }

        int getPlanSize() {
            return planSize;
        }
    }

    private static class TaskInterest {
        FBTask task;
        double value;

        double getValue() {
            return value;
        }

        int getNameHash() {
            return task.getName().hashCode();
        }
    }
}

