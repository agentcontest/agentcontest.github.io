package fitBut.fbReasoningModule.fbGoals;


import fitBut.agents.FBAgent;
import fitBut.fbActions.FBClear;
import fitBut.fbEnvironment.FBMapPlain;
import fitBut.fbEnvironment.utils.FBObjectType;
import fitBut.fbReasoningModule.fbGoals.utils.PlanCell;
import fitBut.fbReasoningModule.fbGoals.utils.PlanHelper;
import fitBut.utils.Point;
import fitBut.utils.PointAndDir;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

/**
 * Digs at closest reasonable obstacle
 */
public class FBGoalDig extends FBFloodCheck {
    @SuppressWarnings("unused")
    private static final String TAG = "FBGoalHoard";

    @Override
    protected boolean continueFailCheck(PlanCell cell) {
        return false;
    }

    @Override
    protected boolean mapBasedCheckFail(FBAgent agent, FBMapPlain map) {
        return false;
    }

    @Override
    boolean preCheckFail(FBAgent agent) {
        return false;
    }

    @Override
    FBMapPlain goalMap(FBAgent agent) {
        Set<Point> body = agent.getBody().getShiftedList(agent.getLocalPosition());
        return agent.getLocalMap().getMapSnapshot(0, agent.getLocalPosition(), body);
    }

    @Override
    boolean eachUsableField(FBAgent agent, PlanCell cell, FBMapPlain map) {
        return false;
    }

    @SuppressWarnings("SuspiciousNameCombination")
    @Override
    boolean eachUnUsableField(FBAgent agent, PlanCell cell, FBMapPlain map) {
        if (map.getNodeFirstByType(cell.getAt(), FBObjectType.__FBObstacle) != null) { //on obstacle
            plan = cell.getPlan();
            plan.removeLastAction();
            plan.removeLastAction();
            Point vector = cell.getAt().diff(agent.getLocalPosition());
            if (vector.size() <= 1) { //if dig is too close - dig diagonally
                if (vector.x == 0) {
                    vector.x = vector.y;
                } else {
                    vector.y = vector.x;
                }
            }
            plan.appendAction(new FBClear(vector));

            return true;
        } else {
            plan = cell.getPlan();
            plan.removeLastAction();
            HashSet<Point> checked = new HashSet<>();
            checked.add(cell.getAt());
            return digAtNeighbour(agent, cell.getAt(), map, checked);
        }
    }

    @Override
    void generateStepsToOpen(int preferredDirection, ArrayList<PlanCell> open, HashMap<PointAndDir, PlanCell> indexed, PlanCell cell) {
        PlanHelper.generateStepsToOpen(open, indexed, cell, preferredDirection, false);
    }

    private boolean digAtNeighbour(FBAgent agent, Point center, FBMapPlain map, HashSet<Point> checked) {
        for (Point neighbour : PlanHelper.generateDirections(center, 0, false)) {
            if (checked.contains(neighbour)) continue;
            checked.add(neighbour);
            if (map.getNodeFirstByType(neighbour, FBObjectType.__FBObstacle) != null) {
                plan.appendAction(new FBClear(neighbour.diff(agent.getLocalPosition())));
                return true;
            }
        }
        return false;
    }

    @Override
    PlanCell getInitCell(FBAgent agent) {
        return new PlanCell(agent.getLocalPosition());
    }


    public FBGoalDig() {
    }
}
