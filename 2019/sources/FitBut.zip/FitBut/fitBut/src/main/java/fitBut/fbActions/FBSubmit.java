package fitBut.fbActions;

import fitBut.agents.FBAgent;
import fitBut.agents.FBSimAgent;
import fitBut.fbEnvironment.utils.Rotation;
import fitBut.fbPerceptionModule.data.ActionResult;
import fitBut.utils.Point;
import eis.iilang.Action;
import eis.iilang.Identifier;

public class FBSubmit extends FBAction {

    @SuppressWarnings("unused")
    private static final String TAG = "FBSubmit";
    private String taskName;

    @Override
    public Action getEisAction() {
        return new Action("submit", new Identifier(taskName));
    }

    @Override
    public void succeededEffect(FBAgent agent) {
        //TODO: something after submit? .. block will vanish on check
    }

    @Override
    public FBSimAgent simulate(FBAgent agent) {
        return FBSimAgent.getNewSimAgent(agent, Point.zero(), Rotation.NULL);
    }

    @Override
    public void getAgentActionFeedback(ActionResult lastActionResult, FBAgent fbAgent) {

    }

    public FBSubmit(String taskName) {
        this.taskName = taskName;
    }
}
