:-dynamic 
	step/1, steps/1, vision/1, score/1, energy/1, disabled/1, explore/0, name/1, goalCell/2, obstacle/2,
	thing/4, task/4, attachedAny/2, attached/3, enumDirList/2, team/1, relativePosition/2, visited/4, taskPlan/3, connected/3,
	onGoalTerrain/1, agentAt/3, clearEnergyCost/1, lastAgentShare/2, stuck/0.

% All directions pseudo random (essentially seeded)
randomValidDirection(D) :-
	step(N), Seed is N mod 24, % 4! = 24
	enumDirList(DL, Seed),
	member(D, DL),
	not(blocked(D)).

generateEnumDirList(P, V, InitialSeed) :-
	findall(Px, permutation([n, e, s, w], Px), PL),
	generateEnumDirList(PL, InitialSeed, P, V).
generateEnumDirList([P|_], V, P, V).
generateEnumDirList([_|PL], C, P, V) :-
	Cx is (C + 1),
	Cxx is Cx mod 24,
	generateEnumDirList(PL, Cxx, P, V).
	
oppositeDirection(n, s).
oppositeDirection(s, n).
oppositeDirection(e, w).
oppositeDirection(w, e).

% Explore directions
exploreDirections(D) :-
	findall((ExScore, D), (randomValidDirection(D), exploreScore(D, ExScore)), DirectionValueList),
	rsort(DirectionValueList, DirectionValueListSorted),
	member((_, D), DirectionValueListSorted).
	
% safeExploreDirections (prioritize avoiding disrupting agents working on turning in tasks
safeExploreDirections(D) :-
	findall((Score, D), (randomValidDirection(D), safeExploreScore(D, Score)), DirectionValueList),
	rsort(DirectionValueList, DirectionValueListSorted),
	member((_, D), DirectionValueListSorted).

% Best directions for moving towards a position
goToDirections(Xb, Yb, D) :-
	findall((Score, D), (randomValidDirection(D), visitedScore(D, VScore), 
		positionScore(D, Xb, Yb, PScore), Score is VScore+PScore), DirectionValueList),
	sort(DirectionValueList, DirectionValueListSorted),
	member((_, D), DirectionValueListSorted).
	
% Best directions for achieving pattern
taskPatternDirections(Pattern, D) :- 
	findall((Score, D),  (randomValidDirection(D), patternScore(D, Pattern, PScore), visitedScore(D, VScore), Score is PScore+VScore), DVL),
	DVL \= [],
	!,
	sort(DVL, DVLSorted),
	member((_, D), DVLSorted).
	
% detachDirections
detachDirections(D) :-
	findall((ExScore, D), (randomValidDirection(D), detachScore(D, ExScore)), DirectionValueList),
	rsort(DirectionValueList, DirectionValueListSorted),
	member((_, D), DirectionValueListSorted).
	
	
% Pattern score
patternScore(D, Pattern, Score) :-
	findall( LMin , ( 
		member(req(X, Y, BlockType), Pattern),
		not(attached(X, Y, BlockType)),
		findall(L, (thing(Xt, Yt, block, BlockType), not(attached(Xt, Yt, BlockType)), oppositeDirection(D, Dx), translate(Dx, Xt, Yt, Xt2, Yt2), 
			dist(X, Y, Xt2, Yt2, L)), Ls),
		min_list(Ls, LMin)), PScoreList),
	listSum(PScoreList, Score, _).

% Score
exploreScore(D, VSum) :-
	Nv = 30,
	step(StepC),
	relativePosition(Xr, Yr),
	translate(D, Xr, Yr, X, Y),
	findall(V, (visited(Xv, Yv, StepV, _), dist(X, Y, Xv, Yv, Vd), Vd =< Nv, 
		StepDelta is StepC-StepV, StepDelta > 0, V is Vd/(StepDelta^2)), VScoreList),
	listSum(VScoreList, VSum, _).
	
safeExploreScore(D, Score) :-
	exploreScore(D, VSum),
	team(Team),
	findall(L, ((goalCell(Xt, Yt); thing(Xt, Yt, entity, Team)), dist(0, 0, Xt, Yt, L1), 
		(agentAt(Agent, Xt, Yt), taskPlan(_, LocalPlans, _), member(localPlan(Agent, _, _, _, _), LocalPlans)) -> (L is L1*5; L = L1) ), Ls),
	listSum(Ls, ASum, _),
	Score is VSum+ASum.

% Score based on distance to target position given direction D 
positionScore(D, Xb, Yb, PScore) :-
	translate(D, 0, 0, X, Y),
	dist(X, Y, Xb, Yb, PScore).
	
% visitedScore
visitedScore(D, VScore) :-
	relativePosition(Xr, Yr),
	translate(D, Xr, Yr, X, Y),
	findall(Step, visited(X, Y, Step, _), VisitedList),
	length(VisitedList, VScore1),
	VScore is sqrt(VScore1).
	
% detachScore
detachScore(D, Score) :-
	exploreScore(D, ExScore),
	translate(D, 0, 0, X1, Y1),
	findall(L, (obstacle(X, Y), dist(X1, Y1, X, Y, L)), Ls),
	listSum(Ls, DScore, _),
	Score is ExScore+DScore.

% Is direction blocked
blocked(D) :- 
	translate(D, 0, 0, X, Y),
	impassable(X, Y),
	!.
blocked(D) :-
	attached(X, Y, _),
	translate(D, X, Y, X2, Y2),
	impassable(X2, Y2),
	!.
impassable(X, Y) :- obstacle(X, Y).
impassable(X, Y) :- thing(X, Y, entity, _).
impassable(X, Y) :- thing(X, Y, block, BlockType), not(attached(X, Y, BlockType)).

% Can rotate
blockedRotation(R) :- 
	blockedRotation(0, 0, R).
blockedRotation(Xa, Ya, R) :- 
	attached(X, Y, _),
	rotation90(R, X, Y, Xr, Yr),	
	Xf is X+Xa, 
	Xt is Xr+Xa, 
	Yf is Y+Ya, 
	Yt is Yr+Ya,	
	(between(Xf, Xt, Xb); between(Xt, Xf, Xb)), (between(Yf, Yt, Yb); between(Yt, Yf, Yb)),
	impassable(Xb, Yb).
	
% availableAttachmentSpots
availableAttachmentSpots(X, Y) :- 
	member((X, Y), [(1, 0), (0, 1), (-1, 0), (0, -1)]),
	not(attached(X, Y, _)).

% Guess attach direction
attachDirection(X, Y, e) :-
	X > 0,
	abs(X, AbsX),
	abs(Y, AbsY),
	AbsX >= AbsY,
	AbsY < 3.
attachDirection(X, Y, w) :-
	X < 0,
	abs(X, AbsX),
	abs(Y, AbsY),
	AbsX >= AbsY,
	AbsY < 3.
attachDirection(X, Y, s) :-
	Y > 0,
	abs(X, AbsX),
	abs(Y, AbsY),
	AbsX =< AbsY,
	AbsX < 3.
attachDirection(X, Y, n) :-
	Y < 0,
	abs(X, AbsX),
	abs(Y, AbsY),
	AbsX =< AbsY,
	AbsX < 3.
	
% closest thing (dispenser or block)
closestBlockOrDispenser(Xt, Yt) :-
	team(Team),
	findall((L, Xt, Yt, Type), (
		thing(Xt, Yt, Type, _), 
		(Type = block, not(attachedAny(Xt, Yt)); Type = dispenser), 
		dist(0, 0, Xt, Yt, L),
		not((translate(_, Xt, Yt, Xa, Ya), thing(Xa, Ya, entity, Team)))), Things),
	Things \= [],
	sort(Things, ThingsSorted),
	member((_, Xt, Yt, Type), ThingsSorted).
	
% All attachments
getAttachments(Attachments) :-
	findall(attached(X, Y, BlockType), attached(X, Y, BlockType), Attachments).
	
rotateAttachments(R, Attachments, AttachmentsRotated) :-
    	( R=ccw ; R=cw ),
	findall(attach(Xr, Yr, BlockType), (member(attach(X, Y, BlockType), Attachments), rotation90(R, X, Y, Xr, Yr)), AttachmentsRotated),
	length(AttachmentsRotated, L),
	length(Attachments, L).
rotateAttachments(ccw, Attachments, AttachmentsRotated) :-
	findall(attach(Xr, Yr, BlockType), (member(attach(X, Y, BlockType), Attachments), rotation180(ccw, X, Y, Xr, Yr)), AttachmentsRotated),
	length(AttachmentsRotated, L),
	length(Attachments, L).

rotateAttachmentPattern(R, Attachments) :- rotateAttachmentPattern(R, Attachments, []).
rotateAttachmentPattern(R, Attachments, Excluding) :-
	rotateAttachments(R, Attachments, AttachmentsRotated),
	findall(attached(Xa, Ya, BlockType), (attached(Xa, Ya, BlockType), not(member(attached(Xa, Ya, BlockType), Excluding))), AttachedList),
	forall(member(attach(Xa, Ya, BlockType), AttachmentsRotated), member(attached(Xa, Ya, BlockType), AttachedList)).

hasAttachmentPattern(Attachments, Excluding) :-
	findall(attached(Xa, Ya, BlockType), (attached(Xa, Ya, BlockType), not(member(attached(Xa, Ya, BlockType), Excluding))), AttachedList),
	forall(member(attach(Xa, Ya, BlockType), Attachments), member(attached(Xa, Ya, BlockType), AttachedList)),
	!.
hasAttachmentPattern(Attachments, Excluding) :-
	rotateAttachmentPattern(_, Attachments, Excluding),
	!.
	
% closestGoalCell
closestAvailableGoalCells(X, Y) :-
	findall((Sum, X, Y), (goalCell(X, Y), not(impassable(X, Y)), Sum is X+Y), GoalCells),
	sort(GoalCells, GoalCellsSorted),
	member((_, X, Y), GoalCellsSorted).
	
% goalConnected
goalConnected(X1, Y1, X2, Y2) :-
	goalConnected1(X1, Y1, X2, Y2, []).

goalConnected1(X, Y, X, Y, _) :- !.
goalConnected1(X1, Y1, X2, Y2, Checked) :-
	translate(_, X1, Y1, X3, Y3),
	goalCell(X3, Y3),
	not(member((X3, Y3), Checked)),
	goalConnected1(X3, Y3, X2, Y2, [(X1, Y1)|Checked]).
	
	
% Delegate task submission
delegateTaskSubmission([], _, _, _) :- !, fail.
delegateTaskSubmission(Lx, T, MinDeadline, Plan) :-
	removeAgentAttachmentDoubles(Lx, L),
	% Filter out tasks that has too short deadline
	findall((Reward, Task, Requirements), (member([Task, Deadline, Reward, Requirements], T), MinDeadline =< Deadline), TaskList),
	% Sort by reward descending
	sort(TaskList, TaskListSorted), % take easiest currently
	delegateTaskSubmission1(L, TaskListSorted, Plan).

delegateTaskSubmission1(_, [], []).
delegateTaskSubmission1(L, [(_, Task, Requirements)|TaskListTail], [taskPlan(Task, LocalPlans, SubmitAgent)|PlanRest]) :-
	% only 1 task
	%createLocalPlans(L, Requirements, LocalPlans, SubmitAgent, LRest),
	createLocalPlans(L, Requirements, LocalPlans, SubmitAgent, []),
	!,
	delegateTaskSubmission1([], TaskListTail, PlanRest).
delegateTaskSubmission1(L, [_|TaskListTail], PlanRest) :-
	delegateTaskSubmission1(L, TaskListTail, PlanRest).
	
createLocalPlans(L, Requirements, LocalPlans, SubmitAgent, LRest) :-
	hasBlockTypes(L, Requirements),
	generateAgentPositions(Requirements, AgentPosList),
	generateAttachments(Requirements, AgentPosList, [], Attachments),
	checkSolution(Requirements, Attachments),
	assignAgents(L, Attachments, AssignedAttachments, [], LRest),
	member(attachments(SubmitAgent, 0, 0, _), AssignedAttachments),
	!,
	generateConnections(AssignedAttachments, Connections),
	toLocalPlans(AssignedAttachments, AssignedAttachments, Connections, LocalPlans).

hasBlockTypes(L, Requirements) :-
	findall(BlockType, (member([BlockTypes, _], L), member(attached(_, _, BlockType), BlockTypes)), BlockTypesHas),
	findall(BlockType, member(req(_, _, BlockType), Requirements), BlockTypesReq),
	subsetUnique(BlockTypesReq, BlockTypesHas).
	
removeAgentAttachmentDoubles([], []).
removeAgentAttachmentDoubles([[Attachments, Agent]|Ld], [[Attachments, Agent]|Lr]) :-
	removeAgentAttachmentDoubles(Ld, Lr),
	not(member([_, Agent], Lr)),
	!.
removeAgentAttachmentDoubles([[_, _]|Ld], Lr) :-
	removeAgentAttachmentDoubles(Ld, Lr).	 

generateAgentPositions([], []).
generateAgentPositions([req(X, Y, _)|T], AgentPosList) :-
	generateAgentPositions(T, Rest),
	findall(at(X2, Y2), (member(D, [n,e,s,w]), translate(D, X, Y, X2, Y2), not(member(at(X2, Y2), Rest)), not(member(req(X2, Y2, _), T))), L),
	append(L, Rest, AgentPosList).

generateAttachments([], _, R, R) :- !.
generateAttachments(Requirements, [at(X, Y)|T], Attachments, Res) :-
	forall(member(req(Xr, Yr, _), Requirements), not((Xr=X, Yr=Y))),
	forall(member(attachments(Xa, Ya, _), Attachments), not((Xa=X, Ya=Y))),
	forall((member(attachments(_, _, A), Attachments), member(attach(Xa, Ya, _), A)), not((Xa=X, Ya=Y))),
	findall(attach(X2, Y2, BlockType), (member(D, [n,e,s,w]), translate(D, X, Y, X2, Y2), member(req(X2, Y2, BlockType), Requirements), 
		forall(member(attachments(Xa, Ya, _), Attachments), not((Xa=X2, Ya=Y2))), 
		forall((member(attachments(_, _, A), Attachments), member(attach(Xa, Ya, _), A)), not((Xa=X2, Ya=Y2)))), AgentAttachments),
	AgentAttachments \= [],
	findall(req(Xr, Yr, BlockType), ( member(req(Xr, Yr, BlockType), Requirements), not(member(attach(Xr, Yr, BlockType), AgentAttachments))), RequirementsRest),
	generateAttachments(RequirementsRest, T, [attachments(X, Y, AgentAttachments)|Attachments], Res).
generateAttachments(Requirements, [_|T], Attachments, Res) :-
	generateAttachments(Requirements, T, Attachments, Res).
	
checkSolution(Requirements, Attachments) :-
	forall(member(req(X, Y, BlockType), Requirements), (member(attachments(_, _, AgentAttachments), Attachments), member(attach(X, Y, BlockType), AgentAttachments))).

assignAgents(L, [], [], R, LR) :-
	append(L, R, LR).
assignAgents([[Attachments, Agent]|Lt], [attachments(X, Y, A)|Rest], [attachments(Agent, X, Y, A)|AssignedRest], LAlt, LRest) :-
	findall(attach(Xa, Ya, BlockType), member(attached(Xa, Ya, BlockType), Attachments), AttachmentsX),
	findall(attach(Xa, Ya, BlockType), (member(attach(Xa1, Ya1, BlockType), A), Xa is Xa1-X, Ya is Ya1-Y), Ax),
	hasSubPattern(Ax, AttachmentsX),
	assignAgents(Lt, Rest, AssignedRest, LAlt, LRest).
assignAgents(L, [attachments(X, Y, A)|Rest], [attachments(Agent, X, Y, A)|AssignedRest], [[Attachments, Agent]|LtAlt], LRest) :-
	findall(attach(Xa, Ya, BlockType), member(attached(Xa, Ya, BlockType), Attachments), AttachmentsX),
	findall(attach(Xa, Ya, BlockType), (member(attach(Xa1, Ya1, BlockType), A), Xa is Xa1-X, Ya is Ya1-Y), Ax),
	hasSubPattern(Ax, AttachmentsX),
	assignAgents(L, Rest, AssignedRest, LtAlt, LRest).
assignAgents([_|Lt], Attachments, AssignedAttachments, LAlt, LRest) :-
	assignAgents(Lt, Attachments, AssignedAttachments, LAlt, LRest).
assignAgents([H|Lt], Attachments, AssignedAttachments, LAlt, LRest) :-
	assignAgents(Lt, Attachments, AssignedAttachments, [H|LAlt], LRest).
	
toLocalPlans([], _, _, []).
toLocalPlans([attachments(Agent, X, Y, Attachments)|T], AssignedAttachments, AllConnections, [localPlan(Agent, LocalAttachments, Connections, Pattern, AgentBlockPositions)|Rest]) :-
	getLocalPattern(X, Y, AssignedAttachments, Pattern, AgentBlockPositions),
	findall(connect(Agent2, Xc, Yc), member(connect(Agent, Agent2, Xc, Yc), AllConnections), Connections),
	findall(attach(Xl, Yl, BlockType), ( member(attach(Xa, Ya, BlockType), Attachments), Xl is Xa-X, Yl is Ya-Y ), LocalAttachments),
	toLocalPlans(T, AssignedAttachments, AllConnections, Rest).
	
getLocalPattern(X, Y, Attachments, Pattern, AgentBlockPositions) :-
	findall(req(Xp, Yp, BlockType), ( member(attachments(_, _, _, AgentAttachments), Attachments), 
		member(attach(Xa, Ya, BlockType), AgentAttachments), Xp is Xa-X, Yp is Ya-Y ), Pattern),		
	findall(pos(Xp, Yp), ( member(req(Xp, Yp, _), Pattern); member(attachments(_, Xa, Ya, _), Attachments), Xp is Xa-X, Yp is Ya-Y, (Xp, Yp) \= (0, 0) ), 
		AgentBlockPositions).
		
generateConnections([], []).
generateConnections([H|T], Connections) :-
	generateConnections1(H, T, ConnectionsL),
	generateConnections(T, ConnectionsR),
	append(ConnectionsL, ConnectionsR, Connections).

generateConnections1(_, [], []).
generateConnections1(attachments(Agent, X, Y, Attachments), [attachments(Agent2, X2, Y2, Attachments2)|T], [connect(Agent, Agent2, Xc, Yc), connect(Agent2, Agent, Xc2, Yc2)|Rest]) :-
	Agent2 \= Agent,
	findAdjacentPair(Attachments, Attachments2, pair(Xa, Ya), pair(Xa2, Ya2)),
	!,
	Xc is Xa-X,
	Yc is Ya-Y,
	Xc2 is Xa2-X2,
	Yc2 is Ya2-Y2,
	generateConnections1(attachments(Agent, X, Y, Attachments), T,  Rest).
generateConnections1(A, [_|T], Connections) :-
	generateConnections1(A, T, Connections).

findAdjacentPair(Attachments1, Attachments2, pair(X1, Y1), pair(X2, Y2)) :-
	member(attach(X1, Y1, _), Attachments1),
	member(attach(X2, Y2, _), Attachments2),
	translate(_, X1, Y1, X2, Y2),
	!.
	
hasSubPattern(TaskAttachments, Attachments) :-
	subsetUnique(TaskAttachments, Attachments),
	!.
hasSubPattern(TaskAttachments, Attachments) :-
	rotateAttachments(_, TaskAttachments, TaskAttachmentsRotated),
	subsetUnique(TaskAttachmentsRotated, Attachments),
	!.
	
% Test if requirements are believed to be met
observePattern([]).
observePattern([req(Xr, Yr, BlockType)|Requirements]) :-
	thing(Xr, Yr, block, BlockType),
	observePattern(Requirements).
	
observePatternPartial(Attachments, Pattern) :-
	goalCellInVision,
	!,
	findall(req(X, Y, BlockType), (
		member(req(X, Y, BlockType), Pattern),
		not(member(attach(X, Y, BlockType), Attachments)),
		thing(X, Y, block, BlockType), attachedAny(X, Y)), ObservedPartialPattern),
	ObservedPartialPattern \= [],
	not(observePatternPartialBetter(Attachments, Pattern, ObservedPartialPattern)).
observePatternPartialBetter(Attachments, Pattern, ObservedPartialPattern) :-
	between(-5, 5, Tx),
	between(-5, 5, Ty),
	Tx \= 0,
	Ty \= 0,
	findall(block(Xt, Yt, BlockType), (
		thing(X, Y, block, BlockType), attachedAny(X, Y),
		not(member(attach(X, Y, BlockType), Attachments)), 
		Xt is X+Tx, Yt is Y+Ty), BlocksTranslated),
	findall(req(X, Y, BlockType), (member(req(X, Y, BlockType), Pattern), member(block(X, Y, BlockType), BlocksTranslated)), ObservedPartialPatternTranslated),
	length(ObservedPartialPatternTranslated, Lt),
	length(ObservedPartialPattern, L),
	Lt > L.
	
% patternObscured
patternObscured(AgentBlockPositions) :- 
	member(pos(X, Y), AgentBlockPositions),
	obstacle(X, Y),
	!.
	
% identifyCommonEnvironmentPercepts
identifyCommonEnvironmentPercepts(X, Y, Cep) :-
	vision(VisionRange),
	findall(envPercept(Xe, Ye, Type), (
		(thing(Xe, Ye, _, _), Type = thing;
		obstacle(Xe, Ye), Type = obstacle;
		goalCell(Xe, Ye), Type = goal),
		(Xe, Ye) \= (X, Y),
		dist(X, Y, Xe, Ye, D1), D1 < VisionRange,
		dist(0, 0, Xe, Ye, D2), D2 < VisionRange), Cep).

% compareCommonEnvironmentPercepts
compareCommonEnvironmentPercepts([], [], _, _).
compareCommonEnvironmentPercepts([envPercept(Xe, Ye, Type)|Cep1], Cep2, X, Y) :-
	Xe2 is Xe+X, Ye2 is Ye+Y,
	select(envPercept(Xe2, Ye2, Type), Cep2, Cep2Rest),
	compareCommonEnvironmentPercepts(Cep1, Cep2Rest, X, Y).

% Sharable beliefs
sharableBeliefs([agentAt(Name, 0, 0)|AgentPositions], GoalCells) :-
	name(Name),
	findall(agentAt(AgentName, X, Y), agentAt(AgentName, X, Y), AgentPositions),
	findall(goalCell(X, Y), goalCell(X, Y), GoalCells).
	
% checkStuck
checkStuck :- 
	N = 30, % How many steps before stuck
	D = 6, % How large an area to consider
	step(Step),
	Step > N,
	StepMin is Step - N,
	% Get N latest visited
	findall((X, Y), (visited(X, Y, StepV, _), StepV >= StepMin), VisitedCoordinates),
	length(VisitedCoordinates, L), L >= N ->
		% Check all coordinates are within distance D of each other
		forall((member((X, Y), VisitedCoordinates), member((X2, Y2), VisitedCoordinates)), (dist(X, Y, X2, Y2, Dt), Dt =< D)). 

% Translate position
translate(n, X1, Y1, X2, Y2) :- X2 = X1, Y2 is Y1 - 1.
translate(s, X1, Y1, X2, Y2) :- X2 = X1, Y2 is Y1 + 1.
translate(e, X1, Y1, X2, Y2) :- Y2 = Y1, X2 is X1 + 1.
translate(w, X1, Y1, X2, Y2) :- Y2 = Y1, X2 is X1 - 1.

% Besides
adjacent(X, Y) :- translate(_, 0, 0, X, Y).

% Infer needed rotation to point attachment spot (Xa, Ya) towards (Xt, Yt)
% other direction
rotation(R, Xa, Ya, Xt, Yt) :- rotation90(R, Xa, Ya, Xt, Yt).
rotation(R, Xa, Ya, Xt, Yt) :- rotation180(R, Xa, Ya, Xt, Yt).
% 90 degrees
rotation90(ccw,  1, 0, 0, -1).
rotation90(ccw, 0, -1, -1, 0).
rotation90(ccw, -1, 0, 0, 1).
rotation90(ccw, 0, 1, 1, 0).
rotation90(cw, 0, -1, 1, 0).
rotation90(cw, -1, 0, 0, -1).
rotation90(cw, 0, 1, -1, 0).
rotation90(cw, 1, 0, 0, 1).
% 180 degrees
rotation180(ccw, 1, 0, -1, 0).
rotation180(ccw, 0, -1, 0, 1).
rotation180(ccw, -1, 0, 1, 0).
rotation180(ccw, 0, 1, 0, -1).

% Opposite rotation
oppositeRotation(cw, ccw).
oppositeRotation(ccw, cw).

% goalCellInVision
goalCellInVision :-
	goalCell(X, Y),
	inVision(X, Y),
	!.

% (X, Y) in vision
inVision(X, Y) :-
	vision(Vx),
	V is Vx-1,
	abs(X, Xabs),
	abs(Y, Yabs),
	V > Xabs + Yabs.

% In proximity (dist < 6)
inProximity(X1, Y1, X2, Y2) :-
	dist(X1, Y1, X2, Y2, Dist),
	Dist =< 15.

% Name seeding
nameToSeed(Name, Seed) :- sub_string(Name, B, L, _, "agent-GOAL-DTU"), BL is B+L, sub_string(Name, BL, _, 0, Rest), number_string(Seed, Rest). 

% List sum
listSum([], 0, 0).
listSum([H|T], Sum, Length) :-
    listSum(T, TailSum, TailLength),
    Sum is H + TailSum,
    Length is 1 + TailLength.
    
% abs
abs(X, Y) :- X < 0, !, Y is -X.
abs(X, X).

% reverse sort
rsort(List, ListSortedRev) :- sort(List, ListSorted), rev(ListSorted, ListSortedRev).
rev([], []).
rev([H|T], R) :- rev(T, Rt), append(Rt, [H], R).

% subsetUnique
subsetUnique([], _).
subsetUnique([H|SubSet], Set) :-
	select(H, Set, SetRest),
	!,
	subsetUnique(SubSet, SetRest).
	
% Approximation to euclidean distance
dist(X1, Y1, X2, Y2, Res) :- X is X2-X1, abs(X, XAbs), Y is Y2-Y1, abs(Y, YAbs), Res is (XAbs+YAbs).	