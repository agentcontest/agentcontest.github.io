package mas.StreettCompetitionAgent.Strategies;

import java.util.LinkedList;

import apltk.interpreter.data.LogicBelief;

import eis.iilang.Action;
import mas.StreettCompetitionAgent.StreettAgent;
import massim.javaagents.agents.MarsUtil;

public class InspectStrategy {

	private StreettAgent agent;
	
	public InspectStrategy(StreettAgent agent) {
		this.agent = agent;
	}
	
	public Action runStrategy() {
		Action nothing = null;
		LinkedList<LogicBelief> entities = agent.getAllBeliefs("entities");
		boolean inspect = false;
		if (agent.getAllBeliefs("justInspected").isEmpty()) {
			for (LogicBelief e : entities) {
				String ePosition = e.getParameters().get(1).toString();
				String eBotName = e.getParameters().get(0).toString();
				String eBotTeam = e.getParameters().get(2).toString();
				String eBotStatus = e.getParameters().get(3).toString();
				
				if (!eBotTeam.equals(agent.myTeam) && !eBotStatus.equals("disabled")) {
					LogicBelief priorityTarget = new LogicBelief("priorityTarget", new String[] {
							ePosition, eBotName
					});
					agent.broadcastBelief(priorityTarget);
					inspect = true;
				}
				
			}
			if (inspect) {
				LogicBelief justInspected = new LogicBelief("justInspected", new String[] {"true"});
				agent.addBelief(justInspected);
				System.out.println(agent.myName + " is inspecting at " + agent.getPosition());
				return MarsUtil.inspectAction();
			}
		} else {
			agent.removeBeliefs("justInspected");
			return nothing;
		}
		return nothing;
	}
}
