package mas.StreettCompetitionAgent.Strategies;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;

import apltk.interpreter.data.LogicBelief;

import eis.iilang.Action;
import mas.StreettCompetitionAgent.Dijkstra;
import mas.StreettCompetitionAgent.StreettAgent;
import mas.StreettCompetitionAgent.Helpers.VertexHelper;
import massim.javaagents.agents.MarsUtil;

public class ZoneStrategy {

	private StreettAgent agent;
	private ArrayList<String> occupiedVertexes = new ArrayList<String>();
	
	public ZoneStrategy(StreettAgent agent) {
		this.agent = agent;
	}
	
	public Action runStrategy() {
		Action nothing = null;
		LinkedList<LogicBelief> goodPoints = agent.getAllBeliefs("goodPoint");
		//If no prime points are found, don't perform strategy
		if (goodPoints.isEmpty()) { 
			return nothing;
		} else {
			if (agent.getAllBeliefs("myGoalZ").isEmpty()) {
				String chosen = vertexInZone();
				if (chosen != null) {
					LogicBelief myGoal = new LogicBelief("myGoalZ", new String[] {chosen, "", "GOTO"});
					agent.addBelief(myGoal);
					System.out.println(agent.myName + " has ZoneGoal of " + chosen);
					LogicBelief occupied = new LogicBelief("occupied", new String[] {chosen, agent.myName});
					agent.addBelief(occupied);
					agent.broadcastBelief(occupied);
					return goToVertex(chosen);
				}
			} else {
				
				String goalVertex = agent.getAllBeliefs("myGoalZ").getFirst().getParameters().get(0).toString();
				boolean chooseAgain = false;
				for (LogicBelief b : agent.getAllBeliefs("occupied")) {
					 if (b.getParameters().get(0).toString().equals(goalVertex) && !b.getParameters().get(1).toString().equals(agent.myName)) {
						 chooseAgain = true;
					 }
				}
				if (chooseAgain) {
					agent.removeBeliefs("myGoal");
					String chosen = vertexInZone();
					if (chosen != null) {
						LogicBelief myGoal = new LogicBelief("myGoalZ", new String[] {chosen, "", "GOTO"});
						agent.addBelief(myGoal);
						System.out.println(agent.myName + " has new ZoneGoal of " + chosen);
						LogicBelief occupied = new LogicBelief("occupied", new String[] {chosen, agent.myName});
						agent.addBelief(occupied);
						agent.broadcastBelief(occupied);
						return goToVertex(chosen);
					}
				}
				if (!agent.getPosition().equals(goalVertex)) {
					return goToVertex(goalVertex);
				}
			}
		}
		
		return nothing;
	}
	
	public String vertexInZone() {
		if (occupiedVertexes.isEmpty()) {
			for (LogicBelief e : agent.getAllBeliefs("occupied")) {
				occupiedVertexes.add(e.getParameters().get(0).toString());
			}
		}
		
		if (occupiedVertexes.isEmpty()) {
			ArrayList<String> goodPointz = new ArrayList<String>();
			for (LogicBelief b : agent.getAllBeliefs("goodPoint")) {
				goodPointz.add(b.getParameters().get(0).toString());
			}
			Collections.shuffle(goodPointz);
			
			occupiedVertexes.add(goodPointz.get(0));
			System.out.println(agent.myName + " initializing Zone Strategy for the first time!");
			return goodPointz.get(0);
		}
		for (String v0 : occupiedVertexes) {
			
			
			VertexHelper vHelper = new VertexHelper(agent);
			ArrayList<String> neighbors = vHelper.getNeighborVertexes(v0);
			//outterloop:
			for (String v1 : neighbors) {
				ArrayList<String> tier2Neighbor = vHelper.getNeighborVertexes(v1);
				
				for (String v2 : tier2Neighbor) {
					if (!v2.equals(v0) && !occupiedVertexes.contains(v2)) {
						ArrayList<String> tier3Neighbor = vHelper.getNeighborVertexes(v2);
						boolean goodVertex = true;
						for (String v3 : tier3Neighbor) {
							if (occupiedVertexes.contains(v3)) goodVertex = false;
						}
						if (goodVertex) {
							return v2;
						}
					}
				}
			}
		}
		
		return null;
	}
	
	public Action goToVertex(String goal) {
		Dijkstra pathPlanner = new Dijkstra(agent);
		LinkedList<String> thisPath = pathPlanner.findPath(goal);
		if (thisPath != null && thisPath.size() > 1) {
			//System.out.println(agent.myName + "on track - moving to " + thisPath.get(1) + " from " + agent.getPosition());
			return MarsUtil.gotoAction(thisPath.get(1));
		} else {

			return MarsUtil.gotoAction(randomVertex());
		}
	}
	
	public String randomVertex() {
		VertexHelper vHelper = new VertexHelper(agent);
		ArrayList<String> myNeighbors = vHelper.getNeighborVertexes(agent.getPosition());
		Collections.shuffle(myNeighbors);
		return myNeighbors.get(0);
	}
}
