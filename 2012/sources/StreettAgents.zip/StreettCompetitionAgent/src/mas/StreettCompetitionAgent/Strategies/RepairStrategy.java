package mas.StreettCompetitionAgent.Strategies;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;

import apltk.interpreter.data.LogicBelief;

import eis.iilang.Action;
import mas.StreettCompetitionAgent.Dijkstra;
import mas.StreettCompetitionAgent.StreettAgent;
import mas.StreettCompetitionAgent.Helpers.VertexHelper;
import massim.javaagents.agents.MarsUtil;

public class RepairStrategy {

	private StreettAgent agent;
	private boolean debug = false;
	public RepairStrategy(StreettAgent agent) {
		this.agent = agent;
	}
	
	public Action runStrategy() {
		
		LinkedList<LogicBelief> disabledBots = agent.getAllBeliefs("disabledBot");
		//System.out.println(agent.myName + " disabled list:" + disabledBots.toString());
		if (disabledBots.isEmpty()) {
			printLog("entered disabled clause");
			if (!agent.getAllBeliefs("myGoal").isEmpty() && agent.getAllBeliefs("myGoal").getFirst().getParameters().get(1).toString().equals("REPAIR")) {
				agent.removeBeliefs("myGoal");
				printLog("removed goals");
			}
			return null;
		} else {
			printLog("entered repair logic");
			if (agent.getAllBeliefs("myGoal").isEmpty()) {
				if (disabledBots.size() >= 1) {
					Dijkstra pathPlanner = new Dijkstra(agent);
					LinkedList<String> thisPath = new LinkedList<String>();
					int pathDistance = -1;
					String botToRepair = "";
					String botLocation = "";
					for (LogicBelief b : disabledBots) {
						LinkedList<String> testPath = pathPlanner.findPath(b.getParameters().get(0).toString());
						if (testPath != null) {
							int testDistance = testPath.size();
							if (pathDistance < 0 || testDistance < pathDistance) {
								thisPath = testPath;
								pathDistance = testDistance;
								botToRepair = b.getParameters().get(1).toString();
								botLocation = b.getParameters().get(0).toString();
							}
						}
					}
					if (thisPath.size() == 0) {
						printLog("has goal, wandering aimlessly");
						VertexHelper vHelper = new VertexHelper(agent);
						ArrayList<String> myNeighbors = vHelper.getNeighborVertexes(agent.getPosition());
						Collections.shuffle(myNeighbors);
						return MarsUtil.gotoAction(myNeighbors.get(0));
					}
					LogicBelief myGoal = new LogicBelief("myGoal", new String[] {
							botLocation, "REPAIR", botToRepair
					});

					agent.addBelief(myGoal);

					if (thisPath.size() > 1 && !thisPath.get(1).equals(agent.getPosition())) {
						printLog("has goal to repair Agent " + botToRepair + " at " + thisPath.getLast());
						//if (thisPath.get(1).equals(agent.getPosition())) System.out.println(agent.myName + " path debug: " + thisPath.toString());
						return MarsUtil.gotoAction(thisPath.get(1));
					} else {
						printLog("found Agent right away, repairing " + botToRepair);
						agent.removeBeliefs("myGoal");
						return MarsUtil.repairAction(botToRepair);
					}
				}
			} else { //Agent already has a goal
				LogicBelief myGoal = agent.getAllBeliefs("myGoal").getFirst();
				String botToRepair = myGoal.getParameters().get(2).toString();
				String botLocation = myGoal.getParameters().get(0).toString();
				
				//Agent has reached goal
				printLog("is at " + agent.getPosition() + " looking for " + botLocation + " " + agent.getPosition().equals(botLocation) + botLocation.equals(agent.getPosition()));
				if (agent.getPosition().equals(botLocation)) {
					//Check if agent is here
					LinkedList<LogicBelief> entities = agent.getAllBeliefs("entities");
					if (entities.isEmpty()) {
						printLog("found no one here!");
					} else {
						for (LogicBelief b : entities) {
							String ePosition = b.getParameters().get(1).toString();
							String eBotName = b.getParameters().get(0).toString();
						
							if (eBotName.equals(botToRepair) && ePosition.equals(agent.getPosition())) {
								System.out.println(agent.myName + " repairing " + botToRepair + " at " + botLocation);
								agent.removeBeliefs("myGoal");
								return MarsUtil.repairAction(botToRepair);
							}
						}
					}
				}
				//Agent needs next step in path
				Dijkstra pathPlanner = new Dijkstra(agent);
				LinkedList<String> thisPath = pathPlanner.findPath(botLocation);
				if (thisPath != null && thisPath.size() > 1) {
					printLog("on track - moving to " + thisPath.get(1) + " from " + agent.getPosition());
					return MarsUtil.gotoAction(thisPath.get(1));
				} else {
					VertexHelper vHelper = new VertexHelper(agent);
					ArrayList<String> myNeighbors = vHelper.getNeighborVertexes(agent.getPosition());
					Collections.shuffle(myNeighbors);
					printLog("is LOST! + moving to " + myNeighbors.get(0) + " from " + agent.getPosition());
					return MarsUtil.gotoAction(myNeighbors.get(0));
				}
			}

		}
		printLog("has no repair actions =====");
		return null;
	}
	
	public void printLog(String message) {
		if (debug) System.out.println(agent.myName + "(" + agent.getPosition() + ") " + message);
	}
}
