package mas.StreettCompetitionAgent.Strategies;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;

import apltk.interpreter.data.LogicBelief;
import eis.iilang.Action;
import mas.StreettCompetitionAgent.StreettAgent;
import massim.javaagents.agents.MarsUtil;
import mas.StreettCompetitionAgent.Helpers.*;

public class ProbeStrategy {

	private StreettAgent agent;
	
	public ProbeStrategy(StreettAgent agent) {
		this.agent = agent;
	}
	
	public Action runStrategy() {
		
		if (!hasProbedVertex(agent.getPosition())) {
			System.out.println(agent.myName + " probing vertex " + agent.getPosition());
			return MarsUtil.probeAction();
		} else if (goSurvey(agent.getPosition())) {
			//System.out.println(agent.myName + " surveying vertex " + agent.getPosition());
			return MarsUtil.surveyAction();
		}
		else {
			return MarsUtil.gotoAction(getNextProbeVertex());
		}
		
		//return null;
	}
	
	public boolean hasProbedVertex(String thisVertex) {
		boolean probed = false;
		LinkedList<LogicBelief> myBeliefs = agent.getAllBeliefs("probedVertex");
		if (!myBeliefs.isEmpty()) {
			Iterator<?> i = myBeliefs.iterator();
			do {
				LogicBelief thisBelief = (LogicBelief)i.next();
				if (thisBelief.getParameters().get(0).equals(thisVertex)) return true;
			} while (i.hasNext());
		}
		return probed;
	}
	
	public String getNextProbeVertex() {
		VertexHelper vHelper = new VertexHelper(agent);
		ArrayList<String> myNeighbors = vHelper.getNeighborVertexes(agent.getPosition());
		Collections.shuffle(myNeighbors);
		for (String t : myNeighbors) {
			if (!hasProbedVertex(t)) return t;
		}

		return myNeighbors.get(0);
	}
	
	public String getNextSurveyVertex() {
		VertexHelper vHelper = new VertexHelper(agent);
		ArrayList<String> myNeighbors = vHelper.getNeighborVertexes(agent.getPosition());
		for (String t : myNeighbors) {
			if (!hasProbedVertex(t)) return t;
		}
		Collections.shuffle(myNeighbors);
		return myNeighbors.get(0);
	}
	
	public boolean goSurvey(String start)
    {
        //ArrayList<String> vertexes = new ArrayList<String>();
		boolean goSurvey = false;
        String position = start;
        Iterator<LogicBelief> iterEdges = agent.getAllBeliefs("edges").iterator();
        Map<String, Integer> neighbors = new HashMap<String, Integer>();
        do
        {
            if(!iterEdges.hasNext())
                break;
            LogicBelief p = (LogicBelief)iterEdges.next();
            int distance = Integer.parseInt(((String)p.getParameters().get(2)).toString());
            String v1 = (String)p.getParameters().get(0).toString();
            String v2 = (String)p.getParameters().get(1).toString();
            if((v1.equals(position))) {
            	
            	if (!neighbors.containsKey(v1) || (neighbors.containsKey(v1) && distance < neighbors.get(v1))) {
            		neighbors.put(v1, distance);
            	}
                //vertexes.add(((String)p.getParameters().get(1)).toString());
            	//return true;
            } else if((v2.equals(position))) {
                //vertexes.add(((String)p.getParameters().get(0)).toString());
            	//return true;
            	if (!neighbors.containsKey(v2) || (neighbors.containsKey(v2) && distance < neighbors.get(v2))) {
            		neighbors.put(v2, distance);
            	}
            }
        } while(true);
        for (Integer t : neighbors.values()) {
        	if (t == 11) goSurvey = true;
        }
        return goSurvey;
    }
}
