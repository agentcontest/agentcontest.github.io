package mas.StreettCompetitionAgent.Strategies;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

import eis.iilang.Action;

import apltk.interpreter.data.LogicBelief;
import mas.StreettCompetitionAgent.Dijkstra;
import mas.StreettCompetitionAgent.StreettAgent;
import mas.StreettCompetitionAgent.Helpers.VertexHelper;
import massim.javaagents.agents.MarsUtil;

public class AttackStrategy {

	
	private StreettAgent agent;
	private boolean debug = false;
	private Map<String,String> enemyDictionary = new HashMap<String, String>();
	private ArrayList<String> reservedTargets = new ArrayList<String>();
	
	public AttackStrategy(StreettAgent agent) {
		this.agent = agent;
	}
	
	public Action runStrategy() {
		Action shouldUpgrade = shouldBuyUpgrade();
		if (shouldUpgrade != null) {
			return shouldUpgrade;
		}
		
		//If there are two repairers, this is a pointless fight, SCRAMBLE
		if (howMany("Repairer") > 1) {
			System.out.println(agent.myName + " scrambling due to pointless fight.");
			return MarsUtil.gotoAction(randomVertex());
		}
		LinkedList<LogicBelief> disabledBots = agent.getAllBeliefs("priorityTarget");

		Action myTarget = acquireTarget();
		//If any enemies within a block, attack them
		LinkedList<LogicBelief> executiveTargets = agent.getAllBeliefs("executiveTarget");
		if (!executiveTargets.isEmpty()) {
			disabledBots = executiveTargets;
			//System.out.println(agent.myName + " has Executive Targets");
		}
		//System.out.println(agent.myName + " target list:" + disabledBots.toString());
		if (myTarget != null) return myTarget;
		if (disabledBots.isEmpty()) {
			printLog("entered disabled clause");
			if (!agent.getAllBeliefs("myGoal").isEmpty() && agent.getAllBeliefs("myGoal").getFirst().getParameters().get(1).toString().equals("DEFEND")) {
				agent.removeBeliefs("myGoal");
				printLog("removed goals");
			}
			return null;
		} else {
			printLog("entered attack logic");
			if (agent.getAllBeliefs("myGoal").isEmpty()) {
				if (disabledBots.size() >= 1) {
					Dijkstra pathPlanner = new Dijkstra(agent);
					LinkedList<String> thisPath = new LinkedList<String>();
					int pathDistance = -1;
					String botToRepair = "";
					String botLocation = "";
					for (LogicBelief b : disabledBots) {
						LinkedList<String> testPath = pathPlanner.findPath(b.getParameters().get(0).toString());
						if (testPath != null) {
							int testDistance = testPath.size();
							if (pathDistance < 0 || testDistance < pathDistance) {
								thisPath = testPath;
								pathDistance = testDistance;
								botToRepair = b.getParameters().get(1).toString();
								botLocation = b.getParameters().get(0).toString();
							}
						}
					}
					if (thisPath.size() == 0) {
						printLog("has goal, wandering aimlessly");
						
						return MarsUtil.gotoAction(randomVertex());
					}
					LogicBelief myGoal = new LogicBelief("myGoal", new String[] {
							botLocation, "DEFEND", botToRepair
					});

					agent.addBelief(myGoal);

					if (thisPath.size() > 1 && !thisPath.get(1).equals(agent.getPosition())) {
						printLog("has goal to repair Agent " + botToRepair + " at " + thisPath.getLast());
						return MarsUtil.gotoAction(thisPath.get(1));
					} else {
						printLog("found Agent right away, defending " + botToRepair);
						agent.removeBeliefs("myGoal");
						return acquireTarget();
					}
				}
			} else { //Agent already has a goal
				LogicBelief myGoal = agent.getAllBeliefs("myGoal").getFirst();
				String botToRepair = myGoal.getParameters().get(2).toString();
				String botLocation = myGoal.getParameters().get(0).toString();
				
				//Agent has reached goal
				printLog("is at " + agent.getPosition() + " looking for " + botLocation + " " + agent.getPosition().equals(botLocation) + botLocation.equals(agent.getPosition()));
				if (agent.getPosition().equals(botLocation)) {
					//Check if agent is here
					LinkedList<LogicBelief> entities = agent.getAllBeliefs("entities");
					if (entities.isEmpty()) {
						printLog("found no one here!");
					} else {
						for (LogicBelief b : entities) {
							String ePosition = b.getParameters().get(1).toString();
							String eBotName = b.getParameters().get(0).toString();
						
							if (eBotName.equals(botToRepair) && ePosition.equals(agent.getPosition())) {
								System.out.println(agent.myName + " defending " + botToRepair + " at " + botLocation);
								agent.removeBeliefs("myGoal");
								return acquireTarget();
							}
						}
					}
				}
				//Agent needs next step in path
				Dijkstra pathPlanner = new Dijkstra(agent);
				LinkedList<String> thisPath = pathPlanner.findPath(botLocation);
				if (thisPath != null && thisPath.size() > 1) {
					printLog("on track - moving to " + thisPath.get(1) + " from " + agent.getPosition());
					return MarsUtil.gotoAction(thisPath.get(1));
				} else {

					return MarsUtil.gotoAction(randomVertex());
				}
			}

		}
		printLog("has no repair actions =====");
		return null;
	}
	
	public void printLog(String message) {
		if (debug) System.out.println(agent.myName + "(" + agent.getPosition() + ") " + message);
	}
	
	public Action acquireTarget() {
		Action target = null;
		LinkedList<LogicBelief> entities = agent.getAllBeliefs("entities");
		Map<String,String> enemies = new HashMap<String,String>();
		LinkedList<LogicBelief> enemyRolesBelief = agent.getAllBeliefs("enemyRole");
		Map<String,String> enemyRoles = new HashMap<String,String>();
		//LinkedList<LogicBelief> attackedBots = agent.getAllBeliefs("attacking");
		for (LogicBelief b: enemyRolesBelief) {
			enemyRoles.put(b.getParameters().get(0).toString(), b.getParameters().get(1).toString());
		}
		ArrayList<String> simpleTargets = new ArrayList<String>();
		ArrayList<String> priorityTargets = new ArrayList<String>();
		for (LogicBelief b : entities) {
			String ePosition = b.getParameters().get(1).toString();
			String eBotName = b.getParameters().get(0).toString();
			String eBotTeam = b.getParameters().get(2).toString();
			String eBotStatus = b.getParameters().get(3).toString();

			if (!eBotTeam.equals(agent.myTeam) && !eBotStatus.equals("disabled")) enemies.put(eBotName, ePosition);
			if (!eBotTeam.equals(agent.myTeam) && ePosition.equals(agent.getPosition()) && !eBotStatus.equals("disabled")) {
				//System.out.println(agent.myName + "[" + agent.myTeam + "] attacking " + b.toString());
				simpleTargets.add(eBotName);
				//System.out.println(agent.myName + " attacklogic is " + enemyRoles.isEmpty() + " - " +  enemyRoles.get(eBotName));
				if (!enemyRoles.isEmpty() && enemyRoles.get(eBotName) != null && enemyRoles.get(eBotName).equals("Repairer")) {
					//System.out.println(agent.myName + " attacking PRIORITY TARGET " + eBotName);
					//return MarsUtil.attackAction(eBotName);
					priorityTargets.add(eBotName);
				}
				//return MarsUtil.attackAction(eBotName);
			}
			
			
		}
		if (!priorityTargets.isEmpty()) {
			String pTarget = "";
			pTarget = chooseTarget(priorityTargets);
			System.out.println(agent.myName + "[" + agent.myTeam + "] attacking " + pTarget);
			announceTarget(pTarget);
			return MarsUtil.attackAction(pTarget);
		}
		if (!simpleTargets.isEmpty()) {
			String simpleTarget = "";
			simpleTarget = chooseTarget(simpleTargets);
			System.out.println(agent.myName + "[" + agent.myTeam + "] attacking " + simpleTarget);
			announceTarget(simpleTarget);
			return MarsUtil.attackAction(simpleTarget);
		}
		if (enemies.size() >= 1) {
			VertexHelper vHelper = new VertexHelper(agent);
			ArrayList<String> neighbors = vHelper.getNeighborVertexes(agent.getPosition());
			for (String e : enemies.keySet()) {
				for (String v : neighbors) {
					if (v.equals(enemies.get(e))) {
						return MarsUtil.gotoAction(enemies.get(e));
					}
				}
			}
		}
			
		return target;
	}
	
	public Action shouldBuyUpgrade() {
		Action nothing = null;
		String upgradePart = "";
		boolean shouldBuy = true;
		LinkedList<LogicBelief> entities = agent.getAllBeliefs("entities");
		LinkedList<LogicBelief> lastUpgrades = agent.getAllBeliefs("lastUpgrade");
		String lastUpgradedPart = "";
		if (!lastUpgrades.isEmpty()) lastUpgradedPart = lastUpgrades.getFirst().getParameters().get(0).toString();
		
		if (Integer.parseInt(agent.getVariable("money")) >= 4) {
			//System.out.println("WE HAVE MONEY TO BUY LET'S BUY!");
			for (LogicBelief b : entities) {
				String ePosition = b.getParameters().get(1).toString();
				//String eBotName = b.getParameters().get(0).toString();
				String eBotTeam = b.getParameters().get(2).toString();
				String eBotStatus = b.getParameters().get(3).toString();
				
				
				if (!eBotTeam.equals(agent.myTeam) && ePosition.equals(agent.getPosition()) && !eBotStatus.equals("disabled")) {
					//System.out.println(agent.myName + " Don't buy, HE'S CLOSE!!!!!" + eBotName);
					shouldBuy = false;
					break;
				}
				
			}
			//System.out.println(agent.myName + " purchase plans are " + shouldBuy + " " + )
			if (shouldBuy) {
				if (lastUpgradedPart.equals("") || lastUpgradedPart.equals("sabotageDevice")) {
					upgradePart = "shield";
				} else {
					upgradePart = "sabotageDevice";
				}
				LogicBelief lastUpgrade = new LogicBelief("lastUpgrade", new String[] {upgradePart, agent.getVariable("step")});
				if (!agent.getAllBeliefs("lastUpgrade").isEmpty()) {
					agent.updateBelief(agent.getAllBeliefs("lastUpgrade").getFirst(), lastUpgrade);
				} else {
					agent.addBelief(lastUpgrade);
				}
				System.out.println(agent.myName + " is upgrading " + upgradePart);
				return MarsUtil.buyAction(upgradePart);
			}
		}
		
		return nothing;
	}
	
	public int howMany(String role) {
		LinkedList<LogicBelief> enemyRolesBelief = agent.getAllBeliefs("enemyRole");
		LinkedList<LogicBelief> entities = agent.getAllBeliefs("entities");
		int result = 0;
		if (enemyRolesBelief.isEmpty() || entities.isEmpty()) {
			return -1;
		} else {
			//If Dictionary wasn't initialized
			if (enemyDictionary.isEmpty()) {
				for (LogicBelief b : enemyRolesBelief) {
					enemyDictionary.put(b.getParameters().get(0).toString(), b.getParameters().get(1).toString());
				}
			}
			for (LogicBelief e : entities) {
				String ePosition = e.getParameters().get(1).toString();
				String eBotName = e.getParameters().get(0).toString();
				String eBotTeam = e.getParameters().get(2).toString();
				//String eBotStatus = e.getParameters().get(3).toString();
				
				if (ePosition.equals(agent.getPosition()) && !eBotTeam.equals(agent.myTeam)) {
					String myEnemyRole = enemyDictionary.get(eBotName);
					if (myEnemyRole != null && myEnemyRole.equals(role)) {
						result += 1;
					}
				}
				
			}
			return result;
			
		}
	}
	
	public String randomVertex() {
		VertexHelper vHelper = new VertexHelper(agent);
		ArrayList<String> myNeighbors = vHelper.getNeighborVertexes(agent.getPosition());
		Collections.shuffle(myNeighbors);
		return myNeighbors.get(0);
	}
	
	public void announceTarget(String enemy) {
		LogicBelief myTarget = new LogicBelief("attacking", new String[] {enemy});
		agent.addBelief(myTarget);
		agent.broadcastBelief(myTarget);
	}
	
	public String chooseTarget(ArrayList<String> theEnemies) {
		String chosen = "";
		if (reservedTargets.isEmpty()) {
			for (LogicBelief b : agent.getAllBeliefs("attacking")) {
				reservedTargets.add(b.getParameters().get(0).toString());
			}
		}
		for (String t : theEnemies) {
			if (reservedTargets.contains(t)) {
				
				return t;
			}
		}
		Collections.shuffle(theEnemies);
		chosen = theEnemies.get(0);
		return chosen;
	}
}
