package mas.StreettCompetitionAgent;


import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;

import apltk.interpreter.data.LogicBelief;

public class Dijkstra {
	
	private StreettAgent agent;
	private Map<String,Integer> neighbors;
	private Map<String,String> paths = new HashMap<String, String>();
	private Map<String,Integer> distanceFromSource = new HashMap<String,Integer>();
	private Set<String> Q;
	//private Set<String> allVertexes;
	private LinkedList<String> thePath = new LinkedList<String>();
	private boolean debugLog = false;
	
	
	public Dijkstra(StreettAgent agent)
	{
		this.agent = agent;
	}
	
	public LinkedList<String> findPath(String goal) {
		printLog("My goal is :" + goal + " from Start: " + agent.getPosition());

		String u = agent.getPosition();
		boolean foundPath = false;

		Q = new HashSet<String>();
		Q.add(u);
		distanceFromSource.put(u, 0);
		//outterloop:
		while (!Q.isEmpty()) {

			u = getClosestVertex();
			if(u.equals(goal)) {
				foundPath = true;
				System.out.println(agent.myName + " found a PATH!");
				break;
			}


			Q.remove(u);
			getNeighborVertexes(u);
			printLog(agent.myName + " Queue is " + Q.size());

			for (String v : neighbors.keySet()) {
				int alt = distanceFromSource.get(u) + neighbors.get(v);
				if (distanceFromSource.get(v) == null || alt < distanceFromSource.get(v) ) {
					distanceFromSource.put(v, alt);
					paths.put(v, u);
					Q.add(v);
					printLog("Added " + v + " from " + u);
					printLog("Added " + v + " to Queue (" + alt + ")" );
				}
				
			}
		}
			
		if (foundPath) return getMyPath(goal);
		else return null;

	}
	
	public LinkedList<String> getMyPath(String goal) {
		String myToken = goal;
		thePath.addFirst(goal);
		while (!myToken.equals(agent.getPosition())) {
			myToken = paths.get(myToken);

			if (myToken != null) {

				thePath.addFirst(myToken);
			}
		}

		return thePath;
	}
	
	public String getClosestVertex() {
		int dist = 120000;
		String u = "";
		for (String key : Q) {
			if (distanceFromSource.get(key) != null && distanceFromSource.get(key) < dist) {
				u = key;
				dist = distanceFromSource.get(key);
			}
		}
		return u;
	}
	
	public void getNeighborVertexes(String start)
    {
        String position = start;
        Iterator<LogicBelief> iEdges = agent.getAllBeliefs("edges").iterator();
        neighbors = new HashMap<String, Integer>();
        do
        {
            if(!iEdges.hasNext())
                break;
            LogicBelief p = (LogicBelief)iEdges.next();
            if(((String)p.getParameters().get(0)).toString().equals(position)) {
            	String myVertex = (String)p.getParameters().get(1).toString();
            	int myDistance = Integer.parseInt(p.getParameters().get(2).toString());
            	if (neighbors.get(myVertex) == null) {
            		neighbors.put(myVertex, myDistance);
            	} else {
            		if (myDistance < neighbors.get(myVertex)) neighbors.put(myVertex, myDistance);
            	}
            }
            else if(((String)p.getParameters().get(1)).toString().equals(position)) {
            	String myVertex = (String)p.getParameters().get(0).toString();
	        	int myDistance = Integer.parseInt(p.getParameters().get(2).toString());
	        	if (neighbors.get(myVertex) == null) {
	        		neighbors.put(myVertex, myDistance);
	        	} else {
	        		if (myDistance < neighbors.get(myVertex)) neighbors.put(myVertex, myDistance);
	        	}
            }
        } while(true);
    }
	
	public void printLog(String text) {
		if (debugLog) {
			if (agent.myName.equals("b16")) {
				System.out.println(text);
			}
		}
	}
	public void printLogs(String text) {
		if (debugLog) {
			if (agent.myName.equals("b16")) {
				System.out.print(text);
			}
		}
	}

}
