package mas.StreettCompetitionAgent;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;

import apltk.interpreter.data.LogicBelief;

import eis.iilang.Percept;

public class BeliefBuilder {

	
	private StreettAgent agent;

	public BeliefBuilder(StreettAgent agent) {
		this.agent = agent;
	}
	
	public void BuildBeliefs() {
		Collection<?> percepts;
		percepts = agent.getPercepts();
		Iterator<?> i = percepts.iterator();
		boolean outtaJuice = false;
		try {
			agent.removeBeliefs("jointMove");
			agent.removeBeliefs("moving");
			agent.removeBeliefs("disabledBot");
		}
		catch (Exception e) {
			
		}
		agent.getAllMessages();
		try {
			int thisStep = Integer.parseInt(agent.getVariable("step").toString());
			if (thisStep % 25 == 0) {
				//System.out.println("CHANGE PLACES!");
				agent.removeBeliefs("occupied");
				agent.removeBeliefs("myGoalZ");
			}
			agent.removeBeliefs("visibleEntity");
			agent.removeBeliefs("outtaJuice");
			agent.removeBeliefs("money");
			agent.removeBeliefs("position");
			agent.removeBeliefs("entities");
			agent.removeBeliefs("inspected");
			agent.removeBeliefs("step");
			agent.removeBeliefs("health");
			agent.removeBeliefs("attacking");
			agent.removeBeliefs("surveyedEdge");
			agent.removeBeliefs("visibleEdge");
			agent.removeBeliefs("lastActionResult");
			agent.removeBeliefs("lastAction");
			if (!agent.getAllBeliefs("zoned").isEmpty() && agent.getAllBeliefs("zonesCleared").isEmpty()) {
				//System.out.println(agent.myName + " removing Securing Positions");
				agent.removeBeliefs("startPoint");
				agent.removeBeliefs("securingPositions");
				LogicBelief zonesCleared = new LogicBelief("zonesCleared", new String[] {"true"});
				agent.addBelief(zonesCleared);
				agent.removeBeliefs("myGoal");
			}

		}
		catch (Exception e){
			
		}

		do 
		{
			Percept p = (Percept)i.next();
			//Build Singleton Beliefs
			
			String pName = p.getName();
//			if (agent.getRole() != null && agent.getRole().equals("Inspector") && pName != "visibleEdge" && pName != "visibleVertex" && pName != "surveyedEdge" && pName != "probedVertex") {
//				System.out.println(agent.myName + " percept of " + p.toString());
//			}
			if (agent.myName.equals("b1") && pName == "money") {
				System.out.println(p.toString());
			}
			if(pName == "surveyedEdge") {
				LogicBelief surveyedEdge = new LogicBelief("edges", new String[] {
						p.getParameters().get(0).toString(), p.getParameters().get(1).toString(), p.getParameters().get(2).toString()
				});
				LogicBelief visibleEdge = new LogicBelief("edges", new String[] {
						p.getParameters().get(0).toString(), p.getParameters().get(1).toString(), "11"
				});
				LinkedList<LogicBelief> myEdges = agent.getAllBeliefs("edges");
				if (myEdges.contains(surveyedEdge)) {
					//Nothing to do
				} else if (myEdges.contains(visibleEdge)) {
					agent.updateBelief(visibleEdge, surveyedEdge);
				} else if (!myEdges.contains(surveyedEdge)) {
					agent.addBelief(surveyedEdge);
				}
				this.storeBelief("surveyedEdge", new String[] {
						p.getParameters().get(0).toString(), p.getParameters().get(1).toString(), p.getParameters().get(2).toString()
				});
			}

			if (pName == "position" || pName == "money" || pName == "lastAction" || pName == "lastActionResult" || pName == "step" || pName == "health") {
				storeBelief(pName, new String [] {p.getParameters().get(0).toString()});
				//System.out.println(agent.myName + p.toString());
			}
//			if (pName == "lastActionResult" && !p.getParameters().get(0).toString().equals("successful")) {
//				System.out.println(agent.myName + " ========================================" + p.getParameters().get(0).toString() + "==================================");
//			}
			if (pName == "role" && agent.getAllBeliefs("role").isEmpty()) {
				LogicBelief belief = new LogicBelief("role", new String[] {
						p.getParameters().get(0).toString()
				});
				agent.addBelief(belief);
			}
			if (pName == "visibleEdge") {
				LogicBelief belief = new LogicBelief("edges", new String[] {
					p.getParameters().get(0).toString(), p.getParameters().get(1).toString(), "11"	
				});
				
				if (!agent.containsBelief(belief)) {
					agent.addBelief(belief);
					agent.broadcastBelief(belief);
				}
				this.storeBelief("visibleEdge", new String[] {
					p.getParameters().get(0).toString(), p.getParameters().get(1).toString(), "11"	
				});

			}
			if (pName == "probedVertex") {
				//System.out.println(agent.myName + " " + p.toString());
				this.storeBelief("probedVertex", new String[] {p.getParameters().get(0).toString(), p.getParameters().get(1).toString()});
				if (p.getParameters().get(1).toString().equals("10")) {
					LogicBelief startPoint = new LogicBelief("goodPoint", new String[] {p.getParameters().get(0).toString()});
					agent.addBelief(startPoint);
					agent.broadcastBelief(startPoint);
				}
			}
			if (pName == "visibleVertex") {
				LogicBelief belief = new LogicBelief("vertexes", new String[] {
					p.getParameters().get(0).toString()
				});
				
				if (!agent.containsBelief(belief)) {
					agent.addBelief(belief);
					agent.broadcastBelief(belief);
				}

			}
			if (pName == "lastActionResult") {
				if (p.getParameters().get(0).toString().equals("failed_resources")) outtaJuice = true;
				//System.out.println(agent.myName + " " + p.toString());
			}
			if (pName == "energy") {
				if (Integer.parseInt(p.getParameters().get(0).toString()) <= 3) outtaJuice = true;
			}	
	
			if (pName == "visibleEntity") {
				LogicBelief belief = new LogicBelief("entities", new String[] {
						p.getParameters().get(0).toString(), p.getParameters().get(1).toString(), p.getParameters().get(2).toString(), p.getParameters().get(3).toString()
					});
					agent.addBelief(belief);
			}	
			if (pName == "inspectedEntity") {
				LogicBelief belief = new LogicBelief("inspected", new String[] {
						p.getParameters().get(0).toString(), p.getParameters().get(1).toString(), p.getParameters().get(2).toString(), p.getParameters().get(3).toString()
					});
				agent.addBelief(belief);
				LogicBelief enemyRoles = new LogicBelief("enemyRole", new String[] { p.getParameters().get(0).toString(), p.getParameters().get(2).toString()});
				agent.addBelief(enemyRoles);
				agent.broadcastBelief(enemyRoles);
				
				//System.out.println(agent.myName + " found a live one " + p.toString());
				if (p.getParameters().get(2).toString().equals("Repairer") && !p.getParameters().get(7).toString().equals("0")) {
					LogicBelief pTarget = new LogicBelief("executiveTarget", new String[] {
						p.getParameters().get(3).toString(), p.getParameters().get(0).toString()//, p.getParameters().get(2).toString(), p.getParameters().get(3).toString()	
					});
					agent.broadcastBelief(pTarget);
					//System.out.println(agent.myName + " FOUND EXECUTIVE TARGET!" + p.toString());
				}
					
			}


			if (outtaJuice) {
				LogicBelief belief = new LogicBelief("outtaJuice", new String[] {
						"true"
				});
				agent.addBelief(belief);
			}
		} while(i.hasNext());
	}
	
	private void storeBelief(String beliefName, String[] beliefArguments) {
		LogicBelief belief = new LogicBelief(beliefName, beliefArguments);
		agent.addBelief(belief);
		if (beliefName.equals("position")) {
			LogicBelief posBelief = new LogicBelief("allPositions", new String[] {
					agent.myName, agent.getPosition()
			});
			agent.broadcastBelief(posBelief);
		}
		if (beliefName.equals("health") && beliefArguments.equals(new String[] {"0"})) {
			LogicBelief disabledBelief = new LogicBelief("disabled", new String[] {"true"});
			agent.addBelief(disabledBelief);
		}
	}
}
