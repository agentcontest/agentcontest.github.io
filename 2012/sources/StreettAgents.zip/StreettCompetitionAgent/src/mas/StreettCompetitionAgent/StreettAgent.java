package mas.StreettCompetitionAgent;

import apltk.interpreter.data.*;
import eis.iilang.*;
import eis.iilang.Percept;
import massim.javaagents.Agent;
import massim.javaagents.agents.MarsUtil;

import java.util.Collection;

import java.util.Iterator;


public class StreettAgent extends Agent {

	public String myName;
	public String myTeam;
	public int myPhase;

	public StreettAgent(String name, String team) {
		super(name,team);
		myName = name;
		myTeam = team;
		myPhase = 0;
	}
	
	@Override
	public void handlePercept(Percept p) {
		System.out.println("Percept received: " + p.toString());
	}
	
	@Override
	public Action step() {
		BeliefBuilder buildBeliefs = new BeliefBuilder(this);
		buildBeliefs.BuildBeliefs();
		StrategySelector myStrategy = new StrategySelector(this);
		Action myChosenAction = myStrategy.findStrategy();
		if (myChosenAction != null) return myChosenAction;
		return MarsUtil.rechargeAction();
	}
	
	
	public String getPosition() {
		if (this.getAllBeliefs("position").isEmpty()) return null;
		else return this.getAllBeliefs("position").getFirst().getParameters().get(0).toString();
	}
	
	public String getVariable(String varName) {
		if (this.getAllBeliefs(varName).isEmpty()) return null;
		else return this.getAllBeliefs(varName).getFirst().getParameters().get(0).toString();
	}
	
	public String getRole() {
		if (this.getAllBeliefs("role").isEmpty()) return null;
		else return this.getAllBeliefs("role").getFirst().getParameters().get(0).toString();
	}
	
	public boolean isDisabled() {
		if (this.getAllBeliefs("disabled").isEmpty()) return false;
		return true;
	}
	
	public int getHealth() {
		if (!this.getAllBeliefs("health").isEmpty()) {
			return Integer.parseInt(this.getAllBeliefs("health").getFirst().getParameters().get(0).toString());
		}
		return 0;
	}
	
	public Collection<?> getPercepts() {
		return getAllPercepts();
	}

	public void getAllMessages() {
		try {
			Collection<?> myMessages = this.getMessages();
			Iterator<?> i = myMessages.iterator();
			
			do {
				Message bob = (Message)i.next();
				if (!this.containsBelief((LogicBelief)bob.value)) this.addBelief((LogicBelief)bob.value);
								
			} while (i.hasNext());
		}
		catch(Exception e) {
			
		}

	}
	
    public void updateBelief(LogicBelief originalBelief, LogicBelief newBelief) {
    	if (beliefs.contains(originalBelief)) {
    		beliefs.remove(originalBelief);
    	}
		addBelief(newBelief);
 
    }
    
    public void removeBelief(LogicBelief originalBelief) {

    	if (beliefs.contains(originalBelief)) {
    		beliefs.remove(originalBelief);
    	}
    }
}
