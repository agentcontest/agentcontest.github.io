package mas.StreettCompetitionAgent;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;

import apltk.interpreter.data.LogicBelief;

import massim.javaagents.agents.MarsUtil;
import eis.iilang.Action;
import mas.StreettCompetitionAgent.Helpers.VertexHelper;
import mas.StreettCompetitionAgent.Strategies.*;

public class StrategySelector {

	private StreettAgent agent;
	
	public StrategySelector(StreettAgent agent) {
		this.agent = agent;
	}
	
	public Action findStrategy() {
		String myRole = agent.getRole();
		if (agent.getVariable("lastActionResult").equals("failed_wrong_param")) {
			System.out.println(agent.myName + "(" + agent.getRole() + ") " + agent.getPosition() + " ==================================" + agent.getVariable("lastActionResult") + " [" + agent.getVariable("lastAction") + "] ==========================");
		}
		Action disabledAction = disabledStrategy();
		if (disabledAction != null) {
			return disabledAction;
		}
		if (myRole != null && myRole.equals("Explorer")) {
			if(agent.getAllBeliefs("outtaJuice").isEmpty()) {
				ProbeStrategy tryProbe = new ProbeStrategy(agent);
				return tryProbe.runStrategy();
			} else {
				return MarsUtil.rechargeAction();
			}
		}
		else if (myRole.equals("Repairer")) {
			if(agent.getAllBeliefs("outtaJuice").isEmpty()) {
				
				RepairStrategy repairStrategy = new RepairStrategy(agent);
				Action repairAction = repairStrategy.runStrategy();
				if (repairAction != null) {
					return repairAction;
				}
			} else {
				System.out.println(agent.myName + " is recharging.");
				return MarsUtil.rechargeAction();
			}
		}
		else if (myRole.equals("Saboteur")) {
			if (!agent.getAllBeliefs("inspected").isEmpty()) {
				for (LogicBelief b : agent.getAllBeliefs("inspected")){
					System.out.println(agent.myName + " has amazingly seen: " + b.toString());
				}
			}
			if(agent.getAllBeliefs("outtaJuice").isEmpty()) {
				AttackStrategy attackStrategy = new AttackStrategy(agent);
				Action attack = attackStrategy.runStrategy();
				if (attack != null) return attack;
				
			} else {
				System.out.println(agent.myName + " is recharging.");
				return MarsUtil.rechargeAction();
			}
		}
		else if (myRole.equals("Inspector")) {
			if(agent.getAllBeliefs("outtaJuice").isEmpty()) {
				InspectStrategy attackStrategy = new InspectStrategy(agent);
				Action inspect = attackStrategy.runStrategy();
				if (inspect != null) return inspect;
				
			} else {
				System.out.println(agent.myName + " is recharging.");
				return MarsUtil.rechargeAction();
			}
		}
		else {
			//System.out.println(agent.myName + " " + agent.getVariable("lastActionResult"));
			if(agent.getAllBeliefs("outtaJuice").isEmpty()) {
				if (goSurvey(agent.getPosition())) {
					System.out.println(agent.myName + " surveying " + agent.getPosition());
					return MarsUtil.surveyAction();
				} else {
					ZoneStrategy zoneStrategy = new ZoneStrategy(agent);
					Action zone = zoneStrategy.runStrategy();
					if (zoneStrategy != null) {
						return zone;
					}
					//return MarsUtil.gotoAction(randomVertex());
				}
			} else {
				return MarsUtil.rechargeAction();
			}
		}
		if (goSurvey(agent.getPosition())) {
			System.out.println(agent.myName + " surveying " + agent.getPosition());
			return MarsUtil.surveyAction();
		} else {
			return MarsUtil.gotoAction(randomVertex());
		}
		//System.out.println(agent.myName + " has no plan!");
		//return MarsUtil.rechargeAction();
	}
	
	public boolean goSurvey(String start)
    {
        //ArrayList<String> vertexes = new ArrayList<String>();
		boolean goSurvey = false;
        String position = start;
        Iterator<LogicBelief> iterEdges = agent.getAllBeliefs("edges").iterator();
        Map<String, Integer> neighbors = new HashMap<String, Integer>();
        do
        {
            if(!iterEdges.hasNext())
                break;
            LogicBelief p = (LogicBelief)iterEdges.next();
            int distance = Integer.parseInt(((String)p.getParameters().get(2)).toString());
            String v1 = (String)p.getParameters().get(0).toString();
            String v2 = (String)p.getParameters().get(1).toString();
            if((v1.equals(position))) {
            	
            	if (!neighbors.containsKey(v1) || (neighbors.containsKey(v1) && distance < neighbors.get(v1))) {
            		neighbors.put(v1, distance);
            	}

            } else if((v2.equals(position))) {

            	if (!neighbors.containsKey(v2) || (neighbors.containsKey(v2) && distance < neighbors.get(v2))) {
            		neighbors.put(v2, distance);
            	}
            }
        } while(true);
        for (Integer t : neighbors.values()) {
        	if (t == 11) goSurvey = true;
        }
        return goSurvey;
    }
	
	public Action disabledStrategy() {
		Action strategy = null;
		if (agent.getHealth() <= 0) {
			agent.addBelief(new LogicBelief("disabled", new String[] {"true"}));
			LogicBelief disabledBot = new LogicBelief("disabledBot", new String[] {agent.getPosition(), agent.myName, agent.getRole()});
			agent.broadcastBelief(disabledBot);
			if (!agent.getRole().equals("Repairer")) return MarsUtil.rechargeAction();
		}
		if (agent.isDisabled() && agent.getHealth() > 0) {
			agent.removeBeliefs("disabled");
			LogicBelief healed = new LogicBelief("healed", new String[] {agent.getPosition(), agent.myName, agent.getRole()});
			agent.broadcastBelief(healed);
			System.out.println(agent.myName + " was healed for a total of " + agent.getHealth());
		}
		if (!agent.getAllBeliefs("healed").isEmpty()) {
			for (LogicBelief b : agent.getAllBeliefs("healed")) {
				LogicBelief disabledBot = new LogicBelief("disabledBot", new String[] {
						b.getParameters().get(0).toString(), b.getParameters().get(1).toString(), b.getParameters().get(2).toString()
				});
				agent.removeBelief(disabledBot);
				//System.out.println(agent.myName + " removed " + b.getParameters().get(1).toString() + " from disabled");
			}
			agent.removeBeliefs("healed");
		}
		if (!agent.getAllBeliefs("entities").isEmpty()) {
			for (LogicBelief e : agent.getAllBeliefs("entities")) {
				
				String ePosition = e.getParameters().get(1).toString();
				String eBotName = e.getParameters().get(0).toString();
				String eBotTeam = e.getParameters().get(2).toString();
				String eBotStatus = e.getParameters().get(3).toString();
				
				if (!eBotTeam.equals(agent.myTeam) && eBotStatus.equals("disabled")) {
					LogicBelief deadTarget = new LogicBelief("priorityTarget", new String[] {
							ePosition, eBotName
					});
					for (LogicBelief eTarget : agent.getAllBeliefs("executiveTarget")) {
						if (eTarget.getParameters().get(1).equals(eBotName)) {
							LogicBelief markRemoved = new LogicBelief("executiveTarget", new String[] {
									ePosition, eBotName//eBotName, ePosition, eBotTeam, eBotStatus
							});
							agent.removeBelief(markRemoved);
							markRemoved = new LogicBelief("markRemove", new String[] {
									ePosition, eBotName
							});
							//System.out.println(agent.myName + " announced death of " + eTarget.toString());
							agent.broadcastBelief(markRemoved);
						}
					}
					agent.removeBelief(deadTarget);
				}
			}
			if(!agent.getAllBeliefs("markRemove").isEmpty()) {
				for (LogicBelief b : agent.getAllBeliefs("markRemove")) {
					LogicBelief disabledBot = new LogicBelief("executiveTarget", new String[] {
							b.getParameters().get(0).toString(), b.getParameters().get(1).toString()
					});
					agent.removeBelief(disabledBot);
					//System.out.println(agent.myName + " removed " + b.getParameters().get(1).toString() + " from executive Targets");
				}
				agent.removeBeliefs("markRemove");
			}
		}
		
		if(agent.getRole().equals("Repairer") && agent.isDisabled()) {
			System.out.println(agent.myName + " is disabled");
			if(!agent.getAllBeliefs("outtaJuice").isEmpty()) {
				return MarsUtil.rechargeAction();
			} else {
				if (!agent.getAllBeliefs("entities").isEmpty()) {
					
					LinkedList<LogicBelief> entities = agent.getAllBeliefs("entities");
					for (LogicBelief e : entities) {
						String ePosition = e.getParameters().get(1).toString();
						String eBotName = e.getParameters().get(0).toString();
						String eBotTeam = e.getParameters().get(2).toString();
						String eBotStatus = e.getParameters().get(3).toString();
						//System.out.println(agent.myName + " considering " + e.toString());
						if (!eBotName.equals(agent.myName) && eBotTeam.equals(agent.myTeam) && ePosition.equals(agent.getPosition()) && eBotStatus.equals("disabled")) {
							System.out.println(agent.myName + " disabled, but repairing " + eBotName);
							return MarsUtil.repairAction(eBotName);
						}
					}
				}
			}
		}
		
		
		
		return strategy;
	}
	
	public String randomVertex() {
		VertexHelper vHelper = new VertexHelper(agent);
		ArrayList<String> neighbors = vHelper.getNeighborVertexes(agent.getPosition());
		Collections.shuffle(neighbors);
		return neighbors.get(0);
	}
	
}
