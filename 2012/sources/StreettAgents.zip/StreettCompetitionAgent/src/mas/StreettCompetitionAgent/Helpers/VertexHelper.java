package mas.StreettCompetitionAgent.Helpers;

import java.util.ArrayList;
import java.util.Iterator;

import mas.StreettCompetitionAgent.StreettAgent;

import apltk.interpreter.data.LogicBelief;

public class VertexHelper {

	private StreettAgent agent;
	public VertexHelper(StreettAgent agent) {
		this.agent = agent;
	}
	
	public ArrayList<String> getNeighborVertexes(String start)
    {
        ArrayList<String> vertexes = new ArrayList<String>();
        String position = start;
        Iterator<LogicBelief> iterEdges = agent.getAllBeliefs("edges").iterator();
        do
        {
            if(!iterEdges.hasNext())
                break;
            LogicBelief p = (LogicBelief)iterEdges.next();
            if(((String)p.getParameters().get(0)).toString().equals(position))
                vertexes.add(((String)p.getParameters().get(1)).toString());
            else
            if(((String)p.getParameters().get(1)).toString().equals(position))
                vertexes.add(((String)p.getParameters().get(0)).toString());
        } while(true);
        return vertexes;
    }
}
