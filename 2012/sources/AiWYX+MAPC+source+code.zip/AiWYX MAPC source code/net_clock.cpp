#include<stdio.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<error.h>
#include<string.h>
#include<sys/types.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<string>
#include<string.h>
#include<iostream>
#include<vector>
#include<queue>
#include<map>
#include<algorithm>
#include<stack>
#include<sys/wait.h>
using namespace std;

const int max_msg_n=1001000;

string bo_lin_ip="127.0.0.1";
int bo_lin_port=12300;

struct Server;

//N
struct Net
{
	int                  s;//创建套结字
	struct   sockaddr_in    ServerAddr;
//	int                  Port;//端口
	//char     DataBuffer[max_msg_length];//接受数据缓冲区
	string ip;
	int port;
	Net()
	{
		s=0;
	}
	int st(string ip,int Port)
	{	
		this->ip=ip;
		this->port=Port;
		
//		Port = cc.port;
		s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);//创建一个套节字
		if(s==-1)
		{
      		puts("socket failed with error \n");
      		return 0;
   		} 
		ServerAddr.sin_family = AF_INET;
		ServerAddr.sin_port = htons(Port);    
		ServerAddr.sin_addr.s_addr = inet_addr(ip.c_str());//服务器地址IP
			
		cout<<"We are trying to connect to "<<inet_ntoa(ServerAddr.sin_addr)<<":"<<(ntohs(ServerAddr.sin_port))<<"...\n";

		if(connect(s, (   sockaddr *) &ServerAddr, sizeof(ServerAddr)) == -1)//连接到服务器
		{
			cout<<"Connect failed!\n";
			return 0;
		}
		cout<<"Our connection succeeded.\n";
		return 1;
	}
	
			
	void Run()
	{
		int i;
		int n;
		while(1)
		{
			int z=recv(s, buff,max_msg_n, 0);
			cout<<"net "<<s<<' '<<other_s<<' '<<z<<endl;
			if(z==0)
			{
				st(ip,port);
			}
			if(z<=0)
			{
				cout<<"[[[[[[[[[[[[["<<buff<<"]]]]]]]]]]]"<<endl;
				cout<<z<<endl;
				continue;
				return ;
				exit(0);
			}
			cout<<"recv from WYX: "<<z<<' '<<int(buff[z-1])<<endl;
			Send(buff,z);
			
		}
		return;
	}
	
	string Send(char r[],int n)
	{
		//AddLn(r);
		cout<<other_s<<endl;
		cout<<r<<endl;
		cout<<n<<endl;
		cout<<int(r[n-1])<<endl;
		while(1)
		{
			int z=send(other_s, r, n, 0);						
			if(z<=0)
			{
			//	cout<<"z<-0"<<endl;
				continue;	
			}
			printf("send to WYX: %d\n",z);
			break;						
		}
		return "";
	}
	
	~Net()
	{
		close(s);
	}
	char buff[max_msg_n];
	int other_s;
}net;


class Server
{
public:
	Server()
	{
		new_fd=0;
	}
	void Init(string ip,int port)
	{		
		cout<<ip<<"---------"<<port<<endl;
		if ((sock_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
		{
			perror("socket fail!");
			exit(1);
		}
		serv_addr.sin_family = AF_INET;
		serv_addr.sin_port = htons(port); 
		serv_addr.sin_addr.s_addr = INADDR_ANY;
		bzero(&(serv_addr.sin_zero), 8);
		if (bind(sock_fd, (struct sockaddr *) &serv_addr, sizeof(struct sockaddr))== -1)
		{
			fprintf(stderr, "bind port %d fail!\n", port);
			exit(1);
		}
		if (listen(sock_fd, 10) == -1)
		{
			perror("listen fail!");
			exit(1);
		}
		
		
	}
	
	void Run()
	{		
		while(1)
		{
			printf("listenning......\n");
			sin_len = sizeof(dest_addr);
			if ((new_fd = accept(sock_fd, (struct sockaddr *) &dest_addr, &sin_len))== -1)
			{
				perror("accept fail!");
				exit(1);
			}
			printf("A client has connected to me.\t%s:%d\n", inet_ntoa(dest_addr.sin_addr), ntohs(dest_addr.sin_port));
			
			
			while (1)
			{
				if ((recv_byte = read(new_fd, buff,max_msg_n)) < 0)
				{
					perror("read fail!");
					continue;
				}
				else if (recv_byte == 0)
				{
					printf("A current client has disconnected to me.\n");
					break;
				}
				else
				{
					buff[recv_byte] = '\0';
					printf("RECEIVE:%d\n", recv_byte);	
					Send(buff,recv_byte);
				}
			}
		}
	}
	
	string Send(char buff[],int len)
	{
		while(1)
		{
			int z=send(other_s, buff, len, 0);
			cout<<new_fd<<' '<<other_s<<' '<<z<<endl;
			if(z<=0)
			{
				continue;	
			}
			printf("send to bolin: %d\n",z);
			break;						
		}
		return "";
	}
	
	~Server()
	{		
		close(new_fd);
		close(sock_fd);
	}

	int sock_fd, new_fd;
	struct sockaddr_in serv_addr, dest_addr;
	socklen_t sin_len;
	int recv_byte;
	char buff[max_msg_n];
	int other_s;
private:
}server;

pthread_t tid1[100],tid2[100];
int pid1[100],pid2[100];

struct Ip_port
{
	string ip;
	int port;
	int id;
}net_ip_port[100],server_ip_port;

void *thread_net(void *arg)
{
	Ip_port *p;
	p=(Ip_port*)arg;
	
	net[p->id].Init();	
	net[p->id].Run();
	
	return((void *)0);
}

void *thread_net(void *arg)
{
	Ip_port *p;
	p=(Ip_port*)arg;
	
	net[p->id].Init();	
	net[p->id].Run();
	
	return((void *)0);
} 

int main(int argc, char *argv[])
{
	int size=1024*1024*1024;
	char *p = (char*)malloc(size) + size;
	asm("movl %0, %%esp\n" :: "r"(p));

	if(argc!=5)
	{
		return 0;
	}
		
	int i,n;
	int z=0;
	for(i=0;argv[2][i];i++)
		z=z*10+argv[2][i]-'0';
	
	bo_lin_ip=argv[3];
	bo_lin_port=0;
	for(i=0;argv[4][i];i++)
		bo_lin_port=bo_lin_port*10+argv[4][i]-'0';
		
	net.st(bo_lin_ip,bo_lin_port);
	server.Init(argv[1],z);
	
	server.other_s=net.s;
	net.other_s=server.new_fd;
	
	if((pid1[0]=fork())==0)
	{
		net.Run();
		exit(0);
	}
	
	
		server.Run();
	
	n=1;
	for(i=0;i<n;i++)
	{
		net_ip_port.id=i;
		net_ip_port.ip=bo_lin_ip;
		net_ip_port.port=bo_lin_port;
	}
	
		
	if(pthread_create(&tid1[0], NULL, thread_net,&ip_port[i]))
		D.Error("jg589098u43e98yu34");
	
	
	if(pthread_create(&tid1[0], NULL, thread_server,&ip_port[i]))
		D.Error("jg589098u43e98yu34");
		
	cout<<"------------ all fork run"<<endl;
	
	
	
	return 0;
} 
