#include<stdio.h>
#include<stdlib.h>
#include<sys/socket.h>
//#include<error.h>
#include<string.h>
//#include<sys/types.h>
//#include<netinet/in.h>
#include<arpa/inet.h>
#include<string>
#include<string.h>
#include<iostream>
#include<vector>
#include<queue>
#include<map>
#include<algorithm>
#include<stack>
#include <pthread.h>
#include <unistd.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
//#include<sys/wait.h>
using namespace std;


//Should_attack_enermy(zv)


//Node::Set_edge_value() edge value can not be 0
//if some node's nabour are all suveyed then this node do not need to surveyed
//dang1 yu4 dao4 di2 ren2, ru2 guo3 di2 ren2 de neng2liang4 bu2gou4, ze2 pao3

typedef long long LL;
const int oo = 0x3fffffff;

const int max_msg_length =1000000;
const int min_msg_length=1000000;
int ts;
int us;
int clock_sign=0;

struct CC
{	
	CC()
	{				
		srand(time(0));
		qj=0;
		
	//	mm1=rand()%2;
	//	mm1=0;
		
		kuo01=rand()%2;
		log_on=0;
		//ip="agentcontest2.in.tu-clausthal.de";
		//ip="139.174.101.97";
		//ip="127.0.0.1";
		//ip="172.18.218.199";
		//ip="172.18.218.36";
		use_tread_clock=0;
		agent_n=20;
		
		//debug_repairer=1;
		
		debug=1;
		debug_function_path=1;
		port=12300;
		clocksPerSecond=1000;
		
		alliance_mode="alliance_mode";
		mode.clear();
		mode.push_back(alliance_mode);


		explorer="Explorer";
		saboteur="Saboteur";
		inspector="Inspector";		
		repairer="Repairer";
		sentinel="Sentinel";
		
		can_buy_role.clear();
		if(rand()%2)
			can_buy_role.push_back(saboteur);
	//	can_buy_role.push_back(repairer);
		
		do_not_attack.clear();
	//	do_not_attack.push_back("b3");
	//	do_not_attack.push_back("b4");
	//	do_not_attack.push_back("b13");
	//	do_not_attack.push_back("b14");
		
		request_action ="request-action";
		
		version = "version";
		encoding = "encoding";
		message_timestamp = "message_timestamp";
		message_type = "message_type";
		perception_deadline = "perception_deadline";
		perception_id = "perception_id";
		simulation_step = "simulation_step";
		self_energy = "self_energy";
		self_health = "self_health";
		self_lastAction = "self_lastAction";
		self_lastActionParam = "self_lastActionParam";
		self_lastActionResult = "self_lastActionResult";
		self_maxEnergy = "self_maxEnergy";
		self_maxEnergyDisabled = "self_maxEnergyDisabled";
		self_maxHealth = "self_maxHealth";
		self_position = "self_position";
		self_strength = "self_strength";
		self_visRange = "self_visRange";
		self_zoneScore = "self_zoneScore";
		team_lastStepScore = "team_lastStepScore";
		team_money = "team_money";
		team_score = "team_score";
		team_zonesScore = "team_zonesScore";
		achievement_name = "achievement_name";
		visibleVertex_name = "visibleVertex_name";
		visibleVertex_team = "visibleVertex_team";
		
		visibleEntity_name = "visibleEntity_name";
		visibleEntity_node = "visibleEntity_node";
		visibleEntity_status = "visibleEntity_status";
		visibleEntity_team = "visibleEntity_team";
		
		probedVertex_name = "probedVertex_name";
		probedVertex_value = "probedVertex_value";
		
		surveyedEdge_node1 = "surveyedEdge_node1";
		surveyedEdge_node2 = "surveyedEdge_node2";
		surveyedEdge_weight = "surveyedEdge_weight";
		
		inspectedEntity_energy = "inspectedEntity_energy";
		inspectedEntity_health = "inspectedEntity_health";
		inspectedEntity_maxEnergy = "inspectedEntity_maxEnergy";
		inspectedEntity_name = "inspectedEntity_name";
		inspectedEntity_node = "inspectedEntity_node";
		inspectedEntity_role = "inspectedEntity_role";
		inspectedEntity_strength = "inspectedEntity_strength";
		inspectedEntity_team = "inspectedEntity_team";
		inspectedEntity_visRange = "inspectedEntity_visRange";
		/*
		node = "node";
	//	visibleVertex_node = "visibleVertex node";
		status = "status";
	//	visibleVertex_status = "visibleVertex status";
		edges = "edges";
		role = "role";
		steps = "steps";
		vertices = "vertices";
		
		survey="survey";
		achievement="achievement";*/
		survey="survey";
		
		timestamp="timestamp";
		type="type";
		deadline="deadline";
		visibleEdge_node1="visibleEdge_node1";
		visibleEdge_node2="visibleEdge_node2";
		inspectedEntity_maxHealth="inspectedEntity_maxHealth";
		authentication_result="authentication_result";
		ok="ok";
		sim_start="sim-start";
		simulation_edges="simulation_edges";
		simulation_id="simulation_id";
		simulation_role="simulation_role";
		simulation_steps="simulation_steps";
		simulation_vertices="simulation_vertices";
		sim_end="sim-end";
		sim_result_ranking="sim-result_ranking";
		sim_result_score="sim-result_score";
		probe="probe";
		goto_="goto";
		successful="successful";
		
		normal="normal";
		disabled="disabled";
		name="name";
		energy="energy";
		health="health";
		max_energy="max_energy";
		max_health="max_health";
		position="position";
		strenth="strenth";
		vis_range="vis_range";
		team="team";
		role="role";
		status="status";
		node="node";
		edge="edge";
		agent="agent";
		hand="hand";
		A="A";
		B="B";
		k="k";
		check="check";
		edge_value="edge_value";
		surveyed_node="surveyed_node";
		sight="sight";
		noAction="noAction";
		Wang_Yuxin="Wang_Yuxin";
		recharge="recharge";
		attack="attack";
		repair="repair";
		inspect="inspect";
		skip="skip";
		
		battery="battery";
		sensor="sensor";
		shield="shield";
		sabotageDevice="sabotageDevice";
		buy="buy";
		wrongParameter="wrongParameter";
		failed_limit="failed_limit";
		failed_resources="failed_resources";
		failed_random="failed_random";
		failed_attacked="failed_attacked";
		failed_role="failed_role";
		failed_status="failed_status";
		failed_wrong_param="failed_wrong_param";
		
		parry="parry";
		useless="useless";
		
		mission_kuo="kuo";
		
		proxy="proxy";
		ip_port_file_name="./ini/ip_port.ini";
		
		mission_explorer_min_cost_visit_bound="_ev";
		mission_not_explorer_min_cost_visit_bound="nev";
	}
	
	~CC()
	{
		mode.clear();
		do_not_attack.clear();
	}
	
	int qj;
	int kuo01;
	
	string mission_not_explorer_min_cost_visit_bound;
	string mission_explorer_min_cost_visit_bound;
	
	bool log_on;
	
	string ip_port_file_name;
	string proxy;
	
	string mission_kuo;
	
	string parry;
	
	string useless;
	int use_clock;
	int use_tread_clock;
	string ip;
	vector<string> can_buy_role;
	string failed_random;
	string failed_attacked;
	string failed_resources;
	string failed_role;
	string failed_status;
	string failed_wrong_param;
	string failed_away;
	string failed_parry;
	string sentinel;
	
	string failed_limit;
	string wrongParameter;
	string buy;
	string battery;
	string sensor;
	string shield;
	string sabotageDevice;
	
	int debug_repairer;
	
	int agent_n;
	int debug;
	int debug_function_path;
	int port;
	
	vector<string> mode;
	vector<string> do_not_attack;	
	int clocksPerSecond;

	string skip;
	string inspect;
	string repair;
	string attack;
	string recharge;
	string Wang_Yuxin;
	string noAction;
	string sight;
	string surveyed_node;
	string edge_value;
	string check;
	string inspector;
	string k;
	string A;
	string B;
	string hand;
	string agent;
	string edge;
	string node;
	string alliance_mode;
	string repairer;
	string status;
	string role;
	string team;
	string vis_range;
	string strenth;
	string position;
	string max_health;
	string max_energy;
	string health;
	string energy;
	string name;
	string disabled;
	string normal;
	string saboteur;
	string explorer;
	string successful;
	string goto_;
	string probe;
	string sim_result_score;
	string sim_result_ranking;
	string sim_end;
	string sim_start;
	string simulation_edges;
	string simulation_id;
	string simulation_role;
	string simulation_steps;
	string simulation_vertices	;
	string ok;
	string authentication_result;
	string inspectedEntity_maxHealth;
	string visibleEdge_node1;
	string visibleEdge_node2;
	string deadline;
	string type;
	string timestamp;
	string request_action;
	
	string survey;
	
	string version;
	string encoding;
	string message_timestamp;
	string message_type;
	string perception_deadline;
	string perception_id;
	string simulation_step;
	string self_energy;
	string self_health;
	string self_lastAction;
	string self_lastActionParam;
	string self_lastActionResult;
	string self_maxEnergy;
	string self_maxEnergyDisabled;
	string self_maxHealth;
	string self_position;
	string self_strength;
	string self_visRange;
	string self_zoneScore;
	string team_lastStepScore;
	string team_money;
	string team_score;
	string team_zonesScore;
	string achievement_name;
	string visibleVertex_name;
	string visibleVertex_team;
	
	string visibleEntity_name;
	string visibleEntity_node;
	string visibleEntity_status;
	string visibleEntity_team;
	
	string probedVertex_name;
	string probedVertex_value;
	
	string surveyedEdge_node1;
	string surveyedEdge_node2;
	string surveyedEdge_weight;

	string inspectedEntity_energy;
	string inspectedEntity_health;
	string inspectedEntity_maxEnergy;
	string inspectedEntity_name;
	string inspectedEntity_node;
	string inspectedEntity_role;
	string inspectedEntity_strength;
	string inspectedEntity_team;
	string inspectedEntity_visRange;
}cc;
///D
struct D_system
{
	string file_name;
	
	void St(string x)
	{	
		file_name=x;
		FILE *F;
		F=fopen(file_name.c_str(),"w");
		if(F==0)
		{
			cout<<x<<endl;
			Error("eiworyh9w34");
		}			
		if(F!=0)fclose(F);
	}	
	
	void Wait_1_unit()
	{
		usleep(cc.clocksPerSecond);
	}
	void Clear_screan()
	{
		system("CLS");
	}
	/*
	void Pause()
	{
		char r[100];
		write("|> pause |> ");
		gets(r);		
		write("-----------------------------------------");
		write();
	}
	*/
	void Error(string r)
	{
		cout<<"[error] ["<<r<<"]"<<endl;
//		write("[error] [");
//		write(r);
//		writeln("]");
		exit(0);
	}
		
	
	void If_end()
	{
		FILE *F;
		string zs;
		
		F=fopen("WYX","r");
		if(fscanf(F,"%s",buff)==EOF)
		{
			fclose(F);
			return;
		}
		zs=buff;
		if(zs=="end" || zs=="re")
		{
			fclose(F);
			printf("Wang Yuxin order end\n");
			exit(0);
		}
	}
private:
/*
	void write()
	{
		FILE *F=fopen(file_name.c_str(),"a");
		fprintf(F,"\n");
		fclose(F);
	}*/
	/*
	void write(char r)
	{
		printf("%d",int(r));
		
		FILE *F=fopen("z.txt","a");
		fprintf(F,"%c",r);
		fclose(F);
	}
	
	void writeln(char r)
	{
		printf("%d\n",int(r));
		
		FILE *F=fopen("z.txt","a");
		fprintf(F,"%c\n",r);
		fclose(F);
	}
*//*
	void write(string a,int b)
	{
		write(a);
		write(b);
	}
	
	void writeln(string a,int b)
	{
		write(a,b);
		writeln();
	}
	
	void write(int a,string b)
	{
		write(a);
		write(b);
	}
	
	void writeln(int a,string b)
	{
		write(a,b);
		writeln();
	}
	
	void write(string r)
	{
		int i,n;
		n=r.length();
		for(i=0;i<n;i++)
		printf("%c",r[i]);
		
		FILE *F=fopen(file_name.c_str(),"a");		
		for(i=0;i<n;i++)
		fprintf(F,"%c",r[i]);
		fclose(F);
	}
	
	void writeln(string r)
	{
		int i,n;
		n=r.length();
		//for(i=0;i<n;i++)
		//printf("%c",r[i]);
		//printf("\n");
		
		FILE *F=fopen(file_name.c_str(),"a");		
		for(i=0;i<n;i++)
		fprintf(F,"%c",r[i]);
		fprintf(F,"\n");
		fclose(F);
	}
	
	void write(int r)
	{
		//printf("%d",r);
		
		FILE *F=fopen(file_name.c_str(),"a");
		fprintf(F,"%d",r);
		fclose(F);
	}
	
	void writeln(int r)
	{
		//printf("%d\n",r);
		
		FILE *F=fopen(file_name.c_str(),"a");
		fprintf(F,"%d\n",r);
		fclose(F);
	}
	
	void writeln()
	{
		writeln("");
	}*/
	
	char buff[1000];
}D;

struct Log
{
	string file_name;
	void Init(string x)
	{	
		file_name=x;
		
	}	
	
	void Clear()
	{
		FILE *F;
		F=fopen(file_name.c_str(),"w");
		if(F==0)
		{
				cout<<file_name<<endl;
				D.Error("45u45sisj");
		}
			
		if(F!=0)fclose(F);
	}
	

	void write()
	{
		//printf("\n");
		if(!cc.log_on)
			return ;
		
		FILE *F=fopen(file_name.c_str(),"a");
		fprintf(F,"\n");
		fclose(F);
	}
	/*
	void write(char r)
	{
		printf("%d",int(r));
		
		FILE *F=fopen("z.txt","a");
		fprintf(F,"%c",r);
		fclose(F);
	}
	
	void writeln(char r)
	{
		printf("%d\n",int(r));
		
		FILE *F=fopen("z.txt","a");
		fprintf(F,"%c\n",r);
		fclose(F);
	}
*/
	void write(string r)
	{
		if(!cc.log_on)
			return ;
		int i,n;
		n=r.length();
	//	for(i=0;i<n;i++)
	//	printf("%c",r[i]);
		
		FILE *F=fopen(file_name.c_str(),"a");		
		for(i=0;i<n;i++)
		fprintf(F,"%c",r[i]);
		fclose(F);
	}
	
	
	void writeln(string r)
	{
		if(!cc.log_on)
			return ;
		int i,n;
		n=r.length();
	//	for(i=0;i<n;i++)
	//	printf("%c",r[i]);
	//	printf("\n");
	
		///cout<<r<<endl;
		
		FILE *F=fopen(file_name.c_str(),"a");		
		for(i=0;i<n;i++)
		fprintf(F,"%c",r[i]);
		fprintf(F,"\n");
		fclose(F);
	}
	
	void writeln_chars(char r[],int rn)
	{
		if(!cc.log_on)
			return ;
		int i,n;		
		FILE *F=fopen(file_name.c_str(),"a");	
		for(i=0;i<rn;i++)	
		if(r[i])
		fprintf(F,"%c",r[i]);
		fprintf(F,"\n");
		fclose(F);
	}
	
	void write(int r)
	{
		if(!cc.log_on)
			return ;
	//	printf("%d",r);
		
		FILE *F=fopen(file_name.c_str(),"a");
		fprintf(F,"%d",r);
		fclose(F);
	}
	
	void writeln(int r)
	{
		if(!cc.log_on)
			return ;
	//	printf("%d\n",r);
		
		FILE *F=fopen(file_name.c_str(),"a");
		fprintf(F,"%d\n",r);
		fclose(F);
	}
};

class D_file
{
public:
	void Init(string x)
	{
		file_name=x;
		last_pos=0;
	//	Clear();
	}
	
	int Read_file(string file_name,vector<string> &d)	
	{		
		FILE *F;
		int i;
		
		d.clear();
		
		F=Open(file_name,"r");
//		for(i=0;i<file_last_read_line;i++)Read_line(F,buff);
		while(1)
		{
			Read_line(F,buff);
			if(buff[0])
			{
		//		file_last_read_line++;
			}
			else break;
			d.push_back(buff);
		}
		fclose(F);
		return d.size();
	}
	
	void Read(vector<string> &A,vector<int> &B)	
	{		
		FILE *F;
		int i;
		int z;
		
		A.clear();
		B.clear();
		
		F=Open("r");
//		for(i=0;i<file_last_read_line;i++)Read_line(F,buff);
		while(1)
		{
			if(fscanf(F,"%s%d",buff,&z)==EOF)break;
			A.push_back(buff);
			B.push_back(z);
		}
		fclose(F);
		return ;
	}
	
	int Read(vector<string> &d)	
	{		
		FILE *F;
		int i;
		
		d.clear();
		
		F=Open("r");
//		for(i=0;i<file_last_read_line;i++)Read_line(F,buff);
		while(1)
		{
			Read_line(F,buff);
			if(buff[0])
			{
		//		file_last_read_line++;
			}
			else break;
			d.push_back(buff);
		}
		fclose(F);
		return d.size();
	}
	
	int Read_a_block_from_last_position(vector<string> &d)	
	{		
		FILE *F;
		int i;
		string zs;
		
		d.clear();
		
		F=Open("r");
		fseek(F,last_pos,SEEK_SET);
//		for(i=0;i<file_last_read_line;i++)Read_line(F,buff);
		pre_last_pos=last_pos;
		Read_block_head(F);

		while(1)
		{
			if(!Read_line(F,buff))break;;
			zs=buff;
			if(zs=="]")
				break;
			d.push_back(zs);
		}
		fclose(F);
		return d.size();
	}
	
	void Un_read_a_block()	
	{
		last_pos=pre_last_pos;
	}
	/*
	int No_block_after_last_position()
	{
		FILE *F;
		int i;
		string zs;
				
		F=Open("r");
		fseek(F,last_pos,SEEK_SET);
			
		if(fscanf(F,"%s",buff)==EOF)
		{			
			fclose(F);
			return 1;
		}
			
		zs=buff;
		if(zs=="[")
		{
			fclose(F);
			return 0;
		}
		D.Error("jts8ey89ysag");	
		fclose(F);
	}
	*/
	int Have_a_block_from_last_position()
	{
		FILE *F;
		int i;
		string zs;
				
		F=Open("r");
		fseek(F,last_pos,SEEK_SET);
			
		if(fscanf(F,"%s",buff)==EOF)
		{			
			fclose(F);
			return 0;
		}
			
		zs=buff;
		if(zs=="[")
		{
		}
		else
			D.Error("jts8ey89ysag");
		
		while(fscanf(F,"%s",buff)!=EOF)
		{			
			zs=buff;
			if(zs=="]")
				return 1;
		}	
		fclose(F);
		return 0;
	}
	
	
	int Have_two_block_from_last_position()
	{
		FILE *F;
		int i;
		string zs;
				
		F=Open("r");
		fseek(F,last_pos,SEEK_SET);
			
		if(fscanf(F,"%s",buff)==EOF)
		{			
			fclose(F);
			return 0;
		}
			
		zs=buff;
		if(zs=="[")
		{
		}
		else
			D.Error("jts8ey89ysag");
		
		while(fscanf(F,"%s",buff)!=EOF)
		{			
			zs=buff;
			if(zs=="]")
				break;
		}	
		
		
		if(fscanf(F,"%s",buff)==EOF)
		{			
			fclose(F);
			return 0;
		}
			
		zs=buff;
		if(zs=="[")
		{
		}
		else
			D.Error("jts8ey89ysag");
		
		while(fscanf(F,"%s",buff)!=EOF)
		{			
			zs=buff;
			if(zs=="]")
				return 1;
		}	
		fclose(F);
		return 0;
	}
	
	int Read_block_head(FILE *F)
	{
		Read_line(F,buff);
		string zs=buff;
		if(zs=="")return 0;
		if(zs!="[")
			D.Error("gfrehgsrha");
		
		return 1;		
	}
	
	int Read_from_last_position(vector<string> &d)	
	{		
		FILE *F;
		int i;
		
		d.clear();
		
		F=Open("r");
		fseek(F,last_pos,SEEK_SET);
		
//		for(i=0;i<file_last_read_line;i++)Read_line(F,buff);
		while(1)
		{
			Read_line(F,buff);
			if(buff[0])
			{
		//		file_last_read_line++;
			}
			else break;
			d.push_back(buff);
		}
		fclose(F);
		return d.size();
	}
	
	
	
	void Writeln(string pa,string r)
	{
		FILE *F=Open(file_name.c_str(),pa.c_str());
		fprintf(F,"%s\n",r.c_str());
		fclose(F);
	}
	
	void Writeln_file(string file_name,string pa,int r)
	{
		FILE *F=Open(file_name.c_str(),pa.c_str());
		fprintf(F,"%d\n",r);
		fclose(F);
	}
	
	void Block_writeln(vector<string> &r,string pa)
	{
		int i;
		FILE *F=Open(file_name.c_str(),pa.c_str());
		fprintf(F,"[\n");		
		for(i=0;i<r.size();i++)
		{
			fprintf(F,"%s\n",r[i].c_str());
		}
		
//		fprintf(F,"\n");
		fprintf(F,"]\n");
		fclose(F);
	}
	
	void Writeln2(vector<string> &r,string pa)
	{
		int i;
		FILE *F=Open(file_name.c_str(),pa.c_str());
		for(i=0;i<r.size();i++)
		{
			fprintf(F,"%s\n",r[i].c_str());
		}
		
		fprintf(F,"\n");
		fclose(F);
	}
	
	void Clear()
	{
		FILE *F=Open(file_name,"w");		
		fclose(F);
	}
	
	void Clear(string file_name)
	{
		FILE *F=Open(file_name.c_str(),"w");		
		fclose(F);
	}
private:
	void DelLn(char r[])
	{
		int i;
		for(i=0;r[i] && r[i]!='\n';i++);
		r[i]=0;
	}
		
		
	int Read_line(FILE *F,char buff[])
	{
	//	while(1)
		{
			ts++;
			buff[0]=0;
			if(fgets(buff,oo,F)==0)return 0;
		
			last_pos+=strlen(buff);
			DelLn(buff);
		//	if(buff[0]==0)continue;
			return 1;
		}
	}
	
	FILE* Open(string file_name,string m)
	{
		FILE *F;
		while(1)
		{
			D.If_end();
			
			F=fopen(file_name.c_str(),m.c_str());
			if(F!=0)return F;
			D.Wait_1_unit();
		}
	}
	
	FILE* Open(string m)
	{
		FILE *F;
		while(1)
		{
			D.If_end();
				
			F=fopen(file_name.c_str(),m.c_str());
			if(F!=0)return F;
			D.Wait_1_unit();
		}
	}
	
	char buff[1000];
	string file_name;
	int pre_last_pos;
	int last_pos;
}d_file;

///S
struct String
{
	bool Add_until_0(char a[],int &an,char b[],int &bn)
	{
		int i,j;
		int s0=0;
		
		for(i=0;i<bn;i++)
		{
			a[an++]=b[i];
			b[i]=0;
		}		
		bn=0;
		
		for(i=0;i<an;i++)
		{
			if(a[i]==0)
			{
				s0++;
				if(s0)break;
			}
		}
		if(s0<1)return 0;
		
		for(j=i+1;j<an;j++)
		{
			b[bn++]=a[j];
			a[j]=0;
		}
		an=i;
		return 1;
	}
	
	
	char Last_zi_fu(char r[],int n)
	{
		int i;
		for(i=n-1;i>=0;i--)
			if(Is_zi_fu(r[i]))break;
		if(i<0)
			D.Error("jiewhsap94g");
		return r[i];
	}
	/*
	void Just_leave_zi_fu(char r[],int &n)
	{
		int i;
		n=0;
		for(i=0;r[i];i++)
		if(Is_zi_fu(r[i]))r[n++]=r[i];		
		r[n]=0;
		for(;i>n;i--)
		r[i]=0;
		//cout<<"["<<r<<"]"<<endl;
	}
	*/
	bool Is_zi_fu(char r)
	{
		return r==' ' || r>=33 && r<=126;
	}
	int String_to_int(string r)
	{
		int i,ret=0,n=r.length();
		for(i=0;i<n;i++)ret=ret*10+r[i]-'0';
		return ret;
	}
	void Reverse(string &r)
	{
		string ret;
		int i,n;
				
		ret="";
		n=r.length();
		for(i=0;i<n;i++)ret=r[i]+ret;
		
		r=ret;
	}
	string Int_to_string(int x)
	{
		string ret="";
		if(x==0)return "0";
		if(x<0)return '-'+Int_to_string(-x);
		
		while(x)
		{
			ret=char(x%10+'0')+ret;
			x/=10;
		}
		return ret;
	}
	
	
	string Del_lead_space(string r)
	{
		int i;
		string ret="";
		int n=r.length();
		for(i=0;i<n && r[i]==' ';i++);
		for(;i<n;i++)ret+=r[i];
		
		return ret;
	}
	
	string Join_continue_space(string r)
	{
		int i;
		string ret="";
		int n=r.length();
		
		for(i=0;i<n;i++)
			if(i==0) ret=ret+r[i];
			else if(! (r[i]==' ' && r[i-1]==' ') )ret=ret+r[i];
			
		return ret;
	}
	
	void String_to(string r,string &d1,int &d2,int &d3,int &d4)
	{
		sscanf(r.c_str(),"%s %d %d %d",buff,&d2,&d3,&d4);
		d1=buff;	
	}
	
	
	
	string Segment(string r,int x)
	{
		r=Del_lead_space(r);
		r=Join_continue_space(r);
				
		string ret="";
		int n=r.length(),i,z;
		
		z=0;
		for(i=0;i<x-1;i++)
		{
			for(;z<n && r[z]!=' ';z++);
			z++;
		}
		if(z>=n)
			D.Error("oijwds8yp9ahio");
		
		for(;z<n && r[z]!=' ';z++)ret=ret+r[z];
		
		return ret;
	}
	
	int Find_chs_chs(char ra[],char rb[])
	{
		int a,b,z;
		for(a=0;ra[a];a++)
		{
			z=0;
			for(b=0;rb[b];b++)
			if(ra[a+b]!=rb[b])
			{
				z=1;
				break;
			}
			if(!z)return a;
		}
		return -1;
	}
	
	int Find(char r[],char x)
	{
		return Find(r,0,x);
	}
	
	int Find(char r[],int xi,char x)
	{
		int i,n;
		n=strlen(r);
		for(i=xi;i<n;i++)
		if(r[i]==x)return i;
		return -1;
	}
	
	
	int Find_last_before(string &r,int ri,char x)
	{
		int i,n;
		n=r.length();
		ri=min(ri,n);
		for(i=ri;i>=0;i--)
		if(r[i]==x)return i;
		return -1;
	}
	
	int Find(string &r,int xi,string x)
	{
		int i,j,rn,xn,flag;
		rn=r.length();
		xn=x.length();
		
		for(i=0;i+xn<=rn;i++)
		{
			flag=0;
			for(j=0;j<xn;j++)
			if(r[i+j]!=x[j])
			{
				flag=1;
				break;
			}
			if(!flag)return i;
		}
		return -1;
	}
	
	int Find_next_string(vector<string> &r,string x,string &ret)
	{
		int i;
		for(i=0;i<r.size();i+=2)
		if(r[i]==x)
		{
			if(i+1>=r.size())return 0;
			ret = r[i+1];
			return 1;
		}
		return 0;
	}
	
	string Delete(string r,int a,int b)
	{
		int i,n;
		string ret="";
		n=r.length();
		for(i=0;i<n && i<a;i++)
			ret+=r[i];
		for(i=b+1;i<n;i++)
			ret+=r[i];		
		return ret;
	}
	
	string Delete_all(string r,char x)
	{
		string ret;
		int n,i;
		
		ret="";
		n=r.length();
		for(i=0;i<n;i++)
		if(r[i]!=x)ret+=r[i];
		
		return ret;
	}
	
	string Sub_string(string r,int a,int b)
	{
		string ret;
		int i;
		if(a<0 || b<0 || a>r.length() || b>r.length())
		{
			D.Error("erohua38y78943q");
		}
			
		ret="";
		for(i=a;i<=b;i++)
			ret+=r[i];
		
		return ret;
	}	
	
	bool Same(string a,int ai,string b)
	{
		int bi,an,bn;
		an=a.length();
		bn=b.length();
		if(ai+bn>an)return 0;
		for(bi=0;bi<bn;ai++,bi++)
		if(a[ai]!=b[bi])return 0;
		return 1;		
	}
	
	void Splite(string r,vector<string> &d)
	{
		int i,n;
		string zs;
		
		n=r.length();
		d.clear();
		if(r=="")return;
		i=0;
		while(1)
		{
			zs="";
			for(;i<n;i++)
			{
				if(r[i]==' ')break;
				zs+=r[i];
			}			
			i++;
			
			if(zs=="")
			{	
				D.Error("gaeiorhuy9w84uyw");
			}
			d.push_back(zs);
			if(i>=n)break;			
		}		
	}
	char buff[1000];
}str;


class D_stack
{
public:
	void Leave_top(stack<int>& r)
	{
		//cout<<"Leave_top(stack<int>& r)  1"<<endl;
		int z;
		if(!r.size())return;
		z=r.top();
		while(r.size())r.pop();
		r.push(z);
		//cout<<"Leave_top(stack<int>& r) 2"<<endl;
	}
	
	stack<int> Empty_stack()
	{
		stack<int> ret;
		Clear(ret);
		return ret;
	}
	
	void Clear(stack<int> &r)
	{
		while(r.size())r.pop();
	}
	
	void Write(stack<int> x)
	{
		stack<int> r;
		r=x;
		
		while(r.size())
		{
			r.pop();			
		}
	}
private:
}d_stack;

class D_vector
{
public:
	bool Find(vector<string> &r,string x)
	{
		int i;
		for(i=0;i<r.size();i++)
		if(r[i]==x)return 1;
		return 0;
	}
	
	bool Find(vector<int> &r,int x)
	{
		int i;
		for(i=0;i<r.size();i++)
		if(r[i]==x)return 1;
		return 0;
	}
private:
}d_vector;

class D_queue
{
public:
	void Clear(queue<bool> &r)
	{
		while(r.size())r.pop();
	}
	
	void Clear(queue<int> &r)
	{
		while(r.size())r.pop();
	}
private:	
}d_queue;



struct tim
{
	int tv_sec ;
    int tv_usec;
};

//N
struct Net
{
	Log *log;
	int                  s;//创建套结字
	struct   sockaddr_in    ServerAddr;
	string ip;
	int Port;
	int st(string ip,int Port)
	{	
		//cout<<ip<< ' '<<Port<<endl;
		//while(1);
		this->ip=ip;
		this->Port=Port;
		s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);//创建一个套节字
		if(s==-1)
		{
      		puts("socket failed with error \n");
      		return 0;
   		} 
		ServerAddr.sin_family = AF_INET;
		ServerAddr.sin_port =htons(Port);    
		ServerAddr.sin_addr.s_addr = inet_addr(ip.c_str());//服务器地址IP
			
		cout<<"We are trying to connect to "<<inet_ntoa(ServerAddr.sin_addr)<<":"<<(ntohs(ServerAddr.sin_port))<<"...\n";

		if(connect(s, (   sockaddr *) &ServerAddr, sizeof(ServerAddr)) == -1)//连接到服务器
		{
			cout<<"Connect failed!\n";
			return 0;
		}
		cout<<"Our connection succeeded.\n";
		return 1;
	}
	
			
	bool Listen(char ret[],int len,int &ret_n,string agent_name,int &ready,Log *msg_file)
	{
		//log=x;
		int i;
		int n;
		//for(i=0;i<len;i++)
		//	ret[i]=0;
		//ret[0]=0;
		ready=1;
		while(1)
		{
			int z=recv(s, ret+ret_n, len-ret_n, 0);	
			if(z<=0)
			{
				///cout<<"[[[[[[[[[[[[["<<ret<<"]]]]]]]]]]]"<<endl;
				cout<<"z<=0 "<<z<<endl;
				continue;
				exit(0);
			}
					
			//msg_file->writeln(z);
			//msg_file->writeln_chars(ret+ret_n,z);
			ret_n+=z;
			//cout<<agent_name<<' '<<z<<' '<<int(ret[z-1])<<endl;
			return 1;
		}	
		return 1;
	}

	string Send(string r)
	{
		r+='\0';
		//AddLn(r);
		while(1)
		{
			int z=send(s, r.c_str(), r.length(), 0);						
			if(z<=0)
			{
				continue;	
			}
			break;						
		}
		return "";
	}
	
	~Net()
	{
		close(s);
	}
};




class My_vector
{
public:
	bool find(vector<string> &r,string x)
	{
		int i;
		for(i=0;i<r.size();i++)
		if(r[i]==x)return 1;
		return 0;
	}
	
	void Del(vector<string> &r,int x)
	{
		vector<string>::iterator it;
		int i;
		for(i=0,it=r.begin();i<r.size() && i<x;i++,it++);
		if(i==x)r.erase(it);		
	}
private:
}my_vector;

///p
class Protocol
{
public:
	string order_short;
	void Init(Net &x,Log &log)
	{
		net=&x;
		D=&log;
		order="";
		order_short="";
	}
	
	void Buy_battery()
	{
		if(cc.debug_function_path)
		{
			D->write("---------------- protocl Buy_battery() ");
		}
	
		string head="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
		
		order="<message type=\"action\"><action id=\"";
		order+=str.Int_to_string(id);
		order+="\" type=\"buy\" ";
		order+="param=\"";
		order+=cc.battery;
		order+="\"";
		order+="/></message>";
		order=head+order;
		order_short="Buy_battery";
	}
	
	void Buy_sensor()
	{
		if(cc.debug_function_path)
		{
			D->write("---------------- protocl Buy_sensor");	
		}
	
		string head="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
		
		order="<message type=\"action\"><action id=\"";
		order+=str.Int_to_string(id);
		order+="\" type=\"buy\" ";
		order+="param=\"";
		order+=cc.sensor;
		order+="\"";
		order+="/></message>";
		order=head+order;
		order_short="Buy_sensor";
	}
	
	void Buy_shield()
	{
		if(cc.debug_function_path)
		{
			D->write("---------------- protocl Buy_shield");
		}
	
		string head="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
		
		order="<message type=\"action\"><action id=\"";
		order+=str.Int_to_string(id);
		order+="\" type=\"buy\" ";
		order+="param=\"";
		order+=cc.shield;
		order+="\"";
		order+="/></message>";
		order=head+order;
		order_short="Buy_shield";
	}
	
	void Buy_sabotageDevice()
	{
		if(cc.debug_function_path)
		{
			D->write("---------------- protocl Buy_sabotageDevice");
		}
	
		string zs;
		string head="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
		
		order="<message type=\"action\"><action id=\"";
		order+=str.Int_to_string(id);
		order+="\" type=\"buy\" ";
		order+="param=\"";
		order+=cc.sabotageDevice;
		order+="\"";
		order+="/></message>";
		order=head+order;
		order_short="Buy_sabotageDevice";
	}
	
	
	void Repair(string param)
	{
		if(cc.debug_function_path)
		{
			D->write("---------------- protocl Repair ");
			D->writeln(param);
		}
	
		string zs;
		string head="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
		
		order="<message type=\"action\"><action id=\"";
		order+=str.Int_to_string(id);
		order+="\" type=\"repair\" ";
		order+="param=\"";
		order+=param;
		order+="\"";
		order+="/></message>";
		order=head+order;
		order_short="Repair "+param;
	}
	
	void Goto(string param)
	{
		if(cc.debug_function_path)
		{
			D->write("---------------- protocl Goto ");
			D->writeln(param);
		}
	
		string head="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
		
		order="<message type=\"action\"><action id=\"";
		order+=str.Int_to_string(id);
		order+="\" type=\"goto\" ";
		order+="param=\"";
		order+=param;
		order+="\"";
		order+="/></message>";
		order=head+order;
		order_short="Goto "+param;
	}
	
	void Attack(string param)
	{
		if(cc.debug_function_path)
		{
			D->write("---------------- protocl Attack ");
			D->writeln(param);			
		}
	
		string head="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
		
		order="<message type=\"action\"><action id=\"";
		order+=str.Int_to_string(id);
		order+="\" type=\"attack\" ";
		order+="param=\"";
		order+=param;
		order+="\"";
		order+="/></message>";
		order=head+order;
		order_short="Attack "+param;
	}
	
	

	void Parry()
	{
		if(cc.debug_function_path)
			D->writeln("---------------- protocl Parry ");
	
		string head="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
		
		order="<message type=\"action\"><action id=\"";
		order+=str.Int_to_string(id);
		order+="\" type=\"";
		order+=cc.parry;
		order+="\"/></message>";
		order=head+order;
		order_short="Parry";
	}
	
	void Survey()
	{
		if(cc.debug_function_path)
			D->writeln("---------------- protocl Survey ");
	
		string head="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
		
		order="<message type=\"action\"><action id=\"";
		order+=str.Int_to_string(id);
		order+="\" type=\"";
		order+=cc.survey;
		order+="\"/></message>";
		order=head+order;
		order_short="Survey";
	}
	
	void Inspect()
	{
		if(cc.debug_function_path)
			D->writeln("---------------- protocl Inspect ");
	
		string head="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
		
		order="<message type=\"action\"><action id=\"";
		order+=str.Int_to_string(id);
		order+="\" type=\"inspect\"/></message>";
		order=head+order;
		order_short="Inspect";
	}
	
	void Recharge()
	{
		if(cc.debug_function_path)
			D->writeln("---------------- protocl Recharge ");
	
		string head="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
		
		order="<message type=\"action\"><action id=\"";
		order+=str.Int_to_string(id);
		order+="\" type=\"recharge\"/></message>";
		order=head+order;
		order_short="Recharge";
	}
	
	void Probe()
	{
		if(cc.debug_function_path)
			D->writeln("---------------- protocl Probe ");

		string head="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
		
		order="<message type=\"action\"><action id=\"";
		order+=str.Int_to_string(id);
		order+="\" type=\"probe\"/></message>";
		order=head+order;
		order_short="Probe";
	}
	
	void Skip()
	{
		if(cc.debug_function_path)
			D->writeln("---------------- protocl Skip ");
	
		string head="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
		
		order="<message type=\"action\"><action id=\"";
		order+=str.Int_to_string(id);
		order+="\" type=\"skip\"/></message>";
		order=head+order;
		order_short="Skip";
	}		
	
	void Auth_request(string username,string password)
	{
		string head="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
		
		order="<message type=\"auth-request\"><authentication password=\"";
		order+=password;
		order+="\" username=\"";
		order+=username;
		order+="\"/></message>";
		order=head+order;
	}
	
	void Send_order()
	{
		if(order=="")
			return;
		net->Send(order);
		order="";
		order_short="";
	}
	
	bool Have_order()
	{
		return order!="";
	}
	
	void Set_id(int id)
	{
		this->id=id;
	}
	
	int Get_id()
	{
		return id;
	}
private:
	int id;
	Net *net;
	Log *D;
	string order;
};

string buffer;


///x
class XML
{
public:
	void Init(char r[],int rn)
	{
		//cout<<"-----------------Init(string r)1"<<endl;
		//cout<<r<<endl;
		int i;				
		na=0;
		nb=rn;
		Delete_between(r,'?');		
		Delete_empty_pair(r,'<','>');
		
		for(i=na;i<nb;i++)
			f[i]=0;	
		
		//cout<<r<<endl;
		Calc_f(r);
		Init(r,na,nb,f);
	}	
	
	void Init(char r[],int na_x,int nb_x,int f_x[])
	{
		int z,ra,rb,i,j;
		string zs;
		
		f=f_x;
		
		na=na_x;
		nb=nb_x;
				
		
		son.clear();
		A.clear();
		B.clear();
		
		{
			for(ra=na;ra<nb;ra++)
				if(r[ra]=='<')break;
				
				
			if(ra<0)
				D.Error("gah0weyta843y3");
		
			for(i=ra+1;i<nb;i++)
			if(r[i]!=' ')break;
			
			for(zs="";i<nb && r[i]!=' ' && r[i]!='/' && r[i]!='=' && r[i]!='>';i++)
				zs=zs+r[i];
			
			name=zs;
			Delete_last_end(r);			
		}
				
		
		for(rb=ra;rb<nb;rb++)
		if(r[rb]=='>')break;
		
		for(i=ra;i<rb;i++)
		if(r[i]=='=')
		{
			zs="";
			for(j=i-1;j>=0;j--)
			if(r[j]!=' ')break;
			
			for(;j>=0 && r[j]!=' ' && r[j]!='<' && r[j]!='"';j--)
				zs=r[j]+zs;			
			A.push_back(zs);
			
			for(j=i+1;j<nb;j++)
			if(r[j]=='"')break;
			
			zs="";
			
			for(j=j+1;j<nb && r[j]!='"';j++)
				zs=zs+r[j];
				
			B.push_back(zs);
		}		
		
		
		while(1)
		{
			ra=rb+1;
			for(;ra<nb && r[ra]!='<';ra++);
			if(ra>=nb)break;
		
			rb=f[ra];
					
			
			XML Z;			
			son.push_back(Z);
			son[son.size()-1].Init(r,ra,rb+1,f);
		}
	}
	
	

	void To_vector(char r[],int rn,vector<string> &ret,int tmp[])
	{
		//log.writeln("----------- XML To_vector(char r[],vector<string> &ret,int tmp[])" 1);
		f=tmp;
		Init(r,rn);
		ret.clear();
		To_vector(ret);
		//log.writeln("----------- XML To_vector(char r[],vector<string> &ret,int tmp[])" 2);
	}
	
	void To_vector(vector<string> &d,int deep=0)
	{
		int i;
		if(!deep)
			d.clear();
		
		for(i=0;i<A.size();i++)
		{
			d.push_back(name+'_'+A[i]);
			d.push_back(B[i]);
		}
		
		for(i=0;i<son.size();i++)
		son[i].To_vector(d,deep+1);
	}

	~XML()
	{
		A.clear();
		B.clear();
		son.clear();
	}
private:
	void Calc_f(char r[])
	{	
		int i;
		int ra=0,rb=-1;
		int a;
		int z;
		stack<int> S;
		while(S.size())
			S.pop();
			
		while(1)
		{
			ra=rb+1;
			for(;ra<nb && r[ra]!='<';ra++);
			if(ra>=nb)break;
			S.push(ra);
			
			z=1;
			for(rb=ra+1;rb<nb;rb++)
			if(r[rb]=='<')
			{
				a=rb;
				for(rb=rb+1;rb<nb;rb++)
				if(r[rb]!=' ')break;
				if(r[rb]=='/')
				{
					rb--;
					continue;
				}
				S.push(a);
				z++;
			}
			else if(r[rb]=='/')
			{
				z--;
				for(;rb<nb;rb++)
				if(r[rb]=='>')
					break;
					
				f[S.top()]=rb;
				S.pop();
									
				if(z==0)
					break;
			}			
		}
		if(S.size())
		{
			cout<<r<<endl;
			D.Error("oiwhy4390ay");
		}
		
	}
/*
	string Delete_after_last_message(string r)
	{
		string ret;		
		int flag=0;
		
		int n=r.length(),i,j;
		for(i=0;i<n;i++)
		if(str.Same(r,i,"</message>"))
		{			
			flag=1;
			ret="";
			for(j=0;j<i+10;j++)ret+=r[j];
			
			return ret;			
		}
		return r;
	}
	*/
	void Delete_last_end(char r[])
	{
		string ret;		
		int i;
		
		for(i=nb-1;i>=0;i--)
		if(r[i]=='/')break;
		
		for(i=i-1;i>=0;i--)
		if(r[i]!=' ')break;
		
		if(r[i]!='<')return;
		
		for(i=i-1;i>=0;i--)
		if(r[i]!=' ')break;
		
		nb=i+1;
		r[nb]=0;
	}

	string Delete_between(char r[],char x)
	{
		int a,b;
		int i;
		
		while(1)
		{
			a=str.Find(r,0,x);
			if(a<0)return r;
			
			b=str.Find(r,a+1,x);
		
			
		
			if(a>=nb || b>=nb || b<0 || a>=b)
			D.Error("hga38498uy4y");
			
			for(i=a;i<=b;i++)r[i]=' ';
		}		
		
		D.Error("arehaerai4y");
	}
	
	string Delete_empty_pair(char r[],char xa,char xb)
	{
		int z=0,a,b,flag,i;
		while(1)
		{
			a=str.Find(r,z,xa);
			b=str.Find(r,z,xb);
			if(a<0)return r;
			
			flag=0;
			for(i=a+1;i<b;i++)
			if(r[i]!=' ')
			{
				flag=1;
				break;
			}
			
			if(!flag)
			for(i=a;i<=b;i++)
				r[i]=' ';
			else z=b+1;
		}
		
		D.Error("ag933ay4y");
	}
	
	int na,nb;
	int *f;
	string name;
	vector<string> A;
	vector<string> B;
	vector<XML> son;
};

class Node;
vector<Node> node;
///n
class Node
{
public:
	Node()
	{
		Init();
	}
	
	
	void Init()
	{
		n=0;
		edge_id.clear();
		edge.resize(1);
		edge_is_surveyed.resize(1);
		edge_value.resize(1);
		
		is_probed=0;
		value=1;
		visited=0;
		surveyed_n=0;
		is_surveyed=0;
	}
	
	bool Have_edge(int b)
	{
		if(edge_id[b])return 1;
		return 0;
	}
	
	void Add_edge(int b)
	{
		if(edge_id[b])return;	
		n++;
		edge_id[b]=n;	
		edge.push_back(b);
		
		
		
		edge_is_surveyed.push_back(0);
		edge_value.push_back(-1);
	}
	
	bool Edge_is_surveyed(int b)
	{	
		b=edge_id[b];
		if(!b)return 0;
		if(!edge_is_surveyed[b])return 0;
		return 1;
	}
	
	
	void Add_surveyed_edge(int b,int d)
	{			
		if(!edge_id[b])
		{
			D.Error("09it409juj;oiser");
		}
		
		b=edge_id[b];
		if(!b)D.Error("09it409juj;oiser");
		if(edge_is_surveyed[b])
		{
			if(edge_value[b]<0)D.Error("8349y4qy");
			if(edge_value[b]!=d)D.Error("hifg9u8348");
			return;
		}
		//surveyed_n++;
		
		surveyed_n++;
		edge_is_surveyed[b]=1;
		edge_value[b]=d;
	}
	
	void Set_value(int a,int x)
	{
		is_probed=1;
		value=x;
	}
	
	bool Have_surveyed_neighbour(vector<Node> &node)
	{
		int i,z;
		for(i=1;i<=n;i++)
		{
			z=edge[i];
			if(node[z].is_surveyed)return 1;
		}
		return 0;
	}
	
	/*bool All_edge_surveyed()
	{
		int i;
		return surveyed_n==n;
		
		for(i=1;i<=n;i++)
		if(!edge_is_surveyed[i])return 0;
		return 1;
	}*/
	
	~Node()
	{
		edge_id.clear();
		edge.clear();
		edge_is_surveyed.clear();
		edge_value.clear();
	}
	
	map<int,int> edge_id;
	vector<int> edge;
	vector<bool> edge_is_surveyed;
	vector<int> edge_value;
	
	int n;
	bool is_probed;
	int value;
	int visited;
	int surveyed_n;
	bool is_surveyed;
	//tmp
	int v;
	int bound;
	int dis;
	bool can_kuo;
	bool can_visit[20];
	bool can_visit_through_surveyed_node[20];
	int xu;
	bool ev;
	int value_for_agent[20];
	int fu_gai;
	bool yao;
};

class Name
{
public:
	Name()
	{
		Init();
	}
	
	void Init()
	{
		a.clear();
		b.clear();
		n=0;
	}
	
	bool Have_name(string r)
	{
		if(a[r])return 1;
		return 0;
	}
	
	int String_to_int(string r)
	{
		if(a[r])return a[r];
		a[r]=n+1;
		n++;
		b.push_back(r);
		
		Node Z;
		Z.Init();
		node.push_back(Z);
		return n;
	}
	
	string Int_to_string(int r)
	{
		if(r==0)
			D.Error("g834hy98w34yh");
		if(r<=b.size())return b[r-1];
		cout<<r<<' '<<b.size()<<endl;
		D.Error("jgoesur0ya3ay");
	}
	
	int Get_n()
	{
		return n;
	}
	
	~Name()
	{
		a.clear();
		b.clear();		
	}
private:
	map<string,int> a;
	vector<string> b;
	int n;
}name;

///e
class Enermy_agent
{
public:
	int perception_id;
	bool is_useless_parryed;
	bool is_inspected;
	int inspect_time_id;
	string name;
	int energy;
	int health;
	int maxEnergy;
	int maxHealth;
	string role;
	int strength;
	string team;
	int visRange;
	
	void Writeln()
	{
		cout<<"enermy agemt : "<<name<<" "<<status<<' '<<status_time_id<<' '<<node<<' '<<node_time_id<<endl;
	}
	
	void Update_node(string a,int b)
	{
		node=a;
		node_time_id=b;
	}
	
	void Update_status(string a,int b)
	{
		status=a;
		status_time_id=b;
	}
	
	bool Node_is(string a,int b)
	{
		return node==a && node_time_id==b;
	}
	
	bool Status_is(string a,int b)
	{
		return status==a && status_time_id==b;
	}
	
	bool Status_now_is(string a)
	{
		return Status_is(a,perception_id);
	}
	
	bool Get_node(string &a,int b)
	{
		if(b!=node_time_id)return 0;
		a=node;
		return 1;
	}
	
	bool Last_known_position(string &ret)
	{
		if(node=="")return 0;
		ret=node;		
		return 1;
	}
	
	bool Last_known_status_is(string x)
	{
		return status==x;
	}
			
	Enermy_agent()
	{
		Init();
	}
	
	void Init()
	{
		is_inspected=0;
		role="";
		node="";
		status="";
		inspect_time_id=status_time_id=node_time_id=-1;
		is_useless_parryed=0;
	}	
	
private:		
	string node;
	string status;
	int status_time_id;
	int node_time_id;
};
vector<Enermy_agent> enermy_agent,last_time_enermy_agent;

class Enermy_agent_name
{
public:
	Enermy_agent_name()
	{
		Init();
	}
	
	void Init()
	{
		a.clear();
		b.clear();
		n=0;
	}
	
	bool Have_name(string r)
	{
		if(a[r])return 1;
		return 0;
	}
	
	int String_to_int(string r)
	{
		if(a[r])return a[r]-1;
		a[r]=n+1;
		n++;
		b.push_back(r);
		
		Enermy_agent Z;
		Z.Init();
		enermy_agent.push_back(Z);
		return n-1;
	}
	
	string Int_to_string(int r)
	{
		if(r<b.size())return b[r];
		cout<<r<<' '<<b.size();
		D.Error("34y08j'hreau5");
	}
	
	int Get_n()
	{
		return n;
	}
	
	~Enermy_agent_name()
	{
		a.clear();
		b.clear();		
	}
private:
	map<string,int> a;
	vector<string> b;
	int n;
}enermy_agent_name;



class Maximum_cost_perfect_matching
{
public:
	void Run(vector<int> agent_i,vector<Node> &node,vector<int> &ret)
	{
		int i,j;
		nx=name.Get_n();
		ny=agent_i.size();
		
		ret.resize(ny);
		
		for(i=1;i<=nx;i++)
			node[i].v=0;
			
	/*	for(j=0;j<ny;j++)
		{
			for(i=1;i<=nx;i++)
			if(node[i].value_for_agent[agent_i[j]]<oo)
			cout<<i<<' '<<name.Int_to_string(i)<<' '<<j<<' '<<agent_i[j]<<' '<<node[i].value_for_agent[j]<<endl;
		}*/
		for(j=0;j<ny;j++)
		ret[j]=-1;
		/*
		for(j=0;j<ny;j++)
		{
			for(i=1;i<=nx;i++)
			if(!node[i].v && node[i].value_for_agent[agent_i[j]]==0)
			if(ret[j]<0)
			{
				ret[j]=i;
				break;
			}
			if(ret[j]>=0)
			{
				node[ret[j]].v=1;				
			}
		}
		
		for(i=0;i<ny;i++)
		for(j=i+1;j<ny;j++)
		if(ret[i]>=0 && ret[i]==ret[j])
		{
			cout<<i<<' '<<j<<' '<<ret[i]<<endl;
			D.Error("89u43gw");
		}*/
		
		
		
		for(j=0;j<ny;j++)
		if(ret[j]<0)
		{
			for(i=1;i<=nx;i++)
			if(!node[i].v && node[i].value_for_agent[agent_i[j]]<oo)
			if(ret[j]<0 || node[i].value_for_agent[agent_i[j]]<node[ret[j]].value_for_agent[agent_i[j]])
				ret[j]=i;
				
			if(ret[j]>=0)
			{
				node[ret[j]].v=1;				
			}
			else
			{			
				for(i=1;i<=nx;i++)
				if(node[i].value_for_agent[agent_i[j]]<oo)
				if(ret[j]<0 || node[i].value_for_agent[agent_i[j]]<node[ret[j]].value_for_agent[agent_i[j]])
					ret[j]=i;
			}
		}
		
		/*for(j=0;j<ny;j++)
		{
			int s=0;
			for(i=1;i<=nx;i++)
			if(node[i].value_for_agent[agent_i[j]]<oo)s++;
			cout<<agent_i[j]<<' '<<s<<' '<<ret[j]<<endl;
		}*/
		
		for(j=0;j<ny;j++)
		if(ret[j]==-1)
		{
			D.Error("0r9t439uqyj4");
		}
				
		/*cx.resize(nx+1);
		cy.resize(ny+1);
		sx.resize(nx+1);
		sy.resize(ny+1);
		lx.resize(nx+1);
		ly.resize(ny+1);
		KuhnMunkres(agent_i,node);*/
	}
private:
/*
	int path(int u)
	{
		sx[u]=1;
		for(int v=1;v<=ny;v++)
		if(
	}
	
	void KuhnMunkres(vector<int> agent_i,vector<Node> &node)
	{
		int i,j,u,min;
		for(i=0;i<=nx;i++)
		{
			lx[i]=0;
			cx[i]=0;
		}
		
		for(i=0;i<=ny;i++)
		{
			ly[i]=0;
			cy[i]=0;
		}
		
		for(i=1;i<=nx;i++)
		for(j=1;j<=ny;j++)
		if(lx[i]<node[i].value_for_agent[agent_i[j]]
	}
	
	vector<int> cx;
	vector<int> cy;
	vector<int> sx;
	vector<int> sy;
	vector<int> lx;
	vector<int> ly;	*/
	int nx , ny , match;
}maximum_cost_perfect_matching;


class Dijkstra
{
public:
	~Dijkstra()
	{
		value.clear();
		mk.clear();
		nbs.clear();
		ps.clear();
		heap.clear();
		fa.clear();
	}
	
	stack<int> Run(int src,vector<Node> &node)
	{
		stack<int> ret;
		while(ret.size())ret.pop();
		int n=name.Get_n();
		
		value.resize(n+1);
		mk.resize(n+1);
		nbs.resize(n+1);
		ps.resize(n+1);
		heap.resize(n+1);
		fa.resize(n+1);
		
		int i,j,u,v,w,flag;
		
		flag=0;
		for(i=1;i<=n;i++)
		if(node[i].bound==1)
		{
			flag=1;
			break;
		}
		if(!flag)
		{
			return d_stack.Empty_stack();
			D.Error("349ua0hG:WE*wy89e4");
		}
		
		if(node[src].bound==1)
		{
			return ret;		
		}
		
		for(i=1;i<=n;i++) 
		{
			value[i]=oo; 
			mk[i]=ps[i]=0;
		}
		value[src]=0; 
		heap[len=1]=src; 
		ps[src]=1;
		fa[src]=0;
		
		while(1) 
		{
			if(len==0)return ret;
			u=getmin(); 
			mk[u]=1;
			
			if(node[u].bound==1)
			{
				while(ret.size())ret.pop();
				while(u && u!=src)
				{
					ret.push(u);
					u=fa[u];					
				}
				return ret;
			}
			
			for(j=1;j<=node[u].n;j++) 
			{
				v=node[u].edge[j]; 
				w=node[u].edge_value[j];
				
				if(!mk[v] && node[v].bound!=-1 && value[u]+w < value[v]) 
				{
					if(ps[v]==0)
					{
						heap[++len]=v; 
						ps[v]=len; 
					}
					value[v]=value[u]+w; 
					fa[v]=u;
					update(v);
				}
			}
		}
		return ret;
	}

	void Run_calc_value_for_agent(int src,vector<Node> &node,int agent_i)
	{
		int n=name.Get_n();
		
		value.resize(n+1);
		mk.resize(n+1);
		nbs.resize(n+1);
		ps.resize(n+1);
		heap.resize(n+1);
		fa.resize(n+1);
		
		int i,j,u,v,w,flag;
		for(i=1;i<=n;i++)
			node[i].value_for_agent[agent_i]=oo;
				
		
		for(i=1;i<=n;i++) 
		{
			value[i]=oo; 
			mk[i]=ps[i]=0;
			fa[i]=0;
		}
		value[src]=0; 
		heap[len=1]=src; 
		ps[src]=1;
		fa[src]=0;
		
		while(1) 
		{
			if(len==0)break;
			u=getmin(); 
			mk[u]=1;
			//cout<<"u "<<u<<' '<<name.Int_to_string(u)<<endl;
		
			for(j=1;j<=node[u].n;j++) 
			{
				v=node[u].edge[j]; 
				w=node[u].edge_value[j];
				//if(!node[u].is_surveyed)
				//	continue;
				
				
				if(!mk[v] && value[u]+w < value[v]) 
				{
					value[v]=value[u]+w; 
				
				//	cout<<"v "<<v<<' '<<name.Int_to_string(v)<<' '<<u<<' '<<w<<' '<<value[v]<<' '<<value[u]<<endl;
					
					if(node[v].bound==-1)continue;
					
					if(ps[v]==0)
					{
						heap[++len]=v; 
						ps[v]=len; 
					}
					
		//			cout<<"v "<<v<<' '<<name.Int_to_string(v)<<' '<<u<<' '<<w<<' '<<value[v]<<' '<<value[u]<<endl;
					fa[v]=u;
					update(v);
				}
			}
		}
		
		for(i=1;i<=n;i++)
			node[i].value_for_agent[agent_i]=value[i];
			
		/*
		for(i=1;i<=n;i++)
		if(node[i].bound==1)
		{
			node[i].value_for_agent[agent_i]=value[i];
			if(value[i]==oo)
			{
				for(j=1;j<=n;j++)
				if(node[j].bound==1)cout<<"bound1 "<<j<<' '<<name.Int_to_string(j)<<endl;
				for(j=1;j<=n;j++)
				if(node[j].bound==0)cout<<"bound0 "<<j<<' '<<name.Int_to_string(j)<<endl;
				cout<<src<<' '<<name.Int_to_string(src)<<endl;
				cout<<i<<' '<<name.Int_to_string(i)<<' '<<node[i].can_visit_through_surveyed_node[agent_i]<<' '<<fa[i]<<endl;
				D.Error("469uw$yhay");
			}
		}
		
		{
		int flag=0;
		for(i=1;i<=n;i++)
		if(node[i].value_for_agent[agent_i]<oo)flag=1;
		if(!flag)
			D.Error("gj09q3y4u");}*/
	}
private:
	void update(int r)
	{
		int q=ps [ r ] , p=q>>1;
		while ( p && value[heap[p]] > value[r] ) 
		{
			ps[heap[p]]=q; 
			heap[q]=heap[p];
			q=p;
			p=q>>1;
		}
		heap[q]=r; 
		ps[r]=q;
	}

	int getmin()
	{
		int ret=heap[1],p=1,q=2,r=heap[len--];
		while(q<=len) 
		{
			if(q<len && value[heap[q+1]] < value[heap[q]])q++;
			if(value[heap[q]]<value[r]) 
			{
				ps[heap[q]]=p; 
				heap[p]=heap[q];
				p=q; 
				q=p<<1;
			}
			else break;
		}
		heap[p]=r; 
		ps[r]=p;
		return ret;
	}	
	
	
	int num,len,;
	vector<int> value;
	vector<int> mk;
	vector<int> nbs;
	vector<int> ps;
	vector<int> heap;
	vector<int> fa;

}dijkstra;

///b
class Bfs
{
public:
	~Bfs()
	{
		value.clear();
		mk.clear();
		nbs.clear();
		ps.clear();
		heap.clear();
		fa.clear();
	}
	
	stack<int> Run(int src,vector<Node> &node)
	{
		
		stack<int> ret;
		while(ret.size())ret.pop();
		int n=name.Get_n();
		
		value.resize(n+1);
		mk.resize(n+1);
		nbs.resize(n+1);
		ps.resize(n+1);
		heap.resize(n+1);
		fa.resize(n+1);
		
		int i,j,a,b,z,w,flag;
		
		flag=0;
		for(i=1;i<=n;i++)
		if(node[i].bound==1)
		{
			flag=1;
			break;
		}
		if(!flag)
		{
			return d_stack.Empty_stack();
			D.Error("349ua0hG:WE*wy89e4");
		}

		
		queue<int> q;
		while(q.size())q.pop();
		
		
		for(i=1;i<=n;i++)
		{
			node[i].dis=-1;
			node[i].v=0;
			fa[i]=-1;
		}
		
		
		node[src].v=1;
		q.push(src);
		node[src].dis=0;
		fa[src]=0;
		
		while(q.size())
		{
			a=q.front();
			q.pop();
			for(i=1;i<=node[a].n;i++)
			{
				b=node[a].edge[i];
				if(node[b].v)continue;
				
				if(node[b].dis!=-1 && node[b].dis<=node[a].dis+1)continue;
				node[b].dis=node[a].dis+1;
				node[b].v=1;
				fa[b]=a;
				if(node[b].bound==1)continue;
				q.push(b);
			}			
		}
		
		z=-1;
		for(i=1;i<=n;i++)
		if(node[i].bound==1 && node[i].v)
		if(z<0 || node[i].dis<node[z].dis)z=i;
		
		if(node[z].dis<0)return d_stack.Empty_stack();
					
		if(node[z].dis<0)D.Error("8yu95oihyayha");
		
		
		while(z && z!=src)
		{
			ret.push(z);
			z=fa[z];					
		}
		
		return ret;
	}

private:
	void update(int r)
	{
		int q=ps [ r ] , p=q>>1;
		while ( p && value[heap[p]] > value[r] ) 
		{
			ps[heap[p]]=q; 
			heap[q]=heap[p];
			q=p;
			p=q>>1;
		}
		heap[q]=r; 
		ps[r]=q;
	}

	int getmin()
	{
		int ret=heap[1],p=1,q=2,r=heap[len--];
		while(q<=len) 
		{
			if(q<len && value[heap[q+1]] < value[heap[q]])q++;
			if(value[heap[q]]<value[r]) 
			{
				ps[heap[q]]=p; 
				heap[p]=heap[q];
				p=q; 
				q=p<<1;
			}
			else break;
		}
		heap[p]=r; 
		ps[r]=p;
		return ret;
	}	
	
	
	int num,len,;
	vector<int> value;
	vector<int> mk;
	vector<int> nbs;
	vector<int> ps;
	vector<int> heap;
	vector<int> fa;
}bfs;




///k

struct Kuo_d
{
	int da;	
	vector<int> d;
	int root;
	~Kuo_d()
	{
		d.clear();
	}
	
	void st()
	{
		da=-1;
		d.clear();
	}	
	
	void Add(int x)
	{
		d.push_back(x);
	}
	
	void write()
	{	
		int i;
	}
	
	void update(vector<int> &xr,int sd,int x)
	{
		int i;
		if(sd>da)
		{
			da=sd;
			d=xr;
			root=x;
		}		
	}
};
vector<Kuo_d> kuo_d;
int dn;

///k
class Kuo
{
public:
	Log *log;
	void Init(Log* x)
	{
		log=x;
		start=1;
	}
	
	void Run(int max_use_agent)
	{
	//	cout<<"kuo run() 1"<<endl;
		int i,j;
		string zs;
		int n=name.Get_n();
		int z;
		int last_best_root=-1;
		int flag;
		if(kuo_d.size() && kuo_d[0].da>=0)
		{
			last_best_root=kuo_d[0].root;
		}
		
		Kuo_d Z;
		while(kuo_d.size()<=1+n)
		{
			Z.st();
			kuo_d.push_back(Z);
		}
				
		for(i=0;i<kuo_d.size();i++)
		kuo_d[i].st();
			
		for(i=1;i<=n;i++)
		{
			//kuo_d[i].st();		
			node[i].ev=1;
			node[i].can_kuo=0;
		}
		
		for(i=1;i<=n;i++)
		if(node[i].is_surveyed)
		{
			node[i].can_kuo=1;
			node[i].ev=0;
		}
		
		flag=0;
		for(i=0;i<enermy_agent.size();i++)
		{
			///z
			if(enermy_agent[i].Last_known_status_is(cc.disabled))
				continue;
			if(!enermy_agent[i].Last_known_position(zs))
				continue;
			z=name.String_to_int(zs);
			node[z].ev=1;
			flag=1;
		}
		
		if(!flag)
		{
			for(i=0;i<enermy_agent.size();i++)
			{
				///z
				if(enermy_agent[i].role!=cc.repairer)
					continue;
				if(!enermy_agent[i].Last_known_position(zs))
					continue;
				z=name.String_to_int(zs);
				node[z].ev=1;
				flag=1;
			}
		}
		
		if(!flag)
		{
			for(i=0;i<enermy_agent.size();i++)
			{
				if(!enermy_agent[i].Last_known_position(zs))
					continue;
				z=name.String_to_int(zs);
				node[z].ev=1;
				flag=1;
			}
		}
		
		for(i=1;i<=n;i++)
		if(node[i].ev)
		{
			//cout<<z<<endl;
			//cout<<"ev "<<i<<' '<<name.Int_to_string(i);
			for(j=1;j<=node[i].n;j++)
			{
				node[node[i].edge[j]].can_kuo=0;
			//	cout<<"can kuo 0 = "<<i<<' '<<j<<' '<<node[i].edge[j]<<' '<<name.Int_to_string(node[i].edge[j])<<endl;
			}
			
		//	cout<<"can kuo 0 = "<<z<<' '<<name.Int_to_string(z)<<endl;
		}
	//for(i=1;i<=n;i++)
		{
		//	cout<<i<<endl;
		//	if(name.Int_to_string(i)=="vertex278")
		//	start=i;
		}
		//cout<<start<<endl;
	
		//if(name.Int_to_string(start)!="vertex278")
		//	return ;
		
		if(last_best_root>=1)
		{
			xkuo(last_best_root);
		}
		
		for(i=1;i<=10;i++)
		{
		//	cout<<i<<endl;
			xkuo(start);
			//xkuo(18);
			//start=(start+1)%n;
			start++;
			if(start==n+1)
				start=1;
		}
	//	cout<<"kuo run() 3"<<endl;
				
		z=-1;
		for(i=min(int(kuo_d.size()-1),max_use_agent);i>=3;i--)
		{					
			if(kuo_d[i].da>=0)
			{
				z=i;
				break;
			}
		}
		
		if(z>=0)
		{			
			kuo_d[0]=kuo_d[z];
		//	cout<<"kuo d "<<kuo_d[0].d.size()<<' '<<kuo_d[0].da<<' '<<kuo_d[0].root<<' ';
		//	cout<<name.Int_to_string(kuo_d[0].root)<<endl;
		//	for(i=0;i<kuo_d[0].d.size();i++)
			{
			//	cout<<i<<' '<<kuo_d[0].d[i]<<' ';
		//		cout<<name.Int_to_string(kuo_d[0].d[i])<<endl;
			}
		}
		
		
		//cout<<kuo_d[0].da<<endl;
		//cout<<kuo_d[0].d.size()<<endl;
		//for(i=0;i<kuo_d[0].d.size();i++)
		//cout<<kuo_d[0].d[i]<<' '<<name.Int_to_string(kuo_d[0].d[i])<<endl;
	}
	
	void write()
	{	
		int i;
		for(i=1;i<kuo_d.size();i++)
		{
			cout<<"n="<<i<<endl;
			kuo_d[i].write();
			cout<<endl;
		}
	}
private:
	void xkuo(int x)
	{
		////log->writeln("-----------xkuo 1");	
		//log->writeln(x);
		//log->writeln(name.Int_to_string(x));	
		//cout<<"xkuo(int x) " <<x<<' '<<name.Int_to_string(x)<<endl;
		int i,j,z;
		int sn,sd,sb;
		int flag;
		int n=name.Get_n();
		
		//if(x==kuo_d[0].root)
		//cout<<"xkuo "<<x<<' '<<name.Int_to_string(x)<<endl;
	
		if(node[x].ev)return;
	
		for(i=1;i<=n;i++)
			node[i].v=0;
	
		node[x].v=1;	
		sn=1;
		sd=node[x].value;
		sb=1;
		Update_da(sd,x);
	
		
		
		while(1)
		{
			for(i=1;i<=n;i++)
				node[i].xu=0;
		
			for(i=1;i<=n;i++)
			if(node[i].v==1)
			{			
				for(j=1;j<=node[i].n;j++)
				{
					z=node[i].edge[j];
					if(node[z].v)
						continue;
					node[i].xu++;
				}
				if(node[i].xu && !node[i].can_kuo)
					node[i].xu++;			
			}
		
			z=-1;
			for(i=1;i<=n;i++)
			if(node[i].v==1 && node[i].can_kuo)
			{
				if(z<0 || node[i].xu<node[z].xu)z=i;				
			}
		
			if(z<0)
			{
				for(i=1;i<=n;i++)
				if(node[i].v==1 && !node[i].can_kuo)
				if(node[i].xu)
				{
					if(z<0 || node[i].xu<node[z].xu)z=i;				
				}
			}
		
			
			if(z<0)break;
			
		//	if(x==kuo_d[0].root)
			for(i=1;i<=n;i++)
			if(node[i].v==1 || node[i].v==3)
			{	
			//	cout<<i<<endl;
		//		cout<<name.Int_to_string(i)<<' '<<node[i].v<<' '<<node[i].xu<<"| ";
			}
			
			//if(x==kuo_d[0].root)
			if(z>node.size())
				D.Error("wjgghjhaoirj");
		//	cout<<"xkuo(int x) zzzzz  "<<z<<' '<<name.Int_to_string(z)<<endl;
			//log->writeln(z);
		//	log->writeln(name.Int_to_string(z));	
		
			if(node[z].can_kuo)
				del(z,sn,sd,sb);	
			else
				add(z,sn,sd,sb);
			Update_da(sd,x);				
		}
	//	cout<<"xkuo 2========="<<endl;
		//log->writeln("-----------xkuo 2");	
	}
	
	void Fu_gai(int x)
	{
		int i;
		node[x].fu_gai++;
		for(i=1;i<=node[x].n;i++)
		node[node[x].edge[i]].fu_gai++;
	}
	
	void Del_da(int x)
	{
		int i;
		int z;
		string zs;
		
		if(node[x].fu_gai-1<2)return;
		for(i=1;i<=node[x].n;i++)
		if(node[node[x].edge[i]].v==1 || node[node[x].edge[i]].v==3)
		if(node[node[x].edge[i]].can_kuo && !node[node[x].edge[i]].yao && node[node[x].edge[i]].fu_gai-1<2)return;
		
		
		for(i=1;i<=node[x].n;i++)
		if(node[node[x].edge[i]].ev)
		{
			cout<<x<<' '<<name.Int_to_string(x)<<' '<<node[x].v<<' '<<node[x].can_kuo<<endl;
			cout<<node[x].edge[i]<<' '<<name.Int_to_string(node[x].edge[i])<<' '<<node[node[x].edge[i]].ev<<' '<<node[node[x].edge[i]].can_kuo<<endl;
			
			int j=i;
			for(i=0;i<enermy_agent.size();i++)
			{
				///z
				if(enermy_agent[i].Last_known_status_is(cc.disabled))
					continue;
				if(!enermy_agent[i].Last_known_position(zs))
					continue;
				z=name.String_to_int(zs);
				if(z!=node[x].edge[j])continue;
				
				cout<<"----- "<<enermy_agent[i].name<<endl;
			}
			
			D.Error("t430auyah");
		}
		
		node[x].fu_gai--;
		for(i=1;i<=node[x].n;i++)
		node[node[x].edge[i]].fu_gai--;
		node[x].yao=0;
	}
	
	void Update_da(int sd,int x)
	{
		int i;
		int n=name.Get_n();
		int kong=0;
		vector<int> d;
		d.clear();
		int start;
		
		for(i=1;i<=n;i++)
		{
			node[i].fu_gai=0;
			node[i].yao=0;
		}
		
		///z
		
		
		if(cc.kuo01)
		{
			for(i=1;i<=n;i++)
			if(node[i].v==1 || node[i].v==3)
			if(!node[i].can_kuo)
			{
			//	d.push_back(i);
				Fu_gai(i);
				node[i].yao=1;
			}
		
			for(i=1;i<=n;i++)
			if(node[i].v==1 || node[i].v==3)
			if(node[i].can_kuo)
				if(node[i].fu_gai<2)
				{
				//	d.push_back(i);
					Fu_gai(i);
					node[i].yao=1;
				}
			
			for(i=1;i<=n;i++)
			if(node[i].v==1 || node[i].v==3)
			if(node[i].can_kuo && node[i].yao)
				Del_da(i);			
		}
		else
		{
			for(i=1;i<=n;i++)
			if(node[i].v==1 || node[i].v==3)
				node[i].yao=1;
		
		}
		
		for(i=1;i<=n;i++)
		if(node[i].yao)d.push_back(i);
		
		if(!d.size())
			D.Error("3u4jy4ah4y");
		
		kuo_d[d.size()].update(d,sd,x);
		 
	/*	
		if(sd>da)
		{
			da=sd;
			d.clear();
			for(i=1;i<=n;i++)
			if(node[i].v==1 || node[i].v==3)
				Add(i);
			root=x;
		}	*/	
	}
	
	void del(int x,int &sn,int &sd,int &sb)
	{
	//	cout<<"del(int x,int &sn,int &sd,int &sb) "<<x<<' '<<sn<<' '<<sd<<' '<<sb<<endl;
		int i,j,z;
		int flag;
		int n=name.Get_n();
		
		for(i=1;i<=node[x].n;i++)
		{
			z=node[x].edge[i];
			if(node[z].v)
				continue;
			sn++;
			sd+=node[z].value;
			node[z].v=1;
		}
		node[x].v=2;
		
			
		for(i=1;i<=n;i++)
		if(node[i].v==1)
		{
			flag=0;
			for(j=1;j<=node[i].n;j++)
			{
				z=node[i].edge[j];
				if(node[z].v)
					continue;
				flag=1;
				break;
			}						
			if(!flag)
				node[i].v=2;
		}
		
		sb=0;
		for(i=1;i<=n;i++)
		if(node[i].v==1 || node[i].v==3)
			sb++;
	}

	void add(int x,int &sn,int &sd,int &sb)
	{
		int i,j,z;
		int flag;
		int n=name.Get_n();
		
		for(i=1;i<=node[x].n;i++)
		{
			z=node[x].edge[i];
			if(node[z].ev)
				continue;
			if(node[z].v)
				continue;
			sn++;
			sd+=node[z].value;
			node[z].v=1;
		}
		
		node[x].v=3;
	
		for(i=1;i<=n;i++)
		if(node[i].v==1)
		{
			flag=0;
			for(j=1;j<=node[i].n;j++)
			{
				z=node[i].edge[j];
				if(node[z].v)
					continue;
				flag=1;
				break;
			}
			
			if(!flag)
				node[i].v=2;
		}
		
		sb=0;
		for(i=1;i<=n;i++)
		if(node[i].v==1 || node[i].v==3)
			sb++;
	}
	vector<int> q,qb;
	int dn;
	int start;
}kuo;


///a
class Agent
{
public:
	struct Prodcons
	{
		// 缓冲区相关数据结构
		pthread_mutex_t lock; /* 互斥体lock 用于对缓冲区的互斥操作 */
		pthread_cond_t net_msg_signal_start;
		int thread_start;
	}pr;
	string agent_name;
	int mission_destination;
	string mission;	
	int perception_id;
	int sim_end;
	int sim_result_ranking;
	int sim_result_score;
	
//	int first_debug_pain;
	int clear_flag;
	int first_flag;
	int net_msg_signal_ready;
	int net_msg_signal_done;
	int net_msg_signal_start;
	int first_msg;
	int second_msg;
	int have_auth_msg;
	int have_sim_msg;
	
	///w
		
	void write()
	{
		int i;
		printf("%4.d ",perception_id);
		
		printf("%c%c ",simulation_role[0],simulation_role[1]);
		
		if(!agent_pi)
			printf(" 0 ");
		else 
			printf("%2.d ",agent_pi);
			
		if(!health)
			printf(" 0 ");
		else
			printf("%2.d ",health);
			
		if(mission=="")
			printf("    ");
		else
			printf("%s ",mission.c_str());
			
		if(no_action_count==0)
			printf(" 0 ");
		else
			printf("%2.d ",no_action_count);
		printf("%s %s %s %s \n",last_action.c_str(),last_action_param.c_str(),last_action_result.c_str(),protocol.order_short.c_str());
	
		//printf("last_action = %s\n",last_action.c_str());
		//printf("last_action_result = %s\n",last_action_result.c_str());		
		
		
		
		log.writeln("[step state =========================");
		log.write("id = ");
		log.writeln(protocol.Get_id());
		
		log.write("name = ");
		log.writeln(agent_name);
		
		log.write("role = ");
		log.writeln(simulation_role);
		
		log.write("step = ");
		log.writeln(step);
		
		log.write("energy = ");
		log.writeln(energy);
		
		log.write("health = ");
		log.writeln(health);
		
		log.write("last_action = ");
		log.writeln(last_action);
		
		log.write("last_action_param = ");
		log.writeln(last_action_param);
		
		log.write("last_action_result = ");
		log.writeln(last_action_result);
		
		log.write("max_energy = ");
		log.writeln(max_energy);
		
		log.write("max_energy_disabled = ");
		log.writeln(max_energy_disabled);
		
		log.write("max_health = ");
		log.writeln(max_health);
		
		log.write("position = ");
		log.write(position_int);
		log.writeln(" "+position);
		
		log.write("strength = ");
		log.writeln(strength);
		
		log.write("vis_range = ");
		log.writeln(vis_range);
		
		log.write("team money = ");
		log.writeln(team_money);
		
		log.write("used money = ");
		log.writeln(used_money);
		
		log.write("can_buy_battery = ");
		log.writeln(can_buy_battery);
		
		log.write("can_buy_sensor = ");
		log.writeln(can_buy_sensor);
		
		log.write("can_buy_shield = ");
		log.writeln(can_buy_shield);
		
		log.write("can_buy_sabotageDevice = ");
		log.writeln(can_buy_sabotageDevice);
		
		int z,a,b,j;
		int n=name.Get_n();
		z=0;
		for(i=1;i<=n;i++)
		if(node[i].is_surveyed)
			z++;
		
		log.write("surveyed node / all node number = ");
		log.write(z);
		log.write(" / ");
		log.writeln(n);
		
		a=b=0;
		for(i=1;i<=n;i++)
		{
			for(j=1;j<=node[i].n;j++)
			{
				b++;
				if(node[i].edge_is_surveyed[j])
					a++;
			}
		}
		
		log.write("surveyed edge / all edge number = ");
		log.write(a);
		log.write(" / ");
		log.writeln(b);
		
		a=b=0;
		for(i=1;i<=n;i++)
		{			
			b++;
			if(node[i].is_probed)
				a++;
		}
		
		log.write("probed node / all node number = ");
		log.write(a);
		log.write(" / ");
		log.writeln(b);
		
		a=b=0;
		for(i=0;i<agent_p.size();i++)
		{			
			if(agent_p[i]->Have_pain_in_the_ass())
				a++;
			b++;
		}
		
		log.write("repaiered agent / all pain agent number = ");
		log.write(a);
		log.write(" / ");
		log.writeln(b);
		
		a=b=0;
		for(i=0;i<enermy_agent.size();i++)
		{			
			if(enermy_agent[i].is_inspected)
				a++;
			b++;
		}
		
		log.write("inspected enermy agent / all seen agent number = ");
		log.write(a);
		log.write(" / ");
		log.writeln(b);
		
		log.write("visible entity number = ");
		log.writeln(visible_entity_name.size());
		log.writeln("]step state =========================");
		log.write();
	}
	
	///a
	void Arrange_mission_explorer_min_cost_visit_bound()
	{
		if(cc.debug_function_path)
			log.writeln("=======================Arrange_mission_explorer_min_cost_visit_bound()");

		int i,j,b,z;
		string zs;
		vector<int> agent_in_mission;
		vector<int> mission_node;
		mission_node.clear();
		agent_in_mission.clear();
		
		
		{
		
			for(i=0;i<agent_p.size();i++)
			{
				if(agent_p[i]->mission!=cc.mission_explorer_min_cost_visit_bound)			
					continue;
			
				agent_in_mission.push_back(i);
				agent_p[i]->Calc_value_for_agent_in_probe_mission();
			}
		}
		
		maximum_cost_perfect_matching.Run(agent_in_mission,node,mission_node);
		
		if(mission_node.size()!=agent_in_mission.size())
		D.Error("pioeruy98s5rhg");
		
		for(i=0;i<agent_in_mission.size();i++)
		{
			agent_p[agent_in_mission[i]]->mission_destination=mission_node[i];
		}
		
		if(cc.debug_function_path)			
			log.writeln("=======================Arrange_mission_explorer_min_cost_visit_bound()");
	}
	
	void Arrange_mission_not_explorer_min_cost_visit_bound()
	{
		if(cc.debug_function_path)
			log.writeln("=======================Arrange_mission_not_explorer_min_cost_visit_bound() 1");

		int i,j,b,z;
		string zs;
		vector<int> agent_in_mission;
		vector<int> mission_node;
		agent_in_mission.clear();
		
		for(i=0;i<agent_p.size();i++)
		{
			if(agent_p[i]->mission!=cc.mission_not_explorer_min_cost_visit_bound)			
				continue;
			
			agent_in_mission.push_back(i);
			agent_p[i]->Calc_value_for_agent_in_servey_mission();
		}
		
		maximum_cost_perfect_matching.Run(agent_in_mission,node,mission_node);
		
		if(mission_node.size()!=agent_in_mission.size())
		D.Error("e4us548445u743q");
		
		for(i=0;i<agent_in_mission.size();i++)
		{
			agent_p[agent_in_mission[i]]->mission_destination=mission_node[i];
		}
		
		if(cc.debug_function_path)			
			log.writeln("=======================Arrange_mission_not_explorer_min_cost_visit_bound() 2");
	}
	
	void Arrange_mission_kuo()
	{
		if(cc.debug_function_path)
			log.writeln("=======================Arrange_mission_kuo() 1");

		int i,j,b,z;
		string zs;
		vector<int> agent_in_mission;
		vector<int> mission_node;
		agent_in_mission.clear();
		
		if(kuo_d[0].d.size()==0)
		{
			for(i=0;i<agent_p.size();i++)
			{
				if(agent_p[i]->mission!=cc.mission_explorer_min_cost_visit_bound)			
					continue;
			
				agent_in_mission.push_back(i);
				mission_node.push_back(agent_p[i]->position_int);
			}
		}
		else
		for(i=0;i<agent_p.size();i++)
		{
			if(agent_p[i]->mission!=cc.mission_kuo)			
				continue;
			
			agent_in_mission.push_back(i);
			agent_p[i]->Calc_value_for_agent_in_kuo_mission();
		}
		
		maximum_cost_perfect_matching.Run(agent_in_mission,node,mission_node);
		
		if(mission_node.size()!=agent_in_mission.size())
		D.Error("e4us548445u743q");
		
		for(i=0;i<agent_in_mission.size();i++)
		{
			agent_p[agent_in_mission[i]]->mission_destination=mission_node[i];
		}
		
		if(cc.debug_function_path)			
			log.writeln("=======================Arrange_mission_kuo() 2");
	}
	
	void Skip()
	{
		protocol.Skip();
	}
	
	void Send_order()
	{
		protocol.Send_order();
	}/*
	void Share_visible_entity()
	{
		log.writeln("-----------Share_visible_entity() 1");
		string zs;
		int i,j;	
		map<string,bool> entity;
		entity.clear();
		for(i=0;i<visible_entity_name.size();i++)
		entity[visible_entity_name[i]]=1;
		
		for(i=0;i<agent_p.size();i++)
		{
			if(agent_p[i]->agent_name==agent_name)
				continue;
			for(j=0;j<agent_p[i]->visible_entity_name.size();j++)
			{
				zs=agent_p[i]->visible_entity_name[j];
				if(entity[zs])
					continue;
				entity[zs]=1;
				visible_entity_name.push_back(agent_p[i]->visible_entity_name[j]);
				visible_entity_node.push_back(agent_p[i]->visible_entity_node[j]);
				visible_entity_status.push_back(agent_p[i]->visible_entity_status[j]);
				visible_entity_team.push_back(agent_p[i]->visible_entity_team[j]);
			}
		}
		
		for(i=0;i<agent_p.size();i++)
		{
			if(agent_p[i]->agent_name==agent_name)
				continue;
			agent_p[i]->visible_entity_name=visible_entity_name;
			agent_p[i]->visible_entity_node=visible_entity_node;
			agent_p[i]->visible_entity_status=visible_entity_status;
			agent_p[i]->visible_entity_team=visible_entity_team;
			
		}
		
		log.writeln("-----------Share_visible_entity() 2");
	}
	*/
	void Auth_request_send()
	{
		protocol.Auth_request(agent_name,agent_password);
		Send_order();
	}
	
	~Agent()
	{
		FILE *F=fopen("WYX","w");
		fclose(F);
	/*	agent_name_map.clear();
		d_stack.Clear(destination);
		visible_vertex_name.clear();
		visible_vertex_team.clear();
		visible_entity_name.clear();
		visible_entity_node.clear();
		visible_entity_status.clear();
		visible_entity_team.clear();
		visible_edge_node1.clear();
		visible_edge_node2.clear();	
		achievement_name.clear();
		probed_vertex_name.clear();
		probed_bertex_value.clear();
		surveyed_edge_node1.clear();
		surveyed_edge_node2.clear();
		surveyed_edge_weight.clear();
		inspected_entity_energy.clear();
		inspected_entity_health.clear();
		inspected_entity_max_energy.clear();
		inspected_entity_max_health.clear();
		inspected_entity_name.clear();
		inspected_entity_node.clear();
		inspected_entity_role.clear();
		inspected_entity_strength.clear();
		inspected_entity_team.clear();
		inspected_entity_vis_range.clear();
	
	
		vertex_near.clear();*/
	}
	/*
	bool Net_msg_is_complete(char r[])
	{
		int i,z;
		int n=strlen(r);
		if(!n)return 0;
		
		
		if(str.Last_zi_fu(r,n)!='>')
		{
		//	cout<<"last char is not > "<<endl;
			//D.Error("gieryhgihg");
			return 0;
		}
		
		z=str.Find_chs_chs(r,"</message>");
		if(z>=0 && z+10<n)
		{
		//	D.Error("jiewhg");
			return 0;
			//cout<<agent_name<<endl;
			//cout<<r<<endl;
			//return 0;
			//n=0;
		//	return 0;
			//for(i=0;i<10;i++)
			//	putchar(r[i+z]);
		//	puts("");
			z+=10;
			//cout<<"have message after </message>"<<endl;
		//	cout<<z<<endl;
			
			for(i=z;i<n;i++)r[i]=0;
			n=z;			
			return 1;
		//for(i=0;i<n;i++)
		//		putchar(r[i]);
		//	puts("");
		}	
		
		
		z=0;
		for(i=0;i<n;i++)
		if(r[i]=='<')
			z++;
		else if(r[i]=='>')
			z--;
		
		
		if(z!=0)
		{
			return 0;
			cout<<r<<endl;
			cout<<"kuo hao is not match "<<z<<' '<<agent_name<<endl;
			exit(0);
			return 0;
		}
		
		z=0;
		for(i=0;i<n;i++)
		if(r[i]=='<')
		{
			for(i=i+1;i<n;i++)
			if(r[i]!=' ')
				break;
				
			if(r[i]=='/')
				z--;
			else
				z++;
		}
		else
			if(r[i]=='/')
			z--;
		
		if(z!=1)
		{
			cout<<"< and / is not match "<<z<<endl;
			return 0;
		}
		return 1;
	}*/
	
	/*void Listen_auth_sim_id0()
	{
		if(!have_auth_msg)
		net.Listen_simple(auth_msg,min_msg_length);
		have_auth_msg=1;	
		
		net.Listen_simple(sim_msg,min_msg_length);			
		have_sim_msg=1;
		
		///net.Listen_simple(net_msg,max_msg_length);		
		Listen(0);
		first_msg=1;
	}*/
	
	void Listen()
	{
		//cout<<agent_name<<" listen 1"<<endl; 
		
		//net_msg_signal_ready=1;
		//cout<<agent_name<<" ready"<<endl;
	//	net_msg_signal_ready=1;
		
		int i;
		
		
		if(!have_auth_msg)
		{			
			while(net.Listen(buff,max_msg_length,buff_n,agent_name,net_msg_signal_ready,&msg_file))	
			{			
				if(str.Add_until_0(auth_msg,auth_msg_n,buff,buff_n))
					break;
			}
			
			have_auth_msg=1;
		//	Write_net_msg(auth_msg,auth_msg_n);	
		}
		
		if(!have_sim_msg)
		{
			while(net.Listen(buff,min_msg_length,buff_n,agent_name,net_msg_signal_ready,&msg_file))
				if(str.Add_until_0(sim_msg,sim_msg_n,buff,buff_n))
					break;
					
			have_sim_msg=1;
		//	Write_net_msg(sim_msg,sim_msg_n);
		}
		
		while(1)
		{
			///z
			while(net.Listen(buff,max_msg_length,buff_n,agent_name,net_msg_signal_ready,&msg_file))
			{
				if(str.Add_until_0(net_msg,net_msg_n,buff,buff_n))
					break;
			}		
			Write_net_msg(net_msg,net_msg_n);
			
			if(buff_n==0)
				break;
			
			while(1)
			{
				for(i=0;i<net_msg_n;i++)
					net_msg[i]=0;
				net_msg_n=0;
				if(!str.Add_until_0(net_msg,net_msg_n,buff,buff_n))
					break;
		//		Write_net_msg(net_msg,net_msg_n);
			}
		}	
	}
	
	void Write_log(string r)
	{
	//	log.writeln(r);		
	}
	
	void Write_net_msg(char r[],int rn)
	{
		msg_file.writeln(rn);
		msg_file.writeln_chars(r,rn);
	}
	
	///i
	int Init(string name,string password,vector<string> &name_v,vector<Agent> &agent,int x_clear_flag,string ip,int port)
	{
//		first_debug_pain=1;
		
		int i;		
		
		mission="";	
		mission_destination=-1;
		
		memset(auth_msg,0,sizeof(auth_msg));
			auth_msg_n=0;
		
		memset(sim_msg,0,sizeof(sim_msg));
			sim_msg_n=0;
			
		memset(net_msg,0,sizeof(net_msg));
			net_msg_n=0;
			
		buff_n=0;
		memset(buff,0,sizeof(buff));
		
		
		mission="";
		second_msg=0;
		first_msg=0;
		have_auth_msg=0;
		have_sim_msg=0;
	//	sim_start_file.Init("./ini/sim_start.ini");
		pthread_mutex_init(&pr.lock, NULL);
		pthread_cond_init(&pr.net_msg_signal_start,NULL);
		pr.thread_start=0;
	
		net_msg_signal_done=0;
		net_msg_signal_ready=0;
		net_msg_signal_start=0;
		
		no_action_count=0;
		
		used_money=0;
		
		can_buy_battery=1;
		can_buy_sensor=1;
		can_buy_shield=1;
		can_buy_sabotageDevice=1;
		
		
		clear_flag=x_clear_flag;
		
		if(!net.st(ip,port))
			D.Error("tj94838ya9y4");
				
		log.Init("./log/"+name+".log");
		if(clear_flag)
			log.Clear();
			
		msg_file.Init("./msg/"+name+".log");
		msg_file.Clear();
			
		protocol.Init(net,log);
			
		
		agent_name=name;
		agent_password=password;
		
		agent_name_map.clear();
		
		for(i=0;i<name_v.size();i++)
		{
			agent_name_map[name_v[i]]=i+1;
		}
		
		if(agent.size()!=name_v.size())
			D.Error("o4yt8943ayt");
		
		agent_p.clear();
		for(i=0;i<agent.size();i++)
		{
			agent_p.push_back(&agent[i]);
			if(name_v[i]==agent_name)
				agent_pi=i;
		}
		
	
		return 1;
	}
	
	int Init2()
	{
//		first_debug_pain=1;
		
		int i;		
		mission="";	
		mission_destination=-1;
		mission="";
		have_auth_msg=1;	
		
		no_action_count=0;
		
		used_money=0;
		
		can_buy_battery=1;
		can_buy_sensor=1;
		can_buy_shield=1;
		can_buy_sabotageDevice=1;
								
		log.Init("./log/"+agent_name+".log");

		msg_file.Init("./msg/"+agent_name+".log");
			
		protocol.Init(net,log);	
		return 1;
	}
	
	///s
	int Sim_start()
	{
		string zs;
		vector<string> zv;
		int i;
		
		XML xml;		
		xml.To_vector(sim_msg,sim_msg_n,zv,xml_tmp);
		Del_useless_infor(zv);
		for(i=0;i<sim_msg_n;i++)
			sim_msg[i]=0;
		sim_msg_n=0;
			
		if(zv.size()%2)D.Error("0uu349rear");
		
		for(i=0;i<zv.size();i+=2)
		{
			if(zv[i]==cc.message_timestamp)continue;
			if(zv[i]==cc.message_type)
			{
				if(zv[i+1]==cc.sim_start)
				{
					break;
				}
		//		sim_start_file.Read_a_block_from_last_position(zv);
				break;
			}
		}
		
		
		for(i=0;i<zv.size();i+=2)
		{
			if(zv[i]==cc.message_timestamp)continue;
			if(zv[i]==cc.message_type)
			{
				if(zv[i+1]==cc.sim_start)
					continue;
		//		sim_start_file.Read_a_block_from_last_position(zv);
				return 1;
				D.Error("3849y9hroaig4r");
			}
				
			if(zv[i]==cc.simulation_edges)
			{
				simulation_edges=str.String_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==cc.simulation_id)
			{
				simulation_id=str.String_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==cc.simulation_role)
			{
				simulation_role=zv[i+1];
				continue;
			}
			
			if(zv[i]==cc.simulation_steps)
			{
				simulation_steps=str.String_to_int(zv[i+1]);
				continue;
			}
			
			///i
			if(zv[i]==cc.simulation_vertices)
			{
				simulation_vertices=str.String_to_int(zv[i+1]);			
				continue;
			}
			
			D.Error("94e0809uyh5zreh");
		}
	
		return 1;	
	}
	
	
	
	int Auth_request()
	{
		string zs;
		vector<string> zv;
		int i;
		//cout<<net_msg<<endl;
		//protocol.Auth_request(agent_name,agent_password);		
		
		//Listen();
		XML xml;	
		xml.To_vector(auth_msg,auth_msg_n,zv,xml_tmp);
		
		for(i=0;i<auth_msg_n;i++)
			auth_msg[i]=0;
		auth_msg_n=0;
		
		Del_useless_infor(zv);
		
		if(zv.size()%2)	
			D.Error("9u054hyjwosh");
		
		for(i=0;i<zv.size();i+=2)
		{
			if(zv[i]==cc.message_timestamp)continue;
			if(zv[i]==cc.message_type)continue;
			if(zv[i]==cc.authentication_result)
			{
				zs=zv[i+1];
				if(zs==cc.ok)
				{
					printf("%s ok\n",agent_name.c_str());
					return 1;			
				}
				else 
					D.Error("[wrong] [id and password are wrong]\n");
			}
		}
		return 0;
	}
	
	///r
	int Run()
	{					
		if(sim_end)
		{
			Sim_end();
			return 0;
		}
		
		/*if(agent_name[0]=='b')
		{
			write();
			protocol.Skip();
			return 1;
		}*/
		
		Can_visit_node();	
		Can_visit_through_surveyed_node();
		//Calc_value_for_agent();
		d_stack.Clear(destination);
		
		if(mission==cc.mission_not_explorer_min_cost_visit_bound)
		if(!Have_not_surveyed_node())
		{
			mission="";
			mission_destination=-1;
		}
		
		if(mission==cc.mission_explorer_min_cost_visit_bound)
		if(!Have_not_probed_node())
		{
			mission="";
			mission_destination=-1;
		}
		
		if(simulation_role==cc.explorer)
			Run_explorer();
		else if(simulation_role==cc.saboteur) 
			Run_saboteur();
		else if(simulation_role==cc.repairer) 
			Run_repairer();
		else if(simulation_role==cc.inspector)
			Run_inspector();
		else
			Run_sentinel();
		//return Random_explorer();		
		return 1;
	}
	
	int Run_mission()
	{
		if(mission=="")
			return 0;
		if(mission_destination<0)
			return 0;
		if(protocol.Have_order())
			return 0;
		d_stack.Clear(destination);
		
		if(simulation_role==cc.explorer)
			Run_mission_explorer();
	//	else if(simulation_role==cc.saboteur) 
	//		Run_saboteur();
		else if(simulation_role==cc.repairer) 
			Run_mission_repairer();
		else if(simulation_role==cc.inspector)
			Run_mission_inspector();
		else
			Run_mission_sentinel();
		return 1;
	}
	
	int Prepare()
	{
		if(cc.debug_function_path)
			log.writeln("---------------------Prepare() 1");
//		cout<<agent_name<<" prepare 1"<<endl;
		int i,a,b;
				
		
		visible_vertex_name.clear();
		visible_vertex_team.clear();
		visible_edge_node1.clear();
		visible_edge_node2.clear();
		visible_entity_name.clear();
		visible_entity_node.clear();
		visible_entity_status.clear();
		visible_entity_team.clear();
		visible_edge_node1.clear();
		visible_edge_node2.clear();	
		achievement_name.clear();
		probed_vertex_name.clear();
		probed_bertex_value.clear();
		surveyed_edge_node1.clear();
		surveyed_edge_node2.clear();
		surveyed_edge_weight.clear();
		inspected_entity_energy.clear();
		inspected_entity_health.clear();
		inspected_entity_max_energy.clear();
		inspected_entity_max_health.clear();
		inspected_entity_name.clear();
		inspected_entity_node.clear();
		inspected_entity_role.clear();
		inspected_entity_strength.clear();
		inspected_entity_team.clear();
		inspected_entity_vis_range.clear();
		sim_end=0;
		
		vertex_near.clear();
		
		Get_infor();
		
		
		for(i=0;i<visible_edge_node1.size();i++)
		{
			a=name.String_to_int(visible_edge_node1[i]);
			b=name.String_to_int(visible_edge_node2[i]);
			
			if(a==position_int)
			{
				vertex_near.push_back(b);				
			}
			if(b==position_int)
			{
				vertex_near.push_back(a);	
			}
		}
			
		if(!Deal_last_action_result())
			D.Error("ew9rugy8ayg");

		Learn_from_sight();
		return 1;
	}
	
	
	
	int Deal_last_action_result()
	{
	//	log.writeln("-------------Deal_last_action_result() 1");
		string zs;
		int z;
		
		while(1)
		{
			if(last_action_result==cc.failed_random)
				break;
			if(last_action_result==cc.failed_attacked)
				break;
			if(last_action_result==cc.failed_role)
				D.Error("fgjer98ahgar");
			if(last_action_result==cc.failed_status)
				D.Error("fjwehgwhgpaher");
			if(last_action_result==cc.failed_wrong_param)	
				D.Error("gjewryga89ga");
			if(last_action_result==cc.failed_away)
				break;
			if(last_action_result==cc.failed_parry)
				break;
			if(last_action_result==cc.failed_resources)
				break;
			if(last_action==cc.skip)
				break;
				
				
			if(last_action==cc.recharge)
				break;
				
			if(last_action==cc.repair)
				break;
				
			if(last_action==cc.attack)
				break;
				
			if(last_action==cc.inspect)
				break;
				
			if(last_action==cc.noAction)
			{
				///z
				break;
				D.Error("joiewghahg");
			}
				
			if(last_action==cc.parry)
			{
				if(last_action_result==cc.successful)
				{
					if(Last_time_on_one_enermy_agent_ass(zs))				
					{
						z=enermy_agent_name.String_to_int(zs);
						enermy_agent[z].role=cc.saboteur;
					}
				}
				if(last_action_result==cc.useless)
				{
					if(Last_time_on_one_enermy_agent_ass(zs))				
					{
						z=enermy_agent_name.String_to_int(zs);
						enermy_agent[z].is_useless_parryed=1;
					}
				}
				
			}

				
			if(last_action==cc.goto_ && last_action_result==cc.successful)
			{
				z=name.String_to_int(last_action_param);
				if(destination.size())
				if(destination.top()==z)
					destination.pop();
				break;
			}
		
			if(last_action==cc.survey)
			{
				if(last_action_result==cc.successful)
					node[position_int].is_surveyed=1;
				break;
			}
		
			if(last_action==cc.probe)
			{
				if(last_action_result==cc.successful)
					node[position_int].is_probed=1;
				break;
			}
			
			if(last_action==cc.buy)
			{
				if(last_action_result==cc.failed_resources)
					break;
					
				if(last_action_result==cc.successful)
				{
					used_money++;
					break;
				}
				
				if(last_action_result==cc.wrongParameter)
					D.Error("8a9eyap9ajhahg");
					
				if(last_action_result==cc.failed_limit)
				{
					if(last_action_param==cc.battery)
					{
						can_buy_battery=0;
						break;
					}
					if(last_action_param==cc.sensor)
					{
						can_buy_sensor=0;
						break;
					}
					if(last_action_param==cc.shield)
					{
						can_buy_shield=0;
						break;
					}
					if(last_action_param==cc.sabotageDevice)
					{
						can_buy_sabotageDevice=0;
						break;
					}
					D.Error("jg089yspyh");
				}
				
				D.Error("gjoierhy98swyh");
						
					
				break;
			}
			
			cout<<agent_name<<endl;
			cout<<last_action<<endl;
			cout<<last_action_param<<endl;
			cout<<last_action_result<<endl;
			D.Error("984yu89sgjarh");
		}
	//	log.writeln("-------------Deal_last_action_result() 2");
		return 1;
	}	
	
private:
///ri
	int Run_mission_inspector()
	{
		int z;
		string zs;
		
		if(mission==cc.mission_kuo)
		{
			destination=Mission_kuo(mission_destination);
			d_stack.Leave_top(destination);
		}
		
		if(mission==cc.mission_not_explorer_min_cost_visit_bound)
		{
			destination=Mission_not_explorer_min_cost_visit_bound(mission_destination);
			d_stack.Leave_top(destination);
		}
		if(destination.size())
		{
			z=destination.top();
			
			if(z==position_int)
			{
				protocol.Recharge();				
			}
			else
			{
				
				if(!Can_go_to(z))
				D.Error("08 9y6089jhsrousy45");
		
				zs=name.Int_to_string(z);
				protocol.Goto(zs);			
			}
		}
		else
		{
			cout<<position_int<<' '<<position<<endl;
			cout<<mission_destination<<' '<<name.Int_to_string(mission_destination)<<endl;
			D.Error("08uy398uy35aoj");
		}
		return 1;
	}
	
	int Run_inspector()
	{
	//	log.writeln("---------------------Run_inspector");
		int i;
		int z;
		int rethink=0;
		string zs;
					
			
			
			
			
			//if(agent_name[0]=='b' && agent_name=="b3")
	//		write();
			
			//protocol.Survey();
			//continue;
			
			while(1)
			{						
				d_stack.Clear(destination);
				
				if(energy <= int(max_energy * Low_energy_rate()))
				{
					protocol.Recharge();
					break;
				}
				
				if(health==0)
				{
					mission="";	
					mission_destination=-1;
					
					if(!node[position_int].is_surveyed)
					{
						protocol.Recharge();
						break;
					}
				
					if(On_repairer_ass())
					{
						protocol.Recharge();
						break;
					}
					
					if(Near_repairer_ass(zs))
					{
					//	log.writeln("Near_repairer_ass() ");
						protocol.Goto(zs);
						break;
					}
										
					if(Find_repairer())
					{
					//	log.writeln("report to WYX : find repairer");
						if(Repairer_is_reachable_by_surveyed_position())
						{
					//		log.writeln("report to WYX : Repairer is in surveyed reachable node");						
							destination=Go_to_reachable_repairer_by_surveyed_position();
							d_stack.Leave_top(destination);
						}
						else
						{
						//	log.writeln("report to WYX : Repairer is not in surveyed reachable node");
							if(!On_the_edge_of_survey_zone_near_repairer())
							{
						//		log.writeln("report to WYX : I am not on the edge of the surveyd zone near repairer. I will go to edge of the surveyd zone near pain friend.");		destination=Go_to_edge_of_surveyed_zone_near_repairer_place_with_smallest_edge();
								d_stack.Leave_top(destination);
							}								
							else
							{	
						//		log.writeln("report to WYX : I am on the edge of the surveyd zone. I will recharge and wait repairer.");	
								//destination=Go_to_unkown_place_near_repairer_with_smallest_edge()
								//d_stack.Leave_top(destination);
								protocol.Recharge();
								break;
							}
						}
					}
					
					if(destination.size())
					{
						z=destination.top();
				
						if(!Can_go_to(z))
							D.Error("g09uy894yaq4jy4");
				
						zs=name.Int_to_string(z);
						protocol.Goto(zs);
						
						break;
					}			
			
					protocol.Recharge();					
					break;
				}			
				
				
				
				if(health<max_health)
				{
					mission="";	
					mission_destination=-1;
		
					if(!node[position_int].is_surveyed)
					{
						protocol.Survey();
						break;
					}					
					
					if(On_repairer_ass())
					{
						protocol.Recharge();
						break;
					}
					
					if(Near_repairer_ass(zs))
					{
						log.writeln("Near_repairer_ass() ");
						protocol.Goto(zs);
						break;
					}
										
					if(Find_repairer())
					{
						log.writeln("report to WYX : find repairer");
						if(Repairer_is_reachable_by_surveyed_position())
						{
							log.writeln("report to WYX : Repairer is in surveyed reachable node");						
							destination=Go_to_reachable_repairer_by_surveyed_position();
							d_stack.Leave_top(destination);
						}
						else
						{
							log.writeln("report to WYX : Repairer is not in surveyed reachable node");
							if(!On_the_edge_of_survey_zone_near_repairer())
							{
								log.writeln("report to WYX : I am not on the edge of the surveyd zone near repairer. I will go to edge of the surveyd zone near pain friend.");		destination=Go_to_edge_of_surveyed_zone_near_repairer_place_with_smallest_edge();
								d_stack.Leave_top(destination);
							}								
							else
							{	
								log.writeln("report to WYX : I am on the edge of the surveyd zone. I will recharge and wait repairer.");	
								//destination=Go_to_unkown_place_near_repairer_with_smallest_edge()
								//d_stack.Leave_top(destination);
								protocol.Recharge();
								break;
							}
						}
					}
					
					if(destination.size())
					{
						z=destination.top();
				
						if(!Can_go_to(z))
							D.Error("g09uy894yaq4jy4");
				
						zs=name.Int_to_string(z);
						protocol.Goto(zs);
						
						break;
					}			
			
					protocol.Recharge();					
					break;
				}	
				
				
				if(Near_uninspected_enermy_ass())
				{
					protocol.Inspect();
					break;
				}			
			
				if(!node[position_int].is_surveyed)
				{
					protocol.Survey();
					break;
				}
			
				if(Have_pain_in_the_ass())
				{
					if(On_repairer_ass())
					{
						protocol.Recharge();
						break;
					}
				}
				
				if(!destination.size())
				{
					if(Find_uninspected_enermy())
					{
						log.writeln("report to WYX : find uninspected enermy");
						if(Uninspected_enermy_can_visit_through_surveyed_node())
						{
							log.writeln("report to WYX : uninspected enermy is in surveyed reachable node");
							destination=Go_to_uninspected_enermy();	
							d_stack.Leave_top(destination);
						}
						else
						{
							log.writeln("report to WYX : uninspected enermy is not in surveyed reachable node");
							if(!On_the_edge_of_survey_zone_near_uninspected_enermy())
							{
								log.writeln("report to WYX : I am not on the edge of the surveyd zone near uninspected enermy. I will go to edge of the surveyd zone near uninspected enermy.");	
								destination=Go_to_uninspected_enermy_near_known_place();
								d_stack.Leave_top(destination);
							}
							else
							{	
								log.writeln("report to WYX : I am on the edge of the surveyd zone. I will go to unkown place.");
								destination=Go_to_unkown_place_near_uninspected_enermy();
								d_stack.Leave_top(destination);
							}
						}
					}
				}				
			
				if(!destination.size())
				if(Have_not_surveyed_node())
				{
					mission=cc.mission_not_explorer_min_cost_visit_bound;
					return 1;
					{
					//	destination=Not_explorer_min_cost_visit_bound();
					//	d_stack.Leave_top(destination);
					}
				}
				
				if(!destination.size())
				{
					mission=cc.mission_kuo;
					return 1;
					/*if(On_occupy_max_kuo_node())
					{						
						protocol.Recharge();
						break;
					}
					destination=Go_to_not_occupy_max_kuo_node();
					d_stack.Leave_top(destination);		*/
				}
			
				if(!destination.size())
				{
					destination=Go_to_not_occupy_max_value_node();
					d_stack.Leave_top(destination);
				}
			
				if(destination.size())
				{
					z=destination.top();
				
					if(!Can_go_to(z))D.Error("54ue75dikis445i");
				
					zs=name.Int_to_string(z);
					protocol.Goto(zs);
					
					break;
				}
			
				protocol.Recharge();	
				break;
				D.Error("No destination");
				return 1;
			}
		return 1;
	}
	
	///rr	
	int Run_mission_repairer()
	{
		int z;
		string zs;
		
		if(mission==cc.mission_kuo)
		{
			destination=Mission_kuo(mission_destination);
			d_stack.Leave_top(destination);
		}
		
		if(mission==cc.mission_not_explorer_min_cost_visit_bound)
		{
			destination=Mission_not_explorer_min_cost_visit_bound(mission_destination);
			d_stack.Leave_top(destination);
		}
		if(destination.size())
		{
			z=destination.top();
				
			if(z==position_int)
			{
				protocol.Recharge();				
			}
			else
			{
				
				if(!Can_go_to(z))
				D.Error("08 9y6089jhsrousy45");
		
				zs=name.Int_to_string(z);
				protocol.Goto(zs);			
			}	
		}
		else
		{
			cout<<position_int<<' '<<position<<endl;
			cout<<mission_destination<<' '<<name.Int_to_string(mission_destination)<<endl;
			D.Error("34y335uaqgw3eur8");
		}
		return 1;
	}
	
	int Run_repairer()
	{
		log.writeln("---------------------Run_repairer()	");
///		cout<<"---------------------Run_repairer()	"<<endl;
		int i;
		int z;
		int rethink=0;
		string zs;
		vector<int> zv;		
			//if(agent_name[0]=='b' && agent_name=="b3")
			//write();
			
			//protocol.Survey();
			//continue;
			
			/*if(All_enermy_is_dead())
			{
				protocol.Skip();
				continue;
			}*/
			while(1)			
			{			
				//z
				/*
				protocol.Parry();
					break;
					
				if(energy ==0)
				{
					protocol.Recharge();
					break;
				}
				*/
				
				
				/*
				if(On_enermy_ass())
				{
					if(On_saboteur_enermy_ass())
					if(!On_saboteur_friend_ass())
					{
						protocol.Parry();
						break;
					}
				
					if(!Must_not_on_saboteur_enermy_ass())
					if(Have_not_parryed_unkown_role_enermy_on_ass())
					{
						protocol.Parry();
						break;
					}
				}
				*/
				
				d_stack.Clear(destination);
				
				if(energy <= int(max_energy * Low_energy_rate()))
				{
					protocol.Recharge();
					break;
				}
				/*
				protocol.Parry();
				break;
				*/
				if(health==0)
				{
					mission="";	
					mission_destination=-1;
		
					if(On_friend_pain_ass(zv))
					{				
						z=Should_repair_friend(zv);
						zs=agent_p[z]->agent_name;
						protocol.Repair(zs);
						break;
					}
			
					
					
					if(!node[position_int].is_surveyed)
					{
						protocol.Recharge();
						break;
					}
				
					if(On_repairer_ass())
					{
						protocol.Recharge();
						break;
					}
					
					if(Near_repairer_ass(zs))
					{
						log.writeln("Near_repairer_ass() ");
						protocol.Goto(zs);
						break;
					}
										
					if(Find_repairer())
					{
						log.writeln("report to WYX : find repairer");
						if(Repairer_is_reachable_by_surveyed_position())
						{
							log.writeln("report to WYX : Repairer is in surveyed reachable node");						
							destination=Go_to_reachable_repairer_by_surveyed_position();
							d_stack.Leave_top(destination);
						}
						else
						{
							log.writeln("report to WYX : Repairer is not in surveyed reachable node");
							if(!On_the_edge_of_survey_zone_near_repairer())
							{
								log.writeln("report to WYX : I am not on the edge of the surveyd zone near repairer. I will go to edge of the surveyd zone near pain friend.");		destination=Go_to_edge_of_surveyed_zone_near_repairer_place_with_smallest_edge();
								d_stack.Leave_top(destination);
							}								
							else
							{	
								log.writeln("report to WYX : I am on the edge of the surveyd zone. I will recharge and wait repairer.");	
								//destination=Go_to_unkown_place_near_repairer_with_smallest_edge()
								//d_stack.Leave_top(destination);
								protocol.Recharge();
								break;
							}
						}
					}
					
					if(destination.size())
					{
						z=destination.top();
				
						if(!Can_go_to(z))
							D.Error("g09uy894yaq4jy4");
				
						zs=name.Int_to_string(z);
						protocol.Goto(zs);
						break;
					}
			
					protocol.Recharge();					
					break;
				}			
				
				
				
				if(health<max_health)
				{
					mission="";	
					mission_destination=-1;
		
					if(On_friend_pain_ass(zv))
					{				
						z=Should_repair_friend(zv);
						zs=agent_p[z]->agent_name;
						protocol.Repair(zs);
						break;
					}
			
					
					if(!node[position_int].is_surveyed)
					{
						protocol.Survey();
						break;
					}
					
					
					if(On_repairer_ass())
					{
						protocol.Recharge();
						break;
					}
					
					if(Near_repairer_ass(zs))
					{
						log.writeln("Near_repairer_ass() ");
						protocol.Goto(zs);
						break;
					}
										
					if(Find_repairer())
					{
						log.writeln("report to WYX : find repairer");
						if(Repairer_is_reachable_by_surveyed_position())
						{
							log.writeln("report to WYX : Repairer is in surveyed reachable node");						
							destination=Go_to_reachable_repairer_by_surveyed_position();
							d_stack.Leave_top(destination);
						}
						else
						{
							log.writeln("report to WYX : Repairer is not in surveyed reachable node");
							if(!On_the_edge_of_survey_zone_near_repairer())
							{
								log.writeln("report to WYX : I am not on the edge of the surveyd zone near repairer. I will go to edge of the surveyd zone near pain friend.");		destination=Go_to_edge_of_surveyed_zone_near_repairer_place_with_smallest_edge();
								d_stack.Leave_top(destination);
							}								
							else
							{	
								log.writeln("report to WYX : I am on the edge of the surveyd zone. I will recharge and wait repairer.");	
								//destination=Go_to_unkown_place_near_repairer_with_smallest_edge()
								//d_stack.Leave_top(destination);
								protocol.Recharge();
								break;
							}
						}
					}
					
					if(destination.size())
					{
						z=destination.top();
				
						if(!Can_go_to(z))
							D.Error("g09uy894yaq4jy4");
				
						zs=name.Int_to_string(z);
						protocol.Goto(zs);
						break;
					}		
			
					protocol.Recharge();					
					break;
				}	
				
				
				//////
				if(On_friend_pain_ass(zv))
				{				
					z=Should_repair_friend(zv);
					zs=agent_p[z]->agent_name;
					protocol.Repair(zs);
					break;
				}
			
				if(!node[position_int].is_surveyed)
				{
					protocol.Survey();
					break;
				}
			
				if(!destination.size())
				{
					////
					if(Find_friend_has_pain_in_the_ass())
					{
						log.writeln("report to WYX : find pain friend");
						if(Pain_friend_is_reachable_by_surveyed_position())
						{
							log.writeln("report to WYX : pain friend is in surveyed reachable node");						
							destination=Go_to_reachable_friend_by_surveyed_position();
							d_stack.Leave_top(destination);
						}
						else
						{
							log.writeln("report to WYX : pain friend is not in surveyed reachable node");
							if(!On_the_edge_of_survey_zone_near_friend())
							{
								log.writeln("report to WYX : I am not on the edge of the surveyd zone near pain friend. I will go to edge of the surveyd zone near pain friend.");		destination=Go_to_edge_of_surveyed_zone_near_friend_place();
							d_stack.Leave_top(destination);
							}	
							
							else
							{	
								log.writeln("report to WYX : I am on the edge of the surveyd zone. I will go to unkown place and find pain friend.");	
								destination=Go_to_unkown_place_near_friend();
								d_stack.Leave_top(destination);
							}
						}
					}
				}
				
				if(!destination.size())
				if(Have_not_surveyed_node())
						{
							log.writeln("report to WYX : I can not find enermy. I will explorer map.");
							mission=cc.mission_not_explorer_min_cost_visit_bound;
							return 1;
						//	destination=Not_explorer_min_cost_visit_bound();
						//	d_stack.Leave_top(destination);
						}
				
				/*
				if(!destination.size())
				{
					if(On_occupy_max_kuo_node())
					{						
						protocol.Recharge();
						break;
					}
					destination=Go_to_not_occupy_max_kuo_node();
					d_stack.Leave_top(destination);		
				}*/
			
				if(!destination.size())
				{
					destination=Go_to_not_occupy_max_value_node();
					d_stack.Leave_top(destination);
				}
			
				if(destination.size())
				{
					z=destination.top();
				
					if(!Can_go_to(z))
					{
						D.Error("g09uy894yaq4jy4");
					}
				
					zs=name.Int_to_string(z);
					protocol.Goto(zs);
					break;
				}
				
				protocol.Recharge();	
				break;		
				D.Error("No destination");
				return 1;
			}
		return 1;
	}

	///rs
	int Run_mission_sentinel()
	{
		int z;
		string zs;
		
		if(mission==cc.mission_kuo)
		{
			destination=Mission_kuo(mission_destination);
			d_stack.Leave_top(destination);
		}
		
		if(mission==cc.mission_not_explorer_min_cost_visit_bound)
		{
			destination=Mission_not_explorer_min_cost_visit_bound(mission_destination);
			d_stack.Leave_top(destination);
		}
		if(destination.size())
		{
			z=destination.top();
				
			if(z==position_int)
			{
				protocol.Recharge();				
			}
			else
			{
				
				if(!Can_go_to(z))
				D.Error("08 9y6089jhsrousy45");
		
				zs=name.Int_to_string(z);
				protocol.Goto(zs);			
			}		
		}
		else
		{
			cout<<position_int<<' '<<position<<endl;
			cout<<mission_destination<<' '<<name.Int_to_string(mission_destination)<<endl;
			D.Error("45o86s72w8");
		}
		return 1;
	}
	
	int Run_sentinel()
	{
		log.writeln("---------------------Run_Sentinel");
		int i;
		int z;
		int rethink=0;
		string zs;
		
			
			//if(agent_name[0]=='b' && agent_name=="b3")
			//write();
			
			//protocol.Survey();
			//continue;
			
			while(1)
			{				
				d_stack.Clear(destination);
				
				if(cc.debug_repairer && agent_name[0]=='b')
				{
					protocol.Recharge();
					break;
				}
						
				if(energy <= int(max_energy * Low_energy_rate()))
				{
					protocol.Recharge();
					break;
				}
				
				if(health==0)
				{
					mission="";	
					mission_destination=-1;
		
					if(!node[position_int].is_surveyed)
					{
						protocol.Recharge();
						break;
					}
				
					if(On_repairer_ass())
					{
						protocol.Recharge();
						break;
					}
					
					if(Near_repairer_ass(zs))
					{
						log.writeln("Near_repairer_ass() ");
						protocol.Goto(zs);
						break;
					}
										
					if(Find_repairer())
					{
						log.writeln("report to WYX : find repairer");
						if(Repairer_is_reachable_by_surveyed_position())
						{
							log.writeln("report to WYX : Repairer is in surveyed reachable node");						
							destination=Go_to_reachable_repairer_by_surveyed_position();
							d_stack.Leave_top(destination);
						}
						else
						{
							log.writeln("report to WYX : Repairer is not in surveyed reachable node");
							if(!On_the_edge_of_survey_zone_near_repairer())
							{
								log.writeln("report to WYX : I am not on the edge of the surveyd zone near repairer. I will go to edge of the surveyd zone near pain friend.");		destination=Go_to_edge_of_surveyed_zone_near_repairer_place_with_smallest_edge();
								d_stack.Leave_top(destination);
							}								
							else
							{	
								log.writeln("report to WYX : I am on the edge of the surveyd zone. I will recharge and wait repairer.");	
								//destination=Go_to_unkown_place_near_repairer_with_smallest_edge()
								//d_stack.Leave_top(destination);
								protocol.Recharge();
								break;
							}
						}
					}
					
					if(destination.size())
					{
						z=destination.top();
				
						if(!Can_go_to(z))
							D.Error("g09uy894yaq4jy4");
				
						zs=name.Int_to_string(z);
						protocol.Goto(zs);
						break;
					}		
			
					protocol.Recharge();					
					break;
				}			
				
				
				
				if(health<max_health)
				{
					mission="";	
					mission_destination=-1;
		
					if(!node[position_int].is_surveyed)
					{
						protocol.Survey();
						break;
					}
					
					
					if(On_repairer_ass())
					{
						protocol.Recharge();
						break;
					}
					
					if(Near_repairer_ass(zs))
					{
						log.writeln("Near_repairer_ass() ");
						protocol.Goto(zs);
						break;
					}
										
					if(Find_repairer())
					{
						log.writeln("report to WYX : find repairer");
						if(Repairer_is_reachable_by_surveyed_position())
						{
							log.writeln("report to WYX : Repairer is in surveyed reachable node");						
							destination=Go_to_reachable_repairer_by_surveyed_position();
							d_stack.Leave_top(destination);
						}
						else
						{
							log.writeln("report to WYX : Repairer is not in surveyed reachable node");
							if(!On_the_edge_of_survey_zone_near_repairer())
							{
								log.writeln("report to WYX : I am not on the edge of the surveyd zone near repairer. I will go to edge of the surveyd zone near pain friend.");		destination=Go_to_edge_of_surveyed_zone_near_repairer_place_with_smallest_edge();
								d_stack.Leave_top(destination);
							}								
							else
							{	
								log.writeln("report to WYX : I am on the edge of the surveyd zone. I will recharge and wait repairer.");	
								//destination=Go_to_unkown_place_near_repairer_with_smallest_edge()
								//d_stack.Leave_top(destination);
								protocol.Recharge();
								break;
							}
						}
					}
					
					if(destination.size())
					{
						z=destination.top();
				
						if(!Can_go_to(z))
							D.Error("g09uy894yaq4jy4");
				
						zs=name.Int_to_string(z);
						protocol.Goto(zs);
						break;
					}		
			
					protocol.Recharge();					
					break;
				}	
			
				if(!node[position_int].is_surveyed)
				{
					protocol.Survey();
					break;
				}
			
				if(!destination.size())
				if(Have_not_surveyed_node())
				{
					mission=cc.mission_not_explorer_min_cost_visit_bound;
					return 1;
					{
					//	destination=Not_explorer_min_cost_visit_bound();
					//	d_stack.Leave_top(destination);
					}
				}
				
				if(!destination.size())
				{
					mission=cc.mission_kuo;
					return 1;
					/*
					if(On_occupy_max_kuo_node())
					{						
						protocol.Recharge();
						break;
					}
					destination=Go_to_not_occupy_max_kuo_node();
					d_stack.Leave_top(destination);		*/
				}
				
				if(!destination.size())
				{
					destination=Go_to_not_occupy_max_value_node();
					d_stack.Leave_top(destination);
				}
							
				if(destination.size())
				{
					z=destination.top();
				
					if(!Can_go_to(z))D.Error("g09uy894yaq4jy4");
				
					zs=name.Int_to_string(z);
					protocol.Goto(zs);
					break;
				}
			
				protocol.Recharge();	
				break;
				
				D.Error("No destination");
				return 1;
			}
		return 1;
	}

	///rs
	int Run_mission_saboteur()
	{
		int z;
		string zs;
		
		if(mission==cc.mission_kuo)
		{
			destination=Mission_kuo(mission_destination);
			d_stack.Leave_top(destination);
		}
		
		if(mission==cc.mission_not_explorer_min_cost_visit_bound)
		{
			destination=Mission_not_explorer_min_cost_visit_bound(mission_destination);
			d_stack.Leave_top(destination);
		}
		if(destination.size())
		{
			z=destination.top();
				
			if(z==position_int)
			{
				protocol.Recharge();				
			}
			else
			{
				
				if(!Can_go_to(z))
				D.Error("08 9y6089jhsrousy45");
		
				zs=name.Int_to_string(z);
				protocol.Goto(zs);			
			}		
		}
		else
		{
			cout<<position_int<<' '<<position<<endl;
			cout<<mission_destination<<' '<<name.Int_to_string(mission_destination)<<endl;
			D.Error("43y6id7ii65");
		}
		return 1;
	}
	
	int Run_saboteur()	
	{
		log.writeln("---------------------Run_saboteur()	");
		int i;
		int z;
		int rethink=0;
		string zs;
		int clock_a=0,clock_b;
		vector<int> zv;
		
			//clock_b=clock()-clock_a;
			//clock_a=clock();
			
		//	d_file.Writeln_file("clock.txt","w",perception_id);
			
									
			
//			write();
						
			ts=us=0;
			
			
			if(last_action==cc.noAction)
				no_action_count++;
			
			while(1)
			{
				d_stack.Clear(destination);
				
				if(cc.debug_repairer && agent_name[0]=='b')
				{
					protocol.Recharge();
					break;
				}			
				
				
						
				
								
				if(energy <= int(max_energy * Low_energy_rate()))
				{
					protocol.Recharge();
					break;
				}
				
				
				if(health==0)
				{
					mission="";	
					mission_destination=-1;
		
					if(!node[position_int].is_surveyed)
					{
						protocol.Recharge();
						break;
					}
				
					if(On_repairer_ass())
					{
						protocol.Recharge();
						break;
					}
					
					if(Near_repairer_ass(zs))
					{
						log.writeln("Near_repairer_ass() ");
						protocol.Goto(zs);
						break;
					}
										
					if(Find_repairer())
					{
						log.writeln("report to WYX : find repairer");
						if(Repairer_is_reachable_by_surveyed_position())
						{
							log.writeln("report to WYX : Repairer is in surveyed reachable node");						
							destination=Go_to_reachable_repairer_by_surveyed_position();
							d_stack.Leave_top(destination);
						}
						else
						{
							log.writeln("report to WYX : Repairer is not in surveyed reachable node");
							if(!On_the_edge_of_survey_zone_near_repairer())
							{
								log.writeln("report to WYX : I am not on the edge of the surveyd zone near repairer. I will go to edge of the surveyd zone near pain friend.");		destination=Go_to_edge_of_surveyed_zone_near_repairer_place_with_smallest_edge();
								d_stack.Leave_top(destination);
							}								
							else
							{	
								log.writeln("report to WYX : I am on the edge of the surveyd zone. I will recharge and wait repairer.");	
								//destination=Go_to_unkown_place_near_repairer_with_smallest_edge()
								//d_stack.Leave_top(destination);
								protocol.Recharge();
								break;
							}
						}
					}
					
					
					if(destination.size())
					{
						z=destination.top();
				
						if(!Can_go_to(z))
							D.Error("g09uy894yaq4jy4");
				
						zs=name.Int_to_string(z);
						protocol.Goto(zs);
						
						break;
					}			
			
					protocol.Recharge();					
					break;
				}			
				
				
				
				if(health<max_health)
				{
					mission="";	
					mission_destination=-1;
		
					if(On_enermy_ass(zv))
					{
						z=Should_attack_enermy(zv);
						zs=enermy_agent[z].name;
						protocol.Attack(zs);
						break;
					}
					
					if(!node[position_int].is_surveyed)
					{
						protocol.Survey();
						break;
					}
					
					
					if(On_repairer_ass())
					{
						protocol.Recharge();
						break;
					}
					
					if(Near_repairer_ass(zs))
					{
						log.writeln("Near_repairer_ass() ");
						protocol.Goto(zs);
						break;
					}
										
					if(Find_repairer())
					{
						log.writeln("report to WYX : find repairer");
						if(Repairer_is_reachable_by_surveyed_position())
						{
							log.writeln("report to WYX : Repairer is in surveyed reachable node");						
							destination=Go_to_reachable_repairer_by_surveyed_position();
							d_stack.Leave_top(destination);
						}
						else
						{
							log.writeln("report to WYX : Repairer is not in surveyed reachable node");
							if(!On_the_edge_of_survey_zone_near_repairer())
							{
								log.writeln("report to WYX : I am not on the edge of the surveyd zone near repairer. I will go to edge of the surveyd zone near pain friend.");		destination=Go_to_edge_of_surveyed_zone_near_repairer_place_with_smallest_edge();
								d_stack.Leave_top(destination);
							}								
							else
							{	
								log.writeln("report to WYX : I am on the edge of the surveyd zone. I will recharge and wait repairer.");	
								//destination=Go_to_unkown_place_near_repairer_with_smallest_edge()
								//d_stack.Leave_top(destination);
								protocol.Recharge();
								break;
							}
						}
					}
					
					if(destination.size())
					{
						z=destination.top();
				
						if(!Can_go_to(z))
							D.Error("g09uy894yaq4jy4");
				
						zs=name.Int_to_string(z);
						protocol.Goto(zs);
						
						break;
					}			
			
					protocol.Recharge();					
					break;
				}	
				
				////
				if(On_enermy_ass(zv))
				{
					z=Should_attack_enermy(zv);
					zs=enermy_agent[z].name;
					protocol.Attack(zs);
					break;
				}
				
				if(agent_name[0]!='b')
				if(team_money)
				{
					log.writeln("============== team have money");
					if(I_am_not_use_max_money())
					{
						log.writeln("============== I_use_lowest_money()");
						if(can_buy_shield)
						if(!can_buy_sabotageDevice || max_health<strength)
						{
							protocol.Buy_shield();
							break;
						}
					
						if(can_buy_sabotageDevice)
						{
							protocol.Buy_sabotageDevice();
							break;
						}
					}
					else
						log.writeln("============== I am not use_lowest_money or I can not buy ()");
				}
			
				if(!node[position_int].is_surveyed)
				{
					protocol.Survey();
					break;
				}
				
								
				if(Have_pain_in_the_ass())
				{
					if(On_repairer_ass())
					{
						protocol.Recharge();
						break;
					}
				}
				
				
				
				
			
				if(!destination.size())
				{
					if(Find_enermy())
					{
						log.writeln("report to WYX : find enermy");
						if(Enermy_can_visit_through_surveyed_node())
						{
							log.writeln("report to WYX : enermy is in surveyed reachable node");
							destination=Go_to_enermy();	
							d_stack.Leave_top(destination);
						}
						else
						{
							log.writeln("report to WYX : enermy is not in surveyed reachable node");
							if(!On_the_edge_of_survey_zone_near_enermy())
							{
								log.writeln("report to WYX : I am not on the edge of the surveyd zone near enermy. I will go to edge of the surveyd zone near enermy.");	
								destination=Go_to_enermy_near_known_place();
								d_stack.Leave_top(destination);
							}
							else
							{	
								log.writeln("report to WYX : I am on the edge of the surveyd zone. I will go to unkown place.");
								destination=Go_to_unkown_place_near_enermy();
								d_stack.Leave_top(destination);
							}
						}
					}
				}
				
				if(!destination.size())
				if(Have_not_surveyed_node())
						{
							log.writeln("report to WYX : I can not find enermy. I will explorer map.");
							mission=cc.mission_not_explorer_min_cost_visit_bound;
							return 1;
						//	destination=Not_explorer_min_cost_visit_bound();
						//	d_stack.Leave_top(destination);
						}
				
				/*
				if(!destination.size())
				{
					if(On_occupy_max_kuo_node())
					{
						protocol.Recharge();
						break;
					}
					destination=Go_to_not_occupy_max_kuo_node();
					d_stack.Leave_top(destination);		
				}*/
				
				if(!destination.size())
				{
					destination=Go_to_not_occupy_max_value_node();
					d_stack.Leave_top(destination);
				}
			
				if(destination.size())
				{
					z=destination.top();
				
					if(!Can_go_to(z))
						D.Error("g09uy894yaq4jy4");
				
					zs=name.Int_to_string(z);
					protocol.Goto(zs);
					
					break;
				}			
			
				protocol.Recharge();	
				break;
				
				D.Error("No destination");
				return 1;
			}	
		return 1;
	}

	///re
	int Run_mission_explorer()
	{
		int z;
		string zs;
		
		if(mission==cc.mission_kuo)
		{
			destination=Mission_kuo(mission_destination);
			d_stack.Leave_top(destination);
		}
		
		if(mission==cc.mission_explorer_min_cost_visit_bound)
		{
			destination=Mission_explorer_min_cost_visit_bound(mission_destination);
			d_stack.Leave_top(destination);
		}
		if(!destination.size())
		{
			if(mission==cc.mission_not_explorer_min_cost_visit_bound)
			{
				destination=Mission_not_explorer_min_cost_visit_bound(mission_destination);
				d_stack.Leave_top(destination);
			}
		}
		if(destination.size())
		{
			z=destination.top();
				
			if(z==position_int)
			{
				protocol.Recharge();				
			}
			else
			{
				
				if(!Can_go_to(z))
				D.Error("08 9y6089jhsrousy45");
		
				zs=name.Int_to_string(z);
				protocol.Goto(zs);			
			}	
		}
		else
		{
			cout<<position_int<<' '<<position<<endl;
			cout<<mission_destination<<' '<<name.Int_to_string(mission_destination)<<endl;
			D.Error("y9834yhj45euhy5s4r");
		}
		return 1;
	}
	
	int Run_explorer()
	{
		log.writeln("---------------------Run_explorer()");;
		int i;
		int z;
		int rethink=0;
		string zs;
		
			
		//	if(agent_name[0]=='b' && agent_name=="b3")
	//		write();
			
			//protocol.Survey();
			//continue;
			
			while(1)
			{					
				d_stack.Clear(destination);
				
				if(cc.debug_repairer && agent_name[0]=='b')
				{
					protocol.Recharge();
					break;
				}
								
				if(energy <= int(max_energy * Low_energy_rate()))
				{
					protocol.Recharge();
					break;
				}
				
				if(health==0)
				{
					mission="";	
					mission_destination=-1;
					
					if(!node[position_int].is_surveyed)
					{
						protocol.Recharge();
						break;
					}
				
					if(On_repairer_ass())
					{
						protocol.Recharge();
						break;
					}
					
					if(Near_repairer_ass(zs))
					{
						log.writeln("Near_repairer_ass() ");
						protocol.Goto(zs);
						break;
					}
										
					if(Find_repairer())
					{
						log.writeln("report to WYX : find repairer");
						if(Repairer_is_reachable_by_surveyed_position())
						{
							log.writeln("report to WYX : Repairer is in surveyed reachable node");						
							destination=Go_to_reachable_repairer_by_surveyed_position();
							d_stack.Leave_top(destination);
						}
						else
						{
							log.writeln("report to WYX : Repairer is not in surveyed reachable node");
							if(!On_the_edge_of_survey_zone_near_repairer())
							{
								log.writeln("report to WYX : I am not on the edge of the surveyd zone near repairer. I will go to edge of the surveyd zone near pain friend.");		destination=Go_to_edge_of_surveyed_zone_near_repairer_place_with_smallest_edge();
								d_stack.Leave_top(destination);
							}								
							else
							{	
								log.writeln("report to WYX : I am on the edge of the surveyd zone. I will recharge and wait repairer.");	
								//destination=Go_to_unkown_place_near_repairer_with_smallest_edge()
								//d_stack.Leave_top(destination);
								protocol.Recharge();
								break;
							}
						}
					}
					
					if(destination.size())
					{
						z=destination.top();
				
						if(!Can_go_to(z))
							D.Error("g09uy894yaq4jy4");
				
						zs=name.Int_to_string(z);
						protocol.Goto(zs);
						
						break;
					}			
			
					protocol.Recharge();					
					break;
				}			
				
				
				
				if(health<max_health)
				{
					mission="";	
					mission_destination=-1;
		
					if(!node[position_int].is_surveyed)
					{
						protocol.Survey();
						break;
					}
					
					
					if(On_repairer_ass())
					{
						protocol.Recharge();
						break;
					}
					
					if(Near_repairer_ass(zs))
					{
						log.writeln("Near_repairer_ass() ");
						protocol.Goto(zs);
						break;
					}
										
					if(Find_repairer())
					{
						log.writeln("report to WYX : find repairer");
						if(Repairer_is_reachable_by_surveyed_position())
						{
							log.writeln("report to WYX : Repairer is in surveyed reachable node");						
							destination=Go_to_reachable_repairer_by_surveyed_position();
							d_stack.Leave_top(destination);
						}
						else
						{
							log.writeln("report to WYX : Repairer is not in surveyed reachable node");
							if(!On_the_edge_of_survey_zone_near_repairer())
							{
								log.writeln("report to WYX : I am not on the edge of the surveyd zone near repairer. I will go to edge of the surveyd zone near pain friend.");		destination=Go_to_edge_of_surveyed_zone_near_repairer_place_with_smallest_edge();
								d_stack.Leave_top(destination);
							}								
							else
							{	
								log.writeln("report to WYX : I am on the edge of the surveyd zone. I will recharge and wait repairer.");	
								//destination=Go_to_unkown_place_near_repairer_with_smallest_edge()
								//d_stack.Leave_top(destination);
								protocol.Recharge();
								break;
							}
						}
					}
					
					if(destination.size())
					{
						z=destination.top();
				
						if(!Can_go_to(z))
							D.Error("g09uy894yaq4jy4");
				
						zs=name.Int_to_string(z);
						protocol.Goto(zs);
						
						break;
					}			
			
					protocol.Recharge();					
					break;
				}	
			
				if(!node[position_int].is_probed)
				{
					protocol.Probe();
					break;
				}
			
				if(!node[position_int].is_surveyed)
				{
					protocol.Survey();
					break;
				}
			
				if(!destination.size())
				if(Have_not_probed_node())
				{		
					mission=cc.mission_explorer_min_cost_visit_bound;	
					return 1;
					//destination=Explorer_min_cost_visit_bound();
					//d_stack.Leave_top(destination);
				}
				
				if(!destination.size())
				{
					mission=cc.mission_kuo;
					return 1;
					/*
					if(On_occupy_max_kuo_node())
					{						
						protocol.Recharge();
						break;
					}
					destination=Go_to_not_occupy_max_kuo_node();
					d_stack.Leave_top(destination);		*/
				}
				
				if(!destination.size())
				{
					destination=Go_to_not_occupy_max_value_node();
					d_stack.Leave_top(destination);					
				}
			
				if(destination.size())
				{
					z=destination.top();
				
					if(!Can_go_to(z))
						D.Error("g09uy894yaq4jy4");
				
					zs=name.Int_to_string(z);
					protocol.Goto(zs);
					
					break;
				}
				
				protocol.Recharge();	
				break;
				D.Error("No destination");
				return 1;
			}
		return 1;
	}
	
	
	///e
	
	void Have_not_parryed_unkown_role_enermy_on_ass()
	{
		//z
		
		int i;
		for(i=0;i<enermy_agent.size();i++)
		{
			
		}
	}
	/*
	bool On_occupy_max_kuo_node()
	{
		log.writeln("------------------On_occupy_max_kuo_node() 1");
		
		bool ret;
		ret=0;
		int i;
		int z;
		int flag;
		
		int n=name.Get_n();
		for(i=1;i<=n;i++)
		{
			node[i].v=0;
			node[i].bound=0;
		}
			
		for(i=0;i<kuo_d[0].d.size();i++)
		{
			z=kuo_d[0].d[i];
			if(!node[z].can_visit[agent_pi])
				continue;
			if(node[z].v)
				continue;
				
			node[z].bound=1;
		}
		
		if(node[position_int].bound)
		{
			flag=0;
			for(i=0;i<agent_p.size();i++)
			{
				if(agent_p[i]->agent_name==agent_name)
					continue;
				if(agent_p[i]->health==0)
					continue;
				if(agent_p[i]->position_int!=position_int)
					continue;
				if(agent_p[i]->level>level)
					continue;
					
				flag=1;
			}
			if(flag)ret=0;
			else ret=1;
		}
		
		//for(i=0;i<ret.size();i++)
	//	cout<<i<<' '<<name.Int_to_string(ret.top())<<' '<<agent_name<<endl;
		
		log.writeln("------------------On_occupy_max_kuo_node() 2");
		return ret;
	}*
	
	stack<int> Go_to_not_occupy_max_kuo_node()
	{
		log.writeln("------------------Go_to_not_occupy_max_kuo_node() 1");
				
		stack<int> ret;
		d_stack.Clear(ret);
		int i;
		int z;
		int flag;
		
		int n=name.Get_n();
		for(i=1;i<=n;i++)
		{
			node[i].v=0;
			node[i].bound=0;
		}
			
		for(i=0;i<kuo_d[0].d.size();i++)
		{
			z=kuo_d[0].d[i];
			if(!node[z].can_visit[agent_pi])
				continue;
			if(node[z].v)
				continue;
				
			node[z].bound=1;
		}
		
		if(node[position_int].bound)
		{
			flag=0;
			for(i=0;i<agent_p.size();i++)
			{
				if(agent_p[i]->agent_name==agent_name)
					continue;
				if(agent_p[i]->health==0)
					continue;
				if(agent_p[i]->position_int!=position_int)
					continue;
				if(agent_p[i]->level>level)
					continue;
					
				flag=1;
			}
			
			if(!flag)
			return d_stack.Empty_stack();
		}
				
		for(i=0;i<agent_p.size();i++)
		{
			if(agent_p[i]->agent_name==agent_name)
				continue;
			if((agent_p[i]->health)==0)
				continue;
			if(!node[agent_p[i]->position_int].bound)
				continue;
			node[agent_p[i]->position_int].bound=0;			
		}
		
		z=0;
		for(i=1;i<=n;i++)
		if(node[i].bound)z=1;
		
		if(!z)
			return d_stack.Empty_stack();
			
		ret=dijkstra.Run(position_int,node);
		log.writeln(ret.size());
		
		
		if(ret.size()==0)
		{
			cout<<agent_name<<endl;
			for(i=1;i<=n;i++)
			{
				cout<<i<<' '<<name.Int_to_string(i)<<' '<<node[i].v<<' '<<node[i].bound<<endl;
			}
			D.Error("53089yuhjioae4i78");
		}
		
		//for(i=0;i<ret.size();i++)
	//	cout<<i<<' '<<name.Int_to_string(ret.top())<<' '<<agent_name<<endl;
		
		log.writeln("------------------Go_to_not_occupy_max_kuo_node() 2");
		return ret;
	}*/
	
	stack<int> Go_to_not_occupy_max_value_node()
	{
		log.writeln("------------------Go_to_not_occupy_max_value_node() 1");
		stack<int> ret;
		d_stack.Clear(ret);
		int i;
		int z;
		int flag;
		
		int n=name.Get_n();
		for(i=1;i<=n;i++)
		{
			node[i].v=0;
			node[i].bound=0;
		}
		
		for(i=0;i<agent_p.size();i++)
		{
			if(agent_p[i]->agent_name==agent_name)
				continue;
			if((agent_p[i]->health)==0)
				continue;
			node[agent_p[i]->position_int].v=1;			
		}
		
		z=-1;
		for(i=1;i<=n;i++)
		if(!node[i].v)
		{
			if(z<0 || node[z].value<node[i].value)
				z=i;
		}
		
		if(z<0)
			return d_stack.Empty_stack();
			
		if(node[z].value<=node[position_int].value)
		{
			flag=0;
			for(i=0;i<agent_p.size();i++)
			{
				if(agent_p[i]->agent_name==agent_name)
					continue;
				if(agent_p[i]->health==0)
					continue;
				if(agent_p[i]->position_int!=position_int)
					continue;
				if(agent_p[i]->level>level)
					continue;
					
				flag=1;
			}
			
			if(!flag)
			return d_stack.Empty_stack();
		}
		
		
		for(i=1;i<=n;i++)
		if(!node[i].v && node[i].value==node[z].value)
			node[i].bound=1;
		
		
		
		ret=dijkstra.Run(position_int,node);
		log.writeln(ret.size());
		
		
		if(ret.size()==0)
		{
			cout<<agent_name<<endl;
			for(i=1;i<=n;i++)
			{
				cout<<i<<' '<<name.Int_to_string(i)<<' '<<node[i].v<<' '<<node[i].bound<<endl;
			}
			D.Error("jy0943uy45ae3aher");
		}
		
		log.writeln("------------------Go_to_not_occupy_max_value_node() 2");
		return ret;				
	}
	
	
	int Should_repair_friend(vector<int> &r)
	{
		int z=rand()%r.size();
		return r[z];
	}
	
	int Should_attack_enermy(vector<int> &r)
	{
		int z=rand()%r.size();
		return r[z];
	}
	
	bool We_know_all_saboteur()
	{
		int sa=0;
		int sb=0;
		int i;
		for(i=0;i<agent_p.size();i++)
		if(agent_p[i]->simulation_role==cc.saboteur)
			sa++;
		for(i=0;i<enermy_agent.size();i++)
		if(enermy_agent[i].role==cc.saboteur)
			sb++;
		if(sa<sb)
			D.Error("jgireyh9s8rhgas");
		return sb==sa;
	}
	
	bool Last_time_on_one_enermy_agent_ass(string ret)
	{
		int s=0;
		int i;
		for(i=0;i<last_time_enermy_agent.size();i++)
		{
			if(last_time_enermy_agent[i].Status_is(cc.disabled,perception_id))
				continue;
			
			if(!last_time_enermy_agent[i].Node_is(position,perception_id))
				continue;
				
			s++;
			ret=last_time_enermy_agent[i].name;
		}
		if(s!=1)
			ret="";
		return s==1;
	}
	
	
	stack<int> Go_to_unkown_place_near_uninspected_enermy()
	{
		if(cc.debug_function_path)
			log.writeln("Go_to_unkown_place_near_uninspected_enermy() 1");
	
		int i,j,a,b,z,w;
		string zs;
		int n=name.Get_n();
				
		for(i=1;i<=n;i++)node[i].bound=-1;
		for(i=1;i<=n;i++)
		if(!node[i].is_surveyed)node[i].bound=0;
		
		
		queue<int> q;
		while(q.size())q.pop();
		for(i=1;i<=n;i++)
		{
			node[i].dis=-1;
			node[i].v=0;
		}
				
		for(i=0;i<enermy_agent.size();i++)
		{
			if(!enermy_agent[i].Get_node(zs,perception_id))
				continue;
				
			int znode=name.String_to_int(zs);									
			if(!node[znode].can_visit[agent_pi])
				continue;
				
			if(enermy_agent[i].is_inspected)
				continue;
			
				
			node[znode].dis=0;
			q.push(znode);
			node[znode].v=1;
		}
		
		while(q.size())
		{
			if(node[position_int].v)
				break;
				
			a=q.front();
			q.pop();
			for(i=1;i<=node[a].n;i++)
			{
				if(node[position_int].v)
					break;
				
				b=node[a].edge[i];
				if(node[b].v)continue;
				//if(node[b].bound==-1)continue;				
				if(node[b].dis!=-1 && node[b].dis<=node[a].dis+1)continue;
				node[b].dis=node[a].dis+1;
				node[b].v=1;
				q.push(b);
			}			
		}
		
		int da=-1,cost;
		for(i=1;i<=node[position_int].n;i++)
		{
			z=node[position_int].edge[i];
			w=node[position_int].edge_value[i];
			
			if(node[z].bound==0 && node[z].v)
			{
				if(da<0)
				{
					da=z;
					cost=w;
					continue;
				}
				if(node[da].dis<node[z].dis)continue;
				if(node[da].dis==node[z].dis && cost<w)continue;
				da=z;
				cost=w;
			}
		}

		if(da==-1)
		{
			D.Error("wgya4u4a3us "+agent_name);
		}	
		
		stack<int> ret;
		while(ret.size())ret.pop();
		ret.push(da);
		
		if(cc.debug_function_path)
			log.writeln("Go_to_unkown_place_near_uninspected_enermy() 2");
		return ret;
	}
	
	stack<int> Go_to_uninspected_enermy_near_known_place()
	{
		if(cc.debug_function_path)
			log.writeln("Go_to_enermy_near_known_place() 1");
	
		int i,j,a,b,z;
		string zs;
		int n=name.Get_n();
				
		for(i=1;i<=n;i++)node[i].bound=-1;
		
		for(i=1;i<=n;i++)
		if(node[i].is_surveyed && node[i].can_visit_through_surveyed_node[agent_pi])node[i].bound=0;
		
	

		
		queue<int> q;
		while(q.size())q.pop();
		
		for(i=1;i<=n;i++)
		{
			node[i].dis=-1;
			node[i].v=0;
		}
		
		for(i=0;i<enermy_agent.size();i++)
		{			
			if(!enermy_agent[i].Get_node(zs,perception_id))
				continue;
				
			z=name.String_to_int(zs);
			
			if(!node[z].can_visit[agent_pi])
				continue;
				
			if(enermy_agent[i].is_inspected)
				continue;
				
			node[z].dis=0;
			q.push(z);
			node[z].v=1;
		}
				
		while(q.size())
		{
			a=q.front();
			q.pop();
			for(i=1;i<=node[a].n;i++)
			{
				b=node[a].edge[i];
				if(node[b].v)
					continue;
				
				if(node[b].dis!=-1 && node[b].dis<=node[a].dis+1)
					continue;
					
				node[b].dis=node[a].dis+1;
				node[b].v=1;
				
				if(node[b].bound==0)
					continue;
					
				q.push(b);		
			}			
		}
		
		z=-1;
		for(i=1;i<=n;i++)
		if(node[i].bound==0 && node[i].v)
		if(z<0 || node[i].dis<node[z].dis)z=i;
		
		if(z<0)
			D.Error("djgarei0934ya "+agent_name);
		
		for(i=1;i<=n;i++)
		if(node[i].bound==0 && node[i].v)
		if(node[i].dis==node[z].dis)node[i].bound=1;
		
		if(node[z].dis<0)
			D.Error("09834uty983wqh4yw3y");
		
		stack<int> ret;
		while(ret.size())ret.pop();
		
		
		ret = dijkstra.Run(position_int,node);	
				
		if(cc.debug_function_path)
			log.writeln("Go_to_enermy_near_known_place() 2");
		return ret;
	}
	
	bool On_the_edge_of_survey_zone_near_uninspected_enermy()
	{
		if(cc.debug_function_path)
			log.writeln("On_the_edge_of_survey_zone_near_uninspected_enermy() 1");
	
		int i,j,a,b,z;
		string zs;
		int n=name.Get_n();
				
		for(i=1;i<=n;i++)node[i].bound=-1;
		
		for(i=1;i<=n;i++)
		if(node[i].is_surveyed && node[i].can_visit_through_surveyed_node[agent_pi])node[i].bound=0;
		
	

		
		queue<int> q;
		while(q.size())q.pop();
		
		for(i=1;i<=n;i++)
		{
			node[i].dis=-1;
			node[i].v=0;
		}
		
		for(i=0;i<enermy_agent.size();i++)
		{							
			if(!enermy_agent[i].Get_node(zs,perception_id))
				continue;
				
			z=name.String_to_int(zs);
			
			if(!node[z].can_visit[agent_pi])
				continue;
				
			if(enermy_agent[i].is_inspected)
				continue;
				
			node[z].dis=0;
			q.push(z);
			node[z].v=1;
		}
		
			
		
		while(q.size())
		{
			a=q.front();
			q.pop();
			for(i=1;i<=node[a].n;i++)
			{
				b=node[a].edge[i];
				if(node[b].v)
					continue;
				
				if(node[b].dis!=-1 && node[b].dis<=node[a].dis+1)
					continue;
					
				node[b].dis=node[a].dis+1;
				node[b].v=1;
				
				if(node[b].bound==0)
					continue;
					
				q.push(b);		
			}			
		}
		
		
		z=-1;
		for(i=1;i<=n;i++)
		if(node[i].bound==0 && node[i].v)
		if(z<0 || node[i].dis<node[z].dis)z=i;
		
		if(z<0)
			D.Error("hj8s934y0s4pyuha");
		
		for(i=1;i<=n;i++)
		if(node[i].bound==0 && node[i].v)
		if(node[i].dis==node[z].dis)node[i].bound=1;
		
		if(node[z].dis<0)
			D.Error("s45i65ytsw45i");
			
		if(cc.debug_function_path)
			log.writeln("On_the_edge_of_survey_zone_near_uninspected_enermy() 2");
			
		return node[position_int].dis==node[z].dis;	
	}
	
	stack<int> Go_to_uninspected_enermy()
	{
		if(cc.debug_function_path)
			log.writeln("Go_to_uninspected_enermy() 1");
	
		int i,j,b,z;
		string zs;
		int n=name.Get_n();
		
		
		for(i=1;i<=n;i++)node[i].bound=-1;
		for(i=1;i<=n;i++)
		if(node[i].is_surveyed)node[i].bound=0;
		
		
		for(i=0;i<enermy_agent.size();i++)
		{							
			if(!enermy_agent[i].Get_node(zs,perception_id))
				continue;
				
			z=name.String_to_int(zs);
			
			if(!node[z].can_visit_through_surveyed_node[agent_pi])
				continue;
				
			if(enermy_agent[i].is_inspected)
				continue;
				
			node[z].bound=1;
		}

	
		stack<int> ret;
		ret = dijkstra.Run(position_int,node);	
	
		if(cc.debug_function_path)		
			log.writeln("Go_to_uninspected_enermy() 2");

		return ret;
	}
	
	int Uninspected_enermy_can_visit_through_surveyed_node()
	{
		if(cc.debug_function_path)
			log.writeln("Uninspected_nermy_can_visit_through_surveyed_node() 1");
	
		int i,flag,z;
		string zs;
		
		for(i=0;i<enermy_agent.size();i++)
		{			
			if(!enermy_agent[i].Get_node(zs,perception_id))
				continue;
				
			z=name.String_to_int(zs);
			
			if(!node[z].can_visit_through_surveyed_node[agent_pi])
				continue;
				
			if(enermy_agent[i].is_inspected)
				continue;
				
			if(cc.debug_function_path)			
				log.writeln("Uninspected_nermy_can_visit_through_surveyed_node() 2");
			return 1;
		}
				
		if(cc.debug_function_path)
			log.writeln("Uninspected_nermy_can_visit_through_surveyed_node() 3");
	
		return 0;
	}
	
	bool On_the_edge_of_survey_zone_near_repairer()
	{
		if(cc.debug_function_path)
			log.writeln("On_the_edge_of_survey_zone_near_repairer() 1");
	
	
		int i,j,a,b,z;
		string zs;
		int n=name.Get_n();
		
		
		for(i=1;i<=n;i++)node[i].bound=-1;
				
		for(i=1;i<=n;i++)
		if(node[i].is_surveyed && node[i].can_visit_through_surveyed_node[agent_pi])node[i].bound=0;
		
		

		
		queue<int> q;
		while(q.size())q.pop();
		
		for(i=1;i<=n;i++)
		{
			node[i].dis=-1;
			node[i].v=0;
		}
	
		
		for(i=0;i<agent_p.size();i++)
		{			
			if(agent_p[i]->simulation_role!=cc.repairer)
				continue;
			if(agent_p[i]->agent_name==agent_name)
				continue;
			if(agent_p[i]->health==0)
				continue;	
				
			z=agent_p[i]->position_int;
						
			if(!node[z].can_visit[agent_pi])
				continue;
									
			node[z].dis=0;
			q.push(z);
			node[z].v=1;
		}
		
		
		while(q.size())
		{
			a=q.front();
			q.pop();
			for(i=1;i<=node[a].n;i++)
			{
				b=node[a].edge[i];
				if(node[b].v)
					continue;
				
				if(node[b].dis!=-1 && node[b].dis<=node[a].dis+1)
					continue;
					
				node[b].dis=node[a].dis+1;
				node[b].v=1;
				
				if(node[b].bound==0)
					continue;
					
				q.push(b);		
			}			
		}
		
		
		z=-1;
		for(i=1;i<=n;i++)
		if(node[i].bound==0 && node[i].v)
		if(z<0 || node[i].dis<node[z].dis)z=i;
		
		if(z<0)
		{
			return 0;
			D.Error("8y943neh;rahee "+agent_name);
		}
		
		for(i=1;i<=n;i++)
		if(node[i].bound==0 && node[i].v)
		if(node[i].dis==node[z].dis)node[i].bound=1;
		
		if(node[z].dis<0)
			D.Error("s45i65ytsw45i");
			
		if(cc.debug_function_path)
			log.writeln("On_the_edge_of_survey_zone_near_repairer() 2");
			
		return node[position_int].dis==node[z].dis;	
	}
	
	
	stack<int> Go_to_reachable_repairer_by_surveyed_position()
	{
		if(cc.debug_function_path)
			log.writeln("Go_to_reachable_repairer_by_surveyed_position() 1");
		int i,flag,z;
		string zs;
		int n=name.Get_n();
		
		
		for(i=1;i<=n;i++)node[i].bound=-1;
		for(i=1;i<=n;i++)
		if(node[i].is_surveyed)node[i].bound=0;
				
		
		for(i=0;i<agent_p.size();i++)
		{	
			if(agent_p[i]->simulation_role!=cc.repairer)
				continue;
			if(agent_p[i]->agent_name==agent_name)
				continue;
			if(agent_p[i]->health==0)
				continue;	
				
			z=agent_p[i]->position_int;
			if(!node[z].can_visit_through_surveyed_node[agent_pi])
				continue;	
			node[z].bound=1;
		}
		
		stack<int> ret=dijkstra.Run(position_int,node);

		if(cc.debug_function_path)		
			log.writeln("Go_to_reachable_repairer_by_surveyed_position() 2");
		
		return ret;
	}
	
	bool Repairer_is_reachable_by_surveyed_position()
	{
		if(cc.debug_function_path)
			log.writeln("Repairer_is_reachable_by_surveyed_position() 1");
		int i,flag,z;
		string zs;
		int ret=0;
	
		
		
		for(i=0;i<agent_p.size();i++)
		{	
			if(agent_p[i]->simulation_role!=cc.repairer)
				continue;
			if(agent_p[i]->agent_name==agent_name)
				continue;
			if(agent_p[i]->health==0)
				continue;	
				
			z=agent_p[i]->position_int;
			if(!node[z].can_visit_through_surveyed_node[agent_pi])
				continue;
			log.write("Repairer_is_reachable_by_surveyed_position() = ");
			log.writeln(agent_p[i]->agent_name);
			ret=1;
		}
		return ret;
	}
	
	bool Find_repairer()
	{
		log.writeln("Find_repairer() 1");
		int i,z;
		string zs;
		int ret=0;
				
		for(i=0;i<agent_p.size();i++)
		{
			if(agent_p[i]->simulation_role!=cc.repairer)
				continue;
			if(agent_p[i]->agent_name==agent_name)
				continue;
			if(agent_p[i]->health==0)
				continue;	
			
			z=agent_p[i]->position_int;
			if(!node[z].can_visit[agent_pi])
				continue;
				
			log.write("--------- repairer is reachable : ");
			log.writeln(agent_p[i]->agent_name);
			ret=1;
		}
		return ret;						
	}
	
	bool On_repairer_ass()
	{
		log.writeln("--------- On_repairer_ass()1");
		int i,z;
		for(i=0;i<agent_p.size();i++)
		{
			if(agent_p[i]->simulation_role!=cc.repairer)
				continue;
			if(agent_p[i]->agent_name==agent_name)
				continue;
			if(agent_p[i]->health==0)
				continue;	
			
			z=agent_p[i]->position_int;
			if(z!=position_int)
				continue;
				
			log.write("--------- On_repairer_ass()2 ");
			return 1;
		}
		log.writeln("--------- On_repairer_ass()3");
		return 0;
	}
	
	int Near_uninspected_enermy_ass()
	{
		if(cc.debug_function_path)
				log.writeln(" Near_uninspected_enermy_ass(string &ret) 1");
		int ret;
		int i;
		string zs;
		int z;
		ret=0;
					
		for(i=0;i<enermy_agent.size();i++)
		{
			if(enermy_agent[i].is_inspected)
				continue;
			
			if(!enermy_agent[i].Get_node(zs,perception_id))
				continue;
			
			if(zs==position)
			{
				ret=1;
				break;
			}
			
			z=name.String_to_int(zs);
			
			if(!d_vector.Find(vertex_near,z))
				continue;
			
			
			ret=1;
			
			if(cc.debug_function_path)
				log.writeln(" Near_uninspected_enermy_ass(string &ret) 2");
			break;
		}			
		
		if(cc.debug_function_path)
			log.writeln("Near_uninspected_enermy_ass(string &ret) 3");
		return ret;
	}
	
	bool Near_repairer_ass(string &ret)
	{
		log.writeln("--------- Near_repairer_ass(string &ret)1");
		int i,z;
		for(i=0;i<agent_p.size();i++)
		{
			if(agent_p[i]->simulation_role!=cc.repairer)
				continue;
			if(agent_p[i]->agent_name==agent_name)
				continue;
			if(agent_p[i]->health==0)
				continue;	
			
			z=agent_p[i]->position_int;
			if(!d_vector.Find(vertex_near,z))
				continue;
				
			ret=agent_p[i]->position;
			log.write("--------- Near_repairer_ass(string &ret)2 = ");
			log.writeln(ret);
			return 1;
		}
		log.writeln("--------- Near_repairer_ass(string &ret)3");
		return 0;
	}
	
	double Low_energy_rate()
	{
		if(health==0)
			return 0.5;
		else
			return 0.5;
	}
	
	bool Can_buy()
	{
		return can_buy_battery || can_buy_sensor ||	can_buy_shield ||	can_buy_sabotageDevice;
	}
	
	bool I_am_not_use_max_money()
	{
		log.writeln("-------------- I_use_lowest_money() 1");
		int a=oo;
		int b=0;
		int i;
		if(!Can_buy())
		{
			log.writeln("---------------- I can not buy");
			return 0;
		}
				
		for(i=0;i<agent_p.size();i++)
		{
			if(!agent_p[i]->Can_buy())
				continue;
			a=min(a,agent_p[i]->used_money);
			b=max(b,agent_p[i]->used_money);
		}
		
		log.write("min used money = ");
		log.writeln(a);
		
		log.write("max used money = ");
		log.writeln(b);
		
		if(a==used_money)
			return 1;
		if(used_money<b)
			return 1;
		return 0;
	}
	
	

	void Do_order(vector<string> r)
	{
		if(r[0]==cc.repair)
			protocol.Repair(r[1]);
		else if(r[0]==cc.goto_)
			protocol.Goto(r[1]);
		else if(r[0]==cc.attack)
			protocol.Attack(r[1]);
		else if(r[0]==cc.survey)
			protocol.Survey();
		else if(r[0]==cc.inspect)
			protocol.Inspect();
		else if(r[0]==cc.recharge)
			protocol.Recharge();
		else if(r[0]==cc.probe)
			protocol.Probe();
		else if(r[0]==cc.skip)
			protocol.Skip();
		else
			D.Error("fjsiga9rgha");
	}

	
	void Sim_end()
	{
		//D.Error("successfully end");
	}
	
	int Get_infor()
	{
		log.writeln("---------------------Get_infor() 1");
		string zs;
		vector<string> zv;
		int i,j;
		
		XML xml;	
		xml.To_vector(net_msg,net_msg_n,zv,xml_tmp);
		log.write("xml to vector size  = ");
		log.writeln(zv.size());
		
		for(i=0;i<net_msg_n;i++)
			net_msg[i]=0;
		net_msg_n=0;
		
		if(zv.size()%2)
			D.Error("aeyua84uya34");
		
		for(i=0;i<zv.size();i+=2)
		{
			if(i+1>=zv.size())
				D.Error("GJW94WJHw3943");
			
			if(zv[i]==cc.message_timestamp) 
				continue;
						
			if(zv[i]==cc.message_type) 
			{
				if(zv[i+1]==cc.request_action)continue;
				if(zv[i+1]==cc.sim_end)
				{
					sim_end=1;
					continue;
				}
				cout<<zv[i+1]<<endl;
				D.Error("iga9834yu98qayu");
				continue;
			}
			
			if(zv[i]==cc.sim_result_ranking)
			{
				sim_result_ranking=str.String_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==cc.sim_result_score)
			{
				sim_result_score=str.String_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==cc.perception_deadline) 
			{				
				continue;
			}
						
			if(zv[i]==cc.perception_id) 
			{
				perception_id=str.String_to_int(zv[i+1]);
				protocol.Set_id(perception_id);
			//	net_file.Set_perception_id(perception_id);
				continue;
			}
			
			if(zv[i]==cc.simulation_step) 
			{
				simulation_step=str.String_to_int(zv[i+1]);
				continue;
			}
							
			if(zv[i]==cc.self_energy) 
			{
				energy = str.String_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==cc.self_health) 
			{
				health = str.String_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==cc.self_lastAction) 
			{
				last_action = zv[i+1];
				continue;
			}
			
			if(zv[i]==cc.self_lastActionParam) 
			{
				last_action_param = zv[i+1];
				continue;
			}
			
			if(zv[i]==cc.self_lastActionResult) 
			{
				last_action_result = zv[i+1];
				continue;
			}
			
			if(zv[i]==cc.self_maxEnergy)
			{
				max_energy = str.String_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==cc.self_maxEnergyDisabled)
			{
				max_energy_disabled = str.String_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==cc.self_maxHealth)
			{
				max_health = str.String_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==cc.self_position) 
			{				
				position = zv[i+1];
				position_int=name.String_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==cc.self_strength)
			{
				strength = str.String_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==cc.self_visRange)
			{
				vis_range = str.String_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==cc.self_zoneScore)
			{
				zone_score = str.String_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==cc.team_lastStepScore)
			{
				team_last_step_score = str.String_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==cc.team_money)
			{
				team_money = str.String_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==cc.team_score)
			{
				team_score = str.String_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==cc.team_zonesScore)
			{
				team_zones_score = str.String_to_int(zv[i+1]);
				continue;
			}
			
			if(zv[i]==cc.achievement_name)
			{
				achievement_name.push_back(zv[i+1]);
				continue;
			}
			
			if(zv[i]==cc.visibleVertex_name)
			{
				visible_vertex_name.push_back(zv[i+1]);
				continue;
			}
			
			if(zv[i]==cc.visibleVertex_team)
			{
				visible_vertex_team.push_back(zv[i+1]);
				continue;
			}
			
			if(zv[i]==cc.visibleEdge_node1)
			{
				visible_edge_node1.push_back(zv[i+1]);
				continue;
			}
			
			if(zv[i]==cc.visibleEdge_node2)
			{
				visible_edge_node2.push_back(zv[i+1]);
				continue;
			}
			
			if(zv[i]==cc.visibleEntity_name)
			{
				visible_entity_name.push_back(zv[i+1]);
				continue;
			}
			
			if(zv[i]==cc.visibleEntity_team)
			{
				visible_entity_team.push_back(zv[i+1]);
				continue;
			}
			
			if(zv[i]==cc.visibleEntity_node)
			{
				visible_entity_node.push_back(zv[i+1]);
				continue;
			}
			
			if(zv[i]==cc.visibleEntity_status)
			{
				visible_entity_status.push_back(zv[i+1]);
				continue;
			}
						
			if(zv[i]==cc.probedVertex_name)
			{				
				probed_vertex_name.push_back(zv[i+1]);
				continue;
			}
			
			if(zv[i]==cc.probedVertex_value)
			{				
				probed_bertex_value.push_back(str.String_to_int(zv[i+1]));
				continue;
			}
			
			if(zv[i]==cc.surveyedEdge_node1)
			{				
				surveyed_edge_node1.push_back(name.String_to_int(zv[i+1]));
				continue;
			}
			
			if(zv[i]==cc.surveyedEdge_node2)
			{			
				surveyed_edge_node2.push_back(name.String_to_int(zv[i+1]));	
				continue;
			}
			
			if(zv[i]==cc.surveyedEdge_weight)
			{			
				surveyed_edge_weight.push_back(str.String_to_int(zv[i+1]));	
				continue;
			}
			
			if(zv[i]==cc.inspectedEntity_energy)
			{			
				inspected_entity_energy.push_back(str.String_to_int(zv[i+1]));	
				continue;
			}
			
			if(zv[i]==cc.inspectedEntity_health)
			{			
				inspected_entity_health.push_back(str.String_to_int(zv[i+1]));	
				continue;
			}
			
			if(zv[i]==cc.inspectedEntity_maxEnergy)
			{			
				inspected_entity_max_energy.push_back(str.String_to_int(zv[i+1]));	
				continue;
			}
			
			if(zv[i]==cc.inspectedEntity_maxHealth)
			{			
				inspected_entity_max_health.push_back(str.String_to_int(zv[i+1]));	
				continue;
			}
			
			if(zv[i]==cc.inspectedEntity_name)
			{			
				inspected_entity_name.push_back(zv[i+1]);	
				continue;
			}
			
			if(zv[i]==cc.inspectedEntity_node)
			{			
				inspected_entity_node.push_back(zv[i+1]);	
				continue;
			}
			
			if(zv[i]==cc.inspectedEntity_role)
			{			
				inspected_entity_role.push_back(zv[i+1]);	
				continue;
			}
			
			if(zv[i]==cc.inspectedEntity_strength)
			{			
				inspected_entity_strength.push_back(str.String_to_int(zv[i+1]));	
				continue;
			}
			
			if(zv[i]==cc.inspectedEntity_team)
			{			
				inspected_entity_team.push_back(zv[i+1]);	
				continue;
			}
			
			if(zv[i]==cc.inspectedEntity_visRange)
			{			
				inspected_entity_vis_range.push_back(str.String_to_int(zv[i+1]));	
				continue;
			}
			
			{
				cout<<agent_name<<endl;
				cout<<zv[i]<<endl;
				cout<<zv[i+1]<<endl;
				D.Error("834uwy3haGHWOEha");
			}
		}
		log.writeln("---------------------Get_infor 2");
	}
	
	void Del_useless_infor(vector<string> &r)
	{
		vector<string> d;
		int i;
		
		d.clear();
		for(i=0;i<r.size();i+=2)
		{
			if(r[i]==cc.version)continue;
			if(r[i]==cc.encoding)continue;
			if(r[i]==cc.timestamp)continue;
			if(r[i]==cc.type)continue;
			if(r[i]==cc.deadline)continue;
		
			d.push_back(r[i]);
			if(i+1>=r.size())
				D.Error("GWOHE9y4jhw4wreah");
			
			d.push_back(r[i+1]);
		}
		
		r=d;
	}
	
	int Friend_have_pain_in_the_ass(string friend_name)
	{
	//	cout<<"Friend_have_pain_in_the_as() 1"<<endl;
		int z,a,b;
		z=agent_name_map[friend_name]-1;
		
	//	cout<<"Friend_have_pain_in_the_as() 2"<<endl;
		return agent_p[z]->Have_pain_in_the_ass();
	}
	
	bool All_enermy_is_dead()
	{
		if(cc.debug_function_path)
			log.writeln("All_enermy_is_dead 1");
		int n=visible_entity_name.size();
		if(n!=cc.agent_n)return 0;
		
		int i;
		for(i=0;i<visible_entity_name.size();i++)
		{	
			if(visible_entity_team[i]!=team)continue;
//			if(visible_entity_status[i]==cc.disabled)continue;
			if(name.String_to_int(visible_entity_node[i])!=position_int)continue;

			if(cc.debug_function_path)
				log.writeln("All_enermy_is_dead 2");
			return 1;
		}
		
		if(cc.debug_function_path)
			log.writeln("All_enermy_is_dead 3");
		return 0;
	}
	
	
	stack<int> Go_to_reachable_friend_by_surveyed_position()
	{
		if(cc.debug_function_path)
			log.writeln("Go_to_reachable_friend_by_surveyed_position() 1");
		int i,flag,z;
		string zs;
		int n=name.Get_n();
		
		
		for(i=1;i<=n;i++)node[i].bound=-1;
		for(i=1;i<=n;i++)
		if(node[i].is_surveyed)node[i].bound=0;
		
		
		for(i=0;i<agent_p.size();i++)
		{	
			if(agent_p[i]->agent_name==agent_name)
				continue;
			
			if(!agent_p[i]->Have_pain_in_the_ass())
				continue;
				
			z=agent_p[i]->position_int;
			if(!node[z].can_visit_through_surveyed_node[agent_pi])
				continue;	
			node[z].bound=1;
		}
		
		stack<int> ret=dijkstra.Run(position_int,node);

		if(cc.debug_function_path)		
			log.writeln("Go_to_reachable_friend_by_surveyed_position() 2");
		
		return ret;
	}
	
	int Pain_friend_is_reachable_by_surveyed_position()
	{
		if(cc.debug_function_path)
			log.writeln("Pain_friend_is_reachable_by_surveyed_position() 1");
		int i,flag,z;
		string zs;
				
		for(i=0;i<agent_p.size();i++)
		{	
			if(!agent_p[i]->Have_pain_in_the_ass())
				continue;
			
			if(agent_p[i]->agent_name==agent_name)
				continue;
				
			z=agent_p[i]->position_int;
			if(!node[z].can_visit_through_surveyed_node[agent_pi])
				continue;
			return 1;
		}
		return 0;
	}
	
	stack<int> Go_to_unkown_place_near_repairer_with_smallest_edge()
	{
		if(cc.debug_function_path)
			log.writeln("Go_to_unkown_place_near_repairer_with_smallest_edge() 1");
		int i,j,a,b,z,w;
		string zs;
		int n=name.Get_n();
		
		
		for(i=1;i<=n;i++)node[i].bound=-1;
		for(i=1;i<=n;i++)
		if(!node[i].is_surveyed)node[i].bound=0;
		
		
		queue<int> q;
		while(q.size())q.pop();
		for(i=1;i<=n;i++)
		{
			node[i].dis=-1;
			node[i].v=0;
		}
				
		for(i=0;i<agent_p.size();i++)		
		{	
			if(agent_p[i]->simulation_role!=cc.repairer)
				continue;
			if(agent_p[i]->agent_name==agent_name)
				continue;
			if(agent_p[i]->health==0)
				continue;
				
			z=agent_p[i]->position_int;		
			
			if(!node[z].can_visit[agent_pi])
				continue;
			
			node[z].dis=0;
			q.push(z);
			node[z].v=1;
		}
		
		
		while(q.size())
		{
			if(node[position_int].v)
				break;
				
			a=q.front();
			q.pop();
			for(i=1;i<=node[a].n;i++)
			{
				if(node[position_int].v)
					break;
				
				b=node[a].edge[i];
				if(node[b].v)continue;
				//if(node[b].bound==-1)continue;
				if(node[b].dis!=-1 && node[b].dis<=node[a].dis+1)continue;
				node[b].dis=node[a].dis+1;
				node[b].v=1;
				q.push(b);
			}			
		}
		
		int da=-1;
		for(i=1;i<=node[position_int].n;i++)
		{
			z=node[position_int].edge[i];
			
			if(node[z].bound==0 && node[z].v)
			{
				if(da<0)
				{
					da=z;
					continue;
				}
				if(node[da].dis<node[z].dis)continue;
				da=z;
			}
		}

		if(da==-1)
		{
			for(i=1;i<=n;i++)
			cout<<i<<' '<<name.Int_to_string(i)<<' '<<node[i].bound<<' '<<node[i].dis<<endl;
			D.Error("wa3e6rdsuus4");
		}	
		
		stack<int> ret;
		while(ret.size())ret.pop();
		ret.push(da);
	
		if(cc.debug_function_path)	
			log.writeln("Go_to_unkown_place_near_repairer_with_smallest_edge() 2");
		return ret;
	}
	
	stack<int> Go_to_unkown_place_near_friend()
	{
		if(cc.debug_function_path)
			log.writeln("Go_to_unkown_place_near_friend() 1");
		int i,j,a,b,z,w;
		string zs;
		int n=name.Get_n();
		
		
		for(i=1;i<=n;i++)node[i].bound=-1;
		for(i=1;i<=n;i++)
		if(!node[i].is_surveyed)node[i].bound=0;
		
		
		queue<int> q;
		while(q.size())q.pop();
		for(i=1;i<=n;i++)
		{
			node[i].dis=-1;
			node[i].v=0;
		}
				
		for(i=0;i<agent_p.size();i++)		
		{	
			if(agent_p[i]->agent_name==agent_name)
				continue;
			
			if(!agent_p[i]->Have_pain_in_the_ass())
				continue;
				
			z=agent_p[i]->position_int;		
			
			if(!node[z].can_visit[agent_pi])
				continue;
			
			node[z].dis=0;
			q.push(z);
			node[z].v=1;
		}
		
		
		while(q.size())
		{
			if(node[position_int].v)
				break;
					
			a=q.front();
			q.pop();
			for(i=1;i<=node[a].n;i++)
			{
				if(node[position_int].v)
					break;
					
				b=node[a].edge[i];
				if(node[b].v)continue;
				
				//if(node[b].bound==-1)continue;
				if(node[b].dis!=-1 && node[b].dis<=node[a].dis+1)continue;
				node[b].dis=node[a].dis+1;
				node[b].v=1;
				q.push(b);
			}			
		}
		
		int da=-1,cost;
		for(i=1;i<=node[position_int].n;i++)
		{
			z=node[position_int].edge[i];
			w=node[position_int].edge_value[i];
			
			if(node[z].bound==0 && node[z].v)
			{
				if(da<0)
				{
					da=z;
					cost=w;
					continue;
				}
				if(node[da].dis<node[z].dis)continue;
				if(node[da].dis==node[z].dis && cost<w)continue;
				da=z;
				cost=w;
			}
		}

		if(da==-1)
		{
			for(i=1;i<=n;i++)
			cout<<i<<' '<<name.Int_to_string(i)<<' '<<node[i].bound<<' '<<node[i].dis<<endl;
			
			cout<<agent_name<<endl;
			D.Error("ghruw4587ayh4");
		}	
		
		stack<int> ret;
		while(ret.size())ret.pop();
		ret.push(da);
	
		if(cc.debug_function_path)	
			log.writeln("Go_to_unkown_place_near_friend() 2");
		return ret;
	}
	
	bool On_the_edge_of_survey_zone_near_friend()
	{
		if(cc.debug_function_path)
			log.writeln("On_the_edge_of_survey_zone_near_friend() 1");
	
		int i,j,a,b,z;
		string zs;
		int n=name.Get_n();
		
		
		for(i=1;i<=n;i++)node[i].bound=-1;
				
		for(i=1;i<=n;i++)
		if(node[i].is_surveyed && node[i].can_visit_through_surveyed_node[agent_pi])node[i].bound=0;
		
	

		
		queue<int> q;
		while(q.size())q.pop();
		
		for(i=1;i<=n;i++)
		{
			node[i].dis=-1;
			node[i].v=0;
		}
	
		
		for(i=0;i<agent_p.size();i++)
		{			
			if(agent_p[i]->agent_name==agent_name)
				continue;
			if(!agent_p[i]->Have_pain_in_the_ass())
				continue;
				
			z=agent_p[i]->position_int;
						
			if(!node[z].can_visit[agent_pi])
				continue;
									
			node[z].dis=0;
			q.push(z);
			node[z].v=1;
		}
		
		
		while(q.size())
		{
			a=q.front();
			q.pop();
			for(i=1;i<=node[a].n;i++)
			{
				b=node[a].edge[i];
				if(node[b].v)
					continue;
				
				if(node[b].dis!=-1 && node[b].dis<=node[a].dis+1)
					continue;
					
				node[b].dis=node[a].dis+1;
				node[b].v=1;
				
				if(node[b].bound==0)
					continue;
					
				q.push(b);		
			}			
		}
		
		
		z=-1;
		for(i=1;i<=n;i++)
		if(node[i].bound==0 && node[i].v)
		if(z<0 || node[i].dis<node[z].dis)z=i;
		
		if(z<0)
		{
			return 0;
			D.Error("s45itkSwaulouy");
		}
		
		for(i=1;i<=n;i++)
		if(node[i].bound==0 && node[i].v)
		if(node[i].dis==node[z].dis)node[i].bound=1;
		
		if(node[z].dis<0)
			D.Error("s45i65ytsw45i");
			
		if(cc.debug_function_path)
			log.writeln("On_the_edge_of_survey_zone_near_friend() 2");
			
		return node[position_int].dis==node[z].dis;	
	}

	bool On_the_edge_of_survey_zone_near_enermy()
	{
		if(cc.debug_function_path)
			log.writeln("On_the_edge_of_survey_zone_near_enermy() 1");
	
		int i,j,a,b,z;
		string zs;
		int n=name.Get_n();
				
		for(i=1;i<=n;i++)node[i].bound=-1;
		
		for(i=1;i<=n;i++)
		if(node[i].is_surveyed && node[i].can_visit_through_surveyed_node[agent_pi])node[i].bound=0;
		
	

		
		queue<int> q;
		while(q.size())q.pop();
		
		for(i=1;i<=n;i++)
		{
			node[i].dis=-1;
			node[i].v=0;
		}
		
		for(i=0;i<enermy_agent.size();i++)
		{
			if(d_vector.Find(cc.do_not_attack,enermy_agent[i].name))
				continue;
			
			if(enermy_agent[i].Status_is(cc.disabled,perception_id))
				continue;
				
			if(!enermy_agent[i].Get_node(zs,perception_id))
				continue;
				
			z=name.String_to_int(zs);
			
			if(!node[z].can_visit[agent_pi])
				continue;
				
			node[z].dis=0;
			q.push(z);
			node[z].v=1;
		}
				
		
		while(q.size())
		{
			a=q.front();
			q.pop();
			for(i=1;i<=node[a].n;i++)
			{
				b=node[a].edge[i];
				if(node[b].v)
					continue;
				
				if(node[b].dis!=-1 && node[b].dis<=node[a].dis+1)
					continue;
					
				node[b].dis=node[a].dis+1;
				node[b].v=1;
				
				if(node[b].bound==0)
					continue;
					
				q.push(b);		
			}			
		}
		
		
		z=-1;
		for(i=1;i<=n;i++)
		if(node[i].bound==0 && node[i].v)
		if(z<0 || node[i].dis<node[z].dis)z=i;
		
		if(z<0)
		{
			return 0;
			D.Error("903yu4hjererjst");
		}
		
		for(i=1;i<=n;i++)
		if(node[i].bound==0 && node[i].v)
		if(node[i].dis==node[z].dis)node[i].bound=1;
		
		if(node[z].dis<0)
			D.Error("s45i65ytsw45i");
			
		if(cc.debug_function_path)
			log.writeln("On_the_edge_of_survey_zone_near_enermy() 2");
			
		return node[position_int].dis==node[z].dis;	
	}
	
	
	stack<int> Go_to_unkown_place_near_enermy()
	{
		if(cc.debug_function_path)
			log.writeln("Go_to_unkown_place_near_enermy() 1");
	
		int i,j,a,b,z,w;
		string zs;
		int n=name.Get_n();
				
		for(i=1;i<=n;i++)node[i].bound=-1;
		for(i=1;i<=n;i++)
		if(!node[i].is_surveyed)node[i].bound=0;
		
		
		queue<int> q;
		while(q.size())q.pop();
		for(i=1;i<=n;i++)
		{
			node[i].dis=-1;
			node[i].v=0;
		}
		
		for(i=0;i<enermy_agent.size();i++)
		{
			if(d_vector.Find(cc.do_not_attack,enermy_agent[i].name))
				continue;
			
			if(enermy_agent[i].Status_is(cc.disabled,perception_id))
				continue;
				
			if(!enermy_agent[i].Get_node(zs,perception_id))
				continue;
				
			z=name.String_to_int(zs);
			
			if(!node[z].can_visit[agent_pi])
			node[z].bound=1;
			
			node[z].dis=0;
			q.push(z);
			node[z].v=1;
		}
		
		
		while(q.size())
		{
			if(node[position_int].v)
				break;
				
			a=q.front();
			q.pop();
			for(i=1;i<=node[a].n;i++)
			{
				if(node[position_int].v)
					break;
				
				b=node[a].edge[i];
				if(node[b].v)continue;
				//if(node[b].bound==-1)continue;				
				if(node[b].dis!=-1 && node[b].dis<=node[a].dis+1)continue;
				node[b].dis=node[a].dis+1;
				node[b].v=1;
				q.push(b);
			}			
		}
		
		int da=-1,cost;
		for(i=1;i<=node[position_int].n;i++)
		{
			z=node[position_int].edge[i];
			w=node[position_int].edge_value[i];
		//	cout<<z<<' '<<node[z].bound<<' '<<node[z].v<<endl;
			if(node[z].bound==0 && node[z].v)
			{
				if(da<0)
				{
					da=z;
					cost=w;
					continue;
				}
				if(node[da].dis<node[z].dis)continue;
				if(node[da].dis==node[z].dis && cost<w)continue;
				da=z;
				cost=w;
			}
		}

		if(da==-1)
		{
			D.Error("erusrjus "+agent_name);
		}	
		
		stack<int> ret;
		while(ret.size())ret.pop();
		ret.push(da);
		
		if(cc.debug_function_path)
			log.writeln("Go_to_unkown_place_near_enermy() 2");
		return ret;
	}
	
	stack<int> Go_to_edge_of_surveyed_zone_near_repairer_place_with_smallest_edge()
	{
		if(cc.debug_function_path)
			log.writeln("Go_to_edge_of_surveyed_zone_near_repairer_place_with_smallest_edge() 1");
	
		int i,flag,z;
		int a,b;
		string zs;
		int n=name.Get_n();
			
		for(i=1;i<=n;i++)node[i].bound=-1;
				
		for(i=1;i<=n;i++)
		if(node[i].is_surveyed && node[i].can_visit_through_surveyed_node[agent_pi])node[i].bound=0;
		
		queue<int> q;
		while(q.size())q.pop();
		
		for(i=1;i<=n;i++)
		{
			node[i].dis=-1;
			node[i].v=0;
		}
		
		//cout<<"-------------- 1"<<endl;
		
		for(i=0;i<agent_p.size();i++)
		{
			if(agent_p[i]->simulation_role!=cc.repairer)
				continue;
			if(agent_p[i]->agent_name==agent_name)
				continue;
			if(agent_p[i]->health==0)
				continue;
			z=(agent_p[i]->position_int);
			
		//	cout<<agent_p[i]->agent_name<<' '<<i<<' '<<z<<' '<<(agent_p[i]->position_int)<<endl;
			
			if(!node[z].can_visit[agent_pi])continue;
			node[z].dis=0;
			q.push(z);
			node[z].v=1;
		}
		
	//	cout<<"-------------- 2"<<endl;
		while(q.size())
		{
			a=q.front();
			q.pop();
			for(i=1;i<=node[a].n;i++)
			{
				b=node[a].edge[i];
				if(node[b].v)
					continue;
				
				if(node[b].dis!=-1 && node[b].dis<=node[a].dis+1)
					continue;
					
				node[b].dis=node[a].dis+1;
				node[b].v=1;
				
				if(node[b].bound==0)
					continue;
					
				q.push(b);		
			}			
		}
		
	//	cout<<"-------------- 3"<<endl;
		
		z=-1;
		for(i=1;i<=n;i++)
		if(node[i].bound==0 && node[i].v)
		if(z<0 || node[i].dis<node[z].dis)z=i;
		
		if(z<0)
			D.Error("56a45trj65");
		
		for(i=1;i<=n;i++)
		if(node[i].bound==0 && node[i].v)
		if(node[i].dis==node[z].dis)node[i].bound=1;
		
		if(node[z].dis<0)
			D.Error("7oru55ixty987q34");
		

	
		stack<int> ret;
	//	cout<<"-------------- 4"<<endl;
		ret = bfs.Run(position_int,node);	
	//	cout<<"-------------- 5"<<endl;
		if(cc.debug_function_path)	
			log.writeln("Go_to_edge_of_surveyed_zone_near_repairer_place_with_smallest_edge() 2");
		
		return ret;
	}
	
	stack<int> Go_to_edge_of_surveyed_zone_near_friend_place()
	{
		if(cc.debug_function_path)
			log.writeln("Go_to_edge_of_surveyed_zone_near_friend_place() 1");
	
		int i,flag,z;
		int a,b;
		string zs;
		int n=name.Get_n();
				
		for(i=1;i<=n;i++)node[i].bound=-1;
		
		for(i=1;i<=n;i++)
		if(node[i].is_surveyed && node[i].can_visit_through_surveyed_node[agent_pi])node[i].bound=0;
		
		queue<int> q;
		while(q.size())q.pop();
		
		for(i=1;i<=n;i++)
		{
			node[i].dis=-1;
			node[i].v=0;
		}
		
		
		for(i=0;i<agent_p.size();i++)
		{
			if(agent_p[i]->agent_name==agent_name)
				continue;
			
			if(!agent_p[i]->Have_pain_in_the_ass())
				continue;
				
			z=agent_p[i]->position_int;
			
			if(!node[z].can_visit[agent_pi])continue;
			node[z].dis=0;
			q.push(z);
			node[z].v=1;
		}
		
		
		while(q.size())
		{
			a=q.front();
			q.pop();
			for(i=1;i<=node[a].n;i++)
			{
				b=node[a].edge[i];
				if(node[b].v)
					continue;
				
				if(node[b].dis!=-1 && node[b].dis<=node[a].dis+1)
					continue;
					
				node[b].dis=node[a].dis+1;
				node[b].v=1;
				
				if(node[b].bound==0)
					continue;
					
				q.push(b);		
			}			
		}
		
		z=-1;
		for(i=1;i<=n;i++)
		if(node[i].bound==0 && node[i].v)
		if(z<0 || node[i].dis<node[z].dis)z=i;
		
		if(z<0)
			D.Error("56a45trj65");
		
		for(i=1;i<=n;i++)
		if(node[i].bound==0 && node[i].v)
		if(node[i].dis==node[z].dis)node[i].bound=1;
		
		if(node[z].dis<0)
			D.Error("7oru55ixty987q34");
		

	
		stack<int> ret;
		
		ret = dijkstra.Run(position_int,node);	
	
		if(cc.debug_function_path)	
			log.writeln("Go_to_edge_of_surveyed_zone_near_friend_place() 2");
		
		return ret;
	}
	
	void Can_visit_through_surveyed_node()
	{
		if(cc.debug_function_path)
			log.writeln("Can_visit_through_surveyed_node(vector<bool> &d) 1");
		int i,j,k;
		int a,b;
		int n=name.Get_n();
		for(i=0;i<=n;i++)
			node[i].can_visit_through_surveyed_node[agent_pi]=0;
		
		queue<int> q;
		d_queue.Clear(q);
		
		q.push(position_int);
		node[position_int].can_visit_through_surveyed_node[agent_pi]=1;
		
		
		
		while(q.size())
		{
			a=q.front();
			//cout<<"a "<<a<<' '<<name.Int_to_string(a)<<endl;
			q.pop();
			for(i=1;i<=node[a].n;i++)
			{
				b=node[a].edge[i];
				if(node[b].can_visit_through_surveyed_node[agent_pi])continue;				
				node[b].can_visit_through_surveyed_node[agent_pi]=1;
			//	cout<<"b "<<b<<' '<<name.Int_to_string(b)<<endl;
				if(!node[b].is_surveyed)continue;
			//	cout<<"p "<<b<<' '<<name.Int_to_string(b)<<endl;
				q.push(b);
			}
		}
		
		//for(i=1;i<=n;i++)
		//if(d[i])cout<<i<<' '<<name.Int_to_string(i)<<endl;
		
		if(cc.debug_function_path)
			log.writeln("Can_visit_through_surveyed_node(vector<bool> &d) 2");
	}
	
	///c
	void Calc_value_for_agent_in_kuo_mission()
	{
		if(cc.debug_function_path)
			log.writeln("Calc_value_for_agent_in_kuo_mission() 1");
		int i,j,b,z;
		string zs;
		int s=0;
		int n=name.Get_n();
		
				
		for(i=1;i<=n;i++)
			node[i].bound=-1;
		for(i=1;i<=n;i++)
		if(node[i].is_surveyed)node[i].bound=0;
			
		dijkstra.Run_calc_value_for_agent(position_int,node,agent_pi);
		
		
		for(i=1;i<=n;i++)
		node[i].v=0;
		
		for(i=0;i<kuo_d[0].d.size();i++)
		node[kuo_d[0].d[i]].v=1;
		
		for(i=1;i<=n;i++)
		if(node[i].v)
		{
			node[i].bound=1;
			s++;
		}
		
		if(node[position_int].bound<0)
		{
			node[position_int].bound=1;
			s++;
		}
		///cout<<agent_name<<' '<<s;
		
		for(i=1;i<=n;i++)
		if(node[i].bound!=1)
		node[i].value_for_agent[agent_pi]=oo;
		
		int flag=0;
		s=0;
		for(i=1;i<=n;i++)
		if(node[i].value_for_agent[agent_pi]<oo)
		{
			flag=1;
			s++;
		}
		//cout<<s<<endl;
		
		if(!flag)
		{
			cout<<kuo_d[0].d.size()<<endl;
			for(i=0;i<kuo_d[0].d.size();i++)
			cout<<kuo_d[0].d[i]<<' ';
			cout<<endl;
			
			D.Error("j4t43a8yujrga");
		}
		
		if(cc.debug_function_path)
			log.writeln("Calc_value_for_agent_in_kuo_mission() 2");
	}
	
	void Calc_value_for_agent_in_servey_mission()
	{
		if(cc.debug_function_path)
			log.writeln("Calc_value_for_agent_in_servey_mission() 1");
		int i,j,b,z;
		string zs;
		int n=name.Get_n();
				
		for(i=1;i<=n;i++)
			node[i].bound=-1;
		for(i=1;i<=n;i++)
		if(node[i].is_surveyed && node[i].can_visit_through_surveyed_node[agent_pi])
		{
			node[i].bound=0;
		//	cout<<"bound 0 = "<<i<<' '<<name.Int_to_string(i)<<' '<<agent_name<<endl;
		}
			
						
		dijkstra.Run_calc_value_for_agent(position_int,node,agent_pi);
		
		for(i=1;i<=n;i++)
		if(node[i].bound==-1 && node[i].can_visit_through_surveyed_node[agent_pi])
		{
			for(j=1;j<=node[i].n;j++)
			{
				b=node[i].edge[j];
				if(node[b].bound==0)
				{
					node[i].bound=1;
				//	cout<<"bound 1 = "<<i<<' '<<name.Int_to_string(i)<<' '<<node[i].value_for_agent[agent_pi]<<endl;
					break;
				}
			}
		}
		
		for(i=1;i<=n;i++)
		if(node[i].bound!=1)
		node[i].value_for_agent[agent_pi]=oo;
		
		
		if(cc.debug_function_path)
			log.writeln("Calc_value_for_agent_in_servey_mission() 2");
	}
	
	void Calc_value_for_agent_in_probe_mission()
	{
		if(cc.debug_function_path)
			log.writeln("Calc_value_for_agent_in_probe_mission() 1");
		int i,j,b,z;
		string zs;
		int n=name.Get_n();
				
		for(i=1;i<=n;i++)
			node[i].bound=-1;
		for(i=1;i<=n;i++)
		if(node[i].is_probed && node[i].is_surveyed && node[i].can_visit_through_surveyed_node[agent_pi])node[i].bound=0;
		
				
		dijkstra.Run_calc_value_for_agent(position_int,node,agent_pi);
		
		
		for(i=1;i<=n;i++)
		if(node[i].bound==-1 && node[i].can_visit_through_surveyed_node[agent_pi])
		{
			for(j=1;j<=node[i].n;j++)
			{
				b=node[i].edge[j];
				if(node[b].bound==0)
				{
					node[i].bound=1;
					break;
				}
			}
		}
		
		
		for(i=1;i<=n;i++)
		if(node[i].bound!=1)
		node[i].value_for_agent[agent_pi]=oo;
			
		if(cc.debug_function_path)
			log.writeln("Calc_value_for_agent_in_probe_mission() 2");
	}
	
	void Can_visit_node()
	{
		if(cc.debug_function_path)
			log.writeln("Can_visit_node(vector<bool> &d) 1");
		int i,j,k;
		int a,b;
		int n=name.Get_n();
		for(i=0;i<=n;i++)
			node[i].can_visit[agent_pi]=0;
		
		queue<int> q;
		d_queue.Clear(q);
		
		q.push(position_int);
		node[position_int].can_visit[agent_pi]=1;
		
		while(q.size())
		{
			a=q.front();
			q.pop();
			for(i=1;i<=node[a].n;i++)
			{
				b=node[a].edge[i];
				if(node[b].can_visit[agent_pi])continue;
				node[b].can_visit[agent_pi]=1;
				q.push(b);
			}
		}
		
		/*for(i=1;i<=n;i++)
		if(d[i])
		{
			log.write(i);
			log.write(" ");
			log.writeln(name.Int_to_string(i));
		}*/
		
		if(cc.debug_function_path)
			log.writeln("Can_visit_node(vector<bool> &d) 2");
	}
	
	
	
	stack<int> Go_to_enermy_near_known_place()
	{
		if(cc.debug_function_path)
			log.writeln("Go_to_enermy_near_known_place() 1");
	
		int i,j,a,b,z;
		string zs;
		int n=name.Get_n();
				
		for(i=1;i<=n;i++)node[i].bound=-1;
		
		for(i=1;i<=n;i++)
		if(node[i].is_surveyed && node[i].can_visit_through_surveyed_node[agent_pi])node[i].bound=0;
		
	

		
		queue<int> q;
		while(q.size())q.pop();
		
		for(i=1;i<=n;i++)
		{
			node[i].dis=-1;
			node[i].v=0;
		}
		
		for(i=0;i<enermy_agent.size();i++)
		{			
			if(d_vector.Find(cc.do_not_attack,enermy_agent[i].name))
				continue;
				
			if(enermy_agent[i].Status_is(cc.disabled,perception_id))
				continue;
				
			if(!enermy_agent[i].Get_node(zs,perception_id))
				continue;
				
			z=name.String_to_int(zs);
			
			if(!node[z].can_visit[agent_pi])
				continue;
				
			node[z].dis=0;
			q.push(z);
			node[z].v=1;
		}
				
		
		while(q.size())
		{
			a=q.front();
			q.pop();
			for(i=1;i<=node[a].n;i++)
			{
				b=node[a].edge[i];
				if(node[b].v)
					continue;
				
				if(node[b].dis!=-1 && node[b].dis<=node[a].dis+1)
					continue;
					
				node[b].dis=node[a].dis+1;
				node[b].v=1;
				
				if(node[b].bound==0)
					continue;
					
				q.push(b);		
			}			
		}
		
		z=-1;
		for(i=1;i<=n;i++)
		if(node[i].bound==0 && node[i].v)
		if(z<0 || node[i].dis<node[z].dis)z=i;
		
		if(z<0)
			D.Error("djgarei0934ya");
		
		for(i=1;i<=n;i++)
		if(node[i].bound==0 && node[i].v)
		if(node[i].dis==node[z].dis)node[i].bound=1;
		
		if(node[z].dis<0)
			D.Error("09834uty983wqh4yw3y");
		
		stack<int> ret;
		while(ret.size())ret.pop();
		
		
		ret = dijkstra.Run(position_int,node);	
				
		if(cc.debug_function_path)
			log.writeln("Go_to_enermy_near_known_place() 2");
		return ret;
	}
	
	int Enermy_can_visit_through_surveyed_node()
	{
		if(cc.debug_function_path)
			log.writeln("Enermy_can_visit_through_surveyed_node() 1");
	
		int i,flag,z;
		string zs;
				
		for(i=0;i<enermy_agent.size();i++)
		{
			if(d_vector.Find(cc.do_not_attack,enermy_agent[i].name))
				continue;
			if(enermy_agent[i].Status_is(cc.disabled,perception_id))
				continue;
				
			if(!enermy_agent[i].Get_node(zs,perception_id))
				continue;
			
			z=name.String_to_int(zs);
			if(!node[z].can_visit_through_surveyed_node[agent_pi])
				continue;
				
			if(cc.debug_function_path)			
				log.writeln("Enermy_can_visit_through_surveyed_node() 2");
				
			return 1;
		}
		
		
		if(cc.debug_function_path)
			log.writeln("Enermy_can_visit_through_surveyed_node() 3");
	
		return 0;
	}
	
	
	/*
	int Friend_hear_has_pain_in_the_ass(string &ret)
	{
		if(cc.debug_function_path)
			log.writeln("Friend_hear_has_pain_in_the_ass() 1");
	
		int i,z;
		string zs;
		ret="";
		for(i=0;i<visible_entity_name.size();i++)
		{	
			if(visible_entity_team[i]!=team)continue;
//			if(visible_entity_status[i]==cc.disabled)continue;
			if(name.String_to_int(visible_entity_node[i])!=position)continue;

			if(!friend_agents.Have_pain_in_the_ass(zs))continue;
			ret=visible_entity_name[i];
		
			if(cc.debug_function_path)
				log.writeln("Friend_hear_has_pain_in_the_ass() 2");
			return 1;
		}
	
		if(cc.debug_function_path)
			log.writeln("Friend_hear_has_pain_in_the_ass() 3");
		return 0;
	}*/
	/*
	int On_friend_pain_ass(string &ret)
	{
		if(cc.debug_function_path)
			log.writeln("On_friend_ass() 1");
		int i;
		ret="";
		for(i=0;i<agent_p.size();i++)
		{	
			if(agent_p[i]->position!=position)
				continue;
				
			if(!agent_p[i]->Have_pain_in_the_ass())
				continue;
				
			if(agent_p[i]->agent_name==agent_name)
				continue;
				
			if(cc.debug_function_path)
				log.writeln("On_friend_ass() 2");
			
			ret=agent_p[i]->agent_name;
			return 1;
		}
		
		if(cc.debug_function_path)
			log.writeln("On_friend_ass() 3");
		return 0;
	}*/
	
	int On_friend_pain_ass(vector<int> &ret)
	{
		if(cc.debug_function_path)
			log.writeln("On_friend_pain_ass(vector<int> &ret) 1");
		int i;
		ret.clear();
		for(i=0;i<agent_p.size();i++)
		{	
			if(agent_p[i]->position!=position)
				continue;
				
			if(!agent_p[i]->Have_pain_in_the_ass())
				continue;
				
			if(agent_p[i]->agent_name==agent_name)
				continue;
				
			if(cc.debug_function_path)
				log.writeln("On_friend_pain_ass(vector<int> &ret) 2");
			
			ret.push_back(i);
		}
		
		if(cc.debug_function_path)
			log.writeln("On_friend_pain_ass(vector<int> &ret) 3");
		return ret.size();
	}
	
	int On_saboteur_friend_ass()
	{
		if(cc.debug_function_path)
				log.writeln("On_saboteur_friend_ass() 1");
	
		int i;
		string zs;
		//z
		for(i=0;i<agent_p.size();i++)
		{	
			if(agent_p[i]->health==0)
				continue;
			
			if(agent_p[i]->agent_name==agent_name)
				continue;
				
			if(agent_p[i]->simulation_role!=cc.saboteur)
				continue;
				
			if(agent_p[i]->position_int!=position_int)
				continue;				
			
			if(cc.debug_function_path)
				log.writeln("On_saboteur_friend_ass() 2");
			return 1;
		}
		
		if(cc.debug_function_path)
			log.writeln("On_saboteur_friend_ass() 3");
		return 0;
	}
	
	
	int Must_not_on_saboteur_enermy_ass()
	{
		if(cc.debug_function_path)
				log.writeln("Must_not_on_saboteur_enermy_ass() 1");
	
		int i;
		string zs;
		int z;
		int ret=0;
		
		if(On_saboteur_enermy_ass())
			return 0;
			
		for(i=0;i<enermy_agent.size();i++)
		{			
			if(enermy_agent[i].Status_is(cc.disabled,perception_id))
				continue;
				
			if(!enermy_agent[i].Get_node(zs,perception_id))
				continue;
				
			if(zs!=position)
				continue;
				
			if(enermy_agent[i].role!="")
				continue;
			
			if(cc.debug_function_path)
				log.writeln("On_saboteur_enermy_ass() 2");
			
			ret++;
		}
			
		if(!ret)
			return 0;

			
		if(!We_know_all_saboteur())
			return 0;
		
		if(cc.debug_function_path)
			log.writeln("Must_not_on_saboteur_enermy_ass() 3");
		return 1;
	}
	
	int On_saboteur_enermy_ass()
	{
		if(cc.debug_function_path)
				log.writeln("On_saboteur_enermy_ass() 1");
	
		int i;
		string zs;
		int z;
		
		for(i=0;i<enermy_agent.size();i++)
		{			
			if(enermy_agent[i].Status_is(cc.disabled,perception_id))
				continue;
				
			if(!enermy_agent[i].Get_node(zs,perception_id))
				continue;
				
			if(zs!=position)
				continue;	
				
			if(enermy_agent[i].role!=cc.saboteur)
				continue;
			
			if(cc.debug_function_path)
				log.writeln("On_saboteur_enermy_ass() 2");
			return 1;
		}
		
		if(cc.debug_function_path)
			log.writeln("On_saboteur_enermy_ass() 3");
		return 0;
	}
	
	int On_enermy_ass()
	{
		if(cc.debug_function_path)
				log.writeln("On_enermy_ass() 1");
	
		int i;
		string zs;
		for(i=0;i<enermy_agent.size();i++)
		{	
			if(enermy_agent[i].Status_is(cc.disabled,perception_id))
				continue;
				
			if(!enermy_agent[i].Get_node(zs,perception_id))
				continue;
			
			if(zs!=position)
				continue;
			
			if(cc.debug_function_path)
				log.writeln("On_enermy_ass() 2");
			return 1;
		}
		
		if(cc.debug_function_path)
			log.writeln("On_enermy_ass() 3");
		return 0;
	}
	
	int On_enermy_ass(vector<int> &ret)
	{
		if(cc.debug_function_path)
				log.writeln("On_enermy_ass(string &ret) 1");
	
		int i;
		ret.clear();
		
		for(i=0;i<enermy_agent.size();i++)
		{
			if(enermy_agent[i].Status_is(cc.disabled,perception_id))
				continue;
			if(!enermy_agent[i].Node_is(position,perception_id))
				continue;
			if(d_vector.Find(cc.do_not_attack,enermy_agent[i].name))
				continue;
				
			ret.push_back(i);			
		}
		if(cc.debug_function_path)
			log.writeln("On_enermy_ass(string &ret) 3");
		return ret.size();
	}
	
	stack<int> Go_to_enermy()
	{
		if(cc.debug_function_path)
			log.writeln("Go_to_enermy() 1");
	
		int i,j,b,z;
		string zs;
		int n=name.Get_n();
		
		
		for(i=1;i<=n;i++)node[i].bound=-1;
		for(i=1;i<=n;i++)
		if(node[i].is_surveyed)node[i].bound=0;
		
				
		for(i=0;i<enermy_agent.size();i++)
		{
			if(d_vector.Find(cc.do_not_attack,enermy_agent[i].name))
				continue;
			
			if(enermy_agent[i].Status_is(cc.disabled,perception_id))
				continue;
				
			if(!enermy_agent[i].Get_node(zs,perception_id))
				continue;
				
			z=name.String_to_int(zs);
			
			if(!node[z].can_visit_through_surveyed_node[agent_pi])continue;
			node[z].bound=1;
		}
	
		stack<int> ret;
		ret = dijkstra.Run(position_int,node);	
	
		if(cc.debug_function_path)		
			log.writeln("Go_to_enermy() 2");

		return ret;
	}
	
	bool Find_uninspected_enermy()
	{
		log.writeln("Find_uninspected_enermy() 1");
		int i;
		int z;
		string zs;
		
		for(i=0;i<enermy_agent.size();i++)
		{
			if(!enermy_agent[i].Get_node(zs,perception_id))
				continue;
				
			z=name.String_to_int(zs);
			
			if(!node[z].can_visit[agent_pi])
				continue;
				
			if(enermy_agent[i].is_inspected)
				continue;
				
			log.writeln(enermy_agent[i].name);
		}
		
		log.writeln("Find_uninspected_enermy() 2");
		
		for(i=0;i<enermy_agent.size();i++)
		{
			if(!enermy_agent[i].Get_node(zs,perception_id))
				continue;
				
			z=name.String_to_int(zs);
			
			if(!node[z].can_visit[agent_pi])
				continue;
				
			if(enermy_agent[i].is_inspected)
				continue;
				
			return 1;
		}
		
		return 0;
	}
	
	bool Find_enermy()
	{
		log.writeln("Find_enermy() 1");
		int i;
		int z;
		string zs;
		
		for(i=0;i<enermy_agent.size();i++)
		{			
			if(d_vector.Find(cc.do_not_attack,enermy_agent[i].name))
				continue;
			
			if(enermy_agent[i].Status_is(cc.disabled,perception_id))
				continue;
				
			if(!enermy_agent[i].Get_node(zs,perception_id))
				continue;
				
			z=name.String_to_int(zs);
			
			if(!node[z].can_visit[agent_pi])
				continue;
				
			log.writeln(enermy_agent[i].name);
		}
		
		for(i=0;i<enermy_agent.size();i++)
		{			
			if(d_vector.Find(cc.do_not_attack,enermy_agent[i].name))
				continue;
			
			if(enermy_agent[i].Status_is(cc.disabled,perception_id))
				continue;
				
			if(!enermy_agent[i].Get_node(zs,perception_id))
				continue;
				
			z=name.String_to_int(zs);
			
			if(!node[z].can_visit[agent_pi])
				continue;
				
			return 1;
		}				
		return 0;
	}
	
	bool Have_pain_in_the_ass()
	{		
		return health<max_health;
	}
	
	bool Find_friend_has_pain_in_the_ass()
	{
		log.writeln("Find_friend_has_pain_in_the_ass() 1");
		int i,z;
		string zs;
		
		
		for(i=0;i<agent_p.size();i++)
		if((agent_p[i]->agent_name)!=agent_name)
		{
			if(!agent_p[i]->Have_pain_in_the_ass())
				continue;
				
			if(!node[agent_p[i]->position_int].can_visit[agent_pi])
				continue;
				
			log.writeln(agent_p[i]->agent_name);
		}
			
		log.writeln("Find_friend_has_pain_in_the_ass() 1");
			
		for(i=0;i<agent_p.size();i++)
		if((agent_p[i]->agent_name)!=agent_name)
		{
			if(!agent_p[i]->Have_pain_in_the_ass())
				continue;
				
			if(!node[agent_p[i]->position_int].can_visit[agent_pi])
				continue;
				
			return 1;
		}
		
		return 0;						
	}
	
	
	
	
	
	
	int Can_go_to(int x)
	{
		int i;
		for(i=0;i<vertex_near.size();i++)
		if(vertex_near[i]==x)return 1;
		
		if(cc.debug_function_path)
			log.writeln("Can_go_to(int x)1: ");
		
		log.writeln(x);
		for(i=0;i<vertex_near.size();i++)
		{
			log.write(vertex_near[i]);
			log.write(" ");			
		}
		log.writeln("");
		
		
		log.writeln(name.Int_to_string(x));
		for(i=0;i<vertex_near.size();i++)
		{
			log.write(name.Int_to_string(vertex_near[i]));
			log.write(" ");			
		}
		log.writeln("");
		
		return 0;
	}
	
	///z
	stack<int> Mission_kuo(int destination)
	{
		if(cc.debug_function_path)
			log.writeln("=======================Mission_kuo(int destination)");
		stack<int> ret;
		int i,j,b,z;
		string zs;
		int n=name.Get_n();
		
		
		for(i=1;i<=n;i++)node[i].bound=-1;
		for(i=1;i<=n;i++)
		if(node[i].is_surveyed)node[i].bound=0;
		
		for(i=1;i<=n;i++)
		if(i==destination)
		{
			node[i].bound=1;
		}
		
		if(destination==position_int || node[position_int].bound==1)
		{
			d_stack.Clear(ret);
			ret.push(position_int);
			return ret;
		}

		
		 ret= dijkstra.Run(position_int,node);
		
		if(ret.size()==0)
		{
			for(i=1;i<=n;i++)
			cout<<i<<' '<<name.Int_to_string(i)<<' '<<node[i].bound<<endl;
			cout<<destination<<endl;
			cout<<node[destination].can_visit[agent_pi]<<endl;
			D.Error("34uri:G348a9y");
		}
		//d_stack.Write(ret);
	
		if(cc.debug_function_path)
			log.writeln("=======================Mission_kuo(int destination)2");
		
		return ret;
	}
	
	stack<int> Mission_not_explorer_min_cost_visit_bound(int destination)
	{
		if(cc.debug_function_path)
			log.writeln("=======================Mission_not_explorer_min_cost_visit_bound(int destination)");
		stack<int> ret;
		int i,j,b,z;
		string zs;
		int n=name.Get_n();
		
		
		for(i=1;i<=n;i++)node[i].bound=-1;
		for(i=1;i<=n;i++)
		if(node[i].is_surveyed)node[i].bound=0;
		
		for(i=1;i<=n;i++)
		if(i==destination)
		if(node[i].bound==-1)
		{
			for(j=1;j<=node[i].n;j++)
			{
				b=node[i].edge[j];
				if(node[b].bound==0)
				{
					node[i].bound=1;
					break;
				}
			}
		}
		
		if(destination==position_int || node[position_int].bound==1)
		{
			d_stack.Clear(ret);
			ret.push(position_int);
			return ret;
		}
		
		ret= dijkstra.Run(position_int,node);
		
		
		//d_stack.Write(ret);
	
		if(cc.debug_function_path)
			log.writeln("=======================Mission_not_explorer_min_cost_visit_bound(int destination)2");
		
		return ret;
	}
	/*
	stack<int> Not_explorer_min_cost_visit_bound()
	{
		if(cc.debug_function_path)
			log.writeln("=======================Not_explorer_min_cost_visit_bound()");
	
		
		
		int i,j,b,z;
		string zs;
		int n=name.Get_n();
		
		
		for(i=1;i<=n;i++)node[i].bound=-1;
		for(i=1;i<=n;i++)
		if(node[i].is_surveyed)node[i].bound=0;
		
		for(i=1;i<=n;i++)
		if(node[i].bound==-1)
		{
			for(j=1;j<=node[i].n;j++)
			{
				b=node[i].edge[j];
				if(node[b].bound==0)
				{
					node[i].bound=1;
					break;
				}
			}
		}
		
		

		
		stack<int> ret= dijkstra.Run(position_int,node);
		
		
		//d_stack.Write(ret);
	
		if(cc.debug_function_path)
			log.writeln("=======================Not_explorer_min_cost_visit_bound()2");
		
		return ret;
	}*/
	
	
	stack<int> Mission_explorer_min_cost_visit_bound(int destination)
	{
		if(cc.debug_function_path)
			log.writeln("=======================Min_cost_visit_bound()");
		stack<int> ret;
		int i,j,b,z;
		string zs;
		int n=name.Get_n();
		int flag=0;
		
	//	mission=cc.mission_explorer_min_cost_visit_bound;		
		
		for(i=1;i<=n;i++)node[i].bound=-1;
		for(i=1;i<=n;i++)
		if(node[i].is_probed && node[i].is_surveyed)node[i].bound=0;
		
		for(i=1;i<=n;i++)
		if(i==destination)
		if(node[i].bound==-1)
		{
			for(j=1;j<=node[i].n;j++)
			{
				b=node[i].edge[j];
				if(node[b].bound==0)
				{
					flag=1;
					node[i].bound=1;
					break;
				}
			}
		}
		
		if(destination==position_int || node[position_int].bound==1)
		{
			d_stack.Clear(ret);
			ret.push(position_int);
			return ret;
		}
		
		if(!flag)
		{
			cout<<destination<<endl;
			cout<<name.Int_to_string(destination)<<endl;
			D.Error("ioery894s5y8943y");
		}
		

		
		ret = dijkstra.Run(position_int,node);
	
		if(cc.debug_function_path)			
			log.writeln("=======================Min_cost_visit_bound()");
		return ret;
	}
	
	int Have_not_surveyed_node()
	{
		if(cc.debug_function_path)
			log.writeln("=======================Have_not_surveyed_node()");
		int ret=0;
		int i,j,b,z;
		string zs;
		int n=name.Get_n();
					
		
		for(i=1;i<=n;i++)
		if(!node[i].is_surveyed)
			ret++;
			
		if(cc.debug_function_path)			
			log.writeln("=======================Have_not_surveyed_node()");
		return ret;
	}
	
	int Have_not_probed_node()
	{
		if(cc.debug_function_path)
			log.writeln("=======================Have_not_probed_node()");
		int ret=0;
		int i,j,b,z;
		string zs;
		int n=name.Get_n();
					
		
		for(i=1;i<=n;i++)
		if(!node[i].is_probed)
			ret++;
			
		if(cc.debug_function_path)			
			log.writeln("=======================Have_not_probed_node()");
		return ret;
	}
	
	/*stack<int> Explorer_min_cost_visit_bound()
	{
		if(cc.debug_function_path)
			log.writeln("=======================Min_cost_visit_bound()");
		stack<int> ret;
		int i,j,b,z;
		string zs;
		int n=name.Get_n();
					
		
		for(i=1;i<=n;i++)node[i].bound=-1;
		for(i=1;i<=n;i++)
		if(node[i].is_probed && node[i].is_surveyed)node[i].bound=0;
		
		for(i=1;i<=n;i++)
		if(node[i].bound==-1)
		{
			for(j=1;j<=node[i].n;j++)
			{
				b=node[i].edge[j];
				if(node[b].bound==0)
				{
					node[i].bound=1;
					break;
				}
			}
		}
		

		
		ret = dijkstra.Run(position_int,node);
	
		if(cc.debug_function_path)			
			log.writeln("=======================Min_cost_visit_bound()");
		return ret;
	}*/
	
	void Learn_from_sight()
	{
	//	if(cc.debug_function_path)
	//		log.writeln("---------------------Learn_from_sight()1");
		int i,a,b,c,z;
		string sa,sb;
		string zs;
		
		
		for(i=0;i<enermy_agent.size();i++)
		{
			enermy_agent[i].perception_id=perception_id;
		}
		
		for(i=0;i<agent_p.size();i++)
		if(agent_p[i]->agent_name==agent_name)
		{
			level=i;
			if(simulation_role==cc.saboteur)
			{
				level+=100;
				continue;
			}
			if(simulation_role==cc.repairer) 
			{
				level+=100;
				continue;
			}
		}
		
		can_buy_battery=1;
		can_buy_sensor=1;
		can_buy_shield=1;
		can_buy_sabotageDevice=1;
		
		if(simulation_role==cc.explorer)
		{
			can_buy_sabotageDevice=0;
		}
		else if(simulation_role==cc.saboteur) 
		{
		}
		else if(simulation_role==cc.repairer) 
		{
			can_buy_sabotageDevice=0;
		}
		else if(simulation_role==cc.inspector)
		{
			can_buy_sabotageDevice=0;
		}
		else
		{
			can_buy_sabotageDevice=0;
		}
		
		if(!d_vector.Find(cc.can_buy_role,simulation_role))
		{
			for(i=0;i<cc.can_buy_role.size();i++)
				log.writeln(cc.can_buy_role[i]);
			log.writeln(simulation_role);
			log.writeln("-------------- I am not can buy money role");
			can_buy_battery=0;
			can_buy_sensor=0;
			can_buy_shield=0;
			can_buy_sabotageDevice=0;
		}
		
		
		
		for(i=0;i<visible_vertex_name.size();i++)
			name.String_to_int(visible_vertex_name[i]);
		
		

		
		for(i=0;i<visible_edge_node1.size();i++)
		{
			sa=visible_edge_node1[i];
			sb=visible_edge_node2[i];
			a=name.String_to_int(sa);
			b=name.String_to_int(sb);
			node[a].Add_edge(b);
			node[b].Add_edge(a);
		}
		
		
		z=position_int;
		node[z].visited=1;
		
		
		for(i=0;i<surveyed_edge_node1.size();i++)
		{
			a=surveyed_edge_node1[i];
			b=surveyed_edge_node2[i];
			c=surveyed_edge_weight[i];
			node[a].Add_surveyed_edge(b,c);
			node[b].Add_surveyed_edge(a,c);
		}
		
		for(i=0;i<probed_vertex_name.size();i++)
		{
			a=name.String_to_int(probed_vertex_name[i]);
			b=probed_bertex_value[i];
			node[a].Set_value(a,b);
		}
		
		for(i=0;i<visible_entity_name.size();i++)
		if(visible_entity_name[i]==agent_name)
		{
			team=visible_entity_team[i];
			//status=visible_entity_status[i];
		}
		
		for(i=0;i<visible_entity_name.size();i++)
		{
			if(visible_entity_team[i]==team)
				continue;
				
			zs=visible_entity_name[i];
			z=enermy_agent_name.String_to_int(zs);			
			enermy_agent[z].name=zs;
			enermy_agent[z].Update_node(visible_entity_node[i],perception_id);
			enermy_agent[z].Update_status(visible_entity_status[i],perception_id);
		}
		
		
		//cout<<inspected_entity_name.size()<<endl;
		//cout<<enermy_agent.size()<<endl;
		for(i=0;i<inspected_entity_name.size();i++)
		{
			zs=inspected_entity_name[i];
			z=enermy_agent_name.String_to_int(zs);
			//cout<<i<<' '<<z<<endl;
			enermy_agent[z].is_inspected=1;
			enermy_agent[z].inspect_time_id=perception_id;
			
			enermy_agent[z].name=inspected_entity_name[i];
			enermy_agent[z].energy=inspected_entity_energy[i];
			enermy_agent[z].health=inspected_entity_health[i];
			enermy_agent[z].maxEnergy=inspected_entity_max_energy[i];
			enermy_agent[z].maxHealth=inspected_entity_max_health[i];
			enermy_agent[z].Update_node(inspected_entity_node[i],perception_id);
			enermy_agent[z].role=inspected_entity_role[i];
			enermy_agent[z].strength=inspected_entity_strength[i];
			enermy_agent[z].team=inspected_entity_team[i];
			enermy_agent[z].visRange=inspected_entity_vis_range[i];
		}

		if(cc.debug_function_path)		
			log.writeln("---------------------Learn_from_sight() 2");
	}
	
	
	
	
	/*
	void Write_node()
	{
		int i,j;
		int n=name.Get_n();
	//	cout<<"write node["<<endl;
		for(i=1;i<=n;i++)
		{
			for(j=1;j<=node[i].n;j++)
				cout<<i<<' '<<node[i].edge[j]<<endl;
		}
	//	cout<<"write node]"<<endl;
	}
	*/
	
	
	
	///m	

	
	int level;
	int used_money;
	
	int can_buy_battery;
	int can_buy_sensor;
	int can_buy_shield;
	int can_buy_sabotageDevice;
	
	int auth_msg_n;
	char auth_msg[min_msg_length];
	int sim_msg_n;
	char sim_msg[min_msg_length];
	int buff_n;
	char buff[max_msg_length];
	int net_msg_n;
	char net_msg[max_msg_length];
	int xml_tmp[max_msg_length];
	
	Log log;
	Log msg_file;
	Net net;
	int no_action_count;
	
	int agent_pi;
	vector<Agent*> agent_p;
	map<string,int> agent_name_map;
	
	stack<int> destination;
	
	Protocol protocol;
	
	
	string agent_password;
	
	//int id;
	//int vertices;
	int step;
	int energy;
	int health;
	string last_action;
	string last_action_param;
	string last_action_result;
	int max_energy;
	int max_energy_disabled;
	int max_health;
	string position;
	int position_int;
	int strength;
	int vis_range;
	int zone_score;
	int last_step_score;
	int score;
	int zones_score;
	
	
	vector<string> visible_vertex_name;
	vector<string> visible_vertex_team;
	vector<string> visible_entity_name;
	vector<string> visible_entity_node;
	vector<string> visible_entity_status;
	vector<string> visible_entity_team;
		
	vector<string> visible_edge_node1;
	vector<string> visible_edge_node2;	
	vector<string> achievement_name;
	vector<string> probed_vertex_name;
	vector<int> probed_bertex_value;
	vector<int> surveyed_edge_node1;
	vector<int> surveyed_edge_node2;
	vector<int> surveyed_edge_weight;
	vector<int> inspected_entity_energy;
	vector<int> inspected_entity_health;
	vector<int> inspected_entity_max_energy;
	vector<int> inspected_entity_max_health;
	vector<string> inspected_entity_name;
	vector<string> inspected_entity_node;
	vector<string> inspected_entity_role;
	vector<int> inspected_entity_strength;
	vector<string> inspected_entity_team;
	vector<int> inspected_entity_vis_range;
	
	
	vector<int> vertex_near;
	
//	map<string,int> vertex_name;
//	int visit_vertex[max_vertex_number

	string lastAction_result;
//	XML xml;
	
	int simulation_step;
	int team_last_step_score;
	int team_money;
	int team_score;
	int team_zones_score;
	int simulation_edges;
	int simulation_id;
	string simulation_role;
	int simulation_steps;
	int simulation_vertices;
	

	string team;
//	string status;
		
	
};

void *thread_main_auth(void *arg)
{
	Agent *p;
	p=(Agent*)arg;
	
	p->Auth_request_send();	
	p->Send_order();
	
	return((void *)0);
}

void *thread_listen_main(void *arg)
{
	Agent *p;
	p=(Agent*)arg;
	

	//cout<<"thread : I am start ."<<endl;

	
	while(1)
	{
		pthread_mutex_lock(&p->pr.lock);
	//	pthread_cond_signal(&p->pr.thread_start);
	//cout<<"thread : I am waiting start signal ."<<endl;
		p->pr.thread_start=1;
		pthread_cond_wait(&p->pr.net_msg_signal_start, &p->pr.lock);
		
		
		p->pr.thread_start=0;
	//	
	//	cout<<"thread : I have start signal ."<<endl;
	//	cout<<12345<<endl;
		
		pthread_cond_init(&p->pr.net_msg_signal_start, NULL);
		
		p->net_msg_signal_done=0;
		p->net_msg_signal_start=0;
	//	p->net_msg_signal_ready=1;
		pthread_mutex_unlock(&p->pr.lock);	
		
		
		p->Listen();	
			
		p->net_msg_signal_done=1;	
		
	}	
	
	return((void *)0);
}


void *thread_send_main(void *arg)
{
	Agent *p;
	p=(Agent*)arg;
	
	p->Send_order();
	
	
	return((void *)0);
}


///wa
class Wang_Yuxin_class
{
public:	
	void Init(string agent_name_password_ini_file,int x_clear_flag)
	{		
		int i;
		kuo_d.clear();
		kuo.Init(&log);	
		sim_result_score.clear();
		sim_result_ranking.clear();
		
		clear_flag=x_clear_flag;
		
		
		
		vector<string> info;		
		node.clear();
		
		enermy_agent.clear();
		name.Init();
		enermy_agent_name.Init();
		
		Node Z;
		node.push_back(Z);
		
		d_file.Clear("WYX");
		agent_n=0;
		agent_name.clear();
		agent_password.clear();
		
		/////
		agent_name_password_ini.Init(agent_name_password_ini_file);		
		agent_name_password_ini.Read(info);
		
		//for(i=0;i<info.size();i++)
		//	cout<<info[i]<<endl;
		
		if(info.size()%2)
			D.Error("4u90yjserhjasi");
			
		for(i=0;i<info.size();i+=2)
		{
			if(d_vector.Find(agent_name,info[i]))
			{
			//	cout<<info[i]<<endl;
				D.Error("u8yw94ypwjy");
			}
			agent_name.push_back(info[i]);
			agent_password.push_back(info[i+1]);
			agent_n++;
		}
		string zs=(agent_name[0]);
		zs=zs[0];
		log.Init("./log/"+zs+"WYX.log");
			log.Clear();
		
	//	cout<<"======== "<<agent_n<<endl;
				
		ip_port_file.Init(cc.ip_port_file_name);
		ip_port_file.Read(ip,port);	
		if(ip.size()!=agent_n || port.size()!=agent_n)
			D.Error("jwte0jta");		
		
		//for(i=0;i<agent_n;i++)
		//cout<<ip[i]<<' '<<port[i]<<endl;
		//while(1);
		
		agent.resize(agent_n);	
		for(i=0;i<agent_n;i++)
		if(!agent[i].Init(agent_name[i],agent_password[i],agent_name,agent,clear_flag,ip[i],port[i]))
			D.Error("jw9et9ayte");
	
		vector<int> pid;
		pid.resize(agent_n);
		
		vector<pthread_t> tid;
		tid.resize(agent_n);
		
		Thread_listen();
		
		
		
		All_net_msg_signal_start();
		
		
		
		Wait_all_net_msg_signal_ready();
		
		//cout<<"Auth_request_send() ghserhusrju"<<endl;
		for(i=0;i<agent_n;i++)
			agent[i].Auth_request_send();
			
			
		Wait_all_auth_msg();
		for(i=0;i<agent_n;i++)
		{
			if(agent[i].Auth_request()==0)
				D.Error("a475ke7oi5");	
		}
			
			
		Wait_all_sim_msg();
		for(i=0;i<agent_n;i++)		
		{
			if(!agent[i].Sim_start())
				D.Error("a3y45a3ui");
			else
				cout<<agent_name[i]<<" sim start"<<endl;
		}
		
		
		Wait_all_net_msg_signal_done();
		
		
		
		
		
		
		//All_net_msg_signal_start();
		//Wait_all_net_msg_signal_ready();
		//Wait_all_net_msg_signal_done();
		
		
		
		
		
		
		
		/*
		cout<<"Wait_all_net_msg_signal_ready();";
	//	while(1);
		
		
		if(clear_flag)
		for(i=0;i<agent_n;i++)
		if(pthread_create(&tid[i], NULL, thread_main_auth,&agent[i]))
			D.Error("gjreoihus98uha");
	
	//	for(i=0;i<agent_n;i++)
	//		pthread_join(tid[i],0);
		
		
		Wait_all_net_msg_signal_done();
		cout<<"Wait_all_net_msg_signal_done();";
		
		
		
			
		
		
		All_net_msg_signal_start();
		Wait_all_net_msg_signal_ready();
		cout<<"Wait_all_net_msg_signal_ready();";
		
		
		
		Wait_all_net_msg_signal_done();
		cout<<"Wait_all_net_msg_signal_done();";
		
		while(1);
		
		
		
		//simulation_vertices=Wang_agent[0].Get_simulation_vertices();
		

		
		//node.resize(simulation_vertices+1);
		//for(i=0;i<=simulation_vertices;i++)
		//	node[i].Init();*/
	}	
	
	void Init2()
	{		
		int i;	
		kuo_d.clear();
		kuo.Init(&log);
			
		node.clear();		
		enermy_agent.clear();
		
		name.Init();
		enermy_agent_name.Init();
		
		Node Z;
		node.push_back(Z);
		
		d_file.Clear("WYX");
		
		
		string zs=(agent_name[0]);
		zs=zs[0];
		log.Init("./log/"+zs+"WYX.log");
			log.Clear();
		
	//	cout<<"======== "<<agent_n<<endl;
				
		for(i=0;i<agent_n;i++)
		if(!agent[i].Init2())
			D.Error("aewhrarjar");
	
		for(i=0;i<agent_n;i++)		
		{
			if(!agent[i].Sim_start())
				D.Error("a3y45a3ui");
			else
				cout<<agent_name[i]<<" sim start"<<endl;
		}		
	}	
	
	
	void All_agent_write_log(string r)
	{
		int i;
		for(i=0;i<agent_n;i++)
		{
			agent[i].Write_log(r);
		}
	}
	
	void Thread_listen()
	{
		int i;
		vector<pthread_t> tid;
		tid.resize(agent_n);
		
		for(i=0;i<agent_n;i++)
		if(pthread_create(&tid[i], NULL, thread_listen_main,&agent[i]))
			D.Error("jg589098u43e98yu34");
			
		//for(i=0;i<agent_n;i++)
		//	pthread_join(tid[i],0);
	}
	
	void Thread_send()
	{
		int i;
		vector<pthread_t> tid;
		tid.resize(agent_n);
		
		for(i=0;i<agent_n;i++)
		if(pthread_create(&tid[i], NULL, thread_send_main,&agent[i]))
			D.Error("jg589098u43e98yu34");
			
		for(i=0;i<agent_n;i++)
			pthread_join(tid[i],0);
	}
	
	void All_net_msg_signal_start()
	{	
		int i;
		int z;
	//	cout<<"All_net_msg_signal_start() 1"<<endl;
		for(i=0;i<agent_n;i++)
		{
		//	pthread_mutex_lock(&agent[i].pr.lock);
			z=0;
			while(!agent[i].pr.thread_start)
			{
				D.Wait_1_unit();
			//	cout<<"wait some one is waiting net_msg signal "<<endl;
			//	cout<<z++<<' '<<rand()<<endl;
			}
			agent[i].pr.thread_start=0;
			//cout<<z<<endl;
			agent[i].net_msg_signal_start=1;
			//pthread_mutex_lock(&agent[i].pr.lock);
			pthread_cond_signal(&agent[i].pr.net_msg_signal_start);
			//pthread_mutex_unlock(&agent[i].pr.lock);
		}
	//	cout<<"All_net_msg_signal_start() 2"<<endl;		
	}
	
	void Wait_all_auth_msg()
	{
		int i;
		int z;
		//cout<<"Wait_all_auth_msg() 1"<<endl;
		for(i=0;i<agent_n;i++)
		{
			while(!agent[i].have_auth_msg)
			{
				D.Wait_1_unit();
			}
		}
		//cout<<"Wait_all_auth_msg() 2"<<endl;
	}
	
	void Wait_all_sim_msg()
	{
		int i;
		int z;
		//cout<<"Wait_all_auth_msg() 1"<<endl;
		for(i=0;i<agent_n;i++)
		{
			while(!agent[i].have_sim_msg)
			{
				D.Wait_1_unit();
			}
		}
		//cout<<"Wait_all_auth_msg() 2"<<endl;
	}
	
	void Wait_all_thread_start()
	{
		int i;
		int z;
		//cout<<"Wait_all_net_msg_signal_ready() 1"<<endl;
		for(i=0;i<agent_n;i++)
		{
			while(!agent[i].pr.thread_start)
			{
				D.Wait_1_unit();
			}
		}
		//cout<<"Wait_all_net_msg_signal_ready() 2"<<endl;
	}
	
	void Wait_all_net_msg_signal_ready()
	{
		//cout<<"Wait_all_net_msg_signal_ready() 1"<<endl;	
		int i,j;
		int z=0;
		for(i=0;i<agent_n;i++)
		while(!agent[i].net_msg_signal_ready)
		{
			D.Wait_1_unit();
			//cout<<agent_name[i]<<" is not ready"<<endl;
			z++;
			
		}
		
		for(i=0;i<agent_n;i++)
		agent[i].net_msg_signal_ready=0;
	//	cout<<"Wait_all_net_msg_signal_ready() 2"<<endl;	
	}
	
	void Wait_all_net_msg_signal_done()
	{
	//	cout<<"Wait_all_net_msg_signal_done()"<<endl;		

		int i;
		
		for(i=0;i<agent_n;i++)
		while(!agent[i].net_msg_signal_done)
		{
			D.Wait_1_unit();
		}
		
		
		for(i=0;i<agent_n;i++)
			agent[i].net_msg_signal_done=0;
		//cout<<"Wait_all_net_msg_signal_done()"<<endl;		
	}
		
	///r///
	int Run()
	{
		int i;
		int j;
		int z;
		int zi=0;
				
		
		vector<int> pid;
		pid.resize(agent_n);
		
		
		
			
		for(i=0;i<agent_n;i++)
			agent[i].first_flag=0;
		
		int first=0;
		
	
		while(1)
		{		
			if(1)		
			{
				if(agent[0].sim_end)
				{
					Init2();				
				}			
								
				if(rand()%300==0)
				{
					cc.kuo01=rand()%2;
					if(rand()%2)
					{
						cc.can_buy_role.clear();
						cc.can_buy_role.push_back(cc.saboteur);
					}
					else
						cc.can_buy_role.clear();
				}
				
				
				last_time_enermy_agent=enermy_agent;
						
				All_agent_write_log("Thread listen start");
				//Thread_listen();	
			//	Tread_send();
			
				All_agent_write_log("Thread listen end");
				/*
				for(i=0;i<agent_n;i++)
					agent[i].Write_net_msg();
				*/
			
				if(!clear_flag)
				for(i=0;i<agent_n;i++)
					agent[i].first_flag=1;
		
						
				for(i=0;i<agent_n;i++)
				{
				//	cout<<agent_name[i]<<endl;
					if(!agent[i].Prepare())
						D.Error("tj9304yyha");
					else
					{
						log.writeln("if(!agent[i].Prepare()) "+agent_name[i]);
					}
				}
				
				perception_id=0;
				for(i=0;i<agent_n;i++)
				perception_id=max(perception_id,agent[i].perception_id);
				/*
				while(1)
				{
					for(i=0;i<agent_n;i++)
					if(agent[i].perception_id<perception_id)
						re_listen[i]=1;
					else
						re_listen[i]=0;
				}*/
				/*
				if(!clear_flag && !first)
				{
					first=1;
					continue;
				}*/
			
				//agent[0].Share_visible_entity();
				//log.writeln("agent[0].Share_visible_entity();");
			
				//All_agent_write_log("Share_visible_entity() 2");
				
				
				for(i=0;i<agent_n;i++)
				{
				//	cout<<"agent : "<<i<<" run"<<1<<endl;
					log.writeln("agent[i].Run(); 1 "+agent_name[i]);
					agent[i].Run();
					log.writeln("agent[i].Run(); 2 "+agent_name[i]);
				//	cout<<"agent : "<<i<<" run"<<2<<endl;
				}
				
								
			
				if(agent[0].sim_end)
				{
					sim_result_ranking.push_back(agent[0].sim_result_ranking);
					sim_result_score.push_back(agent[0].sim_result_score);
				
					printf("sim-result ranking = %d\n",sim_result_ranking[sim_result_ranking.size()-1]);
					printf("sim-result score = %d\n",sim_result_score[sim_result_score.size()-1]);		
				
				
					for(i=0;i<agent_n;i++)
					{
						agent[i].first_msg=0;
						agent[i].have_sim_msg=0;
					}
				}
				else
				{
					z=0;
					for(i=0;i<agent_n;i++)
					if(agent[i].mission==cc.mission_kuo)z++;
					
					if(z)
					kuo.Run(z);
				
					for(i=0;i<agent_n;i++)
					if(agent[i].mission==cc.mission_kuo)
					{
						log.writeln("agent[i].Arrange_mission_kuo(); 1 "+agent_name[i]);
						agent[i].Arrange_mission_kuo();
						log.writeln("agent[i].Arrange_mission_kuo(); 2 "+agent_name[i]);
						break;
					}
				
					for(i=0;i<agent_n;i++)
					if(agent[i].mission==cc.mission_explorer_min_cost_visit_bound)
					{
						log.writeln("agent[i].Arrange_mission_explorer_min_cost_visit_bound(); 1 "+agent_name[i]);
						agent[i].Arrange_mission_explorer_min_cost_visit_bound();
						log.writeln("agent[i].Arrange_mission_explorer_min_cost_visit_bound(); 2 "+agent_name[i]);
						break;
					}
				
					for(i=0;i<agent_n;i++)
					if(agent[i].mission==cc.mission_not_explorer_min_cost_visit_bound)
					{
						log.writeln("agent[i].Arrange_mission_not_explorer_min_cost_visit_bound(); 1 "+agent_name[i]);
						agent[i].Arrange_mission_not_explorer_min_cost_visit_bound();
						log.writeln("agent[i].Arrange_mission_not_explorer_min_cost_visit_bound(); 2 "+agent_name[i]);
						break;
					}
				
					for(i=0;i<agent_n;i++)
					{
						log.writeln("agent[i].Run_mission(); 1 "+agent_name[i]);
						agent[i].Run_mission();
						log.writeln("agent[i].Run_mission(); 2 "+agent_name[i]);
					}
				}
				
				write();
					
			/*	for(i=0;i<agent_n;i++)
				for(j=i+1;j<agent_n;j++)
				if(agent[i].mission!="" && agent[i].mission==agent[j].mission && agent[i].mission_destination>=0 && agent[i].mission_destination==agent[j].mission_destination)
				{
					cout<<i<<' '<<agent[i].agent_name<<' '<<agent[i].mission<<' '<<agent[i].mission_destination<<endl;
					
					cout<<j<<' '<<agent[j].agent_name<<' '<<agent[j].mission<<' '<<agent[j].mission_destination<<endl;
					D.Error("fgio43hy98734ty8934y");					
				}*/
			
				cout<<"--------"<<endl;			
			}
			
			All_net_msg_signal_start();
			
			log.writeln("All_net_msg_signal_start();");
			
			Wait_all_net_msg_signal_ready();
			log.writeln("Wait_all_net_msg_signal_ready();");
			
			Thread_send();
			log.writeln("Thread_send();");
			
			Wait_all_net_msg_signal_done();
			log.writeln("Wait_all_net_msg_signal_done();");
		}
		return 1;
	}
private:
	////w	
	void write()
	{
		string zs;
		int max_l=0,min_l=oo;
		int i;
		
		printf("ol ai sta nod\n");
		for(i=0;i<enermy_agent.size();i++)
		{
			zs=enermy_agent[i].name;
			max_l=max(max_l,int(zs.length()));
			min_l=min(min_l,int(zs.length()));
		}
		
		for(i=0;i<enermy_agent.size();i++)
		{
		//	if(enermy_agent[i].role!=cc.saboteur)
		//		continue;
			//if(!enermy_agent.Status_is(cc.normal,perception_id))
			//	continue;
			if(enermy_agent[i].role=="")
			printf("-- ");
			else printf("%c%c ",enermy_agent[i].role[0],enermy_agent[i].role[1]);
			if(i==0)
				printf(" 0 ");
				else
			printf("%2.d ",i);
			
			if(enermy_agent[i].Status_is(cc.normal,perception_id))
				printf(" nor ");
			else if(enermy_agent[i].Status_is(cc.disabled,perception_id))
				printf(" dis ");
			else if(enermy_agent[i].Last_known_status_is(cc.normal))
				printf("-nor ");
			else if(enermy_agent[i].Last_known_status_is(cc.disabled))
				printf("-dis ");
			else
				printf(" --- ");
			
			if(enermy_agent[i].Get_node(zs,perception_id))
			{
				printf("%4.d ",name.String_to_int(zs));
			}
			else
			{
				if(enermy_agent[i].Last_known_position(zs))
					printf("%4.d ",-name.String_to_int(zs));
				else
					printf("---- ");
			}
			puts("");
		}
			
		printf("p_id ol ai hp mis no last_action order\n");
		for(i=0;i<agent_n;i++)
			agent[i].write();	
	}
	
	//int simulation_vertices;
	int perception_id;
	vector<int > sim_result_ranking;
	vector<int> sim_result_score;
	
	int sim_end;
	int have_history_memory;
	Log log;

///m
	int clear_flag;
	vector<Agent> agent;
		
	D_file agent_name_password_ini,ip_port_file;
	vector<string> ip;
	vector<int> port;
	
	int agent_n;	
	vector<string> agent_name;
	vector<string> agent_password;
	
	
}Wang_Yuxin;


///c
void *thread_clock(void *arg)
{
	int a;
	int da;
	int s=0;
	int ps=clock_sign;
	int z;
	
	int ta;
	int tda;
	int ts=0;
	int tz;
	
	while(1)
	if(ps!=clock_sign)
	{
		if(clock_sign==1)
		{
			da=clock()-s;
			tda=time(0)-ts;
		}
		else
		if(clock_sign==2)
		{
			z=clock();		
			tz=time(0);	
			printf("clock = %d / %d = %lf\n",da,z-s,da/double(z-s));		
			printf("time = %d / %d = %lf\n",tda,tz-ts,tda/double(tz-ts));			
			s=z;
			ts=tz;
		}
		
		ps=clock_sign;
	}
	return((void *)0);
}




int main(int argc,char *argv[])
{
	int size=1024*1024*1024;
	char *p = (char*)malloc(size) + size;
	asm("movl %0, %%esp\n" :: "r"(p));
	
	srand(time(0));
	
	int i,j;
	string zs;
	string zs0;
	vector<string> zv;
	vector<string> A;
	char buff[1000];
	
	system("mkdir log");
	system("mkdir msg");
	
	cout<<(argc);
	for(i=0;i<argc;i++)
		cout<<argv[i]<<endl;
	
	//if(argc<2)return 0;
	
	
	
	///A
	if(argc == 1)
	{
		cout<<"A team start"<<endl;
		int i;
		int flag=1;
		/*
		if(argc==3)
		{
			zs=argv[2];
			if(zs=="init")
				flag=1;
		}*/
		cout<<flag<<endl;
		Wang_Yuxin.Init("./ini/team_A_agent.ini",flag);
		Wang_Yuxin.Run();
		return 0;
	}
	
	zs=argv[1];
	
	if(cc.use_tread_clock)
	{
		pthread_t tid;
		if(pthread_create(&tid, NULL, thread_clock,NULL))
			D.Error("0954u8945juhyrs");
	}

	
	
	
	if(zs==cc.B)
	{
		cout<<"B team start"<<endl;
		int i;
		int flag=0;
		
		if(argc==3)
		{
			zs=argv[2];
			if(zs=="init")
				flag=1;
		}
		
		Wang_Yuxin.Init("./ini/team_B_agent.ini",flag);
		Wang_Yuxin.Run();//m
		return 0;
	}
	
	if(zs==cc.k)
	{
		return 0;
	}
	
	if(zs==cc.check)
	{
		cout<<"check file = "<<argv[2]<<endl;
		
		FILE *F=fopen(argv[2],"r");
		map<string,int> Dm;
		char rs[1000];
		int line=0;
		int da=0,db=0;
		int z;
		while(fgets(rs,1000,F)!=0)
		{
			line++;
			db++;
			int n=strlen(rs);
			z=0;
			zs=str.Segment(rs,1);
			if(zs==cc.sight)continue;
			
			for(i=n-1;i>=0;i--)
			{
				if(rs[i]==' ')z++;
				if(z==2)break;
			}
			rs[i]=0;
			zs=rs;
			
			if(Dm[zs])
			{
				cout<<zs+" "<<Dm[zs]<<' '<<line<<endl;
				continue;
			}
			
			
			da++;
			Dm[zs]=line;
		}
		cout<<"check finished, value = "<<da<<" / "<<db<<endl;
		fclose(F);
		return 0;
	}

	if(zs=="z")
	{
		int i,z;
		int d=1000000;
		for(i=0;i<100;i++)
		{
			while(1)
			{
				z=clock();
				if(z>=i*d && z<(i+1)*d)
				{
					printf("%d %d\n",i,z);
					break;
				}
			}
		}
		return 0;
	}	
	return 0;
}












































