package de.tub.mac12.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;

public class VisibleEntity implements IFact {
	private static final long serialVersionUID = 7245460003743131123L;
	public String name;
	public String vertex;
	public String team;
	public boolean disabled = false;

	public VisibleEntity(String name, String vertex, String team, boolean disabled) {
		this.name = name;
		this.vertex = vertex;
		this.team = team;
		this.disabled = disabled;
	}
}
