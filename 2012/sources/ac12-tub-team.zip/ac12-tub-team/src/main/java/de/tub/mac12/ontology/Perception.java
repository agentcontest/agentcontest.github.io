package de.tub.mac12.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;

public class Perception implements IFact {
	private static final long serialVersionUID = 8856781490395163392L;

	public String username;
	
	public long timestamp;
	public long deadline;
	public String id;
	public int step;

	public String role;
	public int energy;
	public int maxEnergy;
	public int maxEnergyDisabled;
	public int health;
	public int maxHealth;
	public String lastAction;
	public boolean lastActionSuccess;
	public String position;
	public int strength;
	public int visRange;
	public int zoneScore;
	
	public int lastStepScore;
	public int money;
	public int score;
	public int zonesScore;
	
	public String[] achievements = null;
	public Vertex[] visibleVertices = null;
	public Edge[] visibleEdges = null;
	public VisibleEntity[] visibleEntities = null;
	public Vertex[] probedVertices = null;
	public Edge[] surveyedEdges = null;
	public InspectedEntity[] inspectedEntities = null;
	
	public Perception(String username) {
		this.username = username;
	}
}
