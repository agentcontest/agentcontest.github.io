package de.tub.mac12.bean.frogs;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Set;

import de.dailab.jiactng.agentcore.comm.message.JiacMessage;
import de.tub.mac12.bean.frogs.messages.InformContent;
import de.tub.mac12.connection.MessageConstants;
import de.tub.mac12.ontology.Edge;
import de.tub.mac12.ontology.Intention;
import de.tub.mac12.ontology.Vertex;
import de.tub.mac12.util.DistanceEntry;

public class FrogsExplorerDecisionBean extends FrogsAbstractDecisionBean {

  private StringBuffer stateString = null;

  public void decide() {
    // skip, goto, probe, survey, buy, recharge
    Intention intention = null;

    currentPosition = world.vertices.get(world.self.position);
    currentPosition.lastSeen = world.currentStep;

    // various outputs for debugging
    stateString = initStateString("Explorer");

    // get intention
    intention = simpleIntention();
    printValue("Intention", intention, stateString);

    // print everything, submit intention and done
    produceStatistics(intention, stateString);
    System.out.println(stateString.toString());
    // log.warn(stateString.toString());
    submitAction(intention);
  }

  private Intention simpleIntention() {

    // long start, end;
    // System.err.println("\n\n\t calculating subgraphs...");
    // start = System.currentTimeMillis();
    // HashSet<Vertex> bestSet = calculateSubgraph(5);
    // end = System.currentTimeMillis();
    // ArrayList<String> bestNames = new ArrayList<String>();
    // for(Vertex v: bestSet) {
    // bestNames.add(v.name);
    // }
    // ArrayList<String> borderNames = new ArrayList<String>();
    // for(Vertex v: calculateBorderSet(bestSet)) {
    // borderNames.add(v.name);
    // }
    //
    // System.err.println("\t suggested graph: "+bestNames);
    // System.err.println("\t border: "+borderNames);
    // System.err.println("\t value: "+calculateSubgraphValue(bestSet));
    // System.err.println("\t subgraphs complete in time: "+(end-start));

    Intention intention = null;

    // check if we may buy more energy
    if (intention == null) {
      intention = checkEnergyBuy();
    }

    // check if this vertex has been probed
    if (intention == null) {
      intention = checkProbe();
    }

    // check if there are unknown edges here, if so -> survey
    if (intention == null) {
      intention = checkSurvey();
    }

    // check if we need to recharge
    if ((intention == null) || (this.world.self.energy < 1)) {
      intention = checkRecharge();
    }

    // make sure matrix is known, otherwise a random move is chosen
    if (intention == null) {
      intention = checkIfMatrixIsKnown();
    }
    
    if((world.self.health==0) && (this.world.self.energy >= 2)) {
      intention = checkNeedHelp(stateString);
    }    

    if (intention == null) {
      intention = checkEvade(stateString);
    }
    
    if (intention == null) {
      // find unvisited node and set it as goal
      intention = visitAllVertices();
    }

    // check if we can help with occupation
    if (intention == null) {
      intention = checkOccupy(stateString);
    }

    return intention;
  }

  private Intention visitAllVertices() {
    Intention ret = null;

    if (currentPosition.equals(currentGoal)) {
      // goal has been reached, reset currentGoal
      printValue("reached checkpoint", currentPosition.name, stateString);
      currentPosition.lastSeen = world.currentStep;
      currentGoal = null;
    }

    Vertex forbidden = null;

    InformContent template = new InformContent(InformContent.TYPE.PROBE_VERTEX, null, null);
    Set<InformContent> contents = memory.readAll(template);

    for (InformContent cont : contents) {
      if (cont.username.equals(world.username)) {
        continue;
      }

      if (isMyBoss(cont.username)) {
        forbidden = world.vertices.get(cont.target);
        break;
      }
    }

    if (currentGoal == null || currentGoal.equals(forbidden)) {
      currentGoal = null;

      // we have no goal, so check if something is to discover...
      ArrayList<Vertex> notVisited = findUnvisitedVertices();
      if (notVisited.size() == 0) {
        stateString.append("Exploration DONE! ");

      } else {
        // there are unvisited vertices, select the closest...
        notVisited.remove(forbidden);

        printValue("unvisited", notVisited.size(), stateString);
        currentGoal = getClosestVertexFromList(currentPosition, notVisited);
      }
    }

    if (currentGoal != null) {
      // there is a goal (either old or new) so move towards it
      DistanceEntry entry = matrix.getEntry(currentPosition, currentGoal);
      if (entry == null) {
        System.err.println("matrix entry is empty for " + currentPosition.name + " -> " + currentGoal.name);
        return null;
      }
      printValue("dest", currentGoal.name, stateString);
      printValue("path", entry.path, stateString);
      ret = new Intention(MessageConstants.ACTION_GOTO, entry.path.get(1));
      sendExplorationGoal(currentGoal);
    }

    return ret;
  }

  private ArrayList<Vertex> findUnvisitedVertices() {
    ArrayList<Vertex> ret = new ArrayList<Vertex>();
    for (Vertex v : world.vertices.values()) {
      if (!v.probed || (v.lastSeen == -1)) {
        ret.add(v);
      }
    }

    for (Edge e : world.edges.values()) {
      if (!e.surveyed) {
        Vertex v1 = world.vertices.get(e.node1);
        Vertex v2 = world.vertices.get(e.node2);

        if (!ret.contains(v1)) {
          ret.add(v1);
        }

        if (!ret.contains(v2)) {
          ret.add(v2);
        }

      }
    }

    return ret;
  }

  private Intention checkProbe() {
    Intention ret = null;
    if (!currentPosition.probed) {
      ret = new Intention(MessageConstants.ACTION_PROBE, null);
    }
    return ret;
  }

  /**
   * Sends the intention of this agent to all other agents in the team
   * 
   * @param intention
   *          the intention to send
   */
  private void sendExplorationGoal(Vertex v) {
    // System.err.println(" --- sending message");
    JiacMessage msg = new JiacMessage(new InformContent(InformContent.TYPE.PROBE_VERTEX, world.username, v.name));
    Serializable[] params = new Serializable[2];
    params[0] = msg;
    params[1] = this.teamChannel;
    invoke(sendAction, params);
  }

}
