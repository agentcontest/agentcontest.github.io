package de.tub.mac12.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;

public class InspectedEntity implements IFact {
	private static final long serialVersionUID = 9110530033837557925L;
	public String name;
	public String vertex;
	public String role;
	public String team;
	public int energy;
	public int health;
	public int maxEnergy;
	public int maxHealth;
	public int strength;
	public int visRange;
}
