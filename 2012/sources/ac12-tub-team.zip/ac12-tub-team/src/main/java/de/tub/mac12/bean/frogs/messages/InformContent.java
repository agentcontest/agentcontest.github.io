package de.tub.mac12.bean.frogs.messages;

import de.dailab.jiactng.agentcore.knowledge.IFact;

public class InformContent implements IFact {

  public static enum TYPE {
    PROBE_VERTEX, SURVEY_VERTEX, SCOUT_VERTEX, GOTO_VERTEX, INSPECT_BOT, GOTO_BOT, ATTACK_BOT, HUNT_BOT, REPAIR_BOT, OCCUPY_VERTEX
  };

  public TYPE   type   = null;
  public String username = null;
  public String target = null;

  public InformContent() {
    
  }
  
  public InformContent(TYPE type, String username, String target) {
    this.type = type;
    this.username = username;
    this.target = target;
  }

  @Override
  public int hashCode() {
    return 0;
  }

  @Override
  public boolean equals(Object obj) {
    if ((obj == null) || !(obj instanceof InformContent)) {
      return false;
    }

    if (this == obj) {
      return true;
    }

    InformContent other = (InformContent) obj;

    return (((this.type == null) || (other.type == null) || (this.type.equals(other.type))) 
         && ((this.username == null) || (other.username == null) || (this.username.equals(other.username)))
         && ((this.target == null) || (other.target == null) || (this.target.equals(other.target))));

  }
}
