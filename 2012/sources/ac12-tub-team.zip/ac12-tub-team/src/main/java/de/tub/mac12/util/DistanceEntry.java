package de.tub.mac12.util;

import java.util.ArrayList;

import de.dailab.jiactng.agentcore.knowledge.IFact;

public class DistanceEntry implements IFact {
	private static final long serialVersionUID = -5978920542303035002L;
	public int totalCost = -1;
	public ArrayList<String> path = new ArrayList<String>();
	
	public int getSteps() {
	  return path.size()-1;
	}
	
}
