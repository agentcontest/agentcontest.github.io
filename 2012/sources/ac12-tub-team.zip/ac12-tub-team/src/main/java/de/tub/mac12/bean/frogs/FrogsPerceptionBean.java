package de.tub.mac12.bean.frogs;

import java.io.Serializable;
import java.util.Set;

import org.sercho.masp.space.event.SpaceEvent;
import org.sercho.masp.space.event.SpaceObserver;
import org.sercho.masp.space.event.WriteCallEvent;
import org.w3c.dom.Document;

import de.dailab.jiactng.agentcore.IAgentBean;
import de.dailab.jiactng.agentcore.action.AbstractMethodExposingBean;
import de.dailab.jiactng.agentcore.action.Action;
import de.dailab.jiactng.agentcore.comm.CommunicationAddressFactory;
import de.dailab.jiactng.agentcore.comm.ICommunicationAddress;
import de.dailab.jiactng.agentcore.comm.IGroupAddress;
import de.dailab.jiactng.agentcore.comm.message.IJiacMessage;
import de.dailab.jiactng.agentcore.comm.message.JiacMessage;
import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac12.bean.frogs.messages.InformContent;
import de.tub.mac12.bean.frogs.messages.MatrixContent;
import de.tub.mac12.bean.frogs.messages.WorldContent;
import de.tub.mac12.connection.MessageParser;
import de.tub.mac12.ontology.AuthResponse;
import de.tub.mac12.ontology.Authentication;
import de.tub.mac12.ontology.Bye;
import de.tub.mac12.ontology.Perception;
import de.tub.mac12.ontology.SimEnd;
import de.tub.mac12.ontology.World;

public class FrogsPerceptionBean extends AbstractMethodExposingBean {

  private static int                   turn            = -1;

  private String                       username;
  private MessageParser                messageParser;

  private FrogsServerCommunicationBean serverCommunicationBean;
  private FrogsAbstractDecisionBean    decisionBean;

  /** Actions to communicate with other team members. */
  private Action                       sendAction, registerAction;

  /** The channel where agents of one team share their knowledge. */
  public IGroupAddress                 teamChannel;
  public long                          time;

  private World                        world;

  private long                         currentDeadline = -1;

  public String getTeamChannel() {
    return this.teamChannel.toString();
  }

  public void setTeamChannel(String teamChannel) {
    this.teamChannel = CommunicationAddressFactory.createGroupAddress(teamChannel);
  }

  @Override
  public void doInit() throws Exception {
    super.doInit();

    for (IAgentBean ab : thisAgent.getAgentBeans()) {
      if (ab instanceof FrogsServerCommunicationBean) {
        this.serverCommunicationBean = (FrogsServerCommunicationBean) ab;
        messageParser = new MessageParser(serverCommunicationBean.getUsername());
      }
      if (ab instanceof FrogsAbstractDecisionBean) {
        this.decisionBean = (FrogsAbstractDecisionBean) ab;
      }
    }

    SpaceObserver<IFact> messageObserver = new SpaceObserver<IFact>() {
      private static final long serialVersionUID = -2109274101459190774L;

      @SuppressWarnings("unchecked")
      @Override
      public void notify(SpaceEvent<? extends IFact> event) {
        if (event instanceof WriteCallEvent) {
          Object eventObj = ((WriteCallEvent) event).getObject();
          if (eventObj instanceof IJiacMessage) {
            IJiacMessage message = (IJiacMessage) eventObj;
            if (message != null) {
              IFact payload = message.getPayload();

              if (payload instanceof Perception) {
                // handle Perception
                message = memory.remove(message);
                Perception perception = (Perception) payload;

                // ignore own perception that we have received
                // via team channel
                if (!perception.username.equals(username)) {

                  // only process actual perceptions and when
                  // world is initialized
                  if ((world != null) && (world.currentStep <= perception.step)) {
                    world.update(perception);
                  }
                }

              } else if (payload instanceof MatrixContent) {
                // handle distance matrix 
                message = memory.remove(message);
                MatrixContent content = (MatrixContent) payload;
                if (world != null) {
                  content.matrix.initVertexMap(world.vertices.values());
                  decisionBean.matrix = content.matrix;
                }

              } else if (payload instanceof WorldContent) {
                // handle world propagation (important for pathfinder only)
                message = memory.remove(message);
                if (username == null) {
                  WorldContent content = (WorldContent) payload;
                  world = content.world;
                  decisionBean.setWorld(world);
                  memory.write(world);
                }

              } else if (payload instanceof InformContent) {
                // handle inform
                message = memory.remove(message);
                InformContent content = (InformContent) payload;
                InformContent template = new InformContent(null, content.username, null);
                memory.remove(template);
                memory.write(content);
             }

            }
          }
        }
      }
    };
    memory.attach(messageObserver);

  }

  public void doStart() throws Exception {
    super.doStart();

    Authentication auth = memory.read(new Authentication(null, null));
    if (auth != null) {
      this.username = auth.getUsername();
    } else {
      System.err.println("NO AUTHENTICATION FOUND");
    }

    // retrieving needed actions from own CommunicationBean
    sendAction = memory.read(new Action("de.dailab.jiactng.agentcore.comm.ICommunicationBean#send", null, new Class[] {
        IJiacMessage.class, ICommunicationAddress.class }, null));
    if (sendAction == null)
      throw new RuntimeException("Could not find Communication...1");

    registerAction = memory.read(new Action("de.dailab.jiactng.agentcore.comm.ICommunicationBean#joinGroup", null,
        new Class[] { IGroupAddress.class }, null));
    if (registerAction == null)
      throw new RuntimeException("Could not find Communication...2");

    invoke(registerAction, new Serializable[] { this.teamChannel });
  }

  public void processServerMessage(Document message) {

    IFact parseResult = messageParser.parse(message);

    time = System.nanoTime();

    if (parseResult instanceof Perception) {

      // Perception received
      Perception perception = (Perception) parseResult;

      synchronized (Object.class) {
        if (perception.step > turn) {
          turn = perception.step;
          System.out.println("\n\n\n" + "Round: " + perception.step + " money: " + perception.money + " score: "
              + perception.score);
        }
      }

      // send own perception to other agents
      sendPerception(perception);

      if (world != null) {
        world.update(perception);
        decisionBean.decide();
        long offset = System.currentTimeMillis() - perception.timestamp;
        currentDeadline = perception.deadline + offset;
        if (currentDeadline < System.currentTimeMillis()) {
          log.error(" !!! MISSED DEADLINE BY: " + (System.currentTimeMillis() - currentDeadline));
        }

      } else {
        System.err.println("## [INFO] Agent " + this.username + " received ActionRequest before process SimStart!");
      }
    }

    else if (parseResult instanceof World) {

      // SimStart received
      world = (World) parseResult;
      decisionBean.setWorld(world);
      memory.write(world);

      if (memory.readAllOfType(World.class).size() == 1) {
        System.err.println("World found!!!");
      } else {
        System.err.println("World not found!!!");
      }

      String s = "Welt erstellt: Edges " + world.numEdges + " Vertices " + world.numVertices;
      System.out.println(s);

      if (username.contains("2")) {
        System.err.println("send world");
        sendWorld(world);
      }
    }

    else if (parseResult instanceof SimEnd) {
      // SimEnd received
      SimEnd simEnd = (SimEnd) parseResult;
      simEnd.setSimName(world.simulationId);
      memory.write(simEnd);

      memory.remove(world);
      world = null;
      decisionBean.setWorld(null);

      System.out.println(simEnd);
    }

    else if (parseResult instanceof Bye) {

      Set<SimEnd> results = memory.readAllOfType(SimEnd.class);
      for (SimEnd rse : results) {
        System.out.println(rse);
      }
      System.out.flush();

      Runtime.getRuntime().halt(666);

    }

    else if (parseResult instanceof AuthResponse) {
      String s = ((AuthResponse) parseResult).isAuthSuccessful() ? "AUTHENTICATION OK!" : "AUTHENTICATION FAILED!";
      System.out.println(s);
    }

  }

  /**
   * Sends the own perception to all team members.
   * 
   * @param perception
   *          the perception object to send
   */
  private void sendPerception(Perception perception) {
    JiacMessage msg = new JiacMessage(perception);
    Serializable[] params = new Serializable[2];
    params[0] = msg;
    params[1] = this.teamChannel;
    invoke(sendAction, params);
  }

  /**
   * Sends the own world to all team members for the pathfinding agent.
   * 
   * @param world
   *          the world object to send
   */
  private void sendWorld(World world) {
    JiacMessage msg = new JiacMessage(new WorldContent(world));
    Serializable[] params = new Serializable[2];
    params[0] = msg;
    params[1] = this.teamChannel;
    invoke(sendAction, params);
  }

}
