package de.tub.mac12.bean.frogs;

import de.tub.mac12.ontology.Intention;

public class FrogsSentinelDecisionBean extends FrogsAbstractDecisionBean {

  private StringBuffer stateString = null;

  public void decide() {
    // skip, goto, parry, survey, buy, recharge
    Intention intention = null;

    currentPosition = world.vertices.get(world.self.position);
    currentPosition.lastSeen = world.currentStep;

    // various outputs for debugging
    stateString = initStateString("Sentinel");

    // get intention
    intention = simpleIntention();
    printValue("Intention", intention, stateString);

    // print everything, submit intention and done
    produceStatistics(intention, stateString);
    System.out.println(stateString.toString());
    // log.warn(stateString.toString());
    submitAction(intention);
  }

  private Intention simpleIntention() {
    Intention intention = null;

    // check if we may buy more energy
    if (intention == null) {
      intention = checkEnergyBuy();
    }

    // check if there are unknown edges here, if so -> survey
    if (intention == null) {
      intention = checkSurvey();
    }

    // check if we need to recharge
    if ((intention == null) || (this.world.self.energy < 2)) {
      intention = checkRecharge();
    }

    // make sure matrix is known, otherwise a random move is chosen
    if (intention == null) {
      intention = checkIfMatrixIsKnown();
    }

    if((world.self.health==0) && (this.world.self.energy >= 2)) {
      intention = checkNeedHelp(stateString);
    }    
    
    if (intention == null) {
      intention = checkEvade(stateString);
    }    
    
    // check if we can help with occupation
    if (intention == null) {
      intention = checkOccupy(stateString);
    }

    return intention;
  }

}
