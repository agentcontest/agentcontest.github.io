package de.tub.mac12.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;

public class Intention implements IFact {
	
	private static final long serialVersionUID = -5482169226353959121L;
	public static final String GO_TO = "go to";
	public static final String CREATE_ZONE = "create zone";
	public static final String SKIP = "skip";
	public static final String RECHARGE = "recharge";
	
	public String action;
	public String param;
	public String getAction() {
		return action;
	}

	public String sender;
	public int step;
	
	public Intention(String action, String param) {
		this.action = action;
		this.param = param;
	}
	
	public Intention(String action, String param, String sender, int step) {
		this.action = action;
		this.param = param;
		this.sender = sender;
		this.step = step;
	}
	
	public String toString() {
		return action + "(" + param + ")";
	}
	
	public void setAction(String action) {
		this.action = action;
	}

	public String getParam() {
		return param;
	}

	public void setParam(String param) {
		this.param = param;
	}

	public String getSender() {
		return sender;
	}

	public void setSender(String sender) {
		this.sender = sender;
	}

	public int getStep() {
		return step;
	}

	public void setStep(int step) {
		this.step = step;
	}
}
