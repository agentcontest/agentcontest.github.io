package de.tub.mac12.states;

import java.util.LinkedList;
import java.util.Map.Entry;

import de.tub.mac12.bean.DecisionBean;
import de.tub.mac12.connection.MessageConstants;
import de.tub.mac12.ontology.Bot;
import de.tub.mac12.ontology.InfoMsg;
import de.tub.mac12.ontology.Intention;
import de.tub.mac12.ontology.Vertex;
import de.tub.mac12.ontology.World;

//TODO more than one saboteur?
//TODO avoid nodes with team mate as lon as they are not disabled

public class Repair extends State {

	private Bot secondRepairer = null;
	private Vertex myPosition = null;
	private Vertex secondRepairerPosition = null;
	private LinkedList<Bot> disabledAgents = new LinkedList<Bot>();
	
	public Repair(World world, DecisionBean db) {
		super(world, db);
	}

	@Override
	public Intention execute() {
		
		Intention intention;
		secondRepairer = getWorld().getSameRoleAgent();
		disabledAgents.clear();
		myPosition = getWorld().getMyPosition();
		secondRepairerPosition = getWorld().getAgentPosition(secondRepairer);
				
		// get disabled agents in game field
		for (Entry<String, Bot> agent : getWorld().getTeam().entrySet()) {
			
			// is agent alive?
			if (!agent.getValue().isAlive()
					&& !agent.getValue().name.equals(getWorld().getSelf().name)) {
//				Vertex agentPosition = getWorld().getAgentPosition(agent.getValue());
				
//				// is disabled agent in game field?
//				if (getWorld().isInGameField(agentPosition)) {
					disabledAgents.add(agent.getValue());
//				}
			}
		}
		
		// get the nearest disabled agent
		
		Bot disabledSaboteur = null;
		Bot disabledRepairer = null;
		
		Bot nearestDisabledAgent = null;
		int nearestDisabledAgentDistance = 10000;
		Vertex nearestDisabledAgentPosition = null;
		
		for (Bot agent : disabledAgents) {
		
			Vertex disabledAgentPosition = getWorld().getAgentPosition(agent);
			int disabledAgentDistance = getWorld().getDistanceWeighted(myPosition, disabledAgentPosition);
			
			// is agent saboteur standing on the same vertex?
			if (disabledAgentDistance == 0 && agent.role.equals(Bot.SABOTEUR)) {
				disabledSaboteur = agent;
				break;
			}
			
			// is agent repairer standing on the same vertex?
			if (disabledAgentDistance == 0 && agent.role.equals(Bot.REPAIRER)) {
				disabledRepairer = agent;
			}
			
			// is it the nearest disabled agent?
			if (disabledAgentDistance < nearestDisabledAgentDistance && disabledRepairer == null) {
				nearestDisabledAgent = agent;
				nearestDisabledAgentDistance = disabledAgentDistance;
				nearestDisabledAgentPosition = disabledAgentPosition;
			}
		}
		
		// determine agent to repair
		
		// is agent saboteur?
		if (disabledSaboteur != null) {
			nearestDisabledAgent = disabledSaboteur;
			
		// is agent repairer?
		} else if (disabledRepairer != null) {
			nearestDisabledAgent = disabledRepairer;
		}
		
		// are there two saboteurs in attack state?
		if (disabledAgents.size() >= 2 
				&& secondRepairer.isAlive()) {
//				&& getWorld().isInGameField(getWorld().getAgentPosition(secondRepairer))) {
		
			// get second repairer nearest enemy
			
			Bot srDisabledSaboteur = null;
			Bot srDisabledRepairer = null;
			
			Bot srNearestDisabledAgent = null;
			int srNearestDisabledAgentDistance = 10000;
			
			for (Bot agent : disabledAgents) {
				
				Vertex agentPosition = getWorld().getVertices().get(agent.getPosition());
				int agentDistance = getWorld().getDistanceWeighted(secondRepairerPosition, agentPosition);
				
				if (agent.role != null) {
					// is agent agent saboteur standing on the same vertex?
					if (agentDistance == 0 && agent.role.equals(Bot.SABOTEUR)) {
						srDisabledSaboteur = agent;
						break;
					}
					
					// is agent repairer standing on the same vertex?
					if (agentDistance == 0 && agent.role.equals(Bot.REPAIRER)) {
						srDisabledRepairer = agent;
					}
				}
				
				// is it the nearest agent?
				if (agentDistance <= srNearestDisabledAgentDistance && srDisabledRepairer == null) {
					srNearestDisabledAgent = agent;
					srNearestDisabledAgentDistance = agentDistance;
				}
			}
			
			// determine the target
			
			// is enemy saboteur?
			if (srDisabledSaboteur != null) {
				srNearestDisabledAgent = srDisabledSaboteur;
				
			// is enemy repairer?
			} else if (srDisabledRepairer != null) {
				srNearestDisabledAgent = srDisabledRepairer;
			}
			
			// have both saboteurs the same target?
			if (nearestDisabledAgent.name.equals(srNearestDisabledAgent.name)) {
				
				// get new target?
				if ((nearestDisabledAgentDistance > srNearestDisabledAgentDistance)
						|| (nearestDisabledAgentDistance == srNearestDisabledAgentDistance 
								&& getWorld().getSelf().getRank() < secondRepairer.getRank())) {
					
					disabledSaboteur = null;
					disabledRepairer = null;
					
					nearestDisabledAgentDistance = 10000;
					
					for (Bot agent : disabledAgents) {
						
						if (!agent.name.equals(srNearestDisabledAgent.name)) {
						
							Vertex agentPosition = getWorld().getVertices().get(agent.getPosition());
							int agentDistance = getWorld().getDistanceWeighted(myPosition, agentPosition);
							
							if (agent.role != null) {
								// is agent saboteur standing on the same vertex?
								if (agentDistance == 0 && agent.role.equals(Bot.SABOTEUR)) {
									disabledSaboteur = agent;
									break;
								}
								
								// is agent repairer standing on the same vertex?
								if (agentDistance == 0 && agent.role.equals(Bot.REPAIRER)) {
									disabledRepairer = agent;
								}
							}
							
							// is it the nearest agent?
							if (agentDistance <= nearestDisabledAgentDistance && disabledRepairer == null) {
								nearestDisabledAgent = agent;
								nearestDisabledAgentDistance = agentDistance;
								nearestDisabledAgentPosition = agentPosition;
							}
						}						
					}
					
					// determine the target
					
					// is agent saboteur?
					if (disabledSaboteur != null) {
						nearestDisabledAgent = disabledSaboteur;
						
					// is agent repairer?
					} else if (disabledRepairer != null) {
						nearestDisabledAgent = disabledRepairer;
					}				
				}
			}
			
		}
		
		nearestDisabledAgentPosition = getWorld().vertices.get(nearestDisabledAgent.position);
		
		// is agent on the same position?
		if (myPosition.name.equals(nearestDisabledAgentPosition.name)) {
			intention = new Intention(MessageConstants.ACTION_REPAIR, nearestDisabledAgent.name);
			
		// go to agent
		} else  {
			intention = new Intention(MessageConstants.ACTION_GOTO, getPathNextVertex(nearestDisabledAgentPosition));
		}
		
		return intention;
	}

	public boolean isTrue() {
		
		secondRepairer = getWorld().getSameRoleAgent();
		disabledAgents.clear();
		myPosition = getWorld().getMyPosition();
		secondRepairerPosition = getWorld().getAgentPosition(secondRepairer);
		
		// get disabled agents in game field
		for (Entry<String, Bot> agent : getWorld().getTeam().entrySet()) {
			
			// is agent alive?
			if (!agent.getValue().isAlive()
					&& !agent.getValue().name.equals(getWorld().getSelf().name)) {
//				Vertex agentPosition = getWorld().getAgentPosition(agent.getValue());
				
//				// is disabled agent in game field?
//				if (getWorld().isInGameField(agentPosition)) {
					disabledAgents.add(agent.getValue());
//				}
			}
		}
		
		// there are no disabled agents
		if (disabledAgents.size() == 0) {
			return false;
		}
			
		// is there enough disabled agents for two repairers or is the second repairer disabled
		// or is the second repairer not in game field?
		if (disabledAgents.size() >= 2 
				|| !secondRepairer.isAlive()) {
//				|| !getWorld().isInGameField(getWorld().getAgentPosition(secondRepairer))) {
			return true;
		}
		
		// the nearest repairer repairs if there is only one disabled agent
		
		Vertex agentPosition = getWorld().getAgentPosition(disabledAgents.getFirst());
		int myDistanceToAgent = getWorld().getDistanceWeighted(myPosition, agentPosition);
		int ssDistanceToAgent = getWorld().getDistanceWeighted(secondRepairerPosition, agentPosition);
		
		// self is closer
		if (myDistanceToAgent < ssDistanceToAgent) {
			return true;
			
		// second repairer is closer
		} else if (myDistanceToAgent > ssDistanceToAgent) {
			return false;
			
		// the same distance, rank decides
		} else {
			if (getWorld().getSelf().getRank() > secondRepairer.getRank()) {
				return true;
			} else {
				return false;
			}
		}
	}
	
	@Override
	protected void handleInfoMsg(InfoMsg infoMsg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected Path getPathfinding() {
		return Path.NORMAL;
	}


}