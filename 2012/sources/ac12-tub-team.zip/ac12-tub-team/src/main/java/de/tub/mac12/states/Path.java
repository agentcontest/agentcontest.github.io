package de.tub.mac12.states;

public enum Path {
	SAFE, SEMISAFE, NORMAL;
}
