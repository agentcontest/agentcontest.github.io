package de.tub.mac12.states;

import java.util.LinkedList;
import java.util.Map.Entry;

import de.tub.mac12.bean.DecisionBean;
import de.tub.mac12.connection.MessageConstants;
import de.tub.mac12.ontology.Bot;
import de.tub.mac12.ontology.InfoMsg;
import de.tub.mac12.ontology.Intention;
import de.tub.mac12.ontology.Vertex;
import de.tub.mac12.ontology.World;


public class Attack extends State {
	
	private Vertex myPosition = null;
	private Bot secondSaboteur = null;
	private Vertex secondSaboteurPosition = null;
	private LinkedList<Bot> enemies = new LinkedList<Bot>();
	private LinkedList<String> enemyGroups = new LinkedList<String>();

	public Attack(World world, DecisionBean db) {
		super(world, db);
	}

	@Override
	public Intention execute() {
		
		Intention intention = null;
		secondSaboteur = getWorld().getSameRoleAgent();
		enemies.clear();
		enemyGroups.clear();
		myPosition = getWorld().getMyPosition();
		secondSaboteurPosition = getWorld().getAgentPosition(secondSaboteur);
		
		// get enemy agents
		for (Entry<String, Bot> enemy : getWorld().opponents.entrySet()) {
			
			// is enemy agent alive?
			if (enemy.getValue().isAlive()
					&& enemy.getValue().lastSeen == getWorld().getCurrentStep()) {
				
				enemies.add(enemy.getValue());
				
				// create enemy groups (i.e. more enemies on the same position)
				if (!enemyGroups.contains(enemy.getValue().position)) {
					enemyGroups.add(enemy.getValue().position);
				}
			}
		}
		
//		System.err.println(getWorld().getCurrentStep() + " | " + getWorld().getSelf().name  + " : " + enemyGroups.size());
		
		// get the nearest enemy
		
		Bot enemySaboteur = null;
		Bot enemyRepairer = null;
		
		Bot nearestEnemy = null;
		Vertex nearestEnemyPosition = null;
		int nearestEnemyDistance = 10000;
		
		for (Bot enemy : enemies) {
			
			Vertex enemyPosition = getWorld().getVertices().get(enemy.getPosition());
			int enemyDistance = getWorld().getDistanceWeighted(myPosition, enemyPosition);
			
			if (enemy.role != null) {
				// is enemy agent saboteur standing on the same vertex?
				if (enemyDistance == 0 && enemy.role.equals(Bot.SABOTEUR)) {
					enemySaboteur = enemy;
					break;
				}
				
				// is enemy agent repairer standing on the same vertex?
				if (enemyDistance == 0 && enemy.role.equals(Bot.REPAIRER)) {
					enemyRepairer = enemy;
				}
			}
			
			// is it the nearest enemy?
			if (enemyDistance <= nearestEnemyDistance && enemyRepairer == null) {
				nearestEnemy = enemy;
				nearestEnemyDistance = enemyDistance;
				nearestEnemyPosition = enemyPosition;
			}
			
		}
		
		// determine the target
		
		// is enemy saboteur?
		if (enemySaboteur != null) {
			nearestEnemy = enemySaboteur;
			
		// is enemy repairer?
		} else if (enemyRepairer != null) {
			nearestEnemy = enemyRepairer;
		}
		
//		System.err.println(getWorld().getCurrentStep() + " | " + getWorld().getSelf().name  + " target "
//				+ nearestEnemy.name);
			
		// are there two saboteurs in attack state?
		if (enemies.size() >= 2 && secondSaboteur.isAlive()) {
			
			// get second saboteurs's nearest enemy
			
			Bot ssEnemySaboteur = null;
			Bot ssEnemyRepairer = null;
			
			Bot ssNearestEnemy = null;
			int ssNearestEnemyDistance = 10000;
			
			for (Bot enemy : enemies) {
				
				Vertex enemyPosition = getWorld().getVertices().get(enemy.getPosition());
				int enemyDistance = getWorld().getDistanceWeighted(secondSaboteurPosition, enemyPosition);
				
				if (enemy.role != null) {
					// is enemy agent saboteur standing on the same vertex?
					if (enemyDistance == 0 && enemy.role.equals(Bot.SABOTEUR)) {
						ssEnemySaboteur = enemy;
						break;
					}
					
					// is enemy agent repairer standing on the same vertex?
					if (enemyDistance == 0 && enemy.role.equals(Bot.REPAIRER)) {
						ssEnemyRepairer = enemy;
					}
				}
				
				// is it the nearest enemy?
				if (enemyDistance <= ssNearestEnemyDistance && ssEnemyRepairer == null) {
					ssNearestEnemy = enemy;
					ssNearestEnemyDistance = enemyDistance;
				}
			}
			
			// determine the target
			
			// is enemy saboteur?
			if (ssEnemySaboteur != null) {
				ssNearestEnemy = ssEnemySaboteur;
				
			// is enemy repairer?
			} else if (ssEnemyRepairer != null) {
				ssNearestEnemy = ssEnemyRepairer;
			}
			
//			System.err.println(getWorld().getCurrentStep() + " | " + getWorld().getSelf().name  + ": " + secondSaboteur.name 
//					+ " target " + ssNearestEnemy.name);
			
			
			// have both saboteurs the same target?
			if (nearestEnemy.name.equals(ssNearestEnemy.name)
					|| (nearestEnemy.position.equals(ssNearestEnemy.position)
							&& enemyGroups.size() >= 2)) {
				
				// get new target?
				if ((nearestEnemyDistance > ssNearestEnemyDistance)
						|| (nearestEnemyDistance == ssNearestEnemyDistance 
								&& getWorld().getSelf().getRank() < secondSaboteur.getRank())) {
					
					String forbiddenPosition = "";
					if (enemyGroups.size() >= 2) {
						forbiddenPosition = ssNearestEnemy.position;
					}
					
					enemySaboteur = null;
					enemyRepairer = null;
					
					nearestEnemyDistance = 10000;
					
					for (Bot enemy : enemies) {
						
						if (!enemy.name.equals(ssNearestEnemy.name)
								&& !enemy.position.equals(forbiddenPosition)) {
						
							Vertex enemyPosition = getWorld().getVertices().get(enemy.getPosition());
							int enemyDistance = getWorld().getDistanceWeighted(myPosition, enemyPosition);
							
							if (enemy.role != null) {
								// is enemy agent saboteur standing on the same vertex?
								if (enemyDistance == 0 && enemy.role.equals(Bot.SABOTEUR)) {
									enemySaboteur = enemy;
									break;
								}
								
								// is enemy agent repairer standing on the same vertex?
								if (enemyDistance == 0 && enemy.role.equals(Bot.REPAIRER)) {
									enemyRepairer = enemy;
								}
							}
							
							// is it the nearest enemy?
							if (enemyDistance <= nearestEnemyDistance && enemyRepairer == null) {
								nearestEnemy = enemy;
								nearestEnemyDistance = enemyDistance;
								nearestEnemyPosition = enemyPosition;
							}
						}						
					}
					
					// determine the target
					
					// is enemy saboteur?
					if (enemySaboteur != null) {
						nearestEnemy = enemySaboteur;
						
					// is enemy repairer?
					} else if (enemyRepairer != null) {
						nearestEnemy = enemyRepairer;
					}	
					
//					System.err.println(getWorld().getCurrentStep() + " | " + getWorld().getSelf().name  + " new target "
//							+ nearestEnemy.name);
				}
			}
			
		}
		
		
		nearestEnemyPosition = getWorld().vertices.get(nearestEnemy.position);
		
		// is enemy on the same position?
		if (myPosition.name.equals(nearestEnemyPosition.name)) {
			intention = new Intention(MessageConstants.ACTION_ATTACK, nearestEnemy.name);
			
		// go to enemy
		} else  {
			intention = new Intention(MessageConstants.ACTION_GOTO, getPathNextVertex(nearestEnemyPosition));
		}
		
		return intention;
	}

	/**
	 * Returns true if there is an (not disabled) enemy in game field
	 * 
	 */	
	public boolean isTrue() {

		secondSaboteur = getWorld().getSameRoleAgent();
		enemies.clear();
		myPosition = getWorld().getMyPosition();
		secondSaboteurPosition = getWorld().getAgentPosition(secondSaboteur);
		
		// get enemy agents
		for (Entry<String, Bot> enemy : getWorld().opponents.entrySet()) {
			
			// is enemy agent alive?
			if (enemy.getValue().isAlive() 
					&& enemy.getValue().lastSeen == getWorld().getCurrentStep()) {
				
				enemies.add(enemy.getValue());
			}
		}
		
		// there are no enemies
		if (enemies.size() == 0) {
			return false;
		}
			
		// is there enough enemies for two saboteurs or is the second saboteur disabled?
		if (enemies.size() >= 2 || !secondSaboteur.isAlive()) {
			return true;
		}
		
		// the nearest saboteur attacks if there is only one enemy
		
		Vertex enemyPosition = getWorld().getAgentPosition(enemies.getFirst());
		int myDistanceToEnemy = getWorld().getDistanceWeighted(myPosition, enemyPosition);
		int ssDistanceToEnemy = getWorld().getDistanceWeighted(secondSaboteurPosition, enemyPosition);
		
		// self is closer
		if (myDistanceToEnemy < ssDistanceToEnemy) {
			return true;
			
		// second saboteur is closer
		} else if (myDistanceToEnemy > ssDistanceToEnemy) {
			return false;
			
		// the same distance, rank decides
		} else {
			if (getWorld().getSelf().getRank() > secondSaboteur.getRank()) {
				return true;
			} else {
				return false;
			}
		}
	}
	
	@Override
	public void handleInfoMsg(InfoMsg infoMsg) {
		// do nothing		
	}

	@Override
	protected Path getPathfinding() {
		return Path.NORMAL;
	}


}
