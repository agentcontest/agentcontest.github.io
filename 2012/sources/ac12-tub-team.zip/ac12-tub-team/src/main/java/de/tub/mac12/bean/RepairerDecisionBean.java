package de.tub.mac12.bean;

import de.tub.mac12.states.Repair;

public class RepairerDecisionBean extends DecisionBean {
	
	@Override
	protected void addStatesAndConditions(){
		
		repair = new Repair(getWorld(), this);
		
		// add states
		super.addStatesAndConditions();
		getStatesList().add(disabled);
		getStatesList().add(group);
		getStatesList().add(repair);
		getStatesList().add(surveyEdges);
		getStatesList().add(createZone);
	}

}