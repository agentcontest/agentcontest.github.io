package de.tub.mac12.bean;

import de.tub.mac12.states.Escape;
import de.tub.mac12.states.Group;
import de.tub.mac12.states.SurveyEdges;

public class DefaultDecisionBean extends DecisionBean {

	@Override
	protected void addStatesAndConditions() {
		
		escape = new Escape(getWorld(), this);
		
		// add states
		super.addStatesAndConditions();
		getStatesList().add(disabled);
		getStatesList().add(escape);
		getStatesList().add(group);
		getStatesList().add(surveyEdges);
		getStatesList().add(createZone);
	}	
	
}