package de.tub.mac12.ontology;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.collections15.Predicate;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac12.util.WeightReader;
import edu.uci.ics.jung.algorithms.filters.EdgePredicateFilter;
import edu.uci.ics.jung.algorithms.filters.KNeighborhoodFilter;
import edu.uci.ics.jung.algorithms.filters.KNeighborhoodFilter.EdgeType;
import edu.uci.ics.jung.algorithms.filters.VertexPredicateFilter;
import edu.uci.ics.jung.algorithms.shortestpath.DijkstraDistance;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.UndirectedSparseGraph;

public class World implements IFact, Cloneable {

	private static final long      serialVersionUID = 787004556346917991L;

  public String                  username;
  public String                  simulationId;

  public int                     numEdges;
  public int                     numVertices;

  public int                     steps            = 0;
  public int                     currentStep      = -1;
  
  // perceptions received from other agents for particular round
  public int[]					receivedPerceptions = new int[1000];

  public long                    timestamp;
  public long                    deadline;
  public String                  id;

  public Bot                     self;
  public HashMap<String, Bot>    team             = new HashMap<String, Bot>();
  public HashMap<String, Bot>    opponents        = new HashMap<String, Bot>();
  
  private LinkedList<Bot>			enemySaboteurs = new LinkedList<Bot>();
  private LinkedList<Bot> enemyRepairers  	= new LinkedList<Bot>();
  public int					enemySaboteurEstimatedStrength;
  
  public String                  myTeamName       = null;
  public String                  opponentTeamName = null;

  public int                     energy;
  public int                     maxEnergy;
  public int                     maxEnergyDisabled;
  public int                     health;
  public int                     maxHealth;
  public int                     strength;
  public int                     visRange;

  public String                  position;
  private Vertex 				positionVertex;
  
  public String                  lastAction;
  public boolean                 lastActionSuccess;

  public int                     score            = 0;
  public int                     zoneScore;
  public int                     zonesScore;
  public int                     lastStepScore;

  public int                     money;

  public HashMap<String, Vertex> vertices         = new HashMap<String, Vertex>();
  public HashMap<String, Edge>   edges            = new HashMap<String, Edge>();
  private Graph<Vertex, Edge>    graph            = new UndirectedSparseGraph<Vertex, Edge>();
  
  private Graph<Vertex, Edge>	gameField = null;
  private Graph<Vertex, Edge>	gameFieldExtended = null;
  private Vertex				gameFieldCenter = null;
  private int 					gameFieldRadius = 3;
  private int 					gameFieldRadiusExtended = gameFieldRadius + 2;
  private boolean 				isNewGameField = true;
  
  public LinkedList<Zone> 			zones			= new LinkedList<Zone>();
  public LinkedList<Zone> 			enemyZones		= new LinkedList<Zone>();
  public HashSet<Vertex> 			unsafeVertices = new HashSet<Vertex>();
  public HashSet<Vertex> 			semiUnsafeVertices = new HashSet<Vertex>();
  
  private boolean probedGamefieldExtended 	= false;
  private boolean probedGamefield 			= false;
  private boolean probedCenter				= false;
  


  public World(String username) {
	  this.username = username;
	  this.self = new Bot();
	  this.self.name = username;
  }
  
  public synchronized void update(Perception perception) {
    if (perception.username.equals(username)) {
      this.timestamp = perception.timestamp;
      this.deadline = perception.deadline;
      this.id = perception.id;
      this.currentStep = perception.step;

      // self
      if (this.self == null) {
        this.self = new Bot();
        this.self.name = perception.username;
        this.self.role = perception.role;
      }
      
      this.self.energy = perception.energy;
      this.self.maxEnergy = perception.maxEnergy;
      this.self.maxEnergyDisabled = perception.maxEnergyDisabled;
      this.self.previousHealth = this.self.health;
      this.self.health = perception.health;
      
      if(this.self.health == 0){
    	  this.self.disabled = true;
      }else{
    	  this.self.disabled = false;
      }
      
      if(!self.disabled){
    	  self.setMaxAvailableEnergy(this.self.maxEnergy);
      }else{
    	  self.setMaxAvailableEnergy(this.self.maxEnergyDisabled);
      }
      
      this.self.maxHealth = perception.maxHealth;
      this.self.strength = perception.strength;
      this.self.visRange = perception.visRange;

      this.self.position = perception.position;
      this.self.lastAction = perception.lastAction;
      this.self.lastActionSuccess = perception.lastActionSuccess;
      this.zoneScore = perception.zoneScore;

      if (this.self.getRank() == 0) {
    	  this.self.setRank(Integer.parseInt(perception.username.substring(3)));
      }
      
      // team
      this.money = perception.money;
      this.score = perception.score;
      this.zonesScore = perception.zonesScore;
      this.lastStepScore = perception.lastStepScore;
      
      // agent's role
//      if (this.currentStep == 0) {
//    	  switch (this.self.maxEnergy) {
//	  		case 12:			
//	  			this.self.role = Bot.EXPLORER;
//	  			break;
//	  		case 10:			
//	  			this.self.role = Bot.SENTINEL;
//	  			break;
//	  		case 8:			
//	  			this.self.role = Bot.INSPECTOR;
//	  			break;
//	  		case 7:			
//	  			this.self.role = Bot.SABOTEUR;
//	  			break;
//  		} 
//      }

    } else {
      Bot bot = this.team.get(perception.username);
      if (bot == null) {
        bot = new Bot();
        bot.name = perception.username;
        this.team.put(perception.username, bot);
      }

      bot.role = perception.role;
      bot.energy = perception.energy;
      bot.maxEnergy = perception.maxEnergy;
      bot.maxEnergyDisabled = perception.maxEnergyDisabled;
      bot.health = perception.health;
      bot.maxHealth = perception.maxHealth;
      bot.strength = perception.strength;
      bot.visRange = perception.visRange;

      bot.position = perception.position;
      bot.lastAction = perception.lastAction;
      bot.lastActionSuccess = perception.lastActionSuccess;
      
      if (bot.getRank() == 0) {
    	  bot.setRank(Integer.parseInt(perception.username.substring(3)));
      }

    }
    
    if (perception.visibleVertices != null) {
      for (Vertex vv : perception.visibleVertices) {
        Vertex vertex = this.vertices.get(vv.name);
        if (vertex == null) {
          vertex = new Vertex(vv.name);
          vertex.x = vv.x;
          vertex.y = vv.y;
          vertices.put(vv.name, vertex);
          graph.addVertex(vertex);
        }
        vertex.team = vv.team;
      }
    }

    if (perception.probedVertices != null) {
      for (Vertex pv : perception.probedVertices) {
        Vertex vertex = this.vertices.get(pv.name);
        if (vertex == null) {
          vertex = new Vertex(pv.name);
          vertex.x = pv.x;
          vertex.y = pv.y;
          vertices.put(pv.name, vertex);
          graph.addVertex(vertex);
        }
        vertex.value = pv.value;
        vertex.probed = true;
        vertex.updated = true;
        if (gameFieldCenter == null) {
        	gameFieldCenter = pv;
        	isNewGameField = true;
        } else if (pv.value > gameFieldCenter.value) {
        	gameFieldCenter = pv;
        	isNewGameField = true;
        }
      }
    }

    if (perception.visibleEdges != null) {
      for (Edge ve : perception.visibleEdges) {
        Edge edge = this.edges.get(ve.id);
        if (edge == null) {
          edge = new Edge(ve.node1, ve.node2);
          this.edges.put(edge.id, edge);
          graph.addEdge(edge, vertices.get(edge.node1), vertices.get(edge.node2));
        }
      }
    }

    if (perception.surveyedEdges != null) {
      ArrayList<Edge> selist = new ArrayList<Edge>();
      for (int i = 0; i < perception.surveyedEdges.length; i++) {
        selist.add(perception.surveyedEdges[i]);
      }
      for (Edge se : perception.surveyedEdges) {
        Edge edge = this.edges.get(se.id);
        if (edge == null) {
          edge = new Edge(se.node1, se.node2, se.weight);
          this.edges.put(edge.id, edge);
        } else {
          edge.weight = se.weight;
        }
        edge.surveyed = true;
        edge.updated = true;
        vertices.get(edge.node1).updated = true;
        vertices.get(edge.node2).updated = true;
      }
    }

    if (perception.visibleEntities != null) {
      for (VisibleEntity oneEnt : perception.visibleEntities) {
        Bot knownBot = null;

        // search for bot in known data
        String prefix = perception.username.substring(0, 1);
        boolean opponent = !oneEnt.name.startsWith(prefix);

        if (opponent) {
          knownBot = this.opponents.get(oneEnt.name);
        } else {
          knownBot = this.team.get(oneEnt.name);
        }

        if (knownBot == null) {
          // bot not found, so create a new one and add it
          knownBot = new Bot();
        }

        // update info
        knownBot.name = oneEnt.name;
        knownBot.position = oneEnt.vertex;
        knownBot.lastSeen = perception.step;
        knownBot.team = oneEnt.team;
        knownBot.disabled= oneEnt.disabled;

        if (opponent) {
          this.opponents.put(knownBot.name, knownBot);
          if (opponentTeamName == null) {
        	  opponentTeamName = knownBot.team;
          }
        } else {
          this.team.put(knownBot.name, knownBot);
          if (myTeamName == null) {
        	  myTeamName = knownBot.team;
          }
        }
        
      }
    }

    if (perception.inspectedEntities != null) {
      for (InspectedEntity oneEnt : perception.inspectedEntities) {
        Bot knownBot = null;

        // search for bot in known data
        String prefix = perception.username.substring(0, 1);
        boolean opponent = !oneEnt.name.startsWith(prefix);

        if (opponent) {
          knownBot = this.opponents.get(oneEnt.name);
        } else {
          knownBot = this.team.get(oneEnt.name);
        }

        if (knownBot == null) {
          // bot not found, so create a new one and add it
          knownBot = new Bot();
        }

        // update info
        knownBot.name = oneEnt.name;
        //knownBot.position = oneEnt.node;
        knownBot.energy = oneEnt.energy;
        knownBot.health = oneEnt.health;
        knownBot.maxEnergy = oneEnt.maxEnergy;
        knownBot.maxHealth = oneEnt.maxHealth;
        knownBot.role = oneEnt.role;
        knownBot.strength = oneEnt.strength;
        knownBot.team = oneEnt.team;
        knownBot.visRange = oneEnt.visRange;
        knownBot.position = oneEnt.vertex;
        knownBot.inspected = true;

        if (opponent) {
          this.opponents.put(knownBot.name, knownBot);
          
          // add saboteurs to the enemySaboteurs list 
          if (knownBot.role.equals(Bot.SABOTEUR) && enemySaboteurs.size() < 2) {
        	  if (!enemySaboteurs.contains(knownBot)) {
        		  enemySaboteurs.add(knownBot);
        	  }
          }
          if (knownBot.role.equals(Bot.REPAIRER) && enemyRepairers.size() < 2){
        	  if (!enemyRepairers.contains(knownBot)) {
        		  enemyRepairers.add(knownBot);
        	  }
          }
          
        } else {
          this.team.put(knownBot.name, knownBot);
        }

      }
    }
    
    if (perception.username.equals(username)) {
    	positionVertex = vertices.get(self.position);
    }
    
    if (self != null && self.team == null && myTeamName != null) {
    	self.team = myTeamName;
    }
    
    synchronized(this) {
      receivedPerceptions[perception.step]++;
    }
  }

  public synchronized Graph<Vertex, Edge> getGameField() {
    return this.gameField;
  }

  public synchronized void setGraph(Graph<Vertex, Edge> graph) {
    this.graph = graph;
  }

  public Bot getSelf() {
    return self;
  }

  public HashMap<String, Vertex> getVertices() {
    return vertices;
  }
  
  	public LinkedList<Bot> getEnemySaboteurs() {
  		return enemySaboteurs;
  	}
  	
	public LinkedList<Bot> getEnemyRepairers() {
  		return enemyRepairers;
  	}
  	
  	public HashSet<Vertex> getUnsafeVertices(){
		return unsafeVertices;  		
  	}
  	
  	public HashSet<Vertex> getSemiUnsafeVertices(){
  		return semiUnsafeVertices;
  	}

	/**
	 *  Counts team neighbor nodes
	 * 
	 */
	public int numTeamNeighborNodes(Vertex node) {
		List<Vertex> neighbors = getNeighborNodes(node);
		List<Vertex> teamNeighbors = new LinkedList<Vertex>();
		for (Vertex v : neighbors) {
			if (v.team.equals("own")) {
				teamNeighbors.add(v);
			}
		}
		return teamNeighbors.size();
	}
	
	/**
	 *  Counts enemy neighbor nodes
	 * 
	 */
	public int numEnemyNeighborNodes(Vertex node) {
		List<Vertex> neighbors = getNeighborNodes(node);
		List<Vertex> enemyNeighbors = new LinkedList<Vertex>();
		for (Vertex v : neighbors) {
			if (v.team.equals("enemy")) {
				enemyNeighbors.add(v);
			}
		}
		return enemyNeighbors.size();
	}
	
	/**
	 *  Returns a list of neighbor vertices for the given vertex
	 * 
	 */
	public synchronized LinkedList<Vertex> getNeighborNodes(Vertex node) {
		if (!graph.containsVertex(node)) {
			System.err.println("getNeighborNodes(): graph does not contain " + node + " !");
		}
		Collection<Vertex> neighbors = graph.getNeighbors(node);
		if (neighbors == null) {
			System.err.println("getNeighborNodes(): neighbors are null!");
		}
		LinkedList<Vertex> nList = new LinkedList<Vertex>();
		for (Vertex neighbour : neighbors) {
			nList.add(neighbour);
		}	
		return nList;
	}
	
	/**
	 *  Returns a list of neighbor vertices for the given vertex
	 * 
	 */
	public synchronized LinkedList<Vertex> getNeighborNodesGamefield(Vertex node) {
		Collection<Vertex> neighbors = graph.getNeighbors(node);
		LinkedList<Vertex> nList = new LinkedList<Vertex>();
		for (Vertex neighbour : neighbors) {
			if (isInGameField(neighbour)) {
				nList.add(neighbour);
			}
		}	
		return nList;
	}
	
	public synchronized LinkedList<Vertex> getNeighborNodesGamefieldExtended(Vertex node) {
		
		if (gameFieldExtended == null) {
			this.defineGameFieldExtended();
		}
		
		Collection<Vertex> neighbors = graph.getNeighbors(node);
		LinkedList<Vertex> nList = new LinkedList<Vertex>();
		for (Vertex neighbour : neighbors) {
			if (isInGameFieldExtended(neighbour)) {
				nList.add(neighbour);
			}
		}	
		return nList;
	}
	
	/**
	 *  Returns a list of k neighbor vertices for the given vertex
	 * 
	 */
	public synchronized LinkedList<Vertex> getKNeighborNodesGamefield(Vertex node, int k) {
		KNeighborhoodFilter<Vertex, Edge> neighborFilter = new KNeighborhoodFilter<Vertex, Edge>(node, k, EdgeType.IN_OUT);
		Graph<Vertex,Edge> neighbors = neighborFilter.transform(graph);
		
		LinkedList<Vertex> nList = new LinkedList<Vertex>();
		for (Vertex neighbour : neighbors.getVertices()) {
			if (isInGameField(neighbour)) {
				nList.add(neighbour);
			}
		}	
		return nList;
	}
	
	public synchronized LinkedList<Vertex> getKNeighborNodesGamefieldExtended(Vertex node, int k) {
		
		if (gameFieldExtended == null) {
			this.defineGameFieldExtended();
		}
		
		KNeighborhoodFilter<Vertex, Edge> neighborFilter = new KNeighborhoodFilter<Vertex, Edge>(node, k, EdgeType.IN_OUT);
		Graph<Vertex,Edge> neighbors = neighborFilter.transform(graph);
		
		LinkedList<Vertex> nList = new LinkedList<Vertex>();
		for (Vertex neighbour : neighbors.getVertices()) {
			if (isInGameFieldExtended(neighbour)) {
				nList.add(neighbour);
			}
		}	
		return nList;
	}
	
	public synchronized Graph<Vertex,Edge> getKNeighborNodes(Vertex node, int k) {
		KNeighborhoodFilter<Vertex, Edge> neighborFilter = new KNeighborhoodFilter<Vertex, Edge>(node, k, EdgeType.IN_OUT);
	    return neighborFilter.transform(graph);
	}
	
	/**
	 *  Returns all active team agents standing on the vertex
	 * 
	 */
	public LinkedList<Bot> getTeamAgentsOnVertex(Vertex node) {
		LinkedList<Bot> agents= new LinkedList<Bot>();
		
		// self	
		if (this.self.position.equals(node.name) && this.self.isAlive()) {
			agents.add(this.self);
		}
		
		// team
		for (Map.Entry<String, Bot> bot : this.team.entrySet()){
			if (bot.getValue().position.equals(node.name) && bot.getValue().isAlive()) {
				agents.add(bot.getValue());
			}
		}	
		return agents;
	}

	/**
	 *  Returns all active visible enemy agents standing on the vertex
	 * 
	 */
	public LinkedList<Bot> getEnemyAgentsOnVertex(Vertex node) {
		LinkedList<Bot> agents= new LinkedList<Bot>();
		for (Map.Entry<String, Bot> bot : this.opponents.entrySet()){
			if (bot.getValue().position.equals(node.name) 
					&& bot.getValue().isAlive()
					&& bot.getValue().lastSeen == currentStep) {
				agents.add(bot.getValue());
			}
		}	
		return agents;
	}
	
	/**
	 *  Returns a number of active visible enemy saboteurs standing on the vertex
	 * 
	 */
	public int numEnemySaboteursOnVertex(String node) {
		int numEnemySaboteurs = 0;
		for (Bot bot : enemySaboteurs) {
			if (bot.position.equals(node) 
					&& bot.isAlive()
					&& bot.lastSeen == currentStep) {
				numEnemySaboteurs++;
			}
		}	
		return numEnemySaboteurs;
	}
	
	/**
	 *  Returns a number of active team agents standing on the vertex
	 * 
	 */
	public int numTeamAgentsOnVertex(String node) {
		int numTeamAgents = 0;
		
		for (Map.Entry<String, Bot> bot : this.team.entrySet()){
			if (bot.getValue().position.equals(node) 
					&& bot.getValue().isAlive()) {
				numTeamAgents++;
			}
		}	
		
		return numTeamAgents;
	}
	
	public int numEnemyAgentsOnVertex(String node) {
		int numEnemyAgents = 0;
		
		for (Map.Entry<String, Bot> bot : this.opponents.entrySet()){
			if (bot.getValue().position.equals(node) 
					&& bot.getValue().isAlive()
					&& bot.getValue().lastSeen == currentStep) {
				numEnemyAgents++;
			}
		}	
		
		return numEnemyAgents;
	}
	
	/**
	 *  Returns all active visible agents of the specified team standing on the vertex
	 * 
	 */
	public LinkedList<Bot> getAgentsOnVertex(Vertex node, String team) {
		LinkedList<Bot> agents = new LinkedList<Bot>();
		
		if (team.equals("own")) {
			for (Map.Entry<String, Bot> bot : this.team.entrySet()){
				if (bot.getValue().position.equals(node.name) && bot.getValue().isAlive()) {
					agents.add(bot.getValue());
				}
			}	
		} else if (team.equals("enemy")) {
			for (Map.Entry<String, Bot> bot : this.opponents.entrySet()){
				if (bot.getValue().position.equals(node.name) 
						&& bot.getValue().isAlive()
						&& bot.getValue().lastSeen == currentStep) {
					agents.add(bot.getValue());
				}
			}
		}		
		
		return agents;
	}
	
	/**
	 *  Returns all active visible agents (self + team + opponents)
	 * 
	 */
	public LinkedList<Bot> getAllAgents() {
		LinkedList<Bot> agents= new LinkedList<Bot>();
		agents.add(self);
		for (Map.Entry<String, Bot> bot : this.team.entrySet()){
			if (bot.getValue().isAlive()) {
				agents.add(bot.getValue());
			}
		}	
		for (Map.Entry<String, Bot> bot : this.opponents.entrySet()){
			if (bot.getValue().isAlive()
					&& bot.getValue().lastSeen == currentStep) {
				agents.add(bot.getValue());
			}
		}	
		return agents;
	}

	/**
	 *  Returns the vertex, the agent is standing on
	 * 
	 */
	public Vertex getAgentPosition(Bot agent) {
		if (agent == null) {
			System.err.println("getAgentPosition(): agent is null!");
			return this.vertices.get(self.position);
		}
		return this.vertices.get(agent.position);
	}
	
	/**
	 * Returns the name of the vertex which is the current position.
	 * 
	 * @return
	 */
	public Vertex getCurrentPosition() {
		String botPosition = getSelf().getPosition();
		Vertex currentPosition = getVertices().get(botPosition);
		return currentPosition;
	}
	
	/**
	 *  Checks if an active visible enemy agent is standing on the vertex
	 * 
	 */
	public boolean isFreeOfEnemies(Vertex node) {
		for (Map.Entry<String, Bot> bot : this.opponents.entrySet()){
			if (bot.getValue().position.equals(node.name) 
					&& bot.getValue().isAlive()
					&& bot.getValue().lastSeen == currentStep) {
				return false;
			}
		}	
		return true;
	}
	
	/**
	 *  Returns all unprobed vertices
	 * 
	 */
	public LinkedList<Vertex> getUnprobedVertices() {
		LinkedList<Vertex> unprobedVertices = new LinkedList<Vertex>();
		for (Vertex node : this.getGameField().getVertices()) {
			if (!node.probed) {
				unprobedVertices.add(node);
			}
		}
		return unprobedVertices;
	}
	
	
	
	public boolean isAllEdgesSurveyed() {
		for (Map.Entry<String, Edge> e : this.edges.entrySet()) {
			if (!e.getValue().surveyed) {
				return false;
			}
		}
		return true;
	}
	
	public boolean isNeighborEdgesSurveyed(Vertex node) {
		Collection<Edge> edges= graph.getIncidentEdges(node);
		for (Edge edge : edges) {
			if (!edge.surveyed) {
				return false;
			}
		}
		return true;
	}

	/**
	 *  Returns agent's team
	 * 
	 */
	public String getAgentTeam(Bot agent) {
		if (agent.name.equals(self.name)) {
			return "own";
		} else if (team.get(agent.name) != null) {
			return "own";
		} else {
			return "enemy";
		}
	}
	
	/**
	 *  Returns enemy zones' score
	 * 
	 */
	public int getEnemyZonesScore() {
		int score = 0;
		for (Zone zone : enemyZones) {
			score += zone.getScore();
		}	
		return score;
	}
	
	public int getTeamZonesScore() {
		int score = 0;
		for (Zone zone : zones) {
			score += zone.getScore();
		}	
		return score;
	}
	
	/**
	 * Returns true, if every vertex in graph has been probed.
	 * @return
	 */
	public boolean isProbedGamefieldExtended() {
		if (!probedGamefieldExtended) {
			for (Vertex node : this.gameFieldExtended.getVertices()) {
				if (!node.isProbed()) {
					return false;
				}
			}
			probedGamefieldExtended = true;
		}
		return true;
	}
	
	public boolean isProbedGamefield() {
		if (!probedGamefield) {
			for (Vertex node : this.gameField.getVertices()) {
				if (!node.isProbed()) {
					return false;
				}
			}
			probedGamefield = true;
		}
		return true;
	}

	public int getCurrentStep() {
		return currentStep;
	}

	public String getLastAction() {
		return lastAction;
	}
	
	/**
	 * Computes the distance between two vertices (edges' weights are always 1)
	 * 
	 * @return 10000 if there is no path from v1 to v2
	 */
	public synchronized int getDistance(Vertex v1, Vertex v2) {
		DijkstraDistance<Vertex, Edge> dd = new DijkstraDistance<Vertex, Edge>(getAvaliableEdgesGraph());
		Number distance = dd.getDistance(v1, v2);
		if (distance == null) {
			distance = 10000;
		}
		return distance.intValue();
	}
	
	/**
	 * Computes the distance between two vertices (sum of the edges' weights)
	 * 
	 * @return 10000 if there is no path from v1 to v2
	 */
	public synchronized int getDistanceWeighted(Vertex v1, Vertex v2) {
		DijkstraDistance<Vertex, Edge> dd = new DijkstraDistance<Vertex, Edge>(getAvaliableEdgesGraph(), new WeightReader());
		Number distance = dd.getDistance(v1, v2);
		if (distance == null) {
			distance = 10000;
		}
		return distance.intValue();
	}
	
	/**
	 * Returns a graph containing edges with weight <= maxAvailableEnergy  
	 * 
	 */
	public Graph<Vertex, Edge> getAvaliableEdgesGraph() {
		
		Predicate<Edge> weightTooHigh = new Predicate<Edge>() {

			@Override
			public boolean evaluate(Edge edge) {
				if(edge.weight <= getSelf().getMaxAvailableEnergy()){
					return true;
				}else{
					return false;
				}
			}
		};
		
		EdgePredicateFilter<Vertex, Edge> edgeFilter = new EdgePredicateFilter<Vertex, Edge>(weightTooHigh);
		Graph<Vertex, Edge> reducedGraph = edgeFilter.transform(graph);
		return reducedGraph;
	}
	
	public synchronized Graph<Vertex, Edge> getReducedGraph(Collection<Vertex> vertices) {
		
		final Collection<Vertex> verticesToRemove = vertices;
		
		Predicate<Vertex> predicate = new Predicate<Vertex>() {

			@Override
			public boolean evaluate(Vertex vertex) {
				if (verticesToRemove.contains(vertex)) {
					return false;
				} else {
					return true;
				}
			}
		};
		
		VertexPredicateFilter<Vertex, Edge> vertexFilter = new VertexPredicateFilter<Vertex, Edge>(predicate);
		return vertexFilter.transform(graph);
	}


	public HashMap<String, Bot> getTeam() {
		return team;
	}
	
	/**
	 * Returns a set of unsafe vertices, i.e. enemy saboteurs' positions
	 * and sometimes their neighbors.
	 * 
	 */
	public void calculateUnsafeVertices() {
		unsafeVertices.clear();
		
		for (Bot enemy : enemySaboteurs) {
			if (enemy.lastSeen == currentStep && enemy.isAlive()) {
				
				// enemy saboteur's position is always unsafe
				unsafeVertices.add(getVertices().get(enemy.position));
				
				int numEnemySaboteurs = numEnemySaboteursOnVertex(enemy.position);
				int numTeamAgents = numTeamAgentsOnVertex(enemy.position);
				
				// are enemy saboteur's neighbors not safe?
				if (numEnemySaboteurs > numTeamAgents) {
					
					Vertex enemyPosition = getAgentPosition(enemy);
					LinkedList<Vertex> enemyNeighbors = getNeighborNodes(enemyPosition);
					// declare enemy neighbors as unsafe
					for (Vertex node : enemyNeighbors) {
						unsafeVertices.add(getVertices().get(node.name));
					}
				}				
			}
		}
		
	}
	
	/**
	 * Returns a set of semi-safe vertices, i.e. enemy saboteurs' positions
	 * and sometimes their neighbors.
	 * 
	 */
	public void calculateSemiUnsafeVertices() {
		semiUnsafeVertices.clear();
		
		for (Bot enemy : enemySaboteurs) {
			if (enemy.lastSeen == currentStep && enemy.isAlive()) {
				
				// enemy saboteur's position is always unsafe
				semiUnsafeVertices.add(getVertices().get(enemy.position));
				
				int numEnemySaboteurs = numEnemySaboteursOnVertex(enemy.position);
				int numTeamAgents = numTeamAgentsOnVertex(enemy.position);
				
				// are enemy saboteur's neighbors not safe?
				if (numEnemySaboteurs > numTeamAgents) {
					
					Vertex enemyPosition = getAgentPosition(enemy);
					LinkedList<Vertex> enemyNeighbors = getNeighborNodes(enemyPosition);
					// check if enemy neighbors are semi-unsafe
					for (Vertex node : enemyNeighbors) {
						if (this.numTeamAgentsOnVertex(node.name) > 0) {
							semiUnsafeVertices.add(node);
						}
					}
				}				
			}
		}
		
	}
	
	/**
	 * Returns true if the given position is safe, i.e. there is no danger
	 * of being attacked by enemy saboteur.
	 * 
	 */
	public boolean isSafePosition(String vertex) {
		if (unsafeVertices.contains(vertex)) {
			return false;
		} else {
			return true;
		}
	}
	
	/**
	 * Returns true if the given position is semi-safe, i.e. there is small chance
	 * of being attacked by enemy saboteur.
	 * 
	 */
	public boolean isSemiSafePosition(String vertex) {
		if (semiUnsafeVertices.contains(vertex)) {
			return false;
		} else {
			return true;
		}
	}

	public Vertex getMyPosition() {
		return positionVertex;
	}

	public void defineGameField() {
		if (gameFieldCenter == null) {
			gameFieldCenter = getMyPosition();
		}
		this.gameField = getKNeighborNodes(gameFieldCenter, gameFieldRadius);	
	}
	
	public void defineGameFieldExtended() {
		if (gameFieldCenter == null) {
			gameFieldCenter = getMyPosition();
		}
		this.gameFieldExtended = getKNeighborNodes(gameFieldCenter, gameFieldRadiusExtended);	
	}
	
	public boolean isInGameField(Vertex node) {
		if (gameField.getVertices().contains(node)) {
			return true;
		} else {
			return false;
		}
	}
	
	public boolean isInGameFieldExtended(Vertex node) {
		if (gameFieldExtended.getVertices().contains(node)) {
			return true;
		} else {
			return false;
		}
	}
	
	public Bot getSameRoleAgent() {
		for (Entry<String, Bot> agent : team.entrySet()) {
			if (!agent.getValue().name.equals(this.self.name)){
				if (agent.getValue().role != null) {
					if (agent.getValue().role.equals(this.self.role)) {
						return agent.getValue();
					}
				}
			}
		}
		System.err.println("getSameRoleAgent() : returning self");
		return self;
	}

	public Vertex getGameFieldCenter() {
		return gameFieldCenter;
	}

	public void setGameFieldCenter(Vertex gameFieldCenter) {
		this.gameFieldCenter = gameFieldCenter;
	}

	public Graph<Vertex, Edge> getGraph() {
		return this.graph;
	}

	public void setNewGameField(boolean isNewGameField) {
		this.isNewGameField = isNewGameField;
	}

	public boolean isNewGameField() {
		return isNewGameField;
	}

	public boolean isVertexInZone(Vertex node) {

		for (Zone zone : zones) {
			if (zone.getVertices().contains(node)) {
				return true;
			}
		}
		
		return false;
	}
	
	public boolean isProbedCenter() {
		
		if (!probedCenter) {
			for (Vertex node : this.getNeighborNodes(gameFieldCenter)) {
				if (!node.isProbed()) {
					return false;
				}
			}
			probedCenter = true;
		}
		
		return true;
	}

}