package de.tub.mac12;

import de.dailab.jiactng.agentcore.SimpleAgentNode;

public class ContestNodeStarter {
	public static String NODES_SPRINGCONFIGFILE = "classpath:MAC12-contestNode.xml";

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SimpleAgentNode.main(new String[] {NODES_SPRINGCONFIGFILE});
	}

}
