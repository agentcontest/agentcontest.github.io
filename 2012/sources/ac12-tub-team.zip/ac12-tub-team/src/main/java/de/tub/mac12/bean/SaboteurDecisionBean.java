package de.tub.mac12.bean;

import de.tub.mac12.states.Attack;
import de.tub.mac12.states.Buy;

public class SaboteurDecisionBean extends DecisionBean {

	@Override
	protected void addStatesAndConditions() {
		
		attack = new Attack(getWorld(), this);
		buy = new Buy(getWorld(), this);
		
		// add states
		super.addStatesAndConditions();
		getStatesList().add(disabled);
		getStatesList().add(buy);
//		getStatesList().add(group);
		getStatesList().add(attack);
		getStatesList().add(surveyEdges);
		getStatesList().add(createZone);
	}
	

	@Override
	public int getHealthPuffer(){
		return 2;
	}

}