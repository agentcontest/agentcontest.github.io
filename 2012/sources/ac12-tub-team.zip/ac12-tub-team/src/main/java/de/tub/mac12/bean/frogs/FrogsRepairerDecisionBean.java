package de.tub.mac12.bean.frogs;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Set;

import de.dailab.jiactng.agentcore.comm.message.JiacMessage;
import de.tub.mac12.bean.frogs.messages.InformContent;
import de.tub.mac12.connection.MessageConstants;
import de.tub.mac12.ontology.Bot;
import de.tub.mac12.ontology.Intention;
import de.tub.mac12.util.DistanceEntry;

public class FrogsRepairerDecisionBean extends FrogsAbstractDecisionBean {

  private StringBuffer stateString   = null;

  private Bot          currentTarget = null;

  private Bot          forbidden     = null;

  public void decide() {
    // skip, goto, parry, survey, buy, repair, recharge
    Intention intention = null;

    currentPosition = world.vertices.get(world.self.position);
    currentPosition.lastSeen = world.currentStep;

    // various outputs for debugging
    stateString = initStateString("Repairer");

    // get intention
    intention = simpleIntention();
    printValue("Intention", intention, stateString);

    // print everything, submit intention and done
    produceStatistics(intention, stateString);
    System.out.println(stateString.toString());
    // log.warn(stateString.toString());
    submitAction(intention);
  }

  private Intention simpleIntention() {
    Intention intention = null;

    if(currentTarget != null) {
      printValue("patient", currentTarget.name, stateString);
    }
    
    // update forbidden bot (or set to null if none)
    updateForbiddenBot();

    // check if we may buy more energy
    if (intention == null) {
      intention = checkEnergyBuy();
    }

    // check if any bots on my vertex need repair
    if (intention == null) {
      intention = checkRepair();
    }

    // check if there are unknown edges here, if so -> survey
    if (intention == null) {
      intention = checkSurvey();
    }

    // check if we need to recharge
    if ((intention == null) || (this.world.self.energy < 2)) {
      intention = checkRecharge();
    }

    // make sure matrix is known, otherwise a random move is chosen
    if (intention == null) {
      intention = checkIfMatrixIsKnown();
    }

    if (intention == null) {
      intention = checkEvade(stateString);
    }    
    
    if((world.self.health==0) && (this.world.self.energy >= 2)) {
      intention = checkNeedHelp(stateString);
    }    
    
    // check if we can move to a damaged bot
    if (intention == null) {
      intention = checkEmergency();
    }

    // check if we can help with occupation
    if (intention == null) {
      intention = checkOccupy(stateString);
    }

    return intention;
  }

  private Intention checkRepair() {
    Intention ret = null;

    // check if a bot is on my vertex that needs repair
    ArrayList<Bot> botsOnVertex = getFriendlyBotsOnVertex(currentPosition);
    for (Bot b : botsOnVertex) {
      if (b.health < b.maxHealth) {
        printValue("reparing bot", b, stateString);
        ret = new Intention(MessageConstants.ACTION_REPAIR, b.name);
        break;
      }
    }

    return ret;
  }

  private Intention checkEmergency() {
    Intention ret = null;

    // check if we need a new target
    if ((currentTarget == null) || (currentTarget.health == currentTarget.maxHealth)) {
      currentTarget = null;

      // find all damaged bots
      ArrayList<Bot> damagedBots = findDamagedBots();

      // select closest bot with existing path
      int currentDist = Integer.MAX_VALUE;
      for (Bot b : damagedBots) {
        if(b.name.equals(world.self.name)) {
          continue;
        }
        
        DistanceEntry entry = matrix.getEntry(currentPosition, world.vertices.get(b.position));
        if ((entry != null) && (entry.path.size() > 1)) {
          
          System.err.println(b.role+" damaged...");
          if(Bot.REPAIRER.equals(b.role)) {
            currentTarget = b;
            currentDist = entry.totalCost;
            break;
          }
          
          if ((entry.totalCost < currentDist)) {
            currentTarget = b;
            currentDist = entry.totalCost;
          }
        }
      }
    }

    if (currentTarget != null) {
      // we have a target, so move there
      DistanceEntry entry = matrix.getEntry(currentPosition, world.vertices.get(currentTarget.position));
      printValue("saving", currentTarget, stateString);
      printValue("path", entry.path, stateString);
      sendRepairTarget(currentTarget);
      ret = new Intention(MessageConstants.ACTION_GOTO, entry.path.get(1));
    }

    return ret;
  }

  private ArrayList<Bot> findDamagedBots() {
    ArrayList<Bot> ret = new ArrayList<Bot>();
    for (Bot b : world.team.values()) {
      // skip forbidden bot
      if ((forbidden != null) && b.name.equals(forbidden.name)) {
        continue;
      }

      if (b.health < b.maxHealth) {
        ret.add(b);
      }
    }
    return ret;
  }

  private void updateForbiddenBot() {
    InformContent template = new InformContent(InformContent.TYPE.REPAIR_BOT, null, null);
    Set<InformContent> contents = memory.readAll(template);

    forbidden = null;
    for (InformContent cont : contents) {
      if (cont.username.equals(world.username)) {
        continue;
      }

      if (isMyBoss(cont.username)) {
        forbidden = world.team.get(cont.target);
        if ((currentTarget != null) && currentTarget.name.equals(cont.target)) {
          currentTarget = null;
        }
        break;
      }
    }
  }

  /**
   * Sends the intention of this agent to all other agents in the team
   * 
   * @param intention
   *          the intention to send
   */
  private void sendRepairTarget(Bot b) {
    // System.err.println(" --- sending message");
    JiacMessage msg = new JiacMessage(new InformContent(InformContent.TYPE.REPAIR_BOT, world.username, b.name));
    Serializable[] params = new Serializable[2];
    params[0] = msg;
    params[1] = this.teamChannel;
    invoke(sendAction, params);
  }

}
