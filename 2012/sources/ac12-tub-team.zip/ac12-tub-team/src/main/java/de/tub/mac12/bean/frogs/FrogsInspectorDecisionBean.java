package de.tub.mac12.bean.frogs;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;

import de.dailab.jiactng.agentcore.comm.message.JiacMessage;
import de.tub.mac12.bean.frogs.messages.InformContent;
import de.tub.mac12.connection.MessageConstants;
import de.tub.mac12.ontology.Bot;
import de.tub.mac12.ontology.Intention;
import de.tub.mac12.ontology.Vertex;
import de.tub.mac12.util.DistanceEntry;

public class FrogsInspectorDecisionBean extends FrogsAbstractDecisionBean {

  private StringBuffer stateString   = null;

  private Bot          currentTarget = null;

  private boolean      watcher       = false;

  private boolean      hunter        = false;

  public void decide() {
    // skip, goto, inspect, survey, buy, recharge
    Intention intention = null;

    currentPosition = world.vertices.get(world.self.position);
    currentPosition.lastSeen = world.currentStep;

    // various outputs for debugging
    stateString = initStateString("Inspecto");

    // get intention
    intention = simpleIntention();
    printValue("Intention", intention, stateString);

    // print everything, submit intention and done
    produceStatistics(intention, stateString);
    System.out.println(stateString.toString());
    // log.warn(stateString.toString());
    submitAction(intention);
  }

  private Intention simpleIntention() {
    Intention intention = null;

    // check if we may buy more energy
    if (intention == null) {
      intention = checkEnergyBuy();
    }

    // check if we need to inspect
    if (intention == null) {
      intention = checkInspect();
    }

    // check if there are unknown edges here, if so -> survey
    if (intention == null) {
      intention = checkSurvey();
    }

    // check if we need to recharge
    if ((intention == null) || (this.world.self.energy < 1)) {
      intention = checkRecharge();
    }

    // make sure matrix is known, otherwise a random move is chosen
    if (intention == null) {
      intention = checkIfMatrixIsKnown();
    }

    if((world.self.health==0) && (this.world.self.energy >= 2)) {
      intention = checkNeedHelp(stateString);
    }    
    
    if (intention == null) {
      intention = checkEvade(stateString);
    }    
    
    // check for bots to hunt
    if (intention == null) {
      intention = checkHunt();
    }

//    // watcher keeps watching
//    if ((intention == null) && watcher) {
//      for (Bot bot : this.world.opponents.values()) {
//        bot.inspected = false;
//      }
//    }

    // check if we can help with occupation
    if (intention == null) {
      intention = checkOccupy(stateString);
    }

    return intention;
  }

  private Intention checkHunt() {
    Intention ret = null;
    int currentCost = Integer.MAX_VALUE;

    if (currentTarget == null) {
      // find new target
      for (Bot bot : this.world.opponents.values()) {
        if (hunter || !bot.inspected) {
          if (hunter) {
            // this is a hunter, so look for bots with health
            if (bot.disabled) {
              continue;
            }
          }

          DistanceEntry newEntry = matrix.getEntry(currentPosition, this.world.vertices.get(bot.position));
          if (newEntry == null) {
            // no path to bot
            continue;
          }

          if ((currentTarget == null) || (newEntry.totalCost < currentCost)) {
            currentTarget = bot;
            currentCost = newEntry.totalCost;
          }
        }
      }

      if (currentTarget != null) {
        sendInspectionTarget(currentTarget);
        if (hunter) {
          sendKillTarget(currentTarget);
        }
      }

    }

    if (currentTarget != null) {
      // get closer to current target
      currentGoal = this.world.vertices.get(currentTarget.position);
      if (currentGoal == null) {
        System.err.println(" no position for " + currentTarget);
      }
      if (matrix == null) {
        printValue("matrix in checkhunt is", matrix, stateString);
        return null;
      }
      DistanceEntry pathEntry = matrix.getEntry(currentPosition, currentGoal);
      if (pathEntry == null) {
        System.err.println("matrix entry is empty for " + currentPosition.name + " -> " + currentGoal.name);
        return null;
      }
      printValue("hunting", currentTarget, stateString);
      printValue("path", pathEntry.path, stateString);
      if (pathEntry.path.size() > 1) {
        ret = new Intention(MessageConstants.ACTION_GOTO, pathEntry.path.get(1));
      }
      if (hunter) {
        sendKillTarget(currentTarget);
      }

    } else {
      printValue("All bots known!", this.world.opponents.values().size(), stateString);
    }
    return ret;
  }

  private Intention checkInspect() {
    Intention ret = null;

    if (hunter) {
      // hunter inspects target at same node
      if ((currentTarget != null) && (currentPosition.name.equals(currentTarget.position))) {

        if (currentTarget.health == 0) {
          // target is dead - set null to search for new target
          printValue("target dead", currentTarget, stateString);
          currentTarget = null;

        } else {
          printValue("inspecting", currentTarget, stateString);
          sendKillTarget(currentTarget);
          sendInspectionTarget(currentTarget);
          ret = new Intention(MessageConstants.ACTION_INSPECT, null);
        }
      }

    } else {
      // non-hunters
      // collect bots on this node and all neighbors
      HashSet<Bot> botSet = new HashSet<Bot>();
      botSet.addAll(getEnemyBotsOnVertex(currentPosition, true));

      ArrayList<Vertex> neighbors = getNeighbors(currentPosition);
      for (Vertex v : neighbors) {
        botSet.addAll(getEnemyBotsOnVertex(v, true));
      }

      // check if one bot is not yet inspected
      for (Bot bot : botSet) {
        if (!bot.inspected) {
          printValue("inspecting", bot, stateString);
          ret = new Intention(MessageConstants.ACTION_INSPECT, null);
          sendInspectionTarget(bot);
          currentTarget = null;
          break;
        }
      }
    }

    return ret;
  }

  /**
   * Sends the intention of this agent to all other agents in the team
   * 
   * @param intention
   *          the intention to send
   */
  private void sendInspectionTarget(Bot b) {
    // System.err.println(" --- sending message");
    JiacMessage msg = new JiacMessage(new InformContent(InformContent.TYPE.INSPECT_BOT, world.username, b.name));
    Serializable[] params = new Serializable[2];
    params[0] = msg;
    params[1] = this.teamChannel;
    invoke(sendAction, params);
  }

  /**
   * Sends the intention of this agent to all other agents in the team
   * 
   * @param intention
   *          the intention to send
   */
  private void sendKillTarget(Bot b) {
    // System.err.println(" --- sending message");
    JiacMessage msg = new JiacMessage(new InformContent(InformContent.TYPE.HUNT_BOT, world.username, b.name));
    Serializable[] params = new Serializable[2];
    params[0] = msg;
    params[1] = this.teamChannel;
    invoke(sendAction, params);
  }

  public boolean isWatcher() {
    return watcher;
  }

  public void setWatcher(boolean watcher) {
    this.watcher = watcher;
  }

  public boolean isHunter() {
    return hunter;
  }

  public void setHunter(boolean hunter) {
    this.hunter = hunter;
  }

}
