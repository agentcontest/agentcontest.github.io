package de.tub.mac12.bean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import edu.uci.ics.jung.graph.UndirectedSparseGraph;

import de.tub.mac12.ontology.Bot;
import de.tub.mac12.ontology.Edge;
import de.tub.mac12.ontology.Intention;
import de.tub.mac12.ontology.Zone;
import de.tub.mac12.ontology.Vertex;
import de.tub.mac12.ontology.World;
import de.tub.mac12.states.State;


/**
 * This class is in charge of calculating who is dominating nodes and zones. 
 * 
 * (Some zones calculating algorithms was taken from the mac11 server sources)
 * 
 */
public class ZoneCalculator {
	
	private World world;
	private State state;
	
	public ZoneCalculator() {
	}
	
	public ZoneCalculator(World world) {
		this.world = world;
	}
	
	public ZoneCalculator(World world, State state) {
		this.world = world;
		this.state = state;
	}

	public void setWorld(World world) {
		this.world = world;
	}
	
	public void setState(State state) {
		this.state = state;
	}
	
	/**
	 * Calculates zones. After calculation, it updates this information 
	 * in world, vertices and bots.
	 * 
	 * IMPORTANT: perform this action before any other, to have the world state up to date.
	 * 
	 */
	public void calculateZones(){
		
		HashMap<String, Vertex> nodes = world.getVertices();
		
		// First step: basic domination
		
		for (Map.Entry<String, Vertex> node : nodes.entrySet()){			
			calculateBasicNodeDomination(node.getValue(), world);	
		}
		
		// Second step: neighbor domination
		
		Map<Vertex, String> m = new HashMap<Vertex, String>();

		for (Map.Entry<String, Vertex> node : nodes.entrySet()){
			if ((node.getValue().getTeam().equals("none")) && isEmptyOfActiveAgents(node.getValue(), world)){
				String domin = calculateDominatorFromNeighbours(node.getValue(), world);
				if (!domin.equals("none")){
					m.put(node.getValue(), domin);
				}
			}
		}
		
		for (Vertex node : m.keySet()){
			node.setTeam(m.get(node));
		}

		// Third step: isolated zone domination
		
		ArrayList<Vertex> emptyNodesList = getEmptyNodesList(nodes, world);
		HashSet<Vertex> nodesChecked = new HashSet<Vertex>();
		
		while (!emptyNodesList.isEmpty()){
			
			HashSet<Vertex> subgraphNodes;
			ArrayList<Vertex> nodesToCheck;
			boolean isolated = true;
			String dominatorTeam = "none";
			
			Vertex node = emptyNodesList.remove(0);
			subgraphNodes = new HashSet<Vertex>();			
			nodesToCheck = new ArrayList<Vertex>();
			nodesToCheck.add(node);
			
			while (!nodesToCheck.isEmpty()){
				node = nodesToCheck.remove(0);
				subgraphNodes.add(node);
				List<Vertex> neighbors = world.getNeighborNodes(node);
				for (Vertex neighbor : neighbors){
					if (neighbor.getTeam().equals("none") && isEmptyOfActiveAgents(neighbor, world)){
						if (!nodesChecked.contains(neighbor) && !nodesToCheck.contains(neighbor)){
							nodesToCheck.add(neighbor);
							emptyNodesList.remove(neighbor);
						}
					}
					else if (isolated && !neighbor.getTeam().equals("none") 
							&& (dominatorTeam.equals("none") || neighbor.getTeam().equals(dominatorTeam))){
						dominatorTeam = neighbor.getTeam();
					}
					else {
						isolated = false;
						dominatorTeam = "none";
					}
				}
				nodesChecked.add(node);
			}
			
			if (isolated && !dominatorTeam.equals("none")){
				for (Vertex isolatedNode: subgraphNodes){			
					isolatedNode.setTeam(dominatorTeam);
				}
			}
		}
		
		// Now compute the zones that have been created, and add them to the world state.
		world.zones.clear();
		world.enemyZones.clear();
		
		for (Bot bot : world.getAllAgents()) {
			bot.myZone = null;
		}
		
		LinkedList<Bot> allAgents =	world.getAllAgents(); //Agents to review
		
		while (!allAgents.isEmpty()){			
			
			Bot agent = allAgents.removeFirst();
			Vertex agentPosition = world.getAgentPosition(agent);
			String agentTeam = world.getAgentTeam(agent);
			
			if (agentPosition.team.equals(agentTeam)) {
				int score = 0;
				
				LinkedList<Bot> zoneAgents = new LinkedList<Bot>();
				LinkedList<Vertex> zoneNodes = new LinkedList<Vertex>();
				LinkedList<Vertex> nodesToCheck = new LinkedList<Vertex>();
				
				zoneNodes.add(agentPosition);
				nodesToCheck.add(agentPosition);
				
				while(!nodesToCheck.isEmpty()){
					Vertex node = nodesToCheck.removeFirst();
					score += node.value;
					
					// If node has agents, add all agents from team
					for (Bot agentInNode : world.getAgentsOnVertex(node, agentTeam)) {
						if (agentTeam.equals(world.getAgentTeam(agentInNode))) {
							zoneAgents.add(agentInNode);
						}	
						allAgents.remove(agentInNode);
					}
	
					for (Vertex neighbor : world.getNeighborNodes(node)) {
						if (neighbor.team.equals(agentTeam)	&& !zoneNodes.contains(neighbor)) {
							// Node belongs to zone
							zoneNodes.add(neighbor);
							nodesToCheck.add(neighbor);
						}	
					}
				}
				
				if (zoneNodes.size() > 1) {					
					Zone zone = new Zone(zoneAgents, zoneNodes, zoneNodes.size(), score);
					
					if (agentTeam.equals("own")) {
						world.zones.add(zone);
					} else if (agentTeam.equals("enemy")) {
						world.enemyZones.add(zone);
					}					
					
					for (Bot bot : zoneAgents) {
						bot.myZone = zone;
					}
				}
			}
		}
	}
	
	public void calculateBestPositions(LinkedList<String> agents) {
		
		// map with agents' names and their distances to gameFieldCenter
		HashMap<String, Integer> agentsToCheck = new HashMap<String, Integer>();
		
		// get agents' distances to gemeFieldCenter 
		for (String bot : agents) {
			Bot agent = world.getTeam().get(bot);
			Vertex agentPosition = world.getAgentPosition(agent);
			int distanceToGameFieldCenter = world.getDistance(agentPosition, world.getGameFieldCenter());
			agentsToCheck.put(bot, distanceToGameFieldCenter);
		}
		
		// calculate best positions for agents,
		// starting with agents outside the game field and then
		// agents nearest to the gameFieldCenter  
		while (!agentsToCheck.isEmpty()) {
			
			String nextAgent = getNextAgent(agentsToCheck);
			Bot agentToCheck = null;
			if (world.getSelf().name.equals(nextAgent)) {
				agentToCheck = world.getSelf();
			} else {
				agentToCheck = world.getTeam().get(nextAgent);
			}
			
			String agentOldPosition = agentToCheck.position;
			agentToCheck.position = getTheBestPosition(agentToCheck).name;
			
			if (!agentToCheck.position.equals(agentOldPosition)) {
				calculateZones();
			}
		}
	}
	
	private String getNextAgent(HashMap<String, Integer> agentsToCheck) {
		
		// search for agents outside the zone 
		for (Map.Entry<String, Integer> agent : agentsToCheck.entrySet()) {
			Bot bot = world.getTeam().get(agent.getKey());
			if (!world.isInGameField(world.getAgentPosition(bot))) {
				agentsToCheck.remove(bot.name);
				return bot.name;
			}
		}
		
		// search for agents nearest to gameFieldCenter
		
		String nextAgent = null;
		int nextAgentDistance = 12345;
		
		for (Map.Entry<String, Integer> agent : agentsToCheck.entrySet()) {
			if (agent.getValue() < nextAgentDistance) {
				nextAgent = agent.getKey();
				nextAgentDistance = agent.getValue();
			}
		}
		
		agentsToCheck.remove(nextAgent);
		
		return nextAgent;
	}

	/**
	 * Returns a position, where an agent can maximize own zones' score
	 * and minimize enemy zones' score.
	 * 
	 * @return	a position with maximum zones' score difference
	 */
	private Vertex getTheBestPosition(Bot agent) {
		
		// check agent's actual position and all neighbors
		Vertex agentPosition = world.getAgentPosition(agent);
		LinkedList<Vertex> nodesToCheck = world.getNeighborNodesGamefield(agentPosition);
		if (world.isInGameField(agentPosition)) {
			nodesToCheck.add(agentPosition);
		}
		
		// go to the game field if outside
		if (nodesToCheck.isEmpty()) {
			Vertex goTo = state.getNextVertex(agentPosition, world.getGameFieldCenter());
			System.err.println(world.currentStep + " | " + agent.name + " goToGameField position : " + goTo.name); 
			return goTo;
		}
		
//		// spread if in the middle of the zone
//		if (isAllNeighborsInZone(agentPosition)) {
//			
//			Vertex nextPosition = null;
//			
//			for (Vertex node : nodesToCheck) {
//				
//				// try to find free position
//				if (world.numTeamAgentsOnVertex(node.name) == 0) {
//					
//					// try to find safe position
//					if (world.isSafePosition(node.name)) {
//						nextPosition = node;
//						break;
//					}
//					
//					// try to find semi-safe position
//					if (world.isSemiSafePosition(node.name)) {
//						nextPosition = node;
//					} 
//				}
//			}
//			
//			// choose random position if there is no free or safe position
//			if (nextPosition == null) {
//				nextPosition =  nodesToCheck.getFirst();
//			}
//			
//			System.err.println(world.currentStep + " | " + agent.name + " spread position : " + 
//					nextPosition.name); 
//			
//			return nextPosition;
//		}
		
		// calculate the best position
		
		Vertex bestPosition = agentPosition;
		int bestScore = -1234;
		boolean scoreChange = false;
		
		for (Vertex node : nodesToCheck) {
			if (world.isSafePosition(node.name)) {
				int score = getNewPositionScore(agent, node);
				if (score >= bestScore) { 
					if (canGoTo(agent, agentPosition, node)) {
						bestPosition = node;
						bestScore = score;
					}
				}
				if (score != 0) {
					scoreChange = true;
				}
			}
		}
		
		// if there is no score change or other team agent is standing 
		// on the same position (not good) go somewhere else
		
		int teamAgentsOnVertex = world.numTeamAgentsOnVertex(bestPosition.name);
		int enemyAgentsOnVertex = world.numEnemyAgentsOnVertex(bestPosition.name);
		
		if (!scoreChange 
				|| enemyAgentsOnVertex >= 2
				|| teamAgentsOnVertex >= 3
				|| (teamAgentsOnVertex >= 2 && enemyAgentsOnVertex == 0)) {
			
//			System.err.println(world.currentStep + " | " + agent.name + " " + enemyAgentsOnVertex + " "
//					+ teamAgentsOnVertex + " " + scoreChange + " "
//					+ (teamAgentsOnVertex >= 2 && enemyAgentsOnVertex == 0));
			
			Vertex nextPosition = null;
			
			for (Vertex node : nodesToCheck) {
				
				// try to find free position
				if (world.numTeamAgentsOnVertex(node.name) == 0) {
					
					// try to find safe position
					if (world.isSafePosition(node.name)) {
						nextPosition = node;
						break;
					}
					
					// try to find semi-safe position
					if (world.isSemiSafePosition(node.name)) {
						nextPosition = node;
					} 
				}
			}
			
			// choose random position if there is no free or safe position
			if (nextPosition == null) {
				nextPosition =  nodesToCheck.getFirst();
			}
			
//			System.err.println(world.currentStep + " | " + agent.name + " spread position : " + 
//					nextPosition.name); 
			
			return nextPosition;
		}
		
//		System.err.println(world.currentStep + " | " + agent.name + " best position : " + 
//				bestPosition.name + " (" + bestScore + ")"); 
		
		return bestPosition;
	}
	
	private boolean isAllNeighborsInZone(Vertex vertex) {
		
		for (Vertex neighbor : world.getNeighborNodes(vertex)) {
			if (!world.isVertexInZone(neighbor)) {
				return false;
			}
		}
		
		return true;
	}

	/**
	 * Returns the difference between old and new score 
	 * if an agent would change his position to {@code vertex}. 
	 * 
	 * @param vertex	agent's new position
	 * @return	zones' score after changing position
	 */
	private int getNewPositionScore(Bot agent, Vertex vertex) {
		
		// backup agent's position and vertices' teams		
		String agentPositionBackup = agent.position;
		
		String[] nodesDominationBackup = new String[1000]; //world.getVertices().size() * 5];
		for (Map.Entry<String, Vertex> v : world.getVertices().entrySet()) {
			int index = Integer.parseInt(v.getValue().name.substring(6));
			nodesDominationBackup[index] = v.getValue().team;
		}
		
		// change agent's position
		Vertex oldPosition = world.vertices.get(agent.position);
		Vertex newPosition = vertex;		
		agent.position = newPosition.name;
		
		// First step: basic domination
		
		// update agent's old and new position only
		calculateBasicNodeDomination(oldPosition, world);
		calculateBasicNodeDomination(newPosition, world);
		
		// Second step: neighbor domination
		
		// check old and new position's neighbors only
		LinkedList<Vertex> newAndOldNeighbors = world.getNeighborNodes(oldPosition);
		for (Vertex v : world.getNeighborNodes(newPosition)) {
			if (!newAndOldNeighbors.contains(v)) {
				newAndOldNeighbors.add(v);
			}
		}
				
		Map<Vertex, String> m = new HashMap<Vertex, String>();
		
		for (Vertex nb : newAndOldNeighbors){
			if ((nb.getTeam().equals("none")) && isEmptyOfActiveAgents(nb, world)){
				String domin = calculateDominatorFromNeighbours(nb, world);
				if (!domin.equals("none")){
					m.put(nb, domin);
				}
			}
		}
		
		for (Vertex n : m.keySet()){
			n.setTeam(m.get(n));
		}
		
		// Third step: isolated zone domination
		
		ArrayList<Vertex> emptyNodesList = getEmptyNodesList(world.getVertices(), world);
		HashSet<Vertex> nodesChecked = new HashSet<Vertex>();
		
		while (!emptyNodesList.isEmpty()){
			
			HashSet<Vertex> subgraphNodes;
			ArrayList<Vertex> nodesToCheck;
			boolean isolated = true;
			String dominatorTeam = "none";
			
			Vertex node = emptyNodesList.remove(0);
			subgraphNodes = new HashSet<Vertex>();			
			nodesToCheck = new ArrayList<Vertex>();
			nodesToCheck.add(node);
			
			while (!nodesToCheck.isEmpty()){
				node = nodesToCheck.remove(0);
				subgraphNodes.add(node);
				List<Vertex> neighbors = world.getNeighborNodes(node);
				for (Vertex neighbor: neighbors){
					if (neighbor.getTeam().equals("none") && isEmptyOfActiveAgents(neighbor, world)){
						if (!nodesChecked.contains(neighbor) && !nodesToCheck.contains(neighbor)){
							nodesToCheck.add(neighbor);
							emptyNodesList.remove(neighbor);
						}
					}
					else if (isolated && !neighbor.getTeam().equals("none") 
							&& (dominatorTeam.equals("none") || neighbor.getTeam().equals(dominatorTeam))){
						dominatorTeam = neighbor.getTeam();
					}
					else {
						isolated = false;
						dominatorTeam = "none";
					}
				}
				nodesChecked.add(node);
			}
			
			if (isolated && !dominatorTeam.equals("none")){
				for (Vertex isolatedNode: subgraphNodes){			
					isolatedNode.setTeam(dominatorTeam);
				}
			}
		}
		
		// Now compute the zones that have been created.
		
		LinkedList<Zone> tmpZones = new LinkedList<Zone>();
		LinkedList<Zone> tmpZonesEnemy = new LinkedList<Zone>();
		
		for (Bot bot : world.getAllAgents()) {
			bot.myZone = null;
		}
		
		LinkedList<Bot> allAgents =	world.getAllAgents(); //Agents to review
		
		while (!allAgents.isEmpty()){			
			
			Bot bot = allAgents.removeFirst();
			Vertex agentPosition = world.getAgentPosition(bot);
			String agentTeam = world.getAgentTeam(bot);
			
			if (agentPosition.team.equals(agentTeam)) {
				int score = 0;
				
				LinkedList<Bot> zoneAgents = new LinkedList<Bot>();
				LinkedList<Vertex> zoneNodes = new LinkedList<Vertex>();
				LinkedList<Vertex> nodesToCheck = new LinkedList<Vertex>();
				
				zoneNodes.add(agentPosition);
				nodesToCheck.add(agentPosition);
				
				while(!nodesToCheck.isEmpty()){
					Vertex node = nodesToCheck.removeFirst();
					score += node.value;
					
					// If node has agents, add all agents from team
					for (Bot agentInNode : world.getAgentsOnVertex(node, agentTeam)) {
						if (agentTeam.equals(world.getAgentTeam(agentInNode))) {
							zoneAgents.add(agentInNode);
						}	
						allAgents.remove(agentInNode);
					}
	
					for (Vertex neighbor : world.getNeighborNodes(node)) {
						if (neighbor.team.equals(agentTeam)	&& !zoneNodes.contains(neighbor)) {
							// Node belongs to zone
							zoneNodes.add(neighbor);
							nodesToCheck.add(neighbor);
						}	
					}
				}
				
				if (zoneNodes.size() > 1) {					
					Zone zone = new Zone(zoneAgents, zoneNodes, zoneNodes.size(), score);
					
					if (agentTeam.equals("own")) {
						tmpZones.add(zone);
					} else if (agentTeam.equals("enemy")) {
						tmpZonesEnemy.add(zone);
					}	
				}
			}
		}
		
		int newOwnZonesScore = 0;
		for (Zone zone : tmpZones) {
			newOwnZonesScore += zone.getScore();
		}	
		
		int newEnemyZonesScore = 0;
		for (Zone zone : tmpZonesEnemy) {
			newOwnZonesScore += zone.getScore();
		}
		
//		// calculate own zones' score
//		int newOwnZonesScore = 0;
//		System.out.print("[");
//		for (Map.Entry<String, Vertex> vx : world.getVertices().entrySet()) {
//			if ((vx.getValue().getTeam().equals("own")) && (world.numTeamNeighborNodes(vx.getValue()) > 0)) {
//				System.out.print(vx.getKey()+ ",");
//				newOwnZonesScore += vx.getValue().value;
//			}
//		}
//		System.out.print("]");
//		// calculate enemy zones' score
//		int newEnemyZonesScore = 0;
//		for (Map.Entry<String, Vertex> vx : world.getVertices().entrySet()) {
//			if ((vx.getValue().getTeam().equals("enemy")) && (world.numEnemyNeighborNodes(vx.getValue()) > 0)) {
//				newEnemyZonesScore += vx.getValue().value;
//			}
//		}
		
		// calculate new score
		int ownZonesScore = world.getTeamZonesScore();
		int enemyZonesScore = world.getEnemyZonesScore();
		
		int score = (newOwnZonesScore - ownZonesScore) + (enemyZonesScore - newEnemyZonesScore);
		
//		System.out.println(vertex.name + " (" + newOwnZonesScore + "-" + ownZonesScore + ") " +
//				"+ (" + enemyZonesScore + "-" + newEnemyZonesScore + ") = " + score);
		
		// restore world's original state
		agent.position = agentPositionBackup;
		
		for (Map.Entry<String, Vertex> v : world.getVertices().entrySet()) {
			int index = Integer.parseInt(v.getValue().name.substring(6));
			v.getValue().team = nodesDominationBackup[index];
		}
		
		return score;		
	}
	
//	/**
//	 * Returns a position, where an agent can maximize own zones' score
//	 * and minimize enemy zones' score.
//	 * 
//	 * @return	a position with maximum zones' score difference
//	 */
//	public Vertex getTheBestPosition() {
//		
//		// check agent's actual position and all neighbors
//		Vertex agentPosition = world.vertices.get(world.self.position);
//		LinkedList<Vertex> nodesToCheck = world.getNeighborNodes(agentPosition);
//		nodesToCheck.add(agentPosition);
//		
//		Vertex bestPosition = agentPosition;
//		int bestScore = 0;
//		
//		for (Vertex node : nodesToCheck) {
//			int score = getNewPositionScore(node);
//			if (score >= bestScore) { 
//				if (canGoTo(agentPosition, node)) {
//					bestPosition = node;
//					bestScore = score;
//				}
//			}			
//		}
//		
////		if (bestPosition.name.equals(world.self.position)) {
////			System.out.println("Step " + world.currentStep + " | " + world.username + "(" + world.self.position + ") is staying on " + world.self.position);
////		}
////		
////		if (bestScore > 0) 
////			System.out.println("Step " + world.currentStep + " | " + world.username + "(" + world.self.position + ") best position : " + bestPosition.name + " | benefit " + bestScore);
//		
//		return bestPosition;
//	}
	
//	/**
//	 * Returns the difference between old and new score 
//	 * if an agent would change his position to {@code vertex}. 
//	 * 
//	 * @param vertex	agent's new position
//	 * @return	zones' score after changing position
//	 */
//	private int getNewPositionScore(Vertex vertex) {
//		
//		// backup agent's position and vertices' teams		
//		String agentPositionBackup = world.self.position;
//		
//		String[] nodesDominationBackup = new String[1000]; //world.getVertices().size() * 5];
//		for (Map.Entry<String, Vertex> v : world.getVertices().entrySet()) {
//			int index = Integer.parseInt(v.getValue().name.substring(6));
//			nodesDominationBackup[index] = v.getValue().team;
//		}
//		
//		// change agent's position
//		Vertex oldPosition = world.vertices.get(world.self.position);
//		Vertex newPosition = vertex;		
//		world.self.position = newPosition.name;
//		
//		// First step: basic domination
//		
//		// update agent's old and new position only
//		calculateBasicNodeDomination(oldPosition, world);
//		calculateBasicNodeDomination(newPosition, world);
//		
//		// Second step: neighbor domination
//		
//		// check old and new position's neighbors only
//		LinkedList<Vertex> newAndOldNeighbors = world.getNeighborNodes(oldPosition);
//		for (Vertex v : world.getNeighborNodes(newPosition)) {
//			if (!newAndOldNeighbors.contains(v)) {
//				newAndOldNeighbors.add(v);
//			}
//		}
//				
//		Map<Vertex, String> m = new HashMap<Vertex, String>();
//		
//		for (Vertex nb : newAndOldNeighbors){
//			if ((nb.getTeam().equals("none")) && isEmptyOfActiveAgents(nb, world)){
//				String domin = calculateDominatorFromNeighbours(nb, world);
//				if (!domin.equals("none")){
//					m.put(nb, domin);
//				}
//			}
//		}
//		
//		for (Vertex n : m.keySet()){
//			n.setTeam(m.get(n));
//		}
//		
//		// Third step: isolated zone domination
//		
//		ArrayList<Vertex> emptyNodesList = getEmptyNodesList(world.getVertices(), world);
//		HashSet<Vertex> nodesChecked = new HashSet<Vertex>();
//		
//		while (!emptyNodesList.isEmpty()){
//			
//			HashSet<Vertex> subgraphNodes;
//			ArrayList<Vertex> nodesToCheck;
//			boolean isolated = true;
//			String dominatorTeam = "none";
//			
//			Vertex node = emptyNodesList.remove(0);
//			subgraphNodes = new HashSet<Vertex>();			
//			nodesToCheck = new ArrayList<Vertex>();
//			nodesToCheck.add(node);
//			
//			while (!nodesToCheck.isEmpty()){
//				node = nodesToCheck.remove(0);
//				subgraphNodes.add(node);
//				List<Vertex> neighbors = world.getNeighborNodes(node);
//				for (Vertex neighbor: neighbors){
//					if (neighbor.getTeam().equals("none") && isEmptyOfActiveAgents(neighbor, world)){
//						if (!nodesChecked.contains(neighbor) && !nodesToCheck.contains(neighbor)){
//							nodesToCheck.add(neighbor);
//							emptyNodesList.remove(neighbor);
//						}
//					}
//					else if (isolated && !neighbor.getTeam().equals("none") 
//							&& (dominatorTeam.equals("none") || neighbor.getTeam().equals(dominatorTeam))){
//						dominatorTeam = neighbor.getTeam();
//					}
//					else {
//						isolated = false;
//						dominatorTeam = "none";
//					}
//				}
//				nodesChecked.add(node);
//			}
//			
//			if (isolated && !dominatorTeam.equals("none")){
//				for (Vertex isolatedNode: subgraphNodes){			
//					isolatedNode.setTeam(dominatorTeam);
//				}
//			}
//		}
//		
//		// calculate own zones' score
//		int newOwnZonesScore = 0;
//		for (Map.Entry<String, Vertex> vx : world.getVertices().entrySet()) {
//			if ((vx.getValue().getTeam().equals("own")) && (world.numTeamNeighborNodes(vx.getValue()) > 0)) {
//				newOwnZonesScore += vx.getValue().value;
//			}
//		}
//		
//		// calculate enemy zones' score
//		int newEnemyZonesScore = 0;
//		for (Map.Entry<String, Vertex> vx : world.getVertices().entrySet()) {
//			if ((vx.getValue().getTeam().equals("enemy")) && (world.numEnemyNeighborNodes(vx.getValue()) > 0)) {
//				newEnemyZonesScore += vx.getValue().value;
//			}
//		}
//		
//		// calculate new score
//		int ownZonesScore = world.zonesScore;
//		int enemyZonesScore = world.getEnemyZonesScore();
//		
//		int score = (newOwnZonesScore - ownZonesScore) + (enemyZonesScore - newEnemyZonesScore);
//		
////		System.out.println(world.self.name + " (" + (newOwnZonesScore - ownZonesScore) + ") + (" + (enemyZonesScore - newEnemyZonesScore) + ") = " + score);
//		
//		// restore world's original state
//		world.self.position = agentPositionBackup;
//		
//		for (Map.Entry<String, Vertex> v : world.getVertices().entrySet()) {
//			int index = Integer.parseInt(v.getValue().name.substring(6));
//			v.getValue().team = nodesDominationBackup[index];
//		}
//		
//		return score;		
//	}
	
	private boolean canGoTo(Bot agent, Vertex agentPosition, Vertex destination) {
		if (agentPosition.name.equals(destination.name)) {
			return true;
		}
		
		Edge edge = world.getGraph().findEdge(agentPosition, destination);
		if (edge.weight > agent.energy) {
			return false;
		} else {
			return true;
		}		
	}
	
	private ArrayList<Vertex> getEmptyNodesList(HashMap<String, Vertex> nodes, World world) {
		ArrayList<Vertex> freeNodes =  new ArrayList<Vertex>();
		for (Map.Entry<String, Vertex> node : nodes.entrySet()){			
			if (node.getValue().getTeam().equals("none") && isEmptyOfActiveAgents(node.getValue(), world)) {
				freeNodes.add(node.getValue());
			}
		}
		return freeNodes;
	}

	private void calculateBasicNodeDomination (Vertex node, World world){
		int [] numAgents = {0, 0};
		int activeAgents = 0;
		
		LinkedList<Bot> agents = world.getTeamAgentsOnVertex(node);
		LinkedList<Bot> enemyAgents = world.getEnemyAgentsOnVertex(node);

		// team agents
		for (Bot agent : agents){
			if (agent.health > 0){
				numAgents[0]++;
				activeAgents++;
			}
		}
		
		// enemy agents
		for (Bot agent : enemyAgents){
			numAgents[1]++;
			activeAgents++;
		}
		
		int max = 0;
		int dominatorTeam=-1;			
		for (int i = 0; i < numAgents.length; i++) {
			if (numAgents[i] > max){
				dominatorTeam = i;
				max = numAgents[i];
			}
			else if (numAgents[i] == max){
				dominatorTeam=-1;
			}
		}
		
		if (dominatorTeam!=-1){
			if (max * 2 < activeAgents){
				dominatorTeam = -1;
			}
		}
		
		if (dominatorTeam == 0) {
			node.setTeam("own");
		} else if (dominatorTeam == 1) {
			node.setTeam("enemy");
		} else {
			node.setTeam("none");
		}
	}

	
	private String calculateDominatorFromNeighbours(Vertex node, World world) {				
		int [] numNNodes = {0, 0};

		List<Vertex> neighbours = world.getNeighborNodes(node);
		
		for (Vertex neighbour : neighbours) {
			if (neighbour.getTeam().equals("own")) {
				numNNodes[0]++;
			} else if (neighbour.getTeam().equals("enemy")) {
				numNNodes[1]++;
			}
		}		
		
		int max = 0;
		int dominatorTeam = -1;			
		for (int i = 0; i < numNNodes.length; i++) {
			if (numNNodes[i] > max){
				dominatorTeam = i;
				max = numNNodes[i];
			}
			else if (numNNodes[i] == max){
				dominatorTeam=-1;
			}
		}		
		
		if (dominatorTeam != -1 && max < 2){
			dominatorTeam = -1;
		}
		
		if (dominatorTeam == 0) {
			return "own";
		} else if (dominatorTeam == 1) {
			return "enemy";
		}		
		return "none";
	}
	
	private boolean isEmptyOfActiveAgents(Vertex node, World world){
		LinkedList<Bot> agents = world.getTeamAgentsOnVertex(node);
		LinkedList<Bot> enemyAgents = world.getEnemyAgentsOnVertex(node);
				
		for (Bot agent : agents) {
			if (agent.health > 0){
				return false;
			}
		}
		
		for (Bot agent : enemyAgents) {
			if (agent.health > 0){
				return false;
			}
		}
		
		return true;
	}
	
}
