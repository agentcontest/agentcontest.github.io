package de.tub.mac12.states;

import java.util.LinkedList;

import de.tub.mac12.bean.DecisionBean;
import de.tub.mac12.bean.ZoneCalculator;
import de.tub.mac12.connection.MessageConstants;
import de.tub.mac12.ontology.InfoMsg;
import de.tub.mac12.ontology.Intention;
import de.tub.mac12.ontology.World;

public class CreateZone extends State {
	
	/**
	 * Defines how long should an agent wait for teammates' intentions,
	 * before he starts calculating best positions.
	 */
	private final static int WAIT_FOR_INTENTIONS = 500;
	
	/**
	 * Defines how long should an agent wait for his best position,
	 * which is calculated by the highest rank agent.
	 */
	private final static int WAIT_FOR_POSITIONS = 700;
	
	// for testing purposes
	long t0b, t0e, t1b, t1e, t2b, t2e;
	
	private ZoneCalculator zoneCalc;
	
	private String myCurrentPosition;
	private Intention myIntention;
	
	private boolean waitingForIntentions = true;
	private int[] receivedIntentions = new int[1100];
	private LinkedList<String>[] agentsCreatingZones = new LinkedList[1100];

	public CreateZone(World world) {
		super(world);
		this.zoneCalc = new ZoneCalculator(world, this);
	}	
	
	public CreateZone(World world, DecisionBean decisionBean) {
		super(world, decisionBean);
		this.zoneCalc = new ZoneCalculator(world);
	}

	@Override
	public Intention execute() {
		
		t0b = System.currentTimeMillis();
		myCurrentPosition = world.self.position;
		myIntention = null;
		if (agentsCreatingZones[world.currentStep] == null) {
			agentsCreatingZones[world.currentStep] = new LinkedList<String>();
		}
		
		// inform team members that agent wants to create zone
		sendInfoMsg(new InfoMsg(InfoMsg.WANT_TO_CREATE_ZONE, world.self.name, world.currentStep));

		// wait for other agents' intentions
		
		t1b = System.currentTimeMillis();
		waitForInfoMessages(WAIT_FOR_INTENTIONS);
		setWaitingForIntentions(false);
		t1e = System.currentTimeMillis();
//		System.out.println("TIME | CreateZone.waitForIntentions() : " + (t1e - t1b) + " ms");

		// check which agent has the highest rank
		int highestRank = 0;
		for (String agent : getAgentsCreatingZones()) {
			int agentRank = Integer.parseInt(agent.substring(3));
			if (agentRank > highestRank) {
				highestRank = agentRank;
			}
		}
		
		// if agent has the highest rank, he calculates the best positions
		int myRank = Integer.parseInt(world.self.name.substring(3));
		if (myRank > highestRank) {
			addAgentsCreatingZones(world.self.name, world.currentStep);
			zoneCalc.setWorld(world);
			zoneCalc.setState(this);
			zoneCalc.calculateZones();
			t2b = System.currentTimeMillis();
			zoneCalc.calculateBestPositions(agentsCreatingZones[world.currentStep]);
			t2e = System.currentTimeMillis();
//			System.out.println("TIME | ZoneCalculator.calculateBestPositions() : " + (t2e - t2b) + " ms");
			
			// inform other agents about their best positions
			for (String agent : agentsCreatingZones[world.currentStep]) {
				if (!agent.equals(world.self.name)) {
					String agentBestPosition = world.team.get(agent).position;
					sendInfoMsg(new InfoMsg(InfoMsg.YOUR_BEST_POSITION, world.self.name, world.currentStep, agent, agentBestPosition));
				}
			}
			
			// check if agent has to change his position
			if (world.self.position.equals(myCurrentPosition)) {
				myIntention = new Intention(MessageConstants.ACTION_RECHARGE, null);
			} else {
				myIntention = new Intention(MessageConstants.ACTION_GOTO, world.self.position);
			}
			world.self.intention = myIntention;
			
		// another agent with highest rank is calculating best position for this agent
		} else {
			waitForBestPosition(WAIT_FOR_POSITIONS);
			// if agent receive no best position in time, he recharges
			if (myIntention == null) {
				myIntention = new Intention(MessageConstants.ACTION_RECHARGE, null);
				System.err.println(world.self.name + " received no best position in time");
			}
		}
		
		setWaitingForIntentions(true);
		
		t0e = System.currentTimeMillis();
//		System.out.println("TIME | ZreateZone.execute() : " + (t0e - t0b) + " ms");
		
		return myIntention;
	}
	
	@Override
	public synchronized void handleInfoMsg(InfoMsg infoMsg) {
		
		// received another agent's intention
		if (infoMsg.getInfo().equals(InfoMsg.MY_INTENTION) && isWaitingForIntentions()) {
			if (infoMsg.getIntention().getAction().equals(MessageConstants.ACTION_GOTO)) {
				world.team.get(infoMsg.getSender()).position = infoMsg.getIntention().getParam();
			}
			receivedIntentions[infoMsg.getStep()]++;
		
		// another agent wants to create zone too
		} else if (infoMsg.getInfo().equals(InfoMsg.WANT_TO_CREATE_ZONE) && isWaitingForIntentions()) {
			addAgentsCreatingZones(infoMsg.getSender(), infoMsg.getStep());
			receivedIntentions[infoMsg.getStep()]++;
		
		// agent received his best position 
		} else if (infoMsg.getInfo().equals(InfoMsg.YOUR_BEST_POSITION) && infoMsg.getParam1().equals(world.self.name)) {
			if (myCurrentPosition.equals(infoMsg.getParam2())) {
				myIntention = new Intention(MessageConstants.ACTION_RECHARGE, null);
			} else {
				myIntention = new Intention(MessageConstants.ACTION_GOTO, infoMsg.getParam2());
			}
			world.self.intention = myIntention;
			
		} else if (infoMsg.getInfo().equals(InfoMsg.ENEMY_SAB_STRENGTH)) {
			if (getWorld().enemySaboteurEstimatedStrength < Integer.valueOf(infoMsg.getParam1())) {
				getWorld().enemySaboteurEstimatedStrength = Integer.valueOf(infoMsg.getParam1());
			}
		}
	}
	
	protected void waitForInfoMessages(int duration) {
		int waited = 0;
		while ((waited <= duration) && receivedIntentions[world.currentStep] < 9) {
			try {
				Thread.sleep(3);
			} catch (InterruptedException e) {
				// do nothing
			}
			waited += 3;
		}
		
		if (waited >= duration) {
			System.err.println(getWorld().getCurrentStep() + " | " + getWorld().getSelf().name 
					+ " has not received all INTENTIONS in time!");
		}
	}
	
	private void waitForBestPosition(int duration) {
		int waited = 0;
		while ((waited <= duration) && myIntention == null) {
			try {
				Thread.sleep(3);
			} catch (InterruptedException e) {
				// do nothing
			}
			waited += 3;
		}
	}
	
	synchronized private LinkedList<String> getAgentsCreatingZones() {
		return agentsCreatingZones[world.currentStep];
	}

	synchronized private void addAgentsCreatingZones(String agent, int step) {
		if (agentsCreatingZones[step] == null) {
			agentsCreatingZones[step] = new LinkedList<String>();
		}
		this.agentsCreatingZones[step].add(agent);
	}
	
	public boolean isTrue() {
		return true;
	}

	@Override
	protected Path getPathfinding() {
		return Path.SEMISAFE;
	}

	synchronized private boolean isWaitingForIntentions() {
		return waitingForIntentions;
	}

	synchronized private void setWaitingForIntentions(boolean waitingForIntentions) {
		this.waitingForIntentions = waitingForIntentions;
	}

	public void resetVars() {
		waitingForIntentions = true;
		
		for (int i = 0; i < receivedIntentions.length; i++) {
			receivedIntentions[i] = 0;
		}
		
		for (int i = 0; i < agentsCreatingZones.length; i++) {
			agentsCreatingZones[i] = null;
		}
	}

}
