package de.tub.mac12.bean;

import java.io.Serializable;
import java.util.Set;

import org.sercho.masp.space.event.SpaceEvent;
import org.sercho.masp.space.event.SpaceObserver;
import org.sercho.masp.space.event.WriteCallEvent;
import org.w3c.dom.Document;

import de.dailab.jiactng.agentcore.IAgentBean;
import de.dailab.jiactng.agentcore.action.AbstractMethodExposingBean;
import de.dailab.jiactng.agentcore.action.Action;
import de.dailab.jiactng.agentcore.comm.CommunicationAddressFactory;
import de.dailab.jiactng.agentcore.comm.ICommunicationAddress;
import de.dailab.jiactng.agentcore.comm.IGroupAddress;
import de.dailab.jiactng.agentcore.comm.message.IJiacMessage;
import de.dailab.jiactng.agentcore.comm.message.JiacMessage;
import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac12.connection.MessageParser;
import de.tub.mac12.ontology.AuthResponse;
import de.tub.mac12.ontology.Authentication;
import de.tub.mac12.ontology.Bot;
import de.tub.mac12.ontology.Bye;
import de.tub.mac12.ontology.InfoMsg;
import de.tub.mac12.ontology.Intention;
import de.tub.mac12.ontology.Perception;
import de.tub.mac12.ontology.SimEnd;
import de.tub.mac12.ontology.World;

public class PerceptionBean extends AbstractMethodExposingBean {

  private String                  username;
  private MessageParser           messageParser;

  private ServerCommunicationBean serverCommunicationBean;
  private DecisionBean            decisionBean;
  private ExplorerDecisionBean    explorerDecisionBean;
  private InspectorDecisionBean   inspectorDecisionBean;
  private RepairerDecisionBean    repairerDecisionBean;
  private SaboteurDecisionBean    saboteurDecisionBean;
  private DefaultDecisionBean     sentinelDecisionBean;

  /** Actions to communicate with other team members. */
  private Action                  sendAction, registerAction;

  /** The channel where agents of one team share their knowledge. */
  public IGroupAddress            teamChannel;
  public long                     time;

  private World                   world;

  public String getTeamChannel() {
    return this.teamChannel.toString();
  }

  public void setTeamChannel(String teamChannel) {
    this.teamChannel = CommunicationAddressFactory.createGroupAddress(teamChannel);
  }

  @Override
  public void doInit() throws Exception {
    super.doInit();

    for (IAgentBean ab : thisAgent.getAgentBeans()) {
      if (ab instanceof ServerCommunicationBean) {
        this.serverCommunicationBean = (ServerCommunicationBean) ab;
        messageParser = new MessageParser(serverCommunicationBean.getUsername());
      }

      if (ab instanceof ExplorerDecisionBean) {
        explorerDecisionBean = (ExplorerDecisionBean) ab;
      } else if (ab instanceof InspectorDecisionBean) {
        inspectorDecisionBean = (InspectorDecisionBean) ab;
      } else if (ab instanceof RepairerDecisionBean) {
        repairerDecisionBean = (RepairerDecisionBean) ab;
      } else if (ab instanceof SaboteurDecisionBean) {
        saboteurDecisionBean = (SaboteurDecisionBean) ab;
      } else if (ab instanceof DefaultDecisionBean) {
        sentinelDecisionBean = (DefaultDecisionBean) ab;
      } else if (ab instanceof DecisionBean) {
        this.decisionBean = (DecisionBean) ab;
      }
    }

    SpaceObserver<IFact> messageObserver = new SpaceObserver<IFact>() {
      private static final long serialVersionUID = -2109274101459190774L;

      @Override
      public void notify(SpaceEvent<? extends IFact> event) {
        if (event instanceof WriteCallEvent) {
          Object eventObj = ((WriteCallEvent) event).getObject();
          if (eventObj instanceof IJiacMessage) {
            IJiacMessage message = (IJiacMessage) eventObj;
            message = memory.remove(message);
            if (message != null) {
              IFact payload = message.getPayload();

              if (payload instanceof Perception) {
                Perception perception = (Perception) payload;

                // ignore own perception that we have received
                // via team channel
                if (!perception.username.equals(username)) {

                  // only process actual perceptions and when
                  // world is initialized
                  if ((world != null) && (world.currentStep <= perception.step)) {
                    world.update(perception);
                  }
                }

              } else if (payload instanceof InfoMsg) {
                InfoMsg infoMsg = (InfoMsg) payload;

                // ignore own action that we have received
                // via team channel
                if (!infoMsg.getSender().equals(username)) {
                  // process only actual messages
                  if (world.currentStep <= infoMsg.getStep()
                		  && world.currentStep > 1) {
                    decisionBean.getStateInstance().handleInfoMsgAndCount(infoMsg);
                  }
                }
              }
            }
          }
        }
      }
    };
    memory.attach(messageObserver);

  }

  public void doStart() throws Exception {
    super.doStart();

    Authentication auth = memory.read(new Authentication(null, null));
    if (auth != null) {
      this.username = auth.getUsername();
    } else {
      System.err.println("NO AUTHENTICATION FOUND");
    }

    // retrieving needed actions from own CommunicationBean
    sendAction = memory.read(new Action("de.dailab.jiactng.agentcore.comm.ICommunicationBean#send", null, new Class[] {
        IJiacMessage.class, ICommunicationAddress.class }, null));
    if (sendAction == null)
      throw new RuntimeException("Could not find Communication...1");

    registerAction = memory.read(new Action("de.dailab.jiactng.agentcore.comm.ICommunicationBean#joinGroup", null,
        new Class[] { IGroupAddress.class }, null));
    if (registerAction == null)
      throw new RuntimeException("Could not find Communication...2");

    invoke(registerAction, new Serializable[] { this.teamChannel });

    // When reconnecting during simulation
    // if (isRebootoing) {
    // List<IActionDescription> allActions = thisAgent.searchAllActions(new
    // Action("getWorld"));
    // if (!allActions.isEmpty()) {
    // invoke(allActions.get(0), new Serializable[]{},this);
    // }
    // }
  }

  public void processServerMessage(Document message) {
    IFact parseResult = messageParser.parse(message);

    time = System.nanoTime();

    if (parseResult instanceof Perception) {

      // Perception received
      Perception perception = (Perception) parseResult;
      perception.role = world.self.role;

      // send own perception to other agents
      sendPerception(perception);

      if (world != null) {
        world.update(perception);
        decisionBean.decide();
      } else {
        System.err.println("## [INFO] Agent " + this.username + " received ActionRequest before process SimStart!");
      }
    }

    else if (parseResult instanceof World) {

      // SimStart received
      world = (World) parseResult;
      System.out.println("World has been read: " + world);

      // switch decissionBean to match role
      if (Bot.EXPLORER.equals(world.self.role)) {
        decisionBean = explorerDecisionBean;
      } else if (Bot.INSPECTOR.equals(world.self.role)) {
        decisionBean = inspectorDecisionBean;
      } else if (Bot.REPAIRER.equals(world.self.role)) {
        decisionBean = repairerDecisionBean;
      } else if (Bot.SABOTEUR.equals(world.self.role)) {
        decisionBean = saboteurDecisionBean;
      } else if (Bot.SENTINEL.equals(world.self.role)) {
        decisionBean = sentinelDecisionBean;
      }

      decisionBean.setWorld(world);
      memory.write(world);

      if (memory.readAllOfType(World.class).size() == 1) {
        System.err.println("World found!!!");
      } else {
        System.err.println("World not found!!!");
      }

      String s = "Welt erstellt: Edges " + world.numEdges + " Vertices " + world.numVertices;
      System.out.println(s);
    }

    else if (parseResult instanceof SimEnd) {
      // SimEnd received
      SimEnd simEnd = (SimEnd) parseResult;
      simEnd.setSimName(world.simulationId);
      memory.write(simEnd);

      memory.remove(world);
      world = null;
      decisionBean.setWorld(null);
      explorerDecisionBean.setWorld(null);
      inspectorDecisionBean.setWorld(null);
      repairerDecisionBean.setWorld(null);
      saboteurDecisionBean.setWorld(null);
      sentinelDecisionBean.setWorld(null);

      System.out.println(simEnd);
    }

    else if (parseResult instanceof Bye) {

      Set<SimEnd> results = memory.readAllOfType(SimEnd.class);
      for (SimEnd rse : results) {
        System.out.println(rse);
      }
      System.out.flush();

      Runtime.getRuntime().halt(666);

    }

    else if (parseResult instanceof AuthResponse) {
      String s = ((AuthResponse) parseResult).isAuthSuccessful() ? "AUTHENTICATION OK!" : "AUTHENTICATION FAILED!";
      System.out.println(s);
    }

  }

  /**
   * Sends the own perception to all team members.
   * 
   * @param perception
   *          the perception object to send
   */
  private void sendPerception(Perception perception) {
    JiacMessage msg = new JiacMessage(perception);
    Serializable[] params = new Serializable[2];
    params[0] = msg;
    params[1] = this.teamChannel;
    invoke(sendAction, params);
  }

  /**
   * Sends the own intention to all team members.
   * 
   * @param intention
   *          the intention object to send
   */
  public void sendIntention(Intention intention) {
    JiacMessage msg = new JiacMessage(intention);
    Serializable[] params = new Serializable[2];
    params[0] = msg;
    params[1] = this.teamChannel;
    invoke(sendAction, params);
  }

  // When reconnecting during simulation
  // @Expose(scope=ActionScope.NODE)
  // public World getWorld() {
  // return world;
  // }
  //
  // @Override
  // public void receiveResult(ActionResult arg0) {
  // super.receiveResult(arg0);
  //
  // if (arg0.getAction().getName().equals("getWorld")) {
  // World obj = (World)arg0.getResults()[0];
  // }
  // }
  //
  //
}
