package de.tub.mac12.states;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map.Entry;

import de.tub.mac12.bean.DecisionBean;
import de.tub.mac12.connection.MessageConstants;
import de.tub.mac12.ontology.Bot;
import de.tub.mac12.ontology.InfoMsg;
import de.tub.mac12.ontology.Intention;
import de.tub.mac12.ontology.Vertex;
import de.tub.mac12.ontology.World;

public class Group extends State {
	
	private boolean grouped = false;
	private boolean existsPathToGameField = false;
	private HashSet<String> visitedPositions = new HashSet<String>();

	public Group(World world, DecisionBean db) {
		super(world, db);
	}

	@Override
	public Intention execute() {
		
		// SABOTEUR : attack enemy on the same position 
		if (getWorld().getSelf().role.equals(Bot.SABOTEUR)) {
			
			// check if there is an enemy on the same position
			for (Entry<String, Bot> enemy : getWorld().opponents.entrySet()) {
				if (enemy.getValue().isAlive() 
						&& enemy.getValue().lastSeen == getWorld().getCurrentStep()
						&& enemy.getValue().position.equals(getWorld().getMyPosition())) {
					
					return new Intention(MessageConstants.ACTION_ATTACK, enemy.getValue().name);
				}
			}
		}
		
		// REPAIRER : repair agents on the same position 
		if (getWorld().getSelf().role.equals(Bot.REPAIRER)) {
			
			// check if there is an disabled agent on the same position
			for (Entry<String, Bot> agent : getWorld().team.entrySet()) {
				if (!agent.getValue().isAlive()
						&& agent.getValue().lastSeen == getWorld().getCurrentStep()
						&& agent.getValue().position.equals(getWorld().getMyPosition())) {
					
					return new Intention(MessageConstants.ACTION_REPAIR, agent.getValue().name);
				}
			}
		}
		
		// INSPECTOR : inspect enemy on the same or neighbor position 
		if (getWorld().getSelf().role.equals(Bot.INSPECTOR)) {
			
			LinkedList<Vertex> neighbors = getWorld().getNeighborNodes(getWorld().getMyPosition());
			neighbors.add(getWorld().getMyPosition());
			
			// look for not inspected enemies in neighborhood
			for (Entry<String, Bot> enemy : getWorld().opponents.entrySet()) {
				
				Vertex enemyPosition = getWorld().getAgentPosition(enemy.getValue());
				if (neighbors.contains(enemyPosition) 
						&& !enemy.getValue().inspected
						&& enemy.getValue().lastSeen == getWorld().getCurrentStep()) {
					
					return new Intention(MessageConstants.ACTION_INSPECT, null);
				}
			}
		}
		
		// go to game field if there is a path
		String nextVertexToGo= null;
		nextVertexToGo = getPathNextVertex(getWorld().getGameFieldCenter());
		
		if (nextVertexToGo != null) {
			return new Intention(MessageConstants.ACTION_GOTO, nextVertexToGo);			
		// there is no path, explore the world and try to avoid already visited positions
		} else {
			
			LinkedList<Vertex> neighborVertices = getWorld().getNeighborNodes(getWorld().getMyPosition());
			for (Vertex node : neighborVertices) {
				if (!visitedPositions.contains(node.name)) {
					return new Intention(MessageConstants.ACTION_GOTO, node.name);
				}
			}
			
			return new Intention(MessageConstants.ACTION_GOTO, neighborVertices.getFirst().name);			
		}
	}

	@Override
	protected void handleInfoMsg(InfoMsg infoMsg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isTrue() {
		
		if (grouped) {
			return false;
		}
		
		if (getWorld().isInGameField(getWorld().getMyPosition())) {
			grouped = true;
			existsPathToGameField = true;
			return false;
			
		} else {			
			
			if (!existsPathToGameField) {
				visitedPositions.add(getWorld().getMyPosition().name);
				for (Entry<String, Bot> agent : getWorld().getTeam().entrySet()) {
					visitedPositions.add(agent.getValue().position);
				}
			}
			
			return true;
		}
			
		
	}

	@Override
	protected Path getPathfinding() {
		return Path.SAFE;
	}

	public void setGrouped(boolean grouped) {
		this.grouped = grouped;
	}
	
}
