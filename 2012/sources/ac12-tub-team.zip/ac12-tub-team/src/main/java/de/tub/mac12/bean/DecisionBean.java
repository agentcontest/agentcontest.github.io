package de.tub.mac12.bean;

import java.io.Serializable;
import java.util.LinkedList;

import org.w3c.dom.Document;

import de.dailab.jiactng.agentcore.IAgentBean;
import de.dailab.jiactng.agentcore.action.AbstractMethodExposingBean;
import de.dailab.jiactng.agentcore.action.Action;
import de.dailab.jiactng.agentcore.comm.ICommunicationAddress;
import de.dailab.jiactng.agentcore.comm.IGroupAddress;
import de.dailab.jiactng.agentcore.comm.message.IJiacMessage;
import de.dailab.jiactng.agentcore.comm.message.JiacMessage;
import de.tub.mac12.connection.ActionFactory;
import de.tub.mac12.connection.MessageConstants;
import de.tub.mac12.ontology.Bot;
import de.tub.mac12.ontology.Edge;
import de.tub.mac12.ontology.InfoMsg;
import de.tub.mac12.ontology.Intention;
import de.tub.mac12.ontology.Vertex;
import de.tub.mac12.ontology.World;
import de.tub.mac12.states.CreateZone;
import de.tub.mac12.states.Disabled;
import de.tub.mac12.states.Group;
import de.tub.mac12.states.State;
import de.tub.mac12.states.SurveyEdges;
import edu.uci.ics.jung.algorithms.filters.KNeighborhoodFilter;
import edu.uci.ics.jung.algorithms.filters.KNeighborhoodFilter.EdgeType;
import edu.uci.ics.jung.graph.Graph;

public abstract class DecisionBean extends AbstractMethodExposingBean {

	private World world;
	IGroupAddress teamChannel;
	PerceptionBean perceptionBean;
	ServerCommunicationBean serverCommunicationBean;
	Action sendAction;

	public SurveyEdges surveyEdges;
	public CreateZone createZone;
	public State disabled;
	public State repair;
	public State attack;
	public State inspect;
	public State explore;
	public Group group;
	public State escape;
	public State buy;

	private final static int WAIT_FOR_PERCEPTIONS = 1500;
	
	private State stateInstance;

	public Intention intention = new Intention(null, null);
	protected LinkedList<State> statesList;
	private boolean initialized = false;

	public void setWorld(World world) {
		this.world = world;
	}

	@Override
	public void doStart() {
		for (IAgentBean ab : thisAgent.getAgentBeans()) {
			if (ab instanceof PerceptionBean) {
				this.perceptionBean = ((PerceptionBean) ab);
				this.teamChannel = perceptionBean.teamChannel;
			}
			if (ab instanceof ServerCommunicationBean) {
				this.serverCommunicationBean = (ServerCommunicationBean) ab;
			}
		}
		// retrieving needed actions from own CommunicationBean
		sendAction = memory.read(new Action(
				"de.dailab.jiactng.agentcore.comm.ICommunicationBean#send",
				null, new Class[] { IJiacMessage.class,
						ICommunicationAddress.class }, null));
		if (sendAction == null)
			throw new RuntimeException("Could not find Communication...1");
		statesList = new LinkedList<State>();
		addStatesAndConditions();
	}

	/**
	 * Class for inserting new States and Conditions. For classes which extend
	 * {@code this}, override this method and add additional content to
	 * {@code stateGraph}.
	 * 
	 * @return
	 */
	protected void addStatesAndConditions() {
		
		// states used by all agents
		disabled 	= new Disabled(world, this);
		group 		= new Group(world, this);
		surveyEdges = new SurveyEdges(world, this);
		createZone 	= new CreateZone(world, this);
		
		// start with surveyEdges by default
		setStateInstance(group);
	}

	public void decide() {
		if (getWorld().getCurrentStep() == 0) {
			group.setGrouped(false);
			createZone.resetVars();
		}
		createZone.setWorld(world);
		waitForPerceptions(WAIT_FOR_PERCEPTIONS);
		if (getWorld().isNewGameField()) {
			getWorld().setNewGameField(false);
			group.setGrouped(false);
		}
		if (getWorld().getCurrentStep() > 0) {
			getWorld().defineGameField();
			getWorld().calculateUnsafeVertices();
			getWorld().calculateSemiUnsafeVertices();
			stateInstance = defineState();
			if (!initialized && getWorld() != null) {
				initialize();
			}
			logStatus();
			intention = stateInstance.doStep();

			broadcastIntention(intention);
			sendActionResponse(intention);

		} else {

			if (getWorld().getSelf().role.equals(Bot.EXPLORER)) {
				intention = new Intention(MessageConstants.ACTION_PROBE, null);
			} else {
				intention = new Intention(MessageConstants.ACTION_SURVEY, null);
			}
			sendActionResponse(intention);
		}
	}

	/**
	 * Send intention to other agents
	 * 
	 */
	public void broadcastIntention(Intention intention) {
		sendInfoMsg(new InfoMsg(InfoMsg.MY_INTENTION,
				getWorld().getSelf().name, getWorld().currentStep, intention));
	}

	private void initialize() {
		for (State state : getStatesList()) {
			if (state.getWorld() == null) {
				stateInstance.setWorld(getWorld());
			}
			if (state.getDecisionBean() == null) {
				stateInstance.setDecisionBean(this);
			}
		}

		initialized = true;
	}

	/**
	 * Checks if a state change is possible and returns a new state.
	 * 
	 * @return
	 */
	private State defineState() {

		for (State state : statesList) {
			state.setWorld(getWorld());
			if (state.isTrue()) {
				return state;
			}
		}

		return getStatesList().getLast();
	}

	/**
	 * Prints information about the current status of agent.
	 */
	private void logStatus() {
		synchronized (world) {
			StringBuffer output = new StringBuffer();
			Graph<Vertex, Edge> gameField = getWorld().getGameField();
			output.append(getWorld().currentStep);
			output.append(" | ");
			output.append(getWorld().getSelf().role);
			output.append(" ");
			output.append(getWorld().self.name);
			// output.append(" on ").output.append(getStateInstance().getCurrentPosition().name);
			output.append(" tried ");
			output.append(getWorld().getSelf().lastAction).append(" ");
			output.append(intention.getParam());
			output.append("\t | Sccs: ");
			output.append(getWorld().self.lastActionSuccess);
			output.append(" | En: ").append(getWorld().self.energy);
//			output.append(" | KnownEdges: ").append(gameField.getEdgeCount());
			Graph<Vertex, Edge> unweighted = stateInstance.getUnweightedGraph(gameField);
			output.append(" | Unsurveyed: ").append(unweighted.getEdgeCount());
			output.append(" | Unprobed: ").append(getWorld().getUnprobedVertices().size());
			output.append(" | State: ").append(stateInstance.getClass().toString().substring(26));
			System.out.println(output.toString());
		}
	}

	/**
	 * Sends InfoMsg of this agent to all other agents in the team
	 * 
	 * @param infoMsg
	 *            the information to send
	 */
	public void sendInfoMsg(InfoMsg infoMsg) {
		JiacMessage msg = new JiacMessage(infoMsg);
		Serializable[] params = new Serializable[2];
		params[0] = msg;
		params[1] = this.teamChannel;
		invoke(sendAction, params);

	}

	public void sendActionResponse(Intention intention) {
		try {
			Document response = ActionFactory.getAction(intention.action,
					intention.param, getWorld().id);
			serverCommunicationBean.sendActionResponse(response);
		} catch (NullPointerException e) {
			e.printStackTrace();
			System.err.println("type of agent: " + getWorld().getSelf().role);
		}

		// System.out.println("time: " + (System.nanoTime() -
		// perceptionBean.time));
	}

	public World getWorld() {
		return this.world;
	}

	/**
	 * Wait for other agents' perceptions.
	 * 
	 * @param duration
	 *            Defines for how long an agent should wait.
	 */
	private void waitForPerceptions(int duration) {
		int waited = 0;
		int numberOfAgents = getWorld().team.size();
		while (waited <= duration) {
			synchronized (world) {
				if ((world.receivedPerceptions[world.currentStep] >= numberOfAgents)) {
					break;
				}
			}

			try {
				Thread.sleep(5);
			} catch (InterruptedException e) {
				// do nothing
			}
			waited += 5;
		}
//		System.out.println(getWorld().getCurrentStep() + " | " + getWorld().getSelf().name 
//				+ " waited for PERCEPTIONS : " + waited + "ms");
		if (waited >= duration) {
			System.err.println(getWorld().getCurrentStep() + " | " + getWorld().getSelf().name 
					+ " has not received all PERCEPTIONS in time!");
		}
	}

	public LinkedList<State> getStatesList() {
		return statesList;
	}

	public State getStateInstance() {
		return stateInstance;
	}

	public void setStateInstance(State stateInstance) {
		this.stateInstance = stateInstance;
	}

	/**
	 * The return value of this method is needed to calculate the desired
	 * maximum value of health.
	 * 
	 * @return
	 */
	public int getHealthPuffer() {
		return 0;
	}

}