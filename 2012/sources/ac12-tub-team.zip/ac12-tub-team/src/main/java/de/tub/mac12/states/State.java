package de.tub.mac12.states;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.NoSuchElementException;

import org.apache.commons.collections15.Predicate;

import de.dailab.jiactng.agentcore.action.Action;
import de.dailab.jiactng.agentcore.comm.IGroupAddress;
import de.tub.mac12.bean.DecisionBean;
import de.tub.mac12.connection.MessageConstants;
import de.tub.mac12.ontology.Bot;
import de.tub.mac12.ontology.Edge;
import de.tub.mac12.ontology.InfoMsg;
import de.tub.mac12.ontology.Intention;
import de.tub.mac12.ontology.Vertex;
import de.tub.mac12.ontology.World;
import de.tub.mac12.util.WeightReader;
import edu.uci.ics.jung.algorithms.filters.EdgePredicateFilter;
import edu.uci.ics.jung.algorithms.shortestpath.DijkstraDistance;
import edu.uci.ics.jung.algorithms.shortestpath.DijkstraShortestPath;
import edu.uci.ics.jung.graph.Graph;

/**
 * The default interface for every state in this package. A class which
 * implements {@code this} computes the next intention for an agent.
 * 
 * @author benjamin
 * 
 */
public abstract class State {
	
	IGroupAddress teamChannel;
	Action sendAction;

	protected World world;

	private EdgePredicateFilter<Vertex, Edge> weightFilter;
	private DecisionBean db;
	
	/**
	 * In this map bots which registered theirselves
	 */
	private HashMap<Bot, Integer> registeredAgents = new HashMap<Bot, Integer>();

	public State(World world, DecisionBean db) {
		// setGraph(world.getGraph());
		setWorld(world);
		setDecisionBean(db);
	}

	public State(World world) {
		setWorld(world);
	}

	/**
	 * Agents always try to recharge up to their max energy before any other
	 * action. Exceptions are attack, repair and inspect and they will be always
	 * performed at first if agent has enough energy. Actions in escape state
	 * will be always performed.
	 * 
	 */
	public Intention doStep() {
		Intention intention = null;

		if (getWorld().currentStep > 1) {
			estimateEnemySaboteursStrength();
		}
		
		// evaluateLastAction();
		clearRegisteredAgents();
		// inform team members
		sendInfoMsg(new InfoMsg(this.getClass().toString(), getWorld()
				.getSelf().name, getWorld().getCurrentStep(),
				InfoMsg.REGISTRATION));

		// agent always recharges if has no energy
		if (getWorld().getSelf().energy == 0) {
			return new Intention(MessageConstants.ACTION_RECHARGE, null);

		} else {

			int myEnergy = getWorld().getSelf().energy;
			State currentState = db.getStateInstance();

			// saboteur always attacks if has enough energy
			if (currentState instanceof Attack) {
				intention = execute();
				if (intention.action.equals(MessageConstants.ACTION_ATTACK)
						&& myEnergy >= 2) {
					return intention;
				}
			} 
			
			// saboteur always attacks if has enough energy
			if (currentState instanceof Group) {
				intention = execute();
				if (intention.action.equals(MessageConstants.ACTION_ATTACK)
						&& myEnergy >= 2) {
					return intention;
				}
			}

			// repairer always repairs if has enough energy
			if (currentState instanceof Repair) {
				intention = execute();
				if (intention.action.equals(MessageConstants.ACTION_REPAIR)
						&& myEnergy >= 2) {
					return intention;
				}
			}

			// inspector always inspects if has enough energy
			if (currentState instanceof Inspect) {
				intention = execute();
				if (intention.action.equals(MessageConstants.ACTION_INSPECT)
						&& myEnergy >= 2) {
					return intention;
				}
			}
			
			// inspector always inspects if has enough energy
			if (currentState instanceof Group) {
				intention = execute();
				if (intention.action.equals(MessageConstants.ACTION_INSPECT)
						&& myEnergy >= 2) {
					return intention;
				}
			}

			// agent in escape state decides about the best action for him
			if (currentState instanceof Escape) {
				intention = execute();
				return intention;
			}

			// agent tries not to attack/repair/inspect or has energy < 2

			int myMaxEnergy = getWorld().getSelf().getMaxAvailableEnergy();
			long rechargeValue = Math.round(myMaxEnergy * 0.3);

			// agent recharges up to full energy before any other action
			if (myMaxEnergy - rechargeValue >= myEnergy) {
				return new Intention(MessageConstants.ACTION_RECHARGE, null);

				// agent does his intention if has full energy
			} else {
				if (intention == null) {
					intention = execute();
				}
				return intention;
			}
		}
	}

	private void estimateEnemySaboteursStrength() {
		
		int healthDifference = getWorld().getSelf().previousHealth - getWorld().getSelf().health;
		
		if (healthDifference > 0) {
			
			int numEnemySaboteurs = 0;
			for (Bot enemy : getWorld().getEnemySaboteurs()) {
				if (enemy.position.equals(getWorld().getSelf().position) 
						&& enemy.lastSeen == getWorld().getCurrentStep()) {
					numEnemySaboteurs++;
				}
			}	
						
			if (numEnemySaboteurs == 1) {
				getWorld().enemySaboteurEstimatedStrength = healthDifference;
				sendInfoMsg(new InfoMsg(InfoMsg.ENEMY_SAB_STRENGTH, world.self.name, world.currentStep, 
						String.valueOf(healthDifference)));
			}
		}
		
	}

	private synchronized void clearRegisteredAgents() {
		for (Bot agent : getWorld().getTeam().values()) {
			if (getRegisteredAgents().get(agent) != null) {
				if (getRegisteredAgents().get(agent) != getWorld()
						.getCurrentStep()) {
					getRegisteredAgents().remove(agent);
				}
			}
		}
	}

	public abstract Intention execute();

	/**
	 * A method which performs an action when @ code} receives an
	 * {@code InfoMsg}
	 * 
	 * @param infoMsg
	 */
	public void handleInfoMsgAndCount(InfoMsg infoMsg) {
		// if(infoMsg.getStep() == getWorld().getCurrentStep()){
		// registerAgent(infoMsg);
		// }
//		handleInfoMsg(infoMsg);
		db.createZone.handleInfoMsg(infoMsg);
	}

	protected abstract void handleInfoMsg(InfoMsg infoMsg);

	/**
	 * Sends InfoMsg of this agent to all other agents in the team
	 * 
	 * @param infoMsg
	 *            the information to send
	 */
	protected void sendInfoMsg(InfoMsg infoMsg) {
		getDecisionBean().sendInfoMsg(infoMsg);
	}

	public World getWorld() {
		return world;
	}

	/**
	 * Returns the first Vertex on the shortest path to target.
	 * 
	 * @param target
	 * @return
	 */
	private String getPathNextVertexNormal(Vertex target) {
		return computeNextVertexName(target, null);
	}

	/**
	 * Returns the first Vertex on path to target, in which the first Vertex has
	 * no enemy saboteurs.
	 * 
	 * @param target
	 * @return
	 */
	private String getPathNextVertexSemiSafe(Vertex target) {
		
		String vertex = computeNextVertexName(target, getWorld().getSemiUnsafeVertices());
		
		if (vertex == null) {
			vertex = computeNextVertexName(target, null);
		}
		
		return vertex;
	}

	/**
	 * Returns the first Vertex on path to target, in which the first Vertex has
	 * no enemy saboteurs, and no saboteurs in his direct neighborhood.
	 * 
	 * @param target
	 * @return
	 */
	private String getPathNextVertexSafe(Vertex target) {
		
		String vertex = computeNextVertexName(target, getWorld().getUnsafeVertices());
		
		if (vertex == null) {
//			System.err.println(getWorld().getCurrentStep() + " | " + getWorld().getSelf().name
//					+ " : there is no safe path to " + target.name);
			vertex = computeNextVertexName(target, getWorld().getSemiUnsafeVertices());
		}
		
		if (vertex == null) {
//			System.err.println(getWorld().getCurrentStep() + " | " + getWorld().getSelf().name
//					+ " : there is no semi-safe path to " + target.name);
			vertex = computeNextVertexName(target, null);
		}
		
		return vertex;
	}

	/**
	 * Returns the next vertex on the path to {@code target}. Avoids taking
	 * vertices in blacklist.
	 * 
	 * @return
	 */
	protected String computeNextVertexName(Vertex target, Collection<Vertex> blacklist) {
		
		if (getWorld().getCurrentPosition() == null) {
			System.err.println("getNextVertexName(): Waiting for initialization... "
							+ "\n Returning null");
			return null;
		}
		
		if (target == null) {
			System.err.println("getNextVertexName(): Target is null");
			return null;
		}
		
		if (blacklist != null) {
			
			if (blacklist.contains(getWorld().getMyPosition())) {
				blacklist.remove(getWorld().getMyPosition());
			}
			
			if (blacklist.contains(target)) {
				return null;
			}
		}
		
//		DijkstraDistance<Vertex, Edge> calculator = new DijkstraDistance<Vertex, Edge>(getReducedGraph(blacklist));
//		if (calculator.getDistance(getWorld().getCurrentPosition(), target) == null) {
////			System.err
////					.println("getNextVertexName(): No connection between current position and target.");
//			return null;
//		}

		LinkedList<Edge> path = getPath(getWorld().getCurrentPosition(), target, blacklist);
		
		if (path.isEmpty()) {
			return null;
		}
		
		Edge nextEdge;
		String nextVertex = null;
		
		try {
			nextEdge = path.getFirst();
			if (nextEdge.node1.equals(getWorld().getSelf().getPosition())) {
				nextVertex = nextEdge.node2;
			} else if (nextEdge.node2
					.equals(getWorld().getSelf().getPosition())) {
				nextVertex = nextEdge.node1;
			} else {
				System.out.println(nextEdge.id + " is not incident with " + getWorld().getCurrentPosition());
			}
		} catch (NoSuchElementException e) {
			e.printStackTrace();
		}

		return nextVertex;
	}

	/**
	 * Computes the shortest path from {@code start} to {@code end}. This method
	 * only takes edges whose weights are less or equal to the current max
	 * energy.
	 * 
	 * @param start
	 *            The vertex where the returned path starts
	 * @param end
	 *            The vertex where the returned path ends
	 * @param blacklist
	 *            A list of vertices which must not appear in the resulting path
	 * @return
	 */
	protected LinkedList<Edge> getPath(Vertex start, Vertex end, Collection<Vertex> blacklist) {
		
		DijkstraShortestPath<Vertex, Edge> shortestPathCalculator = new DijkstraShortestPath<Vertex, Edge>(
				getReducedGraph(blacklist), new WeightReader());
		
		return new LinkedList<Edge>(shortestPathCalculator.getPath(start, end));
	}
	
	public Vertex getNextVertex(Vertex start, Vertex end) {
		
		DijkstraShortestPath<Vertex, Edge> distanceCalculator = new DijkstraShortestPath<Vertex, Edge>(
				getWorld().getGraph(), new WeightReader());
		LinkedList<Edge> path = (LinkedList<Edge>) (distanceCalculator.getPath(start, end));
		
		Edge nextEdge;
		String nextVertex = null;
		try {
			nextEdge = path.getFirst();
			if (nextEdge.node1.equals(start.name)) {
				nextVertex = nextEdge.node2;
			} else if (nextEdge.node2.equals(start.name)) {
				nextVertex = nextEdge.node1;
			} else {
				System.out.println(nextEdge.id + " is not incident with "
						+ getWorld().getCurrentPosition());
			}
		} catch (NoSuchElementException e) {
			e.printStackTrace();
		}
		
		return getWorld().getVertices().get(nextVertex);
	}

	protected Graph<Vertex, Edge> getReducedGraph(Collection<Vertex> blacklist) {
		
		if (blacklist == null) {
			return getWorld().getGraph();
			
		} else {		
			return  getWorld().getReducedGraph(blacklist);
		}
		
//		Graph<Vertex, Edge> reducedGraph = getWorld().getAvaliableEdgesGraph();
//		if (blacklist != null) {
//			Vertex position = getWorld().getCurrentPosition();
//			Collection<Vertex> neighbors = reducedGraph.getNeighbors(position);
//			for (Vertex vertex : blacklist) {
//				if (neighbors.contains(vertex)) {
//					reducedGraph.removeVertex(vertex);
//				}
//			}
//		}
//		return reducedGraph;
	}

	public void setWorld(World world) {
		this.world = world;
	}

	public void setWeightFilter(EdgePredicateFilter<Vertex, Edge> weightFilter) {
		this.weightFilter = weightFilter;
	}

	public EdgePredicateFilter<Vertex, Edge> getWeightFilter() {
		return weightFilter;
	}

	/**
	 * Creates a subgraph of {@code graph}, in which are only edges with unknown
	 * weights.
	 * 
	 * @param graph
	 * @return
	 */
	public Graph<Vertex, Edge> getUnweightedGraph(Graph<Vertex, Edge> graph) {
		Predicate<Edge> weightUnknown = new Predicate<Edge>() {

			@Override
			public boolean evaluate(Edge edge) {
				return !edge.surveyed;
			}

		};
		setWeightFilter(new EdgePredicateFilter<Vertex, Edge>(weightUnknown));
		// remove unreachable nodes in this graph
		Graph<Vertex, Edge> unweightedGraph = getWeightFilter()
				.transform(graph);
		return unweightedGraph;
	}

	public DecisionBean getDecisionBean() {
		return db;
	}

	public void setDecisionBean(DecisionBean db) {
		this.db = db;
	}


	/**
	 * Waits for messages from other agents for the given duration. May also
	 * return earlier, if the number of received messages is equal to the number
	 * of team members.
	 * 
	 * @param duration
	 *            The maximum number of steps the agent will wait.
	 * @param messageType
	 *            The
	 */
	protected void waitForInfoMessages(int duration) {
		int waited = 0;
		while ((waited <= duration)
				&& getRegisteredAgents().size() < getWorld().team.size()) {
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				// do nothing
			}
			waited += 10;
		}
	}

	protected void wait(int duration) {
		try {
			Thread.sleep(duration);
		} catch (InterruptedException e) {
			// do nothing
		}
	}
	
	/**
	 * Computes shortest path to the target and returns the first vertex of the path.  
	 * 
	 * @param target
	 * 			target vertex
	 * @param searchMethod
	 * 			defines if path search algorithm should avoid unsafe vertices
	 * @return
	 */
	public String getPathNextVertex(Vertex target) {
		
		if (target == null) {
			System.err.println("getNextVertexName(): Target is null");
			return null;
		}
		
		// in case some agent wants to calculate a path to his current position
		if (target.name.equals(getWorld().getAgentPosition(getWorld().getSelf()).name)) {
			return target.name;
		}
		
		int unweightedDistance = getWorld().getDistance(getWorld().getMyPosition(), target);
		if (unweightedDistance == 1) {
			return target.name;
		}
		
		// saboteur uses always normal path finding
		if (getWorld().getSelf().role.equals(Bot.SABOTEUR)) {
			return getPathNextVertexNormal(target);
		}
		
		// repairer uses always normal path finding
		if (getWorld().getSelf().role.equals(Bot.REPAIRER)) {
			return getPathNextVertexNormal(target);
		}
		
		switch (getPathfinding()) {
			case NORMAL: 
				return getPathNextVertexNormal(target);		
			case SEMISAFE:
				return getPathNextVertexSemiSafe(target);
			case SAFE:
				return getPathNextVertexSafe(target);
			default:
				return null;
		}
	}

	public abstract boolean isTrue();

	protected boolean rechargeNeeded(){
		return true;	
	}

	protected abstract Path getPathfinding();

	protected synchronized HashMap<Bot, Integer> getRegisteredAgents() {
		return registeredAgents;
	}

	/**
	 * Registers an agent, who needs a vertex
	 * 
	 * @param infoMsg
	 */
	protected void registerAgent(String agent, int step) {
		getRegisteredAgents().put(getWorld().getTeam().get(agent), step);
	}

}