package de.tub.mac12.bean.frogs.messages;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac12.util.DistanceMatrix;

public class MatrixContent implements IFact {

  public DistanceMatrix matrix = null;

  public MatrixContent(DistanceMatrix matrix) {
    this.matrix = matrix;
  }

}
