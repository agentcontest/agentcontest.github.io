package de.tub.mac12.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac12.connection.MessageConstants;

public class Bot implements IFact {
	private static final long serialVersionUID = 8077063489884641566L;

	public static final String EXPLORER = "Explorer";

	public static final String SENTINEL = "Sentinel";

	public static final String INSPECTOR = "Inspector";

	public static final String SABOTEUR = "Saboteur";

	public static final String REPAIRER = "Repairer";

	public String name;
	public String team;

	public String agent;

	public String role = null;

	private int rank = 0;

	public int energy;
	public int maxEnergy;
	public int maxEnergyDisabled;
	public int health = 1;
	public int maxHealth;
	public int previousHealth;
	public int strength;
	public int visRange;

	public String position;

	public Zone myZone = null;

	public int lastSeen = -1;

	public String lastAction;
	public boolean lastActionSuccess;
	public Intention intention;
	public boolean inspected = false;

	public boolean disabled = false;

	private int maxAvailableEnergy;

	@Override
	public int hashCode() {
		if (name == null) {
			return 0;
		}
		return name.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || !(obj instanceof Bot)) {
			return false;
		}

		Bot other = (Bot) obj;
		return ((this.name == null) || (other.name == null) || this.name
				.equals(other.name));
	}

	@Override
	public String toString() {
		StringBuffer ret = new StringBuffer("<Bot: ");
		ret.append(name);
		if (this.role != null) {
			ret.append("(").append(role).append(")");
		}
		ret.append(" p:").append(position);
		ret.append(" h:").append(health).append("/").append(maxHealth);
		ret.append(" e:").append(energy).append("/").append(maxEnergy);
		ret.append(">");
		return ret.toString();
	}

	public String getPosition() {
		// TODO Auto-generated method stub
		return position;
	}

	public void setIntention(Intention intention) {
		this.intention = intention;
	}

	public Intention getIntention() {
		// TODO Auto-generated method stub
		if (intention == null) {
			intention = new Intention(MessageConstants.ACTION_SKIP, null);
		}
		return intention;
	}

	public boolean getLastActionSuccess() {
		// TODO Auto-generated method stub
		return lastActionSuccess;
	}

	public String getLastAction() {
		// TODO Auto-generated method stub
		return lastAction;
	}

	/**
	 * Checks if agent is not disabled (health > 0).
	 * 
	 */
	public boolean isAlive() {
		return !disabled;
	}

	/**
	 * Checks if agent has been inspected
	 * 
	 */
	public boolean isInspected() {
		return inspected;
	}

	public void setMaxAvailableEnergy(int maxEnergy) {
		maxAvailableEnergy = maxEnergy;

	}

	public int getMaxAvailableEnergy() {
		return maxAvailableEnergy;
	}

	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}

	public int getRank() {
		return rank;
	}

	public void setRank(int rank) {
		this.rank = rank;
	}

}