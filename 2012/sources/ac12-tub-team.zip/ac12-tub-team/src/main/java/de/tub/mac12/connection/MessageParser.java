package de.tub.mac12.connection;

import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac12.ontology.AuthResponse;
import de.tub.mac12.ontology.Bye;
import de.tub.mac12.ontology.Edge;
import de.tub.mac12.ontology.InspectedEntity;
import de.tub.mac12.ontology.Perception;
import de.tub.mac12.ontology.SimEnd;
import de.tub.mac12.ontology.Vertex;
import de.tub.mac12.ontology.VisibleEntity;
import de.tub.mac12.ontology.World;

public class MessageParser {
  private String username;

  public MessageParser(String username) {
    this.username = username;
  }

  public IFact parse(Document message) {
    Element root = message.getDocumentElement();
//    try {
//		TransformerFactory.newInstance().newTransformer().transform(
//		        new DOMSource(message), new StreamResult(System.out));
//	} catch (TransformerConfigurationException e) {
//		// TODO Auto-generated catch block
//		e.printStackTrace();
//	} catch (TransformerException e) {
//		// TODO Auto-generated catch block
//		e.printStackTrace();
//	} catch (TransformerFactoryConfigurationError e) {
//		// TODO Auto-generated catch block
//		e.printStackTrace();
//	}
    
    String messageType = root.getAttribute("type").trim();

    if (messageType.equalsIgnoreCase(MessageConstants.MESSAGE_ACTION_REQUEST)) {
      return receivePerception(root);
    }
    if (messageType.equalsIgnoreCase(MessageConstants.MESSAGE_SIM_START)) {
      return receiveSimStart(root);
    }
    if (messageType.equalsIgnoreCase(MessageConstants.MESSAGE_SIM_END)) {
      return receiveSimEnd(root);
    }
    if (messageType.equalsIgnoreCase(MessageConstants.MESSAGE_BYE)) {
      return new Bye();
    }
    if (messageType.equalsIgnoreCase(MessageConstants.MESSAGE_AUTH_RESPONSE)) {
      return receiveAuth(root);
    }

    System.out.println(messageType);
    return null;
  }

  private IFact receivePerception(Element root) {
    Perception perception = new Perception(username);
    perception.timestamp = Long.parseLong(root.getAttribute("timestamp"));

    NodeList nodes = root.getElementsByTagName("perception");
    Element childPerception = (Element) nodes.item(0);
    perception.id = childPerception.getAttribute("id");
    perception.deadline = Long.parseLong(childPerception
        .getAttribute("deadline"));

    // step
    nodes = root.getElementsByTagName("simulation");
    childPerception = (Element) nodes.item(0);
    perception.step = Integer.parseInt(childPerception.getAttribute("step")); // current
                                                                              // simulation
                                                                              // step

    // self
    nodes = root.getElementsByTagName("self");
    childPerception = (Element) nodes.item(0);
    perception.energy = Integer
        .parseInt(childPerception.getAttribute("energy"));
    perception.health = Integer
        .parseInt(childPerception.getAttribute("health"));
    perception.lastAction = childPerception.getAttribute("lastAction");
    perception.lastActionSuccess = childPerception.getAttribute(
        "lastActionResult").equals("successful") ? true : false;
    perception.maxEnergy = Integer.parseInt(childPerception
        .getAttribute("maxEnergy"));
    perception.maxEnergyDisabled = Integer.parseInt(childPerception
        .getAttribute("maxEnergyDisabled"));
    perception.maxHealth = Integer.parseInt(childPerception
        .getAttribute("maxHealth"));
    perception.position = childPerception.getAttribute("position");
    perception.strength = Integer.parseInt(childPerception
        .getAttribute("strength"));
    perception.visRange = Integer.parseInt(childPerception
        .getAttribute("visRange"));
    perception.zoneScore = Integer.parseInt(childPerception
        .getAttribute("zoneScore"));

    // team
    nodes = root.getElementsByTagName("team");
    childPerception = (Element) nodes.item(0);
    perception.lastStepScore = Integer.parseInt(childPerception
        .getAttribute("lastStepScore"));
    perception.money = Integer.parseInt(childPerception.getAttribute("money"));
    perception.score = Integer.parseInt(childPerception.getAttribute("score"));
    perception.zonesScore = Integer.parseInt(childPerception
        .getAttribute("zonesScore"));

    // team achievements
    nodes = root.getElementsByTagName("achievement");
    if (nodes.getLength() > 0) {
      perception.achievements = new String[nodes.getLength()];
      for (int i = 0; i < nodes.getLength(); i++) {
        perception.achievements[i] = ((Element) nodes.item(i))
            .getAttribute("name");
      }
    }

    // visibleVertices
    nodes = root.getElementsByTagName("visibleVertex");
    if (nodes.getLength() > 0) {
      perception.visibleVertices = new Vertex[nodes.getLength()];
      for (int i = 0; i < nodes.getLength(); i++) {
        Element item = (Element) nodes.item(i);
        perception.visibleVertices[i] = new Vertex(item.getAttribute("name"),
            1, item.getAttribute("team"), -1);
//TODO        System.out.println("i=" + i + " x="+item.getAttribute("x") + " y=" + item.getAttribute("y"));
        try {
	        perception.visibleVertices[i].x = Integer.parseInt(item.getAttribute("x"));
	        perception.visibleVertices[i].y = Integer.parseInt(item.getAttribute("y"));
//	        System.out.println("Parser: x=" + perception.visibleVertices[i].x + " y=" + perception.visibleVertices[i].y);
        } catch (Exception e) {
        	//Pech
        }
      }
    }

    // visibleEdges
    nodes = root.getElementsByTagName("visibleEdge");
    if (nodes.getLength() > 0) {
      perception.visibleEdges = new Edge[nodes.getLength()];
      for (int i = 0; i < nodes.getLength(); i++) {
        Element item = (Element) nodes.item(i);
        perception.visibleEdges[i] = new Edge(item.getAttribute("node1"), item
            .getAttribute("node2"));
      }
    }

    // visibleEntities
    nodes = root.getElementsByTagName("visibleEntity");
    if (nodes.getLength() > 0) {
      perception.visibleEntities = new VisibleEntity[nodes.getLength()];
      for (int i = 0; i < nodes.getLength(); i++) {
        Element item = (Element) nodes.item(i);
        perception.visibleEntities[i] = new VisibleEntity(item
            .getAttribute("name"), item.getAttribute("node"), item
            .getAttribute("team"), "disabled".equals(item.getAttribute("status")));
      }
    }

    // probedVertices
    nodes = root.getElementsByTagName("probedVertex");
    if (nodes.getLength() > 0) {
      perception.probedVertices = new Vertex[nodes.getLength()];
      for (int i = 0; i < nodes.getLength(); i++) {
        Element item = (Element) nodes.item(i);
        perception.probedVertices[i] = new Vertex(item.getAttribute("name"),
            Integer.parseInt(item.getAttribute("value")), null, -1);
      }
    }

    // surveyedEdges
    nodes = root.getElementsByTagName("surveyedEdge");
    if (nodes.getLength() > 0) {
      perception.surveyedEdges = new Edge[nodes.getLength()];
      for (int i = 0; i < nodes.getLength(); i++) {
        Element item = (Element) nodes.item(i);
        perception.surveyedEdges[i] = new Edge(item.getAttribute("node1"), item
            .getAttribute("node2"), Integer.parseInt(item
            .getAttribute("weight")));
        perception.surveyedEdges[i].surveyed=true;
      }
    }

    // inspectedEntities
    nodes = root.getElementsByTagName("inspectedEntity");
    if (nodes.getLength() > 0) {
      perception.inspectedEntities = new InspectedEntity[nodes.getLength()];
      for (int i = 0; i < nodes.getLength(); i++) {
        Element item = (Element) nodes.item(i);
        InspectedEntity entity = new InspectedEntity();
        entity.name = item.getAttribute("name");
        entity.team = item.getAttribute("team");
        entity.role = item.getAttribute("role");
        entity.vertex = item.getAttribute("node");
        entity.health = Integer.parseInt(item.getAttribute("health"));
        entity.maxHealth = Integer.parseInt(item.getAttribute("maxHealth"));
        entity.strength = Integer.parseInt(item.getAttribute("strength"));
        entity.energy = Integer.parseInt(item.getAttribute("energy"));
        entity.maxEnergy = Integer.parseInt(item.getAttribute("maxEnergy"));
        entity.visRange = Integer.parseInt(item.getAttribute("visRange"));
        perception.inspectedEntities[i] = entity;
        
      }
    }

    return perception;
  }

  private IFact receiveSimStart(Element root) {
    World world = new World(username);

    NodeList childs = root.getElementsByTagName("simulation");
    Element childSimulation = (Element) childs.item(0);

    world.simulationId = childSimulation.getAttribute("id");
    world.steps = Integer.parseInt(childSimulation.getAttribute("steps"));
    world.numEdges = Integer.parseInt(childSimulation.getAttribute("edges"));
    world.numVertices = Integer.parseInt(childSimulation.getAttribute("vertices"));

    world.self.role = childSimulation.getAttribute("role");
    System.out.println("SIM_START" + 
    		" SimulationId=" + world.simulationId +
    		" steps=" + world.steps +
    		" edges=" + world.numEdges +
    		" vertices=" + world.numVertices + 
    		" role=" + world.self.role);
    return world;
  }

  private IFact receiveSimEnd(Element root) {
    SimEnd simEnd = new SimEnd();

    NodeList childs = root.getElementsByTagName("sim-result");
    Element childSimResult = (Element) childs.item(0);

    simEnd.setRanking(childSimResult.getAttribute("ranking"));
    simEnd.setScore(childSimResult.getAttribute("score"));

    return simEnd;
  }

  private IFact receiveAuth(Element root) {
    NodeList nodes = root.getElementsByTagName("authentication");

    String result = ((Element) nodes.item(0)).getAttribute("result");

    if (result.equalsIgnoreCase("ok")) {
      return new AuthResponse(true);
    } else {
      return new AuthResponse(false);
    }
  }

}
