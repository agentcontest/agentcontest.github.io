package de.tub.mac12;

import de.dailab.jiactng.agentcore.SimpleAgentNode;

public class FrogsTeamStarter {
	public static String NODES_SPRINGCONFIGFILE = "classpath:Frogs-Team.xml";

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SimpleAgentNode.main(new String[] {NODES_SPRINGCONFIGFILE});
	}

}
