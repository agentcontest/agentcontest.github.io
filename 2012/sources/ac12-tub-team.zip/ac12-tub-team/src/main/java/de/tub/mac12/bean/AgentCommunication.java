package de.tub.mac12.bean;

import de.dailab.jiactng.agentcore.action.AbstractMethodExposingBean;

public class AgentCommunication extends AbstractMethodExposingBean {

}
