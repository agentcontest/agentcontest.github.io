package de.tub.mac12.bean;

import de.tub.mac12.states.Escape;
import de.tub.mac12.states.Explore;
import de.tub.mac12.states.Group;

public class ExplorerDecisionBean extends DecisionBean {
	
	@Override
	protected void addStatesAndConditions() {
		
		escape = new Escape(getWorld(), this);
		explore = new Explore(getWorld(), this);
		
		// add states
		super.addStatesAndConditions();
		getStatesList().add(disabled);
		getStatesList().add(escape);
		getStatesList().add(group);
		getStatesList().add(explore);
		getStatesList().add(surveyEdges);
		getStatesList().add(createZone);
		
		setStateInstance(explore);
	}

}