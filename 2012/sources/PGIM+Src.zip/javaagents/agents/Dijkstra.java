/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package massim.javaagents.agents;

import java.util.LinkedList;

/**
 *
 * @author hosein
 */
public class Dijkstra {
    
       public  LinkedList<Integer>  path (int s,int t,int[][] matrixgraph)
	{  
	   int vnear=0;
	   int n=matrixgraph.length;
	   int [] touch = new int[n];
	   int [] length1 = new int[n];
	   boolean finished=false; 
	   
	   for (int i = 0; i < n; i++)
	   {                        // For all vertices, initialize v1
          touch [i] = s;                                    // to be the last vertex on the
          length1 [i] =matrixgraph[s][i];                          // current shortest path from
       //   System.out.println (s+","+i+"=="+length1 [i]);
       }        
		 int min;
		 for (int j=1;j<n;j++)
		{                           // Add all n - 1 vertices to Y.
             min = 2000;
             for (int i = 0; i <  n; i++)                    // Check each vertex for
			  {  
                if(i==s)
                   continue;				
                if ( 0 < length1 [i] && length1 [i] < min) 
				{              // having shortest path.
                  min = length1 [i];
                 // System.out.println ("min"+"=="+length1 [i]);
                  vnear = i;
                }
			 }
             if(vnear==t)
              {
			    finished=true;
			    break;	 
			  }
             for (int i = 0; i <  n; i=i+1)
			 {
			    if(i==s)
                   continue;
                 if (length1 [vnear] + matrixgraph[vnear] [i] < length1 [i])
				{
                    length1[i] = length1[vnear] + matrixgraph[vnear][i];
                    touch[i] = vnear;   
                   // For each vertex not in Y,
                    
                }                                         // update its shortest path.
			 }
            length1[vnear] = -1;                                // Add vertex indexed by vnear
        }                                             // to Y.
        LinkedList<Integer> path=new LinkedList<Integer>();
		if(finished)
		{
		 path.add(t);
		 while (touch[t]!=s)
		 {
		    path.addFirst(touch[t]);
		    t = touch[t];
                    //System.out.println(t);
		 }
		}
		return path;
	}
       
       
       
       
       
       
       
     public  int  len (int s,int t,int[][] matrixgraph)
	{  
	   int vnear=0;
	   int n=matrixgraph.length;
	   int [] touch = new int[n];
	   int [] length1 = new int[n];
	   boolean finished=false; 
           int res=0;
	   
	   for (int i = 0; i < n; i++)
	   {                        // For all vertices, initialize v1
          touch [i] = s;                                    // to be the last vertex on the
          length1 [i] =matrixgraph[s][i];                          // current shortest path from
          //System.out.println (s+","+i+"=="+length1 [i]);
       }        
		 int min;
		 for (int j=1;j<n;j++)
		{                           // Add all n - 1 vertices to Y.
             min = 2000;
             for (int i = 0; i <  n; i++)                    // Check each vertex for
			  {  
                if(i==s)
                   continue;				
                if ( 0 < length1 [i] && length1 [i] < min) 
				{              // having shortest path.
                  min = length1 [i];
                  
                  vnear = i;
                }
			 }
//             System.out.println ("min"+"=="+min+"vnear = "+vnear);
             res=min;
             
             if(vnear==t)
              {
			    finished=true;
			    break;	 
			  }
             for (int i = 0; i <  n; i=i+1)
			 {
			    if(i==s)
                   continue;
                 if (length1 [vnear] + matrixgraph[vnear] [i] < length1 [i])
				{
                    length1[i] = length1[vnear] + matrixgraph[vnear][i];
                    
                    touch[i] = vnear;   
                   // For each vertex not in Y,
                    
                }                                         // update its shortest path.
			 }
            length1[vnear] = -1;                                // Add vertex indexed by vnear
        }                                             // to Y.
        LinkedList<Integer> path=new LinkedList<Integer>();
		if(finished)
		{
		 path.add(t);
		 while (touch[t]!=s)
		 {                    
		    path.addFirst(touch[t]);
		    t = touch[t];                    
                  //  System.out.println("t: "+t);
		 }
		}                                
                  //  System.out.println("lenght is :"+res);
		return res;
	}
}