package massim.javaagents.agents;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Vector;

import apltk.interpreter.data.LogicBelief;
import apltk.interpreter.data.LogicGoal;
import apltk.interpreter.data.Message;
import eis.iilang.Action;
import eis.iilang.Percept;
import java.io.FileOutputStream;
import java.io.IOException;
import massim.javaagents.Agent;
import java.io.*;
import java.util.*;

public class InspectorAgent extends Agent {

        private  boolean turn = true;
        private boolean survaied_need=true;
        private boolean enable = true;
        private  LinkedList<String> enable_repairers = new LinkedList<String>();
        private HashMap agent_position = new HashMap<String,String>();
        private HashMap agent_role = new HashMap<String,String>();
        private HashMap enemy_role = new HashMap<String,String>();
        private  LinkedList<Integer> p = new LinkedList<Integer>();
        private boolean gotoMaster = false;
        private boolean gotoZone = false;
        private String master;
        private String mode ="find";
        private String target , targetZone;
        
	public InspectorAgent(String name, String team,String group,String grade) {
		super(name, team,group,grade);	           
	}

	@Override
	public void handlePercept(Percept p) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Action step() {

		handleMessages();
		handlePercepts();
                 if (Agent.start){
                checkLastAction();

		Action act = null;

		// 1. recharging
		act = planRecharge();
		if ( act != null ) {println(this.getName()+" : "+act.toString());return act;}
                
                
                if (enable)
                {
               
                if(survaied_need)
                {
                act = planSurvey();
		if ( act != null) {println(this.getName()+" : "+act.toString());return act;}
                } 
                
                }
                                
                                
                if(gotoMaster)
                {                 
                   act = planGotoMaster(master,target);
                   if ( act != null ) {println(this.getName()+" : "+act.toString());return act;}
                }
                
                
                IfRepairNeed();
                        
		if (enable)
                {
                    
                act =planEscape();
                if ( act != null ) {println(this.getName()+" : "+act.toString());return act;} 
                 
                if(gotoZone)
                {               
                   act = planGotoZone(master,targetZone);
                   if ( act != null ) {println(this.getName()+" : "+act.toString());return act;}
                }
                    		// 2 buying battery
		act = planInspect();
		if ( act != null ) {println(this.getName()+" : "+act.toString());return act;}
                }
             }
                    println(this.getName()+" : Skip");
		return MarsUtil.skipAction();
		
	}
                   
   private void IfRepairNeed()
   {       
            if(!enable)       
            {
                 String pos = getAllBeliefs("position").get(0).getParameters().firstElement();
                 LinkedList<String> repairers = new LinkedList<String>();                 
                 Dijkstra obj = new Dijkstra();
                 int src = new Integer(pos.substring(6));
                 int min = 1000;
                 String closest ="null";
                 for (String ag :Agent.agent_list)
                 {
                     if(agent_role.containsKey(ag))
                     {
                         if(agent_role.get(ag).equals("Repairer") && !repairers.contains(ag))
                         {
                             repairers.add(ag);
                         }
                     }
                 }
                 
                 for(String ag :repairers)
                 {
                     int des = new Integer(agent_position.get(ag).toString());                                       
                         if (src != des) //if source is equal desination dont need to find path
                                    { 
                                        int lenght = obj.len(src, des, matrixgraph);
                                        if (lenght > 900)
                                        {
                                            lenght = obj.len(src, des, linked_nodes);
                                            if (lenght > 900)
                                            {
                                                //no repairer is available
                                            }    
                                            else
                                            {
                                                if(lenght<min)
                                                {
                                                    min = lenght;
                                                    closest = ag;
                                                }
                                            }                                            
                                        }
                                        else
                                        {
                                            if(lenght<min)
                                                {
                                                    min = lenght;
                                                    closest = ag;
                                                }                                        
                                        }                                        
                                    }
                                    else
                                    {
                                        
                                    }
            }
              if(!closest.equals("null"))
                 {
                                    
              LogicBelief b = new LogicBelief("iAmDisabled",pos.substring(6));
              sendMessage(b, closest);
                     
                 }
               
            }            
   }

        
                        
                private Action planSurvey() {

		// get all neighbors
		LinkedList<LogicBelief> visible = getAllBeliefs("visibleEdge");
		LinkedList<LogicBelief> surveyed = getAllBeliefs("surveyedEdge");

		String position = getAllBeliefs("position").get(0).getParameters().firstElement();
		
		int unsurveyedNum = 0;
		int adjacentNum = 0;
		
		for ( LogicBelief v : visible ) 
                {
		
			String vVertex0 = v.getParameters().elementAt(0);
			String vVertex1 = v.getParameters().elementAt(1);
                       


			boolean adjacent = false;
			if ( vVertex0.equals(position) || vVertex1.equals(position) )
				adjacent = true;
			
			if ( adjacent == false) continue;
			adjacentNum ++;
			
			boolean isSurveyed = false;
			for ( LogicBelief s : surveyed )
                        {
                                String sVertex0 = s.getParameters().elementAt(0);
                                String sVertex1 = s.getParameters().elementAt(1);

                                if ( sVertex0.equals(vVertex0) &&  sVertex1.equals(vVertex1) ) 
                                    {
                                        isSurveyed = true;
                                        
                                        break;
                                    }
                                if ( sVertex0.equals(vVertex1) &&  sVertex1.equals(vVertex0) )
                                    {
                                        isSurveyed = true;
                                        
                                        break;
                                    }

                                if(get_surveied_count() >= edgs_num)
                                {
                                    survaied_need = false;
                                }
			}
			if ( isSurveyed == false ) unsurveyedNum ++;
                }
		
		if ( unsurveyedNum > 0 ) {
			return MarsUtil.surveyAction();
		}
		
		return null;
		
	}
                
                
                     

	private void handleMessages() {
		
		// handle messages... believe everything the others say
		Collection<Message> messages = getMessages();
		for ( Message msg : messages ) { 
			String predicate = ((LogicBelief)msg.value).getPredicate();  
                        if( predicate.equals("position"))
                                 {
                                     agent_position.remove(msg.sender.toString());
                                            int pos;                                     
                                            pos= vertex_num(((LogicBelief)msg.value).getParameters().get(0).toString());
                                            agent_position.put(msg.sender.toString(), pos);
                                  }                
                       
                      else if (predicate.equals("role"))
                               {
                                  String role = ((LogicBelief)msg.value).getParameters().get(0).toString(); 
                                  agent_role.put(msg.sender, role);
                               }
                       else if (predicate.equals("joinMe"))
                            {
                                target = ((LogicBelief)msg.value).getParameters().get(0).toString();
                                gotoMaster = true;
                                master = msg.sender.toString();
                            }
                       else if (predicate.equals("goto"))
                            {
                                targetZone = ((LogicBelief)msg.value).getParameters().get(0).toString();
                                gotoZone = true;
                                master = msg.sender.toString();
                            }
                       
                      else if (predicate.equals("inspectedEntity"))
                               {
                                  String e_name = ((LogicBelief)msg.value).getParameters().get(0).toString(); 
                                  String e_role = ((LogicBelief)msg.value).getParameters().get(2).toString(); 
                                  enemy_role.put(e_name, e_role);
                               }                                                                                             
                       else
                       {
                           
                       }
			}
		}
		
	

	
        
        
        
        	private void handlePercepts() {
             
		String position = null;
		Vector<String> neighbors = new Vector<String>();
		
		// check percepts
		Collection<Percept> percepts = getAllPercepts();
		removeBeliefs("visibleEntity");
		removeBeliefs("visibleEdge");
                removeBeliefs("visibleVertex");
                removeBeliefs("position");
                
		for ( Percept p : percepts ) {		

                    
			if ( p.getName().equals("edges") ) {
				 edgs_num = Integer.parseInt(p.getParameters().get(0).toString());
			}
                        if ( p.getName().equals("step") ) {
                              step_num = p.getParameters().get(0).toString();
                        }
                        
			else if ( p.getName().equals("visibleEntity") ) {
				LogicBelief b = MarsUtil.perceptToBelief(p);
				if ( containsBelief(b) == false ) {
					addBelief(b);
				}
				else {
				}
			}
                       else if ( p.getName().equals("visibleVertex") ) {

       				LogicBelief b = MarsUtil.perceptToBelief(p);
				if ( containsBelief(b) == false ) {
					addBelief(b);
                                }
				else {
				}
                            
			}
                        
			else if ( p.getName().equals("visibleEdge") ) {
				LogicBelief b = MarsUtil.perceptToBelief(p);
				if ( containsBelief(b) == false ) 
                                {                                                                        
                                    addBelief(b);      
                                    int node1 =new Integer(b.getParameters().get(0).toString().substring(6));
                                    int node2 =new Integer(b.getParameters().get(1).toString().substring(6));
                                    if (Agent.linked_nodes[node1][node2]==999)
                                    {
                                        fillLinked(node1, node2);
                                    }                                 
				}
				else 
                                {
				}
			}
			else if ( p.getName().equals("probedVertex") ) {
				LogicBelief b = MarsUtil.perceptToBelief(p);;
				if ( containsBelief(b) == false ) {					
					addBelief(b);
					broadcastBelief(b);
				}
				else {
				}
			}
                        
                        
                        else if ( p.getName().equals("role") ) {
				LogicBelief b = MarsUtil.perceptToBelief(p);;
				if ( containsBelief(b) == false ) {					
					addBelief(b);
                                         agent_role.put(this.getName(), b.getParameters().get(0));
					broadcastBelief(b);
				}
				else {
				}
			}
                        
                        
                        
                              else if ( p.getName().equals("inspectedEntity") ) {
				LogicBelief b = MarsUtil.perceptToBelief(p);;
				if ( containsBelief(b) == false ) {					
					addBelief(b);
					broadcastBelief(b);
				}
				else {					
				}
			}
                        
                        
                        
			else if ( p.getName().equals("surveyedEdge") ) {
				LogicBelief b = MarsUtil.perceptToBelief(p);
                                if ( containsBelief(b) == false ) {				
					addBelief(b);
                                        int node1 = new Integer(b.getParameters().get(0).toString().substring(6));
                                        int node2 = new Integer(b.getParameters().get(1).toString().substring(6));
                                        int weight = new Integer(b.getParameters().get(2).toString());
                                         if(matrixgraph[node1][node2]==999)
                                              {
                                             fillMatrix(node1, node2, weight);
                                              }
				}
				else {
				}

			}
			else if ( p.getName().equals("health")) {
				Integer health = new Integer(p.getParameters().get(0).toString());
				if ( health.intValue() == 0 ) {
                                     enable = false;                                                                          
                                 }
                                else
                                {
                                    enable = true;
                                }                                
			}
			else if ( p.getName().equals("position") ) {
                          

				position = p.getParameters().get(0).toString();
                                if (agent_position.containsKey(this.getName()))
                                   { agent_position.remove(this.getName());}
                                agent_position.put(this.getName(),position.substring(6));
				removeBeliefs("position");
                                LogicBelief b = new LogicBelief("position",position);
				addBelief(b);
                                broadcastBelief(b);
                                        
			}
			else if ( p.getName().equals("energy") ) {
				Integer energy = new Integer(p.getParameters().get(0).toString());
				removeBeliefs("energy");
				addBelief(new LogicBelief("energy",energy.toString()));
			}
			else if ( p.getName().equals("maxEnergy") ) {
				Integer maxEnergy = new Integer(p.getParameters().get(0).toString());
				removeBeliefs("maxEnergy");
				addBelief(new LogicBelief("maxEnergy",maxEnergy.toString()));
			}
			else if ( p.getName().equals("money") ) {
				Integer money = new Integer(p.getParameters().get(0).toString());
				removeBeliefs("money");
				addBelief(new LogicBelief("money",money.toString()));
			}
                        else if (p.getName().equals("lastAction"))
                        { 
                            removeBeliefs("lastAction");
                            LogicBelief b= new LogicBelief("lastAction",p.getParameters().getFirst().toString());
                            addBelief(b);                                                       
                        }
                       else if (p.getName().equals("lastActionResult"))
                            {                               
                            removeBeliefs("lastActionResult");
                            LogicBelief b= new LogicBelief("lastActionResult",p.getParameters().getFirst().toString());
                            addBelief(b);
                            }
                      else if (p.getName().equals("lastActionParam"))
                            {                               
                            removeBeliefs("lastActionParam");
                            LogicBelief b= new LogicBelief("lastActionParam",p.getParameters().getFirst().toString());
                            addBelief(b);
                            }
			else if ( p.getName().equals("achievement") ) {
			}
		}
		               
		// again for checking neighbors
		this.removeBeliefs("neighbor");
		for ( Percept p : percepts ) {
			if ( p.getName().equals("visibleEdge") ) {
				String vertex1 = p.getParameters().get(0).toString();
				String vertex2 = p.getParameters().get(1).toString();
				if ( vertex1.equals(position) ) 
					addBelief(new LogicBelief("neighbor",vertex2));
				if ( vertex2.equals(position) ) 
					addBelief(new LogicBelief("neighbor",vertex1));
                                
                                
			}
		}
	}
        

        

	private Action planRecharge() {
            
		LinkedList<LogicBelief> beliefs = null;
                LinkedList<LogicBelief> vis_ent = getAllBeliefs("visibleEntity");
                String position = getAllBeliefs("position").get(0).getParameters().firstElement();
                boolean danger_zone = false;
                
                for ( LogicBelief b : vis_ent ) {
			String name = b.getParameters().get(0);
			String pos = b.getParameters().get(1);
			String team = b.getParameters().get(2);
                        String status = b.getParameters().get(3);                         
			if ( team.equals(getTeam())) continue;
			if ( !pos.equals(position)) continue;
                        if (enemy_role.containsKey(name))
                        {
                            if(enemy_role.get(name).equals("Saboteur") && status.equals("normal"))
                       		danger_zone = true;
                        }
                        else
                        {
                            double r = Math.random();
                            if ( r > 0.4 ) {
                            danger_zone = true;
                            }
                        }
                }
                
                
                    beliefs =  getAllBeliefs("energy");
                    if ( beliefs.size() == 0 ) {
                                    return MarsUtil.skipAction();
                    }		
                    int energy = new Integer(beliefs.getFirst().getParameters().firstElement()).intValue();

                    beliefs =  getAllBeliefs("maxEnergy");
                    if ( beliefs.size() == 0 ) {
                                    return MarsUtil.skipAction();
                    }		
                    int maxEnergy = new Integer(beliefs.getFirst().getParameters().firstElement()).intValue();

                    if(energy < 8)
                    {
                         return MarsUtil.rechargeAction();
                    }
                    if(!danger_zone)		
                    {


                            if ( energy < 10) {
                                    goals.add(new LogicGoal("beAtFullCharge"));
                                    return MarsUtil.rechargeAction();
                            }
                    }	
                
                    return null;                		
	}

        
                
                
	/**
	 * Buy a battery with a given probability
	 * @return
	 */
	private Action planBuyBattery() {
		
		LinkedList<LogicBelief> beliefs = this.getAllBeliefs("money");
                LinkedList<LogicBelief> vis_ent = getAllBeliefs("visibleEntity");
                String position = getAllBeliefs("position").get(0).getParameters().firstElement();
                boolean danger_zone = false;
                
                for ( LogicBelief b : vis_ent ) {
			String name = b.getParameters().get(0);
			String pos = b.getParameters().get(1);
			String team = b.getParameters().get(2);
                        String status = b.getParameters().get(3);                         
			if ( team.equals(getTeam())) continue;
			if ( !pos.equals(position)) continue;
                        if (enemy_role.containsKey(name))
                        {
                            if(enemy_role.get(name).equals("Saboteur") && status.equals("normal"))
                       		danger_zone = true;
                        }
                        else
                        {
                            double r = Math.random();
                            if ( r > 0.4 ) {
                            danger_zone = true;
                            }
                        }
                }
                
                if(!danger_zone)
                 {
                     if ( beliefs.size() == 0 ) {
                            return null;
                    }

                    LogicBelief moneyBelief = beliefs.get(0);
                    int money = new Integer(moneyBelief.getParameters().get(0)).intValue();

                    if ( money < 10 ) {
                            return null;
                    }
                    return MarsUtil.buyAction("battery");
                }
                else
                {
                    return null;
                }
		
	}
	
	private Action planInspect() {

		LinkedList<LogicBelief> beliefs = null;

		// determine adjacent vertices including the current position
		Vector<String> vertices = new Vector<String>();
		beliefs =  getAllBeliefs("position");
		String position = beliefs.getFirst().getParameters().firstElement();
		vertices.add(position);
		beliefs = getAllBeliefs("neighbor");
		for ( LogicBelief b : beliefs ) {
			vertices.add(b.getParameters().firstElement());
		}
		
		int adjacentNum = 0;
		
		String myTeam = getTeam();
		
		LinkedList<LogicBelief> visible = getAllBeliefs("visibleEntity");
		for ( LogicBelief v : visible ) {
		
                        String name = v.getParameters().get(0);
			String pos = v.getParameters().get(1);
			String team = v.getParameters().get(2);
			
			// ignore same team
			if ( myTeam.equals(team) ) continue;
			
			// not adjacent
			if ( !vertices.contains(pos)) continue;
                        if(enemy_role.containsKey(name)) continue;
			adjacentNum ++;
						
		}

		if ( adjacentNum == 0 ) {
			return null;
		}
			return MarsUtil.inspectAction();
	}

	
        
        
        private Action planRandomWalk() {

            LinkedList<LogicBelief> nei = getAllBeliefs("neighbor");
                LinkedList<LogicBelief> vis_ent = getAllBeliefs("visibleEntity");
                
                LinkedList<String> enemy = new LinkedList<String>();
                LinkedList<String> safe = new LinkedList<String>();                                
                 for ( LogicBelief n : nei )
                     {
                       String node = n.getParameters().get(0).toString();
                       for ( LogicBelief e : vis_ent ) {
                    	String name = e.getParameters().get(0);
			String pos = e.getParameters().get(1);
			String team = e.getParameters().get(2);
                        String status = e.getParameters().get(3); 
                        
                              if(!team.equals(this.getTeam()) && status.equals("normal") && pos.equals(node))
                                {
                                    if(enemy_role.containsKey(name))
                                    { 
                                        if(enemy_role.get(name).equals("Saboteur"))
                                        {
                                            enemy.add(pos);
                                        }
                                    }
                                }                          
                        }
                     }
                        
               for ( LogicBelief n : nei )
                     {
                       String node = n.getParameters().get(0).toString();
                    if(!enemy.contains(node))
                     {
                        safe.add(n.getParameters().get(0).toString());
                    }
		}
                if(!safe.isEmpty())
                {
                Collections.shuffle(safe);
                String safe_pos = safe.getFirst();
		return MarsUtil.gotoAction(safe_pos);
                }
                return null;
		
	}
        
        
        
       public int vertex_num(String msg)
       {
         int pos =new Integer ( msg.substring(6));
         return pos;
         
       }


       
	
       
    private Action planGotoMaster(String master,String target)
        {
                     
                               Dijkstra obj = new Dijkstra();
                                    int src = new Integer(agent_position.get(this.getName()).toString());
                                    int des = new Integer(target); 
                      if (mode.equals("find"))
                           {
                                    if (src != des) //if source is equal desination dont need to find path
                                    { 
                                        int lenght = obj.len(src, des, matrixgraph);
                                        if (lenght > 900)
                                        {
                                            lenght = obj.len(src, des, linked_nodes);
                                            if (lenght > 900)
                                            {
                                                Action act;
                                                act = planRandomWalk();
                                                return act;
                                            }    
                                            else
                                            {
                                                 p = obj.path(src,des, linked_nodes);
                                            }                                            
                                        }
                                        else
                                        {
                                           p = obj.path(src,des, matrixgraph);
                                        }
                                        
                                    }
                                    else
                                    {
                                        gotoMaster =false;
                                        return null;
                                    }
                                    if(p.isEmpty())
                                    {
                                        Action act;
                                        act = planRandomWalk();
                                        return act; 
                                    }
                                    mode="track";
                           }
                        
            
            String position = getAllBeliefs("position").get(0).getParameters().firstElement();
            if(mode.equals("track"))
            {          
                if(obj.len(src, des, linked_nodes)<=3)
                {
                    p.clear();
                    gotoMaster = false;
                    mode = "find";
                    return null;
                }
              while(!p.isEmpty())
              {
                  //String node = "vertex"+p.pop();
                  String node = "vertex"+p.getFirst();
                    return MarsUtil.gotoAction(node);
              }
              gotoMaster =false;
              mode="find";
               return null;
              
            }                 
               return null;  
        }
    

private void checkLastAction()
 {
    LinkedList<LogicBelief> lastAction = getAllBeliefs("lastAction");
    LinkedList<LogicBelief> lastActionResult = getAllBeliefs("lastActionResult");
    LinkedList<LogicBelief> lastActionParam = getAllBeliefs("lastActionParam");
    String last_action="";
    String last_action_result="";
    String last_action_param="";
    if(!lastAction.isEmpty())
     last_action = lastAction.getFirst().getParameters().get(0).toString();
    if(!lastActionResult.isEmpty())
     last_action_result = lastActionResult.getFirst().getParameters().get(0).toString();
    if(!lastActionParam.isEmpty())
     last_action_param = lastActionParam.getFirst().getParameters().get(0).toString();

    if ( last_action.equals("goto") && last_action_result.equals("successful") && mode.equals("track"))
    {
        if(!p.isEmpty())
        {
        p.removeFirst();
        }
    } 
        if ( last_action.equals("goto") && last_action_result.equals("failed_wrong_param"))
    {
            p.clear();                
        mode = "find";
    } 
 }
        
       
       private Action planEscape()
        {
                LinkedList<LogicBelief> vis_ent = getAllBeliefs("visibleEntity");
                String position = getAllBeliefs("position").get(0).getParameters().firstElement();
                LinkedList<String> enemies = new LinkedList<String>(); 
                enemies.clear();
                for ( LogicBelief b : vis_ent ) {
                        String name = b.getParameters().get(0);
			String pos = b.getParameters().get(1);
			String team = b.getParameters().get(2);
                        String status = b.getParameters().get(3);                                          
			if ( team.equals(getTeam()) ) continue;
			if (!pos.equals(position)) continue;
                        if (enemy_role.containsKey(name))
                        {
                            if(enemy_role.get(name).equals("Saboteur") && status.equals("normal"))
                                enemies.add(name);
                        }
        }
            if(!enemies.isEmpty()) 
            {
                p.clear();
                mode ="find";
                gotoZone = false;
                gotoMaster =false;
                return planRandomWalk();
            }
                    return null;
        }
       
           private Action planGotoZone(String master,String target)
        {
                    if (mode.equals("find"))
                           { 
                               Dijkstra obj = new Dijkstra();
                                    int src = new Integer(agent_position.get(this.getName()).toString());
                                    int des = new Integer(target);                       
                                    if (src != des) //if source is equal desination dont need to find path
                                    { 
                                        int lenght = obj.len(src, des, matrixgraph);
                                        if (lenght > 900)
                                        {
                                            lenght = obj.len(src, des, linked_nodes);
                                            if (lenght > 900)
                                            {
                                                Action act;
                                                act = planRandomWalk();
                                                return act;
                                            }    
                                            else
                                            {
                                                 p = obj.path(src,des, linked_nodes);
                                            }                                            
                                        }
                                        else
                                        {
                                           p = obj.path(src,des, matrixgraph);
                                        }
                                        
                                    }
                                    else
                                    {
                                        gotoZone =false;
                                        return null;
                                    }
                                    if(p.isEmpty())
                                    {
                                        Action act;
                                        act = planRandomWalk();
                                        return act; 
                                    }
                                    mode="track";
                           }
                        
            
                        String position = getAllBeliefs("position").get(0).getParameters().firstElement();
            if(mode.equals("track"))
            {                   
              while(!p.isEmpty())
              {
                  //String node = "vertex"+p.pop();
                  String node = "vertex"+p.getFirst();
                    return MarsUtil.gotoAction(node);
              }
              gotoZone =false;
              mode="find";
               return null;
              
            }                 
               return null;  
        }
        
    
                       
}