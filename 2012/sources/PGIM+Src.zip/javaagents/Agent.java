package massim.javaagents;

import java.lang.reflect.Constructor;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;

import apltk.interpreter.data.Belief;
import apltk.interpreter.data.Goal;
import apltk.interpreter.data.LogicBelief;
import apltk.interpreter.data.LogicGoal;
import apltk.interpreter.data.Message;

import eis.EnvironmentInterfaceStandard;
import eis.exceptions.ActException;
import eis.exceptions.NoEnvironmentException;
import eis.exceptions.PerceiveException;
import eis.iilang.Action;
import eis.iilang.Numeral;
import eis.iilang.Percept;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.*;

/**
 * This class represents a simple agent. Note that is is an abstract class, that is
 * that you are supposed to inherit from this class in order to implement
 * specialized agents.</p>
 * 
 * An abstract agent consists of beliefs and goals and has access to a simple 
 * system for communicating with others.</p>
 * 
 * Note that specialized agents can and will be instantiated by the interpreter
 * using Java-reflection.
 * 
 * @author tristanbehrens
 *
 */
public abstract class Agent {

	// the name of the agent. supposed to be unique (ensured by the constructor).
    
    
    public static int min_enemy = 10;
    public static String master_sen=" ";
    public static boolean start ;
    
    
      public static LinkedList<String> agent_list;
      public static LinkedList<String> current_enemies;
      public static LinkedList<String> current_disabled;
      public static LinkedList<String> current_enemy_repairer;
      public static int linked_nodes[][];
      public static int matrixgraph[][];
      public static int con_linked_nodes;
      public static  int counter;
      public static FileOutputStream output;
        public static int edgs_num;
        public  static String step_num;
	private String name;
	
	// the team of the agent. this is required for comminication.
	private String team;
        // the group of the agent. this is required for cordination.
        private String group;
        private String grade;
	
	private boolean printMind = false;
	
	// agent specific stuff
	private Set<LogicBelief> beliefs; // what the agent knows about the world
	protected Set<LogicGoal> goals; // what the agent wants to achieve in the world

	// static stuff, shared by all agents
	private static EnvironmentInterfaceStandard ei; // access to the environment
	private static Collection<String> agents; // all agents in the agent system
	private static Collection<Message> messages; // messages
	public static Map<String,String> agentsTeams; 
        public static Map<String,String> agentsGroups;
          public static Map<String,String> agentsGrades;
	static {
    	agents = new LinkedList<String>();
    	messages = new LinkedList<Message>();
        agent_list = new LinkedList<String>();
        current_disabled = new LinkedList<String>();
        current_enemy_repairer = new LinkedList<String>();
        current_enemies = new LinkedList<String>();
    	agentsTeams = new HashMap<String,String>();
        agentsGroups = new HashMap<String,String>();
        agentsGrades = new HashMap<String,String>();
        matrixgraph = new int[300][300];
        linked_nodes = new int[300][300];
        con_linked_nodes = 0;
        counter = 0;
        start = false;
        }
        
        
	/**
	 * Initializes an agent with a given name. Ensures that the name is unique.
	 * @param name is the name of the agent
	 * @param team is the team of the agent
	 */
	public Agent(String name, String team ,String group,String grade) {
		
		this.name = name;
		this.team = team;
                this.group = group;
                this.grade = grade;
		
		if ( agents.contains(name) ) 
		throw new AssertionError("duplicate agent name \"" + name);
		agents.add(name);
                agent_list.add(name);
		
		beliefs = new HashSet<LogicBelief>();
		goals = new HashSet<LogicGoal>();
		
		agentsTeams.put(name, team);
                agentsGroups.put(name, group);
                agentsGrades.put(name, grade);

                
                for (int i = 0 ; i < 300 ; i++)
                    for (int j = 0 ; j < 300 ; j++)                        
                        if(i==j)
                        { matrixgraph[i][j] = 0;
                        linked_nodes[i][j] = 0;
                        }
                        else
                        {matrixgraph[i][j] = 999;
                        linked_nodes[i][j] = 999;
                        }
                
           try
		{                    
                    output = new FileOutputStream("out_put.txt");                                
                    //dij = new FileOutputStream ("dijkstra.txt");                
		}
		// Catches any error conditions
            catch (IOException e)
		{
			System.err.println ("Unable to write to  file");
			System.exit(-1);
		}                                 
		
	}
        
     public void reset()
        {
              for (int i = 0 ; i < 300 ; i++)
                    for (int j = 0 ; j < 300 ; j++)                        
                        if(i==j)
                        { matrixgraph[i][j] = 0;
                        linked_nodes[i][j] = 0;
                        }
                        else
                        {matrixgraph[i][j] = 999;
                        linked_nodes[i][j] = 999;
                        }
              counter=0;
              con_linked_nodes =0;
              current_enemies.clear();
              current_disabled.clear();
              current_enemy_repairer.clear();
              start = false;
             
        }
        
        public void fillMatrix(int node1 , int node2 , int weight)
        {
            matrixgraph[node1][node2] = weight;
            matrixgraph[node2][node1] = weight;
            counter ++;
        }
        public void fillLinked(int node1 , int node2)
        {
            linked_nodes[node1][node2] = 1;
            linked_nodes[node2][node1] = 1;
            con_linked_nodes ++;
        }
        public int get_surveied_count ()
        {
            return counter;
        }
                
        public int get_linked_count ()
        {
            return con_linked_nodes;
        }
        
        public LinkedList<String> getAgents()
        {
            return agent_list;
        }

	/**
	 * Yields the name of the agent.
	 * @return the name of the agent
	 */
	public String getName() {
		return name;
	}

	/**
	 * Yields the team of the agent.
	 * @return the team of the agent
	 */
	public String getTeam() {
		return team;
	}
        /**
	 * Yields the group of the agent.
	 * @return the group of the agent
	 */
        public String getGroup() {
		return group;
	}        /**
	 * Yields the grade of the agent.
	 * @return the grade of the agent
	 */
        public String getGrade() {
		return grade;
	}
        
	/**
	 * Yields an instance of a specified agent-class with a given name. This uses Java-reflection and assumes
	 * that the class is already in the classpath.
	 * 
	 * @param agentName is the name of the agent
	 * @param team is the team of the agent
         * @param grade is the grade of the agent
         * @param group is the group of the agent
	 * @param agentClass is the fully-qualified name of the agent-class to-be-loaded
	 * @return an agent-instance 
	 */
	static public Agent createAgentFromClass(String agentName, String team,String group,String grade, String agentClass) {
	
		// 1. retrieve a class loader
		ClassLoader classLoader = Agent.class.getClassLoader();

		// 2. load the class
		Class<?> aClass = null;
	    try {
	        aClass = classLoader.loadClass(agentClass);
	        System.out.println("instance of \"" + aClass.getName() + "\" created");
	    } catch (ClassNotFoundException e) {
	        e.printStackTrace();
	    }

		// 3.  get an instance of the class
		Constructor<?> c = null;
		Agent ret = null;
		try {                   
			c = aClass.getConstructor(new Class[]{String.class,String.class,String.class,String.class});                       
			ret = (Agent)(c.newInstance(agentName,team,group,grade));
		} catch (Exception e) {
			System.out.println(e);
			//throw new IOException("Class \"" + mainClass + "\" could not be loaded from \"" + file + "\"", e);
			assert false:e;
			return null;
		} 

		//ret.name = agentName;
		return ret;
		
	}

	/**
	 * Sets the environment-interface for all agents in this process.
	 * 
	 * @param theEI is the environment-interface
	 */
	public static void setEnvironmentInterface(EnvironmentInterfaceStandard theEI) {
		ei = theEI;
	}
	
	/**
	 * Yields the environment-interface that all agents access.
	 * @return
	 */
	public static EnvironmentInterfaceStandard getEnvironmentInterface() {
		return ei;
	}
	
	/**
	 * Executes one step of the agent. This method is assumed to terminate in appropriate time.
	 */
	public abstract Action step();
	
	/**
	 * Prints an arbitrary object, e.g. a String, to the standard-out. 
	 * Should be used for debugging purposes only.
	 * @param obj
	 */
	protected final void println(Object obj) {
		
		System.out.println("Agent " + name + ": " + obj);
		
	}

	/**
	 * Yields the belief-base of the agent.
	 * 
	 * @return the belief-base
	 */
	public final Collection<LogicBelief> getBeliefBase() {
		
		Collection<LogicBelief> ret = new LinkedList<LogicBelief>();
		ret.addAll(beliefs);
		return ret;

	}	
	
	/**
	 * Yields the goal-base of the agent.
	 * 
	 * @return the goal-base
	 */
	public final Collection<LogicGoal> getGoalBase() {

		Collection<LogicGoal> ret = new LinkedList<LogicGoal>();
		ret.addAll(goals);
		return ret;

	}
	
	int oldStep = 100000;
	
	/**
	 * Yields all percepts that are currently available.
	 * 
	 * @return a list of percepts or an empty-list if perceiving failed
	 */
	protected Collection<Percept> getAllPercepts() {
		
		try {
			Map<String, Collection<Percept>> percepts = ei.getAllPercepts(getName());
			Collection<Percept> ret = new LinkedList<Percept>();
			for ( Collection<Percept> ps : percepts.values() ) {
				ret.addAll(ps);
			}
			
			// sweep mental attitudes if there has been a restart 
			// TODO maybe use simulation-id
			int step = -1;
			for ( Percept p : ret ) {
				if ( p.getName().equals("step")) {
					step = new Integer(p.getParameters().get(0).toProlog()).intValue();
					break;
				}
			}
			if ( step != -1 && step < oldStep) {
				println("sweeping mental attitudes");
				beliefs.clear();
				goals.clear();
			}
			if ( step != -1 )
				oldStep = step;
			
			return ret;
		} catch (PerceiveException e) {
			//e.printStackTrace();
			println("error perceiving \"" + e.getMessage() + "\"");	
			return new LinkedList<Percept>();
		} catch (NoEnvironmentException e) {
			//e.printStackTrace();
			println("error perceiving \"" + e.getMessage() + "\"");	
			return new LinkedList<Percept>();
		}
		
	}
	
	/**
	 * Gets all messages that were sent to the agent. After calling this method
	 * the messages will be removed from the message-box.
	 * 
	 * @return all messages
	 */
	  protected final Collection<Message> getMessages() {
	
		Collection<Message> ret = new LinkedList<Message>();
		
		for ( Message m : messages ) {
			if ( m.receiver.equals(getName()) ) {
				ret.add(m);
			}
		}

		messages.removeAll(ret);
		
		return ret;
		
	}
	
	/**
	 * Sends a message to a specific agent in the team.
	 * 
	 * @param msg the message to be sent
	 * @param receiver the recipient of the message
	 */
	public final void sendMessage(Belief belief, String receiver) {
		
		Message msg = new Message();
		
		msg.value = belief;
		msg.sender = getName();
		msg.receiver = receiver;
		
		if ( agentsTeams.get(receiver).equals(team) == false ) {
			System.out.println("cannot send a message to an agent from another team");
		}
		messages.add(msg);
		
	}

	/**
	 * Sends a message to all agents of the team.
	 * 
	 * @param msg the message to be broadcasted
	 */
	public final void broadcastBelief(LogicBelief belief) {
	
		for ( String ag : agents ) {
			if ( ag.equals(getName())) continue;
			if ( agentsTeams.get(ag).equals(team) == false ) continue;
			sendMessage(belief,ag);
		}
		
	}
	
	/**
	 * This method is called if the environment-interface sends a
	 * percept as a notification. Note, that sending percepts-via-notifications
	 * must be explicitely activated for the environment-interface.
	 * An alternative is to use the <code>getAllPercepts</code> method which
	 * yields all percepts.
	 * @param p the percept to be handled
	 */
	public abstract void handlePercept(Percept p);
	
	@Override
	public boolean equals(Object obj) {
		
		if ( obj == null )
			return false;
		
		if ( obj == this )
			return true;
		
		if ( obj.getClass().equals(this.getClass()) == false )
			return false;
		
		if ( ((Agent)obj).getName().equals(getName()) )
				return true;
		
		return false;
		
	}
	
	@Override
	public int hashCode() {
		
		return name.hashCode();
		
	}

	/**
	 * Yields all beliefs from the belief base that have a specific
	 * predicate.
	 * 
	 * @param predicate the given predicate
	 * @return a list of beliefs that have the given predicate
	 */
	public LinkedList<LogicBelief> getAllBeliefs(String predicate) {
		
		LinkedList<LogicBelief> ret = new LinkedList<LogicBelief>();
		
		for ( LogicBelief b : beliefs ) {
			if ( b.getPredicate().equals(predicate) )
				ret.add(b);
		}
		
		return ret;
		
	}
	
	/**
	 * Removes all beliefs from the belief-base that have a given predicate.
	 * @param predicate the given predicate
	 */
	public void removeBeliefs(String predicate) {
		
		LinkedList<LogicBelief> remove = new LinkedList<LogicBelief>();
		
		for ( LogicBelief b : beliefs ) {
			if ( b.getPredicate().equals(predicate) )
				remove.add(b);
		}
	
		beliefs.removeAll(remove);
		
	}
	
	/**
	 * Removes all goals that have a given predicate.
	 * @param predicate the given predicate
	 */
	protected void removeGoals(String predicate) {
		
		LinkedList<LogicGoal> remove = new LinkedList<LogicGoal>();
		
		for ( LogicGoal g : goals ) {
			if ( g.getPredicate().equals(predicate) )
				remove.add(g);
		}
	
		goals.removeAll(remove);
		
	}

	public void addBelief(LogicBelief belief) {
		beliefs.add(belief);
	}
	
	public void addGoal(LogicGoal goal) {
		goals.add(goal);
	}
	
	public boolean containsBelief(LogicBelief belief) {
		return beliefs.contains(belief);
	}

	protected boolean containsGoal(LogicGoal goal) {
		return goals.contains(goals);
	}
	
	protected void clearBeliefs() {
		beliefs.clear();
	}
	
	public void clearGoals() {
		goals.clear();
	}

}