﻿Multi-Agent Programming Contest 2012 - Python-DTU

Participants from DTU Informatics:

- Jørgen Villadsen - Supervisor - Associate professor

- Andreas Schmidt Jensen

- Mikko Berggren Ettienne

- Steen Vester
 
- Kenneth Balsiger Andersen

- Andreas Frøsig

Department of Informatics and Mathematical Modelling
Technical University of Denmark (DTU)

http://www.imm.dtu.dk/~jv/MAS

----------

REQUIREMENTS: Python 3.0+

RUNNING: python bagent.py -h
