% some variables so that they can be updated later
lastPos(unknown).
oldZone(unknown).
step(unknown).

% predicate that will contain info about the optimum zone, updated each round in common percepts
optimumInfo([], [], []).

% makes sure agents wait for mails from other agents in first round.
doneAction.
donePercepts.
doneMailing.
