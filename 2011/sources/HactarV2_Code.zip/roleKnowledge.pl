%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%                             Explorer specific knowledge                         %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
needProbe(Vertex) :- vertex(Vertex,unknown,_).
needProbe(Vertex) :- not(vertex(Vertex,_,_)).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%                             Saboteur specific knowledge                         %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Because a target cannor be permanently disabled your never done hunting it.
hunt(ID) :- !, fail.

% To determine which enemies are on the current position
enemyHere(ID) :- currentPos(Vertex),!, visibleEntity(ID,Vertex,Team,_), enemyTeam(Team).

% To deterine which enemies are close to the current position
enemyNear(ID,Vertex) :- enemyHere(ID).
enemyNear(Id,Pos) :- neighbour(Pos), visibleEntity(Id,Pos,Team,_), enemyTeam(Team).

% To determine when a non-disabled enemy is at your position
enabledEnemyHere(Id) :- currentPos(Vertex),!, visibleEntity(Id,Vertex,Team,normal), enemyTeam(Team).

% when an non-disabled enemy is at or next to your position
enabledEnemyNear(ID,Vertex) :- enabledEnemyHere(ID).
enabledEnemyNear(Id,Pos) :- neighbour(Pos), visibleEntity(Id,Pos,Team,normal), enemyTeam(Team).

% A list of all locations near where there are enemies
enabledEnemiesNear(List) :- setof(Vertex,enabledEnemyNear(ID,Vertex),List).

% Predicate to find all enemy repairers
enemyRepairerList(List) :- setof(ID,(inspectedEnemy(ID,'Repairer')),List).

% Short predicate for finding enemies worth attacking
enabledEnemy(ID,Vertex) :- enemyStatus(ID,Vertex,normal).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%                             Repairer specific knowledge                         %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Predicate that returns disabled allies near or on the current position
disabledAllyNear(ID,Here) :- currentPos(Here), team(Team), me(Me), visibleEntity(ID,Here,Team,disabled), ID \= Me, !.
disabledAllyNear(ID,Vertex) :- team(Team), neighbour(Vertex), visibleEntity(ID,Vertex,Team,disabled), !.
disabledAllyNear(ID,Vertex) :- currentPos(Here), team(Team), visibleEdge(Here,Vertex), visibleEntity(ID,Vertex,Team,disabled), !.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%                            Inspector specific knowledge                         %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Predicate that returns uninspected agents close to the inspector
% This also makes sure enemy saboteurs are suitable for inspection again when last inspection is older than 50 steps
uninspectedNear :- visibleEntity(Agent,Vertex,Team,_), enemyTeam(Team), (currentPos(Vertex) ; neighbour(Vertex)), 
	(not(inspectedEntity(Agent,_,_,_,_,_,_,_,_,_)); ( inspectedEnemy(Agent, 'Saboteur'), lastInspect(Agent,LI), step(S), LI2 is LI + 50, LI2 < S)).
uninspectedEntity(Agent) :- not(inspectedEntity(Agent,_,_,_,_,_,_,_,_,_)).
