% energy/money checks
energyGE(Nr) :- energy(E), E >= Nr. 
moneyGE(Nr) :- money(M), M >= Nr.
maxEnergy(E) :- disabled, maxEnergyDisabled(E), !.
maxEnergy(E) :- not(disabled), maxEnergyWorking(E).
recharge(Nr) :- not(disabled), maxEnergy(E), Nr is round(0.5*E).
recharge(Nr) :- disabled, maxEnergy(E), Nr is round(0.3*E).

% Short predicate for current position of agent
role(Role) :- me(Id), role(Id, Role).

% Predicate that defines when an agent can not be trusted within the swarm
% This means the agent will not take the swarm into account when making its moves
independableAgent(Agent) :- me(Agent).
independableAgent(Agent) :- currentPos(Agent, Pos), insideZone(Pos).
independableAgent(Agent) :- role(Agent, 'Explorer'), not(swarmProbed).
independableAgent(Agent) :- role(Agent, 'Saboteur'), visibleEntity(_,_,Team,normal), enemyTeam(Team).
independableAgent(Agent) :- role(Agent, 'Repairer'), team(Team), visibleEntity(Id,Vertex,Team,disabled), not(currentPos(Agent, Vertex)).

% This rule is true when the area we intend to swarm is is entirely probed
swarmProbed :- optimum(Opt), !, vertexValue(Opt, OptVal), !, 
	doneExploring(OptVal), !, Val2 is OptVal - 1, doneExploring(Val2), !, Val3 is OptVal - 2, doneExploring(Val3).

% Two agents are connected when there are one or two edges between them
connectedAgent(Agent1, Agent2) :- team(Team), visibleEntity(Agent1,Pos1,Team,normal), visibleEntity(Agent2,Pos2,Team,normal), 
	visibleEdge(Pos1, Pos2), not(independableAgent(Agent2)), vertexOwner(Pos1, Team), vertexOwner(Pos2, Team).
connectedAgent(Agent1, Agent2) :- team(Team), visibleEntity(Agent1,Pos1,Team,normal), visibleEntity(Agent2,Pos2,Team,normal),
	visibleEdge(Pos1, Pos3), visibleEdge(Pos3,Pos2), not(Pos1 == Pos2), not(independableAgent(Agent2)),
	vertexOwner(Pos1, Team), vertexOwner(Pos2, Team), vertexOwner(Pos3, Team).

% Some short predicates for information about our optimum zone(the swarm around the found optimum)
agentsInOptimumZone(A) :- optimumInfo(A, _, _).
neighboursOfOptimumZone(F) :- optimumInfo(_, _, F).

% Team determination
enemyTeam(T) :- inspectedEntity(_, T, _, _, _, _, _, _, _, _).
enemyTeam(T) :- not(team(T)), T \= none.
% defines when an agent is disabled
disabled :- health(0).

% predicates for determining when a node or it's neighbour needs surveying
needSurvey(Vertex) :- vertex(Vertex,_,[]),!.
needSurvey(Vertex) :- not(vertex(Vertex,_,_)).
neighbourNeedSurvey(ID) :- currentPos(Here), neighbourNeedSurvey(Here,ID).
neighbourNeedSurvey(Vertex,ID) :- vertex(Vertex,_,List), member([_,ID],List), needSurvey(ID).

% true when an optimum is found
optimum :- optimum(_).
 
%should already exist but doesn't in SWI prolog so wrote the predicates ourself
select(X, [X | List], Y, [Y | List]).
select(X, [Same | XList], Y, [Same | YList]) :- Same \== X, select(X, XList, Y, YList).
random(0.0, 1.0, R) :-  R is (random(65391)/65391).

% Defines whether an enemy is to be considered dangerous for sure
dangerousEnemy(Id) :- inspectedEnemy(Id, 'Saboteur'), !.
dangerousEnemy(Id) :- not(inspectedEnemy(Id, _)), !, not((inspectedEnemy(Id2, 'Saboteur'), !, inspectedEnemy(Id3, 'Saboteur'), Id2 \= Id3)).
% Enemy is passive when disabled, can also be used on allies.
passiveEnemy(Id) :- visibleEntity(Id,_,_,disabled), !.
passiveEnemy(Id) :- inspectedEnemy(Id,Role), !, Role \= 'Saboteur'.
passiveEnemy(Id) :- not(inspectedEnemy(Id,_)), !, inspectedEnemy(Id2, 'Saboteur'), !, inspectedEnemy(Id3, 'Saboteur'), Id2 \= Id3.

% Short predicate to extract the most useful information from an inspected enemy
inspectedEnemy(Id,Role) :- inspectedEntity(Id, _, Role, _, _, _, _, _, _, _).

% True when we have 90 percent or more of all nodes in our posession
allMapAreBelongToUs :- team(Team), findall(Vertex, vertexOwner(Vertex, Team), List), vertices(V), V2 is 0.9*V, length(List, V3), V3 > V2.
	
% Rule that defines whether it is requires to parry, speaks for itself ;)
needToParry :- currentPos(Here), !, visibleEntity(Agent,Here,_,normal), dangerousEnemy(Agent).
