%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%                             Dijkstra from S to T                                %%
%% Code is adapted from: http://colin.barker.pagesperso-orange.fr/lpa/dijkstra.htm %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% main predicate

% path(Vertex0, Vertex, Path, Dist) is true if Path is the shortest path from
%   Vertex0 to Vertex, and the length of the path is Dist. The graph is defined
%   by e/3.
% e.g. path(penzance, london, Path, Dist)
path(Start, Target, Path, Dist) :-
  dijkstra2(Start, Target, s(Target,Dist,Path)), !.
  
% helping predicates

dijkstra2(Start, Target, ResultingS):-
  create(Start, [Start], Ds),
  recharge(ERecharge),
  dijkstra_2(Ds, ERecharge, [s(Start,0,[])], Target, ResultingS).

dijkstra_2([], _, _, _, _) :- !, fail.
dijkstra_2([D|Ds], ERecharge, _, Target, s(Target,Distance2,Path1)):-
  best(Ds,D,s(Target,Distance,Path)),
  delete2([D|Ds], [s(Target,Distance,Path)], _),
  reverse([Target|Path], Path1),
  Distance2 is Distance + ERecharge, !. % the '!' makes sure only 1 solution (the shortest) is correct.
  
dijkstra_2([D|Ds], ERecharge, Ss0, Target, ResultingS):-
  best(Ds, D, S),
  delete2([D|Ds], [S], Ds1),
  S=s(Vertex,Distance,Path),
  reverse([Vertex|Path], Path1),
  Distance2 is Distance + ERecharge,
  merge2(Ss0, [s(Vertex,Distance2,Path1)], Ss1),
  create(Vertex, [Vertex|Path], Ds2),
  delete2(Ds2, Ss1, Ds3),
  incr(Ds3, Distance2, Ds4),
  merge2(Ds1, Ds4, Ds5),
  dijkstra_2(Ds5, ERecharge, Ss1, Target, ResultingS).
  

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%                     Dijkstra for closest non-probed vertex                     %%
%% Code is adapted from: http://colin.barker.pagesperso-orange.fr/lpa/dijkstra.htm %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% main predicate

pathClosestNonProbed(Start, NonProbedVertex, Path, Dist) :-
  dijkstra3(Start, s(NonProbedVertex, Dist, Path)), !.

% helping predicates

dijkstra3(Start, ResultingS):-
  create(Start, [Start], Ds),
  recharge(ERecharge),
  dijkstra_3(Ds, ERecharge, [s(Start,0,[])], ResultingS).

dijkstra_3([], _, _, _) :- !, fail.
dijkstra_3([D|Ds], ERecharge, _, s(Vertex,Distance2,Path1)):-
  best(Ds,D,s(Vertex,Distance,Path)),
  needProbe(Vertex),
  delete2([D|Ds], [s(Vertex,Distance,Path)], _),
  reverse([Vertex|Path], Path1),
  Distance2 is Distance + ERecharge, !.
  
dijkstra_3([D|Ds], ERecharge, Ss0, ResultingS):-
  best(Ds, D, S),
  delete2([D|Ds], [S], Ds1),
  S=s(Vertex,Distance,Path),
  reverse([Vertex|Path], Path1),
  Distance2 is Distance + ERecharge,
  merge2(Ss0, [s(Vertex,Distance2,Path1)], Ss1),
  create(Vertex, [Vertex|Path], Ds2),
  delete2(Ds2, Ss1, Ds3),
  incr(Ds3, Distance2, Ds4),
  merge2(Ds1, Ds4, Ds5),
  dijkstra_3(Ds5, ERecharge, Ss1, ResultingS).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%        Dijkstra for closest non-probed vertex, with some additional checks      %%
%% Code is adapted from: http://colin.barker.pagesperso-orange.fr/lpa/dijkstra.htm %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% main predicate

pathClosestNonProbedWithExtraChecks(Start, NonProbedVertex, Path, Dist) :-
  dijkstra9(Start, s(NonProbedVertex, Dist, Path)), !.

% helping predicates

dijkstra9(Start, ResultingS):-
  create(Start, [Start], Ds),
  recharge(ERecharge),
  dijkstra_9(Ds, ERecharge, [s(Start,0,[])], ResultingS).

dijkstra_9([], _, _, _) :- !, fail.
dijkstra_9([D|Ds], ERecharge, _, s(Vertex,Distance2,Path1)):-
  best(Ds,D,s(Vertex,Distance,Path)),
  needProbe(Vertex),
  e(Vertex, NeedExploring, _), vertexValue(NeedExploring, Value), needExploring(Value),
  delete2([D|Ds], [s(Vertex,Distance,Path)], _),
  reverse([Vertex|Path], Path1),
  Distance2 is Distance + ERecharge.
  
dijkstra_9([D|Ds], ERecharge, Ss0, ResultingS):-
  best(Ds, D, S),
  delete2([D|Ds], [S], Ds1),
  S=s(Vertex,Distance,Path),
  reverse([Vertex|Path], Path1),
  Distance2 is Distance + ERecharge,
  merge2(Ss0, [s(Vertex,Distance2,Path1)], Ss1),
  create(Vertex, [Vertex|Path], Ds2),
  delete2(Ds2, Ss1, Ds3),
  incr(Ds3, Distance2, Ds4),
  merge2(Ds1, Ds4, Ds5),
  dijkstra_9(Ds5, ERecharge, Ss1, ResultingS).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%                    Dijkstra for closest non-surveyed vertex                     %%
%% Code is adapted from: http://colin.barker.pagesperso-orange.fr/lpa/dijkstra.htm %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% main predicate

pathClosestNonSurveyed(Start, NonSurveyedVertex, Path, Dist) :-
  dijkstra4(Start, s(NonSurveyedVertex, Dist, Path)), !.
  
% helping predicates

dijkstra4(Start, ResultingS):-
  create(Start, [Start], Ds),
  recharge(ERecharge),
  dijkstra_4(Ds, ERecharge, [s(Start,0,[])], ResultingS).

dijkstra_4([], _, _, _) :- !, fail.
dijkstra_4([D|Ds], ERecharge, _, s(Vertex,Distance2,Path1)):-
  best(Ds,D,s(Vertex,Distance,Path)),
  needSurvey(Vertex),
  delete2([D|Ds], [s(Vertex,Distance,Path)], _),
  reverse([Vertex|Path], Path1),
  Distance2 is Distance + ERecharge, !. % the '!' makes sure only 1 solution (the shortest) is correct.
  
dijkstra_4([D|Ds], ERecharge, Ss0, ResultingS):-
  best(Ds, D, S),
  delete2([D|Ds], [S], Ds1),
  S=s(Vertex,Distance,Path),
  reverse([Vertex|Path], Path1),
  Distance2 is Distance + ERecharge,
  merge2(Ss0, [s(Vertex,Distance2,Path1)], Ss1),
  create(Vertex, [Vertex|Path], Ds2),
  delete2(Ds2, Ss1, Ds3),
  incr(Ds3, Distance2, Ds4),
  merge2(Ds1, Ds4, Ds5),
  dijkstra_4(Ds5, ERecharge, Ss1, ResultingS).
  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%                           Dijkstra for closest Repairer                         %%
%% Code is adapted from: http://colin.barker.pagesperso-orange.fr/lpa/dijkstra.htm %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% main predicate

pathClosestRepairer(Start, LocationRepairer, NameAgent, Path, Dist) :-
  dijkstra5(Start, s(LocationRepairer, Dist, Path), NameAgent), !.
  
% helping predicates

dijkstra5(Start, ResultingS, NameAgent):-
  create(Start, [Start], Ds),
  recharge(ERecharge),
  dijkstra_5(Ds, ERecharge, [s(Start,0,[])], ResultingS, NameAgent).

dijkstra_5([], _, _, _, _) :- !, fail. 
dijkstra_5([D|Ds], ERecharge, _, s(Vertex,Distance2,Path1), NameAgent):-
  best(Ds,D,s(Vertex,Distance,Path)),
  repairerLoc(NameAgent, Vertex), 
  delete2([D|Ds], [s(Vertex,Distance,Path)], _),
  reverse([Vertex|Path], Path1),
  Distance2 is Distance + ERecharge, !. % the '!' makes sure only 1 solution (the shortest) is correct.
  
dijkstra_5([D|Ds], ERecharge, Ss0, ResultingS, NameAgent):-
  best(Ds, D, S),
  delete2([D|Ds], [S], Ds1),
  S=s(Vertex,Distance,Path),
  reverse([Vertex|Path], Path1),
  Distance2 is Distance + ERecharge,
  merge2(Ss0, [s(Vertex,Distance2,Path1)], Ss1),
  create(Vertex, [Vertex|Path], Ds2),
  delete2(Ds2, Ss1, Ds3),
  incr(Ds3, Distance2, Ds4),
  merge2(Ds1, Ds4, Ds5),
  dijkstra_5(Ds5, ERecharge, Ss1, ResultingS, NameAgent).

 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%                           Dijkstra for closest Enemy                         %%
%% Code is adapted from: http://colin.barker.pagesperso-orange.fr/lpa/dijkstra.htm %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% main predicate

pathClosestEnemy(Start, LocationEnemy, NameEnemy, Path, Dist) :-
  dijkstra6(Start, s(LocationEnemy, Dist, Path), NameEnemy), !.
  
% helping predicates

dijkstra6(Start, ResultingS, NameAgent):-
  create(Start, [Start], Ds),
  recharge(ERecharge),
  dijkstra_6(Ds, ERecharge, [s(Start,0,[])], ResultingS, NameAgent).

dijkstra_6([], _, _, _, _) :- !, fail. 
dijkstra_6([D|Ds], ERecharge, _, s(Vertex,Distance2,Path1), NameAgent):-
  best(Ds,D,s(Vertex,Distance,Path)),
  enabledEnemy(NameAgent, Vertex), %Enemy must be active by last info.
  delete2([D|Ds], [s(Vertex,Distance,Path)], _),
  reverse([Vertex|Path], Path1),
  Distance2 is Distance + ERecharge, !. % the '!' makes sure only 1 solution (the shortest) is correct.
  
dijkstra_6([D|Ds], ERecharge, Ss0, ResultingS, NameAgent):-
  best(Ds, D, S),
  delete2([D|Ds], [S], Ds1),
  S=s(Vertex,Distance,Path),
  reverse([Vertex|Path], Path1),
  Distance2 is Distance + ERecharge,
  merge2(Ss0, [s(Vertex,Distance2,Path1)], Ss1),
  create(Vertex, [Vertex|Path], Ds2),
  delete2(Ds2, Ss1, Ds3),
  incr(Ds3, Distance2, Ds4),
  merge2(Ds1, Ds4, Ds5),
  dijkstra_6(Ds5, ERecharge, Ss1, ResultingS, NameAgent).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%                   List all the information in the optimum zone                  %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  
allInformationOptimumZone([],[],[]) :- not(optimum(_)), !.
allInformationOptimumZone(Agents, Nodes, Neighbours) :- optimum(Opt), team(Team),
	allInformationOptimumZone([Opt], [], Nodes, Agents, Neighbours, Team), !.

allInformationOptimumZone([], _, [], [], [], _).
allInformationOptimumZone([First|ToConsider], Visited, [First|Nodes], Agents, Neighbours, Team) :-
	vertexOwner(First, Team),
	findall([NameAgent, First], visibleEntity(NameAgent, First, Team, normal), FoundAgents),
	findall(Node, (e4(First, Node, _), not(member(Node, Visited))), FoundNodesTemp), list_to_set(FoundNodesTemp, FoundNodes),
	union(FoundNodes, ToConsider, NewToConsider),
	allInformationOptimumZone(NewToConsider, [First|Visited], Nodes, NewAgents, Neighbours, Team),
	union(NewAgents, FoundAgents, Agents).
allInformationOptimumZone([First|ToConsider], Visited, Nodes, Agents, [First|Neighbours], Team) :-
	not(vertexOwner(First, Team)),
	allInformationOptimumZone(ToConsider, [First|Visited], Nodes, Agents, Neighbours, Team).

 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%                        Dijkstra for closest Visible Enemy                       %%
%% Code is adapted from: http://colin.barker.pagesperso-orange.fr/lpa/dijkstra.htm %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% main predicate

pathClosestVisibleEnemy(Start, LocationEnemy, NameEnemy, Path, Dist) :-
  dijkstra8(Start, s(LocationEnemy, Dist, Path), NameEnemy), !.
  
% helping predicates

dijkstra8(Start, ResultingS, NameAgent):-
  create(Start, [Start], Ds),
  recharge(ERecharge),
  dijkstra_8(Ds, ERecharge, [s(Start,0,[])], ResultingS, NameAgent).

dijkstra_8([], _, _, _, _) :- !, fail. 
dijkstra_8([D|Ds], ERecharge, _, s(Vertex,Distance2,Path1), NameAgent):-
  best(Ds,D,s(Vertex,Distance,Path)),
  enabledEnemy(NameAgent, Vertex), 
  visibleEntity(NameAgent,_,_,_), %Enemy must be visible in current step.
  delete2([D|Ds], [s(Vertex,Distance,Path)], _),
  reverse([Vertex|Path], Path1),
  Distance2 is Distance + ERecharge, !. % the '!' makes sure only 1 solution (the shortest) is correct.
  
dijkstra_8([D|Ds], ERecharge, Ss0, ResultingS, NameAgent):-
  best(Ds, D, S),
  delete2([D|Ds], [S], Ds1),
  S=s(Vertex,Distance,Path),
  reverse([Vertex|Path], Path1),
  Distance2 is Distance + ERecharge,
  merge2(Ss0, [s(Vertex,Distance2,Path1)], Ss1),
  create(Vertex, [Vertex|Path], Ds2),
  delete2(Ds2, Ss1, Ds3),
  incr(Ds3, Distance2, Ds4),
  merge2(Ds1, Ds4, Ds5),
  dijkstra_8(Ds5, ERecharge, Ss1, ResultingS, NameAgent).
  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%                     General Dijkstra helping predicates                         %%
%% Code is adapted from: http://colin.barker.pagesperso-orange.fr/lpa/dijkstra.htm %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% create(Start, Path, Edges) is true if Edges is a list of structures s(Vertex,
%   Distance, Path) containing, for each Vertex accessible from Start, the
%   Distance from the Vertex and the specified Path.  The list is sorted by the
%   name of the Vertex.
create(Start, Path, Edges):-
  maxEnergy(E), setof(s(Vertex,Edge,Path), (e(Start,Vertex,Edge), Edge =< E ), Edges), !.
create(_, _, []).

% best(Edges, Edge0, Edge) is true if Edge is the element of Edges, a list of
%   structures s(Vertex, Distance, Path), having the smallest Distance.  Edge0
%   constitutes an upper bound.
best([], s(A,B,C), s(A,B,C)).
best([s(A,B,C)|Edges], Best0, Best):-
  shorter(s(A,B,C), Best0), !,
  best(Edges, s(A,B,C), Best).
best([_|Edges], Best0, Best):-
  best(Edges, Best0, Best).

shorter(s(_,X,_), s(_,Y,_)):-X < Y.

% delete2(Xs, Ys, Zs) is true if Xs, Ys and Zs are lists of structures s(Vertex,
%   Distance, Path) ordered by Vertex, and Zs is the result of deleting from Xs
%   those elements having the same Vertex as elements in Ys.
delete2([], _, []).
delete2([X|Xs], [], [X|Xs]):-!.
delete2([X|Xs], [Y|Ys], Ds):-
  eq(X, Y), !,
  delete2(Xs, Ys, Ds).
delete2([X|Xs], [Y|Ys], [X|Ds]):-
  lt(X, Y), !, delete2(Xs, [Y|Ys], Ds).
delete2([X|Xs], [_|Ys], Ds):-
  delete2([X|Xs], Ys, Ds).

% merge2(Xs, Ys, Zs) is true if Zs is the result of merging Xs and Ys, where Xs,
%   Ys and Zs are lists of structures s(Vertex, Distance, Path), and are
%   ordered by Vertex.  If an element in Xs has the same Vertex as an element
%   in Ys, the element with the shorter Distance will be in Zs.
merge2([], Ys, Ys).
merge2([X|Xs], [], [X|Xs]):-!.
merge2([X|Xs], [Y|Ys], [X|Zs]):-
  eq(X, Y), shorter(X, Y), !,
  merge2(Xs, Ys, Zs).
merge2([X|Xs], [Y|Ys], [Y|Zs]):-
  eq(X, Y), !,
  merge2(Xs, Ys, Zs).
merge2([X|Xs], [Y|Ys], [X|Zs]):-
  lt(X, Y), !,
  merge2(Xs, [Y|Ys], Zs).
merge2([X|Xs], [Y|Ys], [Y|Zs]):-
  merge2([X|Xs], Ys, Zs).

eq(s(X,_,_), s(X,_,_)).

lt(s(X,_,_), s(Y,_,_)):-X @< Y.

% incr(Xs, Incr, Ys) is true if Xs and Ys are lists of structures s(Vertex,
%   Distance, Path), the only difference being that the value of Distance in Ys
%   is Incr more than that in Xs.
incr([], _, []).
incr([s(V,D1,P)|Xs], Incr, [s(V,D2,P)|Ys]):-
  D2 is D1 + Incr,
  incr(Xs, Incr, Ys).

% predicate that finds all surveyed edges, and checks both ways to make sure not an edge is missed
e(X, Y, Z):- vertex(X, _, List), member([Z,Y], List), not(Z == unknown).
e(X, Y, Z):- vertex(Y, _, List), member([Z,X], List), not(Z == unknown).
e(X, Y, 5):- vertex(X, _, List), member([unknown,Y], List), vertex(Y, _, List2), member([unknown, X], List2).
e(X, Y, 5):- vertex(Y, _, List), member([unknown,X], List), vertex(X, _, List2), member([unknown, Y], List2).

% predicate that finds all survyed edges, but requires at least one of the sides of the edge to be in our zone
e4(X, Y, Z):- vertex(X, _, List), member([Z,Y], List), not(Z == unknown), team(OurTeam), (vertexOwner(X,OurTeam);vertexOwner(Y,OurTeam)).
e4(X, Y, Z):- vertex(Y, _, List), member([Z,X], List), not(Z == unknown), team(OurTeam), (vertexOwner(X,OurTeam);vertexOwner(Y,OurTeam)).
e4(X, Y, 5):- vertex(X, _, List), member([unknown,Y], List), vertex(Y, _, List2), member([unknown, X], List2), team(OurTeam), (vertexOwner(X,OurTeam);vertexOwner(Y,OurTeam)).
e4(X, Y, 5):- vertex(Y, _, List), member([unknown,X], List), vertex(X, _, List2), member([unknown, Y], List2), team(OurTeam), (vertexOwner(X,OurTeam);vertexOwner(Y,OurTeam)).
