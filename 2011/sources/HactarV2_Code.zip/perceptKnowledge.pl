% Extraction some information about the agent itself from the percepts
money(M) :- percept(money(M)).
energy(E) :- percept(energy(E)).
maxEnergyWorking(E) :- percept(maxEnergy(E)).
maxEnergyDisabled(E) :- percept(maxEnergyDisabled(E)).
strength(S) :- percept(strength(S)).
maxHealth(H) :- percept(maxHealth(H)).

% Extracting visible entities, vertices and edges from the percepts
visibleEntity(Id,Vertex,Team,Status) :- percept(visibleEntity(Id,Vertex,Team,Status)).
vertexOwner(Vertex,Team) :- percept(visibleVertex(Vertex, Team)).
visibleEdge(Vertex1,Vertex2) :- percept(visibleEdge(Vertex1,Vertex2)).
visibleEdge(Vertex1,Vertex2) :- percept(visibleEdge(Vertex2,Vertex1)).

% Extracting the agents current position from the percepts
currentPos(Agent,Vertex) :- percept(visibleEntity(Agent,Vertex,_,_)).

% Extracting round information from the percepts
lastAction(Action) :- percept(lastAction(Action)).
lastActionResult(Result) :- percept(lastActionResult(Result)).
