% Finds all neighbouring nodes of the current position
neighbour(Neighbour) :- currentPos(Id),!, neighbour(Id,_,Neighbour).

% Finds all neighbouring nodes of a given node
neighbour(Id,Neighbour) :- neighbour(Id,_,Neighbour).

% Finds all neighbouring nodes of a given node, and the weight of their connection
neighbour(Id,Weight,Neighbour) :- vertex(Id,_,List), member([Weight,Neighbour],List).

% This predicate determines when a node is to be considered safe to stand on, this means no unknown role agent or saboteur can be at this location 
safePos(P) :- not((visibleEntity(A, P, T, normal), enemyTeam(T), not(passiveEnemy(A)))), 
	not((neighbour(P, P2), visibleEntity(A2, P2, T, normal), enemyTeam(T), inspectedEnemy(A2,'Saboteur'))).
	
% This is true when the agent has the highest rank(based on its name) of all agents on this node
kingOfTheHill :- agentRankHere(0).

% Determines if the agent is the only agent on its position
foreverAlone :- not( (currentPos(Pos), me(Me), team(Team), !, visibleEntity(ID, Pos, Team ,_), Me \= ID ) ).

% Compares agents names to find which name has a higher 'value'
compareAgents(Agent1,Agent2,Agent2) :- Agent1 @< Agent2.
compareAgents(Agent1,Agent2,Agent1) :- Agent1 @> Agent2.

% Returns the rank(based on its name) of an agent compared to all other agents on its node
agentRankHere(Rank) :- currentPos(Here), me(Name), team(Team), !, 
	setof(Agent, visibleEntity(Agent,Here,Team,normal), Agents), agentRank(Agents,Name,Rank).
	
%
agentRank(List,Agent,Rank) :- nth0(Rank, List, Agent), !.

% Predicate that selects a Neighbour on index Number from the list of Neighbours, useful in combination with agentrank for splitting up, agent with rank 0 will not get a neighbour
selectNeighbour(List, Number, Neighbour) :- length(List, Size), Num is mod(Number,Size), nth1(Num, List, Neighbour), !.

% Predicate that selects a Destination on index Number from the list of Destinations, useful for splitting up in combination with agentrank when multiple destinations are available
selectDestination(List, Number, Destination) :- length(List,Size), Num is mod(Number,Size), nth0(Num, List, Destination), !.

% Short predicates for vertex information
vertexValue(Id,Value) :- vertex(Id,Value,_).
vertexValue(Id,unknown) :- not(vertex(Id,_,_)).

% predicate that determines if a position results situation where the agent maintains connection with another agent
connectedPos(X, Agent) :- currentPos(Agent, Y), not(independableAgent(Agent)), visibleEdge(X,Y).
connectedPos(X, Agent) :- currentPos(Agent, Z), not(independableAgent(Agent)), X \== Z, 
	visibleEdge(Z,Y), team(Team), vertexOwner(Y, Team), visibleEdge(Y,X).

% a vertex that is a swarmpos is a position that makes sure the agent is still connected to 2 other agents
swarmPos(X) :- connectedPos(X, Agent1), connectedPos(X, Agent2), Agent1 \== Agent2, !.

% check if the agent is currently in the zone that contains the found optimum
inOptimumZone :- me(Id), agentsInOptimumZone(A), member([Id,_], A).
