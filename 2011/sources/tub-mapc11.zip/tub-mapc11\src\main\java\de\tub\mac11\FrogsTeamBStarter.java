package de.tub.mac11;

import de.dailab.jiactng.agentcore.SimpleAgentNode;

public class FrogsTeamBStarter {
	public static String NODES_SPRINGCONFIGFILE = "classpath:Frogs-TeamB.xml";

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SimpleAgentNode.main(new String[] {NODES_SPRINGCONFIGFILE});
	}

}
