package de.tub.mac11.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac11.ontology.Edge;
import de.tub.mac11.ontology.Vertex;

public class DistanceMatrix implements IFact {

  private int                                worldSize        = -1;

  private DistanceEntry[][]                  matrix           = null;

  private HashMap<String, Integer>           nameToIndexMap   = new HashMap<String, Integer>();

  private transient HashMap<Integer, Vertex> indexToVertexMap = new HashMap<Integer, Vertex>();

  public DistanceMatrix(int worldSize, Collection<Vertex> vertices, Collection<Edge> edges, int maxEdgeCost) {
    this.worldSize = worldSize;
    this.matrix = new DistanceEntry[worldSize][worldSize];
    calculateFWMatrix(vertices, edges, maxEdgeCost);
  }

  private void calculateFWMatrix(Collection<Vertex> vertices, Collection<Edge> edges, int maxEdgeCost) {

    initVertexMap(vertices);

    // // Vertex[] vArray = new Vertex[worldSize];
    //
    // for (int i = 0; i < vertices.size(); i++) {
    // int index = calcVertexIndex(vertices.get(i));
    // vArray[index] = vertices.get(i);
    // }

    // initial distances: self
    DistanceEntry selfToSelf = new DistanceEntry();
    selfToSelf.totalCost = 0;
    for (int i = 0; i < worldSize; i++) {
      matrix[i][i] = selfToSelf;
    }

    // initial distances: edges
    for (Edge e : edges) {
      if (e.weight > maxEdgeCost) {
        e.updated = false;
        continue;
      }

      int i = getIndex(e.node1);
      int j = getIndex(e.node2);
      DistanceEntry forward = new DistanceEntry();
      DistanceEntry backward = new DistanceEntry();

      // forward
      forward.totalCost = e.weight;
      forward.path.add(getVertex(i).name);
      forward.path.add(getVertex(j).name);

      // backward
      backward.totalCost = e.weight;
      backward.path.add(getVertex(j).name);
      backward.path.add(getVertex(i).name);

      matrix[i][j] = forward;
      matrix[j][i] = backward;

      e.updated = false;
    }

    // main loop, for each vertex, check if it can connect two other vertices.
    for (int k = 0; k < worldSize; k++) {
      Vertex vk = getVertex(k);
      if (vk == null) {
        continue;
      }

      calcaluateAllPathsForVertex(vk);

      vk.updated = false;
    } // end k-loop

    // int maxSteps = 0;
    // int bestMaxSteps = Integer.MAX_VALUE;
    //
    // for(int i=0;i<worldSize;i++) {
    // int tempI = 0;
    // for(int j=0;j<worldSize;j++) {
    // if(matrix[i][j] == null) {
    // continue;
    // }
    // int temp = matrix[i][j].getSteps();
    // if(temp>maxSteps) {
    // maxSteps = temp;
    // }
    //
    // if(temp>tempI) {
    // tempI = temp;
    // }
    // }
    // if(tempI>0 && tempI<bestMaxSteps) {
    // bestMaxSteps = tempI;
    // }
    // }
    //
    // System.err.println("maxSteps: "+maxSteps);
    // System.err.println("bestMaxSteps: "+bestMaxSteps);

  }

  public void updateFWMatrix(Collection<Vertex> vertices, Collection<Edge> edges) {

    // check if vertices are known
    for (Vertex v : vertices) {
      Integer index = nameToIndexMap.get(v.name);
      if (index == null) {
        index = calcVertexIndex(v);
        nameToIndexMap.put(v.name, index);
      }
      indexToVertexMap.put(index, v);
    }

    // update all edges
    for (Edge e : edges) {
      int i = getIndex(e.node1);
      int j = getIndex(e.node2);
      if (matrix[i][j] == null) {
        DistanceEntry forward = new DistanceEntry();
        DistanceEntry backward = new DistanceEntry();

        // forward
        forward.totalCost = e.weight;
        forward.path.add(getVertex(i).name);
        forward.path.add(getVertex(j).name);

        // backward
        backward.totalCost = e.weight;
        backward.path.add(getVertex(j).name);
        backward.path.add(getVertex(i).name);

        matrix[i][j] = forward;
        matrix[j][i] = backward;

      } else if (matrix[i][j].getSteps() == 1) {
        matrix[i][j].totalCost = e.weight;
        matrix[j][i].totalCost = e.weight;
      }
      e.updated = false;
    }

    // update paths for all vertices
    for (Vertex v : vertices) {
      calcaluateAllPathsForVertex(v);
      v.updated = false;
    }

  }

  private void calcaluateAllPathsForVertex(Vertex newVertex) {
    int k = getIndex(newVertex);

    for (int i = 0; i < worldSize; i++) {
      Vertex vi = getVertex(i);
      if (vi == null) {
        continue;
      }

      for (int j = i + 1; j < worldSize; j++) {
        Vertex vj = getVertex(j);
        if (vj == null) {
          continue;
        }

        if (!vi.name.equals(vj.name)) {
          // vi and vj are different, so there is something to do

          if (matrix[i][j] == null) {
            matrix[i][j] = new DistanceEntry();
          }

          if (matrix[i][k] == null) {
            matrix[i][k] = new DistanceEntry();
          }

          if (matrix[k][j] == null) {
            matrix[k][j] = new DistanceEntry();
          }

          int length_ij = matrix[i][j].totalCost;
          int length_ikj = -1;
          if ((matrix[i][k].totalCost > 0) && (matrix[k][j].totalCost > 0)) {
            // paths i-k and k-j exist, so we compare them to i-j
            length_ikj = matrix[i][k].totalCost + matrix[k][j].totalCost;
            if ((length_ij == -1) || (length_ij > length_ikj)) {
              // either i-j does not exist, or i-k-j is shorter, so we take
              // i-k-j
              DistanceEntry forward = new DistanceEntry();
              DistanceEntry backward = new DistanceEntry();

              forward.totalCost = length_ikj;
              forward.path.clear();
              forward.path.addAll(matrix[i][k].path);
              forward.path.remove(matrix[i][k].path.size() - 1);
              forward.path.addAll(matrix[k][j].path);

              // set backwards path
              backward.totalCost = length_ikj;
              backward.path.clear();
              for (int c = forward.path.size() - 1; c >= 0; c--) {
                backward.path.add(forward.path.get(c));
              }

              matrix[i][j] = forward;
              matrix[j][i] = backward;

            } // stay with i-j, nothing to do
          }
        }
      } // end j-loop
    } // end i-loop
  }

  private int calcVertexIndex(Vertex v) {
    int index = calcVertexIndex(v.name);
    return index;
  }

  private int calcVertexIndex(String name) {
    int index = Integer.parseInt(name.substring(6));
    return index;
  }

  public int getIndex(Vertex v) {
    return getIndex(v.name);
  }

  public int getIndex(String vertexName) {
    Integer ret = null;
    ret = nameToIndexMap.get(vertexName);
    if (ret == null) {
      ret = -1;
    }
    return ret;
  }

  public Vertex getVertex(int index) {
    return indexToVertexMap.get(index);
  }

  public DistanceEntry getEntry(Vertex v1, Vertex v2) {
    DistanceEntry ret = null;
    ret = matrix[calcVertexIndex(v1)][calcVertexIndex(v2)];
    // TODO: null or empty entry???
    // if (ret == null) {
    // ret = new DistanceEntry();
    // }
    return ret;
  }

  private void printFWMatrix() {
    System.err.println("\n --- --- ---");
    for (int i = 0; i < worldSize; i++) {
      for (int j = 0; j < worldSize; j++) {
        System.err.print("  " + matrix[i][j].totalCost);
      }
      System.err.println();
    }
    System.err.println(" --- --- ---\n");
  }

  public void initVertexMap(Collection<Vertex> vertices) {
    nameToIndexMap = new HashMap<String, Integer>();
    indexToVertexMap = new HashMap<Integer, Vertex>();

    for (Vertex v : vertices) {
      int index = calcVertexIndex(v);
      nameToIndexMap.put(v.name, index);
      indexToVertexMap.put(index, v);
    }
  }

  public ArrayList<Vertex> getAllVerticesWithinSteps(Vertex start, int dist) {
    ArrayList<Vertex> ret = new ArrayList<Vertex>();

    int startIndex = getIndex(start);
    if(startIndex == -1) {
      System.err.println("Start-vertex not yet in matrix - skipping neighbor calculation");
      return ret;
    }
    for (int i = 0; i < worldSize; i++) {
      DistanceEntry entry = matrix[startIndex][i];

      if ((entry != null) && (0 < entry.getSteps()) && (entry.getSteps() <= dist)) {
        ret.add(indexToVertexMap.get(i));
      }
    }

    return ret;
  }

}
