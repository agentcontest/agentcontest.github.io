package de.tub.mac11.util;

import org.apache.commons.collections15.Transformer;

import de.tub.mac11.ontology.Edge;

/**
 * A class which defines how to read the weights of edges. The weight of an
 * unsurveyed edge gets estimated as 5.
 * 
 * @author benjamin
 * 
 */
public class WeightReader implements Transformer<Edge, Number> {
	public Number transform(Edge edge) {
		Number weight = null;
		if (edge.surveyed) {
			weight = edge.weight;
		} else {
			weight = 5;
		}
		return weight;
	}
}
