package de.tub.mac11.bean;

import de.dailab.jiactng.agentcore.action.AbstractMethodExposingBean;

public class AgentCommunication extends AbstractMethodExposingBean {

}
