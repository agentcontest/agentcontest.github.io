package de.tub.mac11.ontology;

import java.util.HashMap;

import de.dailab.jiactng.agentcore.knowledge.IFact;

public class Vertex implements IFact {

  public String name;
  public int    lastSeen = -1;
  
  // values: "none", "own", "enemy" 
  public String team = "none";

	public int x = -1;
	public int y = -1;

  public boolean updated = true;

	public int value = 1;

	/*
	 * by default, a vertex has the value 1, which doesn't indicate if the
	 * vertex has already been probed. Because of this, a separate property probed is
	 * needed.
	 */
	public boolean probed = false;

	public Vertex(String name) {
		this.name = name;
	}

	public Vertex(String name, int value, String team, int lastSeen) {
		this(name);
		this.value = value;
		this.team = team;
		this.lastSeen = lastSeen;
	}

	@Override
	public int hashCode() {
		if (name == null) {
			return 0;
		} else {
			return name.hashCode();
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || !(obj instanceof Vertex)) {
			return false;
		}

		Vertex other = (Vertex) obj;
		return ((this.name == null) || (other.name == null) || (this.name
				.equals(other.name)));
	}

	@Override
	public String toString() {
		StringBuffer ret = new StringBuffer("(V: ");
		ret.append(name);
		ret.append(" v=").append(value);
		ret.append(" t=").append(team);
		ret.append(" lastSeen=").append(lastSeen);
		ret.append(")");
		return ret.toString();
	}

	public void setProbed(boolean probed) {
		this.probed = probed;
	}

	public boolean isProbed() {
		return probed;
	}
  
  public void setTeam(String team) {
		this.team = team;
	}
  
  public String getTeam() {
		return team;
	}

}
