package de.tub.mac11.bean;

import de.tub.mac11.states.Escape;
import de.tub.mac11.states.Inspect;

public class InspectorDecisionBean extends DecisionBean {
	
	@Override
	protected void addStatesAndConditions() {
		
		escape = new Escape(getWorld(), this);
		inspect = new Inspect(getWorld(), this);	
		
		// add states
		super.addStatesAndConditions();
		getStatesList().add(disabled);
		getStatesList().add(escape);
		getStatesList().add(group);
		getStatesList().add(inspect);
		getStatesList().add(surveyEdges);
		getStatesList().add(createZone);
	}	
	
}