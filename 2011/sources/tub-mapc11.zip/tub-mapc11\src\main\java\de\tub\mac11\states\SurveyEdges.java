package de.tub.mac11.states;

import de.tub.mac11.bean.DecisionBean;
import de.tub.mac11.connection.MessageConstants;
import de.tub.mac11.ontology.InfoMsg;
import de.tub.mac11.ontology.Intention;
import de.tub.mac11.ontology.Vertex;
import de.tub.mac11.ontology.World;

public class SurveyEdges extends State {

	Vertex myPosition = null;
	
	public SurveyEdges(World world, DecisionBean db) {
		super(world, db);
	}

	@Override
	public Intention execute() {
		
		return new Intention(MessageConstants.ACTION_SURVEY, null);
	}

	@Override
	protected void handleInfoMsg(InfoMsg infoMsg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isTrue() {
		myPosition = getWorld().getVertices().get(getWorld().getSelf().getPosition());
		if (getWorld().isNeighborEdgesSurveyed(myPosition)) {
			return false;
		}
		return true;
	}

	@Override
	public boolean rechargeNeeded() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	protected Path getPathfinding() {
		return Path.SAFE;
	}

}