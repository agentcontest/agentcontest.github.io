package de.tub.mac11.states;

import de.tub.mac11.bean.DecisionBean;
import de.tub.mac11.connection.MessageConstants;
import de.tub.mac11.ontology.InfoMsg;
import de.tub.mac11.ontology.Intention;
import de.tub.mac11.ontology.World;


public class Buy extends State {
	
	public Buy(World world, DecisionBean db) {
		super(world, db);
	}

	@Override
	public Intention execute() {
		
		Intention intention = null;
		
		if (getWorld().getSelf().maxHealth < 5
				|| getWorld().enemySaboteurEstimatedStrength+1 >= getWorld().getSelf().maxHealth) {
			intention = new Intention(MessageConstants.ACTION_BUY, "shield");
			
		} else if (getWorld().getSelf().strength < 6) {
			intention = new Intention(MessageConstants.ACTION_BUY, "sabotageDevice");
		}
		
		return intention;
	}
		
	public boolean isTrue() {
		
		// check if there is an enemy on the same position
		int enemies = getWorld().numEnemyAgentsOnVertex(getWorld().getSelf().position);
		if (enemies > 0) {
			return false;
		}
		
		// check if enough money
		if (getWorld().money >= 4) {
			
			// check if need upgrade
			if (getWorld().getSelf().maxHealth < 5 
					|| getWorld().getSelf().strength < 6
					|| getWorld().enemySaboteurEstimatedStrength+1 >= getWorld().getSelf().maxHealth) {
				return true;
			}
		}
			
		return false;		
	}
	
	@Override
	public void handleInfoMsg(InfoMsg infoMsg) {
		// do nothing		
	}

	@Override
	protected Path getPathfinding() {
		return Path.NORMAL;
	}

}
