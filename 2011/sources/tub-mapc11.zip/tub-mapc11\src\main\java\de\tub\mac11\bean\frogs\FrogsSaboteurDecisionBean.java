package de.tub.mac11.bean.frogs;

import java.util.List;

import de.tub.mac11.connection.MessageConstants;
import de.tub.mac11.ontology.Bot;
import de.tub.mac11.ontology.Intention;
import de.tub.mac11.util.DistanceEntry;

public class FrogsSaboteurDecisionBean extends FrogsAbstractDecisionBean {

  private StringBuffer stateString   = null;

  private Bot          currentTarget = null;

  public void decide() {
    // skip, goto, parry, survey, buy, attack, recharge
    Intention intention = null;

    currentPosition = world.vertices.get(world.self.position);
    currentPosition.lastSeen = world.currentStep;

    // various outputs for debugging
    stateString = initStateString("Saboteur");

    // get intention
    intention = simpleIntention();
    printValue("Intention", intention, stateString);

    // print everything, submit intention and done
    produceStatistics(intention, stateString);
    System.out.println(stateString.toString());
    // log.warn(stateString.toString());
    submitAction(intention);
  }

  private Intention simpleIntention() {
    Intention intention = null;

    // check if we may buy more energy
    if (intention == null) {
      intention = checkEnergyBuy();
    }

    // check if we can attack something
    if (intention == null) {
      intention = checkAttack();
    }

    // check if there are unknown edges here, if so -> survey
    if (intention == null) {
      intention = checkSurvey();
    }

    // check if we need to recharge
    if ((intention == null) || (this.world.self.energy < 2)) {
      intention = checkRecharge();
    }

    // make sure matrix is known, otherwise a random move is chosen
    if (intention == null) {
      intention = checkIfMatrixIsKnown();
    }
    
    if((world.self.health==0) && (this.world.self.energy >= 2)) {
      intention = checkNeedHelp(stateString);
    }

    if (intention == null) {
      // update hunting target (or set to null)
      updateHuntingTarget();
      intention = checkHunt();
    }

    // check if we can help with occupation
    if (intention == null) {
      intention = checkOccupy(stateString);
    }

    return intention;
  }

  private void updateHuntingTarget() {
    // InformContent template = new InformContent(InformContent.TYPE.HUNT_BOT,
    // null, null);
    // Set<InformContent> infoSet = memory.readAll(template);
    //
    // if (infoSet.size() == 0) {
    // currentTarget = null;
    // } else {
    // String targetName = infoSet.iterator().next().target;
    // currentTarget = world.opponents.get(targetName);
    // }

    if ((currentTarget != null) && (currentTarget.disabled)) {
      currentTarget = null;
    }

    int distance = Integer.MAX_VALUE;
    for (Bot b : world.opponents.values()) {
      if (b.lastSeen < world.currentStep) {
        continue;
      }

      if (b.disabled) {
        continue;
      }

      DistanceEntry entry = matrix.getEntry(currentPosition, world.vertices.get(b.position));
      if ((entry == null) || (entry.path.size() < 2)) {
        continue;
      }

      if (currentTarget == null) {
        currentTarget = b;
        distance = entry.totalCost;
        continue;
      }

      if (compareBotRoles(currentTarget, b) > 0) {
        currentTarget = b;
        distance = entry.totalCost;

      } else if (entry.totalCost < distance) {
        currentTarget = b;
        distance = entry.totalCost;
      }

    }
  }

  private Intention checkHunt() {
    Intention ret = null;
    // if (currentTarget == null) {
    // for (Bot bot : this.world.opponents.values()) {
    // if (bot.health > 0) {
    // // should be known, as bot was visible at least once
    // currentTarget = bot;
    // break;
    // }
    // }
    // }

    if (currentTarget != null) {
      currentGoal = this.world.vertices.get(currentTarget.position);
      if (currentGoal == null) {
        System.err.println(" no position for " + currentTarget);
        return null;
      }
      DistanceEntry pathEntry = matrix.getEntry(currentPosition, currentGoal);
      printValue("hunting", currentTarget, stateString);
      printValue("path", pathEntry.path, stateString);
      if (pathEntry.path.size() > 1) {
        ret = new Intention(MessageConstants.ACTION_GOTO, pathEntry.path.get(1));
      }

    } else {
      printValue("Waiting for target...", null, stateString);
    }
    return ret;
  }

  private Intention checkAttack() {
    Intention ret = null;

    Bot attackTarget = null;
    List<Bot> currentOpponents = getEnemyBotsOnVertex(currentPosition, true);
    for (Bot b : currentOpponents) {
      if (b.disabled) {
        continue;
      }

      if (attackTarget == null) {
        attackTarget = b;
      } else if (compareBotRoles(attackTarget, b) > 0) {
        attackTarget = b;
      } 
    }

    if (attackTarget != null) {
      currentTarget = attackTarget;
      printValue("attacking", currentTarget, stateString);
      stateString.append("opponentState: ").append(currentTarget.health).append("/").append(currentTarget.maxHealth)
          .append(", ");
      ret = new Intention(MessageConstants.ACTION_ATTACK, currentTarget.name);
    }
    return ret;

    // if (currentTarget != null) {
    // if (currentPosition.name.equals(currentTarget.position)) {
    // if (!currentTarget.disabled) {
    // printValue("attacking", currentTarget, stateString);
    // stateString.append("opponentState: ").append(currentTarget.health).append("/")
    // .append(currentTarget.maxHealth).append(", ");
    // ret = new Intention(MessageConstants.ACTION_ATTACK, currentTarget.name);
    // } else {
    // printValue("target dead", currentTarget, stateString);
    // }
    // }
    // }
    // return ret;
  }

  private int compareBotRoles(Bot b1, Bot b2) {
    if ((b1.role != null) && (b2.role != null) && b1.role.equals(b2.role)) {
      return 0;
    }

    if (Bot.REPAIRER.equals(b1.role)) {
      return -1;
    }

    if (Bot.REPAIRER.equals(b2.role)) {
      return 1;
    }

    if (Bot.SABOTEUR.equals(b1.role)) {
      return -1;
    }

    if (Bot.SABOTEUR.equals(b2.role)) {
      return 1;
    }

    return 0;
  }

}
