package de.tub.mac11.util;

import java.util.ArrayList;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac11.ontology.Vertex;

public class DistanceEntry implements IFact {

	public int totalCost = -1;
	public ArrayList<String> path = new ArrayList<String>();
	
	public int getSteps() {
	  return path.size()-1;
	}
	
}
