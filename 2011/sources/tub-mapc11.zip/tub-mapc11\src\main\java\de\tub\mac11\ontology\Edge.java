package de.tub.mac11.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;

public class Edge implements IFact {
  public String node1;
  public String node2;

  public int weight = 1;
  public String id;
  public boolean surveyed = false;
  public boolean updated = true;

  public Edge(String node1, String node2) {
    this.node1 = node1;
    this.node2 = node2;

    if (node1 == null || node2 == null) {
      this.id = null;
    } else if(String.CASE_INSENSITIVE_ORDER.compare(node1, node2) > 0) {
      this.id = this.node1 + ":" + this.node2;
    } else {
      this.id = this.node2 + ":" + this.node1;
    }
  }

  public Edge(String node1, String node2, int weight) {
    this(node1,node2);
    this.weight = weight;
  }
  
  @Override
  public int hashCode() {
    if (this.id == null) {
      return 0;
    } else {
      return this.id.hashCode();
    }
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == null || !(obj instanceof Edge)) {
      return false;
    }

    Edge other = (Edge) obj;
    return ((this.id != null && other.id != null && this.id.equals(other.id)) 
        || ((this.node1 == null || other.node1 == null || this.node1.equals(other.node1)) 
         && (this.node2 == null || other.node2 == null || this.node2.equals(other.node2))));
  }

  @Override
  public String toString() {
//    StringBuffer ret = new StringBuffer("[");
//    ret.append(this.id);
//    ret.append(",").append(weight);
//    ret.append("]");
//    return ret.toString();
    return new StringBuffer().append(weight).append(" s: ").append(surveyed).toString();

  }
  
  
  public String getName(){
    StringBuffer ret = new StringBuffer(" [");
    ret.append(node1);
    ret.append(" <").append(weight);
    ret.append("> ").append(node2);
    ret.append("] ");
    return ret.toString();
  }

}
