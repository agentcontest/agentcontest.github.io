package de.tub.mac11.states;

import java.util.LinkedList;
import java.util.Map.Entry;

import de.tub.mac11.bean.DecisionBean;
import de.tub.mac11.connection.MessageConstants;
import de.tub.mac11.ontology.Bot;
import de.tub.mac11.ontology.InfoMsg;
import de.tub.mac11.ontology.Intention;
import de.tub.mac11.ontology.Vertex;
import de.tub.mac11.ontology.World;
import edu.uci.ics.jung.algorithms.shortestpath.DijkstraDistance;

public class Disabled extends State {

	Vertex myPosition = null;
	LinkedList<Bot> repairers = new LinkedList<Bot>();
	
	public Disabled(World world, DecisionBean db) {
		super(world, db);
	}

	@Override
	public Intention execute() {
		
		myPosition = getWorld().getAgentPosition(getWorld().getSelf());
		repairers.clear();
		repairers = getRepairers();
		
		// repair agents on the same vertex if self is REPAIRER
		
		if (getWorld().getSelf().role.equals(Bot.REPAIRER)) {
			
			for (Entry<String, Bot> agent : getWorld().getTeam().entrySet()) {
				
				if (!agent.getValue().name.equals(getWorld().getSelf().name) 
						&& !agent.getValue().isAlive()
						&& agent.getValue().position.equals(myPosition.name)) {
					
					return getDecisionBean().repair.execute(); 
				}
			}
		}
		
		// check if some repairer is standing on the same vertex
		
		for (Bot repairer : repairers) {
			if (myPosition.name.equals(repairer.getPosition())) {
				return new Intention(MessageConstants.ACTION_RECHARGE, null); 
			}
		}
		
		// check if some repairer is in neighborhood
		
		// repairer goes only to disabled agents in game field
		if (getWorld().isInGameField(myPosition)) {
			
			LinkedList<Vertex> neighbors = getWorld().getNeighborNodes(myPosition);
			for (Bot repairer : repairers) {
				
				// is repairer neighbor?
				if (neighbors.contains(getWorld().getAgentPosition(repairer))) {
					
					// go to repairer if there are some disabled agents on his position
					if (numDisabledAgents(getWorld().getAgentPosition(repairer)) > 0) {	
						
						return new Intention(MessageConstants.ACTION_GOTO, getWorld().getAgentPosition(repairer).name);
					}	
					
					// wait for repairer if he is alive
					if (repairer.isAlive()) {
						
						return new Intention(MessageConstants.ACTION_RECHARGE, null);
					}
						
					// if both repairers are disabled, the one with lower rank have to wait
					if (getWorld().getSelf().role.equals(Bot.REPAIRER)
							&& getWorld().getSelf().getRank() < repairer.getRank()) {
						
						return new Intention(MessageConstants.ACTION_RECHARGE, null);
					}
					
					// repairer is disabled, self is not repairer -> go to repairer
					return new Intention(MessageConstants.ACTION_GOTO, getWorld().getAgentPosition(repairer).name);
				}
			}
		}
		
		// go to nearest repairer
		
		String nextVertexToGo = null;
		Bot nearestRepairer = getNearestRepairer();
		Vertex nearestRepairerPosition = getWorld().getAgentPosition(nearestRepairer);
		nextVertexToGo = getPathNextVertex(nearestRepairerPosition);
		
		if (nextVertexToGo != null) {
			return new Intention(MessageConstants.ACTION_GOTO, nextVertexToGo);
		}
		
		// go to game field if there is a path
		
		nextVertexToGo = getPathNextVertex(getWorld().getGameFieldCenter());
		
		if (nextVertexToGo != null) {
			return new Intention(MessageConstants.ACTION_GOTO, nextVertexToGo);		
			
		// there is no path, explore the world
		} else {
			
			LinkedList<Vertex> neighborVertices = getWorld().getNeighborNodes(getWorld().getMyPosition());			
			return new Intention(MessageConstants.ACTION_GOTO, neighborVertices.getLast().name);			
		}
		
	}

	private int numDisabledAgents(Vertex vertex) {
		
		int disabledAgents = 0;
		
		for (Entry<String, Bot> agent : getWorld().getTeam().entrySet()) {
			if (!agent.getValue().isAlive() && vertex.name.equals(agent.getValue().position)) {
				disabledAgents++;
			}
		}
		
		return disabledAgents;
	}

	private Bot getNearestRepairer() {
		Bot nearestRepairer = null;
		int nearestRepairerDistance = 10000;
		for (Bot repairer : repairers) {
			Vertex repairerPosition = getWorld().getAgentPosition(repairer);
			int repairerDistance = getWorld().getDistanceWeighted(myPosition, repairerPosition);
			if (repairerDistance < nearestRepairerDistance) {
				nearestRepairer = repairer;
				nearestRepairerDistance = repairerDistance;
			}
		}
		
		return nearestRepairer;
	}


	/**
	 * Returns a list of repairers. If self is repairer, returns the second repairer only.
	 * 
	 */
	private LinkedList<Bot> getRepairers() {
		
		for (Entry<String, Bot> agent : getWorld().team.entrySet()) {
			if (agent.getValue().role != null) {
				if (agent.getValue().role.equals(Bot.REPAIRER) 
						&& !agent.getValue().name.equals(getWorld().getSelf().name)) {
					repairers.add(agent.getValue());
				}
			}
		}
		
		return repairers;
	}
	
	public boolean isTrue() {
		return (getWorld().getSelf().health == 0);
	}

	@Override
	protected void handleInfoMsg(InfoMsg infoMsg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean rechargeNeeded() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	protected Path getPathfinding() {
		return Path.NORMAL;
	}


}