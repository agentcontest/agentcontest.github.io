package de.tub.mac11.states;

import java.util.LinkedList;
import java.util.Map.Entry;

import de.tub.mac11.bean.DecisionBean;
import de.tub.mac11.connection.MessageConstants;
import de.tub.mac11.ontology.Bot;
import de.tub.mac11.ontology.InfoMsg;
import de.tub.mac11.ontology.Intention;
import de.tub.mac11.ontology.Vertex;
import de.tub.mac11.ontology.World;

public class Inspect extends State {
	
	private Bot secondInspector = null;
	private LinkedList<Bot> enemies = new LinkedList<Bot>();

	public Inspect(World world, DecisionBean db) {
		super(world, db);
	}

	@Override
	public Intention execute() {
		
		Intention intention = null;
		
		// get the nearest enemy
		
		Bot nearestEnemy = null;
		Vertex nearestEnemyPosition = null;
		int nearestEnemyDistance = 10000;
		
		for (Bot enemy : enemies) {
			
			// is it the nearest enemy?
			int enemyDistance = getWorld().getDistanceWeighted(getWorld().getMyPosition(), getWorld().getAgentPosition(enemy));
			if (enemyDistance < nearestEnemyDistance) {
				nearestEnemy = enemy;
				nearestEnemyDistance = enemyDistance;
				nearestEnemyPosition = getWorld().getAgentPosition(enemy);
			}
		}
		
		// are there two inspectors in inspect state?
		if (enemies.size() >= 2 
				&& secondInspector.isAlive()
				&& getWorld().isInGameField(getWorld().getAgentPosition(secondInspector))) {
			
			// get second inspector's nearest enemy
			
			Bot siNearestEnemy = null;
			int siNearestEnemyDistance = 10000;
			
			for (Bot enemy : enemies) {
				
				// is it the nearest enemy?
				int enemyDistance = getWorld().getDistanceWeighted(getWorld().getAgentPosition(secondInspector), getWorld().getAgentPosition(enemy));
				if (enemyDistance < siNearestEnemyDistance) {
					siNearestEnemy = enemy;
					siNearestEnemyDistance = enemyDistance;
				}
			}
			
			// have both inspectors the same target?
			if (nearestEnemy.name.equals(siNearestEnemy.name)) {
				
				// get new target?
				if ((nearestEnemyDistance > siNearestEnemyDistance)
						|| (nearestEnemyDistance == siNearestEnemyDistance 
								&& getWorld().getSelf().getRank() < secondInspector.getRank())) {
					
					nearestEnemyDistance = 10000;
					
					for (Bot enemy : enemies) {
						
						// is it the nearest enemy?
						int enemyDistance = getWorld().getDistanceWeighted(getWorld().getMyPosition(), getWorld().getAgentPosition(enemy));
						if (enemyDistance < nearestEnemyDistance && !enemy.name.equals(siNearestEnemy.name)) {
							nearestEnemy = enemy;
							nearestEnemyDistance = enemyDistance;
							nearestEnemyPosition = getWorld().getAgentPosition(enemy);
						}
					}					
				}
			}
			
		}
			
		// check if the enemy agent is standing on the same vertex
		if (getWorld().getMyPosition().name.equals(nearestEnemyPosition.name)) {
			intention = new Intention(MessageConstants.ACTION_INSPECT, null);
			
		// check if the enemy agent is standing on the neighbor vertices
		} else if (isEnemyNeighbor(nearestEnemyPosition)) {
			intention = new Intention(MessageConstants.ACTION_INSPECT, null);
			
		// go to the enemy agent
		} else {
			intention = new Intention(MessageConstants.ACTION_GOTO, getPathNextVertex(nearestEnemyPosition));
		}
		
		return intention;
	}
	
	/**
	 * Returns true if there is an not inspected enemy in game field
	 * 
	 */
	public boolean isTrue() {
		
		enemies.clear();
		secondInspector = getWorld().getSameRoleAgent();
			
		// look for not inspected enemies
		for (Entry<String, Bot> enemy : getWorld().opponents.entrySet()) {
			
			// is enemy agent not inspected and visible?
			if (!enemy.getValue().isInspected() 
					&& enemy.getValue().lastSeen == getWorld().getCurrentStep()) {
				
				Vertex enemyPosition = getWorld().getAgentPosition(enemy.getValue());
				
				// is enemy agent in game field?
				if (getWorld().isInGameField(enemyPosition)) {
					enemies.add(enemy.getValue());
				}
			}
		}
		
		// there are no enemies
		if (enemies.size() == 0) {
			return false;
		}
			
		// is there enough enemies for two inspectors or is the second inspector disabled
		// or is the second inspector not in game field?
		if (enemies.size() >= 2 
				|| !secondInspector.isAlive()
				|| !getWorld().isInGameField(getWorld().getAgentPosition(secondInspector))) {
			return true;
		}
		
		// the nearest inspector inspects if there is only one enemy
		
		Vertex enemyPosition = getWorld().getAgentPosition(enemies.getFirst());
		int myDistanceToEnemy = getWorld().getDistanceWeighted(getWorld().getMyPosition(), enemyPosition);
		int siDistanceToEnemy = getWorld().getDistanceWeighted(getWorld().getAgentPosition(secondInspector), enemyPosition);
		
		// self is closer
		if (myDistanceToEnemy < siDistanceToEnemy) {
			return true;
			
		// second inspector is closer
		} else if (myDistanceToEnemy > siDistanceToEnemy) {
			return false;
			
		// the same distance, rank decides
		} else {
			if (getWorld().getSelf().getRank() > secondInspector.getRank()) {
				return true;
			} else {
				return false;
			}
		}
	}

	private boolean isEnemyNeighbor(Vertex enemyPosition) {
		
		LinkedList<Vertex> neighbors = getWorld().getNeighborNodes(getWorld().getMyPosition());
		if (neighbors.contains(enemyPosition)) {
			return true;
		} else {		
			return false;
		}
	}
	
	@Override
	public void handleInfoMsg(InfoMsg infoMsg) {
		// do nothing		
	}

	@Override
	protected Path getPathfinding() {
		return Path.SEMISAFE;
	}


}
