package de.tub.mac11.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;

public class VisibleEntity implements IFact {
	public String name;
	public String vertex;
	public String team;
	public boolean disabled = false;

	public VisibleEntity(String name, String vertex, String team, boolean disabled) {
		this.name = name;
		this.vertex = vertex;
		this.team = team;
		this.disabled = disabled;
	}
}
