package de.tub.mac11.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;

/**
 * Class for exchange of informations between agents.  
 * 
 */
public class InfoMsg implements IFact {

	private static final long serialVersionUID = -4466563322382536756L;
	
	public static final String MY_INTENTION = "my intention";
	public static final String WANT_TO_CREATE_ZONE = "want to create zone";
	public static final String YOUR_BEST_POSITION = "your best position";
	public static final String ENEMY_SAB_STRENGTH = "enemy saboteur strength";

	public static final String REGISTRATION = "registration";
		
	private String info = null;
	private String sender = null;
	private int step = -1;
	private String param1 = null;
	private String param2 = null;
	private Intention intention = null;

	public InfoMsg(String info, String sender, int step) {
		this.info = info;
		this.sender = sender;
		this.step = step;
	}
	
	public InfoMsg(String info, String sender, int step, String param1) {
		this.info = info;
		this.sender = sender;
		this.step = step;
		this.param1 = param1;
	}
	
	public InfoMsg(String info, String sender, int step, String param1, String param2) {
		this.info = info;
		this.sender = sender;
		this.step = step;
		this.param1 = param1;
		this.param2 = param2;
	}
	
	public InfoMsg(String info, String sender, int step, Intention intention) {
		this.info = info;
		this.sender = sender;
		this.step = step;
		this.intention = intention;
	}
	
	public String getInfo() {
		return info;
	}
	
	public String getSender() {
		return sender;
	}
	
	public int getStep() {
		return step;
	}

	public String getParam1() {
		return param1;
	}
	
	public String getParam2() {
		return param2;
	}
	
	public Intention getIntention() {
		return intention;
	}
	
}
