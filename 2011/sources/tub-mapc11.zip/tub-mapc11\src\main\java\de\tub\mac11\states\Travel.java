package de.tub.mac11.states;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;

import de.tub.mac11.bean.DecisionBean;
import de.tub.mac11.connection.MessageConstants;
import de.tub.mac11.ontology.Bot;
import de.tub.mac11.ontology.Edge;
import de.tub.mac11.ontology.InfoMsg;
import de.tub.mac11.ontology.Intention;
import de.tub.mac11.ontology.Vertex;
import de.tub.mac11.ontology.World;
import de.tub.mac11.util.WeightReader;
import edu.uci.ics.jung.algorithms.shortestpath.DijkstraDistance;
import edu.uci.ics.jung.algorithms.shortestpath.DijkstraShortestPath;

public abstract class Travel extends State {

	private Intention receivedIntention;

	public Travel(World world, DecisionBean db) {
		super(world, db);
	}

	/**
	 * Computes the next Intention for the current step. Checks if the computed
	 * pair of Intention and destination is equal to any other team mate's
	 * higher intention. If so, another higher intention gets computed.
	 */
	@Override
	public synchronized Intention execute() {
		Intention intention = null;
		// inform team members
		// sendInfoMsg(new InfoMsg(this.getClass().toString(), getWorld()
		// .getSelf().name, getWorld().getCurrentStep(),
		// InfoMsg.REGISTRATION));

		waitForInfoMessages(20);
		intention = selectIntention(getRegisteredAgents());

		// save agents who need a destination
		// for (Bot teamMate: getRegisteredAgents()) {
		// int agentRank = Integer.parseInt(teamMate.getName().substring(1));
		// if (agentRank > highestRank) {
		// highestRank = agentRank;
		// }
		// }

		// if agent has the highest rank, he calculates the vertices for every
		// agent who registered itself
		// int myRank = Integer.parseInt(getWorld().getSelf().getName()
		// .substring(1));
		// if (myRank > highestRank) {
		// Vertex destination = null;
		// for (Bot agent : getRegisteredAgents()) {
		// if (agent == getWorld().getSelf()) {
		// destination = computeDestination(getWorld().getVertices()
		// .get(agent.getPosition()));
		// if (destination != null) {
		// if (agent.equals(getWorld().getSelf())) {
		// intention = new Intention(
		// MessageConstants.ACTION_GOTO,
		// destination.name);
		// } else {
		// sendInfoMsg(new InfoMsg(this.getClass().toString(),
		// getWorld().getSelf().getName(), getWorld()
		// .getCurrentStep(),
		// InfoMsg.YOUR_BEST_POSITION,
		// destination.name));
		// }
		// }
		// }
		// }
		// } else {
		// waitForBestPosition(50);
		// if(getReceivedIntention() != null){
		// intention = getReceivedIntention();
		// }
		// }
		setReceivedIntention(null);
		getRegisteredAgents().clear();

		return intention;
	}

	/**
	 * Chooses the kind of action
	 * 
	 * @return
	 */
	protected Intention selectIntention(HashMap<Bot, Integer> agents) {
		Intention intention = new Intention(MessageConstants.ACTION_SKIP, null);
		if(getConditionForPrimaryIntention()){
			intention = primaryIntention();
		}else{
			Vertex destination = computeNewDestination(agents.keySet());
			if (destination != null) {
				if (destination.equals(getWorld().getCurrentPosition())) {
					System.err.println("destination ist currentposition");
					intention = primaryIntention();
				} else {
					String nextVertex = getPathNextVertex(destination);
					if(nextVertex != null){
						intention = new Intention(MessageConstants.ACTION_GOTO,nextVertex);
					}else{
						System.err.println("No path found. Returning skip action.");
					}
				}
			} else {
				System.out.println("No destination found. Returning skip action.");			
			}
		}

		return intention;
	}

	public synchronized void handleInfoMsg(InfoMsg infoMsg) {
		if (getWorld() != null) {
			if (infoMsg.getStep() == getWorld().getCurrentStep()) {
				// is infoMsg from an agent in the same state?
				if (infoMsg.getInfo() != null) {
					if (infoMsg.getInfo().equals(this.getClass().toString())) {
						if (infoMsg.getParam1().equals(InfoMsg.REGISTRATION)) {
							registerAgent(infoMsg.getSender(),
									infoMsg.getStep());
						}
					}
				}
			}
		}
	}

	protected void setReceivedIntention(Intention intention) {
		receivedIntention = intention;
	}

	protected Intention getReceivedIntention() {
		return receivedIntention;

	}

	protected abstract Intention primaryIntention();

	/**
	 * Computes a destination for the agent.
	 * 
	 * @return A {@code LinkedList<Edge>}, which represents this path.
	 */
	protected abstract Vertex computeNewDestination(Collection<Bot> agents);
	
	protected abstract boolean getConditionForPrimaryIntention();

	protected boolean getPreferredAgent(Vertex vertex, Collection<Bot> agents) {
		DijkstraDistance<Vertex, Edge> distanceCalculator = new DijkstraDistance<Vertex, Edge>(
				getWorld().getAvaliableEdgesGraph());
		Number oDistance = distanceCalculator.getDistance(getWorld()
				.getCurrentPosition(), vertex);
		if (oDistance == null) { // in case, there is no path
			oDistance = 10000;
		}
		int ownDistance = oDistance.intValue();
		int ownRank = Integer.parseInt(getWorld().getSelf().getName()
				.substring(3));
		for (Bot agent : agents) {
			if (agent == null) {
				System.err
						.println("WARNING: found null-agent in Travel.getPreferredAgent: "
								+ agents);
				continue;
			}

			Number aDistance = distanceCalculator.getDistance(getWorld()
					.getAgentPosition(agent), vertex);
			if (aDistance == null) { // in case, there is no path
				aDistance = 10000;
			}
			int agentDistance = aDistance.intValue();
			if (agentDistance < ownDistance) {
				return true;
			} else if (agentDistance == ownDistance) {
				int agentRank = Integer.parseInt(agent.getName().substring(3));
				if (agentRank > ownRank) {
					return true;
				}
			}
		}
		return false;
	}
	
	
}