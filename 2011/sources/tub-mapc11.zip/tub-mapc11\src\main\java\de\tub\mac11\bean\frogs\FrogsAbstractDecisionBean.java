package de.tub.mac11.bean.frogs;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.w3c.dom.Document;

import de.dailab.jiactng.agentcore.action.AbstractMethodExposingBean;
import de.dailab.jiactng.agentcore.action.Action;
import de.dailab.jiactng.agentcore.comm.ICommunicationAddress;
import de.dailab.jiactng.agentcore.comm.IGroupAddress;
import de.dailab.jiactng.agentcore.comm.message.IJiacMessage;
import de.dailab.jiactng.agentcore.comm.message.JiacMessage;
import de.tub.mac11.bean.frogs.messages.InformContent;
import de.tub.mac11.connection.ActionFactory;
import de.tub.mac11.connection.MessageConstants;
import de.tub.mac11.ontology.Bot;
import de.tub.mac11.ontology.Edge;
import de.tub.mac11.ontology.Intention;
import de.tub.mac11.ontology.Vertex;
import de.tub.mac11.ontology.World;
import de.tub.mac11.util.DistanceEntry;
import de.tub.mac11.util.DistanceMatrix;

public abstract class FrogsAbstractDecisionBean extends AbstractMethodExposingBean {

  protected World                        world;

  protected DistanceMatrix               matrix;

  protected IGroupAddress                teamChannel;
  protected FrogsPerceptionBean          perceptionBean;
  protected FrogsServerCommunicationBean serverCommunicationBean;
  protected Action                       sendAction;

  protected Vertex                       currentGoal     = null;
  protected Vertex                       currentPosition = null;

  protected int                          allowBatteryBuy = 0;

  private int                            totalActions    = 0;
  private int                            surveyActions   = 0;
  private int                            probeActions    = 0;
  private int                            rechargeActions = 0;
  private int                            gotoActions     = 0;
  private int                            inspectActions  = 0;
  private int                            attackActions   = 0;
  private int                            repairActions   = 0;
  private int                            buyActions      = 0;
  private int                            skipActions     = 0;

  public void setWorld(World world) {
    this.world = world;
  }

  @Override
  public void doStart() {
    // find perceptionbean
    this.perceptionBean = thisAgent.findAgentBean(FrogsPerceptionBean.class);
    this.teamChannel = perceptionBean.teamChannel;

    // find servicecommbean
    this.serverCommunicationBean = thisAgent.findAgentBean(FrogsServerCommunicationBean.class);

    // retrieving needed actions from own CommunicationBean
    sendAction = memory.read(new Action(thisAgent.getCommunication().ACTION_SEND, null, new Class[] {
        IJiacMessage.class, ICommunicationAddress.class }, null));
    if (sendAction == null)
      throw new RuntimeException("Could not find Communication...1");
  }

  /**
   * TODO: select an appropriate action and send it back to the server
   */
  public abstract void decide();

  protected void submitAction(Intention intention) {
    if (intention == null) {
      intention = new Intention(MessageConstants.ACTION_SKIP, null);
    }

    sendActionResponse(intention);
  }

  protected Vertex getClosestVertexFromList(Vertex origin, ArrayList<Vertex> destinations) {
    Vertex ret = null;

    int bestDistance = Integer.MAX_VALUE;
    for (int i = 0; i < destinations.size(); i++) {
      Vertex newDestination = destinations.get(i);

      // todo also calculate number of steps
      DistanceEntry entry = matrix.getEntry(origin, newDestination);

      if (entry == null) {
        // no path known
        continue;
      }

      int newLength = entry.totalCost;
      if ((0 < newLength) && (newLength < bestDistance)) {
        ret = newDestination;
        bestDistance = newLength;
      }
    }

    return ret;
  }

  //
  // -- simple intention methods --
  //
  protected Intention checkRecharge() {
    Intention ret = null;
    if (world.self.disabled || (world.self.health == 0)) {
      if (world.self.energy < world.self.maxEnergyDisabled) {
        ret = new Intention(MessageConstants.ACTION_RECHARGE, null);
      }

    } else if (world.self.energy < world.self.maxEnergy) {
      ret = new Intention(MessageConstants.ACTION_RECHARGE, null);
    }
    return ret;
  }

  protected Intention checkSurvey() {
    Intention ret = null;

    for (Edge e : world.edges.values()) {
      if (currentPosition.name.equals(e.node1) || currentPosition.name.equals(e.node2)) {
        if (!e.surveyed) {
          ret = new Intention(MessageConstants.ACTION_SURVEY, null);
        }
      }
    }
    return ret;
  }

  protected Intention checkNeedHelp(StringBuffer stateString) {
    Intention ret = null;

    int distance = Integer.MAX_VALUE;
    Bot repairer = null;
    for (Bot b : world.team.values()) {
      if(world.self.name.equals(b.name)) {
        continue;
      }
      
      if (b.name.endsWith("3") || b.name.endsWith("4")) {
        DistanceEntry entry = matrix.getEntry(currentPosition, world.vertices.get(b.position));
        if ((entry != null) && (entry.path != null) && entry.path.size() > 0) {
          if (entry.totalCost < distance) {
            repairer = b;
          }
        }
      }
    }
    
    if(repairer!=null) {
      printValue("searching Help", repairer.name, stateString);
      DistanceEntry entry = matrix.getEntry(currentPosition, world.vertices.get(repairer.position));
      ret = new Intention(MessageConstants.ACTION_GOTO, entry.path.get(1));
    } else {
      System.err.println(" COULD NOT FIND REPAIRER!!!");
    }

    return ret;
  }

  protected Intention checkEvade(StringBuffer stateString) {
    Intention ret = null;

    ArrayList<Vertex> avoidList = new ArrayList<Vertex>();
    for (Edge e : getEdges(currentPosition)) {
      Vertex otherNode = null;
      if (currentPosition.name.equals(e.node1)) {
        otherNode = world.vertices.get(e.node2);
      } else {
        otherNode = world.vertices.get(e.node1);
      }

      if (getEnemyBotsOnVertex(otherNode, true).size() > 0) {
        avoidList.add(otherNode);
      }
    }

    if (avoidList.size() > 0) {
      ArrayList<Vertex> optionList = getNeighbors(currentPosition);
      for (Vertex v : avoidList) {
        optionList.remove(v);
      }

      if (optionList.size() > 0) {
        Vertex select = null;
        int distance = Integer.MAX_VALUE;
        for (Vertex option : optionList) {
          DistanceEntry entry = matrix.getEntry(currentPosition, option);
          if ((entry != null) && (entry.path != null) && (entry.path.size() > 0)) {
            if (entry.totalCost < distance) {
              select = option;
              distance = entry.totalCost;
            }
          }
        }
        if (select != null) {
          printValue("Evading", null, stateString);
          ret = new Intention(MessageConstants.ACTION_GOTO, select.name);
        }
      }
    }

    return ret;
  }

  protected Intention checkEnergyBuy() {
    Intention ret = null;
    if ((world.self.maxEnergy < allowBatteryBuy) && (this.world.money > 10)) {
      ret = new Intention(MessageConstants.ACTION_BUY, "battery");
    }
    return ret;
  }

  /**
   * if we have no intention yet and the matrix is null, no proper path is /*
   * possible, so we just go to the next node.
   * 
   * @return
   */
  protected Intention checkIfMatrixIsKnown() {
    Intention ret = null;

    if (matrix == null) {
      System.err.println("Matrix is still null - trying direct neighbors...");
      List<Vertex> nodes = getNeighbors(currentPosition);
      if ((nodes.size() > 0) && (nodes.get(0) != null)) {
        ret = new Intention(MessageConstants.ACTION_GOTO, nodes.get(0).name);
      }
    }

    return ret;
  }

  protected Intention checkOccupy2(StringBuffer stateString) {
    Intention ret = null;
    if (currentGoal == null) {
      currentGoal = currentPosition;
    }
    printValue("current value", currentGoal.value, stateString);

    // retrieve info from other agents
    InformContent template = new InformContent(InformContent.TYPE.OCCUPY_VERTEX, null, null);
    Set<InformContent> occupySet = memory.readAll(template);

    // find all nodes within 2 steps of teams occupy-targets
    HashSet<Vertex> optVertices = new HashSet<Vertex>();
    for (InformContent content : occupySet) {
      if (!isMyBoss(content.username)) {
        continue;
      }

      Vertex target = world.vertices.get(content.target);
      ArrayList<Vertex> targetNeighbors = matrix.getAllVerticesWithinSteps(target, 2);
      optVertices.addAll(targetNeighbors);
    }

    // remove actual occupy targets from set (they are taken care of)
    for (InformContent content : occupySet) {
      // keep my own...
      if (world.username.equals(content.username)) {
        continue;
      }

      optVertices.remove(world.vertices.get(content.target));

      if (currentGoal == null) {
        System.err.println("WARNING! currentGoal: " + currentGoal + " currentPosition: " + currentPosition);
      }

      // change current goal, if it is occupied by another agent
      if (currentGoal.name.equals(content.target)
          && (String.CASE_INSENSITIVE_ORDER.compare(content.username, world.username) < 0)) {
        currentGoal = optVertices.iterator().next();
      }
    }

    // find node with highest value...
    for (Vertex v : optVertices) {
      if ((v == null) || (currentGoal == null)) {
        continue;
      }
      if (v.value > currentGoal.value) {
        currentGoal = v;
      } else if (!optVertices.contains(currentGoal)) {
        currentGoal = v;
      }
    }

    // goal has changed
    if (!currentGoal.equals(currentPosition)) {
      printValue("new goal", currentGoal.name, stateString);
      printValue("new value", currentGoal.value, stateString);
      DistanceEntry entry = matrix.getEntry(currentPosition, currentGoal);

      // check if path exists...
      if ((entry == null) || (entry.path.size() < 2)) {
        System.err.println("WARNING! Entry(" + currentPosition.name + "," + currentGoal.name + "):" + entry.path);
        ret = null;
      } else {
        ret = new Intention(MessageConstants.ACTION_GOTO, entry.path.get(1));
      }

    } else {
      // old goal
      printValue("reached occupy", currentPosition.name, stateString);
    }

    if (currentGoal != null) {
      // inform other agents
      sendOccupyGoal(currentGoal);
    }

    return ret;
  }

  protected Intention checkOccupy(StringBuffer stateString) {
    Intention ret = null;
    if (currentGoal != null) {
      printValue("current value", currentGoal.value, stateString);
    }

    // TODO: check if goal is reached

    // retrieve info from other agents
    InformContent template = new InformContent(InformContent.TYPE.OCCUPY_VERTEX, null, null);
    Set<InformContent> occupySet = memory.readAll(template);

    // find all nodes within 2 steps of teams occupy-targets
    HashSet<Vertex> optVertices = new HashSet<Vertex>();
    for (InformContent content : occupySet) {
      if (!isMyBoss(content.username)) {
        continue;
      }

      // reset current goal, if it is occupied by another agent
      if ((currentGoal != null) && currentGoal.name.equals(content.target)) {
        currentGoal = null;
      }

      Vertex target = world.vertices.get(content.target);
      ArrayList<Vertex> targetNeighbors = matrix.getAllVerticesWithinSteps(target, 2);
      optVertices.addAll(targetNeighbors);
    }

    // remove actual occupy targets from set (they are taken care of)
    for (InformContent content : occupySet) {
      // keep my own...
      if (world.username.equals(content.username)) {
        continue;
      }

      optVertices.remove(world.vertices.get(content.target));
    }

    // find node with highest value...
    int currentValue = Integer.MIN_VALUE;
    for (Vertex v : optVertices) {
      if (v == null) {
        System.err.println("!!! WE HAVE A NULL NODE...: " + optVertices);
        continue;
      }

      // check if path exists
      DistanceEntry entry = matrix.getEntry(currentPosition, v);
      if ((entry == null) || ((entry.path.size() < 2) && !currentPosition.name.equals(v.name))) {
        continue;
      }

      if (v.value > currentValue) {
        currentGoal = v;
        currentValue = v.value;
      }
    }

    if (currentGoal == null) {
      printValue("no goal found, using: ", currentPosition, stateString);
      currentGoal = currentPosition;
    }

    // goal has changed
    if (!currentGoal.equals(currentPosition)) {
      printValue("new goal", currentGoal.name, stateString);
      printValue("new value", currentGoal.value, stateString);
      DistanceEntry entry = matrix.getEntry(currentPosition, currentGoal);
      if (entry.path.size() > 1) {
        ret = new Intention(MessageConstants.ACTION_GOTO, entry.path.get(1));
      }

    } else {
      // old goal
      printValue("reached occupy", currentPosition.name, stateString);
    }

    if (currentGoal != null) {
      // inform other agents
      sendOccupyGoal(currentGoal);
    }

    return ret;
  }

  /**
   * Sends the intention of this agent to all other agents in the team
   * 
   * @param intention
   *          the intention to send
   */
  private void sendOccupyGoal(Vertex v) {
    // System.err.println(" --- sending message");
    JiacMessage msg = new JiacMessage(new InformContent(InformContent.TYPE.OCCUPY_VERTEX, world.username, v.name));
    Serializable[] params = new Serializable[2];
    params[0] = msg;
    params[1] = this.teamChannel;
    invoke(sendAction, params);
  }

  //
  // -- utility methods start here ---
  //
  protected ArrayList<Edge> getEdges(Vertex v) {
    ArrayList<Edge> ret = new ArrayList<Edge>();
    for (Edge e : world.edges.values()) {
      if (v.name.equals(e.node1) || v.name.equals(e.node2)) {
        ret.add(e);
      }
    }
    return ret;
  }

  protected ArrayList<Vertex> getNeighbors(Vertex v) {
    ArrayList<Vertex> ret = new ArrayList<Vertex>();
    for (Edge e : getEdges(v)) {
      if (v.name.equals(e.node1)) {
        ret.add(world.vertices.get(e.node2));
      } else {
        ret.add(world.vertices.get(e.node1));
      }
    }
    return ret;
  }

  protected ArrayList<Bot> getEnemyBotsOnVertex(Vertex v, boolean current) {
    ArrayList<Bot> ret = new ArrayList<Bot>();
    for (Bot b : world.opponents.values()) {
      if (current && (b.lastSeen != world.currentStep)) {
        continue;
      }
      if ((v.name.equals(b.position))) {
        ret.add(b);
      }
    }
    return ret;
  }

  protected ArrayList<Bot> getFriendlyBotsOnVertex(Vertex v) {
    ArrayList<Bot> ret = new ArrayList<Bot>();
    for (Bot b : world.team.values()) {
      if ((b.lastSeen == world.currentStep) && (v.name.equals(b.position))) {
        ret.add(b);
      }
    }
    return ret;
  }

  protected StringBuffer initStateString(String role) {
    StringBuffer ret = new StringBuffer(role).append(" (").append(world.self).append("): ");
    ret.append("h: ").append(world.self.health).append("(").append(world.self.maxHealth).append(") ");
    ret.append("e: ").append(world.self.energy).append("(").append(world.self.maxEnergy).append(") ");
    // ret.append("Vertices: ").append(world.vertices.values().size()).append(" Edges: ").append(world.edges.values().size()).append(" ");
    return ret;
  }

  protected void printValue(String name, Object value, StringBuffer buffer) {
    buffer.append(name).append("(").append(value).append("), ");
  }

  protected void produceStatistics(Intention intention, StringBuffer stateString) {
    if (intention == null) {
      skipActions++;
    } else if (MessageConstants.ACTION_SKIP.equals(intention.action)) {
      skipActions++;
    } else if (MessageConstants.ACTION_SURVEY.equals(intention.action)) {
      surveyActions++;
    } else if (MessageConstants.ACTION_PROBE.equals(intention.action)) {
      probeActions++;
    } else if (MessageConstants.ACTION_RECHARGE.equals(intention.action)) {
      rechargeActions++;
    } else if (MessageConstants.ACTION_GOTO.equals(intention.action)) {
      gotoActions++;
    } else if (MessageConstants.ACTION_INSPECT.equals(intention.action)) {
      inspectActions++;
    } else if (MessageConstants.ACTION_ATTACK.equals(intention.action)) {
      attackActions++;
    } else if (MessageConstants.ACTION_REPAIR.equals(intention.action)) {
      repairActions++;
    } else if (MessageConstants.ACTION_BUY.equals(intention.action)) {
      buyActions++;
    } else {
      System.err.println("unknown intention at statistics... " + intention.action);
      skipActions++;
    }
    totalActions++;

    StringBuffer stats = new StringBuffer();
    stats.append(surveyActions).append("/");
    stats.append(probeActions).append("/");
    stats.append(rechargeActions).append("/");
    stats.append(gotoActions).append("/");
    stats.append(inspectActions).append("/");
    stats.append(attackActions).append("/");
    stats.append(repairActions).append("/");
    stats.append(buyActions).append("/");
    stats.append(skipActions).append("/");
    stats.append(totalActions);

    printValue("actions", stats.toString(), stateString);

  }

  protected boolean isMyBoss(String username) {
    return (String.CASE_INSENSITIVE_ORDER.compare(world.username, username) < 0);
  }

  /**
   * Send action and optional parameter to the contest server.
   * 
   * @param intention
   *          the intention to send
   */
  protected void sendActionResponse(Intention intention) {
    Document response = ActionFactory.getAction(intention.action, intention.param, world.id);
    serverCommunicationBean.sendActionResponse(response);
  }

  //
  // -- subgraph calculation (experimental) --
  //
  protected HashSet<Vertex> calculateBorderSet(HashSet<Vertex> currentSet) {
    HashSet<Vertex> borderSet = new HashSet<Vertex>();
    for (Vertex v : currentSet) {
      for (Vertex neighbor : getNeighbors(v)) {
        if (!currentSet.contains(neighbor)) {
          // add all nodes with external neighbors to border
          borderSet.add(v);
        }
      }
    }
    return borderSet;
  }

  private HashSet<Vertex> expandSubgraphAtOrigin(Vertex origin, HashSet<Vertex> currentSet) {
    HashSet<Vertex> expandedSet = new HashSet<Vertex>();
    expandedSet.addAll(currentSet);
    expandedSet.addAll(getNeighbors(origin));
    return expandedSet;
  }

  protected int calculateSubgraphValue(HashSet<Vertex> currentSet) {
    int ret = 0;
    for (Vertex v : currentSet) {
      ret += v.value;
    }
    return ret;
  }

  protected boolean containsEnemyBots(HashSet<Vertex> currentSet) {
    boolean ret = false;
    for (Vertex v : currentSet) {
      if (getEnemyBotsOnVertex(v, false).size() > 0) {
        ret = true;
        break;
      }
    }
    return ret;
  }

  protected HashSet<Vertex> calculateSubgraph(int numberOfBots) {
    HashSet<Vertex> bestSet = new HashSet<Vertex>();
    int bestValue = 0;

    for (Vertex origin : world.vertices.values()) {
      // create level-1 graph from node
      HashSet<Vertex> currentSet = new HashSet<Vertex>();
      currentSet.add(origin);
      currentSet = expandSubgraphAtOrigin(origin, currentSet);

      // calculate border length and check if we have enough bots
      HashSet<Vertex> borderSet = calculateBorderSet(currentSet);
      if (borderSet.size() > numberOfBots) {
        continue;
      }

      // check for enemy bots
      if (containsEnemyBots(currentSet)) {
        continue;
      }

      // calculate value and remember best set
      int currentValue = calculateSubgraphValue(currentSet);
      if (currentValue > bestValue) {
        bestSet = currentSet;
        bestValue = currentValue;
      }

      boolean flag = true;
      while (flag) {
        flag = false;
        for (Vertex v : calculateBorderSet(bestSet)) {
          HashSet<Vertex> tempSet = expandSubgraphAtOrigin(v, bestSet);
          HashSet<Vertex> tempBorder = calculateBorderSet(tempSet);

          // check if border is too long
          if (tempBorder.size() > numberOfBots) {
            continue;
          }

          // check for enemy bots
          if (containsEnemyBots(tempSet)) {
            continue;
          }

          int tempValue = calculateSubgraphValue(tempSet);
          if (tempValue > bestValue) {
            bestSet = tempSet;
            bestValue = tempValue;
            flag = true;
            break;
          }
        }
      }

    }

    return bestSet;
  }

  //
  // -- getters/setters
  //
  public int getAllowBatteryBuy() {
    return allowBatteryBuy;
  }

  public void setAllowBatteryBuy(int allowEnergyBuy) {
    this.allowBatteryBuy = allowEnergyBuy;
  }

}
