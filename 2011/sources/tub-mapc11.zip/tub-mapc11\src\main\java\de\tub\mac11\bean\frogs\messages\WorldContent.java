package de.tub.mac11.bean.frogs.messages;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac11.ontology.World;

public class WorldContent implements IFact {

  public World world = null;

  public WorldContent(World world) {
    this.world = world;
  }

}
