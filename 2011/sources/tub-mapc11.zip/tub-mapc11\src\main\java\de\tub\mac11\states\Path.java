package de.tub.mac11.states;

public enum Path {
	SAFE, SEMISAFE, NORMAL;
}
