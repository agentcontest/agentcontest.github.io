package de.tub.mac11.ontology;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;

/**
 * This class holds information about zone, i.e. a connected part  
 * of the graph that belongs to a team.
 */
public class Zone {

	private int size;
	private int score;
	private LinkedList<Bot> agents;
	private LinkedList<Vertex> vertices;

	public Zone(
			LinkedList<Bot> agents,
			LinkedList<Vertex> vertices,
			int size, int score) {
		this.size = size;
		this.score = score;
		this.agents = agents;
		this.vertices = vertices;
	}
	
	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public LinkedList<Bot> getAgents() {
		return agents;
	}

	public void setAgents(LinkedList<Bot> agents) {
		this.agents = agents;
	}

	public LinkedList<Vertex> getVertices() {
		return vertices;
	}

	public void setVertices(LinkedList<Vertex> vertices) {
		this.vertices = vertices;
	}

}
