package de.tub.mac11.bean.frogs;

import java.io.Serializable;

import de.dailab.jiactng.agentcore.comm.message.JiacMessage;
import de.tub.mac11.bean.frogs.messages.MatrixContent;
import de.tub.mac11.ontology.Edge;
import de.tub.mac11.ontology.Vertex;
import de.tub.mac11.util.DistanceMatrix;

public class FrogsPathfindingBean extends FrogsAbstractDecisionBean {

  private int maxEdgeCost = 9;

  @Override
  public void decide() {

  }

  @Override
  public void execute() {

    if (world == null) {
      return;
    }

    // check if we need to recalculate (vertices)
    boolean recalc = false;
    for (Vertex v : this.world.vertices.values()) {
      if (v.updated) {
        recalc = true;
        break;
      }
    }

    // check if we need to recalculate (edges)
    if (!recalc) {
      for (Edge e : this.world.edges.values()) {
        if (e.updated) {
          recalc = true;
          break;
        }
      }
    }

    if (recalc) {
      long startTime, endTime;
      startTime = System.currentTimeMillis();
      matrix = new DistanceMatrix(world.numVertices, world.vertices.values(), world.edges.values(), maxEdgeCost);

      endTime = System.currentTimeMillis();
      System.err.println("Pathfinder matrixTime: " + (endTime - startTime));
      sendNewDistanceMatrx(matrix);

    } else {
      System.err.println("Pathfinder no recalc.");
    }
  }

  /**
   * Sends the intention of this agent to all other agents in the team
   * 
   * @param intention
   *          the intention to send
   */
  private void sendNewDistanceMatrx(DistanceMatrix matrix) {
    // System.err.println(" --- sending message");
    JiacMessage msg = new JiacMessage(new MatrixContent(matrix));
    Serializable[] params = new Serializable[2];
    params[0] = msg;
    params[1] = this.teamChannel;
    invoke(sendAction, params);

  }

  public int getMaxEdgeCost() {
    return maxEdgeCost;
  }

  public void setMaxEdgeCost(int maxEdgeCost) {
    this.maxEdgeCost = maxEdgeCost;
  }

}
