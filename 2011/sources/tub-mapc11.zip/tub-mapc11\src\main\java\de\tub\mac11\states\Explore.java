package de.tub.mac11.states;

import java.util.LinkedList;
import java.util.Map.Entry;
import de.tub.mac11.bean.DecisionBean;
import de.tub.mac11.connection.MessageConstants;
import de.tub.mac11.ontology.Bot;
import de.tub.mac11.ontology.InfoMsg;
import de.tub.mac11.ontology.Intention;
import de.tub.mac11.ontology.Vertex;
import de.tub.mac11.ontology.World;

public class Explore extends State {
	
	Vertex myPosition = null;
	Vertex sePosition = null;
	LinkedList<Vertex> neighborVertices = null;
	LinkedList<Vertex> toProbe = new LinkedList<Vertex>();
	
	
	Bot secondExplorer = null;
	
	public Explore(World world, DecisionBean db) {
		super(world, db);
		// TODO Auto-generated constructor stub
	}

	@Override
	public Intention execute() {
		
		secondExplorer = getWorld().getSameRoleAgent();
		
		myPosition = getWorld().getVertices().get(getWorld().getSelf().getPosition());
		sePosition = getWorld().getVertices().get(secondExplorer.getPosition());
		neighborVertices = getWorld().getNeighborNodes(myPosition);
		toProbe.clear();
		
		// explore agent's current position
		if (!(secondExplorer.isAlive() 
				&& sePosition.name.equals(myPosition.name) 
				&& getWorld().getSelf().getRank() < secondExplorer.getRank())) {
			
			if (!myPosition.probed) {
				return new Intention(MessageConstants.ACTION_PROBE, null);
				
			}
			
			if (!getWorld().isNeighborEdgesSurveyed(myPosition)) {			
				return new Intention(MessageConstants.ACTION_SURVEY, null);
			}
		}
		
		Vertex seTarget = null;
		
		// define second explorer's target if lower rank
		if (secondExplorer.isAlive()
				&& getWorld().getSelf().getRank() < secondExplorer.getRank()) {
			
			seTarget = defineTarget(secondExplorer, null);
		}
		
		// define target
		Vertex target = defineTarget(getWorld().getSelf(), seTarget);
		
		String nextVertexToGo = getPathNextVertex(target);
		return new Intention(MessageConstants.ACTION_GOTO, nextVertexToGo);		
	}

	private Vertex defineTarget(Bot agent, Vertex forbidden) {
		
		Vertex agentPosition = getWorld().getAgentPosition(agent);
		
		
		// FIRST : explore game field center
		
		if (!getWorld().isProbedCenter()) {
			
			LinkedList<Vertex> toProbe = new LinkedList<Vertex>();
			LinkedList<Vertex> center = getWorld().getNeighborNodes(getWorld().getGameFieldCenter());
			
			for (Vertex node : center) {
				if (!node.probed) {
					toProbe.add(node);
				}
			}	
				
			filterForbidden(toProbe, forbidden);
			
			if (!toProbe.isEmpty()) {
				
				LinkedList<Vertex> neighborVertices = getWorld().getNeighborNodes(agentPosition); 
				Vertex target = toProbe.getFirst();
				
				for (Vertex node : toProbe) {
					if (neighborVertices.contains(node)) {
						target = node;
						break;
					}
				}
				
				return target;
			}
		}
			
		// SECOND : explore game field
		
		if (!getWorld().isProbedGamefield()) {
			
			// neighbor nodes
			
			LinkedList<Vertex> neighborVerticesGameField = getWorld().getNeighborNodesGamefield(agentPosition);
			filterForbidden(neighborVerticesGameField, forbidden);
			
			for (Vertex node : neighborVerticesGameField) {
				if (!node.probed) {
					return node;
				}
			}
				
			// distance 3 neighbor nodes 
				
			LinkedList<Vertex> neighborVerticesGameField3 = getWorld().getKNeighborNodesGamefield(agentPosition, 3);
			filterForbidden(neighborVerticesGameField3, forbidden);
			
			for (Vertex node : neighborVerticesGameField3) {
				if (!node.probed) {
					return node;
				}
			}
			
			// all game field nodes 
			
			for (Entry<String, Vertex> node : getWorld().getVertices().entrySet()) {
				if (!node.getValue().probed) {
					return node.getValue();
				}
			}			
		}
		
		// THIRD : explore extended game field
		
		// neighbor nodes
		
		LinkedList<Vertex> neighborVerticesGameFieldExtended = getWorld().getNeighborNodesGamefieldExtended(agentPosition);
		filterForbidden(neighborVerticesGameFieldExtended, forbidden);
		
		for (Vertex node : neighborVerticesGameFieldExtended) {
			if (!node.probed) {
				return node;
			}
		}
			
		// distance 3 neighbor nodes 
			
		LinkedList<Vertex> neighborVerticesGameFieldExtended3 = getWorld().getKNeighborNodesGamefieldExtended(agentPosition, 3);
		filterForbidden(neighborVerticesGameFieldExtended3, forbidden);
		
		for (Vertex node : neighborVerticesGameFieldExtended3) {
			if (!node.probed) {
				return node;
			}
		}
		
		// all game field nodes 
		
		for (Entry<String, Vertex> node : getWorld().getVertices().entrySet()) {
			if (!node.getValue().probed) {
				return node.getValue();
			}
		}	
		
		System.err.println(getWorld().getCurrentStep() + " | could'n find a target for explorer " + agent.name);
		return agentPosition;
		
	}

	private LinkedList<Vertex> filterForbidden(LinkedList<Vertex> vertices, Vertex forbidden) {
		
		if (vertices.isEmpty() || forbidden == null) {
			return vertices;
		}
		
		if (vertices.contains(forbidden)) {
			vertices.remove(forbidden);
		}
		
		return vertices;
	}

	public boolean isTrue() {
		
		if (!getWorld().isProbedGamefield()) {
			return true;
		}
			
		// calculate extended game field
		getWorld().defineGameFieldExtended();
		
		if (!getWorld().isProbedGamefieldExtended()) {
			return true;
		}
		
		return false;
	}

	@Override
	protected void handleInfoMsg(InfoMsg infoMsg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected Path getPathfinding() {
		return Path.SAFE;
	}

}