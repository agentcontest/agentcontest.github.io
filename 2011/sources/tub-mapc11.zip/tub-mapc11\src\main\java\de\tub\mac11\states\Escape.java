package de.tub.mac11.states;

import java.util.LinkedList;
import java.util.Map.Entry;

import de.tub.mac11.bean.DecisionBean;
import de.tub.mac11.connection.MessageConstants;
import de.tub.mac11.ontology.Bot;
import de.tub.mac11.ontology.Edge;
import de.tub.mac11.ontology.InfoMsg;
import de.tub.mac11.ontology.Intention;
import de.tub.mac11.ontology.Vertex;
import de.tub.mac11.ontology.World;
import de.tub.mac11.util.WeightReader;
import edu.uci.ics.jung.algorithms.shortestpath.DijkstraDistance;

public class Escape extends State {
	
	Vertex myPosition = null;
	LinkedList<Bot> enemySaboteurs = new LinkedList<Bot>();
	
	public Escape(World world, DecisionBean db) {
		super(world, db);
	}

	@Override
	public Intention execute() {
		
		Intention intention;
		myPosition = getWorld().getVertices().get(getWorld().getSelf().position);
		LinkedList<Vertex> neighborVertices = getWorld().getNeighborNodes(myPosition);
		
		enemySaboteurs.clear();
		boolean isEnemySaboteurOnMyPosition = false;
		
		// get neighbor enemy saboteurs
		for (Bot enemy : getWorld().getEnemySaboteurs()) {
			
			if (enemy.isAlive()	&& enemy.lastSeen == getWorld().getCurrentStep()) {
				Vertex enemyPosition = getWorld().getAgentPosition(enemy);
				
				// is enemy saboteur standing on the same vertex?
				if (myPosition.name.equals(enemyPosition.name)) {
					isEnemySaboteurOnMyPosition = true;
					break;
					
				// is enemy saboteur standing on neighbor vertex?
				} else if (neighborVertices.contains(enemyPosition)) {
					enemySaboteurs.add(enemy);
				}
			
			} 
		}
		
		// parry if enemy saboteur is on the same vertex and there are no other active team agents
		if (isEnemySaboteurOnMyPosition && getWorld().numTeamAgentsOnVertex(myPosition.name) <= 1) {
			
			intention = new Intention(MessageConstants.ACTION_PARRY, null);
			
		// try to escape 
		} else {
			
			LinkedList<Vertex> semiSaveUnsurveyedNeighbors = removeSaboteursPositions(neighborVertices);	
			LinkedList<Vertex> semiSaveSurveyedNeighbors = removeUnsurveyedNeighbors(semiSaveUnsurveyedNeighbors);	
			LinkedList<Vertex> saveUnsurveyedNeighbors = removeSaboteursNeighbors(semiSaveUnsurveyedNeighbors);
			LinkedList<Vertex> saveSurveyedNeighbors = removeUnsurveyedNeighbors(saveUnsurveyedNeighbors);
			
			removeUnavailableNeighbors(semiSaveSurveyedNeighbors);
			removeUnavailableNeighbors(saveSurveyedNeighbors);
			
			// (1) is there a SAFE (=not enemy neighbor) SURVEYED neighbor vertex (edge)			
			if (!saveSurveyedNeighbors.isEmpty()) {
				
				Vertex vertexToGo = getCheapestVertexToGo(saveSurveyedNeighbors);
				intention = new Intention(MessageConstants.ACTION_GOTO, vertexToGo.name);
				
			// (2) is there a SEMI-SAFE (=not enemy position) SURVEYED neighbor vertex (edge) 
			} else if (!semiSaveSurveyedNeighbors.isEmpty()) {
				
				Vertex vertexToGo = getCheapestVertexToGo(semiSaveSurveyedNeighbors);
				intention = new Intention(MessageConstants.ACTION_GOTO, vertexToGo.name);
				
			// (3) is there a SAFE (=not enemy neighbor) UNSURVEYED neighbor vertex (edge)
			} else if (!saveUnsurveyedNeighbors.isEmpty()) {
				
				// choose a random vertex
				Vertex vertexToGo = saveUnsurveyedNeighbors.getFirst();
				intention = new Intention(MessageConstants.ACTION_GOTO, vertexToGo.name);
			
			// (4) is there a SEMI-SAFE (=not enemy position) UNSURVEYED neighbor vertex (edge)
			} else if (!saveUnsurveyedNeighbors.isEmpty()) {
				
				// choose a random vertex
				Vertex vertexToGo = saveUnsurveyedNeighbors.getFirst();
				intention = new Intention(MessageConstants.ACTION_GOTO, vertexToGo.name);
			
			// (5) there is no way to escape
			} else {
				
				intention = new Intention(MessageConstants.ACTION_RECHARGE, null);				
			}			
		}
		
		return intention;
	}

	/**
	 * Returns vertices without enemy saboteurs' neighbor vertices
	 * 
	 */
	private LinkedList<Vertex> removeSaboteursNeighbors(LinkedList<Vertex> list) {
		
		LinkedList<Vertex> vertices = (LinkedList<Vertex>) list.clone();
		
		for (Bot enemy : enemySaboteurs) {
			
			Vertex enemyPosition = getWorld().getAgentPosition(enemy);
			LinkedList<Vertex> enemyNeighbors = getWorld().getNeighborNodes(enemyPosition);
			
			for (Vertex node : enemyNeighbors) {
				vertices.remove(node);
			}
		}
		
		return vertices;
	}

	/**
	 * Returns vertices without enemy saboteurs' positions
	 * 
	 */
	private LinkedList<Vertex> removeSaboteursPositions(LinkedList<Vertex> list) {
		
		LinkedList<Vertex> vertices = (LinkedList<Vertex>) list.clone();
		
		for (Bot enemy : enemySaboteurs) {
			Vertex enemyPosition = getWorld().getAgentPosition(enemy);
			vertices.remove(enemyPosition);
		}
		
		return vertices;
	}

	/**
	 * Removes vertices which are connected to agent's position with an unsurveyed edge
	 * 
	 */
	private LinkedList<Vertex> removeUnsurveyedNeighbors(LinkedList<Vertex> list) {
		
		LinkedList<Vertex> vertices = (LinkedList<Vertex>) list.clone();
		
		LinkedList<Vertex> unsurveyedNeighbors = new LinkedList<Vertex>();
		for (Vertex node : vertices) {
			Edge edge = world.getGraph().findEdge(myPosition, node);
			if (!edge.surveyed) {
				unsurveyedNeighbors.add(node);
			}
		}
		
		for (Vertex node : unsurveyedNeighbors) {
			vertices.remove(node);
		}
		
		return vertices;
	}

	/**
	 * Removes vertices which are unavailable because of energy lack 
	 * 
	 */
	private void removeUnavailableNeighbors(LinkedList<Vertex> vertices) {
		
		LinkedList<Vertex> unavailableNeighbors = new LinkedList<Vertex>();
		for (Vertex node : vertices) {
			Edge edge = world.getGraph().findEdge(myPosition, node);
			if (edge.weight > getWorld().getSelf().energy) {
				unavailableNeighbors.add(node);
			}
		}
		
		for (Vertex node : unavailableNeighbors) {
			vertices.remove(node);
		}		
	}
	
	/**
	 * Returns a vertex connected to agent's position with lowest edge weight 
	 * 
	 */
	private Vertex getCheapestVertexToGo(LinkedList<Vertex> vertices) {
		Vertex vertexToGo = null;
		int lowestCosts = 100;
		
		// get vertex with lowest edge weight
		for (Vertex node : vertices) {
			Edge edge = world.getGameField().findEdge(myPosition, node);
			if (edge.weight < lowestCosts) {
				vertexToGo = node;
				lowestCosts = edge.weight;
			}
		}
		
		return vertexToGo;
	}

	/**
	 * Escape if agent is standing on unsafe position.
	 * 
	 */
	public boolean isTrue() {
		
		// explorer in game field try not to escape
		if (getWorld().getSelf().role.equals(Bot.EXPLORER)
				&& getWorld().isInGameField(getWorld().getMyPosition())) {
			return false;
		}
		
		if (getWorld().isSafePosition(getWorld().getSelf().position)) {
			return false;
		} else {
			return true;
		}
	}

	@Override
	protected void handleInfoMsg(InfoMsg infoMsg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected Path getPathfinding() {
		return Path.SAFE;
	}


}