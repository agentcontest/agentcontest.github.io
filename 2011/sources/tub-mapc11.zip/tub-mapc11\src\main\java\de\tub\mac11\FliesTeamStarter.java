package de.tub.mac11;

import de.dailab.jiactng.agentcore.SimpleAgentNode;

public class FliesTeamStarter {
	public static String NODES_SPRINGCONFIGFILE = "classpath:Flies-Team.xml";

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SimpleAgentNode.main(new String[] {NODES_SPRINGCONFIGFILE});
	}

}
