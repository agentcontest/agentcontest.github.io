package de.tub.mac11.bean.frogs.messages;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac11.util.DistanceMatrix;

public class MatrixContent implements IFact {

  public DistanceMatrix matrix = null;

  public MatrixContent(DistanceMatrix matrix) {
    this.matrix = matrix;
  }

}
