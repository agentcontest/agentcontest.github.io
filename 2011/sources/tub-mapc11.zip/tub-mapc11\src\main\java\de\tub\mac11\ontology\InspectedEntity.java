package de.tub.mac11.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;

public class InspectedEntity implements IFact {
	public String name;
	public String vertex;
	public String role;
	public String team;
	public int energy;
	public int health;
	public int maxEnergy;
	public int maxHealth;
	public int strength;
	public int visRange;
}
