package graph.core;

import graph.util.Position;

public interface Edge<T> extends Position<T> {

}
