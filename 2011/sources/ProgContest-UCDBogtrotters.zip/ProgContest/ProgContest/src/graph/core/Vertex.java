package graph.core;

import graph.util.Position;

public interface Vertex<T> extends Position<T> {

}
