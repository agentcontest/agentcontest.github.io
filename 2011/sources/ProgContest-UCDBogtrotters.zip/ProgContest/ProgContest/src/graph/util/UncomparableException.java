package graph.util;

public class UncomparableException extends RuntimeException {

}
