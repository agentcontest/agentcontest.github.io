package graph.util;
public interface Position<T> {
	public T element();
}
