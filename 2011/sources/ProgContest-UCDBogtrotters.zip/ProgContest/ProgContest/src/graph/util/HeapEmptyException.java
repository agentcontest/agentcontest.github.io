package graph.util;

public class HeapEmptyException extends RuntimeException {

}
