package com.agentfactory.mapc;

import graph.util.Heap;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Queue;

import com.agentfactory.clf.interpreter.Action;
import com.agentfactory.clf.interpreter.Module;
import com.agentfactory.clf.interpreter.Sensor;
import com.agentfactory.clf.lang.Predicate;
import com.agentfactory.mapc.MapService2.AgentInfo;

public class MapModule extends Module {
	private Map<String, List<Vertex>> regions;
	private MapService2 service;
	private String myPos;
	private String myStatus;
	private String myTarget = null;
	private String teamName;
	private int probeDepth;
	private boolean patrol = false;
	private Queue<String> route;
	private int maxEnergy = 14;

	public MapModule() {

		addAction("setup", new Action() {
			public boolean execute(Predicate activity) {
				agent.bindToPlatformService(MapService2.NAME);
				service = (MapService2) agent.getPlatformService(MapService2.NAME);
				return true;
			}
		});

		addAction("setPatrolMode", new Action() {
			public boolean execute(Predicate activity) {
				patrol = true;
				return false;
			}
		});

		addAction("setProbeTarget(?vertex, ?d)", new Action() {
			public boolean execute(Predicate activity) {
				myTarget = termAsString(activity, 0);
				probeDepth = termAsInt(activity, 1);
				return true;
			}
		});

		addAction("updateRegions(?start, ?depth, ?extra)", new Action() {
			public boolean execute(Predicate activity) {
				String start = termAsString(activity, 0);
				int depth = termAsInt(activity, 1);
				int extra = termAsInt(activity, 2);
				regions = service.getRegions(start, depth, extra);
				return true;
			}
		});

		addAction("findCluster(?vertex1)", new Action() {

			@Override
			public boolean execute(Predicate activity) {
				String vertex1 = termAsString(activity, 0);
				service.findCluster(vertex1);
				return true;
			}
		});

		addAction("getExplorationVertices(?no, ?d, ?v)", new Action() {

			@Override
			public boolean execute(Predicate activity) {
				int noAgents = termAsInt(activity, 0);
				int distance = termAsInt(activity, 1);
				String vertex = termAsString(activity, 2);
				service.getExplorationVertices(noAgents, distance, vertex);

				return false;
			}
		});

		// Map update actions
		addAction("resetMe", new Action() {
			public boolean execute(Predicate activity) {
				myPos = "";
				myStatus = "";
				myTarget = null;
				route = null;
				patrol = false;
				return true;
			}
		});

		addAction("resetService", new Action() {
			public boolean execute(Predicate activity) {
				System.out.println("Resetting service");
				service.reset();
				return true;
			}
		});

		addAction("addEdge(?vertex1,?vertex2,?weight)", new Action() {
			public boolean execute(Predicate activity) {
				String vertex1 = termAsString(activity, 0);
				String vertex2 = termAsString(activity, 1);
				int weight = termAsInt(activity, 2);
				service.addEdge(vertex1, vertex2, weight);
				return true;
			}
		});

		addAction("getNearProbe(?pos)", new Action() {

			public boolean execute(Predicate activity) {
				String pos = termAsString(activity, 0);
				route = service.getNearProbe(pos, 6);
				return true;
			}
		});

		addAction("setTeam(?name)", new Action() {
			public boolean execute(Predicate activity) {
				String name = termAsString(activity, 0);
				teamName = name;
				return true;
			}
		});

		addAction("getNearSurvey(?pos)", new Action() {

			public boolean execute(Predicate activity) {
				String pos = termAsString(activity, 0);
				route = service.getNearSurvey(pos);
				return true;
			}
		});

		addAction("addEdge(?vertex1,?vertex2)", new Action() { // adds an edge
																// to the map
																// (specifying
																// end vertices)
					public boolean execute(Predicate activity) {
						String vertex1 = termAsString(activity, 0);
						String vertex2 = termAsString(activity, 1);
						service.addEdge(vertex1, vertex2);
						return true;
					}
				});

		addAction("addVertex(?vertex,?owner)", new Action() { // adds a vertex
																// to the map
					public boolean execute(Predicate activity) {
						String name = termAsString(activity, 0);
						String type = termAsString(activity, 1);
						service.addVertex(name, type);
						return true;
					}
				});

		addAction("addProbedVertex(?vertex,?amount)", new Action() { // adds a
																		// vertex
																		// to
																		// the
																		// map
					public boolean execute(Predicate activity) {
						String name = termAsString(activity, 0);
						int value = termAsInt(activity, 1);
						service.addVertex(name, value);
						return true;
					}
				});

		addAction("setSurveyed(?vertex)", new Action() { // marks a vertex as
															// surveyed
					public boolean execute(Predicate activity) {
						String vertex = termAsString(activity, 0);
						service.setSurveyed(vertex);
						return true;
					}
				});

		addAction("setProbed(?vertex)", new Action() { // sets a vertex as
														// probed
					public boolean execute(Predicate activity) {
						String vertex = termAsString(activity, 0);
						service.setProbed(vertex);
						return true;
					}
				});

		// routing actions

		addAction("setTarget(?end)", new Action() { // plots a route between the
					// start and the end
					// positions
					@Override
					public boolean execute(Predicate activity) {
						myTarget = termAsString(activity, 0);
						route = service.getRoute(myPos, myTarget, Integer.MAX_VALUE, maxEnergy);
						return true;
					}
				});

		addAction("setAgentInfo(?name,?position,?team,?status)", new Action() {
			public boolean execute(Predicate activity) {
				String name = termAsString(activity, 0);
				String position = termAsString(activity, 1);
				String team = termAsString(activity, 2);
				String status = termAsString(activity, 3);
				service.setAgentInfo(name, team, position, status);
				return true;
			}
		});

		addAction("setAgentRole(?agentName,?role, ?enM, ?heM, ?st, ?vis,?stp)", new Action() {
			public boolean execute(Predicate activity) {
				String agentName = termAsString(activity, 0);
				String role = termAsString(activity, 1);
				int enM = termAsInt(activity, 2);
				int heM = termAsInt(activity, 3);
				int st = termAsInt(activity, 4);
				int vis = termAsInt(activity, 5);
				int step = termAsInt(activity, 6);
				service.setAgentRole(agentName, role, enM, heM, st, vis, step);
				maxEnergy = enM;
				return true;
			}
		});

		addAction("setStatus(?stat)", new Action() {
			public boolean execute(Predicate activity) {
				String status = termAsString(activity, 0);
				myStatus = status;
				return true;
			}
		});

		addAction("generateHomeZone(?vertex, ?depth)", new Action() {
			public boolean execute(Predicate activity) {
				String vertex = termAsString(activity, 0);
				int depth = termAsInt(activity, 1);

				Map<Integer, List<Vertex>> map = service.getZoneScore2(vertex, depth);

				for (Integer i : map.keySet()) {
					List<Vertex> z = map.get(i);
					String list = "[";
					boolean first = true;
					for (Vertex s : z) {
						if (first) {
							list += s.name;
							first = false;
						} else {
							list += "," + s.name;
						}
					}
					list += "]";

					addBelief("homePositions(" + i + "," + z.size() + ", 0," + list + ")");
				}
				/*
				 * Map<Integer, MAPCGraph.ZoneScore> map = service.getZoneScore(vertex, depth);
				 * 
				 * for (Integer i : map.keySet()) { MAPCGraph.ZoneScore z = map.get(i); String list = "["; boolean first = true; for (String s : z.positions) {
				 * if(first){ list +=s; first = false; } else { list += "," + s; } } list += "]";
				 * 
				 * addBelief("homePositions("+i+","+z.minAgents+"," + z.cumulativeScore+","+ list+")"); }
				 */
				return true;
			}
		});

		addAction("setPos(?vertex)", new Action() {
			public boolean execute(Predicate activity) {
				myPos = termAsString(activity, 0);
				if (route != null && !route.isEmpty()) {
					if (route.peek().equals(myPos)) {
						route.poll();
					}
				}
				return true;
			}
		});

		addAction("removeTarget", new Action() {
			public boolean execute(Predicate activity) {
				route = null;
				myTarget = null;
				return true;
			}
		});
		addSensor("energySensor", new Sensor(){
			public void perceive() {
				addBelief("energyCostP(buy, 2)");
				addBelief("energyCostP(attack, 2)");
				addBelief("energyCost(parry, 2)");
				addBelief("energyCost(probe, 1)");
				addBelief("energyCost(survey, 1)");
				addBelief("energyCost(inspect, 2)");
				if(myStatus!=null&&myStatus.equals("normal"))
					addBelief("energyCostP(repair, 2)");
				else 
					addBelief("energyCostP(repair, 3)");
				
				addBelief("energyCostP(goto, 0)");
				addBelief("energyCost(recharge, 54)");
				
			}});

		addSensor("mapSensor", new Sensor() {
			public void perceive() {
				setitup();
				if (teamName != null)
					addBelief("teamName(" + teamName + ")");
				int sabCount = 0;
				String closestRepairer = null;
				int closestDist = Integer.MAX_VALUE;
				
				// Default Values
				int maxHealth = 6;
				int maxStrength = 3;
				for (AgentInfo s : service.getAgentInfo().values()) {
					if (teamName != null && !s.team.equals(teamName) && s.role.equals("Saboteur")) {
						addBelief("lastInspected("+s.name+","+s.lastInspected+")");
						sabCount++;
					}
					if (myPos != null) {
						int d = service.getDistance(s.position, myPos, maxEnergy);
						if(d!= Integer.MAX_VALUE)
							addBelief("distance("+s.name +","+d+")");
					
						if (teamName != null && s.team.equals(teamName) && s.role.equals("Repairer")) {
							if (d < closestDist) {
								if (!s.name.equals(agent.getName())) {
									closestDist = d;
									closestRepairer = s.name;
								}
							}
						}
					}
					addBelief("agentInfo(" + s.name + "," + s.team + "," + s.position + "," + s.role + "," + s.status + ")");
					
					if (teamName != null && !s.team.equals(teamName)) {
						if (maxHealth < s.health) maxHealth = s.health;
						if (maxStrength < s.strength) maxStrength = s.strength;
						
					}
					addBelief("agentStats(" + s.name + "," + s.energy + "," + s.health + "," + s.strength + "," + s.visibility + ")"); 
				}

				addBelief("maxEnemyHealth(" + maxHealth + ")");
				addBelief("maxEnemyStrength(" + maxStrength + ")");
				addBelief("doubleMaxEnemyStrength(" + (maxStrength*2) + ")");
				
				if (closestRepairer != null) addBelief("closestRepairer(" + closestRepairer + ")");
				
				if (sabCount > 0)
					addBelief("noSaboteurs(" + sabCount + ")");

				for (String s : service.getEdges()) {
					addBelief("edge(" + s + ")"); // list of edges (vertex1,
													// vertex2, weight)
				}

				addBelief("noEdges(" + service.getEdges().size() + ")");

				addBelief("surveyedEdges(" + service.surveyedEdgeCount + ")");

				if (myPos != null) {
					addBelief("myPos(" + myPos + ")");
					for (String s : service.getAdjacentVerticies(myPos)) {
						addBelief("adjacent(" + s + ")");
					}
				}

				if (myTarget != null) {
					addBelief("target(" + myTarget + ")");
					if (route == null){
						route = service.getRoute(myPos, myTarget, 100, maxEnergy);
					}
					if (!service.isConnected(myPos, myTarget))
						addBelief("targetUnavailable");
				}
				
				if (route != null && route.size() > 0) {
					addBelief("nextPosition(" + route.peek() + ")");
					addBelief("routeDistance(" + route.size() + ")");
				} 

				List<String> vertices = service.getVertices();

				for (String s : vertices) {
					addBelief("vertex(" + s + ")"); // list of vertices
				}

				addBelief("status(" + myStatus + ")");

				addBelief("noVertices(" + vertices.size() + ")");

				if (agent.getName().equals("leader")) {
					String s = service.getHighestValueVertex();
					if (s != null) {
						addBelief("highestValue(" + s + ")");
					}
					// System.out.println(service.getZoneScore(s));
				}

				if (myTarget != null) {
					List<String> list = service.getUnprobedWithin(myTarget, probeDepth);
					int min = Integer.MAX_VALUE;
					String closest = null;
					Collections.shuffle(list);
					for (String string : list) {
						addBelief("unprobed(" + string + ")");
						int d = service.getDistance(string, myPos, maxEnergy);
						if (d < min) {
							min = d;
							closest = string;
						}
					}
					if (closest != null)
						route = service.getRoute(myPos, closest, 5, maxEnergy);
					if(route == null)
						addBelief("targetUnavailable");

					addBelief("probeTarget(" + myTarget + "," + probeDepth + ")");
				}

				if (regions != null) {
					for (String zone : regions.keySet()) {
						String lst = "[";
						boolean first = true;
						for (Vertex v : regions.get(zone)) {
							if (first)
								first = false;
							else
								lst += ",";

							lst += v.name;
						}
						addBelief("zone(" + zone + "," + lst + "])");
					}
				}
				
				
				if(myPos!=null){
					Heap<Integer,String> heap = new Heap<Integer,String>();
					for (AgentInfo i : service.getAgentInfo().values()) {
						if(i.status.equals("normal") && !i.team.equals(teamName)){
							int dist = service.getDistance(i.position, myPos, maxEnergy);
							heap.insert(dist,i.name+","+i.position);
						}
					}
					if (!heap.isEmpty()) addBelief("enemyTarget(0,"+heap.remove()+")");
					if (!heap.isEmpty()) addBelief("enemyTarget(1,"+heap.remove()+")");
				}
				
				if(myPos!=null){
					int n = 0;
					for (AgentInfo i : service.getAgentInfo().values()) {
						if(i.status.equals("normal") && i.position.equals(myPos) && !i.team.equals(teamName)&& i.role.equals("Saboteur")){
								addBelief("target("+n+","+i.name+")");
								n++;
						}
					}
					for (AgentInfo i : service.getAgentInfo().values()) {
						if(i.status.equals("normal") && i.position.equals(myPos) && !i.team.equals(teamName)&& i.role.equals("Repairer")){
								addBelief("target("+n+","+i.name+")");
								n++;
						}
					}
					for (AgentInfo i : service.getAgentInfo().values()) {
						if(i.status.equals("normal") && i.position.equals(myPos) && !i.team.equals(teamName)&& !i.role.equals("Repairer") && !i.role.equals("Saboteur")){
								addBelief("target("+n+","+i.name+")");
								n++;
						}
					}
					addBelief("noTargets("+n+")");
					
					
				}
			}
		});

		// addSensor("patrolSensor", new Sensor() {
		// public void perceive() {
		// if (patrol) {
		// addBelief("patrolMode");
		// route = null;
		// List<AgentInfo> repList = new LinkedList<AgentInfo>();
		// List<AgentInfo> sabList = new LinkedList<AgentInfo>();
		// if (teamName != null) {
		// for (AgentInfo i : service.getAgentInfo().values()) {
		// if (!teamName.equals(i.team) && i.role.equals("Repairer") && i.status.equals("normal")) repList.add(i);
		// else if (!teamName.equals(i.team) && i.role.equals("Saboteur") && i.status.equals("normal")) sabList.add(i);
		// }
		// if (repList.size() == 1) {
		// route = service.getRoute(myPos, repList.get(0).position, 100);
		// myTarget = repList.get(1).position;
		// } else if (repList.size() == 2) {
		// int d1 = service.getDistance(myPos, repList.get(0).position);
		// int d2 = service.getDistance(myPos, repList.get(1).position);
		// if (d1 >= d2) {
		// route = service.getRoute(myPos, repList.get(1).position, 100);
		// myTarget = repList.get(1).position;
		// } else {
		// route = service.getRoute(myPos, repList.get(0).position, 100);
		// myTarget = repList.get(0).position;
		// }
		// }
		//
		// if (route == null) {
		// if (sabList.size() == 1) {
		// route = service.getRoute(myPos, sabList.get(0).position, 100);
		// myTarget = sabList.get(0).position;
		// } else if (sabList.size() == 2) {
		// int d1 = service.getDistance(myPos, sabList.get(0).position);
		// int d2 = service.getDistance(myPos, sabList.get(1).position);
		// if (d1 >= d2) {
		// route = service.getRoute(myPos, sabList.get(1).position, 100);
		// myTarget = sabList.get(1).position;
		// } else {
		// route = service.getRoute(myPos, sabList.get(0).position, 100);
		// myTarget = sabList.get(0).position;
		// }
		// }
		// }
		// if (route == null) {
		// int min = Integer.MAX_VALUE;
		// AgentInfo targ = null;
		// for (AgentInfo i : service.getAgentInfo().values()) {
		// if (i.status.equals("normal")) {
		// int d = service.getDistance(myPos, i.position);
		// if (d < min) {
		// min = d;
		// targ = i;
		// }
		// }
		// }
		// route = service.getRoute(myPos, targ.position, 100);
		// myTarget = targ.position;
		// }
		// }
		//
		// }
		// }
		// });
	}

	public void setitup() { // sets up the map service
		agent.bindToPlatformService(MapService2.NAME);
		service = (MapService2) agent.getPlatformService(MapService2.NAME);
	}
}
