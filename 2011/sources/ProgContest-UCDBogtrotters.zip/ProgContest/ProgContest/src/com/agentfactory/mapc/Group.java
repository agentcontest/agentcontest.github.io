package com.agentfactory.mapc;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class Group {
	public String name;
	public String owner;
	public List<Member> members;
	public List<String> roles;
	public Map<String, List<String>> tasks;
	public List<String> groupTask;
	public List<String> requests;
	public String homeVertex;
	
	public Group(String name, String owner, List<String> roles) {
		this.name = name;
		this.owner = owner;
		this.roles = roles;

		groupTask = null;
		members = new LinkedList<Member>();
		tasks = new HashMap<String, List<String>>();
		requests = new LinkedList<String>();
	}
	
	public void addRequest(String request) {
		requests.add(request);
	}
	
	public void setHomeVertex(String homeVertex) {
		this.homeVertex = homeVertex;
	}
	
	public String homeVertex() {
		return homeVertex;
	}

	public String getNextRequest() {
		if (requests.isEmpty()) return null;
		return requests.get(0);
	}
	
	public void reset() {
		members.clear();
		tasks.clear();
		requests.clear();
	}
	
	public synchronized void setGroupTasks(List<String> taskList) {
		groupTask = taskList;
		for(Member member : members) {
			tasks.put(member.name,new LinkedList<String>(taskList));
		}
	}
	
	public void setTasks(String name, List<String> taskList) {
		groupTask = null;
		if (hasMember(name)) {
			tasks.put(name,taskList);
		}
	}
	
	public void addTasks(String name, List<String> taskList) {
		groupTask = null;
		if (hasMember(name)) {
			List<String> list = tasks.get(name);
			if (list == null) {
				list = new LinkedList<String>();
				tasks.put(name, list);
			}
			list.addAll(0, taskList);
		}
	}
	
	public Map<String, List<String>> tasks() {
		return tasks;
	}
	
	public synchronized List<String> availableRoles() {
		List<String> list = new LinkedList<String>();
		list.addAll(roles);
		for (Member member: members) {
			list.remove(member.role);
		}
		return list;
	}
	
	public String getTask(String name) {
		List<String> list = tasks.get(name);
		if (list == null || list.isEmpty()) return null;
		return list.get(0);
	}

	public void removeTask(String name) {
		List<String> list = tasks.get(name);
		if (list!=null && !list.isEmpty()) list.remove(0);
	}
	
	public synchronized void addMember(Member member) {
		members.add(member);
		
		if (groupTask != null) {
			tasks.put(member.name, groupTask);
		}
	}
	
	public synchronized boolean hasMember(String name) {
		for (Member member: members) {
			if (member.name.equals(name)) return true;
		}
		return false;
	}
}