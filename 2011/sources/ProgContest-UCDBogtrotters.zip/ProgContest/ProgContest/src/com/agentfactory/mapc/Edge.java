package com.agentfactory.mapc;

public class Edge {
	int weight;
	Vertex[] ends;

	public Edge(Vertex s, Vertex end, int c) {
		weight = c;
		ends = new Vertex[2];
		ends[0] = s;
		ends[1] = end;
	}

	public Vertex[] getEnds() {
		return ends;
	}
	
	public boolean contains(Vertex v){
		return ends[0] == v || ends[1] == v;
	}

	public Vertex opposite(Vertex v) {
		if(ends[0] == v)
			return ends[1];
		else
			return ends[0];
	}
	
	public boolean equals(Object o){
		if(Edge.class.isInstance(o)){
			Edge e = (Edge)o;
			if((e.ends[0].equals(ends[0]) && e.ends[1].equals(ends[1]) )|| (e.ends[0].equals(ends[1]) && e.ends[1].equals(ends[0])))
				return true;
			else
				return false;
		} else 
			return false;
		
	}
}
