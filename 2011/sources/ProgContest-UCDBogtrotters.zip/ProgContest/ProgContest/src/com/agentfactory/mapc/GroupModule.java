package com.agentfactory.mapc;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.agentfactory.agentspeak.interpreter.Utilities;
import com.agentfactory.clf.interpreter.Action;
import com.agentfactory.clf.interpreter.Module;
import com.agentfactory.clf.interpreter.Sensor;
import com.agentfactory.clf.lang.Function;
import com.agentfactory.clf.lang.ITerm;
import com.agentfactory.clf.lang.Predicate;

public class GroupModule extends Module {
	private GroupService service;
	
	public GroupModule() {
		addAction("setup(?sid, ?list)", new Action() {
			@Override
			public boolean execute(Predicate activity) {
				String sid = termAsString(activity, 0);
				
				if (service == null) {
					if (!agent.bindToPlatformService(sid)) return false;
					service = (GroupService) agent.getPlatformService(sid);
				
					for (ITerm term : activity.termAt(1).terms()) {
						Predicate pred = Utilities.factory.convertToPredicate(term);
						String name = termAsString(pred, 0);
						List<String> roles = this.termAsList(pred, 1);
						if (!service.create(agent.getName(), name, roles)) {
							System.out.println("Could not create group: " + Utilities.presenter.toString(term));
						}
					}
				} else {
					service.reset();
				}
				return true;
			}
		});
		addAction("reset", new Action() {
			@Override
			public boolean execute(Predicate activity) {
				service.reset();
				return true;
			}
		});
		addAction("create(?name)", new Action() {
			@Override
			public boolean execute(Predicate activity) {
				String name = termAsString(activity, 0);
				if (service == null) return false;
				service.create(agent.getName(), name);	
				return true;
			}
		});
		addAction("setHome(?grp, ?vertex)", new Action() {
			@Override
			public boolean execute(Predicate activity) {
				String grp= termAsString(activity, 0);
				String v = termAsString(activity, 1);
				if (service == null) return false;
				service.setHomeVertex(grp, v);	
				return true;
			}
		});
		addAction("request(?grp, ?mess)", new Action() {
			@Override
			public boolean execute(Predicate activity) {
				String grp = termAsString(activity, 0);
				String mess = termAsString(activity, 1);
				if (service == null) return false;
				service.addRequest(grp, mess);	
				return true;
			}
		});
		addAction("assign(?grp, ?name)", new Action() {
			@Override
			public boolean execute(Predicate activity) {
				String group = termAsString(activity, 0);
				String name = termAsString(activity, 1);
				if (service == null) return false;
				if (!service.assign(name)) {
					addBelief("failedAssignment(" + name +"," +group+")");
				}
				return true;
			}
		});
		addAction("setTask(?name, ?grp, ?task)", new Action() {
			@Override
			public boolean execute(Predicate activity) {
				String name = termAsString(activity, 0);
				String grp = termAsString(activity, 1);
				List<String> task = termAsList(activity, 2);
				if (service == null) return false;
				service.setTask(name, grp, task);	
				return true;
			}
		});
		addAction("addTask(?name, ?grp, ?task)", new Action() {
			@Override
			public boolean execute(Predicate activity) {
				String name = termAsString(activity, 0);
				String grp = termAsString(activity, 1);
				List<String> task = termAsList(activity, 2);
				if (service == null) return false;
				service.addTask(name, grp, task);	
				return true;
			}
		});
		addAction("taskDone(?name)", new Action() {
			@Override
			public boolean execute(Predicate activity) {
				String name = termAsString(activity, 0);
				if (service == null) return false;
				service.removeTask(name);	
				return true;
			}
		});
		addAction("setGroupTask(?grp, ?task)", new Action() {
			@Override
			public boolean execute(Predicate activity) {
				String grp = termAsString(activity, 0);
				List<String> task = termAsList(activity, 1);
				if (service == null) return false;
				service.setGroupTask(grp, task);	
				return true;
			}
		});
		addAction("setShared(?list)", new Action() {
			@Override
			public boolean execute(Predicate activity) {
				if (service == null) return false;

				Map<String, String> map = new HashMap<String, String>();
				
				for (ITerm term : activity.termAt(0).terms()) {
					Function fn = (Function) term;
					map.put(fn.functor(), Utilities.presenter.toString(fn.termAt(0)));
				}
				service.setShared(map);	
				return true;
			}
		});
		addAction("register(?name, ?role)", new Action() {
			@Override
			public boolean execute(Predicate activity) {
				String name = termAsString(activity, 0);
				String role = termAsString(activity, 1);
				if (service == null) return false;
				service.register(new Member(name, role));
				return true;
			}
		});
		addSensor("groups", new Sensor() {
			@Override
			public void perceive() {
				if (service == null) return;
				synchronized(service){
				for (Group group: service.groups(agent.getName())) {
					if (group.owner.equals(agent.getName())) {
						addBelief("owner(" + group.name + ")");
						for (Member member : group.members) {
							String task = group.getTask(member.name);
							if (task != null) {
								addBelief("task(" + group.name + "," + member.name + "," + task + ")");
							}
							boolean first = true;
							List<String> list = group.tasks.get(member.name);
							if (list != null) {
								String taskList = "[";
								for (String string : list) {
									if(first) first =false;
									else taskList += ",";
									taskList += string;
								}
								taskList+="]";
								addBelief("taskList(" + group.name + "," + member.name + "," + taskList + ")");
							}
						}
						String req = group.getNextRequest();
						if (req != null) {
							addBelief("request(" + group.name + "," + req + ")");
						}
					}
					
					if (group.hasMember(agent.getName())) {
						addBelief("memberOf(" + group.name + ")");
					}
					
					List<String> temp = new LinkedList<String>();
					for (int i=0; i<group.members.size(); i++) {
						Member member = group.members.get(i);	
						if (!temp.contains(member.role)) {
							temp.add(member.role);
							addBelief("groupOrder(" + group.name + "," + member.name +",primary)");
						} else {
							addBelief("groupOrder(" + group.name + "," + member.name +",secondary)");
						}
						
						addBelief("member(" + group.name +"," + member.name + "," + member.role+")");
					}
					
					for (String role : group.availableRoles()) {
						addBelief("space(" + group.name + "," + role + ")");
					}
					
					String task = group.getTask(agent.getName());
					if (task != null) {
						addBelief("assignedTask(" + task + ")");
					}
					
					if (group.roles.size() == group.members.size()) {
						addBelief("fullGroup(" + group.name + ")");
					}
					if (group.homeVertex != null) {
						addBelief("homeVertex(" + group.name + "," + group.homeVertex + ")");
					}
				}
				
				for (String key : service.getShared().keySet()) {
					addBelief(key + "(" + service.getShared().get(key) + ")");
				}
				
				for (Member member : service.members()) {
					addBelief("registered(" + member.name + "," + member.role + ")");
					if (member.group == null) {
						addBelief("unassigned(" + member.name + ")");
					}
				}
			}
			}
		});
	}
}
