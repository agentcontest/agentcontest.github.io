package com.agentfactory.mapc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Stack;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import com.agentfactory.mapc.MAPCGraph.ZoneScore;
import com.agentfactory.platform.impl.AbstractPlatformService;

public class MapService2 extends AbstractPlatformService {

	class AgentInfo {
		String name;
		String team;
		String role = "none";
		String status;
		String position;
		int health;
		int energy;
		int visibility;
		int strength;
		int lastInspected;

		AgentInfo(String n, String p, String t, String s) {
			name = n;
			position = p;
			team = t;
			status = s;
		}

	}

	String us = "A";
	String opponent = "n";
	private Map<String, String> coloring = new ConcurrentHashMap<String, String>(); 
	//
	public static final String NAME = "graph";
	public int surveyedEdgeCount = 0;
	private MAPCGraph map = new MAPCGraph();
	private Map<String, AgentInfo> agentInfo = new ConcurrentHashMap<String, AgentInfo>();

	// Map based methods......................
	public synchronized void addVertex(String vertex, String owner) {
		// adds a vertex to the map
		Vertex v = map.getVertex(vertex);
		if (v == null) {
			Vertex i = new Vertex(vertex, owner, false, false);
			map.insertVertex(i);
		} else if (!v.team.equals(owner))
			v.team = owner;
	}

	public synchronized void reset() {
		map = new MAPCGraph();
		agentInfo = new ConcurrentHashMap<String, AgentInfo>();
	}

	public synchronized void setSurveyed(String vertex) {
		Vertex v = map.getVertex(vertex);
		v.surveyed = true;
	}

	public synchronized void setProbed(String vertex) {
		Vertex v = map.getVertex(vertex);
		v.probed = true;
	}

	public synchronized void addEdge(String vertex1, String vertex2) {
		Vertex v1 = map.getVertex(vertex1);
		Vertex v2 = map.getVertex(vertex2);
		Edge e = getEdge(v1, v2);
		if (e == null) {
			map.insertEdge(v1, v2, 0);
		}
	}

	public synchronized void addEdge(String vertex1, String vertex2, int weigth) {
		Vertex v1 = map.getVertex(vertex1);
		Vertex v2 = map.getVertex(vertex2);
		Edge e = getEdge(v1, v2);
		if (e == null) {
			surveyedEdgeCount++;
			map.insertEdge(v1, v2, weigth);
		} else {
			if (e.weight != weigth)
				surveyedEdgeCount++;
			e.weight = weigth;
		}
	}

	public synchronized List<String> getEdges() { // return the list of edges
		List<String> list = new LinkedList<String>();
		for (Edge e : map.edges()) {
			Vertex[] vertices = map.endVertices(e);
			list.add(vertices[0].name + "," + vertices[1].name + "," + e.weight);
		}
		return list;
	}

	public synchronized List<String> getVertices() { // return the list of edges
		List<String> list = new LinkedList<String>();
		for (Vertex e : map.vertices()) {
			list.add(e.name + ", " + e.team + ", " + e.probed + ","
					+ e.surveyed + "," + e.value);
		}
		return list;
	}

	private Edge getEdge(Vertex vertex1, Vertex vertex2) {
		for (Edge e : vertex1.getEdges()) {
			if (e.contains(vertex2))
				return e;
		}
		return null;
	}

	// Agent based methods.......

	public synchronized Map<String, String> getAgentPositions() {
		Map<String, String> map = new HashMap<String, String>();
		for (AgentInfo ai : agentInfo.values()) {
			map.put(ai.name, ai.position);
		}
		return map;
	}

	public synchronized void setAgentRole(String agentName, String role, int enM, int heM, int st, int vis, int step) { 
		AgentInfo i = agentInfo.get(agentName);
		if (i == null) {
			i = new AgentInfo(agentName, "unknown", "unknown", "unknown");
			agentInfo.put(agentName, i);
		}
		i.role = role;
		i.energy = enM;
		i.health = heM;
		i.strength = st;
		i.visibility = vis;
		i.lastInspected = step;
	}

	public synchronized void setAgentInfo(String agentName, String team,
			String position, String status) { // sets or updates the agent's
												// role
		AgentInfo i = agentInfo.get(agentName);
		if (i == null)
			agentInfo.put(agentName, new AgentInfo(agentName, position, team,
					status));
		else {
			i.position = position;
			i.status = status;
			i.team = team;
		}
	}

	public synchronized Map<String, AgentInfo> getAgentInfo() {
		return agentInfo;
	}

	public synchronized Queue<String> getRoute(String end, String start, int depth, int maxEnergy) {
		return map.BFsearch(end, start, depth, maxEnergy);
	}

	public synchronized Queue<String> getNearProbe(String myPos, int probeDepth) {
		return map.BFVsearch(myPos, true, probeDepth);
	}

	public synchronized Queue<String> getNearSurvey(String myPos) {
		return map.BFVsearch(myPos, false, 10);
	}

	public synchronized boolean isConnected(String p1, String p2) {
		return map.connected(p1, p2);
	}

	public void findCluster(String vertex) {
		Vertex v = map.getVertex(vertex);
		List<Edge> edges = v.getEdges();
		int val = 0;
		for (Edge edge : edges) {
			Vertex w = edge.opposite(v);
			val += w.value;
		}
		System.out.println(vertex + " has cluster val " + val + " "
				+ v.getEdges().size());
	}

	public synchronized void addVertex(String vertex, int value) {
		// adds a vertex to the map
		Vertex v = map.getVertex(vertex);
		if (v == null) {
			Vertex i = new Vertex(vertex, "unknown", false, false);
			i.value = value;
			map.insertVertex(i);
		} else if (v.value != value)
			v.value = value;
	}

	public synchronized void color() { // coloring algorithm
		// step 1
		Map<Vertex, String> owners = new HashMap<Vertex, String>();
		for (Vertex v : map.vertices()) {
			int ourNo = 0;
			int theirNo = 0;
			for (AgentInfo agent : agentInfo.values()) {
				if (agent.position.equals(v.name)) {
					if (agent.team.equals(us)) {
						ourNo++;
					} else {
						theirNo++;
					}
				}
			}
			if (ourNo > theirNo) {
				owners.put(v, us);
			} else if (ourNo == theirNo) {
				owners.put(v, "none");
			} else {
				owners.put(v, opponent);
			}
		}

		// step 2
		for (Vertex v : owners.keySet()) {
			if (owners.get(v).equals("none")){
				int ourNo = 0;
				int theirNo = 0;
				for (Edge e : v.getEdges()) {
					Vertex v2 = e.opposite(v);
					if (owners.get(v2).equals(us)){
						ourNo++;
					} else if (owners.get(v2).equals(opponent)){
						theirNo--;
					}
				}
				if (ourNo > theirNo) {
					owners.put(v, us);
				} else if (ourNo == theirNo) {
					owners.put(v, "none");
				} else {
					owners.put(v, opponent);
				}
			}

		}

		// step 3
		for (Vertex v : map.vertices()) {
			if (owners.get(v).equals("none")) {
			for (AgentInfo agent : agentInfo.values()) {
				if (agent.position.equals(v.name)) {
					if (agent.team.equals(us)) {
						Queue<String> route = map.getRoute(v.name, agent.position, 1000);
						for (String string : route) {
							Vertex vertex = map.getVertex(string);
							if (owners.get(vertex).equals(opponent));
						}
					}
				}
			}
			}

		}
	}

	public List<String> getNearVerticies(String myPos) {
		List<String> close = new LinkedList<String>();
		Vertex v = map.getVertex(myPos);
		for (Edge e : v.getEdges()) {
			close.add(e.opposite(v).name);
		}
		return close;
	}
	
	public synchronized Map<String, List<Vertex>> getRegions(String start, int depth, int extra) {
		return this.map.getRegions(start, depth, extra);
	}
	
	public List<String> getExplorationVertices(int noAgents, int distance, String vertex){
		return map.getExplorationVertices(noAgents, distance, vertex);
	}

	public synchronized String getHighestValueVertex() {
		return map.getHighestValueVertex();
	}

	public synchronized Map<Integer, ZoneScore> getZoneScore(String s, int depth) {
		return map.getZoneScore(s, depth);
	}
	
	public synchronized Map<Integer, List<Vertex>> getZoneScore2(String s, int depth) {
		return map.getZoneScore2(s, depth);
	}
	
	public synchronized List<String> getUnprobedWithin(String start, int depth){
		return map.getUnprobedWithin(start, depth);
	}

	public synchronized int getDistance(String string, String myPos, int maxEnergy) {
		return map.getDistance(string, myPos, maxEnergy);
	}

	public synchronized List<String> getAdjacentVerticies(String myPos) {
		return map.getAdjacentVerticies(myPos);
	}
}
