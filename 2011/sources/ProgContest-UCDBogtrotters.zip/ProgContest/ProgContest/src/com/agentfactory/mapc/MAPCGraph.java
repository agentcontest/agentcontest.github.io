package com.agentfactory.mapc;

import java.util.ArrayList;

import graph.util.Heap;
import graph.util.Position;
import graph.util.PriorityQueue;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Stack;

public class MAPCGraph {
	public static final int UNEXPLORED = 0;
	public static final int VISITED = 1;
	public static final int DISCOVERY = 2;
	public static final int CROSS = 3;
	public static final int BACK = 4;

	// We view the known parts of the map as clouds, and store
	// them in the map below. Whenever we add a new edge, we
	// check if the endpoints are in the same cloud, and if
	// not, we merge the clouds of the endpoints.
	private Map<Vertex, LinkedList<Vertex>> cloudMap;

	private Map<String, Vertex> verticies;
	private int noVerticies = 0;
	private List<Edge> edges;
	private int noEdges = 0;

	public MAPCGraph() {
		verticies = new HashMap<String, Vertex>();
		edges = new LinkedList<Edge>();
		cloudMap = new HashMap<Vertex, LinkedList<Vertex>>();
	}

	public Vertex[] endVertices(Edge v) {
		return v.getEnds();
	}

	public Vertex opposite(Vertex v, Edge e) {
		if (e.contains(v)) {
			return e.opposite(v);
		} else
			return null;
	}

	public boolean areAdjacent(Vertex v, Vertex w) {
		for (Edge e : v.getEdges()) {
			if (e.contains(w))
				return true;
		}
		return false;
	}

	public Vertex insertVertex(Vertex o) {
		if (verticies.get(o.name) == null) {
			noVerticies++;

			// Add a new cloud for the vertex...
			LinkedList<Vertex> list = new LinkedList<Vertex>();
			list.add(o);
			this.cloudMap.put(o, list);

			return verticies.put(o.name, o);
		} else
			return verticies.get(o.name);
	}

	public Edge insertEdge(String v, String w, int cost) {
		Vertex v1 = verticies.get(v);
		Vertex v2 = verticies.get(w);

		return insertEdge(v1, v2, cost);
	}

	public boolean connected(String v, String w) {
		Vertex v1 = verticies.get(v);
		Vertex v2 = verticies.get(w);
		if ((cloudMap.get(v1)== null) || (cloudMap.get(v2) == null)) return false;
		return cloudMap.get(v1).equals(cloudMap.get(v2));
	}

	public List<Edge> incidentEdges(Vertex v) {
		List<Edge> list = new LinkedList<Edge>();
		for (Edge e : edges) {
			if (e.contains(v))
				list.add(e);
		}
		return list;
	}

	public Iterable<Vertex> vertices() {
		return verticies.values();
	}

	public Iterable<Edge> edges() {
		return edges;
	}

	public boolean isConnected() {
		Iterator<String> i = verticies.keySet().iterator();
		HashMap<String, Boolean> map = new HashMap<String, Boolean>();
		Stack<Vertex> stack = new Stack<Vertex>();
		for (Vertex vertex : verticies.values()) {
			map.put(vertex.name, false);
		}

		if (i.hasNext())
			stack.push(verticies.get(i.next()));
		int count = 0;
		while (!stack.isEmpty()) {
			Vertex v = stack.pop();
			if (!map.get(v.name)) {
				map.put(v.name, true);
				count++;
				for (Edge e : v.getEdges()) {
					Vertex temp = e.opposite(v);
					if (map.get(temp.name) == null) {
						stack.push(temp);
					}
				}
			}
		}
		return count == noVerticies;
	}

	public int getNoEdges() {
		return noEdges;
	}

	public int getNoVerticies() {
		return noVerticies;
	}

	class PathVertex {
		String name;

		PathVertex(String name) {
			this.name = name;
		}

		boolean visited = false;
		int distance = Integer.MAX_VALUE;
	}

	public Queue<String> getLeastEnergyRoute(String end, String start) {
		if (!connected(end, start))
			return null;

		Vertex s = getVertex(start);
		Vertex v = getVertex(end);

		PriorityQueue<Integer, Vertex> Q = new Heap<Integer, Vertex>();

		graph.util.List<Vertex> spVertexList = new graph.util.LinkedList<Vertex>();

		Map<Vertex, Integer> distanceMap = new HashMap<Vertex, Integer>();
		Map<Vertex, Edge> parentMap = new HashMap<Vertex, Edge>();
		Map<Vertex, Position<Vertex>> positionMap = new HashMap<Vertex, Position<Vertex>>();
		for (Vertex vertex : verticies.values()) {
			int value = Integer.MAX_VALUE;
			if (vertex.equals(s))
				value = 0;
			distanceMap.put(vertex, value);
			Position<Vertex> p = Q.insert(value, vertex);
			positionMap.put(vertex, p);
		}

		while (!Q.isEmpty()) {
			Vertex u = Q.remove();
			for (Edge e : u.getEdges()) {
				Vertex z = e.opposite(u);
				int r = distanceMap.get(u) + e.weight;
				if (r < distanceMap.get(z)) {
					distanceMap.put(z, r);
					Q.replaceKey(positionMap.get(z), r);
					parentMap.put(z, e);
				}
			}
		}

		while (!v.equals(s)) {
			spVertexList.insertFirst(v);
			Edge e = parentMap.get(v);
			// spEdgeList.insertFirst(e);
			v = e.opposite(v);
		}
		spVertexList.insertFirst(v);

		Queue<String> ret = new LinkedList<String>();
		boolean first = true;
		for (Vertex z : spVertexList) {

			if (first) {
				first = false;
			} else {
				ret.add(z.name);
			}
		}
		return ret;
	}

	public Queue<String> BFsearch(String start, String endS, int depth, int maxEnergy) {
		Map<Vertex, Integer> vertexLabels = new HashMap<Vertex, Integer>();
		Map<Edge, Integer> edgeLabels = new HashMap<Edge, Integer>();
		for (Vertex vertex : vertices()) {
			vertexLabels.put(vertex, UNEXPLORED);
		}
		for (Edge edge : edges()) {
			edgeLabels.put(edge, UNEXPLORED);
		}

		graph.util.List<Vertex> current = new graph.util.LinkedList<Vertex>();
		Vertex s = getVertex(start);
		Vertex end = getVertex(endS);
		if ((s == null) || (end == null)) return null;
		current.insertLast(s);
		vertexLabels.put(s, VISITED);

		int d = 0;
		boolean bre = false;
		Map<Vertex, Edge> parentMap = new HashMap<Vertex, Edge>();
		while (!current.isEmpty() && d < depth) {
			graph.util.List<Vertex> next = new graph.util.LinkedList<Vertex>();
			for (Vertex v : current) {
				if (!bre) {
					for (Edge e : v.getEdges()) {
						if (edgeLabels.get(e) == UNEXPLORED) {
							if (maxEnergy >= e.weight) {
								Vertex w = e.opposite(v);
								if (vertexLabels.get(w) == UNEXPLORED) {
									edgeLabels.put(e, DISCOVERY);
									vertexLabels.put(w, VISITED);
									next.insertLast(w);
									parentMap.put(w, e);
									if (w.equals(end)) {
										bre = true;
										break;
									}
								} else {
									edgeLabels.put(e, CROSS);
								}
							} else {
								edgeLabels.put(e, CROSS);
							}
						}
					}
				}
			}
			current = next;
			d++;
		}
		if (!bre)
			return null;
		graph.util.List<Vertex> spVertexList = new graph.util.LinkedList<Vertex>();
		while (!end.equals(s)) {
			spVertexList.insertFirst(end);
			Edge e = parentMap.get(end);
			end = e.opposite(end);
		}

		Queue<String> ret = new LinkedList<String>();
		for (Vertex z : spVertexList) {
			ret.add(z.name);
		}
		return ret;
	}

	public Queue<String> BFVsearch(String start, boolean probed, int depth) {
		Map<Vertex, Integer> vertexLabels = new HashMap<Vertex, Integer>();
		Map<Edge, Integer> edgeLabels = new HashMap<Edge, Integer>();
		for (Vertex vertex : vertices()) {
			vertexLabels.put(vertex, UNEXPLORED);
		}
		for (Edge edge : edges()) {
			edgeLabels.put(edge, UNEXPLORED);
		}

		graph.util.List<Vertex> current = new graph.util.LinkedList<Vertex>();
		Vertex s = getVertex(start);
		current.insertLast(s);
		vertexLabels.put(s, VISITED);
		Vertex end = null;
		int d = 0;
		boolean bre = false;
		Map<Vertex, Edge> parentMap = new HashMap<Vertex, Edge>();
		while (!current.isEmpty() && d < depth) {
			graph.util.List<Vertex> next = new graph.util.LinkedList<Vertex>();
			for (Vertex v : current) {
				if (!bre) {
					for (Edge e : v.getEdges()) {
						if (edgeLabels.get(e) == UNEXPLORED) {
							Vertex w = e.opposite(v);
							if (vertexLabels.get(w) == UNEXPLORED) {
								edgeLabels.put(e, DISCOVERY);
								vertexLabels.put(w, VISITED);
								next.insertLast(w);
								parentMap.put(w, e);
								if (probed) {
									if (!w.probed) {
										end = w;
										bre = true;
										break;
									}
								} else {
									if (!w.surveyed) {
										end = w;
										bre = true;
										break;
									}
								}
							} else {
								edgeLabels.put(e, CROSS);
							}
						}
					}
				}
			}
			current = next;
			d++;
		}
		if (end == null)
			return null;
		graph.util.List<Vertex> spVertexList = new graph.util.LinkedList<Vertex>();
		while (!end.equals(s)) {
			spVertexList.insertFirst(end);
			Edge e = parentMap.get(end);
			end = e.opposite(end);
		}

		Queue<String> ret = new LinkedList<String>();
		for (Vertex z : spVertexList) {
			ret.add(z.name);
		}
		return ret;
	}

	public List<String> getUnprobedWithin(String start, int depth) {
		Map<Vertex, Integer> vertexLabels = new HashMap<Vertex, Integer>();
		Map<Edge, Integer> edgeLabels = new HashMap<Edge, Integer>();
		for (Vertex vertex : vertices()) {
			vertexLabels.put(vertex, UNEXPLORED);
		}
		for (Edge edge : edges()) {
			edgeLabels.put(edge, UNEXPLORED);
		}

		graph.util.List<Vertex> current = new graph.util.LinkedList<Vertex>();
		Vertex s = getVertex(start);
		if (s == null) return new LinkedList<String>();
		current.insertLast(s);
		vertexLabels.put(s, VISITED);
		int d = 0;
		Map<Vertex, Edge> parentMap = new HashMap<Vertex, Edge>();
		List<String> unprobed = new LinkedList<String>();
		if (!s.probed)
			unprobed.add(s.name);

		while (!current.isEmpty() && d < depth) {
			graph.util.List<Vertex> next = new graph.util.LinkedList<Vertex>();
			for (Vertex v : current) {
				for (Edge e : v.getEdges()) {
					if (edgeLabels.get(e) == UNEXPLORED) {
						Vertex w = e.opposite(v);
						if (vertexLabels.get(w) == UNEXPLORED) {
							edgeLabels.put(e, DISCOVERY);
							vertexLabels.put(w, VISITED);
							next.insertLast(w);
							parentMap.put(w, e);
							if (!w.probed) {
								unprobed.add(w.name);
							}
						} else {
							edgeLabels.put(e, CROSS);
						}
					}
				}
			}
			current = next;
			d++;
		}
		return unprobed;
	}

	public int getDistance(String s, String e, int energy) {
		Queue<String> q = BFsearch(s, e, 10, energy);
		if (q == null)
			return Integer.MAX_VALUE;
		else
			return q.size();
	}

	public Queue<String> getRoute(String endVertex, String startVertex, int maxCost) {
		// Check if the vertices are connected, and if not, don't
		// even try to get a route.
		if (!connected(endVertex, startVertex))
			return null;

		LinkedList<PathVertex> heap = new LinkedList<PathVertex>();
		Comparator<PathVertex> c = new Comparator<PathVertex>() {
			public int compare(PathVertex o1, PathVertex o2) {
				return o1.distance - o2.distance;
			}
		};
		Collections.sort(heap, c);
		HashMap<String, Edge> pMap = new HashMap<String, Edge>();
		HashMap<String, PathVertex> vMap = new HashMap<String, PathVertex>();
		for (Vertex v : verticies.values()) {
			PathVertex p = new PathVertex(v.name);
			if (p.name.equals(startVertex)) {
				p.distance = 0;
			}
			vMap.put(p.name, p);
			heap.add(p);
		}
		Collections.sort(heap, c);
		while (!heap.isEmpty()) {
			PathVertex current = heap.remove();
			Vertex v = verticies.get(current.name);
			for (Edge e : v.getEdges()) {
				if (e.weight <= maxCost) {
					Vertex o = e.opposite(v);
					PathVertex x = vMap.get(o.name);
					if (x.distance > (current.distance + e.weight)) {
						x.distance = current.distance + e.weight;
						Collections.sort(heap, c);
						pMap.put(x.name, e);
					}
				}
			}
		}

		Queue<String> route = new LinkedList<String>();
		PathVertex p = vMap.get(endVertex);
		if (p == null)
			return null;
		PathVertex s = vMap.get(startVertex);
		while (!p.equals(s)) {
			route.offer(p.name);
			Edge e = pMap.get(p.name);
			p = vMap.get(e.opposite(verticies.get(p.name)).name);
		}
		route.offer(s.name);
		route.poll();

		return route;

	}

	public void printClouds() {
		System.out.println("\n\nCloud Map: ");
		for (Vertex v : cloudMap.keySet()) {
			System.out.println("[" + v.name + "] " + cloudMap.get(v));
		}
	}

	public Vertex getVertex(String vertex) {
		return verticies.get(vertex);
	}

	public Edge insertEdge(Vertex v1, Vertex v2, int cost) {
		if (!cloudMap.get(v1).equals(cloudMap.get(v2))) {
			// join the 2 clouds together...
			Iterator<Vertex> it = cloudMap.get(v1).iterator();
			while (it.hasNext()) {
				cloudMap.get(v2).addLast(it.next());
			}

			it = cloudMap.get(v1).iterator();
			while (it.hasNext()) {
				cloudMap.put(it.next(), cloudMap.get(v2));
			}
		}

		Edge e = new Edge(v1, v2, cost);
		for (Edge ed : edges) {
			if (ed.equals(e))
				return ed;
		}
		noEdges++;
		v1.addEdge(e);
		v2.addEdge(e);
		edges.add(e);
		return e;
	}

	public List<String> getExplorationVertices(int noAgents, int distance, String vertex) {
		List<String> list = new ArrayList<String>();
		int d = 0;
		int chosen = 0;
		List<Vertex> currentLevel = new ArrayList<Vertex>();
		LinkedList<Vertex> all = new LinkedList<Vertex>();
		currentLevel.add(getVertex(vertex));
		while (d <= distance && chosen <= noAgents) {
			List<Vertex> nextLevel = new ArrayList<Vertex>();
			for (Vertex current : currentLevel) {
				for (Edge edge : current.getEdges()) {
					Vertex opposite = edge.opposite(current);
					if (!opposite.probed && !(++chosen > noAgents))
						nextLevel.add(opposite);
				}
			}
			d++;
			currentLevel = nextLevel;
			all.addAll(nextLevel);
		}
		List<String> strigns = new ArrayList<String>();
		for (int i = 0; i < noAgents; i++) {
			Vertex v = all.get(i);
			strigns.add("goto(" + v.name + ")");
		}
		return list;
	}

	public List<String> notsure2(int distance, String vertex) {
		List<String> list = new ArrayList<String>();
		int d = 0;
		List<Vertex> currentLevel = new ArrayList<Vertex>();
		LinkedList<Vertex> all = new LinkedList<Vertex>();
		currentLevel.add(getVertex(vertex));
		while (d <= distance) {
			List<Vertex> nextLevel = new ArrayList<Vertex>();
			for (Vertex current : currentLevel) {
				for (Edge edge : current.getEdges()) {
					Vertex opposite = edge.opposite(current);
					if (!opposite.probed)
						nextLevel.add(opposite);
				}
			}
			d++;
			currentLevel = nextLevel;
			all.addAll(nextLevel);
		}
		List<String> strigns = new ArrayList<String>();
		for (Vertex v : all)
			strigns.add("goto(" + v.name + ")");
		return list;
	}

	public Map<String, List<Vertex>> getRegions(String start, int depth, int extra) {
		Map<String, List<Vertex>> zones = new HashMap<String, List<Vertex>>();
		// zones.put("outer", new LinkedList<Vertex>());
		zones.put("home", new LinkedList<Vertex>());
		zones.put("danger", new LinkedList<Vertex>());

		// for (Vertex v : this.vertices()) {
		// zones.get("outer").add(v);
		// }

		Map<Vertex, Integer> vertexLabels = new HashMap<Vertex, Integer>();
		Map<Edge, Integer> edgeLabels = new HashMap<Edge, Integer>();
		for (Vertex vertex : vertices()) {
			vertexLabels.put(vertex, UNEXPLORED);
		}
		for (Edge edge : edges()) {
			edgeLabels.put(edge, UNEXPLORED);
		}

		graph.util.List<Vertex> current = new graph.util.LinkedList<Vertex>();
		Vertex s = getVertex(start);
		if (s == null) {
			return zones;
		}
		current.insertLast(s);
		vertexLabels.put(s, VISITED);
		int d = 0;
		Map<Vertex, Edge> parentMap = new HashMap<Vertex, Edge>();
		while (!current.isEmpty() && d < depth + extra) {
			graph.util.List<Vertex> next = new graph.util.LinkedList<Vertex>();
			for (Vertex v : current) {
				for (Edge e : v.getEdges()) {
					if (edgeLabels.get(e) == UNEXPLORED) {
						Vertex w = e.opposite(v);
						if (vertexLabels.get(w) == UNEXPLORED) {
							edgeLabels.put(e, DISCOVERY);
							vertexLabels.put(w, VISITED);
							next.insertLast(w);
							parentMap.put(w, e);

							if (d < depth) {
								zones.get("home").add(w);
							} else if (d < depth + extra) {
								zones.get("danger").add(w);
							}
						} else {
							edgeLabels.put(e, CROSS);
						}
					}
				}
			}
			current = next;
			d++;
		}
		return zones;
	}

	public String getHighestValueVertex() {
		int max = Integer.MIN_VALUE;
		String s = null;
		for (Vertex v : verticies.values()) {
			int i = getClusterValue(v.name, 3);
			// System.out.println("ClusterValue "+ v.name+ " "+i);
			if (i > max) {
				max = i;
				s = v.name;
			}

		}
		if (s == null)
			return null;
		return s;
	}

	public Integer getClusterValue(String start, int depth) {
		Map<Vertex, Integer> vertexLabels = new HashMap<Vertex, Integer>();
		Map<Edge, Integer> edgeLabels = new HashMap<Edge, Integer>();
		int clusterValue = 0;
		for (Vertex vertex : vertices()) {
			vertexLabels.put(vertex, UNEXPLORED);
		}
		for (Edge edge : edges()) {
			edgeLabels.put(edge, UNEXPLORED);
		}

		graph.util.List<Vertex> current = new graph.util.LinkedList<Vertex>();
		Vertex s = getVertex(start);
		current.insertLast(s);
		clusterValue = s.value;
		vertexLabels.put(s, VISITED);
		int d = 0;
		Map<Vertex, Edge> parentMap = new HashMap<Vertex, Edge>();
		while (!current.isEmpty() && d < depth) {
			graph.util.List<Vertex> next = new graph.util.LinkedList<Vertex>();
			for (Vertex v : current) {
				for (Edge e : v.getEdges()) {
					if (edgeLabels.get(e) == UNEXPLORED) {
						Vertex w = e.opposite(v);
						if (vertexLabels.get(w) == UNEXPLORED) {
							edgeLabels.put(e, DISCOVERY);
							vertexLabels.put(w, VISITED);
							next.insertLast(w);
							parentMap.put(w, e);
							clusterValue += w.value;

						} else {
							edgeLabels.put(e, CROSS);
						}
					}
				}
			}
			current = next;
			d++;
		}
		return clusterValue;
	}

	class ZoneScore {
		List<String> nodes;
		int cumulativeScore;
		List<String> positions;
		int minAgents;
		LinkedList<String> unprobed;

		ZoneScore(graph.util.List<Vertex> next, int val, LinkedList<String> unprobed) {
			this.unprobed = unprobed;
			nodes = new LinkedList<String>();
			cumulativeScore = val;
			List<Vertex> list = new LinkedList<Vertex>();
			for (Vertex vertex : next) {
				nodes.add(vertex.name);
				list.add(vertex);
				if (!vertex.probed) {
					unprobed.add(vertex.name);
				}
				// cumulativeScore += vertex.value;
			}
			positions = calculatePositions(list);
			minAgents = positions.size();
		}

		public String toString() {
			String r = "\nZone with cumulative score of " + cumulativeScore + "\nWith outer nodes: " + nodes;
			r += "\nRequiring " + minAgents + " agents with positions " + positions + "\n";
			return r;

		}

		List<String> calculatePositions(List<Vertex> next) {
			List<Vertex> pos = new LinkedList<Vertex>();
			List<Vertex> notpos = new LinkedList<Vertex>();
			Map<Vertex, Integer> linkMap = new HashMap<Vertex, Integer>();
			Map<Vertex, List<Vertex>> nMap = new HashMap<Vertex, List<Vertex>>();

			for (Vertex vertex : next) { // calculate link map
				linkMap.put(vertex, 0);
				notpos.add(vertex);
				List<Vertex> neigh = new LinkedList<Vertex>();
				for (Edge e : vertex.getEdges()) {
					Vertex o = e.opposite(vertex);
					if (next.contains(o)) {
						linkMap.put(vertex, (linkMap.get(vertex)) + 1);
						neigh.add(o);
					}
				}
				// System.out.println(vertex.name+ " has "+neigh+" neighbours at this level");
				nMap.put(vertex, neigh);
			}

			for (Vertex vertex : next) { // assign nodes which cannot be owned
											// by owing neighbours
				int c = 0;
				for (Edge e : vertex.getEdges()) {
					if (nodes.contains(e.opposite(vertex)))
						c++;
				}
				if (linkMap.get(vertex) < 2) {
					pos.add(vertex);
					notpos.remove(vertex);
					// System.out.println("pos: "+pos +"\nnotpos: "+ notpos);
				}
			}

			while (!allOwned(next, pos)) { // while not all owned
				// System.out.println("pos: "+pos +"\nnotpos: "+ notpos);
				for (Vertex vertex : notpos) {
					List<Vertex> v = nMap.get(vertex);
					int neighbourCount = 0;
					for (Vertex vertex2 : v) {
						if (pos.contains(vertex2))
							neighbourCount++;
					}
					if (neighbourCount >= 2) {
						notpos.remove(vertex);
						break;
					} else if (neighbourCount == 1) {
						boolean bre = false;
						for (Vertex vertex2 : v) {
							if (!pos.contains(vertex2)) {
								pos.add(vertex2);
								notpos.remove(vertex2);
								bre = true;
								break;
							}
						}
						if (bre)
							break;
					} else {
						pos.add(vertex);
						notpos.remove(vertex);
						break;
					}
				}
			}
			List<String> p = new LinkedList<String>();
			for (Vertex vertex : pos) {
				p.add(vertex.name);
			}
			return p;
		}

		boolean allOwned(List<Vertex> nodes, List<Vertex> positions) {
			// System.out.println("nodes "+ nodes +" positions "+ positions);
			for (Vertex vertex : nodes) {
				if (!positions.contains(vertex)) {
					int neighbourCount = 0;
					for (Edge e : vertex.getEdges()) {
						Vertex o = e.opposite(vertex);
						if (positions.contains(o))
							neighbourCount++;
					}
					if (neighbourCount < 2)
						return false;
				}
			}
			return true;
		}

	}

	public Map<Integer, List<Vertex>> getZoneScore2(String start, int depth) {
		Map<Integer, List<Vertex>> zones = new HashMap<Integer, List<Vertex>>();
		Map<Vertex, Integer> vertexLabels = new HashMap<Vertex, Integer>();
		Map<Edge, Integer> edgeLabels = new HashMap<Edge, Integer>();
		for (Vertex vertex : vertices()) {
			vertexLabels.put(vertex, UNEXPLORED);
		}
		for (Edge edge : edges()) {
			edgeLabels.put(edge, UNEXPLORED);
		}

		graph.util.List<Vertex> current = new graph.util.LinkedList<Vertex>();
		Vertex s = getVertex(start);
		if(s==null) {
			System.out.println("shit");
		}
		
		current.insertLast(s);
		LinkedList<String> unprobed = new LinkedList<String>();
		if (!s.probed)
			unprobed.add(s.name);
		vertexLabels.put(s, VISITED);
		int d = 0;
		Map<Vertex, Edge> parentMap = new HashMap<Vertex, Edge>();
		while (!current.isEmpty() && d < depth) {
			graph.util.List<Vertex> next = new graph.util.LinkedList<Vertex>();
			for (Vertex v : current) {
				for (Edge e : v.getEdges()) {
					if (edgeLabels.get(e) == UNEXPLORED) {
						Vertex w = e.opposite(v);
						if (vertexLabels.get(w) == UNEXPLORED) {
							edgeLabels.put(e, DISCOVERY);
							vertexLabels.put(w, VISITED);
							next.insertLast(w);
							parentMap.put(w, e);
							if (!w.probed)
								unprobed.add(w.name);
						} else {
							edgeLabels.put(e, CROSS);
						}
					}
				}
			}
			current = next;
			
			// Filter list for zone
			List<Vertex> filtered = new LinkedList<Vertex>();
			for (Vertex v : next) {
				if (filtered.isEmpty()) {
					filtered.add(v);
				} else {
					boolean adjacent = false;
					for(Vertex v2 : filtered) {
						if (this.areAdjacent(v, v2)) adjacent = true;
					}
					
					if (!adjacent) filtered.add(v);
				}
			}
//			if (!filtered.isEmpty()) filtered.add(0, filtered.get(0));
			filtered.add(0, s);
//			System.out.println("Filtered: " + filtered);
			zones.put(d, filtered);

			d++;
		}
		return zones;
	}
	
	public Map<Integer, ZoneScore> getZoneScore(String start, int depth) {
		Map<Integer, ZoneScore> zones = new HashMap<Integer, ZoneScore>();
		Map<Vertex, Integer> vertexLabels = new HashMap<Vertex, Integer>();
		Map<Edge, Integer> edgeLabels = new HashMap<Edge, Integer>();
		int clusterValue = 0;
		for (Vertex vertex : vertices()) {
			vertexLabels.put(vertex, UNEXPLORED);
		}
		for (Edge edge : edges()) {
			edgeLabels.put(edge, UNEXPLORED);
		}

		graph.util.List<Vertex> current = new graph.util.LinkedList<Vertex>();
		Vertex s = getVertex(start);
		current.insertLast(s);
		LinkedList<String> unprobed = new LinkedList<String>();
		if (!s.probed)
			unprobed.add(s.name);
		clusterValue = s.value;
		vertexLabels.put(s, VISITED);
		int d = 0;
		Map<Vertex, Edge> parentMap = new HashMap<Vertex, Edge>();
		while (!current.isEmpty() && d < depth) {
			graph.util.List<Vertex> next = new graph.util.LinkedList<Vertex>();
			for (Vertex v : current) {
				for (Edge e : v.getEdges()) {
					if (edgeLabels.get(e) == UNEXPLORED) {
						Vertex w = e.opposite(v);
						if (vertexLabels.get(w) == UNEXPLORED) {
							edgeLabels.put(e, DISCOVERY);
							vertexLabels.put(w, VISITED);
							next.insertLast(w);
							parentMap.put(w, e);
							clusterValue += w.value;

						} else {
							edgeLabels.put(e, CROSS);
						}
					}
				}
			}
			current = next;
			if (d == 1) {
				System.out.println("Level 2 Vertices: " + next);
				graph.util.List<Vertex> filtered = new graph.util.LinkedList<Vertex>();
				for (Vertex v : next) {
					if (filtered.isEmpty()) {
						filtered.insertLast(v);
					} else {
						boolean adjacent = false;
						for(Vertex v2 : filtered) {
							if (this.areAdjacent(v, v2)) adjacent = true;
						}
						
						if (!adjacent) filtered.insertLast(v);
					}
				}
				System.out.println("Filtered: " + filtered);
				next = filtered;
			}
			// System.out.println("adding next "+ next);
			long st = System.currentTimeMillis();
			if (d == 0)
				zones.put(d, new ZoneScore(next, clusterValue, (LinkedList<String>) unprobed.clone()));
			else
				zones.put(d, new ZoneScore(next, clusterValue, (LinkedList<String>) zones.get(d - 1).unprobed.clone()));
			long e = System.currentTimeMillis();
			// System.out.println("zone selection took " +(e-st));
			d++;
		}
		return zones;
	}

	public static void main(String args[]) {
		MAPCGraph d = new MAPCGraph();
		d.insertVertex(new Vertex("v1"));
		d.insertVertex(new Vertex("v2"));
		d.insertEdge("v1", "v2", 7);
		d.insertVertex(new Vertex("v3"));
		d.insertEdge("v1", "v3", 2);
		d.insertEdge("v2", "v3", 8);
		d.insertVertex(new Vertex("v4"));
		d.insertVertex(new Vertex("v5"));
		d.insertVertex(new Vertex("v6"));
		d.insertVertex(new Vertex("v7"));
		d.insertEdge("v1", "v4", 2);
		d.insertEdge("v3", "v6", 2);
		d.insertEdge("v4", "v5", 2);
		d.insertEdge("v5", "v7", 2);
		d.insertEdge("v6", "v7", 3);

		long start = System.currentTimeMillis();
		System.out.println(d.getRoute("v7", "v2", 90));
		long inter = System.currentTimeMillis();
		System.out.println(d.getLeastEnergyRoute("v2", "v7"));
		long end = System.currentTimeMillis();
//		System.out.println(d.BFsearch("v7", "v2", 5));
		long end2 = System.currentTimeMillis();
		System.out.println("time for old sp " + (inter - start) + "\ntime for new sp " + (end - inter) + "\ntime for BF " + (end2 - end));
		d = new MAPCGraph();
		d.insertVertex(new Vertex("v1"));
		d.insertVertex(new Vertex("v2"));
		d.insertVertex(new Vertex("v3"));
		d.insertVertex(new Vertex("v4"));
		d.insertVertex(new Vertex("v5"));
		d.insertVertex(new Vertex("v6"));
		d.insertVertex(new Vertex("v7"));
		d.insertVertex(new Vertex("v8"));
		d.insertVertex(new Vertex("v9"));
		d.insertVertex(new Vertex("v10"));
		d.insertVertex(new Vertex("v11"));
		d.insertEdge("v1", "v2", 2);
		d.insertEdge("v1", "v3", 2);
		d.insertEdge("v1", "v4", 2);
		d.insertEdge("v1", "v5", 2);

		d.insertEdge("v2", "v3", 2);
		d.insertEdge("v2", "v7", 2);
		d.insertEdge("v2", "v8", 2);

		d.insertEdge("v3", "v9", 2);
		d.insertEdge("v3", "v10", 2);
		d.insertEdge("v3", "v4", 2);

		d.insertEdge("v4", "v5", 2);
		d.insertEdge("v4", "v11", 2);
		d.insertEdge("v4", "v6", 2);

		d.insertEdge("v6", "v7", 2);

		d.insertEdge("v7", "v8", 2);

		d.insertEdge("v8", "v9", 2);

		d.insertEdge("v9", "v10", 2);

		System.out.println(d.getZoneScore("v1", 3));
	}

	public List<String> getAdjacentVerticies(String myPos) {
		Vertex v = getVertex(myPos);
		List<String> l = new LinkedList<String>();
		if(v!=null){
		for (Edge e : v.getEdges()) {
			l.add(e.opposite(v).name + "," + e.weight);
		}
		}
		return l;
	}
}
