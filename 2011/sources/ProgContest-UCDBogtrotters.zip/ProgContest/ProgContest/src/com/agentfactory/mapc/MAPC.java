package com.agentfactory.mapc;
import java.util.HashMap;
import java.util.Map;

import com.agentfactory.eis.EISDebugConfiguration;

/**
 * Example Main class that illustrates how to deploy a basic Agent Factory
 * application.
 *
 * @author rem
 */
public class MAPC {
	static class MAPCConfig extends EISDebugConfiguration {

		public MAPCConfig(Map<String, String> designs) {
			super("mapc", designs, "eismassim-1.0.3.jar");
		}
		
		public void configure() {
			super.configure();
			
			addPlatformService(MapService2.class, "graph");
			addPlatformService(GroupService.class, "groups");
			
			addAgent("leader", "com/agentfactory/mapc/Leader.aspeak");
			this.resumeAgent("leader");
			this.resumeAgent("manager");
		}
		
	}
    public static void main(String[] args) {
    	Map<String, String> designs = new HashMap<String, String>();
    	designs.put("a1", "com/agentfactory/mapc/EAATPV.aftr");
    	designs.put("a2", "com/agentfactory/mapc/EAATPV.aftr");
    	designs.put("a3", "com/agentfactory/mapc/EAATPV.aftr");
    	designs.put("a4", "com/agentfactory/mapc/EAATPV.aftr");
    	designs.put("a5", "com/agentfactory/mapc/EAATPV.aftr");
    	designs.put("a6", "com/agentfactory/mapc/EAATPV.aftr");
    	designs.put("a7", "com/agentfactory/mapc/EAATPV.aftr");
    	designs.put("a8", "com/agentfactory/mapc/EAATPV.aftr");
    	designs.put("a9", "com/agentfactory/mapc/EAATPV.aftr");
    	designs.put("a10", "com/agentfactory/mapc/EAATPV.aftr");
    	
    	designs.put("UCDBogtrotters1", "com/agentfactory/mapc/EAATPV.aftr");
    	designs.put("UCDBogtrotters2", "com/agentfactory/mapc/EAATPV.aftr");
    	designs.put("UCDBogtrotters3", "com/agentfactory/mapc/EAATPV.aftr");
    	designs.put("UCDBogtrotters4", "com/agentfactory/mapc/EAATPV.aftr");
    	designs.put("UCDBogtrotters5", "com/agentfactory/mapc/EAATPV.aftr");
    	designs.put("UCDBogtrotters6", "com/agentfactory/mapc/EAATPV.aftr");
    	designs.put("UCDBogtrotters7", "com/agentfactory/mapc/EAATPV.aftr");
    	designs.put("UCDBogtrotters8", "com/agentfactory/mapc/EAATPV.aftr");
    	designs.put("UCDBogtrotters9", "com/agentfactory/mapc/EAATPV.aftr");
    	designs.put("UCDBogtrotters10", "com/agentfactory/mapc/EAATPV.aftr");


    	new MAPCConfig(designs).configure();
    }
}
