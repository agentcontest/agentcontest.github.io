package com.agentfactory.mapc;

import java.util.LinkedList;
import java.util.List;

public 	class Vertex {
	String name;
	String team;
	boolean probed =false;
	boolean surveyed = false;
	int value =1;
	private List<Edge> edges;
	
	public Vertex(String name, String team, boolean probed, boolean surveyed){
		this.name = name;
		this.team = team;
		this.probed = probed;
		this.surveyed = surveyed;
		edges = new LinkedList<Edge>();
	}
	
	public Vertex(String n) {
		this.name = n;
		edges = new LinkedList<Edge>();
	}
	
	public String toString() {
		return name;
	}
	
	public boolean equals(Object o){
		if(Vertex.class.isInstance(o)){
			Vertex other = (Vertex)o;
			if(other.name.equals(name))
				return true;
			else 
				return false;
		} else		
		return false;
	}

	public void addEdge(Edge e) {
		edges.add(e);
	}

	public List<Edge> getEdges() {
		return edges;
	}
}