package com.agentfactory.mapc;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.agentfactory.platform.impl.AbstractPlatformService;

public class GroupService extends AbstractPlatformService {
	private Map<String, Group> groups;
	private Map<String, Member> register;
	private Map<String, String> shared;
	
	public GroupService() {
		groups = new HashMap<String, Group>();
		register = new HashMap<String, Member>();
		shared = new HashMap<String, String>();
	}

	public void reset() {
		for (Group group : groups.values()) {
			group.reset();
		}
		
		register = Collections.synchronizedMap(new HashMap<String, Member>());
	}
	
	public synchronized void addRequest(String grp, String mess) {
		groups.get(grp).addRequest(mess);
	}
	
	public synchronized void setHomeVertex(String grp, String v) {
		groups.get(grp).homeVertex = v;
	}

	public boolean create(String owner, String name) {
		return create(owner, name, new LinkedList<String>());
	}
	
	public boolean create(String owner, String name, List<String> roles) {
		if (groups.containsKey(name)) return false;
		groups.put(name, new Group(name, owner, roles));
		return true;
	}
	
	public void register(Member member) {
		register.put(member.name, member);
		
		assign(member);
	}
	
	public synchronized void setTask(String name, String grp, List<String> task) {
		groups.get(grp).setTasks(name, task);
	}
	
	public synchronized void setGroupTask(String grp, List<String> task) {
		groups.get(grp).setGroupTasks(task);
	}
	
	public synchronized void addTask(String name, String grp, List<String> task) {
		groups.get(grp).addTasks(name, task);
	}
	
	public synchronized void removeTask(String name) {
		Member member = register.get(name);
		if (member != null && member.group != null) {
			groups.get(member.group).removeTask(name);
		}
	}
	
	public synchronized boolean assign(String name) {
		return assign(register.get(name));
	}
	
	public synchronized boolean assign(Member member) {
		// Auto assign member to a group (if one exists)
		for (Group group : groups.values()) {
			if (group.availableRoles().contains(member.role)) {
				group.addMember(member);
				member.group = group.name;
				return true;
			}
		}
		return false;
	}
	
	public Member getMember(String name) {
		return register.get(name);
	}
	
	public List<String> getAvailableRoles(String grp) {
		return groups.get(grp).availableRoles();
	}
	public boolean join(String grp, String name) {
		Group group = groups.get(grp);
		if (group == null) return false;

		Member member = register.get(name);
		if (member == null) return false;
		
		group.addMember(member);
		return true;
	}
	
	public List<Group> groups(String name) {
		List<Group> list = new LinkedList<Group>();
		
		for (Group group: groups.values()) {
			if (group.owner.equals(name)) { 
				list.add(group);
			} else {
//				if (group.hasMember(name)) {
					list.add(group);
//				}
			}
		}
		return list;
	}
	
	public List<String> groupNames() {
		List<String> list = new LinkedList<String>();
		
		for (Group group : groups.values()) {
			list.add(group.name);
		}
		
		return list;
	}
	
	public synchronized List<Member> members() {
		List<Member> list = new LinkedList<Member>();
		for (Member m : register.values()) {
			list.add(m);
		}
		return list;
	}
	
	public void setShared(Map<String, String> shared) {
		this.shared = shared;
	}
	
	public Map<String, String> getShared() {
		return shared;
	}
}
