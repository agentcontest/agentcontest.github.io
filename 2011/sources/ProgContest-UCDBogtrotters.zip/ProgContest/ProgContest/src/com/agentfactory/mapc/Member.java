package com.agentfactory.mapc;

public class Member {
	String name;
	String role;
	String group;
	
	public Member(String name, String role) {
		this.name = name;
		this.role = role;
	}
}
