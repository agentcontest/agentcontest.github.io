from global_vars import * #@UnusedWildImport
import copy #@Reimport
from heapq import heappush, heappop #@Reimport
import random
import time


class Action():
    def __init__(self, goal, type, vertex=None, cost=0, path=[], arg='', length = 0):
        self.goal = goal
        self.type = type
        self.vertex = vertex
        self.cost = cost
        self.path = path
        self.arg = arg
        self.length = length
        
    def __eq__(self, other):
        return self.vertex == other.vertex
    def __cmp__(self, other):
        return cmp(self.vertex, other.vertex)
    def __hash__ (self):
        return self.vertex.hash
    def __repr__(self):
        return repr(self.goal)
        
class Algorithms():

        
    def bfs(self, prefix, type, start, function, count):
        explored = set()
        frontier = PriorityQueue()
        goals = []
        frontier.push(Action(prefix+start.id, type, start))
        while len(frontier) > 0:                
            current = frontier.pop()
            while len(frontier) > 0 and current.vertex in explored:
                current = frontier.pop()
                if len(frontier) == 0:
                    return goals
                    
            explored.add(current.vertex)
            function(current, goals)
            if len(goals) == count:
                return goals #sorted(goals, lambda x,y: cmp(x.cost, y.cost))
                    
            neighbours = current.vertex.neighbours.items()
            for (v,weight) in neighbours:
                if v in explored:
                    continue    


                path = copy.copy(current.path)
                path.append(v)
#                    frontier.push(Action(prefix+v.id, type, v, cost = current.cost + weight, length = current.cost + weight, path = path))
                if weight == WEIGHT:
                    l_weight = 10
                else:
                    l_weight = weight
                frontier.push(Action(prefix+v.id, type, v, cost = current.cost + weight + self.recharge_rate(), length = current.length + l_weight, path = path))

        return goals #sorted(goals, lambda x,y: cmp(x.cost, y.cost))

    def find_init(self):
        edges = 100
        value = 0
        cur = None
        for v in self.vertices.values():
            if v.value < value:
                continue
#            skip if opponent
#            if v.id in self.vertex_to_agent:
#                match = filter(lambda x: x not in self.team, self.vertex_to_agent[v.id].copy())
#                if match:
#                    match = filter(lambda x: not x in SHARED[DIS_OPP], match)
#                    if match:
#                        continue
            if v.value > value:
                cur = v
                edges = len(v.neighbours)
                value = cur.value
            if v.value == value:
                n = len(v.neighbours)
                if n < edges or (n == edges and v.id < cur.id):
                    cur = v
                    edges = n
                    value = cur.value
           
        return cur 
                     
    def calc_expand(self, avoid_opp):
        self.frontier = Set([self.expand])
        self.owned = Set([self.expand])
            
        n1_set = Set(self.expand.neighbours)
        n1_set.add(self.expand)
                   
        n2_set = Set()
        wanted_neighbours = Set()
        self.owned.update(n1_set)
        
        
        for n1 in n1_set:
            if len(self.frontier) == 6:
                break
            if avoid_opp and self.has_opponent(n1):
                continue
            for n2 in n1.neighbours:
                if avoid_opp and self.has_opponent(n2):
                    continue
                if n2 in n1_set:
                    continue

                n3_set = Set(n2.neighbours)
                self.owned.add(n2)
                self.owned.update(n3_set)
                

                if len(n2_set) == 0:
                    self.frontier.add(n2)
                    n2_set.add(n2)
                    wanted_neighbours.update(n3_set)
                    
                    
                elif len(n3_set & n2_set) == 0 and len(wanted_neighbours & n3_set) > 0:
                        self.frontier.add(n2)
                        wanted_neighbours.update(n3_set)
                        n2_set.add(n2)
                
            if len(self.frontier) == 6:
                break
        
        i = 0
        while not avoid_opp and len(self.frontier) < 6 and i < 20:
            i = i + 1
            for n1 in n1_set:
                if len(self.frontier) == 6:
                    break
                for n2 in n1.neighbours:
                    if n2 in n1_set:
                        continue
                    if not n2 in self.frontier:
                        self.frontier.add(n2)
            
            
        SHARED[EXPAND] = (self.step, self.frontier, self.owned)


    def get_expand(self):    
        i = 0
        while SHARED[EXPAND][0] < self.step and i < MAX_ROUNDS:
            time.sleep(WAIT_TIME)
            i = i + 1
        
        if i == MAX_ROUNDS:
            print self.name, 'max rounds exceeded (get_expand)'
            
        self.frontier = SHARED[EXPAND][1]
        self.owned = SHARED[EXPAND][2]
                                    
        
 
    def get_goals(self, start):
        goals = []
        # repairers and attackers keep up the good work
        if self.runtime > RUNTIME and not self.type == REP and not self.type == SAB and not self.type == EXP:
            self.get_expand()
            goals = self.bfs('expand_', NOOP, start, self.get_frontier, count = len(self.frontier)) 
        else:
        
            if self.type == INS:
                if len(SHARED[OPPONENTS]) < 10:
                    goals = self.bfs('inspect_', INSPECT, start, self.get_inspect, 2)
                elif self.runtime > RUNTIME:
                    self.get_expand()
                    goals.extend(self.bfs('expand_', NOOP, start, self.get_frontier, count = len(self.frontier)))
                    
            elif self.type == SAB: 
                if DO_ATTACK:
                    if self.runtime > RUNTIME: 
                        self.get_expand()
                        goals = self.bfs('attack_owned_', ATTACK, start, self.get_opponent_in_owned, 2)
                        for g in goals:
                            g.cost = g.cost - 100 
                        if len(goals) < 2:
                            goals.extend(self.bfs('attack_', ATTACK, start, self.get_opponent, 2))
                    else:
                        goals = self.bfs('attack_', ATTACK, start, self.get_opponent, 2) 
                else:
                    goals = self.bfs('survey_', SURVEY, start, self.is_unsurveyed, 10)   
                    
            elif self.type == SEN:
                goals = self.bfs('survey_', SURVEY, start, self.is_unsurveyed, 10)    
            elif self.type == REP:
                goals = self.bfs('repair_', REPAIR, start, self.is_broken, count = len(SHARED[DISABLED]))
                if len(goals) < 2:
                    e_goals = self.bfs('refresh_', REPAIR, start, self.get_hit, count = 2 - len(goals))
                    goals.extend(e_goals)
            elif self.type == EXP:
                self.get_expand()
                goals = self.bfs('probe_owned_', PROBE, start, self.unprobed_in_owned, 2) 
                if len(goals) < 2:    
                    if self.runtime > RUNTIME:
                        goals.extend(self.bfs('expand_', NOOP, start, self.get_frontier, count = len(self.frontier)))
                    elif len(goals) == 1:
                        goals.extend(self.bfs('probe_', PROBE, start, self.is_unprobed, 1))
                    else:
                        goals.extend(self.bfs('probe_', PROBE, start, self.is_unprobed, 2))
            
             
                
            if self.type != SEN and len(goals) < 2 and self.runtime < RUNTIME:
                extra_goals = self.bfs('survey_', SURVEY, start, self.is_unsurveyed, 10 - len(goals))
                goals.extend(extra_goals)
                if len(goals) == 0:
                    print self.type, self.name, extra_goals
                    
                if self.step > 10 and len(goals) < 10:  
                    if len(goals) == 0:
                        print self.name, 'adding expand goals'
                    self.get_expand()
                    goals.extend(self.bfs('expand_', NOOP, start, self.get_frontier, count = len(self.frontier)) )
                        
                    # we could let rep and sab stay in the "outscirts" of our frontier, to add extra value

                                            
            elif self.type == SEN and len(goals) < 10 and int(self.id) > 10:
                if len(goals) == 0:
                    print self.name, 'adding expand goals'
                    
                self.get_expand()
                goals.extend(self.bfs('expand_', NOOP, start, self.get_frontier, count = len(self.frontier)) )
                        
        while len(goals) < 10:
            goals.append(Action(self.name + '_ignore', NOOP, cost = 200))    

        return goals
              
    def get_frontier(self, v, goals):
        if v.vertex in self.frontier:
            goals.append(v)
  
    def is_unprobed(self, v, goals):
        if v.vertex.value == 0:
            goals.append(v)
    def unprobed_in_owned(self, v, goals):
        if v.vertex.value == 0 and v.vertex in self.owned:
            goals.append(v)
    def is_unsurveyed(self, v, goals):
        if not v.vertex.is_surveyed():
            goals.append(v) 
           
    def n_get_repairer(self, start):
        def har_repairer(v, goals):
            if v.vertex.id in self.vertex_to_agent:
                vert_to_ag = self.vertex_to_agent[v.vertex.id].copy()
                ## only go to disabled repairer if you are a repairer and you are disabled
                match = filter(lambda x: (SHARED[REPS][0] in x or SHARED[REPS][1] in x) and ( x != self.name or not x in SHARED[DISABLED]), vert_to_ag)
                if match:
                    v.rep = match[0]
                    goals.append(v)

        return self.bfs(self.name + '_find_repairer_', GOTO, start, har_repairer, 1)
        
    def get_inspect(self, v, goals):
        match = self.has_opponent(v.vertex)
        ## filter for not prev inspected
        match = filter(lambda x: not x in SHARED[OPPONENTS].keys(), match)
            ## it's just as good if oppnonts are at neighbour vertices
        if not match:
            for n in v.vertex.neighbours:
                match = self.has_opponent(n)
                match = filter(lambda x: not x in SHARED[OPPONENTS].keys(), match)
                if match:
                    break
        if match:
            goals.append(v)
    
    def has_opponent(self, v):
        match = []
        if v.id in self.vertex_to_agent:
            vert_to_ag = self.vertex_to_agent[v.id].copy()
            match = filter(lambda x: x not in self.team, vert_to_ag)
            
        return match
    
    def get_opponent_in_owned(self, v, goals):
        if v.vertex not in self.owned:
            return
        match = self.has_opponent(v.vertex)      
        res = []
        for agent in match:
            if not agent in SHARED[DIS_OPP]:
                res.append(agent)              
        if res:
            op = res[0]
            for a in res:
                if a in SHARED[OPPONENTS]:
                    if SHARED[OPPONENTS][a] == 'Saboteur':
                        op = a
                        break
                    if SHARED[OPPONENTS][a] == 'Repairer':
                        op = a
            
            v.arg = op
            v.goal = op + '_' + v.goal
            goals.append(v)             

    def get_opponent(self, v, goals):
        match = self.has_opponent(v.vertex)      
        res = []
        for agent in match:
            if not agent in SHARED[DIS_OPP]:
                res.append(agent)              
        if res:
            op = res[0]
            for a in res:
                if a in SHARED[OPPONENTS]:
                    if SHARED[OPPONENTS][a] == 'Saboteur':
                        op = a
                        break
                    if SHARED[OPPONENTS][a] == 'Repairer':
                        op = a
            v.arg = op
            v.goal = op + '_' + v.goal
            goals.append(v) 
  
    def get_hit(self, v, goals):
        if v.vertex.id in self.vertex_to_agent:
            
            vert_to_ag = self.vertex_to_agent[v.vertex.id].copy()
            match = filter(lambda x: x != self.name and x in SHARED[AGENTS] and SHARED[AGENTS][x][0].is_hit() , vert_to_ag)   
            if match:
                v.arg = match[0]
                v.goal = match[0] + '_' +  v.goal
                goals.append(v)
                        
    def is_broken(self, v, goals):
        if v.vertex.id in self.vertex_to_agent:
            vert_to_ag = self.vertex_to_agent[v.vertex.id].copy()
            match = filter(lambda x: x != self.name and x in SHARED[DISABLED], vert_to_ag)   
            if match:
                if SHARED[REPS][0][1] in match or SHARED[REPS][1][1] in match:
                    v.cost = 0
                    print self.name, self.type, 'go for repairer first'
                v.arg = match[0]
                v.goal = match[0] + '_' +  v.goal
                goals.append(v)


 
class PriorityQueue():

    def __init__(self):
        self.list = []
    
    def push(self, val):
        heappush(self.list, (val.cost, val))
        
    def pop(self):   
        element = heappop(self.list)
        return element[1]
        
    def __len__(self):
        return len(self.list)
    
    def __repr__(self):
        return repr(self.list)
        
    def __iter__(self):
        for n in self.list:
            yield n
