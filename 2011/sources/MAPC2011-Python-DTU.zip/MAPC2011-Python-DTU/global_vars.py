from sets import Set

            
WEIGHT = 5.5
epsilon = 1
DRAW = False 
#HOST = 'agentcontest1.in.tu-clausthal.de'
#HOST = 'rvince.in.tu-clausthal.de'
#HOST = 'rb02.in.tu-clausthal.de'
#HOST = 'localhost'
#HOST = '192.168.0.13'
RUNTIME = 80
DO_ATTACK = True
PASSWORD = '1'

C = ['Python-DTU1',
        'Python-DTU2',
        'Python-DTU3',
        'Python-DTU4',
        'Python-DTU5',
        'Python-DTU6',
        'Python-DTU7',
        'Python-DTU8',
        'Python-DTU9',
        'Python-DTU10'
        ]
A = ['a1',
        'a2',
        'a3',
        'a4',
        'a5',
        'a6',
        'a7',
        'a8',
        'a9',
        'a10'
        ]
B = ['b1',
        'b2',
        'b3',
        'b4',
        'b5',
        'b6',
        'b7',
        'b8',
        'b9',
        'b10'
        ]

REP = 'Repairer'
SEN = 'Sentinel'
SAB = 'Saboteur'
EXP = 'Explorer'
INS = 'Inspector'

NOOP = 'skip'
ATTACK = 'attack'
INSPECT = 'inspect'
SURVEY = 'survey'
REPAIR = 'repair'
GOTO = 'goto'
RECHARGE = 'recharge'
PROBE = 'probe'
PARRY = 'parry'
BUY = 'buy'
STRENGTH = 'sabotageDevice'
HEALTH = 'shield'


WAIT_TIME = 0.002
MAX_ROUNDS = 500

DISABLED = 1
AUCTION = 3
AGENTS = 4
OPPONENTS = 5
RUNNING = 6
DIS_OPP = 7
READY = 8
EXPAND = 10
EXP_STARTED = 11
REPS = 12
SHARED = { AUCTION : (0,{}), DISABLED : Set(), DIS_OPP : Set(), AGENTS : {}, REPS : [], OPPONENTS : {} , RUNNING : True, READY : (0,Set()), EXPAND : (0, Set(), Set())}

def reset():
    SHARED[AUCTION] = (0,{})
    SHARED[DISABLED] = Set()
    SHARED[DIS_OPP] = Set()
    SHARED[DIS_OPP] = Set()
    SHARED[OPPONENTS] = {}
    SHARED[READY] = (0,Set())
    SHARED[EXPAND] = (0, Set(), Set())
    

COSTS = { ATTACK : 2, INSPECT : 2, SURVEY : 1, REPAIR : 2, PROBE : 1, GOTO : 0, PARRY : 2, NOOP : 2 }
