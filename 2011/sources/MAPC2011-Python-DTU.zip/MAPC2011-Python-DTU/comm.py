import xml.etree.ElementTree as etree 
import socket
import sys
from global_vars import *


auth = etree.fromstring('''<?xml version="1.0" encoding="UTF-8" standalone="no"?>
    <message type="auth-request"><authentication password="test" username="test"/></message>''')


class Communicator():
    
    def connect(self, password):
        try:   
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((HOST, 12300))
            self.s = s
            auth_ele = auth.find('authentication')
            auth_ele.attrib['username'] = self.name
            auth_ele.attrib['password'] = password
            self.s.send(etree.tostring(auth) + '\0')
            resp = self.receive()   
            if not resp.get('type') == 'auth-response':
                raise Exception('Unexpected auth-response message')
            if not  resp.find('authentication').attrib['result'] == 'ok':
                raise Exception('Authentication failed')
        except Exception as a:
            print self.name, 'connection refused', a
            self.stop()
        print self.name, 'connected'
    
#    def receive(self):
#        resp = ''
#        while not resp or resp[-1] != '\0':
#            resp = resp + self.s.recv(1) 
#        resp = resp[:-1]
#        return etree.fromstring(resp)
    def receive(self):
        if self.buffer:
            val = self.buffer.pop(0)
            if val:
                return  etree.fromstring(val)
        resp = ''
        while not resp or resp[-1] != '\0':
            resp = resp + self.s.recv(1024) 
            
        val = resp.split('\0')
        
        if len(val) > 1:
            self.buffer.extend(val[1:])
        
        return etree.fromstring(val[0])
    def stop(self):
        
        try:
            self.s.close()
        except:
            pass
        
        SHARED[RUNNING] = False
        sys.exit(1)
        
        
    def send_action(self, type, param=None):
        action_ele = self.action.find('action')
        action_ele.attrib['id'] = self.id
        action_ele.attrib['type'] = type
        if param is not None :
            action_ele.set('param', param)
            
        self.s.send(etree.tostring(self.action) + '\0')
    def handle_team_percepts(self):
            #Process new team beliefs
        while len(self.edge_percepts) > 0:
            self.handle_edge_percept(*self.edge_percepts.pop())
        while len(self.entity_percepts) > 0:
            self.handle_entity_percept(*self.entity_percepts.pop())
        while len(self.probe_percepts) > 0:
            self.handle_probed_vertex(*self.probe_percepts.pop())
                
    def handle_percept(self, percepts):
        
        self.update_entities()
        
        
        simulation = percepts.find('simulation')
        self.step = int(simulation.get('step'))
        
        team_info = percepts.find('team')
        self.money = int(team_info.get('money'))
        
        info = percepts.find('self')
        self.info = info.attrib 
        self.id = percepts.get('id')
        
        if self.dummy:
            return
            
        vertices = percepts.find('visibleVertices')
        vertices = [] if vertices is None else list(vertices)
        
        edges = percepts.find('visibleEdges')
        edges = [] if edges is None else list(edges)
        
        entities = percepts.find('visibleEntities')
        entities = [] if entities is None else list(entities)
        
        surveyed = percepts.find('surveyedEdges')
        surveyed = [] if surveyed is None else list(surveyed)
        
        probed = percepts.find('probedVertices')
        probed = [] if probed is None else list(probed)
        
        
        inspected = percepts.find('inspectedEntities')
        inspected = [] if inspected is None else list(inspected)
        
        new_vertices = []                
        new_edges = []
        new_entities = []
        new_probed = []


        if not self.team_name:
            for e in entities:
                name, vertex, status, team = e.get('name'), e.get('node'), e.get('status'), e.get('team')
                if name == self.name:
                    self.team_name = team
                    break
                
        #Process perceptions
        
        entities_on_posotion = []
        
        for v in vertices:
            id, team = v.get('name'), v.get('team')
            new_vertices.extend(self.handle_vertex_percept(id, team))
        for e in edges:
            v1, v2 = e.get('node1'), e.get('node2')
            new_edges.extend(self.handle_edge_percept(v1, v2))
        for e in surveyed:
            v1, v2, weight = e.get('node1'), e.get('node2'), int(e.get('weight'))
            new_edges.extend(self.handle_edge_percept(v1, v2, weight))
        for e in entities:
            name, vertex, status, team = e.get('name'), e.get('node'), e.get('status'), e.get('team')
            new_entities.extend(self.handle_entity_percept(name, vertex))
            new_entities.append((self.name, self.info['position']))
            if team != self.team_name and vertex == self.info['position']:
                entities_on_posotion.append(name)
                
            if status == 'disabled':
                if team == self.team_name:
                    SHARED[DISABLED].add(name)
                else:
                    SHARED[DIS_OPP].add(name)
            else:
                try:
                    if team == self.team_name and name in SHARED[DISABLED]:
                        SHARED[DISABLED].remove(name)                
                    elif name in SHARED[DIS_OPP]:
                        SHARED[DIS_OPP].remove(name)
                except:
                    pass
        
        
        for e in probed:
            name, value = e.get('name'), e.get('value')
            self.handle_probed_vertex(name, value)
            if name == self.info['position']:
                new_probed.append((name, value))
                
        for e in inspected:
            name = e.get('name')
            if not name in SHARED[OPPONENTS]:
                SHARED[OPPONENTS][name] = e.get('role')
                    
        #Share new beliefs
        for agent in SHARED[AGENTS].itervalues():
            if agent[0].name != self.name:
                agent[0].vertex_percepts.extend(new_vertices)
                agent[0].probe_percepts.extend(new_probed)
                agent[0].edge_percepts.extend(new_edges)
                agent[0].entity_percepts.extend(new_entities)
