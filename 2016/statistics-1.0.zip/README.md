# MAPC Statistics module
Launch jar with

    java -jar statistics-*.jar
