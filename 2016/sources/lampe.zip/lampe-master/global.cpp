
#include <iostream>

#include "global.hpp"

namespace jup {

std::ostream& jout = std::cout;
std::ostream& jerr = std::cerr;

bool program_closing = false;

} /* end of namespace jup */

