
"""

 /*
  * @(#) E.Sarmas   main.py 1.29e (2016-09-12)
  *
  * Author: E.Sarmas
  *
  * Created: 2016-06-20
  *
  * Description: Flisvos 2016 (MAPC 2016)
  *
  * Version: 1.29e
  * Version-Date: 2016-09-12
  *
  */

"""

VERSION_STR = "Flisvos 2016   1.29eZ (2016-09-12)"

import logging
import argparse
import threading
import sys
import agent
import main

LOGFILE_PREFIX = "agent-"
#LOGFILE_FORMAT = "%(asctime)s %(name)s:%(process)d-%(thread)d %(levelname)s   %(message)s"
LOGFILE_FORMAT = "%(asctime)s %(name)9s: %(levelname)8s %(message)s"
CONSOLE_FORMAT = "%(name)9s: %(levelname)8s %(message)s"

LOG_CRITICAL = 50
LOG_ERROR = 40
LOG_WARNING = 30
LOG_INFO = 20
LOG_DEBUG = 10
LOG_NOTSET = 0

LOG_DETAIL = 5
LOG_DETAIL_STR = "DETAIL"
LOG_OP = 19
LOG_OP_STR = "OP"

VERBOSE = False

###

TEAM = "Flisvos-2016"

#HOST = 'agentcontest2.in.tu-clausthal.de'
HOST = 'agentcontest1.in.tu-clausthal.de'
PORT = 12300

AGENT_PREFIX = "flisvos"
PASSWORD = "jSev94"

NUM_AGENTS = 16

'''
HOST = "localhost"
PORT = 12300

AGENT_PREFIX = "a"
PASSWORD = "1"

NUM_AGENTS = 2
'''

###

import hashlib

def c_file_hash(hasher, file_name):
  size = 1024*1024
  with open(file_name, "rb", buffering=0) as f:
    for b in iter(lambda: f.read(size), b""):
      hasher.update(b)
  return hasher.hexdigest()

def c_file_stats(hasher, file_name):
  size = 1024*1024
  bytes = 0
  lines = 0
  with open(file_name, "rb") as f:
    for b in iter(lambda: f.read(size), b""):
      bytes += len(b)
      lines += b.count(b'\n')
      hasher.update(b)
  return (bytes, lines, hasher.hexdigest())

def c_fileid(hash_factory, file_name_list, verbose=False):
  total_bytes = 0
  total_lines = 0
  hashes = []
  for file_name in file_name_list:
    hasher = hash_factory()
    file_bytes, file_lines, file_hash = c_file_stats(hasher, file_name)
    total_bytes += file_bytes
    total_lines += file_lines
    hashes.append(file_hash.encode("ascii"))
    s_file_hash = "" if not verbose else " ({:s})".format(file_hash)
    print("{:30s} {:10,d} bytes {:9,d} lines {:s}..{:s}{:s}".format(
      file_name, file_bytes, file_lines, file_hash[0:7], file_hash[-3:], s_file_hash
    ))
  hasher = hash_factory()
  for fh in sorted(hashes):
    hasher.update(fh)
  c_hash = hasher.hexdigest()
  s_c_hash = "" if not verbose else " ({:s})".format(c_hash)
  print("{:30s} {:10,d} bytes {:9,d} lines {:s}..{:s}{:s}".format(
    "total", total_bytes, total_lines, c_hash[0:7], c_hash[-3:], s_c_hash
  ))

PROJECT_FILES = ["main.py", "comm.py", "agent.py", "util.py", "util2.py", "actions.py", "team.py"]

import os
class import_source_stats():
  def __init__(self):
    self._module_count = 0
    self._project_files = set(PROJECT_FILES)
  
  #def find_module(self, fullname, path=None):
  def find_spec(self, fullname, path, target=None):
    file_name = fullname+".py"
    if file_name not in self._project_files:
      return None
    if not os.path.exists(file_name):
      return None
    self._module_count += 1
    if self._module_count == len(self._project_files):
      c_fileid(hashlib.sha1, PROJECT_FILES)
    return None
  
  #def exec_module(self, name):
  #def load_module(self, name):
  #  return None

#print(sys.meta_path)
#sys.meta_path = [import_source_stats()]
sys.meta_path.insert(0, import_source_stats())

def _main_():
  
  ###global VERBOSE, AGENT_PREFIX, PASSWORD, NUM_AGENTS, HOST, PORT
  
  args_parser = argparse.ArgumentParser()
  # action=, nargs=, const=, default=, type=, choices=, required=, help=, metavar=, dest=
  args_parser.add_argument('-V', '--version', action='store_true')
  args_parser.add_argument('-v', '--verbose', action='store_true')
  args_parser.add_argument('-a', '--agent_prefix', action='store')
  args_parser.add_argument('-pw', '--password', action='store')
  args_parser.add_argument('-n', '--num_agents', type=int, action='store')
  args_parser.add_argument('-H', '--host', action='store')
  args_parser.add_argument('-P', '--port', type=int, action='store')
  args = args_parser.parse_args()
  
  if args.version:
    print(VERSION_STR)
    sys.exit(0)
  if args.verbose:
    main.VERBOSE = True
  if args.agent_prefix:
    main.AGENT_PREFIX = args.agent_prefix
  if args.password:
    main.PASSWORD = args.password
  if args.num_agents:
    main.NUM_AGENTS = args.num_agents
  if args.host:
    main.HOST = args.host
  if args.password:
    main.PASSWORD = args.password
  
  logging.addLevelName(LOG_DETAIL, LOG_DETAIL_STR)
  logging.addLevelName(LOG_OP, LOG_OP_STR)
  
  log = logging.getLogger()
  log.setLevel(LOG_OP)
  # must set !
  #if main.VERBOSE:
  #  log.setLevel(LOG_DETAIL)
  #else:
  #  log.setLevel(logging.DEBUG)
  
  fileh = logging.FileHandler(filename = "main-"+main.AGENT_PREFIX+".log", mode = "w")
  fileh.setLevel(LOG_OP)
  fileh.setFormatter(logging.Formatter(LOGFILE_FORMAT))
  log.addHandler(fileh)
  
  # define a Handler which writes INFO messages or higher to the sys.stderr
  console = logging.StreamHandler()
  console.setLevel(logging.INFO)
  console.setFormatter(logging.Formatter(CONSOLE_FORMAT))
  log.addHandler(console)
  
  log.info("")
  log.info(VERSION_STR)
  log.info("")
  log.info("started logging... (level = {})".format(log.getEffectiveLevel()))
  log.info("VERBOSE = {}".format(main.VERBOSE))
  log.info("AGENT_PREFIX = {:s}".format(main.AGENT_PREFIX))
  log.info("PASSWORD = {:s}".format(main.PASSWORD))
  log.info("NUM_AGENTS = {:d}".format(main.NUM_AGENTS))
  log.info("HOST = {:s}".format(main.HOST))
  log.info("PORT = {:d}".format(main.PORT))
  log.info("")
  
  shared = {}
  agents = [agent.Agent(i, main.HOST, main.PORT, main.AGENT_PREFIX + str(i), main.PASSWORD, shared, main.VERBOSE)
              for i in range(1, main.NUM_AGENTS+1)]
  for a in agents:
    a.start()
  sys.exit(0)
  '''
  # thread test code
  while True:
    time.sleep(1)
    t_list = threading.enumerate()
    print(time.time(), "threads =", len(t_list))
    print()
    if len(t_list) == 1 and t_list[0] == threading.main_thread():
      print("only main thread remained !")
    # just main thread
    if len(t_list) == 1:
      break
  '''

if __name__ == "__main__":
  _main_()