
"""

 /*
  * @(#) E.Sarmas   comm.py 1.29e (2016-09-12)
  *
  * Author: E.Sarmas
  *
  * Created: 2016-06-20
  *
  * Description: Flisvos 2016 (MAPC 2016)
  *
  * Version: 1.29e
  * Version-Date: 2016-09-12
  *
  */

"""

import xml.etree.ElementTree as etree
import socket
import sys
import logging
import collections
import util

'''
must reconnect

protocol
  AUTH-REQUEST -> AUTH-RESPONSE
  SIM-START
  REQUEST-ACTION -> ACTION
  SIM-END
  BYE
  
  <?xml version="1.0" encoding="UTF-8"?>
  <message timestamp="10001980000000" type="request-action">
    <!-- optional data -->
  </message>
  
  types: auth-request, auth-response, sim-start, sim-end, bye, request-action, action
  responses can omit timestamp=
  
  <?xml version="1.0" encoding="UTF-8" standalone="no"?>
  <message type="auth-request">
    <authentication password="1" username="a1"/>
  </message>
  
  <?xml version="1.0" encoding="UTF-8" standalone="no"?>
  <message timestamp="1297263037617" type="auth-response">
    <authentication result="ok"/> ok or fail
  </message>
  
  <?xml version="1.0" encoding="UTF-8"?>
  <message timestamp="1467151991772" type="sim-start">
    <simulation id="0" map="london" seedCapital="0" steps="1000" team="A">
      <role maxBattery="500" maxLoad="550" name="Car" speed="3">
        <tool name="item16"/>
        <tool name="item4"/>
      </role>
      <products>
        <product assembled="true" name="item10" volume="29">
          <consumed>
            <item amount="1" name="item0"/>
            <item amount="1" name="item12"/>
          </consumed>
          <tools>
            <item amount="2" name="item6"/>
          </tools>
        </product>
        <product assembled="false" name="item2" volume="26"/>
        ...
      </products>
    </simulation>
  </message>
  
  <?xml version="1.0" encoding="UTF-8" standalone="no"?>
  <message timestamp="1297269179279" type="sim-end">
    <sim-result ranking="2" score="9"/>
  </message>
  
  <?xml version="1.0" encoding="UTF-8"?>
  <message timestamp="1204978760555" type="bye"/>
  
  <?xml version="1.0" encoding="UTF-8"?>
    <message timestamp="1467156377654" type="request-action">
      <perception deadline="1467156380404" id="169">
      <simulation step="168"/>
      <self
        batteryCapacity="500"
        charge="500"
        fPosition="-1"
        inFacility="none"
        lastAction="noAction"
        lastActionParam=""
        lastActionResult=""
        lat="51.48081933955414"
        lon="-0.09247273189165717"
        load="0"
        loadCapacity="550"
        name="a1"
        routeLength="0">
        <items>
          <item amount="1" name="item0"/>
          ...
        </items>
        <route>
          <n i="0" lat="10" lon="11"/>
          <n i="1" lat="10" lon="12"/>
          ...
        </route>
      </self>
      <team money="50000">
        <jobs-taken>
          <job id="job_id1/>
          ...
        </jobs-taken>
        <jobs-posted/>
      </team>
      <entities>
        <entity lat="51.48081933955414" lon="-0.09247273189165717" name="a1" role="Car" team="A"/>
         ...
        <entity lat="51.48081933955414" lon="-0.09247273189165717" name="b1" role="Car" team="B"/>
        ...
      </entities>
      <facilities>
        <chargingStation lat="51.494852446102854" lon="-0.1643635272793088" name="charging0" price="1" rate="86" slots="4"/>
          ??? +nested <info qSize="3"/> if nearby
        <dumpLocation lat="51.48825720809224" lon="-0.19179956221755393" name="dump0" price="1"/>
        <workshop lat="51.46902356651228" lon="-0.19167293762237173" name="workshop0" price="254"/>
        <storage lat="51.49312313078761" lon="-0.1835590312252583" name="storage0" price="6" totalCapacity="11150" usedCapacity="0">
          <item name="it1" stored="3" delivered="2"/>
        </storage>
        <shop lat="51.5003430713938" lon="-0.16468962283686922" name="shop0">
          <item name="item8"/> ??? +nested <item...><info cost="10" amount="5" restock="35"/></item>
          ...
        </shop>
      </facilities>
      <jobs>
        <pricedJob begin="12" end="307" id="job_id229718196029243293" reward="3073" storage="storage6">
          <items>
            <item amount="1" name="item2"/> ??? +delivered="10"
            ...
          </items>
        </pricedJob>
        <auctionJob begin="171" end="469" fine="1037" id="job_id9094083311093042440" maxBid="4026" storage="storage6">
          <items>
            <item amount="1" name="item8"/>
            ...
            </items>
        </auctionJob>
      </jobs>
    </perception>
  </message>
  
  # id in REQUEST-ACTION before deadline !!!
  <?xml version="1.0" encoding="UTF-8"?>
  <message type="action">
    <action id="70" type="goto" param="at=51.805 lon=10.3355"/>
  </message>
  
  types =
  goto                facility= or lat=, lon=     # to another location or facility
    [cost = battery charge]
  buy                 item=, amount=              # inside shop
  give                agent=, item=, amount=      # to a teammate
  receive                                         # from teammates
  store               item=, amount=              # inside storage facility
    [cost = volume * amount * cost]
  retrieve            item=, amount=              # stored at storage facility
  retrieve_delivered  item=, amount=              # delivered at storage facility
    [can retrieve partial deliveries of unsuccesful job !!!]
  dump                item=, amount=              # inside dump facility
    [cost = volume * amount * cost]
  assemble            item=                       # inside workshop
  assist_assemble     assembler=                  # assist teammate
  deliver_job         job=                        # inside storage facility
  charge                                          # inside charging station
  bid_for_job         job=, price=                # anywhere
  post_job            type=auction, max_price=, fine=, active_steps=, auction_steps=, storage=, item1=, amount1=, ...
                   or type=priced, price=, active_steps=, storage=, item1=, amount1=, ...
  call_breakdown_service                          # after a predefined amount of time and costs a lot of money
  continue                                        # ongoing action (goto or charge) is continued, else nothing
  skip                                            # same as continue
  abort                                           # does nothing, stops ongoing actions

  action results =

  successful
  failed_location
  failed_unknown_item
  failed_unknown_agent
  failed_unknown_job
  failed_unknown_facility
  failed_no_route
  failed_item_amount
  failed_capacity
  failed_wrong_facility
  failed_tools
  failed_item_type
  failed_job_status
  failed_job_type
  failed_counterpat
  failed_wrong_param
  failed_unknown_error
  failed
  successful_partial
  useless
  
  failed_random [1% probability of random failure]
'''

auth_str = '''<?xml version="1.0" encoding="UTF-8" standalone="no"?>
    <message type="auth-request"><authentication password="test" username="test"/></message>'''

action_str = '''<?xml version="1.0" encoding="UTF-8" standalone="no"?>
    <message type="action"><action/></message>'''

RECV_SIZE = 1024
#SOCKET_TIMEOUT = 20
SOCKET_TIMEOUT = 5

LOG_DETAIL = 5

#MSG_LOG_EXCLUDE_LIST = ["entities"]
MSG_LOG_EXCLUDE_LIST = None

# optionally asyncore, asynchat, select though no performance need
class Comm:
  
  def __init__(self, id, host, port, agent_name, password, verbose):
    self._log = logging.getLogger(agent_name) # may separate loggers
    self._id = id
    self._host = host
    self._port = port
    self._agent_name = agent_name
    self._password = password
    self._verbose = verbose
    self._s = None # socket
    self._connected = False
    self._msg_list = [] # receive buffer, list of (msg_xml, msg_str)
  
  def connect(self):
    log = self._log
    s = None
    try:
      self._connected = False
      s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
      #log.debug("timeout was = {:.1f}".format(s.gettimeout()))
      s.settimeout(SOCKET_TIMEOUT)
      log.debug("timeout set = {:.1f}".format(s.gettimeout()))
      log.debug("connecting to {:s}:{:d} ...".format(self._host, self._port))
      s.connect((self._host, self._port))
      log.debug("socket connected")
      self._s = s
      self._connected = True
      
      auth_xml = etree.fromstring(auth_str)
      auth_ele = auth_xml.find("authentication")
      auth_ele.attrib["username"] = self._agent_name
      auth_ele.attrib["password"] = self._password
      log.debug("send authentication {:s} {:s}".format(self._agent_name, self._password))
      msg_b = etree.tostring(auth_xml)
      msg_str = str(msg_b, "utf-8")
      log.log(LOG_DETAIL, "\n=== message begin === {:d} chars\n{:s}\n=== message end   ===".format(len(msg_str), msg_str))
      s.sendall(msg_b + b"\0")
      
      res = self.receive()
      if res is None:
        raise Exception("did not get auth-response message")
      
      msg_xml, msg_str = res
      msg_auth = None
      if msg_xml.tag != "message" or msg_xml.get("type") != "auth-response":
        raise Exception("expected auth-response message")
      msg_auth = msg_xml.find("authentication")
      if msg_auth is None or msg_auth.get("result") != "ok":
        raise Exception("authentication failed")
      
      log.debug("server connected")
    except Exception as e:
      log.debug("connection error: {:s}".format(str(e)))
      if self._s:
        self._s.close()
      self._s = None
      self._connected = False
  
  # return (msg_xml, msg_str) element
  # may receive >= 2 xml in backlog so must buffer
  # check that is "message" element and has "type"
  def receive(self):
    log = self._log
    log.log(LOG_DETAIL, "receive()")
    if self._msg_list: # true if not None or not empty
      return self._msg_list.pop(0)
    res = ""
    while True:
      b_res1 = b""
      try:
        b_res1 = self._s.recv(RECV_SIZE)
      except Exception as e:
        log.debug("recv() error: {:s}".format(str(e)))
      if b_res1 == b"":
        log.debug("recv() side closed !")
        self._s.close()
        self._s = None
        self._connected = False
        return None
      log.log(LOG_DETAIL, "received {:d} bytes".format(len(b_res1)))
      res1 = str(b_res1, "utf-8")
      res = res + res1
      if res1[-1] == "\0":
        break
    res = res[:-1]
    res_list = res.split("\0")
    msg_list = []
    for msg_str in res_list:
      log.log(LOG_DETAIL, "\n=== message begin === {:d} chars\n{:s}\n=== message end   ===".format(len(msg_str), msg_str))
      try:
        msg_xml = etree.fromstring(msg_str)
        if msg_xml.tag != "message" or msg_xml.get("type") is None:
          raise Exception("xml message is not \"message\" with \"type\"")
        msg_list.append((msg_xml, msg_str))
      except Exception as e:
        log.debug("bad message received")
    # if no valid message assume bad connection, we may get stuck in recv(), so abort connection
    if len(msg_list) == 0:
      self._s.close()
      self._s = None
      self._connected = False
      return None
    self._msg_list = msg_list
    return self._msg_list.pop(0)
  
  # returns (msg_type, parsed_data, msg_xml, msg_str)
  def get_msg(self):
    log = self._log
    log.log(LOG_DETAIL, "get_mesg()")
    while True:
      while not self._connected:
        self.connect()
      res = self.receive()
      if res != None:
        lap_timer = util.LapTimer(log)
        lap_timer.lap_start()
        msg_xml, msg_str = res
        msg_type = msg_xml.get("type")
        data = self.decode_data(msg_xml)
        self.log_data(data, MSG_LOG_EXCLUDE_LIST)
        ela = lap_timer.lap("get_msg processing")
        return (msg_type, data, msg_xml, msg_str)
  
  # msg must be b"..." of xml with b"\0" at end
  def send_msg(self, msg):
    log = self._log
    log.log(LOG_DETAIL, "send_msg()")
    if not self._connected:
      log.debug("not connected, aborted !")
      return
    try:
      self._s.sendall(msg)
      log.log(LOG_DETAIL, "send ok")
    except Exception as e:
      log.debug("sendall() error: {:s}".format(str(e)))
      self._s.close()
      self._s = None
      self._connected = False
  
  def send_action(self, id, action, **kwargs):
    log = self._log
    log.debug("send_action {:s} {}".format(action, kwargs))
    action_xml = etree.fromstring(action_str)
    action_ele = action_xml.find("action")
    action_ele.attrib["id"] = id
    action_ele.attrib["type"] = action
    if kwargs:
      param = " ".join(key+"="+value for key, value in kwargs.items())
      action_ele.attrib["param"] = param
    msg_b = etree.tostring(action_xml)
    msg_str = str(msg_b, "utf-8")
    log.debug("\n=== message begin === {:d} chars\n{:s}\n=== message end   ===".format(len(msg_str), msg_str))
    self.send_msg(msg_b + b"\0")
  
  # single, attributes of tag contained within element
  @staticmethod
  def decode_attribs(element, tag=None):
    x = element
    if tag is not None:
      x = element.find(tag)
    data = util.attr_dict()
    for attr, value in x.attrib.items():
      data[attr] = value
    return data
  
  # list, attributes of all nested subtags contained within tag
  @staticmethod
  def decode_nested_tags(element, tag, key_name, nested_tag_attrib_label = None):
    x = element.find(tag)
    #q = []
    q = util.attr_dict()
    if x is not None:
      for s in list(x):
        subdata = util.attr_dict()
        for attr, value in s.attrib.items():
          subdata[attr] = value
        if nested_tag_attrib_label is not None:
          subdata[nested_tag_attrib_label] = s.tag
        #q.append(subdata)
        q[getattr(subdata, key_name)] = subdata
    return q
  
  # single, attributes of tag and lists all of nested tags contained within subtags in tag_groups
  @staticmethod
  def decode_single_attribs_nested_tag_groups(element, tag, tag_groups, tag_key_names, tag_group_names = None, nested_tag_attrib_label = None):
    x = element.find(tag)
    data = util.attr_dict()
    for attr, value in x.attrib.items():
      data[attr] = value
    for i, subtag in enumerate(tag_groups):
      #p = []
      p = util.attr_dict()
      z = x.find(subtag)
      for s in list(z):
        subdata = util.attr_dict()
        for attr, value in s.attrib.items():
          subdata[attr] = value
        if nested_tag_attrib_label is not None:
          subdata[nested_tag_attrib_label] = s.tag
        #p.append(subdata)
        p[getattr(subdtata, tag_key_names[i])] = subdata
      group_name = subtag
      if tag_group_names is not None:
        group_name = tag_group_names[i]
      data[group_name] = p
    return data
  
  # list, attributes of tags within tag and lists all of nested tags contained within subtags in tag_groups
  @staticmethod
  def decode_list_attribs_nested_tag_groups(element, tag, key_name, tag_groups, tag_key_names, tag_group_names = None, list_tag_attrib_label = None, nested_tag_attrib_label = None):
    y = element.find(tag)
    #q = []
    q = util.attr_dict()
    for x in list(y):
      data = util.attr_dict()
      for attr, value in x.attrib.items():
        data[attr] = value
      for i, subtag in enumerate(tag_groups):
        #p = []
        p = util.attr_dict()
        z = x.find(subtag)
        if z is not None:
          for s in list(z):
            subdata = util.attr_dict()
            for attr, value in s.attrib.items():
              subdata[attr] = value
            if nested_tag_attrib_label is not None:
              subdata[nested_tag_attrib_label] = s.tag
            #p.append(subdata)
            p[getattr(subdata, tag_key_names[i])] = subdata
        group_name = subtag
        if tag_group_names is not None:
          group_name = tag_group_names[i]
        data[group_name] = p
      if list_tag_attrib_label is not None:
        data[list_tag_attrib_label] = x.tag
      #q.append(data)
      q[getattr(data, key_name)] = data
    return q
  
  # list, attributes of tags within tag and lists all of directly nested tags as attribute tag_group
  # inline tag is not nested but it's attributes merged
  # optional extra nested inline tag within nested tags, again it's attributes merged
  @staticmethod
  def decode_list_attribs_nested_tags_opt_inline(element, tag, key_name, as_tag_group, as_key_name, inline_tag, list_tag_attrib_label = None, nested_tag_attrib_label = None):
    y = element.find(tag)
    #q = []
    q = util.attr_dict()
    for x in list(y):
      data = util.attr_dict()
      for attr, value in x.attrib.items():
        data[attr] = value
      #p = []
      p = util.attr_dict()
      for s in list(x):
        if s.tag == inline_tag:
          for attr, value in s.attrib.items():
            data[attr] = value
        else:
          subdata = util.attr_dict()
          for attr, value in s.attrib.items():
            subdata[attr] = value
          for z in list(s):
            if z.tag == inline_tag:
              for attr, value in z.attrib.items():
                subdata[attr] = value
          if nested_tag_attrib_label is not None:
            subdata[nested_tag_attrib_label] = s.tag
          #p.append(subdata)
          p[getattr(subdata, as_key_name)] = subdata
      data[as_tag_group] = p
      if list_tag_attrib_label is not None:
        data[list_tag_attrib_label] = x.tag
      #q.append(data)
      q[getattr(data, key_name)] = data
    return q
  
  def log_data(self, data, exclude_list = None):
    log = self._log
    log.log(LOG_DETAIL, "log_data(): {}".format(data))
    level = 0
    buf = []
    self.log_tree(data, level, buf, exclude_list)
    log.debug("\n".join(buf))
  
  def log_tree(self, data, level, buf, exclude_list = None):
    #log = self._log
    for key, value in data.items():
      if exclude_list and key in exclude_list:
        continue
      if isinstance(value, str):
        #log.debug("{:s}{:s} = {:s}".format("  " * level, key, value))
        buf.append("{:s}{:s} = {:s}".format("  " * level, key, value))
      #else:
      #  if isinstance(value, list):
      elif isinstance(value, util.attr_dict):
        if len(value) > 0:
          #log.debug("{:s}{:s} =".format("  " * level, key))
          buf.append("{:s}{:s} =".format("  " * level, key))
          #for x in value:
            #log.debug("{:s}{:s}".format("  " * (level + 1), "---------------------"))
            #buf.append("{:s}{:s}".format("  " * (level + 1), "---------------------"))
          #  buf.append("{:s}{:s}".format("  " * (level + 1), "-"))
          #  self.log_tree(x, level + 1, buf)
          ###buf.append("{:s}{:s}".format("  " * (level + 1), "-"))
          self.log_tree(value, level + 1, buf)
          #log.debug("{:s}{:s}".format("  " * (level + 1), "---------------------"))
          #buf.append("{:s}{:s}".format("  " * (level + 1), "---------------------"))
          ###buf.append("{:s}{:s}".format("  " * (level + 1), "-"))
        #else:
        #  #log.debug("{:s}{:s}".format("  " * level, key))
        #  buf.append("{:s}{:s}".format("  " * level, key))
        #  self.log_tree(value, level + 1, buf)
  
  @staticmethod
  def decode_data(msg_xml):
    data = util.attr_dict()
    data["message"] = Comm.decode_attribs(msg_xml)
    msg_type = data["message"]["type"]
    #
    # sim-end
    #
    if msg_type == "sim-end":
      # sim-result => ranking, score
      data["sim_result"] = Comm.decode_attribs(msg_xml, "sim-result")
    #
    # sim-start
    #
    if msg_type == "sim-start":
      # simulation => id, map, seedCapital, steps, team
      data["simulation"] = Comm.decode_attribs(msg_xml, "simulation")
      # role => name, speed, maxLoad, maxBattery
      data["role"] = Comm.decode_attribs(msg_xml, "simulation/role")
      # tool => [ name ]
      data["tool"] = Comm.decode_nested_tags(msg_xml, "simulation/role", "name")
      # products => [
      #   assembled(true/false), name, volume,
      #     consumed => [ name, amount ],
      #     tools =>    [ name, amount ]
      # ]
      data["products"] = Comm.decode_list_attribs_nested_tag_groups(msg_xml, "simulation/products", "name", ["consumed", "tools"], ["name", "name"])
    #
    # request-action
    #
    if msg_type == "request-action":
      # perception => deadline, id
      data["perception"] = Comm.decode_attribs(msg_xml, "perception")
      # simulation => step
      data["simulation"] = Comm.decode_attribs(msg_xml, "perception/simulation")
      # self => batteryCapacity, charge, fPosition(-1), inFacility(none),
      #   lastAction(noAction), lastActionParam, lastActionResult, lat, lon, load, loadCapacity,
      #   name, routeLength
      data["self"] = Comm.decode_attribs(msg_xml, "perception/self")
      # items => [ name, amount ]
      data["self_items"] = Comm.decode_nested_tags(msg_xml, "perception/self/items", "name")
      # route => [ i, lat, lon ]
      data["route"] = Comm.decode_nested_tags(msg_xml, "perception/self/route", "i")
      # team => money
      data["team"] = Comm.decode_attribs(msg_xml, "perception/team")
      # jobs-taken => [ id ]
      data["jobs_taken"] = Comm.decode_nested_tags(msg_xml, "perception/team/jobs-taken", "id")
      # jobs-posted => [ id ]
      data["jobs_posted"] = Comm.decode_nested_tags(msg_xml, "perception/team/jobs-posted", "id")
      # entities => [ lat, lon, name, role, team ]
      data["entities"] = Comm.decode_nested_tags(msg_xml, "perception/entities", "name")
      # facilities => [
      #   facility_type =
      #     chargingStation   lat, lon, name, price, rate, slots, ?info#qSize
      #     dumpLocation   lat, lon, name, price
      #     workshop   lat, lon, name, price
      #     storage    lat, lon, name, price, totalCapacity, usedCapacity, extra => [ name, ?stored, ?delivered ]
      #     shop       lat, lon, name, extra => [ name, ?info#cost, ?info#amount, ?info#restock ]
      # ]
      data["facilities"] = Comm.decode_list_attribs_nested_tags_opt_inline(msg_xml, "perception/facilities", "name", "extra", "name", "info", "facility_type")
      # jobs => [
      #   job_type =
      #     pricedJob    begin, end, id, reward, storage, job_items => [ name, amount, ?delivered ]
      #     auctionJob   begin, end, fine, id, maxBid, storage, job_items => [ name, amount ]
      # ]
      data["jobs"] = Comm.decode_list_attribs_nested_tag_groups(msg_xml, "perception/jobs", "id", ["items"], ["name"], ["job_items"], "job_type")
    return data