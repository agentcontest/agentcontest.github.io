
"""

 /*
  * @(#) E.Sarmas   util.py 1.29e (2016-09-12)
  *
  * Author: E.Sarmas
  *
  * Created: 2016-07-11
  *
  * Description: Flisvos 2016 (MAPC 2016)
  *
  * Version: 1.29e
  * Version-Date: 2016-09-12
  *
  */

"""

import collections
import math
import sys
import time
import re
import util2
import actions
import team
import main
import random
import configparser

'''
# Python 3.5

dictclass = collections.OrderedDict

class attr_dict(dictclass):
  #def __init__(self, *args, **kwargs):
  #  super().__init__(*args, **kwargs)
  
  __getattribute__ = dictclass.__getitem__
  __setattribute__ = dictclass.__setitem__

'''

# Python 3.4, 3.5

dictclass = collections.OrderedDict

class attr_dict(collections.abc.MutableMapping):
  
  def __init__(self, *args, **kwargs):
    super().__setattr__("_data", dictclass(*args, **kwargs))
  
  def __getitem__(self, key):
    return super().__getattribute__("_data")[key]
  
  def __setitem__(self, key, value):
    super().__getattribute__("_data")[key] = value
  
  def __delitem__(self, key):
    del super().__getattribute__("_data")[key]
  
  def __iter__(self):
    return iter(super().__getattribute__("_data"))
  
  def __len__(self):
    return len(super().__getattribute__("_data"))
  
  def __contains__(self, key):
    return dictclass.__contains__(super().__getattribute__("_data"), key)
  
  def items(self):
    return super().__getattribute__("_data").items()
  
  def keys(self):
    return super().__getattribute__("_data").keys()
  
  def values(self):
    return super().__getattribute__("_data").values()
  
  def __str__(self):
    return str(super().__getattribute__("_data"))
  
  def __repr__(self):
    return repr(super().__getattribute__("_data"))
  
  __getattr__ = __getitem__
  __setattr__ = __setitem__



perf_time = time.perf_counter

class LapTimer():
  """
  marks time stops and prints laps
  """
  
  def __init__(self, log, desc=""):
    """
    initial time stop, optional description of timer
    """
    self.last_time = 0
    self.sub_time = 0
    self._log = log
  
  def lap_start(self):
    self.last_time = perf_time()
  
  def lap(self, desc="", log_level=main.LOG_DEBUG):
    """
    print lap to stdout (and flush) from previous stop and mark new stop
    optional lap description to print
    """
    ela = 0
    new_time = perf_time()
    if self.last_time != 0:
      ela = new_time - self.last_time
      self._log.log(log_level, "###   " + desc + "   elapsed =  {:.3f} s".format(ela))
    self.last_time = new_time
    return ela
  
  def sub_lap(self, desc="", log_level=main.LOG_DEBUG):
    """
    print sub_lap to stdout (and flush) from previous stop and mark new stop
    optional lap description to print
    """
    ela = 0
    new_time = perf_time()
    if self.sub_time < self.last_time:
      self.sub_time = self.last_time
    if self.sub_time != 0:
      ela = new_time - self.sub_time
      self._log.log(log_level, ">>>   " + desc + "   elapsed =  {:.3f} s".format(ela))
    self.sub_time = new_time
    return ela

def sign(x):
  return (x > 0) - (x < 0)



#RAD_1DEG = 0.017453292519943295 #math.PI/180
#R = 6371
#CELL_LAT = 51.4935 # degrees

MAPS = {
"london": attr_dict(minLon=-0.1978, maxLon=-0.0354, minLat=51.4647, maxLat=51.5223, mapCenterLat=51.4885438, mapCenterLon=-0.1112036),
"hannover": attr_dict(minLon=9.68, maxLon=9.81, minLat=52.33, maxLat=52.39, mapCenterLat=52.362967, mapCenterLon=9.712156),
"sanfrancisco": attr_dict(minLon=-122.495, maxLon=-122.365, minLat=37.695, maxLat=37.795, mapCenterLat=37.73, mapCenterLon=-122.43)
}

'''
MAP_MIN_LAT = 51.4647
MAP_MAX_LAT = 51.5223
MAP_MIN_LON = -0.1978
MAP_MAX_LON = -0.0354
MAP_CENTER_LAT = (MAP_MIN_LAT + MAP_MAX_LAT) / 2
MAP_CENTER_LON = (MAP_MIN_LON + MAP_MAX_LON) / 2

MAP_CELLS_LAT = int(math.ceil((MAP_MAX_LAT - MAP_MIN_LAT)/CELL_SIZE))
MAP_CELLS_LON = int(math.ceil((MAP_MAX_LON - MAP_MIN_LON)/CELL_SIZE))
MAP_CELLS = MAP_CELLS_LAT * MAP_CELLS_LON

MAP_QUADS_LAT = int(math.ceil((MAP_MAX_LAT - MAP_MIN_LAT)/QUAD_SIZE))
MAP_QUADS_LON = int(math.ceil((MAP_MAX_LON - MAP_MIN_LON)/QUAD_SIZE))
MAP_QUADS = MAP_QUADS_LAT * MAP_QUADS_LON
'''

CELL_SIZE = 0.001 # fraction of 1 degree lat/lon
QUAD_SIZE = 0.04
PROXIMITY = 0.0002
#DIST_ROUTE_FAC = 1.43 # 1.2 - 1.4
DIST_ROUTE_FAC = 1.67

SERVICE_STEPS = 25
SERVICE_FEE = 500
SERVICE_CALL_MIN_SIM_STEPS = 200

CHARGE_STEP = 10

#
# *** TODO   next time use learning algorithms to adjust the parameters live, wow !
# *** TODO   if one more week for contest ? more really automated testing with log analysis script highlighting issues
#            will certainly do first at next contest
#

# general job limits
MAX_CONCURRENT_JOBS = 3 # or 3 ?, typically #agents / #avg of items in a job = 4 but allow for friction
MAX_CONCURRENT_AGENTS = 2 # max agents in a shop

# job commit and complete criteria
JOB_MIN_SHOP = 1 # or 2 ? restrictive, select only jobs with items available in min # shops
JOB_NEW_MAX_INCOMPLETE_ITEMS = 2 # or 1
JOB_NEW_MIN_STEPS = 112 # or 121
JOB_MAX_BUY_COST_FAC = 0.90 # or 0.85, percent of reward, protects against expensive unfinished jobs
JOB_MIN_BUY_BALANCE = 1500 # or 1000, min income, reward - buy cost, to use against charge and service
JOB_EST_BUY_FAC = 0.50 # or 0.63; Delphi
JOB_CAPACITY_PERCENT_CLASS = 25 # round volume/capacity percents to multiples of this number; must divide 100 !!!

CC_OP = 0
CC_MIN_POST_STEPS = 10
CC_MAX_POST_STEPS = 30
CC_MIN_A_STEPS = 7 # 77
CC_MAX_A_STEPS = 20 # 220
CC_MIN_REWARD_FAC = 0.43
CC_MAX_REWARD_FAC = 0.50

# job estimation criteria
JOB_STEPS_FAC = 1.33
JOB_ESTIMATE_ITEMS_AMOUNT_FAC = 0.50
JOB_ESTIMATE_ITEMS_COMPLETED_FAC = 0.80 # applied on percent of (amount items/total items)*(distinct items)

JOBS_CLASS_DB = 0
JOBS_CLASS_NEW = 1
JOBS_CLASS_ALL = 2
JOBS_CLASSES_S = ["DB", "NEW", "ALL"]

SEED = 50000

MAX_STEPS = 1000
MAX_INT = sys.maxsize

MAX_ASSEMBLED_ITEMS = 0
MAX_ASSEMBLED_COMPONENTS = 2 # true max is 5

#SHOP_INVENTORY_VALID_LIFE = 0
# === TODO TODO TODO ===
# === (3) === agent/agents assemble item and deliver
# only for MAX_ASSEMBLED_ITEMS, using MAX_ASSEMBLED_COMPONENTS items and
# all recipe items/tools must be available in shop_inventory view

# no support for store, retrieve, dump
# all products held to be used, sensible since ~ every 10 steps a new pricedJob
# op_type =
#   goto
#   service
#   charge
#   abort
#   buy
#   deliver_job



'''
=== NOTE on naming ===

agent = object of an agent, can be used in place of agent_shared too
agent_name etc. are specific attributes
shared = dictionary of all shared data (one per agent)
agent_shared = dictionary entry in 'shared' for specific agent

'''

# all following tuples must be sortable (so can contain only int or str etc. objects)

Duo = collections.namedtuple('Duo', 'value key')
Hexa = collections.namedtuple('Hexa', 'value_sort value0 value1 value2 value_all key')
#Hepta = collections.namedtuple('Hepta', 'value0 value1 value2 value3 value_sort0 value_sort1 key')

# amount first so natural sort by amount if needed
Item_Entry = collections.namedtuple('Item_Entry', 'amount name')

# cost first, new priorities; #amount first so natural sort by amount if needed
Agent_Item = collections.namedtuple('Agent_Item', 'cost amount name agent_name')



# useful generators for simpler code

def facilities(agent_shared, facility_type = None):
  for fac_data in agent_shared.view.facilities.values():
    if facility_type is None or fac_data.facility_type == facility_type:
      yield fac_data

def jobs(agent_shared, job_type = None):
  for job_data in agent_shared.view.jobs.values():
    if job_type is None or job_data.job_type == job_type:
      yield job_data

'''
def products(agent_shared):
  for product_data in agent_shared.sim.products.values():
    yield product_data

def entities(agent_shared):
  for entity_data in agent_shared.view.entities.values():
    yield entity_data

def facility_data(agent_shared, fac_id):
  return agent_shared.view.facilities[fac_id]
'''

def calc_item_volume(agent_shared, item_name, item_amount):
  prod_db = agent_shared.sim.products
  x_product = prod_db[item_name]
  return item_amount * int(x_product.volume)

def calc_self_volume(agent_shared):
  prod_db = agent_shared.sim.products
  self_items = agent_shared.view.self_items
  tot_volume = 0
  for x_item in self_items.values():
    x_product = prod_db[x_item.name]
    tot_volume += int(x_item.amount) * int(x_product.volume)
  return tot_volume

# or s.lower()
def natural_sort_key(str_, _nsre=re.compile(r'(\d+)')):
  return [int(s) if s.isdigit() else s for s in re.split(_nsre, str_)]



def service(agent):
  log = agent._log
  step = agent._step
  sim_steps = MAX_STEPS - step
  shared = agent._shared
  for agent_name, agent_shared in shared.items():
    x = agent_shared.view
    a_self = x.self
    if agent_shared.job_op is None and int(a_self.charge) == 0 and sim_steps >= SERVICE_CALL_MIN_SIM_STEPS:
      action_seq = actions.Action_Seq()
      single_service(log, agent_shared, step, action_seq)
      agent_shared.job_op = action_seq

def single_service(log, agent_shared, step, action_seq):
  x = agent_shared.view
  a_self = x.self
  agent_name = a_self.name
  job_id = team.service_job.get(agent_name, "")
  if job_id:
    del team.service_job[agent_name]
  inFacility = a_self.inFacility
  fac_data = x.facilities.get(inFacility, None)
  if fac_data and fac_data.facility_type == "chargingStation":
    charging_rate = int(fac_data.rate)
    batteryCapacity = int(a_self.batteryCapacity)
    charging_time = int(math.ceil(batteryCapacity/charging_rate))
    log.info("step = {:d}, SMART charge instead of call service for {} {:s}".format(step, agent_name, job_id))
    action_seq.append(actions.op_charge(agent_name, charging_time, _fac_id=inFacility, _job_id=job_id))
  else:
    # TODO ... delay some time ???
    log.info("step = {:d}, call service for {} {:s}".format(step, agent_name, job_id))
    # **args: _job_id (can be "")
    action_seq.append(actions.op_service(agent_name, SERVICE_STEPS, _job_id=job_id))



SETTINGS_SETUP_DICT = {
"MAX_CONCURRENT_JOBS":int,
"MAX_CONCURRENT_AGENTS":int,
"JOB_MIN_SHOP":int,
"JOB_NEW_MAX_INCOMPLETE_ITEMS":int,
"JOB_NEW_MIN_STEPS":int,
"JOB_MAX_BUY_COST_FAC":float,
"JOB_MIN_BUY_BALANCE":int,
"JOB_EST_BUY_FAC":float,
"JOB_CAPACITY_PERCENT_CLASS":int,
"CC_OP":int
}

def settings(agent):
  log = agent._log
  
  SD = SETTINGS_SETUP_DICT
  UTIL = sys.modules["util"]
  config = configparser.ConfigParser()
  config.read("settings.py")
  if not "settings" in config:
    return
  for key, value_s in config["settings"].items():
    key = key.upper()
    log.info("SETTING:   {:s} = {:s}".format(key, value_s))
    if key in SD:
      fun = SD[key]
      value = fun(value_s)
      setattr(UTIL, key, value)

# no use of getattr to be sure !!!
def print_settings(agent):
  log = agent._log
  log.info("=== settings ===")
  log.info("MAX_CONCURRENT_JOBS = {:d}".format(MAX_CONCURRENT_JOBS))
  log.info("MAX_CONCURRENT_AGENTS = {:d}".format(MAX_CONCURRENT_AGENTS))
  log.info("JOB_MIN_SHOP = {:d}".format(JOB_MIN_SHOP))
  log.info("JOB_NEW_MAX_INCOMPLETE_ITEMS = {:d}".format(JOB_NEW_MAX_INCOMPLETE_ITEMS))
  log.info("JOB_NEW_MIN_STEPS = {:d}".format(JOB_NEW_MIN_STEPS))
  log.info("JOB_MAX_BUY_COST_FAC = {:.2f}".format(JOB_MAX_BUY_COST_FAC))
  log.info("JOB_MIN_BUY_BALANCE = {:d}".format(JOB_MIN_BUY_BALANCE))
  log.info("JOB_EST_BUY_FAC = {:.2f}".format(JOB_EST_BUY_FAC))
  log.info("JOB_CAPACITY_PERCENT_CLASS = {:d}".format(JOB_CAPACITY_PERCENT_CLASS))
  log.info("CC_OP = {:d}".format(CC_OP))

# TODO ... template not so smart, may copy opponent's cookies (!), should check for reasonable ones
def CC_op(agent):
  log = agent._log
  '''
  CC_mode = False
  try:
    with open('CC_op.txt') as fh: 
      CC_mode = True
  except IOError as e:
    pass
  '''
  if not CC_OP:
    log.info("CC mode, off")
    return
  #
  shared = agent._shared
  CC_agents = [name for name in shared.keys() if shared[name].job_op is None]
  if not CC_agents:
    log.info("CC mode, on !!!   but no agents to op")
    return
  #
  CC_op_last_step = team.CC_op_last_step
  post_steps = random.randint(CC_MIN_POST_STEPS, CC_MAX_POST_STEPS)
  step = agent._step
  if step - CC_op_last_step < post_steps:
    log.info("CC mode, on !!!   but not in time window to op")
    return
  team.CC_op_last_step = step
  #
  job_spec_top_min_cost = team.job_spec_top_min_cost
  job_spec_top_min_cost_job_id = team.job_spec_top_min_cost_job_id
  job_spec_top_min_cost_job_data = team.job_spec_top_min_cost_job_data
  if not job_spec_top_min_cost_job_id:
    log.info("CC mode, on !!!   but no template to copy")
    return
  #
  # type=priced price= active_steps= storage= item1= amount1= item2= amount2= ...
  #
  agent_name = CC_agents[0]
  agent_shared = shared[agent_name]
  x = agent.view
  CC_storage = min(fac_data.name for fac_data in x.facilities.values() if fac_data.facility_type == "storage")
  CC_a_steps = random.randint(CC_MIN_A_STEPS, CC_MAX_A_STEPS) * 11
  CC_min_reward = int(job_spec_top_min_cost * CC_MIN_REWARD_FAC)
  CC_max_reward = int(job_spec_top_min_cost * CC_MAX_REWARD_FAC)
  CC_reward = random.randint(CC_min_reward, CC_max_reward)
  CC_reward = (CC_reward//7)*7
  CC_spec = {"type":"priced", "price": str(CC_reward), "active_steps":str(CC_a_steps), "storage":CC_storage}
  log.info("CC mode, templating from {:s}".format(job_spec_top_min_cost_job_id))
  job_items = job_spec_top_min_cost_job_data.job_items
  n=1
  for job_item_data in job_items.values():
    CC_spec["item"+str(n)] = job_item_data.name
    CC_spec["amount"+str(n)] = job_item_data.amount
    n += 1
  log.info("{:d} CC mode, {:s} => cookie = {}".format(step, agent_name, CC_spec))    
  #
  action_seq = actions.Action_Seq()
  action_seq.append(actions.op_post_job(agent_name, 1, _job_spec=CC_spec))
  agent_shared.job_op = action_seq

def CC_op_check(agent, reward, begin, end, storage):
  x = agent.view
  CC_storage = min(fac_data.name for fac_data in x.facilities.values() if fac_data.facility_type == "storage")
  if reward%7 == 0 and (end - begin)%11 == 0 and storage == CC_storage:
    return True
  else:
    return False



SPEC_STATE_S = ["select", "ignored"]

# update job_spec_min_buy_cost/job_spec_max_buy_cost/job_spec_blacklist for each new system job
def jobs_spec_update(agent):
  log = agent._log
  #prod_db = agent.sim.products
  
  x = agent.view
  shop_inventory = team.shop_inventory
  fac_dict = x.facilities
  if len(shop_inventory) != sum(1 for fac_data in fac_dict.values() if fac_data.facility_type == "shop"):
    log.info("shop_inventory is not complete, SPEC system not working")
    return
  
  job_spec_min_buy_cost = team.job_spec_min_buy_cost
  job_spec_max_buy_cost = team.job_spec_max_buy_cost
  job_spec_est_buy_cost = team.job_spec_est_buy_cost
  job_spec_checked = team.job_spec_checked
  job_spec_ignored = team.job_spec_ignored
  
  jobs_view = x.jobs
  
  a_self = x.self
  step = int(x.simulation.step)
  
  for job_id in x.jobs_posted:
    job_spec_checked.add(job_id)
    job_spec_ignored.add(job_id)
  
  #for job_data in util.jobs(agent, "pricedJob"):
  for job_id, job_data in jobs_view.items():
    if job_id not in job_spec_checked and job_data.job_type == "pricedJob":
      job_min_buy_cost = 0
      job_max_buy_cost = 0
      job_items_dict = job_data.job_items
      for job_item_name, job_item_data in job_items_dict.items():
        job_item_amount = int(job_item_data.amount)
        item_min_buy_cost = MAX_INT
        item_max_buy_cost = 0
        for fac_id, fac_inv in shop_inventory.items():
          fac_items = fac_inv.data
          if job_item_name in fac_items:
            x_cost = job_item_amount * int(fac_items[job_item_name].cost)
            item_min_buy_cost = min(item_min_buy_cost, x_cost)
            item_max_buy_cost = max(item_max_buy_cost, x_cost)
        job_min_buy_cost += item_min_buy_cost
        job_max_buy_cost += item_max_buy_cost
      #
      job_spec_checked.add(job_id)
      job_spec_min_buy_cost[job_id] = job_min_buy_cost
      job_spec_max_buy_cost[job_id] = job_max_buy_cost
      est_buy_cost = int((job_min_buy_cost*(1+4*(1-JOB_EST_BUY_FAC))+ job_max_buy_cost*(1+4*JOB_EST_BUY_FAC))/6)
      job_spec_est_buy_cost[job_id] = est_buy_cost
      #
      if job_min_buy_cost > team.job_spec_top_min_cost:
        team.job_spec_top_min_cost = job_min_buy_cost
        team.job_spec_top_min_cost_job_id = job_id
        team.job_spec_top_min_cost_job_data = job_data
      #
      reward = int(job_data.reward)
      reward_limit = int(reward * JOB_MAX_BUY_COST_FAC)
      steps = min(int(job_data.end), MAX_STEPS) - step
      spec_ignored = False
      spec_error = ""
      if steps < JOB_NEW_MIN_STEPS:
        spec_ignored = True
        spec_error += ",STEPS"
      if est_buy_cost > reward_limit:
        spec_ignored = True
        spec_error += ",COST"
      if reward - est_buy_cost < JOB_MIN_BUY_BALANCE:
        spec_ignored = True
        spec_error += ",BALANCE"
      if CC_op_check(agent, reward, int(job_data.begin), int(job_data.end), job_data.storage):
        spec_ignored = True
        spec_error += ",CC"
      if spec_ignored:
        job_spec_ignored.add(job_id)
      log.info("{:d} SPEC: {:s} min,max: {:d},{:d}, est: {:d} ~ {:d} (reward = {:d}), steps: {:d} ~ {:d}, {:s}{:s} !!!".format(
        step, job_id, job_min_buy_cost, job_max_buy_cost, est_buy_cost, reward_limit, reward,
        steps, JOB_NEW_MIN_STEPS, SPEC_STATE_S[spec_ignored], spec_error
      ))



# consider only jobs returned by jobs_selection, return dict
# currently if all items available in JOB_MIN_SHOP shops
# TODO ... what if very high reward and 1 <= min_shop < JOB_MIN_SHOP ???
def jobs_selection(agent):
  log = agent._log
  #prod_db = agent.sim.products
  
  job_spec_ignored = team.job_spec_ignored
  fac_dict = agent.view.facilities
  jobs_view = agent.view.jobs
  sel_dict = {}
  #for job_data in util.jobs(agent, "pricedJob"):
  for job_id, job_data in jobs_view.items():
    if job_id not in job_spec_ignored and job_data.job_type == "pricedJob":
      job_items_dict = job_data.job_items
      #mole = 0
      #atom = 0
      #shop = 0
      #total = 0
      min_shop = MAX_INT
      for job_item_name, job_item_data in job_items_dict.items():
        #if job_item_name in prod_db:
        #  prod_data = prod_db[job_item_name]
        #  if prod_data.assembled == "true":
        #    mole += 1
        #  else:
        #   atom += 1
        num_shop = 0
        for fac_data in fac_dict.values():
          if fac_data.facility_type == "shop" and job_item_name in fac_data.extra:
            #if num_shop == 0:
            #  shop += 1
            num_shop += 1
        #total += 1
        if num_shop < min_shop:
          min_shop = num_shop
      if min_shop >= JOB_MIN_SHOP:
        sel_dict[job_id] = job_data
  return sel_dict

#   jobs = dict with key = job_id, value = begin, end, id, reward, storage, job_items => { name: name, amount, delivered, pieces => { id: agent_name, amount, state = ON_BOARD/BUY/DELIVERED } }
# vs
#   jobs => [
#     job_type =
#       pricedJob    begin, end, id, reward, storage, job_items => [ name, amount, ?delivered ]
#       auctionJob   begin, end, fine, id, maxBid, storage, job_items => [ name, amount ]
#   ]

# return jobs_items_dict with unified summary of job items 'needed' (count, amount) from both new and committed jobs
# job items are sorted by density, lower density first
# jobs_class = JOBS_CLASS_DB (committed) / JOBS_CLASS_NEW / JOBS_CLASS_ALL
def jobs_items_needed(agent, jobs_class=JOBS_CLASS_ALL):
  log = agent._log
  
  jobs_db = team.jobs
  
  if jobs_class == JOBS_CLASS_ALL:
    jobs_dict = jobs_selection(agent)
  elif jobs_class == JOBS_CLASS_NEW:
    jobs_dict = {id:data for id, data in jobs_selection(agent).items() if id not in jobs_db._jobs_db}
  elif jobs_class == JOBS_CLASS_DB:
    jobs_dict = jobs_db._jobs_db
  
  ###log.info("jobs_items_needed ({:s}) jobs = {}".format(JOBS_CLASSES_S[job_class], list(jobs_dict.keys())))
  jobs_items_dict = {}
  prod_db = agent.sim.products
  for job_id, job_data in jobs_dict.items():
    if job_id in jobs_db._jobs_db:
      items_needed_count, _ = jobs_db.job_stats(agent, job_id)
      in_jobs_db = True
    else:
      items_needed_count = len(job_data.job_items)
      in_jobs_db = False
    items_list = []
    for job_item_name, job_item_data in job_data.job_items.items():
      if in_jobs_db:
        _, job_item_needed = jobs_db.item_stats(agent, job_id, job_item_name)
      else:
        job_item_needed = int(job_item_data.amount)
      if job_item_needed > 0:
        items_list.append(Duo(job_item_needed, job_item_name))
    # sort by density, amount, name
    if items_list:
      items_list.sort(key = lambda x: (int(prod_db[x.key].volume), x.value, x.key))
      jobs_items_dict[job_id] = items_list
  log.info("=== jobs_items_needed dict ({:s} = {:d}) ===".format(JOBS_CLASSES_S[jobs_class], len(jobs_items_dict)))
  # db first
  for job_id in jobs_db._jobs_db:
    if job_id in jobs_items_dict:
      job_items_data = jobs_items_dict[job_id] 
      log.info("job {:s} (db) =>{}".format(job_id,
        ";".join(" "+item_data.key+","+str(item_data.value) for item_data in job_items_data)
      ))
  # new then
  for job_id in [id for id in jobs_items_dict.keys() if id not in jobs_db._jobs_db]:
    if job_id in jobs_items_dict:
      job_items_data = jobs_items_dict[job_id]
      log.info("job {:s} (new) =>{}".format(job_id,
        ";".join(" "+item_data.key+","+str(item_data.value) for item_data in job_items_data)
      ))
  return jobs_items_dict



# return an agent holding exactly the item_name, item_amount
# else [(cost, amount, name, agent_name)...], in order from low to high amount held
def agents_with_item_onboard(log, shared, item_name, item_amount, storage, steps, steps_cache, filter_agents=None):
  creat = util2.creat
  p = []
  for agent_name in shared.keys():
    if filter_agents is None or agent_name in filter_agents:
      agent_shared = shared[agent_name]
      self_items = agent_shared.view.self_items
      if self_items:
        key = agent_name+"-"+storage
        if key in steps_cache:
          x_steps = steps_cache[key]
        else:
          x_steps = int(math.ceil(creat(log, agent_shared, storage) * JOB_STEPS_FAC))
          steps_cache[key] = x_steps
        if x_steps <= steps:
          for x_self_item in self_items.values():
            if x_self_item.name == item_name:
              x_self_item_amount = int(x_self_item.amount)
              if x_self_item_amount == item_amount:
                return [Agent_Item(0, x_self_item_amount, item_name, agent_name)]
              else:
                p.append(Agent_Item(0, x_self_item_amount, item_name, agent_name))
  return sorted(p)

# return an agent who can buy exactly the item_name, item_amount
# else [(cost, amount, name, agent_name)...], order by cost, new priorities; #in order from high to low amount that can be bought
def agents_with_item_buy(log, shared, item_name, item_amount, storage, steps, steps_cache, filter_agents=None):
  for agent_shared_0 in shared.values():
    break
  prod_db = agent_shared_0.sim.products
  x_product = prod_db[item_name]
  x_product_volume = int(x_product.volume)
  creat = util2.creat
  p = []
  for agent_name in shared.keys():
    if filter_agents is None or agent_name in filter_agents:
      agent_shared = shared[agent_name]
      x = agent_shared.view
      a_self = x.self
      inFacility = a_self.inFacility
      fac_data = x.facilities.get(inFacility, None)
      if fac_data is not None and fac_data.facility_type == "shop": # x.self.inFacility != "none"
        key = agent_name+"-"+storage
        if key in steps_cache:
          x_steps = steps_cache[key]
        else:
          x_steps = int(math.ceil(creat(log, agent_shared, storage) * JOB_STEPS_FAC))
          steps_cache[key] = x_steps
        if x_steps <= steps:
          for x_buy_item in fac_data.extra.values():
            if x_buy_item.name == item_name:
              x_buy_item_amount = min(int(x_buy_item.amount), item_amount)
              x_load = int(a_self.load)
              x_loadCapacity = int(a_self.loadCapacity)
              if x_load + (x_buy_item_amount * x_product_volume) <= x_loadCapacity:
                p.append(Agent_Item(int(x_buy_item.cost), x_buy_item_amount, item_name, agent_name))
  #return sorted(p, reverse=True)
  return sorted(p)

# committed jobs
def complete_jobs(agent):
  core_setup_jobs(agent, new_flag=False)

# new jobs
def new_jobs(agent):
  if len(team.jobs._jobs_db.keys()) >= MAX_CONCURRENT_JOBS:
    return
  core_setup_jobs(agent, new_flag=True)

JOBS_FLAG_S = ["db", "new"]

def core_setup_jobs(agent, new_flag):
  log = agent._log
  shared = agent._shared
  step = agent._step
  
  avail_agents = set(name for name in shared.keys() if shared[name].job_op is None)
  
  log.info("core_setup_jobs ({:s}), avail_agents = {:d} {}".format(JOBS_FLAG_S[new_flag], len(avail_agents), avail_agents))
  
  if not avail_agents:
    log.info("no agents for core_setup_jobs !")
    return
  log.info("")
  
  # 3 lists
  # items on board to deliver for a job, but agent may have for many jobs, must prioritize
  #   => job_op of goto storage, deliver_job, for a specific job a list of items
  # items to buy if agent is inside shop, agent buys as many as possible again with priority
  #   => job_op of buy, goto storage, deliver_job, for a specific job a list of items
  # completed jobs so these are first to act on
  #   dict by job_id of #items completed or MAX_INT if fully completed
  
  # unified dict of job needs
  jobs_items_dict = jobs_items_needed(agent, new_flag)
  
  jobs_db = team.jobs
  jobs_view = agent.view.jobs
  
  on_cache = {}
  buy_cache = {}
  job_cache = {}
  
  steps_cache = {}
  
  jobs_ids = set(jobs_items_dict.keys())
  # loop by job to complete or commit to
  for job_id in list(jobs_ids):
    job_data = jobs_view[job_id]
    storage = job_data.storage
    end_step = min(int(job_data.end), MAX_STEPS)
    steps = end_step - step
    if new_flag and steps < JOB_NEW_MIN_STEPS:
      jobs_ids.remove(job_id)
      log.log(main.LOG_OP, "setup_pre job_id: {:s}, storage = {:s}, steps = {:d} < {:d} skipped".format(
        job_id, storage, steps, JOB_NEW_MIN_STEPS
      ))
      continue
    log.log(main.LOG_OP, "setup_pre job_id: {:s}, storage = {:s}, steps = {:d}".format(job_id, storage, steps))
    reward = int(job_data.reward)
    job_cache[job_id] = (storage, end_step, steps, reward)
    job_items_list = jobs_items_dict[job_id]
    for job_item_amount, job_item_name in job_items_list:
      # agent holds item
      x_on = agents_with_item_onboard(log, shared, job_item_name, job_item_amount, storage, steps, steps_cache, avail_agents)
      on_cache[job_id+"-"+job_item_name] = x_on
      log.log(main.LOG_OP, "   setup_pre  on {:s},{:d} ={}".format(job_item_name, job_item_amount,
        ";".join(" "+agent_name+":"+name+","+str(amount) for cost, amount, name, agent_name in x_on)
      ))
      # agent inside shop can BUY, can be same agent with onboard items in previous loop
      x_buy = agents_with_item_buy(log, shared, job_item_name, job_item_amount, storage, steps, steps_cache, avail_agents)
      buy_cache[job_id+"-"+job_item_name] = x_buy
      log.log(main.LOG_OP, "   setup_pre buy {:s},{:d}  ={}".format(job_item_name, job_item_amount,
        ";".join(" "+agent_name+":"+name+","+str(amount)+"@"+str(cost) for cost, amount, name, agent_name in x_buy)
      ))
  
  log.log(main.LOG_OP, "")
  
  # TODO order by some priority ???
  # TODO agent could buy for many jobs ??? !!! (future)      
  creat = util2.creat
  while len(jobs_ids) > 0:
    
    on_list = collections.defaultdict(list)
    buy_list = collections.defaultdict(list)
    jobs_completed_items = collections.defaultdict(int)
    jobs_needed_items = collections.defaultdict(int)
    
    # loop by job to complete or commit to
    for job_id in list(jobs_ids):
      log.log(main.LOG_OP, "setup_core job_id: {:s}".format(job_id))
      storage, end_step, steps, reward = job_cache[job_id]
      job_items_list = jobs_items_dict[job_id]
      items_needed_count = len(job_items_list)
      jobs_needed_items[job_id] = items_needed_count
      agent_capacity = {}
      buy_cost = 0
      for job_item_amount, job_item_name in job_items_list:
        # agent holds item
        for x_cost, x_amount, x_name, agent_name in on_cache[job_id+"-"+job_item_name]:
          if agent_name not in avail_agents:
            continue
          log.log(main.LOG_OP, "   setup_core {:s}  (on) => {:s}, {:d}".format(agent_name, x_name, x_amount))
          use_amount = min(job_item_amount, x_amount)
          on_list[job_id].append(Agent_Item(0, use_amount, job_item_name, agent_name))
          job_item_amount -= use_amount
          if job_item_amount == 0:
            jobs_completed_items[job_id] += 1
            log.log(main.LOG_OP, "   setup_core {:s}  (on) completed !!!".format(job_item_name))
            break
        if jobs_completed_items[job_id] == items_needed_count:
          log.info("*** setup_core  (on) {:s} completed !!!".format(job_id))
          break
        if job_item_amount == 0:
          continue
        # agent inside shop can BUY, can be same agent with onboard items in previous loop
        for x_cost, x_amount, x_name, agent_name in buy_cache[job_id+"-"+job_item_name]:
          if agent_name not in avail_agents:
            continue
          log.log(main.LOG_OP, "   setup_core {:s} (buy) => {:s}, {:d}".format(agent_name, x_name, x_amount))
          use_amount = min(job_item_amount, x_amount)
          #
          z_shared = shared[agent_name]
          z_self = z_shared.view.self
          if agent_name in agent_capacity:
            x_capacity = agent_capacity[agent_name]
          else:
            z_load = int(z_self.load)
            z_loadCapacity = int(z_self.loadCapacity)
            x_capacity = z_loadCapacity - z_load
            agent_capacity[agent_name] = x_capacity
          #
          x_volume = calc_item_volume(z_shared, x_name, x_amount)
          if x_volume > x_capacity:
            log.log(main.LOG_OP, "   setup_core {:s} (buy) reached capacity limit !!!".format(job_item_name))
            continue
          x_capacity -= x_volume
          agent_capacity[agent_name] = x_capacity
          #
          x_buy_cost = use_amount * x_cost
          buy_cost += x_buy_cost
          buy_list[job_id].append(Agent_Item(x_buy_cost, use_amount, job_item_name, agent_name))
          job_item_amount -= use_amount
          if job_item_amount == 0:
            jobs_completed_items[job_id] += 1
            log.log(main.LOG_OP, "   setup_core {:s} (buy) completed !!!".format(job_item_name))
            break
        if jobs_completed_items[job_id] == items_needed_count:
          log.info("*** setup_core (buy) {:s} completed !!!".format(job_id))
          break
        if job_item_amount == 0:
          continue
      
      log.info("*** setup_core {:s} => {:d}/{:d} items completed, buy_cost = {:d}".format(
        job_id, jobs_completed_items[job_id], items_needed_count, buy_cost
      ))
      
      # TODO ... priority for agents inside storage with on board items to deliver ??? (already ?)
      # criteria for new jobs
      # TODO ... validate !!!
      if (not on_list[job_id] and not buy_list[job_id]):
        log.info("*** setup_core {:s}, no agents !".format(job_id))
        jobs_ids.remove(job_id)
        continue
      if (new_flag and (items_needed_count - jobs_completed_items[job_id]) > JOB_NEW_MAX_INCOMPLETE_ITEMS):
        log.info("*** setup_core {:s} => {:d}/{:d}, more than {:d} incomplete items !".format(
          job_id, jobs_completed_items[job_id], items_needed_count, JOB_NEW_MAX_INCOMPLETE_ITEMS
        ))
        jobs_ids.remove(job_id)
        continue
      # following subsumed by spec system
      '''
      buy_limit = round(reward * JOB_MAX_BUY_COST_FAC * jobs_completed_items[job_id]/max(items_needed_count, 1))
      if (new_flag and buy_cost > buy_limit):
        log.info("   *** setup_core {:s}, buy_cost {:d} exceeds limit {:d} of reward = {:d} !".format(
          job_id, buy_cost, buy_limit, reward
        ))
        jobs_ids.remove(job_id)
        continue
      '''
    
    # choose job_id, generate ops, adjust team.jobs
    if len(jobs_ids) > 0:
      # add reward - buy_cost in sort order !!!
      jobs_priq = [(
          MAX_INT if jobs_completed_items[job_id] == jobs_needed_items[job_id] else jobs_completed_items[job_id],
          reward - buy_cost, end_step, job_id
        ) for job_id in jobs_ids]
      #
      log.info("TEMP: jobs_priq = {}".format(sorted(jobs_priq, reverse=True)))
      #
      best = sorted(jobs_priq, reverse=True)[0]
      job_id = best[3]
      log.info("*** scheduling {:s}".format(job_id))
      storage = jobs_view[job_id].storage
      # generate ops, adjust team.jobs
      if new_flag:
        jobs_db.job_add(agent, job_id)
      on_agent = collections.defaultdict(list)
      buy_agent = collections.defaultdict(list)
      for cost, amount, name, agent_name in on_list[job_id]:
        on_agent[agent_name].append(Duo(amount, name))
      for cost, amount, name, agent_name in buy_list[job_id]:
        buy_agent[agent_name].append(Duo(amount, name))
      #
      agents = set(on_agent.keys()).union(buy_agent.keys())
      for agent_name in agents:
        action_seq = actions.Action_Seq()
        agent_shared = shared[agent_name]
        x = agent_shared.view
        a_self = x.self
        inFacility = a_self.inFacility
        charge = int(a_self.charge)
        # combine onboard + buy in same agent delivery
        if agent_name in on_agent:
          for item_amount, item_name in on_agent[agent_name]:
            piece_id = jobs_db.piece_add(agent, job_id, agent_name, item_name, item_amount, "ON_BOARD")
        if agent_name in buy_agent:
          for item_amount, item_name in buy_agent[agent_name]:
            piece_id = jobs_db.piece_add(agent, job_id, agent_name, item_name, item_amount, "BUY")
            action_seq.append(
              # **args: _item_name, _item_amount, _fac_id, _job_id, _piece_id
              actions.op_buy(agent_name, 1,
                _item_name=item_name, _item_amount=item_amount, _fac_id=inFacility, _job_id=job_id, _piece_id=piece_id
            ))
        # SMART schedule (!)
        # can buy and do nothing else if no charge allowing for call service in next step (limit buys ??? TODO ...)
        # can be in storage and deliver immediately without need for call service
        if inFacility != storage:
          if charge == 0:
            single_service(log, agent_shared, step, action_seq)
          util2.creat(log, agent_shared, storage, action_seq=action_seq, job_id=job_id)
        # **args: _job_id, _fac_id
        action_seq.append(actions.op_deliver_job(agent_name, 1, _job_id=job_id, _fac_id=storage))
        schedule_type = ""
        if inFacility == storage or charge == 0:
          schedule_type = "SMART "
        if len(action_seq) > 0:
          agent_shared.job_op = action_seq
          avail_agents.remove(agent_name)
          log.info("*** setup {:s}schedule: {:s} => {:d} actions = {}".format(
            schedule_type, agent_name, len(action_seq), [str(x) for x in agent_shared.job_op]
          ))
      jobs_ids.remove(job_id)
    
    if len(jobs_db._jobs_db.keys()) >= MAX_CONCURRENT_JOBS:
      return



# for a 'job_id' and 'items_list' of job items, and a shop 'fac_id'
# return (items_count, items_amount, items_volume) that can be bought
# _count = distinct item(s) that can bought fully (complete buys)
# _amount = amount of all items
# _volume = volume of all items
def shop_estimate(agent, job_id, items_list, fac_id):
  log = agent._log
  shared = agent._shared
  
  log.debug("shop_estimate for {:s}, {:s}".format(fac_id, job_id))
  
  fac_view = agent.view.facilities
  shop_inventory = team.shop_inventory
  if fac_id in shop_inventory:
    fac_items = shop_inventory[fac_id].data
    fac_inventory = True
  else:
    fac_items = fac_view[fac_id].extra
    fac_inventory = False
  
  prod_db = agent.sim.products
      
  items_count = 0
  items_amount = 0
  items_volume = 0
  total_count = len(items_list)
  total_amount = 0
  log.debug("   items_list ={}".format(
    ";".join(" "+item_duo.key+","+str(item_duo.value) for item_duo in items_list)
  ))
  if fac_inventory:
    log.debug("   fac_items (data) ={}".format(
      ";".join(" "+item_data.name+","+str(item_data.amount) for item_data in fac_items.values())
    ))
  else:
    log.debug("   fac_items (view) ={}".format(
      ";".join(" "+item_data.name for item_data in fac_items.values())
    ))
  #for x_item_duo, x_item_info in join(items_list, "key", fac_items.values(), "name"):
  for item_duo in items_list:
    x_item_name = item_duo.key
    x_item_amount = item_duo.value
    total_amount += x_item_amount
    x_item_density = int(prod_db[x_item_name].volume)
    x_amount = 0
    if x_item_name in fac_items:
      if fac_inventory:
        x_amount = min(x_item_amount, int(fac_items[x_item_name].amount))
        if x_amount == x_item_amount:
          items_count += 1
      else:
        # speculated, calculation such that 1 => 1 with any FAC
        x_amount = int(math.ceil(x_item_amount * JOB_ESTIMATE_ITEMS_AMOUNT_FAC))
    x_volume = x_amount * x_item_density
    items_amount += x_amount
    items_volume += x_volume
  if not fac_inventory:
    if total_amount > 0:
      # speculated, calculation such that 1 => 1 with any FAC
      items_count = int(math.ceil((items_amount/total_amount) * total_count * JOB_ESTIMATE_ITEMS_COMPLETED_FAC))
  log.debug("   *** shop_estimate = {:d}/{:d} {:.2f}, {:d}/{:d} {:.2f} (volume = {:d})".format(
    items_count, total_count, items_count/max(total_count, 1),
    items_amount, total_amount, items_amount/max(total_amount, 1),
    items_volume
  ))
  return items_count, items_amount, items_volume

SINGLE_S = ["Not Single", "Single"]

# type = pricedJob   begin, end, id, reward, storage, job_items => [ name, amount, ?delivered ]
# type = storage => lat, lon, name, price, extra => [ name, ?stored, ?delivered ]
#   jobs = dict with key = job_id, value = begin, end, id, reward, storage, job_items => { name: name, amount, delivered, pieces => { id: agent_name, amount, state = ON_BOARD/BUY/DELIVERED } }
# TODO swap agent positions ??? (capacity constraints); already done with high probability !!!
# TODO ... reduce gotos(s) !!!
def explore_jobs(agent):
  log = agent._log
  shared = agent._shared
  step = agent._step
  
  fac_agents = team.fac_agents
  fac_goto = team.fac_goto
  fac_view = agent.view.facilities
  
  avail_agents = set(name for name in shared.keys() if shared[name].job_op is None and int(shared[name].view.self.charge) > 0)
  # not consider shop if reached MAX_CONCURRENT_AGENTS
  avail_shops = set(
    fac_id for fac_id, fac_data in fac_view.items()
      if fac_data.facility_type == "shop" and len(fac_agents[fac_data.name]) + len(fac_goto[fac_data.name]) < MAX_CONCURRENT_AGENTS
  )
  
  log.info("explore_jobs, avail_shops = {}, avail_agents = {:d} {}".format(avail_shops, len(avail_agents), avail_agents))
  
  if not avail_shops or not avail_agents:
    log.info("explore_jobs, no shops or agents !")
    return
  log.info("")
  
  # unified dict of job needs
  jobs_items_dict = jobs_items_needed(agent, JOBS_CLASS_ALL)
  
  jobs_db = team.jobs
  jobs_view = agent.view.jobs
  
  log.info("")
  # cache of shop items that can be bought by job_id
  shop_items_cache = {}
  # list of total shop items that can be bought for all jobs
  shop_items_list = []
  for fac_id in avail_shops:
    jobs_items_count = 0
    jobs_items_amount = 0
    jobs_items_volume = 0
    all_items_count = 0
    all_items_amount = 0
    all_items_volume = 0
    for job_id, job_items_list in jobs_items_dict.items():
      x_estimate = shop_estimate(agent, job_id, job_items_list, fac_id)
      shop_items_cache[fac_id+"-"+job_id] = x_estimate
      x_items_count, x_items_amount, x_items_volume = x_estimate
      if job_id in jobs_db._jobs_db:
        jobs_items_count += x_items_count
        jobs_items_amount += x_items_amount
        jobs_items_volume += x_items_volume
      all_items_count += x_items_count
      all_items_amount += x_items_amount
      all_items_volume += x_items_volume
    log.info("{:s} *** explore estimate: {:d}/{:d} {:.2f}, {:d}/{:d} {:.2f}".format(
      fac_id, jobs_items_count, all_items_count, jobs_items_count/max(all_items_count, 1),
      jobs_items_amount, all_items_amount, jobs_items_amount/max(all_items_amount, 1)
    ))
    # !!! NOTE !!! don't limit by jobs in db, need to explore initially and go to shops before first job posted
    # #consider only if jobs in db can be completed; should work too with no shop_inventory
    #if jobs_items_count > 0 or jobs_items_amount > 0:
    shop_items_list.append(
      (jobs_items_count, jobs_items_amount, jobs_items_volume, all_items_count, all_items_amount, all_items_volume, fac_id)
    )
  
  # loop, for each shop (in order of most promising shop first)
  # find best agent that can complete most jobs in time and carry most items
  # remove agent and repeat
  # no need to handle cases of many superfluous agents to same shop
  # as existing agent will buy items (first in order of action selections) and reduce suitability
  
  log.info("")
  creat = util2.creat
  steps_cache = {}
  for x_jobs_items_count, x_jobs_items_amount, x_jobs_items_volume, x_all_items_count, x_all_items_amount, x_all_items_volume, fac_id in [x for x in sorted(shop_items_list, reverse=True)]:
    if not avail_agents:
      break
    # all agents even in same shop so that reduce unnecessary moves
    #agents_list = [x for x in avail_agents if shared[x].view.self.inFacility != fac_id]
    agents_list = avail_agents
    log.info("explore_jobs for {:s} ({:d},{:d} ; {:d},{:d}), agents = {}".format(
      fac_id, x_jobs_items_count, x_jobs_items_amount, x_all_items_count, x_all_items_amount, agents_list
    ))
    if not agents_list:
      continue
    #
    jobs_items_count, jobs_items_amount, jobs_items_volume, all_items_count, all_items_amount, all_items_volume = x_jobs_items_count, x_jobs_items_amount, x_jobs_items_volume, x_all_items_count, x_all_items_amount, x_all_items_volume
    #
    q = []
    for agent_name in agents_list:
      agent_shared = shared[agent_name]
      x = agent_shared.view
      a_self = x.self
      self_volume = calc_self_volume(agent_shared)
      self_loadCapacity = int(a_self.loadCapacity)
      self_avail_capacity = self_loadCapacity - self_volume
      # treat all agents same to speed up loop, practically little difference
      '''
      jobs_items_count = 0
      jobs_items_amount = 0
      jobs_items_volume = 0
      all_items_count = 0
      all_items_amount = 0
      all_items_volume = 0
      '''
      key_1 = agent_name + "-" + fac_id
      if key_1 in steps_cache:
        steps_value_1 = steps_cache[key_1]
      else:
        steps_value_1 = creat(log, agent_shared, fac_id)
        steps_cache[key_1] = steps_value_1
      '''
      for job_id in jobs_items_dict.keys():
        job_data = jobs_view[job_id]
        storage = job_data.storage
        steps = min(int(job_data.end), MAX_STEPS) - step
        key_2 = fac_id + "-" + storage
        if key_2 in steps_cache:
          steps_value_2 = steps_cache[key_2]
        else:
          steps_value_2 = creat(log, agent_shared, storage, src_id=fac_id)
          steps_cache[key_2] = steps_value_2
        x_steps =  steps_value_1 + steps_value_2
        log.debug("   explore {:s} ({:d}/{:d} = {:d}); job = {:s}, steps = {:d} (max {:d})".format(
           agent_name, self_volume, self_loadCapacity, self_avail_capacity, job_id, x_steps, steps
        ))
        if x_steps > steps:
          continue
        x_items_count, x_items_amount, x_items_volume = shop_items_cache[fac_id+"-"+job_id]
        if job_id in jobs_db._jobs_db:
          jobs_items_count += x_items_count
          jobs_items_amount += x_items_amount
          jobs_items_volume += x_items_volume
        all_items_count += x_items_count
        all_items_amount += x_items_amount
        all_items_volume += x_items_volume
      '''
      
      inFacility = a_self.inFacility
      in_shop = 0
      fac_data = x.facilities.get(inFacility, None)
      if fac_data and fac_data.facility_type == "shop":
        in_shop = 1
      '''
      log.info("   *** explore {:s} => {:d},{:d} (v: {:d}) ; {:d},{:d} (v: {:d}); L: {:d}, -shop: {:d}, s_1: {:d}".format(
        agent_name,
        jobs_items_count, jobs_items_amount, jobs_items_volume, all_items_count, all_items_amount, all_items_volume,
        self_avail_capacity, not_in_shop, steps_value_1
      ))
      '''
      charge = int(a_self.charge)
      capacity_fac = round(100*jobs_items_volume/max(self_avail_capacity, 1))
      log.info("   *** explore {:s} => {:d} (v: {:d}), L: {:d} ({:d}%), B: {:d}, shop: {:d}, s_1: {:d}".format(
        agent_name, jobs_items_count, jobs_items_volume, self_avail_capacity, capacity_fac, charge, in_shop, steps_value_1
      ))
      #
      # !!! critical sort !!!
      #
      # in_shop = 1 if in shop else 0 so 'not in shop' sorts lower
      #
      # if ...
      #
      # add self_avail_capacity and charge combined with steps to shop as ratio steps/charge
      sort_capacity_fac = int(int(math.ceil(capacity_fac/JOB_CAPACITY_PERCENT_CLASS)) * JOB_CAPACITY_PERCENT_CLASS)
      q.append(
        (sort_capacity_fac, in_shop, -self_avail_capacity, steps_value_1/max(charge, 1), steps_value_1, agent_name)
      )
    
    # if jobs_items_dict is empty then semi-random forwarding only if no agent in shop and agent in jungle !!!
    # priority for committed jobs, avail_capacity and nearest agent (steps_value_1)
    # TODO ... agent avail_capacity, nearness/battery and reward should enter a more elaborate calculation/order formula !!!
    # generate ops
    if q:
      #
      log.info("TEMP: q = {}".format(sorted(q)))
      #
      best = sorted(q)[0]
      #jobs_items_count, jobs_items_amount, all_items_count, all_items_amount, not_in_shop, _, s_1, agent_name = best
      sort_capacity_fac, in_shop, *X_DUMMY, steps_value_1, agent_name = best
      agent_shared = shared[agent_name]
      inFacility = agent_shared.view.self.inFacility
      # no creat if
      #   already in a shop and
      #   extra benefit to new shop is negligible (?! bogus calculation ?, TODO ... validate !!!)
      # TODO cost/benefit analysis !!!
      #in_shop = not not_in_shop
      single_in_shop = False
      single_s = ""
      if in_shop:
        single_in_shop = ( (len(fac_agents[inFacility]) + len(fac_goto[inFacility])) == 1 )
        single_s = SINGLE_S[single_in_shop]
      log.info("*** explore best = {:s}   {:d}%, shop: {:d}, s_1: {:d}   inFacility = {:s} {:s}".format(
        agent_name, sort_capacity_fac, in_shop, steps_value_1, inFacility, single_s
      ))
      # if already in this shop, ignore
      if inFacility == fac_id:
        continue
      benefit = (jobs_items_count > 0)
      if ((benefit and not single_in_shop) or not in_shop):
        action_seq = actions.Action_Seq()
        log.info("=== explore creat {:s} => {:s}  ({:d},{:d} ; {:d},{:d})".format(
          agent_name, fac_id, jobs_items_count, jobs_items_amount, all_items_count, all_items_amount
        ))
        creat(log, agent_shared, fac_id, action_seq=action_seq)
        # just in case creat catches case of no charge
        if action_seq:
          agent_shared.job_op = action_seq
          team.explore_count += 1
          avail_agents.remove(agent_name)



# TODO ... this is very important and must do as soon as possible !!!
# drop jobs if considered to be difficult/impossible to finish
# or most important if new jobs arrive that are of higher reward and/or may finish faster
def drop_jobs(agent):
  pass

# TODO ...
def dump_ops(agent):
  pass