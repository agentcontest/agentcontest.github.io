
"""

 /*
  * @(#) E.Sarmas   util2.py 1.29e (2016-09-12)
  *
  * Author: E.Sarmas
  *
  * Created: 2016-09-10
  *
  * Description: Flisvos 2016 (MAPC 2016)
  *
  * Version: 1.29e
  * Version-Date: 2016-09-12
  *
  */

"""

import math
import util
import actions
import team

'''
# nested loop
def nested_join(list1, field1, list2, field2):
  p = []
  for d1 in list1:
    d1_key = getattr(d1, field1)
    for d2 in list2:
      if d1_key == getattr(d2, field2):
        p.append((d1, d2))
        break
  return p

# efficient join needed even with lists of small size !!!
# list1, list2 are lists of objects
def sort_join(list1, field1, list2, field2):
  l = sorted(list1, key=lambda x: getattr(x, field1))
  r = sorted(list2, key=lambda x: getattr(x, field2))
  p = []
  lx = 0; lz = len(l)
  rx = 0; rz = len(r)
  while lx < lz and rx < rz:
    lval = l[lx]; lkey = getattr(l[lx], field1)
    rval = r[rx]; rkey = getattr(r[rx], field2)
    if lkey == rkey:
      p.append((lval, rval))
      lx += 1
      rx += 1
    elif lkey < rkey:
      lx += 1
    elif lkey > rkey:
      rx += 1
  return p

def hash_join(list1, field1, list2, field2):
  # list_h   hashed list
  # list_o   other list to compare with hashed
  if len(list1) < len(list2):
    list_h = list1; field_h = field1
    list_o = list2; field_o = field2
    swap = False
  else:
    list_h = list2; field_h = field2
    list_o = list1; field_o = field1
    swap = True
  h = {getattr(obj_h, field_h): obj_h for obj_h in list_h}
  p = []
  for obj_o in list_o:
    field_x = getattr(obj_o, field_o)
    if field_x in h:
      if swap:
        p.append((obj_o, h[field_x]))
      else:
        p.append((h[field_x], obj_o))
  return p

def test_joins(log):
  #list1 = [Duo("x"+str(x), x) for x in range(0, 1000000, 100000)]
  #list2 = [Duo("y"+str(y), y) for y in range(0, 1000000, 1)]
  list1 = [Duo("x"+str(x), x) for x in range(0, 15, 1)]
  list2 = [Duo("y"+str(y), y) for y in range(0, 15, 1)]
  random.shuffle(list1)
  random.shuffle(list2)
  t1 = time.time()
  for i in range(1000):
    p_sort = sort_join(list2, "key", list1, "key")
  t2 = time.time()
  log.info("sort_join: {:.3f} s".format(t2 - t1))
  t1 = time.time()
  for i in range(1000):
    p_hash = hash_join(list2, "key", list1, "key")
  t2 = time.time()
  log.info("hash_join: {:.3f} s".format(t2 - t1))
  t1 = time.time()
  for i in range(1000):
    p_nested = nested_join(list2, "key", list1, "key")
  t2 = time.time()
  log.info("nested_join: {:.3f} s".format(t2 - t1))
  if sorted(p_sort) != sorted(p_hash) or sorted(p_hash) != sorted(p_nested) or sorted(p_nested) != sorted(p_sort):
    log.error("join results are different !")

join = hash_join
'''



'''
# common iterable for lists and dicts
def common_iterable(obj):
  if isinstance(obj, dict):
    return obj.values()
  else:
    return obj
'''



'''
# generate test actions for 2 agents
def test_actions(agent):
  log = agent._log
  for agent_name in [main.AGENT_PREFIX + "1", main.AGENT_PREFIX + "2"]:
    if agent_name in agent._shared and agent._shared[agent_name].job_op is None:
      log.info("test_actions for {:s}".format(agent_name))
      agent_shared = agent._shared[agent_name]
      action_seq = actions.Action_Seq()
      op_goto = actions.op_goto
      if agent_shared.view.self.inFacility == "none":
        fac_id = "shop0"
        op_goto.creat(log, agent_shared, fac_id, action_seq=action_seq)
      elif agent_shared.view.self.inFacility == "shop0":
        fac_id = "shop1"
        op_goto.creat(log, agent_shared, fac_id, action_seq=action_seq)
      if len(action_seq) > 0:
        agent_shared.job_op = action_seq
        log.info("test set {:s} => {:d} actions = {}".format(agent_name, len(action_seq), [str(x) for x in agent_shared.job_op]))

import random

# generate test actions for 2 agents
def test_actions_v2(agent):
  log = agent._log
  for agent_name in [main.AGENT_PREFIX + "1", main.AGENT_PREFIX + "2"]:
    if agent_name in agent._shared and agent._shared[agent_name].job_op is None:
      log.info("test_actions_v2 for {:s}".format(agent_name))
      agent_shared = agent._shared[agent_name]
      action_seq = actions.Action_Seq()
      op_goto = actions.op_goto
      op_buy = actions.op_buy
      jobs_db = team.jobs
      x = agent_shared.view
      a_self = x.self
      inFacility = a_self.inFacility
      self_items = x.self_items
      if inFacility != "none":
        fac_data = x.facilities[inFacility]
        item_name = None
        item_amount = None
        job_id = None
        if fac_data.facility_type == "shop":
          self_volume = calc_self_volume(agent)
          self_loadCapacity = int(a_self.loadCapacity)
          for item_data in fac_data.extra.values():
            item_name = item_data.name
            if item_name not in self_items:
              for job_data in jobs(agent_shared, "pricedJob"):
                job_id = job_data.id
                if item_name in job_data.job_items:
                  if job_id in jobs_db._jobs_db:
                    total, needed = jobs_db.item_stats(agent, job_id, item_name)
                    if total > 0:
                      continue
                  item_amount = min(int(item_data.amount), int(job_data.job_items[item_name].amount))
                  item_volume = calc_item_volume(agent, item_name, item_amount)
                  if item_volume + self_volume <= self_loadCapacity:
                    break
                  else:
                    item_amount = None
            if item_amount is not None:
              break
          if item_amount is not None:
            if job_id not in jobs_db._jobs_db:
              jobs_db.job_add(agent, job_id)
            piece_id = jobs_db.piece_add(agent, job_id, agent_name, item_name, item_amount, "BUY")
            # **args: _item_name, _item_amount, _fac_id, _job_id, _piece_id
            action_seq.append(
              # **args: _item_name, _item_amount, _fac_id, _job_id, _piece_id
              op_buy(agent_name, 1,
                _item_name=item_name, _item_amount=item_amount, _fac_id=inFacility, _job_id=job_id, _piece_id=piece_id
            ))
      # should choose shops that are reachable with battery
      # but leave it as it tests service op too
      shops = [x_fac for x_fac in facilities(agent_shared, "shop") if x_fac.name != inFacility]
      fac_data = random.choice(shops)
      fac_id = fac_data.name
      creat(log, agent_shared, fac_id, action_seq=action_seq)
      if len(action_seq) > 0:
        agent_shared.job_op = action_seq
        log.info("test set {:s} => {:d} actions = {}".format(agent_name, len(action_seq), [str(x) for x in agent_shared.job_op]))
'''



def set_map(agent):
  map_name = agent.sim.simulation.map
  map_data = util.MAPS[map_name]
  util.MAP_MIN_LAT = map_data.minLat
  util.MAP_MAX_LAT = map_data.maxLat
  util.MAP_MIN_LON = map_data.minLon
  util.MAP_MAX_LON = map_data.maxLon
  util.MAP_CENTER_LAT = (util.MAP_MIN_LAT + util.MAP_MAX_LAT) / 2
  util.MAP_CENTER_LON = (util.MAP_MIN_LON + util.MAP_MAX_LON) / 2
  
  util.MAP_CELLS_LAT = int(math.ceil((util.MAP_MAX_LAT - util.MAP_MIN_LAT)/util.CELL_SIZE))
  util.MAP_CELLS_LON = int(math.ceil((util.MAP_MAX_LON - util.MAP_MIN_LON)/util.CELL_SIZE))
  util.MAP_CELLS = util.MAP_CELLS_LAT * util.MAP_CELLS_LON
  
  util.MAP_QUADS_LAT = int(math.ceil((util.MAP_MAX_LAT - util.MAP_MIN_LAT)/util.QUAD_SIZE))
  util.MAP_QUADS_LON = int(math.ceil((util.MAP_MAX_LON - util.MAP_MIN_LON)/util.QUAD_SIZE))
  util.MAP_QUADS = util.MAP_QUADS_LAT * util.MAP_QUADS_LON

# self, fac(s) are dictionaries with lat, lon
# result in steps of CELL_STEP size
def steps_direct(log, agent_shared, dst_fac, src_fac=None):
  a_self = agent_shared.view.self
  agent_name = a_self.name
  if src_fac is None:
    log.debug("steps_direct {:s} -> {:s}".format(agent_name, dst_fac.name))
  else:
    log.debug("steps_direct {:s}, {:s} -> {:s}".format(agent_name, src_fac.name, dst_fac.name))
  speed = int(agent_shared.sim.role.speed)
  CELL_STEP = util.CELL_SIZE * speed
  if src_fac is None:
    lat1 = float(a_self.lat)
    lon1 = float(a_self.lon)
  else:
    lat1 = float(src_fac.lat)
    lon1 = float(src_fac.lon)  
  lat2 = float(dst_fac.lat)
  lon2 = float(dst_fac.lon)
  #slat = (lat1 + lat2)/2 * RAD_1DEG
  dlon = (lon2 - lon1) / CELL_STEP
  dlat = (lat2 - lat1) / CELL_STEP
  #dist = R * math.sqrt(dlat**2 + (dlon*math.cos(slat))**2)
  steps = int(math.ceil(math.sqrt(dlat**2 + dlon**2)))
  log.debug("steps_direct {:.4f},{:.4f} -> {:.4f},{:.4f} = {:d} (speed = {:d} CELL_STEP = {:.4f})".format(
    lat1, lon1, lat2, lon2, steps, speed, CELL_STEP
  ))
  return steps

'''
# using lat, lon find if agent is inside/near a facility
def is_agent_in_fac(log, agent_shared):
  a_self = agent_shared.view.self
  agent_name = a_self.name
  agent_fac_id = None
  agent_lat = float(a_self.lat)
  agent_lon = float(a_self.lon)
  for fac in agent_shared.view.facilities.values():
    fac_lat = float(fac.lat)
    fac_lon = float(fac.lon)
    if abs(agent_lat - fac_lat) <= PROXIMITY and abs(agent_lon - fac_lon) <= PROXIMITY:
      agent_fac_id = fac.name
      break
  log.debug("is_agent_in_fac {:s} => facility = {}".format(agent_name, agent_fac_id))
  return agent_fac_id
'''

# distance agent or src_fac to dst_fac
# use dist_cache, only from fac to fac
# return steps, cache?
def steps_estimate(log, agent_shared, dst_fac, src_fac=None):
  a_self = agent_shared.view.self
  agent_name = a_self.name
  #agent_fac_id = is_agent_in_fac(log, agent_shared)
  agent_fac_id = a_self.inFacility
  agent_role = agent_shared.sim.role.name
  dst_fac_id = dst_fac.name
  if src_fac is None:
    log.debug("steps_estimate {:s}, inFacility = {:s} -> {:s}".format(agent_name, agent_fac_id, dst_fac_id))
  else:
    log.debug("steps_estimate {:s}, {:s} -> {:s}".format(agent_name, src_fac.name, dst_fac_id))
  src_key = None
  if src_fac is None:
    if agent_fac_id != "none":
      src_key = agent_fac_id
  else:
    src_key = src_fac.name
  # use cache
  #if agent_fac_id is not None:
  if src_key is not None:
    cache = team.dist_cache
    # try correct way first
    cache_key = team.mk_cache_key(src_key, dst_fac_id, agent_role)
    if cache_key in cache:
      cache_value = cache[cache_key]
      log.debug("steps_estimate, read cache (direct) {:s} = {:d}".format(cache_key, cache_value))
      return cache_value, actions.STEPS_CACHE
    # try and get estimate from reverse way
    cache_key = team.mk_cache_key(dst_fac_id, src_key, agent_role)
    if cache_key in cache:
      # use a safety factor
      cache_value = int(math.ceil(cache[cache_key] * util.JOB_STEPS_FAC))
      log.debug("steps_estimate, read cache (reverse) {:s} = {:d}".format(cache_key, cache_value))
      return cache_value, actions.STEPS_CACHE_R
  steps = steps_direct(log, agent_shared, dst_fac, src_fac)
  if agent_role != "Drone":
    steps = int(math.ceil(steps * util.DIST_ROUTE_FAC))
  log.debug("steps_estimate = {:d}".format(steps))
  return steps, actions.STEPS_NOCACHE

# nearest charging station to fac, to use on leaving from fac
# give preference in the direction to center of map !
# returns tuple (steps, charge_fac)
def fac_charging_station(log, agent_shared, fac):
  # first try, to center of map
  # TODO ... what if map dynamic and boundaries not known before ???
  MAP_CENTER_LAT = util.MAP_CENTER_LAT
  MAP_CENTER_LON = util.MAP_CENTER_LON
  fac_lat = float(fac.lat)
  fac_lon = float(fac.lon)
  min_lat = min(MAP_CENTER_LAT, fac_lat)
  max_lat = max(MAP_CENTER_LAT, fac_lat)
  min_lon = min(MAP_CENTER_LON, fac_lon)
  max_lon = max(MAP_CENTER_LON, fac_lon)
  log.debug("fac_charging_station for {:s} {:.4f}, {:.4f} (map center = {:.4f}, {:.4f}), bound = {:.4f} - {:.4f}, {:.4f}, {:.4f}".format(fac.name, fac_lat, fac_lon, MAP_CENTER_LAT, MAP_CENTER_LON, min_lat, max_lat, min_lon, max_lon))
  Duo = util.Duo
  p = []
  for charge_fac in util.facilities(agent_shared, "chargingStation"):
    charge_fac_lat = float(charge_fac.lat)
    charge_fac_lon = float(charge_fac.lon)
    if min_lat <= charge_fac_lat <= max_lat and min_lon <= charge_fac_lon <= max_lon:
      steps = steps_estimate(log, agent_shared, charge_fac, fac)
      charge_fac_id = charge_fac.name
      p.append(Duo(steps, charge_fac_id))
      log.debug("... {:s} ({:.4f}, {:.4f}), steps = {}".format(charge_fac_id, charge_fac_lat, charge_fac_lon, steps))
  if p:
    best = sorted(p)[0]
    log.debug("=== fac_charging_station for {:s} = {:s} (centered), steps = {}".format(fac.name, best.key, best.value))
    return best
  # second try, absolutely nearest
  for charge_fac in util.facilities(agent_shared, "chargingStation"):
    steps = steps_estimate(log, agent_shared, charge_fac, fac)
    charge_fac_id = charge_fac.name
    p.append(Duo(steps, charge_fac_id))
  best = sorted(p)[0]
  log.debug(">>> fac_charging_station for {:s} = {:s} (nearest), steps = {}".format(fac.name, best.key, best.value))
  return best

# optimal charging station on the way to dst_fac (from src_fac or from agent current location)
# returns tuple Hexa(steps_order, steps_charge_to_fac, steps_own_to_charge, steps_charging_time, steps(total), charge_fac_id)
# steps_order = steps(total)
# if considered impossible to reach destination, then
#   steps_charging_time = time to fully recharge a totally empty batteryCapacity
#   steps_order = MAX_STEPS, but order by steps_charge_to_fac too
# generally order by minimal steps_charge_to_fac so enough power for next charging station
def best_charging_station(log, agent_shared, dst_fac, src_fac=None):
  x = agent_shared.view
  a_self = x.self
  agent_name = a_self.name
  inFacility = a_self.inFacility
  charge = int(a_self.charge)
  batteryCapacity = int(a_self.batteryCapacity)
  log.debug("best_charging_station {:s} -> {:s} (charge = {:d}, capacity = {:d})".format(
    src_fac.name if src_fac is not None else agent_name+":"+inFacility, dst_fac.name, charge, batteryCapacity
  ))
  #
  MAX_STEPS = util.MAX_STEPS
  CHARGE_STEP = util.CHARGE_STEP
  JOB_STEPS_FAC = util.JOB_STEPS_FAC
  #
  best = fac_charging_station(log, agent_shared, dst_fac)
  steps_fac_to_next_charge = best.value
  expense_fac_to_next_charge = steps_fac_to_next_charge[0] * CHARGE_STEP
  #
  charge_stations = util.facilities(agent_shared, "chargingStation")
  if src_fac is None:
    own_fac_data = x.facilities.get(inFacility, None)
    if own_fac_data and own_fac_data.facility_type == "chargingStation":
      charge_stations = [own_fac_data]
      log.info("   *** best_charging_station {:s} -> {:s}, SMART already inside charging station !!!".format(
        src_fac.name if src_fac is not None else agent_name+":"+inFacility, dst_fac.name
      ))
  Hexa = util.Hexa
  p = []
  for charge_fac in charge_stations:
    steps_own_to_charge = steps_estimate(log, agent_shared, charge_fac, src_fac)
    steps_charge_to_fac = steps_estimate(log, agent_shared, dst_fac, charge_fac)
    expense_own_to_charge = steps_own_to_charge[0] * CHARGE_STEP
    expense_charge_to_fac = steps_charge_to_fac[0] * CHARGE_STEP
    ### comment below and allow all charging stations, so at least one selected and if stall we call service !!!
    ### just ensure no negative steps ever, and special handling of negative cases so best order is maintained
    ###if charge > charge_own_to_fac:
    charging_rate = int(charge_fac.rate)
    steps_charging_time = int(math.ceil((batteryCapacity - max(charge - expense_own_to_charge, 0))/charging_rate))
    steps = steps_own_to_charge[0] + steps_charge_to_fac[0] + steps_charging_time
    steps_order = steps
    # in case of negative cases, all sort same initially but priority to charging station nearest to destination
    # top order class currently
    if charge < expense_own_to_charge:
      steps_order = MAX_STEPS + 1
    # bottom order class, not so accurate estimate
    if int(math.ceil((expense_charge_to_fac + expense_fac_to_next_charge) * JOB_STEPS_FAC)) > batteryCapacity:
      steps_order = MAX_STEPS
    charge_fac_id = charge_fac.name
    p.append(Hexa(steps_order, steps_charge_to_fac, steps_own_to_charge, steps_charging_time, steps, charge_fac_id))
    log.debug("   ... {:s}, ({:d}) steps = {:d} (to_charge = {}, to_fac = {}, charging = {:d})".format(
      charge_fac_id, steps_order, steps, steps_own_to_charge, steps_charge_to_fac, steps_charging_time
    ))
  best = sorted(p)[0]
  log.debug("   best_charging_station, min = {:s}, steps = {:d}".format(best.key, best.value_all))
  return best

# best charge strategy for faster response chosen to be
#   check for charge to arrive + next charge station (but a centered to map first, then nearest one charge station)
#   instead of always charge in between (optimal) + arrive
#
# create sequence of op_goto(s) to target with optional detour to charging station, append to action_seq
# returns estimated steps to reach including charge time, can be MAX_STEPS indicating unreachability
def creat(log, agent_shared, fac_id, action_seq=None, src_id=None, job_id=""):
  if action_seq is not None and src_id is not None:
    log.error("creat called with both action_seq= and src_id=, assuming src_id=None")
    src_id = None
  creat_type_s = "(action)" if action_seq is not None else "(steps)"
  #
  x = agent_shared.view
  a_self = x.self
  agent_name = a_self.name
  inFacility = a_self.inFacility
  charge = int(a_self.charge)
  #
  fac_data = x.facilities[fac_id]
  if src_id is not None:
    src_fac = x.facilities[src_id]
  else:
    src_id = inFacility
    src_fac = None
  #
  best = fac_charging_station(log, agent_shared, fac_data)
  steps_fac_to_charge = best.value
  steps_own_to_fac = steps_estimate(log, agent_shared, fac_data, src_fac)
  charge_budget = int(math.ceil((steps_own_to_fac[0] + steps_fac_to_charge[0]) * util.JOB_STEPS_FAC)) * util.CHARGE_STEP
  #
  if charge_budget <= charge:
    log.debug("creat 1/1 {:s}, {:s} -> {:s} (direct), steps = {} (charge = {:d}, budget = {:d}) {:s}".format(
      creat_type_s, agent_name, fac_id, steps_own_to_fac, charge, charge_budget, job_id
    ))
    if action_seq is not None:
      action_seq.append(
        # **args: _fac_id, _cache_p, _src_id, _job_id (can be "")
        actions.op_goto(agent_name, steps_own_to_fac[0], _fac_id=fac_id, _cache_p=steps_own_to_fac[1], _src_id=src_id, _job_id=job_id)
      )
    return steps_own_to_fac[0]
  else:
    best = best_charging_station(log, agent_shared, fac_data, src_fac)
    # Hexa(steps_order, steps_charge_to_fac, steps_own_to_charge, steps_charging_time, steps(total), charge_fac_id)
    # Hexa = 'value_sort value0 value1 value2 value_all key'
    steps = best.value_all
    steps_charge_to_fac = best.value0
    steps_own_to_charge = best.value1
    steps_charging_time = best.value2
    charge_fac_id = best.key
    charge_fac = x.facilities[charge_fac_id]
    ###
    if steps_own_to_charge[0] > 0:
      log.debug("creat 1/3 {:s}, {:s} -> {:s} (charge), steps = {} {:s}".format(
        creat_type_s, agent_name, charge_fac_id, steps_own_to_charge, job_id
      ))
      if action_seq is not None:
        action_seq.append(
          # **args: _fac_id, _cache_p, _src_id, _job_id (can be "")
          actions.op_goto(agent_name, steps_own_to_charge[0], _fac_id=charge_fac_id, _cache_p=steps_own_to_charge[1], _src_id=src_id, _job_id=job_id)
        )
    ###
    log.debug("creat 2/3 {:s}, {:s} charging, steps = {:d} {:s}".format(creat_type_s, agent_name, steps_charging_time, job_id))
    if action_seq is not None:
      # **args: _fac_id, _job_id (can be "")
      action_seq.append(actions.op_charge(agent_name, steps_charging_time, _fac_id=charge_fac_id, _job_id=job_id))
    ###
    log.debug("creat 3/3 {:s}, {:s} -> {:s} (direct), steps = {}   {:s}".format(
      creat_type_s, agent_name, fac_id, steps_charge_to_fac, job_id
    ))
    if action_seq is not None:
      action_seq.append(
        # **args: _fac_id, _cache_p, _src_id, _job_id (can be "")
        actions.op_goto(agent_name, steps_charge_to_fac[0], _fac_id=fac_id, _cache_p=steps_charge_to_fac[1], _src_id=charge_fac_id, _job_id=job_id)
      )
    ###
    log.debug("creat {:s} total steps = {:d}".format(creat_type_s, steps))
    return steps