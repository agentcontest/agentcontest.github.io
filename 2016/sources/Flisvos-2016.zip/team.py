
"""

 /*
  * @(#) E.Sarmas   team.py 1.29e (2016-09-12)
  *
  * Author: E.Sarmas
  *
  * Created: 2016-08-08
  *
  * Description: Flisvos 2016 (MAPC 2016)
  *
  * Version: 1.29e
  * Version-Date: 2016-09-12
  *
  */

"""

import collections
import util
import team
import main

###
###   jobs_db, begin
###

#   jobs = dict with key = job_id, value = begin, end, id, reward, storage, job_items => { name: name, amount, delivered, pieces => { id: agent_name, amount, state = ON_BOARD/BUY/DELIVERED } }

#
# *** TODO  next time use sqlite3 database !!!
#
class jobs_db():
  
  def __init__(self):
    self._jobs_db = {}
  
  # necessary for failures in job ops
  def cleanup(self, agent):
    shared = agent._shared
    log = agent._log
    
    jobs_db = self._jobs_db
    jobs_view = agent.view.jobs
    for job_id, job_data in list(jobs_db.items()):
      if job_id not in jobs_view:
        log.info("DB CLEANUP: job_id {:s} expired".format(job_id))
        del jobs_db[job_id]
        for agent_name, agent_shared in shared.items():
          job_op = agent_shared.job_op
          if job_op is not None:
            drop_p = False
            for op_action in job_op:
              _job_id = getattr(op_action, "_job_id", None)
              if _job_id and _job_id == job_id:
                drop_p = True
                break
            if drop_p:
              agent_shared.job_op = None
              log.info("DB CLEANUP: job_id {:s} expired, deleted job_op for {:s}".format(job_id, agent_name))
        continue
      job_items_dict = job_data.job_items
      for job_item_name, job_item_data in job_items_dict.items():
        pieces_dict = job_item_data.pieces
        for x_piece_id, x_piece_data in list(pieces_dict.items()):
          if x_piece_data.state != "DELIVERED" and shared[x_piece_data.agent_name].job_op is None:
            log.info("DB CLEANUP: job_id {:s}, stale piece {:d} => agent_name = {:s}, name = {:s}, amount = {:d}, state = {:s}".format(
              job_id, x_piece_id, x_piece_data.agent_name, job_item_name, x_piece_data.amount, x_piece_data.state
            ))
            del pieces_dict[x_piece_id]
  
  #   jobs = dict with key = job_id, value = begin, end, id, reward, storage, job_items => { name: name, amount, delivered, pieces => { id: agent_name, amount, state = ON_BOARD/BUY/DELIVERED } }
  # TODO ... cross-check pieces with items on_board ?!
  def check(self, agent):
    log = agent._log
    
    jobs_db = self._jobs_db
    jobs_view = agent.view.jobs
    for job_id, job_data in jobs_db.items():
      # get percept job_entry
      job_entry = jobs_view[job_id]
      # check db entry
      job_items_dict = job_data.job_items
      for job_item_name, job_item_data in job_items_dict.items():
        total = 0
        delivered = 0
        pieces_dict = job_item_data.pieces
        for x_piece_id, x_piece_data in pieces_dict.items():
          x_amount = x_piece_data.amount
          total += x_amount
          if x_piece_data.state == "DELIVERED":
            delivered += x_amount
        job_item_amount = int(job_item_data.amount)
        job_item_delivered = int(job_item_data.delivered)
        entry_item = job_entry.job_items[job_item_name]
        entry_item_amount = int(entry_item.amount)
        if job_item_amount != entry_item_amount:
          log.error("DB CHECK: job_id {:s}, item {:s}: db amount {:d} != job amount {:d}".format(
            job_id, job_item_name, job_item_amount, entry_item_amount
          ))
          #return
        if job_item_amount < total:
          log.error("DB CHECK: job_id {:s}, item {:s}: db amount {:d} < pieces total {:d}".format(
            job_id, job_item_name, job_item_amount, total
          ))
          #return
        if job_item_delivered != delivered:
          log.error("DB CHECK: job_id {:s}, item {:s}: db delivered {:d} != pieces delivered {:d}".format(
            job_id, job_item_name, job_item_delivered, delivered
          ))
          #return
        #if "delivered" in entry_item:
        #  e_delivered = int(entry_item.delivered)
        #else:
        #  e_delivered = 0
        #if job_item_delivered != e_delivered:
        #  log.error("CHECK: job_id {:s}, item {:s}: db delivered {:d} != job delivered {:d}".format(job_id, job_item_name, job_item_delivered, e_delivered))
        #  return
  
  #   jobs = dict with key = job_id, value = begin, end, id, reward, storage, job_items => { name: name, amount, delivered, pieces => { id: agent_name, amount, state = ON_BOARD/BUY/DELIVERED } }
  def print(self, agent):
    log = agent._log
    
    jobs_db = self._jobs_db
    log.info("=== jobs_db ====")
    for job_id, job_data in jobs_db.items():
      items_needed_count, items_needed_amount = self.job_stats(agent, job_id, logging=False)
      log.info("id: {:s}, end = {:s}, reward = {:s}, storage = {:s}; needed_count = {:d}, needed_amount = {:d}".format(
        job_id, job_data.end, job_data.reward, job_data.storage, items_needed_count, items_needed_amount
      ))
      job_items_dict = job_data.job_items
      for job_item_name, job_item_data in job_items_dict.items():
        total, needed = self.item_stats(agent, job_id, job_item_name, logging=False)
        log.info("   item: name = {:s}, amount = {:s}, delivered = {:d}; total = {:d}, needed = {:d}".format(
          job_item_data.name, job_item_data.amount, job_item_data.delivered, total, needed
        ))
        pieces_dict = job_item_data.pieces
        for x_piece_id, x_piece_data in pieces_dict.items():
          log.info("      piece id: {:d} => agent = {:s}, amount = {:d}, state = {:s}".format(
            x_piece_id, x_piece_data.agent_name, x_piece_data.amount, x_piece_data.state
          ))
  
  #   jobs = dict with key = job_id, value = begin, end, id, reward, storage, job_items => { name: name, amount, delivered, pieces => { id: agent_name, amount, state = ON_BOARD/BUY/DELIVERED } }
  # print summary of system jobs and their assembly status
  @staticmethod
  def summary(jobs, agent):
    log = agent._log
    prod_db = agent.sim.products
    
    MAX_INT = util.MAX_INT
    facilities = util.facilities
    log.info("=== jobs summary ====")
    for job_data in util.jobs(agent, "pricedJob"):
      job_items_dict = job_data.job_items
      mole = 0
      atom = 0
      shop = 0
      total = 0
      min_shop = MAX_INT
      for job_item_name, job_item_data in job_items_dict.items():
        if job_item_name in prod_db:
          prod_data = prod_db[job_item_name]
          if prod_data.assembled == "true":
            mole += 1
          else:
            atom += 1
        num_shop = 0
        for fac_data in facilities(agent, facility_type = "shop"):
          if job_item_name in fac_data.extra:
            if num_shop == 0:
              shop += 1
            num_shop += 1
        total += 1
        if num_shop < min_shop:
          min_shop = num_shop
      log.info("id: {:s}, end = {:s}, reward = {:s}, storage = {:s}; mole = {:}, atom = {:d}, shop = {:d} of {:d}, min_shop = {:d}".format(job_data.id, job_data.end, job_data.reward, job_data.storage, mole, atom, shop, total, min_shop))
  
  #   jobs = dict with key = job_id, value = begin, end, id, reward, storage, job_items => { name: name, amount, delivered, pieces => { id: agent_name, amount, state = ON_BOARD/BUY/DELIVERED } }
  def agent_delivered(self, agent, job_id):
    log = agent._log
    
    x = agent.view
    agent_name = x.self.name
    jobs_db = self._jobs_db
    if job_id not in jobs_db:
      log.info("DB: job id: {:s}, deliver_job by {:s}   CHECK: job has been removed !!!".format(job_id, agent_name))
      return
    log.info("DB: job id: {:s}, deliver_job by {:s}".format(job_id, agent_name))
    job_items_dict = jobs_db[job_id].job_items
    for job_item_name, job_item_data in job_items_dict.items():
      x_delivered = 0
      pieces_dict = job_item_data.pieces
      for x_piece_id, x_piece_data in pieces_dict.items():
        if x_piece_data.agent_name == agent_name and x_piece_data.state != "DELIVERED":
          x_piece_amount = x_piece_data.amount
          log.info("DB: job id: {:s}, {:s} delivered => {:s}, {:d}, {:s} => {:s} !".format(
            job_id, agent_name, job_item_name, x_piece_amount, x_piece_data.state, "DELIVERED"
          ))
          x_delivered += x_piece_amount
          x_piece_data.state = "DELIVERED"
      job_item_data.delivered += x_delivered
  
  # assert before deliver_job, check if in self_items
  def agent_deliver_assert(self, agent, job_id):
    log = agent._log
    
    x = agent.view
    agent_name = x.self.name
    jobs_db = self._jobs_db
    if job_id not in jobs_db:
      log.info("DB: job id: {:s}, deliver_assert for {:s}   CHECK: job has been removed !!!".format(job_id, agent_name))
      return
    #log.info("DB: job id: {:s}, deliver_assert for {:s}".format(job_id, agent_name))
    self_items = x.self_items
    job_items_dict = jobs_db[job_id].job_items
    # db to view
    for job_item_name, job_item_data in job_items_dict.items():
      pieces_dict = job_item_data.pieces
      for x_piece_id, x_piece_data in pieces_dict.items():
        if x_piece_data.agent_name == agent_name and x_piece_data.state != "DELIVERED":
          x_piece_amount = x_piece_data.amount
          if job_item_name in self_items:
            x_self_amount = int(self_items[job_item_name].amount)
            if x_self_amount < x_piece_amount:
              log.error("DB: job id: {:s}, deliver_assert {:s} has {:d} _less_ of {:s}, {:d} !!!".format(
                job_id, agent_name, x_self_amount, job_item_name, x_piece_amount
              ))
          else:
            log.error("DB: job id: {:s}, deliver_assert {:s} has not {:s}, {:d} !!!".format(
              job_id, agent_name, job_item_name, x_piece_amount
            ))
  
  # check after deliver_job, compare with self_items delivered
  def agent_deliver_check(self, agent, job_id, last_items):
    log = agent._log
    
    x = agent.view
    agent_name = x.self.name
    jobs_db = self._jobs_db
    if job_id not in jobs_db:
      log.info("DB: job id: {:s}, deliver_check for {:s}   CHECK: job has been removed !!!".format(job_id, agent_name))
      return
    #log.info("DB: job id: {:s}, deliver_check for {:s}".format(job_id, agent_name))
    self_items = x.self_items
    delivered_items = {}
    for last_item_data in last_items:
      last_name = last_item_data.name
      last_amount = int(last_item_data.amount)
      if last_name not in self_items:
        delivered_items[last_name] = last_amount
      else:
        self_amount = int(self_items[last_name].amount)
        if last_amount > self_amount:
          delivered_items[last_name] = (last_amount - self_amount)
    job_items_dict = jobs_db[job_id].job_items
    # db to view
    for job_item_name, job_item_data in job_items_dict.items():
      pieces_dict = job_item_data.pieces
      for x_piece_id, x_piece_data in pieces_dict.items():
        if x_piece_data.agent_name == agent_name and x_piece_data.state != "DELIVERED":
          x_piece_amount = x_piece_data.amount
          # normally (!) only a single piece per item
          if job_item_name in delivered_items:
            xd_amount = delivered_items[job_item_name]
            if x_piece_amount != xd_amount:
              log.error("DB: job id: {:s}, deliver_check {:s} delivered {:s}, {:d} != {:d} (db) !!!".format(
                job_id, agent_name, job_item_name, xd_amount, x_piece_amount
              ))
            del delivered_items[job_item_name]
          else:
            log.error("DB: job id: {:s}, deliver_check {:s} did not deliver {:s}, {:d} !!!".format(
              job_id, agent_name, job_item_name, x_piece_amount
            ))
    if delivered_items:
      log.error("DB: job id: {:s}, deliver_check {:s} delivered{} (not in db) !!!".format(
        job_id, agent_name, ";".join(" "+name+","+str(amount) for name, amount in delivered_items.items())
      ))
  
  def job_is_complete(self, agent, job_id):
    log = agent._log
    
    jobs_db = self._jobs_db
    if job_id not in jobs_db:
      log.info("DB: job id: {:s}, job_is_complete   CHECK: job has been removed !!!".format(job_id))
      return
    job_items_dict = jobs_db[job_id].job_items
    complete = True
    for job_item_name, job_item_data in job_items_dict.items():
      if job_item_data.delivered != int(job_item_data.amount):
        complete = False
        break
    if complete:
      log.info("DB: job id: {:s}, completed YAIII !!!".format(job_id))
    return complete
  
  #   jobs = dict with key = job_id, value = begin, end, id, reward, storage, job_items => { name: name, amount, delivered, pieces => { id: agent_name, amount, state = ON_BOARD/BUY/DELIVERED } }
  def piece_state(self, agent, job_id, item_name, piece_id, new_state):
    log = agent._log
    
    log.info("DB: job id: {:s}, state piece id: {:d}, item_name = {:s} (=> {:s})".format(job_id, piece_id, item_name, new_state))
    jobs_db = self._jobs_db
    job_items_dict = jobs_db[job_id].job_items
    job_item_data = job_items_dict[item_name]
    pieces_dict = job_item_data.pieces
    x_piece_data = pieces_dict[piece_id]
    log.info("state changed, {:s} => {:s} !".format(x_piece_data.state, new_state))
    x_piece_data.state = new_state
    return
  
  #   jobs = dict with key = job_id, value = begin, end, id, reward, storage, job_items => { name: name, amount, delivered, pieces => { id: agent_name, amount, state = ON_BOARD/BUY/DELIVERED } }
  def piece_del(self, agent, job_id, item_name, piece_id):
    log = agent._log
    
    log.info("DB: job id: {:s}, del piece id: {:d}, item_name = {:s}".format(job_id, piece_id, item_name))
    jobs_db = self._jobs_db
    job_items_dict = jobs_db[job_id].job_items
    job_item_data = job_items_dict[item_name]
    pieces_dict = job_item_data.pieces
    del pieces_dict[piece_id]
    log.info("piece deleted !")
    return
  
  #   jobs = dict with key = job_id, value = begin, end, id, reward, storage, job_items => { name: name, amount, delivered, pieces => { id: agent_name, amount, state = ON_BOARD/BUY/DELIVERED } }
  def piece_add(self, agent, job_id, agent_name, item_name, amount, state):
    log = agent._log
    
    log.info("job id: {:s}, add piece, item_name = {:s} => agent_name = {:s}, amount = {:d}, state = {:s}".format(
      job_id, item_name, agent_name, amount, state
    ))
    jobs_db = self._jobs_db
    job_items_dict = jobs_db[job_id].job_items
    job_item_data = job_items_dict[item_name]
    pieces_dict = job_item_data.pieces
    new_piece = util.attr_dict()
    new_piece.agent_name = agent_name
    new_piece.amount = amount
    new_piece.state = state
    team.piece_id += 1
    pieces_dict[piece_id] = new_piece
    log.info("piece added, piece id: {:d} !".format(piece_id))
    return piece_id
  
  #   jobs = dict with key = job_id, value = begin, end, id, reward, storage, job_items => { name: name, amount, delivered, pieces => { id: agent_name, amount, state = ON_BOARD/BUY/DELIVERED } }
  def job_stats(self, agent, job_id, logging=True):
    log = agent._log
    
    jobs_db = self._jobs_db
    job_items_dict = jobs_db[job_id].job_items
    items_needed_count = 0
    items_needed_amount = 0
    for job_item_name, job_item_data in job_items_dict.items():
      total = 0
      pieces_dict = job_item_data.pieces
      for x_piece_id, x_piece_data in pieces_dict.items():
        x_amount = x_piece_data.amount
        total += x_amount
      x_needed = int(job_item_data.amount) - total
      if x_needed > 0:
        items_needed_count += 1
        items_needed_amount += x_needed
    if logging:
      log.debug("DB: job id: {:s}, stats => items_needed_count = {:d}, items_needed_amount = {:d}".format(
        job_id, items_needed_count, items_needed_amount
      ))
    return items_needed_count, items_needed_amount
  
  #   jobs = dict with key = job_id, value = begin, end, id, reward, storage, job_items => { name: name, amount, delivered, pieces => { id: agent_name, amount, state = ON_BOARD/BUY/DELIVERED } }
  def item_stats(self, agent, job_id, item_name, logging=True):
    log = agent._log
    
    jobs_db = self._jobs_db
    job_items_dict = jobs_db[job_id].job_items
    total = 0
    job_items_dict = jobs_db[job_id].job_items
    job_item_data = job_items_dict[item_name]
    pieces_dict = job_item_data.pieces
    for x_piece_id, x_piece_data in pieces_dict.items():
      total += x_piece_data.amount
    needed = int(job_item_data.amount) - total
    if logging:
      log.debug("DB: job id: {:s}, item_name = {:s}, stats => total = {:d}, needed = {:d}".format(job_id, item_name, total, needed))
    return total, needed
  
  #   jobs = dict with key = job_id, value = begin, end, id, reward, storage, job_items => { name: name, amount, delivered, pieces => { id: agent_name, amount, state = ON_BOARD/BUY/DELIVERED } }
  def job_add(self, agent, job_id):
    log = agent._log
    
    log.info("DB: job id: {:s}, add".format(job_id))
    jobs_db = self._jobs_db
    jobs_view = agent.view.jobs
    if job_id in jobs_db:
      return
    # get percept job_entry
    job_entry = jobs_view[job_id]
    # new copy
    attr_dict = util.attr_dict
    new_job = util.attr_dict()
    new_job.begin = job_entry.begin
    new_job.end = job_entry.end
    new_job.id = job_entry.id
    new_job.reward = job_entry.reward
    new_job.storage = job_entry.storage
    jobs_db[job_id] = new_job
    new_job_items_dict = attr_dict()
    for item_name, entry_item in job_entry.job_items.items():
      new_job_item = attr_dict()
      new_job_item.name = entry_item.name
      new_job_item.amount = entry_item.amount
      #if "delivered" in entry_item:
      #  e_delivered = entry_item.delivered
      #else:
      #  e_delivered = 0
      #new_job_item.delivered = e_delivered
      new_job_item.delivered = 0
      new_job_item.pieces = attr_dict() 
      new_job_items_dict[item_name] = new_job_item
    new_job.job_items = new_job_items_dict
  
  #   jobs = dict with key = job_id, value = begin, end, id, reward, storage, job_items => { name: name, amount, delivered, pieces => { id: agent_name, amount, state = ON_BOARD/BUY/DELIVERED } }
  def job_del(self, agent, job_id):
    log = agent._log
    
    jobs_db = self._jobs_db
    if job_id not in jobs_db:
      log.info("DB: job id: {:s}, del   CHECK: job has been removed !!!".format(job_id))
      return
    log.info("DB: job id: {:s}, del".format(job_id))
    del jobs_db[job_id]

###
###   jobs_db, end
###

def mk_cache_key(fac_name1, fac_name2, role_name):
  return "-".join([fac_name1, fac_name2]) + "-" + role_name

def print_shop_inventory(agent):
  log = agent._log
  log.info("=== shop inventory ===")
  for name in sorted(shop_inventory.keys(), key=util.natural_sort_key):
    shop_data = shop_inventory[name]
    log.info("{:s} ({:d} by {:s}) =>{}".format(
      name, shop_data.data_step, shop_data.data_agent,
      ";".join(" "+item_data.name+","+str(item_data.amount)+"@"+str(item_data.cost) for item_data in shop_data.data.values())
    ))

def print_fac_agents(agent):
  log = agent._log
  log.info("=== fac agents ===")
  for fac_id in sorted(fac_agents.keys(), key=util.natural_sort_key):
    log.info("{:s} (on spot) => {}".format(fac_id, fac_agents[fac_id]))

def fac_agents_update(agent):
  log = agent._log
  shared = agent._shared
  
  fac_agents = collections.defaultdict(set)
  for agent_name, agent_data in shared.items():
    inFacility = agent_data.view.self.inFacility
    if inFacility != "none":
      fac_agents[inFacility].add(agent_name)
  team.fac_agents = fac_agents

def print_fac_goto(agent):
  log = agent._log
  log.info("=== fac goto ===")
  for fac_id in sorted(fac_goto.keys(), key=util.natural_sort_key):
    log.info("{:s} (goto) => {}".format(fac_id, fac_goto[fac_id]))

def print_goto_stats(agent):
  log = agent._log
  log.info("=== goto stats ===")
  for status, status_value in sorted(goto_stats.items()):
    log.info("{:s} = {:d}".format(status, status_value))
  log.info("max cache fac (MORE) ={}".format(
    ";".join(" "+cache_p+"="+"{:.2f}".format(fac) for cache_p, fac in max_goto_fac.items())
  ))

def print_money_stats(agent):
  log = agent._log
  log.info("=== money stats ===")
  log.info("rewards = {:d}, cost = {:d} (jobs b/c/s = {:d}/{:d}/{:d}, explore c/s = {:d}/{:d})".format(
    rewards, alljobs_cost + explore_cost,
    alljobs_buy_cost, alljobs_charge_cost, alljobs_service_cost,
    explore_charge_cost, explore_service_cost
  ))
  log.info("balance = {:d}, money = {:d} (seed = {:d})".format(balance, money, seed))
  if money != agent._money:
    log.error("ASSERT ERROR, team money {:d} != {:d} system money".format(money, agent._money))
  log.info("explores = {:d}, per_step = {:.1f}".format(
    explore_count, explore_count/(int(agent.view.simulation.step)+1)
  ))

def print_job_money_stats(agent, job_id):
  log = agent._log
  jobs_db = jobs._jobs_db
  if job_id not in jobs_db:
    return
  log.info("=== job money stats ===")
  reward = int(jobs_db[job_id].reward)
  buy_cost = job_buy_cost[job_id]
  charge_cost = job_charge_cost[job_id]
  service_cost = job_service_cost[job_id]
  total_cost =  buy_cost + charge_cost + service_cost
  balance = reward - total_cost
  log.info("balance = {:d}, reward = {:d}, cost = {:d} (buy/charge/service = {:d}/{:d}/{:d})".format(
    balance, reward, total_cost, buy_cost, charge_cost, service_cost
  ))

# TODO ... summary of current state of jobs_db, including their pass criteria fac(s) (steps, reward) !!!
def job_QoS_state(agent):
  for job_id, job_data in agent.view.jobs.items():
    if job_data.job_type == "pricedJob":
      system_jobs.add(job_id)
  for job_id in util.jobs_selection(agent):
    selection_jobs.add(job_id)
  for job_id in jobs._jobs_db:
    committed_jobs.add(job_id)
  # completed jobs updated by op_deliver_job_action
  log = agent._log
  log.info("jobs QoS: system = {:d} => selection = {:d} {:d}% => committed = {:d} {:d}% => completed = {:d} {:d}%".format(
    len(system_jobs), len(selection_jobs), round(100*len(selection_jobs)/max(len(system_jobs), 1)),
    len(committed_jobs), round(100*len(committed_jobs)/max(len(selection_jobs), 1)),
    len(completed_jobs), round(100*len(completed_jobs)/max(len(committed_jobs), 1))
  ))

def update_money(agent):
  team.alljobs_cost = alljobs_buy_cost + alljobs_charge_cost + alljobs_service_cost
  team.explore_cost = explore_charge_cost + explore_service_cost
  team.balance = rewards - alljobs_cost - explore_cost
  team.money = seed + balance

def team_initialize(agent):
  log = agent._log
  log.info("team initialize")
  # last piece_id assigned
  team.piece_id = 0
  team.jobs = jobs_db()
  team.dist_cache = {}
  team.goto_stats = collections.defaultdict(int)
  team.max_goto_fac = collections.defaultdict(float)
  # shop_inventory = dict with key = name, value = data_step: step, data_agent: agent_name, data = [ name, ?info#cost, ?info#amount, ?info#restock ]
  team.shop_inventory = {}
  team.service_job = {}
  team.CC_op_last_step = 0
  team.job_spec_top_min_cost = 0
  team.job_spec_top_min_cost_job_id = ""
  team.job_spec_top_min_cost_job_data = None
  team.job_spec_min_buy_cost = collections.defaultdict(int)
  team.job_spec_max_buy_cost = collections.defaultdict(int)
  team.job_spec_est_buy_cost = collections.defaultdict(int)
  team.job_spec_checked = set()
  team.job_spec_ignored = set()
  team.job_buy_cost = collections.defaultdict(int)
  team.job_charge_cost = collections.defaultdict(int)
  team.job_service_cost = collections.defaultdict(int)
  team.alljobs_buy_cost = 0 # total
  team.alljobs_charge_cost = 0 # total
  team.alljobs_service_cost = 0 # total
  team.alljobs_cost = 0
  team.explore_charge_cost = 0
  team.explore_service_cost = 0
  team.explore_cost = 0
  team.balance = 0 # can be negative
  team.rewards = 0
  seedCapital = int(agent.sim.simulation.seedCapital)
  team.seed = seedCapital if seedCapital > 0 else util.SEED
  team.money = seed
  team.explore_count = 0
  team.system_jobs = set()
  team.selection_jobs = set()
  team.committed_jobs = set()
  team.completed_jobs = set()
  team.first_loop = True
  team.step = util.MAX_STEPS
  team.fac_agents = {}
  team.fac_goto = collections.defaultdict(set)
  team.action_stats = collections.defaultdict(int)
  team.sim_id = agent.sim.simulation.id
  team.map_name = agent.sim.simulation.map
