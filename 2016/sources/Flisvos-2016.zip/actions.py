
"""

 /*
  * @(#) E.Sarmas   actions.py 1.29e (2016-09-12)
  *
  * Author: E.Sarmas
  *
  * Created: 2016-08-16
  *
  * Description: Flisvos 2016 (MAPC 2016)
  *
  * Version: 1.29e
  * Version-Date: 2016-09-12
  *
  */

"""

import util
import team

class Action_Seq():
  def __init__(self):
    self._action_list = []
    self._action_index = -1
    self._action_count = 0
    self._iter_index = -1
  
  def __len__(self):
    return self._action_count
  
  def __iter__(self):
    self._iter_index = -1
    return self
  
  def __next__(self):
    self._iter_index += 1
    if self._iter_index < self._action_count:
      return self._action_list[self._iter_index]
    else:
      raise StopIteration
  
  def __repr__(self):
    #[str(x) for x in self._action_list]
    return str(self._action_list)
  
  def append(self, action):
    self._action_list.append(action)
    self._action_count += 1
  
  def action(self):
    if self._action_count == 0 or self._action_index == self._action_count:
      return None
    if self._action_index == -1:
      self._action_index = 0
    return self._action_list[self._action_index]
  
  def next_action(self):
    self._action_index += 1
    if self._action_index == self._action_count:
      return None
    return self._action_list[self._action_index]

#   op_action_seq, agent_name, steps; _start_step, _is_active, _failed, _update_shared
# op_type =
#   goto
#   service
#   charge
#   abort
#   buy
#   deliver_job
class Action():
  def __init__(self, type, agent_name, steps, **args):
    self._type = type
    self._agent_name = agent_name
    self._steps = steps
    self._args = args
    for x_key, x_value in args.items():
      setattr(self, x_key, x_value)
    self._repr = ""
    # negative so calculated action_steps = step - start_step is always positive
    self._start_step = -util.MAX_STEPS
    self._is_active = False
    self._failed = False
    self._updated_shared = False
  
  def __repr__(self):
    return self._repr
  
  def run_step(self, agent):
    return agent._step - self._start_step
  
  def send_action(self, agent):
    pass
  
  # make possible to send_action once again; on failed_random
  def reset(self, agent):
    self._is_active = False
  
  # single step operations
  def is_active(self, agent):
    return False
  
  # failure status, all checks done in is_active() or send_action()
  # if not defined, failure handled by perception
  def is_failed(self, agent):
    return False
  
  def failed_error(self, agent):
    return None
  
  # only update_shared() can update team data structures
  # it is called with different agent than the op agent and must use only object data
  def update_shared(self, agent, lastActionResult=None):
    pass
  
  def on_action_failed(self, agent):
    pass
  
  def is_continuous(self, agent):
    return False



#cache_categ codes
STEPS_NOCACHE = 0
STEPS_CACHE = 1
STEPS_CACHE_R = 2

CACHE_CATEG_LIST = ["NOCACHE", "CACHE", "CACHE_R"]
STEPS_CATEG_LIST = ["LESS", "EXACT", "MORE"]

# NOTE !!! any jobs_db cleanup on action failed will be done by jobs_db_cleanup()
# will remove BUY and ON_BOARD too since will not proceed to deliver
# **args: _fac_id, _cache_p, _src_id, _job_id (can be "")
class op_goto(Action):
  def __init__(self, agent_name, steps, **args):
    super().__init__("goto", agent_name, steps, **args)
    self._cache_key = None
    self._cache_value = None
    self._fac_data = None
    team.fac_goto[self._fac_id].add(agent_name) # safe because only one agent doing op(s)
    self._cache_categ = CACHE_CATEG_LIST[self._cache_p]
    self._action_steps = 0
    self._steps_categ = ""
    self._repr = "{:s} ({:s}) goto => {:s} ({:d} steps {:s}) {:s}".format(
      self._agent_name, self._src_id, self._fac_id, self._steps, self._cache_categ, self._job_id
    )
  
  def send_action(self, agent):
    log = agent._log
    if self._is_active:
      log.error("op_goto.send_action() called more than once !!!")
      return
    if self._steps == 0:
      log.critical("!!! 0 step goto, {}".format(self.__repr__()))
    inFacility = agent.view.self.inFacility
    if inFacility == self._src_id:
      self._start_step = agent._step
      perception_id = agent.view.perception.id
      agent._comm.send_action(perception_id, "goto", **{"facility": self._fac_id})
      self._is_active = True
    else:
      log.error("ASSERT ERROR, op_goto not in assumed facility")
      self._is_active = False
      self._failed = True
      skip(agent)
  
  def is_active(self, agent):
    log = agent._log
    if not self._is_active:
      return False
    src_id = self._src_id
    fac_id = self._fac_id
    x = agent.view
    a_self = x.self
    if a_self.inFacility == fac_id:
      self._is_active = False
      
      action_steps = agent._step - self._start_step
      steps = self._steps
      cache_categ = self._cache_categ
      steps_categ = STEPS_CATEG_LIST[util.sign(action_steps - steps)+1]
      log.info("goto {:s} => {:s} completed in {:d} steps (estimated = {:d}), {:s}_{:s}".format(
        src_id, fac_id, action_steps, steps, cache_categ, steps_categ
      ))
      self._action_steps = action_steps
      self._steps_categ = steps_categ
      # in new facility
      if src_id != "none" and src_id != fac_id:
        # update dist_cache
        self._cache_key = team.mk_cache_key(src_id, fac_id, agent.sim.role.name)
        self._cache_value = action_steps
        if self._cache_p and action_steps != steps:
          log.debug("wrong cache prediction {:s} = {:d} => {:d}".format(self._cache_key, steps, action_steps))
      # if in shop, update shop_inventory
      #fac_data = util.facility_data(agent, fac_id)
      fac_data = x.facilities.get(fac_id, None)
      if fac_data and fac_data.facility_type == "shop":
        # shop       lat, lon, name, extra => [ name, ?info#cost, ?info#amount, ?info#restock ]
        self._fac_data = fac_data
    else:
      if int(a_self.charge) == 0:
        log.error("agent STALLED !!!")
        team.service_job[self._agent_name] = self._job_id
        self._is_active = False
        self._failed = True
    
    return self._is_active
  
  # failure status, all checks done in is_active() or send_action()
  # if not defined, failure handled by perception
  def is_failed(self, agent):
    return self._failed
  
  def failed_error(self, agent):
    if self._failed:
      return "NO CHARGE"
    else:
      return None
  
  # only update_shared() can update team data structures
  # it is called with different agent than the op agent and must use only object data
  def update_shared(self, agent, lastActionResult=None):
    log = agent._log
    if not self._updated_shared and not self._is_active:
      self._updated_shared = True
      # update dist_cache
      cache_key = self._cache_key
      cache_value = self._cache_value
      if cache_key is not None and cache_value is not None:
        cache = team.dist_cache
        #cache_key = mk_cache_key(self._start_fac_id, self._fac_id, agent._sim.role.name)
        #cache_value = action_steps
        cache[cache_key] = cache_value
        log.info("op_goto, updated cache {:s} -> {:d}".format(cache_key, cache_value))
      # goto stats
      cache_categ = self._cache_categ
      steps_categ = self._steps_categ
      team.goto_stats[cache_categ+"_"+steps_categ] += 1
      action_steps = self._action_steps
      steps = self._steps
      if action_steps > steps:
        fac = action_steps/max(steps, 1) # catch bugs
        if fac > team.max_goto_fac[cache_categ]:
          team.max_goto_fac[cache_categ] = fac
      # if in shop, update shop_inventory
      agent_name = self._agent_name
      fac_data = self._fac_data
      if fac_data is not None:
        # shop       lat, lon, name, extra => [ name, ?info#cost, ?info#amount, ?info#restock ]
        team.shop_inventory[fac_data.name] = util.attr_dict(
          {"data_step": agent._step, "data_agent": agent_name, "data": fac_data.extra}
        )
        log.info("op_goto, updated shop inventory for {:s}".format(fac_data.name))
      # update fac_goto
      fac_id = self._fac_id
      fac_goto = team.fac_goto
      if fac_id in fac_goto and agent_name in fac_goto[fac_id]:
        fac_goto[fac_id].remove(agent_name)
  
  def on_action_failed(self, agent):
    agent_name = self._agent_name
    fac_id = self._fac_id
    fac_goto = team.fac_goto
    if fac_id in fac_goto and agent_name in fac_goto[fac_id]:
      fac_goto[fac_id].remove(agent_name)



def skip(agent):
  perception_id = agent.view.perception.id
  agent._comm.send_action(perception_id, "skip")



# **args: _job_id (can be "")
class op_service(Action):
  def __init__(self, agent_name, steps, **args):
    super().__init__("service", agent_name, steps, **args)
    self._repr = "{:s} service ({:d} steps) {:s}".format(self._agent_name, self._steps, self._job_id)
  
  def send_action(self, agent):
    log = agent._log
    #if self._is_active:
    #  log.error("op_service.send_action() called more than once !!!")
    #  return
    if self._start_step < 0:
      self._start_step = agent._step
    perception_id = agent.view.perception.id
    agent._comm.send_action(perception_id, "call_breakdown_service")
    self._is_active = True
  
  def is_active(self, agent):
    log = agent._log
    if not self._is_active:
      return False
    a_self = agent.view.self
    charge = int(a_self.charge)
    batteryCapacity = int(a_self.batteryCapacity)
    if charge == batteryCapacity:
      self._is_active = False
      action_steps = agent._step - self._start_step
      log.info("service completed in {:d} steps (estimated = {:d})".format(action_steps, self._steps))
    return self._is_active
  
  # only update_shared() can update team data structures
  # it is called with different agent than the op agent and must use only object data
  def update_shared(self, agent, lastActionResult=None):
    log = agent._log
    if not self._updated_shared and not self._is_active:
      self._updated_shared = True
      SERVICE_FEE = util.SERVICE_FEE
      if self._job_id:
        team.job_service_cost[self._job_id] += SERVICE_FEE
        team.alljobs_service_cost += SERVICE_FEE
      else:
        team.explore_service_cost += SERVICE_FEE
      log.info("op_service, updated cost = {:d}".format(SERVICE_FEE))
      team.update_money(agent)
  
  def is_continuous(self, agent):
    return True



# **args: _fac_id, _job_id (can be "")
class op_charge(Action):
  def __init__(self, agent_name, steps, **args):
    super().__init__("charge", agent_name, steps, **args)
    self._last_charge = 0
    self._new_charge = 0
    self._battery_capacity = 0
    self._price = 0
    self._repr = "{:s} ({:s}) charge ({:d} steps) {:s}".format(self._agent_name, self._fac_id, self._steps, self._job_id)
  
  def send_action(self, agent):
    log = agent._log
    if self._is_active:
      log.error("op_charge.send_action() called more than once !!!")
      return
    x = agent.view
    a_self = x.self
    inFacility = a_self.inFacility
    fac_data = x.facilities.get(inFacility, None)
    if fac_data and fac_data.facility_type == "chargingStation" and inFacility == self._fac_id:
      self._last_charge = int(a_self.charge)
      self._batteryCapacity = int(a_self.batteryCapacity)
      self._price = int(fac_data.price)
      self._start_step = agent._step
      perception_id = agent.view.perception.id
      agent._comm.send_action(perception_id, "charge")
      self._is_active = True
    else:
      log.error("ASSERT ERROR, op_charge not in charging station")
      self._is_active = False
      self._failed = True
      skip(agent)
  
  def is_active(self, agent):
    log = agent._log
    if not self._is_active:
      return False
    a_self = agent.view.self
    new_charge = int(a_self.charge)
    self._new_charge = new_charge
    if  new_charge == self._batteryCapacity:
      self._is_active = False
      action_steps = agent._step - self._start_step
      log.info("charge completed in {:d} steps (estimated = {:d})".format(action_steps, self._steps))
    return self._is_active
  
  # failure status, all checks done in is_active() or send_action()
  # if not defined, failure handled by perception
  def is_failed(self, agent):
    return self._failed
  
  def failed_error(self, agent):
    if self._failed:
      return "NOT IN CHARGING STATION"
    else:
      return None
  
  # only update_shared() can update team data structures
  # it is called with different agent than the op agent and must use only object data
  def update_shared(self, agent, lastActionResult=None):
    log = agent._log
    last_charge = self._last_charge
    new_charge = self._new_charge
    if new_charge > last_charge:
      charge_cost = (new_charge - last_charge) * self._price
      if self._job_id:
        team.job_charge_cost[self._job_id] += charge_cost
        team.alljobs_charge_cost += charge_cost
      else:
        team.explore_charge_cost += charge_cost
      log.info("op_charge, updated cost = {:d}".format(charge_cost))
      team.update_money(agent)
      self._last_charge = new_charge



class op_abort(Action):
  def __init__(self, agent_name, steps, **args):
    super().__init__("abort", agent_name, steps, **args)
    self._repr = "{:s} abort".format(self._agent_name)
  
  def send_action(self, agent):
    log = agent._log
    if self._is_active:
      log.error("op_abort.send_action() called more than once !!!")
      return
    self._start_step = agent._step
    perception_id = agent.view.perception.id
    agent._comm.send_action(perception_id, "abort")
    self._is_active = True



# NOTE !!! any jobs_db cleanup on action failed will be done by jobs_db_cleanup()
# will remove BUY and ON_BOARD too since will not proceed to deliver
# NOTE !!! after failure to buy will not proceed to deliver because entire action sequence is aborted !!!
# this is the desired behavior
# **args: _item_name, _item_amount, _fac_id, _job_id, _piece_id
class op_buy(Action):
  def __init__(self, agent_name, steps, **args):
    super().__init__("buy", agent_name, steps, **args)
    self._cost = 0
    self._repr = "{:s} ({:s}) buy: {:s}, {:d} => {:s}".format(
      self._agent_name, self._fac_id, self._item_name, self._item_amount, self._job_id
    )
  
  def send_action(self, agent):
    log = agent._log
    if self._is_active:
      log.error("op_buy.send_action() called more than once !!!")
      return
    item_name = self._item_name
    x = agent.view
    a_self = x.self
    inFacility = a_self.inFacility
    fac_data = x.facilities.get(inFacility, None)
    # a bit superfluous as buy commands are given only when inside shop !
    if fac_data and fac_data.facility_type == "shop" and inFacility == self._fac_id:
      fac_items = fac_data.extra
      if item_name in fac_items and int(fac_items[item_name].amount) >= self._item_amount:
        self._cost = int(fac_items[item_name].cost)
        self._start_step = agent._step
        perception_id = agent.view.perception.id
        agent._comm.send_action(perception_id, "buy", **{"item": self._item_name, "amount": str(self._item_amount)})
        self._is_active = True
      else:
        log.error("ASSERT ERROR, op_buy no item or not enough amount")
        self._is_active = False
        self._failed = True
    else:
      log.error("ASSERT ERROR, op_buy not in shop")
      self._is_active = False
      self._failed = True
      skip(agent)
  
  # failure status, all checks done in is_active() or send_action()
  # if not defined, failure handled by perception
  def is_failed(self, agent):
    return self._failed
  
  def failed_error(self, agent):
    if self._failed:
      return "NO ITEM"
    else:
      return None
  
  # only update_shared() can update team data structures
  # it is called with different agent than the op agent and must use only object data
  def update_shared(self, agent, lastActionResult=None):
    log = agent._log
    if not self._updated_shared:
      self._updated_shared = True
      team.jobs.piece_state(agent, self._job_id, self._item_name, self._piece_id, "ON_BOARD")
      buy_cost = self._item_amount * self._cost
      if self._job_id:
        team.job_buy_cost[self._job_id] += buy_cost
        team.alljobs_buy_cost += buy_cost
      log.info("op_buy, updated cost = {:d}".format(buy_cost))
      team.update_money(agent)



# cleanup will be done by jobs_db_cleanup()
# suprefluous need for fail checks (inside correct storage, since system should check and previous goto will have checked too)
# **args: _job_id, _fac_id
class op_deliver_job(Action):
  def __init__(self, agent_name, steps, **args):
    super().__init__("deliver_job", agent_name, steps, **args)
    self._self_items = None
    self._repr = "{:s} ({:s}) deliver_job => {:s}".format(self._agent_name, self._fac_id, self._job_id)
  
  def send_action(self, agent):
    log = agent._log
    if self._is_active:
      log.error("op_deliver_job.send_action() called more than once !!!")
      return
    x = agent.view
    a_self = x.self
    inFacility = a_self.inFacility
    fac_data = x.facilities.get(inFacility, None)
    if fac_data and fac_data.facility_type == "storage" and inFacility == self._fac_id:
      team.jobs.agent_deliver_assert(agent, self._job_id)
      self._self_items = list(x.self_items.values())
      self._start_step = agent._step
      perception_id = agent.view.perception.id
      agent._comm.send_action(perception_id, "deliver_job", **{"job": self._job_id})
      self._is_active = True
    else:
      log.error("ASSERT ERROR, op_deliver_job not in storage")
      self._is_active = False
      self._failed = True
      skip(agent)
  
  # failure status, all checks done in is_active() or send_action()
  # if not defined, failure handled by perception
  def is_failed(self, agent):
    return self._failed
  
  def failed_error(self, agent):
    if self._failed:
      return "NOT IN STORAGE"
    else:
      return None
  
  # only update_shared() can update team data structures
  # it is called with different agent than the op agent and must use only object data
  def update_shared(self, agent, lastActionResult=None):
    log = agent._log
    if not self._updated_shared:
      self._updated_shared = True
      jobs = team.jobs
      job_id = self._job_id
      #
      jobs.agent_deliver_check(agent, job_id, self._self_items)
      jobs.agent_delivered(agent, job_id)
      #
      delivered = False
      if lastActionResult and lastActionResult == "successful":
        log.critical("op_deliver_job, job {:s} IS NOT completed, but system says IS completed !!!".format(job_id))
        delivered = True
      if delivered or jobs.job_is_complete(agent, job_id):
        # update money
        job_reward = 0
        if job_id in jobs._jobs_db:
          job_reward = int(jobs._jobs_db[job_id].reward)
        team.rewards += job_reward
        team.update_money(agent)
        log.info("op_deliver_job, job completed YAIII !!!, updated reward = {:d}".format(job_reward))
        team.print_job_money_stats(agent, job_id)
        # update QoS info
        team.completed_jobs.add(job_id)
        # delete from db
        jobs.job_del(agent, job_id)
        #
        if lastActionResult and lastActionResult == "successful_partial":
          log.critical("op_deliver_job, job {:s} IS completed, but system says IS NOT completed !!!".format(job_id))



# **args: _job_spec
class op_post_job(Action):
  def __init__(self, agent_name, steps, **args):
    super().__init__("post_job", agent_name, steps, **args)
    reward = self._job_spec["price"]
    a_steps = self._job_spec["active_steps"]
    storage = self._job_spec["storage"]
    self._repr = "{:s} post_job {:s} in {:s} to {:s}".format(self._agent_name, reward, a_steps, storage)
  
  def send_action(self, agent):
    log = agent._log
    if self._is_active:
      log.error("op_post_job.send_action() called more than once !!!")
      return
    self._start_step = agent._step
    perception_id = agent.view.perception.id
    # type=priced price= active_steps= storage= item1= amount1= item2= amount2= ...
    agent._comm.send_action(perception_id, "post_job", **self._job_spec)
    self._is_active = True
