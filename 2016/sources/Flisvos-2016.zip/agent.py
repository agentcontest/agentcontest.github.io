
"""

 /*
  * @(#) E.Sarmas   agent.py 1.29e (2016-09-12)
  *
  * Author: E.Sarmas
  *
  * Created: 2016-06-20
  *
  * Description: Flisvos 2016 (MAPC 2016)
  *
  * Version: 1.29e
  * Version-Date: 2016-09-12
  *
  */

"""

import threading
import comm
import logging
import util
import util2
import actions
import team
import main

x_lock = threading.Lock()
#x_sema = threading.Semaphore(0)

# response threshold in sec, above which issue warning
STEP_RESPONSE_THRESHOLD = 1.5

class Agent(threading.Thread):
  
  def __init__(self, id, host, port, agent_name, password, shared, verbose):
    threading.Thread.__init__(self)
    self._id = id
    self._host = host
    self._port = port
    self._agent_name = agent_name
    self._password = password
    self._shared = shared
    self._agent_shared = None
    self._verbose = verbose
    self._comm = comm.Comm(id, host, port, agent_name, password, verbose)
    
    log = logging.getLogger(agent_name)
    # must set !
    if verbose:
      log.setLevel(main.LOG_DETAIL)
    else:
      log.setLevel(logging.DEBUG)
    
    fileh = logging.FileHandler(filename = main.LOGFILE_PREFIX + agent_name + ".log", mode = "w")
    if verbose:
      fileh.setLevel(main.LOG_DETAIL)
    else:
      fileh.setLevel(logging.DEBUG)
    fileh.setFormatter(logging.Formatter(main.LOGFILE_FORMAT))
    log.addHandler(fileh)
    
    # define a Handler which writes INFO messages or higher to the sys.stderr
    #console = logging.StreamHandler()
    #console.setLevel(logging.INFO)
    #console.setFormatter(logging.Formatter(main.CONSOLE_FORMAT))
    #log.addHandler(console)
    
    log.info("started logging... (level = {})".format(log.getEffectiveLevel()))
    
    self._log = log
    self._step = 0
    self._money = 0
    self.sim = None
    self.view = None
    self.job_op = None
    self._event = threading.Event()
  
  def run(self):
    '''
    t_start = time.time()
    while True:
      time.sleep(self._id/5+1)
      self._log.info("koukou, id = {:d}".format(self._id))
      t_now = time.time()
      if t_now > t_start + 10:
        break
    '''
    '''
      #
      # message => timestamp, type
      #
      # sim-end
      #   sim_result => ranking, score
      #
      # sim-start (sim)
      #   simulation => id, map, seedCapital, steps, team
      #   role => name, speed, maxLoad, maxBattery (name = Car, Drone, Motorcycle, Truck)
      #   tool => [ name ]
      #   products => [
      #     assembled(true/false), name, volume,
      #       consumed => [ name, amount ],
      #       tools =>    [ name, amount ]
      #   ]
      #
      # request-action (view)
      #   perception => deadline, id
      #   simulation => step
      #   self => batteryCapacity, charge, fPosition(-1), inFacility(none),
      #     lastAction(noAction), lastActionParam, lastActionResult, lat, lon, load, loadCapacity,
      #     name, routeLength
      #   self_items => [ name, amount ]
      #   route => [ i, lat, lon ]
      #   team => money
      #   jobs_taken => [ id ]
      #   jobs_posted => [ id ]
      #   entities => [ lat, lon, name, role, team ]
      #   facilities => [
      #     facility_type =
      #       chargingStation   lat, lon, name, price, rate, slots, ?info#qSize
      #       dumpLocation   lat, lon, name, price
      #       workshop   lat, lon, name, price
      #       storage    lat, lon, name, price, totalCapacity, usedCapacity, extra => [ name, ?stored, ?delivered ]
      #       shop       lat, lon, name, extra => [ name, ?info#cost, ?info#amount, ?info#restock ]
      #   ]
      #   jobs => [
      #     job_type =
      #       pricedJob    begin, end, id, reward, storage, job_items => [ name, amount, ?delivered ]
      #       auctionJob   begin, end, fine, id, maxBid, storage, job_items => [ name, amount ]
      #   ]
      #
    '''
    log = self._log
    agent_name = self._agent_name
    #thread_data = threading.local()
    lap_timer = util.LapTimer(log)
    while True:
      msg_type, data, msg_xml, msg_str = self._comm.get_msg()
      log.debug("agent, msg_type = {:s}".format(msg_type))
      if msg_type == "sim-start":
        self._step = 0
        self._money = 0
        self.sim = data
        self.view = None
        self.job_op = None
        #log.info("sim-start")
        #   simulation => id, map, seedCapital, steps, team
        #x = data.simulation
        #log.info("sim, id = {}, map = {}, seedCapital = {}, steps = {}, team = {}".format(
        #  x.id, x.map, x.seedCapital, x.steps, x.team
        #))
        #   role => name, speed, maxLoad, maxBattery (name = Car, Drone, Motorcycle, Truck)
        #x = data.role
        #log.info("role, name = {}, speed = {}, maxLoad = {}, maxBattery = {}".format(
        #  x.name, x.speed, x.maxLoad, x.maxBattery
        #))
        with x_lock:
          # team init
          if (getattr(team, "sim_id", None) is None or team.sim_id != data.simulation.id
            or getattr(team, "map_name", None) is None or team.map_name != data.simulation.map):
            team.team_initialize(self)
          # shared init
          self._shared[agent_name] = util.attr_dict({
            "sim": self.sim, "view": self.view, "inwait": False, "job_op": None, "event": self._event
          })
          self._agent_shared = self._shared[agent_name]
          util2.set_map(self)
        continue
      if msg_type == "sim-end":
        x = data.sim_result
        log.info("sim-end, ranking = {}, score = {}, action stats:{}".format(x.ranking, x.score,
          ";".join(" "+stat_id+"="+str(stat_value) for stat_id, stat_value in team.action_stats.items())
        ))
        continue
      if msg_type == "bye":
        break
      if msg_type == "request-action":
        lap_timer.lap_start()
        agent_shared = self._agent_shared
        shared = self._shared
        self.view = data
        self._step = int(data.simulation.step)
        step = self._step
        self._money = int(data.team.money)
        #   self => batteryCapacity, charge, fPosition(-1), inFacility(none),
        #     lastAction(noAction), lastActionParam, lastActionResult, lat, lon, load, loadCapacity,
        #     name, routeLength
        x = data.self
        log.debug("step = {:d}, last action = {:s}, {:s} => {:s}".format(
          step, x.lastAction, x.lastActionParam, x.lastActionResult
        ))
        inFacility = x.inFacility
        log.debug("inFacility = {:s}, routeLength = {:s}, charge = {:s}/{:s}, fPosition = {:s}, load = {:s}/{:s}".format(
          inFacility, x.routeLength, x.charge, x.batteryCapacity, x.fPosition, x.load, x.loadCapacity
        ))
        #   self_items => [ name, amount ]
        log.debug("on_board =>{}".format(";".join(" "+s.name+","+str(s.amount) for s in data.self_items.values())))
        
        lastAction = x.lastAction
        lastActionResult = x.lastActionResult
        if lastAction == "noAction":
          log.critical("<<<   noAction   >>>")
        last_action = None
        # update job step, check if successful last action, else delete current job_op
        if self.job_op is not None:
          failed = False
          op_action = job_op.action()
          # special logging
          if lastActionResult == "failed_random":
            log.info("step = {:d}, action: {} failed_random !!!".format(step, op_action))
            # !!! hack for charge !!!
            if type(op_action) == actions.op_charge:
              log.info("step = {:d}, action: {} failed_random, changed to successful !!!".format(step, op_action))
              lastActionResult = "successful"
          ###
          # more hack for useless, seems it's like success eventually;
          # db not ok since kind of targeted only to gather items for a job
          # but many items onboard in other agents and happy accidents may happen
          if lastActionResult == "useless" and type(op_action) == actions.op_deliver_job:
            log.info("step = {:d}, action: {} useless, changed to successful !!!".format(step, op_action))
            lastActionResult = "successful"
          ###
          if lastActionResult not in ["successful", "successful_partial", ""] or lastAction == "noAction":
            if lastActionResult == "failed_random": 
              log.info("step = {:d}, action: {} failed_random".format(step, op_action))
              if lastAction != "skip":
                log.info("step = {:d}, action: {} failed_random, action reset !".format(step, op_action))
                op_action.reset(self)
            else:
              log.error("step = {:d}, action: {} failed (system): {:s}, deleting job_op !!!".format(
                step, op_action, lastActionResult
              ))
              failed = True
          else:
            # as a side effect will setup shared data to be updated
            if op_action.is_active(self):
              log.debug("step = {:d}, action: {} continues (step {:d})".format(step, op_action, op_action.run_step(self)))
              last_action = op_action
            else:
              if op_action.is_failed(self):
                log.error("step = {:d}, action: {} failed (internal): {:s}, deleting job_op !!!".format(
                  step, op_action, op_action.failed_error(self)
                ))
                failed = True
              else:
                log.info("step = {:d}, action: {} finished".format(step, op_action))
                last_action = op_action
                op_action = job_op.next_action()
                if op_action is None:
                  log.info("step = {:d}, job has no more actions, deleted".format(step))
                  self.job_op = None
          
          if failed:
            for x_op_action in self.job_op:
              x_op_action.on_action_failed(self)
            self.job_op = None
        
        # if restarting then abort any past action before crash (goto)
        # useless ? since a new goto seems to override a previous running goto
        #if len(data.route) > 0 and self.job_op is None:
        #  log.warning("step = {:d}, aborting previous goto !".format(step))
        #  action_seq = actions.Action_Seq()
        #  action_seq.append(actions.op_abort(agent_name, 1))
        #  self.job_op = action_seq
        
        #log.debug("agent, pre x_lock")        
        lap_timer.sub_lap("pre x_lock")
        
        # update shared with own data and optionally evaluate new job
        with x_lock:
          log.debug("agent, in x_lock")
          agent_shared.inwait = True
          agent_shared.view = data
          agent_shared.job_op = self.job_op
          if last_action is not None:
            last_action.update_shared(self, lastActionResult)
          team.action_stats[lastActionResult] += 1
          
          self._event.clear()
          
          # serious issue, if not all threads connect on same step then none detects last and all stay locked here
          # fixed with check on inwait flag
          # BUT still could have situation where half threads one step ahead of other half
          # because half enter barrier at one time and then all
          # so extra check if all NUM_AGENTS present
          all_updated = True
          max_step = 0
          min_step = util.MAX_STEPS
          for x_agent_name, x_agent_data in shared.items():
            if x_agent_data.inwait is False:
              all_updated = False
              break
            x_step = int(x_agent_data.view.simulation.step)
            if x_step > max_step:
              max_step = x_step
            if x_step < min_step:
              min_step = x_step
          
          ### debug
          '''
          log.debug("step = {}, all_updated = {}, len(shared) = {:d}, min_step = {:d}, max_step = {:}".format(
            agent_shared.view.simulation.step, all_updated, len(shared), min_step, max_step
          ))
          for x_agent_name in sorted(shared.keys(), key=util.natural_sort_key):
            x_agent_shared = shared[x_agent_name]
            x_step = None
            if x_agent_shared.view is not None:
              x_step = x_agent_shared.view.simulation.step
            x_inwait = x_agent_shared.inwait
            log.debug("{:s}({}), inwait = {}".format(x_agent_name, x_step, x_inwait))
          '''
          if all_updated and len(shared) == main.NUM_AGENTS:
            
            # one time start logs
            if team.first_loop:
              team.first_loop = False
              
              #   simulation => id, map, seedCapital, steps, team
              log.info("")
              x = self.sim.simulation
              log.info("sim, id = {}, map = {}, seedCapital = {}, steps = {}, team = {}".format(
                x.id, x.map, x.seedCapital, x.steps, x.team
              ))
              # map + parameter data
              log.info("CELL_SIZE = {:.3f}, QUAD_SIZE = {:.2f}, PROXIMITY = {:.4f}, DIST_ROUTE_FAC = {:.2f}".format(
                util.CELL_SIZE, util.QUAD_SIZE, util.PROXIMITY, util.DIST_ROUTE_FAC))
              log.info("map {:.4f} - {:.4f}, {:.4f} - {:.4f}".format(
                util.MAP_MIN_LAT, util.MAP_MAX_LAT, util.MAP_MIN_LON, util.MAP_MAX_LON))
              log.info("CELLS = {:d} x {:d} = {:d}".format(util.MAP_CELLS_LON, util.MAP_CELLS_LAT, util.MAP_CELLS))
              log.info("QUADS = {:d} x {:d} = {:d}".format(util.MAP_QUADS_LON, util.MAP_QUADS_LAT, util.MAP_QUADS))
              log.info("CHARGE_STEP = {:d}, SERVICE_CALL_MIN_STEPS = {:d}".format(util.CHARGE_STEP, util.SERVICE_CALL_MIN_SIM_STEPS))
              log.info("")
              #   role => name, speed, maxLoad, maxBattery (name = Car, Drone, Motorcycle, Truck)
              for x_agent_name in sorted(shared.keys(), key=util.natural_sort_key):
                x_agent_shared = shared[x_agent_name]
                x_step = x_agent_shared.view.simulation.step
                x = x_agent_shared.sim.role
                log.info("{:s}({:s}), name = {}, speed = {}, maxLoad = {}, maxBattery = {}".format(
                  x_agent_name, x_step, x.name, x.speed, x.maxLoad, x.maxBattery
                ))
              log.info("")
          
          if all_updated and len(shared) == main.NUM_AGENTS and min_step == max_step:
            
            team.step = max_step
            log.info("")
            log.info("step = {:d} last thread to update shared, doing job evaluation".format(step))
            log.info("")
            # the following update shared data structure and assume are free to do within lock region
            
            lap_timer.sub_lap("pre main loop")
            
            # dynamic settings update !?
            util.settings(self)
            
            # !!! test only !!!
            #util.test_joins(log)
            
            jobs_db = team.jobs
            # in this order !
            jobs_db.cleanup(self)
            jobs_db.check(self)
            lap_timer.sub_lap("jobs_db check and cleanup")
            
            # !!! test only !!!
            #util.test_actions(self)
            #util.test_actions_v2(self)
            
            team.fac_agents_update(self)
            
            util.jobs_spec_update(self)
            
            #util.drop_jobs(self)
            
            util.complete_jobs(self)
            util.new_jobs(self)
            util.explore_jobs(self)
            
            #util.dump_ops(self)
            
            # no other op possible and no charge to move around
            # mainly to allow buys to proceed and then call service 
            util.service(self)
            
            # finally, some cookies, CC or CuriousCat op
            util.CC_op(self)
            
            lap_timer.sub_lap("actions")
            
            # status logging
            log.info("")
            log.info("========= STATUS =========")
            active_agents = sorted([name for name in shared.keys() if shared[name].job_op is not None], key=util.natural_sort_key)
            #[job_id for job_id in jobs_db._jobs_db]
            log.info("step = {:d}, money = {:d}, active jobs = {:d}, active agents = {:d}".format(
              step, self._money, len(jobs_db._jobs_db), len(active_agents)
            ))
            log.info("=== agent state ===")
            for x_agent_name in sorted(shared.keys(), key=util.natural_sort_key):
              x_agent_shared = shared[x_agent_name]
              x_view = x_agent_shared.view
              x_step = x_view.simulation.step
              x = x_view.self
              log.info("{:s}({:s}), in: {:s}, r: {:s}, charge: {:s}/{:s}, fP: {:s}, load: {:s}/{:s} ={}".format(
                x_agent_name, x_step, x.inFacility, x.routeLength, x.charge, x.batteryCapacity, x.fPosition, x.load, x.loadCapacity,
                ";".join(" "+s.name+","+str(s.amount) for s in x_view.self_items.values())
              ))
            log.info("=== agent ops ===")
            for x_agent_name in active_agents:
              log.info("{:s} => {}".format(x_agent_name, shared[x_agent_name].job_op))
            # per fac agents on spot
            team.print_fac_agents(self)
            # per fac agents going there
            team.print_fac_goto(self)
            # shop inventory
            team.print_shop_inventory(self)
            # system pricedJobs summary
            team.jobs_db.summary(data.jobs, self)
            # committed jobs db status
            jobs_db.print(self)
            # goto stats
            team.print_goto_stats(self)
            # settings
            util.print_settings(self)
            # money stats
            team.print_money_stats(self)
            # QoS
            team.job_QoS_state(self)
            
            lap_timer.sub_lap("status logging")
          
          # open barrier
          if all_updated:
            if min_step < max_step:
              self.unlock_min_agents(max_step)
            else:
              self.unlock_all_agents()
            #for x_agent_name, x_agent_data in shared.items():
            #  x_agent_data.inwait = False
            #for x_agent_name, x_agent_data in shared.items():
            #  x_sema.release()
        
        #x_sema.acquire()
        self._event.wait()
        
        lap_timer.sub_lap("post x_lock")
        #log.debug("agent, post x_lock")
        
        # === action part ===
        
        # === actions ===
        #   YES goto facility=, buy item= amount=, deliver_job job= <<< by algorithms
        #   YES skip, charge <<< by job_op handling
        #   ??? post_job type=priced price= active_steps= storage= item1= amount1= item2= amount2= ...
        #   ??? retrieve_delivered item= amount=
        #   ??? store item= amount=, retrieve item= amount=, dump item= amount=
        #   --- give agent= item= amount=, receive
        #   +++ assemble item=, assist_assemble assembler=
        
        # job_op
        prev_job_op = self.job_op
        job_op = agent_shared.job_op
        self.job_op = job_op
        if job_op is not None:
          if prev_job_op is None:
            log.info("step = {:d}, new job_op with actions = {}".format(step, job_op))
          op_action = job_op.action()
          if not op_action.is_active(self) or op_action.is_continuous(self):
            op_action.send_action(self)
            log.info("step = {:d}, action: {} sent".format(step, op_action))
          else:
            # continue
            actions.skip(self)
        else:
          # default
          actions.skip(self)
        
        ela = lap_timer.lap("complete")
        ###log.debug("elapsed time = {:.3f}".format(ela))
        if ela > STEP_RESPONSE_THRESHOLD:
          log.warning("step = {:d}, elapsed time = {:.3f} exceeded threshold = {:.3f}".format(step, ela, STEP_RESPONSE_THRESHOLD))
  
  # optionally suffled unlock
  def unlock_all_agents(self):
    log = self._log
    shared = self._shared
    step = self._step
    
    log.info("")
    log.info("step = {:d}, unlock barrier for (all) {:d} of {:d}, NUM_AGENTS = {:d}".format(
      step, len(shared), len(shared), main.NUM_AGENTS
    ))
    log.info("")
    
    for x_agent_name, x_agent_data in shared.items():
      x_agent_data.inwait = False
      x_agent_data.event.set()
  
  # optionally suffled unlock
  def unlock_min_agents(self, max_step):
    log = self._log
    shared = self._shared
    step = self._step

    q = []
    for x_agent_name, x_agent_data in shared.items():
      x_step = int(x_agent_data.view.simulation.step)
      if x_step < max_step:
        q.append(x_agent_data)
    
    log.info("")
    log.info("step = {:d}, unlock barrier for (min) {:d} of {:d}, NUM_AGENTS = {:d}".format(
      step, len(q), len(shared), main.NUM_AGENTS
    ))
    log.info("")
    
    for x_agent_data in q:
      x_agent_data.inwait = False
      x_agent_data.event.set()