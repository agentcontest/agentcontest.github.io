﻿Multi-Agent Programming Contest 2016 - Python-DTU

Participants from DTU Compute:

- Jørgen Villadsen - Supervisor - Associate professor

- Andreas Halkjær From

- Salvador Jacobi

- Nikolaj Nøkkentved Larsen 

Algorithms, Logic and Graphs Section
Department of Applied Mathematics and Computer Science
Technical University of Denmark

http://people.compute.dtu.dk/jovi/MAS/

----------

