#!/bin/bash

./bagentup.py -bawc Python-DTU

