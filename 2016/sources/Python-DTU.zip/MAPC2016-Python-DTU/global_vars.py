ADDRESS = ('localhost', 12300)
PASSWORD = '1'
TIMEOUT = 4.0
RETRY_DELAY = 1.0

NUM_OF_AGENTS = 16

GOTO = 'goto'
BUY = 'buy'
GIVE = 'give'
RECEIVE = 'receive'
STORE = 'store'
RETRIEVE = 'retrieve'
RETRIEVE_DELIVERED = 'retrieve_delivered'
DUMP = 'dump'
ASSEMBLE = 'assemble'
ASSIST = 'assist_assemble'
DELIVER_JOB = 'deliver_job'
CHARGE = 'charge'
BID_FOR_JOB = 'bid_for_job'
POST_JOB = 'post_job'
CONTINUE = 'continue'
NOOP = 'skip'
SKIP = 'skip'
ABORT = 'abort'

RUN = True

STEPS_TO_CHARGE = 4  # approximate

THRESHOLD = {'Car': 10, 'Drone': 10, 'Motorcycle': 10, 'Truck': 10}

TOOL2ROLES = {'none': set()} # TODO: Why do we need none in here!?

ID_TO_SIM = {0: 2, 202: 1, 704: 3}  # map from the simulation id from the server, to the one in the config
SIM_TO_PORT = {1: 9001, 2: 9002, 3: 9003}  # ports for the graphhopper server running the corresponding maps
SIM_TO_MAP = {1: 'hannover.osm.pbf', 2: 'london.osm.pbf', 3: 'clausthal.osm.pbf'}

# USE_GRAPHHOPPER = False

MAXIMUM_CONCURRENT_JOBS = 2
STEPS_NEEDED_TO_COMPLETE_JOB = 110
