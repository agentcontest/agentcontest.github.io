from typing import NamedTuple, Dict # TODO: mypy does not like importing Dict here!?

Buy = NamedTuple('Buy', [('item', str), ('amount', int)])
Assemble = NamedTuple('Assemble', [('item', str), ('amount', int)])
Assist = NamedTuple('Assist', [('who', str), ('item', str), ('amount', int)])
Give = NamedTuple('Give', [('who', str), ('item', str), ('amount', int)])
Receive = NamedTuple('Receive', [('item', str), ('amount', int)])
Deliver = NamedTuple('Deliver', [('id', str), ('where', str)])
Goto = NamedTuple('Goto', [('target', str), ('steps', float)])
Charge = NamedTuple('Charge', [('steps', float)])
Bid_for_job = NamedTuple('Bid_for_job', [('job', str), ('price', int)])
Post_auction_job = NamedTuple('Post_auction_job', [('max_price', int), ('fine', int), ('auction_steps', int), ('active_steps', int), ('storage', str), ('items', Dict[str, int])])
Post_priced_job = NamedTuple('Post_priced_job', [('price', int), ('active_steps', int), ('storage', str), ('items', Dict[str, int])])
