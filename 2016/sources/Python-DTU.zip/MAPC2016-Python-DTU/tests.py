from unittest import TestCase
from bagentup import Runner
from typing import Any, Dict, Union, Set
from collections import defaultdict
from commands import *
from random import randrange


loadCapacities = {
    'Car': 550,
    'Drone': 100,
    'Motorcycle': 300,
    'Truck': 3000,
}

def prepareProducts(d1: Dict[str, Any]) -> Dict[str, Any]:
    d2 = {}
    for k1, v1 in d1.items():
        has_items = 'items' in v1 and v1['items'] != []
        has_tools = 'tools' in v1 and v1['tools'] != []
        assembled = has_items or has_tools
        d2[k1] = {'name': k1, 'volume': str(v1['volume']),'assembled': 'true' if assembled else 'false'}
        if assembled:
            items = v1['items'] if has_items else []
            tools = v1['tools'] if has_tools else []
            d2[k1]['items'] = [{'name': name, 'amount': str(amount)} for name, amount in items]
            d2[k1]['tools'] = [{'name': name, 'amount': str(amount)} for name, amount in tools]
    return d2

def prepareShops(d1: Dict[str, Any]) -> Dict[str, Any]:
    d2 = {}
    for k1, v1 in d1.items():
        d2[k1] = {'items': {name: {'cost': str(cost), 'amount': '100'} for name, cost in v1}}
    return d2

def prepareAgents(d1: Dict[str, Any]) -> (Dict[str, Any], Dict[str, Any]):
    d2 = {}
    for k1, v1 in d1.items():
        d2[k1] = type('Agent', (object,), {'name': k1, 'role': v1['role'],'plan': [], 'info': {'inFacility': 'none', 'items': []}})
        d2[k1].remaining_load = lambda capacity=loadCapacities[v1['role']]: capacity
        facility = v1.get('inFacility')
        if facility is not None:
            d2[k1].info['inFacility'] = facility
    return d2, list(d2.values())

def getToolNames(products: Dict[str, Any]) -> Set[str]:
    tool_names = set()
    for item_name, recipe in products.items():
        if not 'tools' in recipe:
            continue
        for tool in recipe['tools']:
            tool_names.add(tool['name'])
    return tool_names

products1_ = {
    'material1': {'volume': 10, 'items': [('base1', 5)], 'tools': [('tool1', 1)]},
    'material2': {'volume': 20, 'items': [('base1', 10)], 'tools': [('tool3', 1)]},
    'material3': {'volume': 100, 'items': [('material1', 2), ('base2', 2), ('base3', 1)], 'tools': [('tool1', 1), ('tool2', 1), ('tool3', 1)]},
    'base1': {'volume': 10},
    'base2': {'volume': 100},
    'base3': {'volume': 500},
    'tool1': {'volume': 10},
    'tool2': {'volume': 100},
    'tool3': {'volume': 30, 'items': [('base1', 8)]},
}
products1 = prepareProducts(products1_)

products2_ = {
    'a': {'volume': 1, 'items': [('b', 1), ('c', 2)]},
    'b': {'volume': 1, 'items': [('d', 3)], 'tools': [('e', 4)]},
    'c': {'volume': 1, 'items': [('f', 5)], 'tools': [('e', 6)]},
    'd': {'volume': 1},
    'e': {'volume': 1, 'items': [('g', 7)]},
    'f': {'volume': 1},
    'g': {'volume': 1},
}
products2 = prepareProducts(products2_)

# shop name -> [(item name, item cost)]
shops1_ = {
    'shop1': [('base1', 5), ('base2', 17), ('base3', 241), ('tool1', 51), ('tool2', 139)],
    'shop2': [('base1', 50), ('base2', 170), ('base3', 2410), ('tool1', 510), ('tool2', 1390)],
    'shop3': [('base1', 6), ('base2', 18), ('base3', 242), ('tool1', 52), ('tool2', 140)],
}
shops1 = prepareShops(shops1_)

ag_names1_ = {
    'a1': {'role': 'Car', 'inFacility': 'shop1'},
    'a2': {'role': 'Car'},
    'a3': {'role': 'Car'},
    'a4': {'role': 'Car'},
    'a5': {'role': 'Drone', 'inFacility': 'shop2'},
    'a6': {'role': 'Drone'},
    'a7': {'role': 'Drone'},
    'a8': {'role': 'Drone'},
    'a9': {'role': 'Motorcycle', 'inFacility': 'shop3'},
    'a10': {'role': 'Motorcycle'},
    'a11': {'role': 'Motorcycle'},
    'a12': {'role': 'Motorcycle'},
    'a13': {'role': 'Truck'},
    'a14': {'role': 'Truck'},
    'a15': {'role': 'Truck'},
    'a16': {'role': 'Truck'},
}
ag_names1, agents1 = prepareAgents(ag_names1_)

tool2roles1 = {
    'tool1': set(['Car', 'Drone', 'Motorcycle']),
    'tool2': set(['Car', 'Truck']),
    'tool3': set(['Motorcycle', 'Truck']),
}

# configuration for set random seeds:
seededConf = {
    '1460210294174': {
        'products': {'item6': {'assembled': 'false', 'volume': '15', 'name': 'item6'}, 'item15': {'assembled': 'false', 'volume': '27', 'name': 'item15'}, 'item10': {'items': [{'amount': '1', 'name': 'item0'}, {'amount': '1', 'name': 'item12'}], 'tools': [{'amount': '2', 'name': 'item6'}], 'assembled': 'true', 'volume': '29', 'name': 'item10'}, 'item19': {'items': [{'amount': '2', 'name': 'item14'}], 'tools': [{'amount': '1', 'name': 'item4'}], 'assembled': 'true', 'volume': '34', 'name': 'item19'}, 'item14': {'assembled': 'false', 'volume': '22', 'name': 'item14'}, 'item13': {'items': [{'amount': '2', 'name': 'item0'}, {'amount': '3', 'name': 'item1'}], 'tools': [], 'assembled': 'true', 'volume': '83', 'name': 'item13'}, 'item4': {'items': [{'amount': '2', 'name': 'item15'}], 'tools': [{'amount': '2', 'name': 'item3'}], 'assembled': 'true', 'volume': '33', 'name': 'item4'}, 'item18': {'items': [{'amount': '1', 'name': 'item14'}], 'tools': [], 'assembled': 'true', 'volume': '14', 'name': 'item18'}, 'item2': {'assembled': 'false', 'volume': '26', 'name': 'item2'}, 'item17': {'assembled': 'false', 'volume': '28', 'name': 'item17'}, 'item16': {'assembled': 'false', 'volume': '21', 'name': 'item16'}, 'item7': {'items': [{'amount': '1', 'name': 'item0'}, {'amount': '2', 'name': 'item1'}], 'tools': [], 'assembled': 'true', 'volume': '49', 'name': 'item7'}, 'item12': {'assembled': 'false', 'volume': '14', 'name': 'item12'}, 'item1': {'assembled': 'false', 'volume': '23', 'name': 'item1'}, 'item5': {'items': [{'amount': '3', 'name': 'item12'}], 'tools': [{'amount': '2', 'name': 'item6'}, {'amount': '1', 'name': 'item3'}, {'amount': '3', 'name': 'item4'}], 'assembled': 'true', 'volume': '10', 'name': 'item5'}, 'item0': {'assembled': 'false', 'volume': '23', 'name': 'item0'}, 'item3': {'assembled': 'false', 'volume': '24', 'name': 'item3'}, 'item11': {'items': [{'amount': '2', 'name': 'item8'}], 'tools': [{'amount': '3', 'name': 'item6'}], 'assembled': 'true', 'volume': '1', 'name': 'item11'}, 'item9': {'assembled': 'false', 'volume': '28', 'name': 'item9'}, 'item8': {'items': [{'amount': '3', 'name': 'item0'}], 'tools': [{'amount': '3', 'name': 'item4'}], 'assembled': 'true', 'volume': '9', 'name': 'item8'}},
        'tool2roles': {'item6': {'Motorcycle', 'Truck'}, 'item5': {'Motorcycle', 'Drone'}, 'item19': {'Truck', 'Drone'}, 'item18': {'Drone'}, 'item3': {'Truck'}, 'item4': {'Car'}, 'item9': {'Motorcycle'}, 'item13': {'Truck'}, 'none': set(), 'item16': {'Truck', 'Car'}},
        'first_job': [{'amount': '1', 'name': 'item0'}, {'amount': '1', 'name': 'item9'}, {'amount': '1', 'name': 'item2'}, {'amount': '1', 'name': 'item5'}],
    },
    '1473594087592': {
        'products': {'item8': {'assembled': 'true', 'name': 'item8', 'volume': '135', 'items': [{'name': 'item4', 'amount': '3'}], 'tools': []}, 'item13': {'assembled': 'true', 'name': 'item13', 'volume': '122', 'items': [{'name': 'item8', 'amount': '1'}], 'tools': []}, 'item7': {'assembled': 'true', 'name': 'item7', 'volume': '16', 'items': [{'name': 'item3', 'amount': '2'}], 'tools': []}, 'item5': {'assembled': 'true', 'name': 'item5', 'volume': '40', 'items': [{'name': 'item14', 'amount': '3'}], 'tools': []}, 'item2': {'assembled': 'true', 'name': 'item2', 'volume': '18', 'items': [{'name': 'item0', 'amount': '2'}], 'tools': []}, 'item15': {'assembled': 'true', 'name': 'item15', 'volume': '410', 'items': [{'name': 'item4', 'amount': '3'}, {'name': 'item8', 'amount': '1'}, {'name': 'item12', 'amount': '2'}], 'tools': []}, 'item12': {'assembled': 'true', 'name': 'item12', 'volume': '141', 'items': [{'name': 'item4', 'amount': '3'}], 'tools': [{'name': 'item2', 'amount': '1'}]}, 'item19': {'assembled': 'true', 'name': 'item19', 'volume': '36', 'items': [{'name': 'item0', 'amount': '3'}], 'tools': [{'name': 'item2', 'amount': '1'}, {'name': 'item6', 'amount': '2'}]}, 'item10': {'assembled': 'true', 'name': 'item10', 'volume': '16', 'items': [{'name': 'item4', 'amount': '3'}], 'tools': [{'name': 'item1', 'amount': '2'}]}, 'item3': {'assembled': 'true', 'name': 'item3', 'volume': '12', 'items': [{'name': 'item14', 'amount': '1'}], 'tools': [{'name': 'item2', 'amount': '1'}]}, 'item17': {'assembled': 'true', 'name': 'item17', 'volume': '501', 'items': [{'name': 'item11', 'amount': '2'}, {'name': 'item15', 'amount': '2'}], 'tools': [{'name': 'item2', 'amount': '1'}]}, 'item6': {'assembled': 'true', 'name': 'item6', 'volume': '25', 'items': [{'name': 'item0', 'amount': '1'}, {'name': 'item14', 'amount': '1'}], 'tools': []}, 'item16': {'assembled': 'true', 'name': 'item16', 'volume': '180', 'items': [{'name': 'item3', 'amount': '3'}, {'name': 'item13', 'amount': '1'}, {'name': 'item11', 'amount': '2'}], 'tools': []}, 'item9': {'assembled': 'true', 'name': 'item9', 'volume': '8', 'items': [{'name': 'item3', 'amount': '1'}], 'tools': []}, 'item4': {'assembled': 'true', 'name': 'item4', 'volume': '55', 'items': [{'name': 'item3', 'amount': '3'}, {'name': 'item14', 'amount': '2'}], 'tools': []}, 'item0': {'assembled': 'false', 'name': 'item0', 'volume': '18'}, 'item14': {'assembled': 'false', 'name': 'item14', 'volume': '14'}, 'item18': {'assembled': 'true', 'name': 'item18', 'volume': '1289', 'items': [{'name': 'item17', 'amount': '3'}], 'tools': [{'name': 'item16', 'amount': '1'}, {'name': 'item10', 'amount': '1'}]}, 'item1': {'assembled': 'true', 'name': 'item1', 'volume': '15', 'items': [{'name': 'item14', 'amount': '2'}], 'tools': []}, 'item11': {'assembled': 'true', 'name': 'item11', 'volume': '42', 'items': [{'name': 'item0', 'amount': '2'}, {'name': 'item14', 'amount': '1'}], 'tools': [{'name': 'item10', 'amount': '3'}]}},
        'tool2roles': {'item7': {'Car'}, 'none': set(), 'item16': {'Motorcycle'}, 'item5': {'Motorcycle', 'Truck'}, 'item6': {'Drone'}, 'item2': {'Motorcycle', 'Truck'}, 'item10': {'Motorcycle', 'Truck'}, 'item1': {'Car'}, 'item9': {'Car'}, 'item19': {'Drone', 'Car'}},
        'first_job': [{'name': 'item17', 'amount': '1'}, {'name': 'item13', 'amount': '1'}, {'name': 'item6', 'amount': '1'}, {'name': 'item19', 'amount': '1'}, {'name': 'item12', 'amount': '1'}],
    }
}


class TestRunner(TestCase):
    def test_needed_base_items(self):
        items = {'material1': 2, 'material2': 3, 'material3': 4}
        expected = {'base1': 2 * 5 + 4 * 2 * 5 + 3 * 10, 'base2': 4 * 2, 'base3': 4 * 1}
        actual = Runner.needed_base_items_static(items, products1)
        self.assertDictEqual(expected, actual)

    def test_needed_tools(self):
        item_names = set(['material1', 'material2', 'material3'])
        expected = {'tool1': 1, 'tool2': 1, 'tool3': 1}
        actual = Runner.needed_tools_static(item_names, products1)
        self.assertDictEqual(expected, actual)

    def test_tools_shopping_list(self):
        needed_tools = {'tool2': 2, 'tool3': 3}
        expected = {'a1': {'tool2': 2}, 'a9': {'base1': 24}}
        actual = Runner.tools_shopping_list_static(needed_tools, products1, shops1, agents1, ag_names1, tool2roles1)
        self.assertDictEqual(expected, actual)

    def test_items_shopping_list(self):
        tools_list = {'a1': {'tool2': 2}, 'a5': {'tool1': 3}, 'a9': {'base1': 32}}
        needed_items = {'base1': 80, 'base2': 8, 'base3': 4}
        actual = Runner.items_shopping_list_static(tools_list, needed_items, products1, agents1, ag_names1)
        actual_base_items = defaultdict(int)
        for agent_name, base in actual.items():
            volume = 0
            for base_name, base_amount in base.items():
                recipe = products1[base_name]
                volume += int(recipe['volume']) * base_amount
                actual_base_items[base_name] += base_amount
            self.assertLessEqual(volume, ag_names1[agent_name].remaining_load())
        self.assertDictEqual(needed_items, actual_base_items)
        
    #TODO: test for shopping_list_to_plan?

    def test_assembly_list(self):
        items = [{'name': 'material3', 'amount': '1'}]
        expected = [
            ([('base1', 8)], ('tool3', 1)),
            ([('base1', 10)], ('material1', 2)),
            ([('material1', 2),
              ('base2', 2),
              ('base3', 1)], ('material3', 1))
        ]
        actual = Runner.assembly_list_static(items, products1)
        self.assertListEqual(sorted(expected), sorted(actual))

    def test_assembly_list_alt(self):
        items = [{'name': 'material3', 'amount': '2'}]
        expected = [
            ([('base1', 8)], ('tool3', 1)),
            ([('base1', 20)], ('material1', 4)),
            ([('material1', 4),
              ('base2', 4),
              ('base3', 2)], ('material3', 2))
        ]
        actual = Runner.assembly_list_static(items, products1)
        self.assertListEqual(sorted(expected), sorted(actual))

    def test_assembly_list_tools_amount_max(self):
        # Test that we only generate instructions for assembling the max amount of tools needed at once
        items = [{'name': 'a', 'amount': '8'}]
        expected = [
            ([('b', 8*1), ('c', 8*2)], ('a', 8)),
            ([('d', 8*1*3)], ('b', 8*1)),
            ([('f', 8*2*5)], ('c', 8*2)),
            ([('g', 42)], ('e', 6))
        ]
        actual = Runner.assembly_list_static(items, products2)
        self.assertEqual(sorted(expected), sorted(actual))

    def test_assembly_list_1460210294174(self):
        expected = [
            ([('item12', 3)], ('item5', 1)),
            ([('item15', 6)], ('item4', 3))
        ]
        actual = Runner.assembly_list_static(seededConf['1460210294174']['first_job'], seededConf['1460210294174']['products'])
        self.assertListEqual(sorted(expected), sorted(actual))
        
    def test_assembly_plan(self):
        items = {'material3': 1}
        item_names = set(['material3'])
        items2 = [{'name': 'material3', 'amount': '1'}]
        
        #First, create plan so agents have buy commands in their plan
        needed_base_items = Runner.needed_base_items_static(items, products1)
        needed_tools = Runner.needed_tools_static(item_names, products1)
        tools_shopping_list = Runner.tools_shopping_list_static(needed_tools, products1, shops1, agents1, ag_names1, tool2roles1)
        items_shopping_list = Runner.items_shopping_list_static(tools_shopping_list, needed_base_items, products1, agents1, ag_names1)
        merge_shopping_list = Runner.merge_shopping_lists(tools_shopping_list, items_shopping_list)

        #print("merge_shopping_list=", merge_shopping_list)
        
        #Manually create plan
        plan = {agent_name: [] for agent_name in ag_names1}
        for agent_name, items in merge_shopping_list.items():
            for item_name, amount in items.items():
                plan[agent_name].append(Buy(item=item_name, amount=amount))
    
        
        #update agent plans
        for agent, jobs in plan.items():
            ag_names1[agent].plan += jobs
        
        #Get alist        
        alist = Runner.assembly_list_static(items2, products1)
        #print("test_assembly_plan alist= ", alist)
        
        #End result
        actual = Runner.assembly_plan_static(alist, agents1, products1, getToolNames(products1))
        #print("Actual=", actual)
        self.assertDictEqual({},{})

        # don't influence other tests
        for agent in agents1:
            agent.plan = []

    def test_assembly_plan_alt(self):
        items = [{'name': 'material3', 'amount': '2'}]

        # arbitrary plan for buying items for 2 material3
        # (this is probably not what we generate!)
        for agent in agents1:
            agent.plan = []
        ag_names1['a1'].plan = [Buy(item='tool2', amount=1), Buy(item='base2', amount=4)] # volume: 500/550
        ag_names1['a5'].plan = [Buy(item='tool1', amount=1)] # volume: 10/100
        ag_names1['a9'].plan = [Buy(item='base1', amount=28)] # volume: 280/300
        ag_names1['a13'].plan = [Buy(item='base3', amount=2)] # volume: 1000/3000

        alist = Runner.assembly_list_static(items, products1)
        assembly_plan = Runner.assembly_plan_static(alist, agents1, products1, getToolNames(products1))

        # only a9 has base1 => a9 assembles tool3 (no assistance required)
        # only a9 has base1 and only a5 has tool1 => a9 assembles material1 and a5 assists

        # material3 requires multiple different tools (tool1, tool2, and tool3),
        # it can be assembled by anyone who enough of one the required item types,
        # i.e. a1, a5, a9, or a13.

        # case1: a1 is assembling material3
        case1 = assembly_plan['a1'] == [Assemble(item='material3', amount=2)] and\
                assembly_plan['a5'] == [Assist(who='a9', item='material1', amount=4), Assist(who='a1', item='material3', amount=2)] and\
                assembly_plan['a9'] == [Assemble(item='tool3', amount=1), Assemble(item='material1', amount=4), Assist(who='a1', item='material3', amount=2)] and\
                assembly_plan['a13'] == [Assist(who='a1', item='material3', amount=2)]

        # case2: a5 is assembling material3
        case2 = assembly_plan['a1'] == [Assist(who='a5', item='material3', amount=2)] and\
                assembly_plan['a5'] == [Assist(who='a9', item='material1', amount=4), Assemble(item='material3', amount=2)] and\
                assembly_plan['a9'] == [Assemble(item='tool3', amount=1), Assemble(item='material1', amount=4), Assist(who='a5', item='material3', amount=2)] and\
                assembly_plan['a13'] == [Assist(who='a5', item='material3', amount=2)]

        # case3: a9 is assembling material3
        case3 = assembly_plan['a1'] == [Assist(who='a9', item='material3', amount=2)] and\
                assembly_plan['a5'] == [Assist(who='a9', item='material1', amount=4), Assist(who='a9', item='material3', amount=2)] and\
                assembly_plan['a9'] == [Assemble(item='tool3', amount=1), Assemble(item='material1', amount=4), Assemble(item='material3', amount=2)] and\
                assembly_plan['a13'] == [Assist(who='a9', item='material3', amount=2)]

        # case4: a13 is assembling material3 (i hit this one every time)
        case4 = assembly_plan['a1'] == [Assist(who='a13', item='material3', amount=2)] and\
                assembly_plan['a5'] == [Assist(who='a9', item='material1', amount=4), Assist(who='a13', item='material3', amount=2)] and\
                assembly_plan['a9'] == [Assemble(item='tool3', amount=1), Assemble(item='material1', amount=4), Assist(who='a13', item='material3', amount=2)] and\
                assembly_plan['a13'] == [Assemble(item='material3', amount=2)]

        # assert that only one case is true
        self.assertEqual(1, sum([1 if x else 0 for x in [case1, case2, case3, case4]]))

        # the rest of the agents are not participating
        self.assertEquals([], assembly_plan['a2'])
        self.assertEquals([], assembly_plan['a3'])
        self.assertEquals([], assembly_plan['a4'])
        self.assertEquals([], assembly_plan['a6'])
        self.assertEquals([], assembly_plan['a7'])
        self.assertEquals([], assembly_plan['a8'])
        self.assertEquals([], assembly_plan['a10'])
        self.assertEquals([], assembly_plan['a11'])
        self.assertEquals([], assembly_plan['a12'])
        self.assertEquals([], assembly_plan['a14'])
        self.assertEquals([], assembly_plan['a15'])
        self.assertEquals([], assembly_plan['a16'])

        # don't influence other tests
        for agent in agents1:
            agent.plan = []

    def test_assembly_plan_1460210294174(self):
        # plans for buying items (this is what we generate as of dcf46bf, minus the Goto and Charge instructions)
        for agent in agents1:
            agent.plan = []
        ag_names1['a1'].plan = [Buy(item='item12', amount=3), Buy(item='item9', amount=1), Buy(item='item2', amount=1), Buy(item='item0', amount=1)]
        ag_names1['a4'].plan = [Buy(item='item15', amount=6)]
        ag_names1['a11'].plan = [Buy(item='item6', amount=2)]
        ag_names1['a16'].plan = [Buy(item='item3', amount=2)]

        products = seededConf['1460210294174']['products']
        alist = Runner.assembly_list_static(seededConf['1460210294174']['first_job'], products)
        assembly_plan = Runner.assembly_plan_static(alist, agents1, products, getToolNames(products))

        # assembly tree
        # -------------
        # 1 item0
        # 1 item2
        # 1 item5
        #   3 item12
        #   tool 2 item6
        #   tool 1 item3
        #   tool 3 item4
        #     2 item15
        #     tool 2 item3
        # 1 item9

        # only a4 has item15 => a4 assembles item4 and a16 assists
        # only a1 has item12 => a1 assembles item5 and a4, a11, and a16 assist

        self.assertFalse(all([plan == [] for agent_name, plan in assembly_plan.items()]), "all plans are empty!")

        self.assertEqual([Assemble(item='item5', amount=1)], assembly_plan['a1'])
        self.assertEqual([], assembly_plan['a2'])
        self.assertEqual([], assembly_plan['a3'])
        self.assertEqual([Assemble(item='item4', amount=3), Assist(who='a1', item='item5', amount=1)], assembly_plan['a4'])
        self.assertEqual([], assembly_plan['a5'])
        self.assertEqual([], assembly_plan['a6'])
        self.assertEqual([], assembly_plan['a7'])
        self.assertEqual([], assembly_plan['a8'])
        self.assertEqual([], assembly_plan['a9'])
        self.assertEqual([], assembly_plan['a10'])
        self.assertEqual([Assist(who='a1', item='item5', amount=1)], assembly_plan['a11'])
        self.assertEqual([], assembly_plan['a12'])
        self.assertEqual([], assembly_plan['a13'])
        self.assertEqual([], assembly_plan['a14'])
        self.assertEqual([], assembly_plan['a15'])
        self.assertEqual([Assist(who='a4', item='item4', amount=3), Assist(who='a1', item='item5', amount=1)], assembly_plan['a16'])

        for agent in agents1:
            agent.plan = []

    def test_delivery_plans(self):
        #Make job
        job = {'end': '200', 'begin': '0', 'id': 'job_id1', 'maxBid': 1, 'storage': 'storage1', 'items': [{'name': 'material2', 'amount': '1'}], 'fine': '1'}
        
        #Assign items to agents
        #print("Giving item to ", agents1[0].name)
        agents1[0].info['items'] = [{'name': 'material2', 'amount': '1'}]
        
        #Redefine the steps function since it will crash otherwise.
        def steps(x):
            #return sum(p.steps for p in x.plan_to(self.storages[delivery_location]))
            return randrange(100)
        
        actual = Runner.delivery_plans_static(agents1, ag_names1, products1, steps, job)
        print("actual= ", actual)
        
        #No assert here since it's impossible to predict race-conditions (the order of the list). The actual looks good though.
        
if __name__ == '__main__':
    unittest.main()