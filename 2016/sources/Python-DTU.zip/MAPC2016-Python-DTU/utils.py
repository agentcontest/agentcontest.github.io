from math import sqrt
from typing import TypeVar, Union, List, Set, Dict, Any, Callable, Iterator
import xml.etree.cElementTree as eT
import xml.dom.minidom as minidom # type: ignore

T = TypeVar('T')
K = TypeVar('K')
V = TypeVar('V')


def euclidean_dist(a: Dict[str, Any], b: Dict[str, Any]) -> float:
    """
    Takes two dicts with keys `lat` and `lon` and returns the Euclidean distance between the two.
    """
    delta_lat = float(a['lat']) - float(b['lat'])
    delta_lon = float(a['lon']) - float(b['lon'])

    return sqrt(delta_lat * delta_lat + delta_lon * delta_lon)


def drone_route_length(dist: float) -> float:
    """
    Given a distance as returned by euclidean_dist above, returns route length for the drone.
    """
    return 0.339417653749553 + 998.334415802130 * dist


def route_length(dist: float) -> float:
    """
    Given a distance as returned by euclidean_dist, returns an approximate route length. The approximation is good.
    """
    return 2.48907584992417 + 1151.52601624103 * dist


def update_dict(dic: Dict[K, V], key: K, value: V, default: V, merge: Callable[[V, V], V]) -> None:
    """
    If `key` exists in the dict, call merge on the corresponding value and the given value to find the new value.
    If `key` doesn't exist, the new value is given by merging the given value and the default value.
    """
    if key in dic:
        dic[key] = merge(dic[key], value)
    else:
        dic[key] = merge(default, value)

def merge_dicts(d1: Dict[K, V], d2: Dict[K, V], merge: Callable[[V, V], V]) -> Dict[K, V]:
    d3 = {}
    for k1, v1 in d1.items():
        d3[k1] = v1
    for k2, v2 in d2.items():
        if k2 in d3:
            d3[k2] = merge(d3[k2], v2)
        else:
            d3[k2] = v2
    return d3

def minkey(ts: Union[List[T], Set[T], Iterator[T]], key: Callable[[T], Union[int, float]]) -> T:
    """ mypy doesn't understand the builtin min, simply finds the minimum value as measured by `key` """
    #for i in ts:
    #    print("TS:", i)
    #print("TSall:", ts)
    #print("key:", key)
    return min(ts, key=key)  # type: ignore

def pretty_print(el: eT.Element):
    """
    pretty print element xml element
    """
    doc = minidom.parseString(eT.tostring(el, 'utf-8'))
    print('\n'.join([line for line in doc.toprettyxml(indent=' '*2).split('\n') if line.strip()]))
