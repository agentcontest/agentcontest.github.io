import argparse
import time
import sys
import itertools
import operator
from multiprocessing import Queue
import utils
import xml.etree.cElementTree as eT
from global_vars import *
from comm import Communicator, Agent, Attrib, Plan, Command
from commands import *
import random
import functools
from collections import defaultdict

from typing import Dict, List, Tuple, Any, Set, Union, cast

#pretty xml
from xml.dom.minidom import *

Plans = Dict[str, Plan]
ShopList = Dict[str, Dict[str, int]]


class Runner:

    def __init__(self, prefix: str) -> None:
        self.prefix = prefix
        self.ag_names = {}  # type: Dict[str, Agent]
        self.step = 0
        self.sim_id = -1
        self.initialized = 0
        self.team_name = ''
        self.runtime = 0
        self.money = 0
        self.sim_info = None
        self.total_shops = 0

        self.buffer = ''
        self.disabled = False
        self.q = Queue()

        self.agents = []  # type: List[Agent]
        self.percepts = []  # type: List[Tuple[Agent, Any]]
        self.entities = {}  # type: Dict[Agent, Attrib]
        self.products = {}  # type: Dict[str, Attrib]

        # Shops have an `items` key with extra information if any agent is nearby.
        # charging_stations have an extra key 'q_size' if any agent is nearby.
        self.charging_stations = {}  # type: Dict[str, Attrib]
        self.dump_locations = {}  # type: Dict[str, Attrib]
        self.shops = {}  # type: Dict[str, Attrib]
        self.storages = {}  # type: Dict[str, Attrib]
        self.workshops = {}  # type: Dict[str, Attrib]

        # id's for the jobs this team has taken and posted respectively
        self.jobs_taken = []  # type: List[str]
        self.jobs_posted = []  # type: List[str]
        self.jobs_accepted = [] # type: List[Dict[str, Attrib]] # A list of the jobs the team is currently completing.
        self.jobs_bidded_on = [] # type: List[Dict[str, Attrib]] #Used to keep track of the jobs we have bidded on but not won yet
        self.jobs_completed = [] # type: List[Dict[str, Attrib]] # A list of the jobs the team has completed

        self.auction_jobs = {}  # type: Dict[str, Attrib]
        self.priced_jobs = {}  # type: Dict[str, Attrib]

    def initialize(self) -> None:
        self.initialized = 0
        self.team_name = ''
        self.runtime = 0

        self.charging_stations = {}
        self.dump_locations = {}
        self.shops = {}
        self.storages = {}
        self.workshops = {}

        self.auction_jobs = {}
        self.priced_jobs = {}
        self.jobs_accepted = []
        self.jobs_bidded_on = []
        self.jobs_completed = []

        # build a set of item names that are only used as tools
        # the generator will never use an item as both a consumed item and tool item
        self.tool_names = set()
        for item_name, recipe in self.products.items():
            if not 'tools' in recipe:
                continue
            for tool in recipe['tools']:
                self.tool_names.add(tool['name'])

    def empty_queue(self) -> None:
        while True:
            try:
                agent, message = self.q.get_nowait()  # type: ignore
            except Exception as _:
                break
            self.handle(agent, message)

    def wait(self) -> None:
        self.empty_queue()
        if self.initialized < NUM_OF_AGENTS:
            while self.initialized < NUM_OF_AGENTS:
                self.empty_queue()

        while len(self.percepts) < NUM_OF_AGENTS:
            self.empty_queue()

    @staticmethod
    def timeit(method, *kwargs):
        s = time.time()
        res = method(*kwargs)
        print(str(method.__name__), time.time() - s)
        return res

    def handle(self, ag: str, message: eT.Element) -> None:
        agent = self.ag_names[ag]
        typ = message.get('type')
        if 'auth-response' in typ:
            if not message.find('authentication').attrib['result'] == 'ok':
                raise Exception('Authentication failed')
            print(agent.name, 'authorized')
        elif 'sim-end' in typ:
            self.buffer = ''
            self.disabled = False
            sim_result = message.find('sim-result').attrib
            print('ranking:', sim_result['ranking'], 'score:', sim_result['score'])
        elif 'bye' in typ:
            print('simulation over, exiting')
            sys.exit(0)
        elif 'sim-start' in typ:
            self.sim_info = message.find('simulation')
            if int(self.sim_info.attrib['id']) != self.sim_id:
                self.sim_id = int(self.sim_info.attrib['id'])

                # Extract "recipes" for products
                for pr in self.sim_info.find('products'):
                    prod = pr.attrib
                    if prod['assembled'] == 'true':
                        prod.update(items=[item.attrib for item in pr.find('consumed')])
                        prod.update(tools=[tool.attrib for tool in pr.find('tools')])
                    self.products[prod['name']] = prod

                self.initialize()
                print('preparing for new simulation')
            agent.initialize(self.sim_info)
            self.initialized += 1
        else:
            self.percepts.append((agent, message.find('perception')))

    def handle_percepts(self) -> None:
        """
        Reads the percepts the agents have received from the server and parses them into usable Python data structures.
        """
        for iteration, (agent, p) in enumerate(self.percepts):
            info = p.find('self')
            info_attrib = info.attrib
            info_attrib['items'] = [it.attrib for it in info.find('items')]
            info_attrib['route'] = [it.attrib for it in info.find('route') or []]
            agent.info = info_attrib
            agent.id = p.get('id')
            facs = p.find('facilities')

            charging_stations = facs.findall('chargingStation')
            shops = facs.findall('shop')

            # Extract info from team-tag
            team_info = p.find('team')
            self.money = int(team_info.attrib['money'])
            #print("jobs=", team_info.find('jobs-taken').attrib)
            self.jobs_taken = [job.get('id') for job in team_info.find('jobs-taken').findall('job')]
            self.jobs_posted = [job.get('id') for job in team_info.find('jobs-posted').findall('job')]

            if iteration == 0:
                # print percept as xml
                #utils.pretty_print(p)

                self.step = int(p.find('simulation').get('step'))


                # Entities
                self.entities = {
                    ent.attrib['name']: ent.attrib for ent in p.find('entities').findall('entity')}

                # Facilities

                # Update info from last step, there can be details we want to
                # remember
                self.charging_stations.update({cs.get('name'): cs.attrib for cs in charging_stations})
                self.shops.update({sh.get('name'): sh.attrib for sh in shops})
                for sh in self.shops:
                    self.shops[sh]['items'] = {}

                self.dump_locations = {dl.get('name'): dl.attrib for dl in facs.findall('dumpLocation')}

                self.storages = {st.get('name'): st.attrib for st in facs.findall('storage')}

                self.workshops = {ws.get('name'): ws.attrib for ws in facs.findall('workshop')}

                # Available jobs
                jobs = p.find('jobs')

                for pj in jobs.findall('pricedJob'):
                    attrib = pj.attrib
                    attrib.update(items=[it.attrib for it in pj.find('items')])
                    self.priced_jobs[pj.get('id')] = attrib

                for aj in jobs.findall('auctionJob'):
                    attrib = aj.attrib
                    attrib.update(items=[it.attrib for it in aj.find('items')])
                    self.auction_jobs[aj.get('id')] = attrib

                #Update Jobs_accepted with the new auction jobs we've won, if any
                for job in self.jobs_taken:
                    addJob = True
                    for acceptedJob in self.jobs_accepted:
                        if acceptedJob.get('id') == job:
                            addJob = False
                    for completedJob in self.jobs_completed:
                        if completedJob.get('id') == job:
                            addJob = False
                    if addJob:
                        self.jobs_accepted.append(self.auction_jobs.get(job))
                        for biddedJob in self.jobs_bidded_on:
                            if biddedJob['id'] == self.auction_jobs.get(job)['id']:
                                self.jobs_bidded_on.remove(biddedJob)

                #print(self.jobs_taken)

            # If any agent has extra info about the charging station, share it:
            for cs in charging_stations:
                info = cs.find('info')
                if info is not None:
                    self.charging_stations[
                        cs.get('name')]['q_size'] = info.get('qSize')

            # If any agent has info about a shop's items, share it:
            for shop in shops:
                items = shop.findall('item')
                for it in items or []:
                    info = it.find('info')
                    if info is not None:
                        self.shops[shop.get('name')]['items'][
                            it.get('name')] = info.attrib

            for x in self.agents:
                x.charging_stations = self.charging_stations
                x.dump_locations = self.dump_locations
                x.shops = self.shops
                x.storages = self.storages
                x.workshops = self.workshops

        self.percepts = []

    def start(self) -> None:
        self.q = Queue()
        self.agents = [Agent( self.prefix + str(suffix), self.q, Queue() ) for suffix in range(1, NUM_OF_AGENTS + 1)]
        for a in self.agents:
            self.ag_names[a.name] = a

        for a in self.agents:
            a.ag_names = self.ag_names

        for a in self.agents:
            a.comm.start()  # type: ignore
            time.sleep(0.01)

        SHOP = 'shop'

        order = [SHOP, BUY, ASSEMBLE, DELIVER_JOB]

        while True:
            #print("items", self.agents[0].info)
            start = time.time()
            self.wait()  # self.timeit(self.wait)
            self.handle_percepts()  # self.timeit(self.handle_percepts)
            self.runtime += 1

            #print('auctionJobs=', self.auction_jobs)
            #print('jobs_taken=', self.auction_jobs)

            for x in self.agents:
                x.handle_last_action()

            if self.runtime == 1:
                order = [SHOP, BUY, ASSEMBLE, DELIVER_JOB]
                for x in self.agents:
                    x.plan = []
                    x.current_index = 0

            if order and SHOP in order[0]:
                print('moving to shops')
                plan = self.move_to_shops_plan()
                self.update_agent_plans(plan)
                print('PLAN:', plan)

                del order[0]

            #We want to bid on auction jobs if we know what all the shops sells as well as having less than two job at the same time.
            amountOfJobs = len(self.jobs_accepted)# + len(self.priced_jobs)
            amountOfBiddedJobs = len(self.jobs_bidded_on)
            print('amountOfJobs=', amountOfJobs)
            #print('amountOfBiddedJobs=', amountOfBiddedJobs)
            #print('takenJobs=', self.jobs_taken)
            #print('auctionJobs=', self.auction_jobs)
            #print('jobs_accepted=', self.jobs_accepted)

            #TODO: Take price of products into account when calculating "profit" on jobs
            if amountOfJobs + amountOfBiddedJobs < MAXIMUM_CONCURRENT_JOBS:
                amountOfShops = 0
                for agent in self.ag_names:
                    facil = self.ag_names[agent].info['inFacility']
                    totalStepsInSim = int(self.ag_names[agent].sim_info.attrib['steps'])
                    if facil.startswith('shop'):
                        shop = self.shops[facil]
                        #length += len(shop['items'])
                        if len(shop['items']) > 0:
                            amountOfShops += 1
                if amountOfShops >= len(self.shops) and totalStepsInSim - STEPS_NEEDED_TO_COMPLETE_JOB > self.step:
                    wantJob = True
                else:
                    wantJob = False
            else:
                wantJob = False


            if order:
                if wantJob and (self.auction_jobs or self.priced_jobs) and (len(self.auction_jobs) > len(self.jobs_accepted) + len(self.jobs_bidded_on)):
                    print('attempting to get job')

                    #Find priced job with highest payout
                    pricedJobToBuy = None
                    for job in self.priced_jobs.values():
                        accepted = job in self.jobs_accepted
                        posted_by_us = job['id'] in self.jobs_posted
                        bidded_on = job in self.jobs_bidded_on
                        completed = job in self.jobs_completed
                        if not accepted and not posted_by_us and not bidded_on and not completed:
                            if pricedJobToBuy != None and job['reward'] > pricedJobToBuy['reward']:
                                pricedJobToBuy = job
                            elif pricedJobToBuy == None:
                                pricedJobToBuy = job

                    #Find Auction job
                    jobToBidOn = None
                    for job in self.auction_jobs.values():
                        accepted = job in self.jobs_accepted
                        posted_by_us = job['id'] in self.jobs_posted
                        bidded_on = job in self.jobs_bidded_on
                        completed = job in self.jobs_completed
                        if not accepted and not posted_by_us and not bidded_on and not completed:
                            if jobToBidOn != None and job['maxbid'] > jobToBidOn['maxbid']:
                                jobToBidOn = job
                            elif jobToBidOn:
                                jobToBidOn = job

                    if jobToBidOn != None or pricedJobToBuy != None:
                        #Find job with best payout
                        if jobToBidOn != None and pricedJobToBuy != None:
                            if jobToBidOn['maxBid'] > pricedJobToBuy['reward']:
                                jobWanted = "auction"
                            else:
                                jobWanted = "priced"
                        elif jobToBidOn != None:
                            #Only auction job available
                            jobWanted = "auction"
                        else:
                            #Only priced job available
                            jobWanted = "priced"

                        #Get the chosen job
                        if jobWanted == "auction":
                            #Auction job is best. Go bid
                            for agent in self.agents:
                                if agent.done:
                                    print('bidding on job: ' + jobToBidOn['id'])
                                    plan = self.bidOnJob_to_plan(agent, jobToBidOn)
                                    self.update_agent_plans(plan)
                                    self.jobs_bidded_on.append(jobToBidOn)
                                    wantJob = False
                                    break
                        else:
                            #Priced job is best. Go get
                            addJob = True
                            for acceptedJob in self.jobs_accepted:
                                if acceptedJob.get('id') == pricedJobToBuy:
                                    addJob = False
                            for completedJob in self.jobs_completed:
                                if completedJob.get('id') == pricedJobToBuy:
                                    addJob = False
                            if addJob:
                                print('buying priced job: ' + pricedJobToBuy['id'])
                                self.jobs_accepted.append(pricedJobToBuy)
                    else:
                        print('no jobs available')

            #If we are delivering job, check if we have other jobs, then start completing them
            #Only start if we have enough steps left to complete it
            if not order and (self.priced_jobs or self.auction_jobs) and int(self.sim_info.attrib['steps']) - self.step > STEPS_NEEDED_TO_COMPLETE_JOB:
                print('resetting order')
                order = [SHOP, BUY, ASSEMBLE, DELIVER_JOB]
            elif not order:
                print('no more jobs or too little time')

            if order and BUY in order[0]:
                # We're ready to plan buying, if there is an agent at every shop
                unique_agent_shops = {x.info['inFacility'] for x in self.agents if x.info['inFacility'].startswith('shop')}

                done = len(self.shops) == len(unique_agent_shops)
            elif order and ASSEMBLE in order[0]:
                # We can plan assembly immediately after buying.
                done = True
            else:
                done = all([agent.done for agent in self.agents])

            if done:
                if not order:
                    print('skipping')
                elif BUY in order[0] and len(self.jobs_accepted) > 0:
                    print('buying')
                    #job = list(self.priced_jobs.values())[0]
                    job = self.jobs_accepted[0]
                    print("now completing:", job['id'])
                    #print('jobAct=', self.jobs_accepted[0])
                    #print("products_lol", self.products)
                    #print('job:', job)
                    item_names = {item['name'] for item in job['items']}
                    needed_tools = self.needed_tools(item_names)
                    print('needed tools: ', needed_tools)
                    tools_list = self.tools_shopping_list(needed_tools)
                    print('tools shopping list:', tools_list)
                    #print('items:', job['items'])
                    items = {item['name']: int(item['amount']) for item in job['items']}
                    needed_items = self.needed_base_items(items)
                    print("needed items:", needed_items)
                    items_list = self.items_shopping_list(tools_list, needed_items)
                    print('items shoping list:', items_list)
                    merged_list = self.merge_shopping_lists(tools_list, items_list)
                    print('merge:', merged_list)
                    plan = self.shopping_list_to_plan(merged_list)
                    self.update_agent_plans(plan)
                    #self.jobs_accepted.append(job)
                    print('PLAN:', plan)

                    del order[0]
                elif ASSEMBLE in order[0]:
                    print('assembling')
                    #alist = self.assembly_list(list(self.priced_jobs.values())[0]['items'])
                    alist = self.assembly_list(self.jobs_accepted[0]['items'])
                    plan = self.assembly_plan(alist)
                    self.update_agent_plans(plan)
                    print('PLAN:', plan)

                    del order[0]
                elif DELIVER_JOB in order[0]:
                    print('delivering')
                    #jobs_accepted.del(0)
                    #plan = self.delivery_plans(self.priced_jobs['job2'])
                    plan = self.delivery_plans(self.jobs_accepted[0])
                    self.update_agent_plans(plan)
                    self.jobs_completed.append(self.jobs_accepted[0])
                    del self.jobs_accepted[0]
                    print('PLAN:', plan)

                    del order[0]
                else:
                    print('unhandled order:', order[0])
                    # nothing else to do, let's post a job :)
                    if len(self.jobs_posted) == 0:
                        print('posting job')
                        plan = self.post_job_plan(random.choice(self.agents))
                        self.update_agent_plans(plan)

            for x in self.agents:
                x.execute_plan()

            print('step#:', self.step, 'since con:', self.runtime,"round time:", time.time() - start)
            print()

    def update_agent_plans(self, plan: Plans) -> None:
        """
        Appends the given plans to the agents' current ones.
        """
        for agent, jobs in plan.items():
            self.ag_names[agent].add_to_plan(jobs)

    @staticmethod
    def delivery_plans_static(selfAgents, selfAgnames, selfProducts, steps, job: Dict[str, Any]) -> Plans:
        """
        Given a job, returns a plan for the fastest way to deliver the needed items.
        """
        delivery_location = job['storage']

        # Set of agents that has items to deliver
        has_it = {}  # type: Dict[str, List[Tuple[str, int]]]

        for agent in selfAgents:
            agent_item_names = [item['name']
                                for item in agent.info['items']]  # type: List[str]

            #print("agent_item_names= ", agent_item_names)

            for item in job['items']:
                #print("item= ", item)
                if item['name'] in agent_item_names:
                    #print("Agent has item")
                    if agent.name not in has_it:
                        has_it[agent.name] = []
                    has_it[agent.name].append(
                        (item['name'], int(item['amount'])))

        #print("has_it= ", str(has_it))

        plan = {agent.name: []
                for agent in selfAgents}  # type: Dict[str, List[Command]]

        for ag, items in has_it.items():
            location = selfAgnames[ag].info['inFacility']
            if location == 'none':
                print("location is none")
                plan[ag].append(Deliver(id=job['id'], where = delivery_location))
            else:
                volume = sum(
                    int(selfProducts[item]['volume']) * amount for item, amount in items)
                possible = {x for x in selfAgents if x.info['inFacility'] == location
                            if x.remaining_load() > volume}  # type: Set[Agent]

                #def steps(x):
                #    return sum(p.steps for p in x.plan_to(self.storages[delivery_location]))
                #    #return 30

                fastest = utils.minkey(possible, steps)
                if fastest.name == ag:
                    plan[ag].append(Deliver(id=job['id'], where = delivery_location))
                else:
                    for item, amount in items:
                        plan[ag].insert(0, Give(who=fastest.name, item=item, amount=amount))
                        plan[fastest.name].insert(0, Receive(item=item, amount=amount))

                    plan[fastest.name].append(Deliver(id=job['id'], where = delivery_location))

        return {agent: cmds for agent, cmds in plan.items()}

    def delivery_plans(self, job: Dict[str, Any]) -> Plans:
        delivery_location = job['storage']

        def steps(x):
            return sum(p.steps for p in x.plan_to(self.storages[delivery_location]))

        return self.delivery_plans_static(self.agents, self.ag_names, self.products, steps, job)


    def shopping_list_to_plan(self, shop_list: ShopList) -> Plans:

        """
        Turns a shopping list into executable plans for the agents, essentially Buy commands.

        TODO: Currently when an agent needs to buy items and they are not in the shop that the agent is currently in, it fails and does not make a plan for that item/tool. Allow to plan for agents to move to different shops and buy it there.

        """
        def items_in_stock(items, shop) -> bool:
            for item_name, required_amount in items.items():
                item = shop['items'].get(item_name)
                if item is None:
                    return False
                if int(item['amount']) < required_amount:
                    return False
            return True

        def cost(shop) -> float:
            return 0 # TODO: Return cost (based on a combination of item cost and distance to shop?)

        plan = {agent_name: [] for agent_name in self.ag_names}

        for agent_name, items in shop_list.items():
            agent = self.ag_names[agent_name]
            facility = agent.info['inFacility']
            if not facility.startswith('shop'):
                # Agent is not at a shop
                # Move to a shop that has required items in stock
                applicable_shops = filter(functools.partial(items_in_stock, items), list(self.shops.values())) #This thing is sometimes empty!
                applicable_shops = list(applicable_shops)
                #empty = not any(True for _ in applicable_shops)
                if not applicable_shops:
                    print('WARNING: no shops have required items in stock')
                    break
                #for i in applicable_shops:
                #    print("appShop:", i)
                #print("appShops:", applicable_shops)
                shop = utils.minkey(applicable_shops, cost)
                plan[agent_name] += agent.plan_to(shop)


            # Buy required items
            for item_name, amount in items.items():
                plan[agent_name].append(Buy(item=item_name, amount=amount))

        return plan

    def bidOnJob_to_plan(self, chosenAgent: Agent, job: Dict[str, Any]) -> Plans:
        """
        Makes an agent bid on a plan. Chooses an agent that is otherwise going to skip (i.e. is done with current plan)
        Does not affect other agents (possible to create plan for only one agent?)
        """
        plan = {agent: [] for agent in self.ag_names}  # type: Plans
        #print('job=', int(job['maxBid']))
        #Price for the job. Calculate it (idea for starting bid: cost of materials x 3)
        #Or just use maxBid even though we shouldn't know it.
        price = int(job['maxBid']) - 2 #This reduction in price is explained in the report
        #print('merged_list=', merged_list)
        #print('self.shops=', self.shops)
        #for agent, items in merged_list.items():
        #    for item, amount in items.items():
        #        print('item=', item)
        #        print('amount=', amount)
                #price += self.shops
        plan[chosenAgent.name].append(Bid_for_job(job=job['id'], price=price))
        return plan

    def post_job_plan(self, postingAgent: Agent) -> Plans:
        plan = {agent: [] for agent in self.ag_names} # type: Plans
        storage = random.choice(list(self.storages.keys()))
        items = {} # type: Dict[str, int]
        for i in range(0, random.randint(1,3)):
            items[random.choice(list(self.products.keys()))] = random.randint(1, 10)
        job = Post_auction_job(max_price=500, fine=200, auction_steps=10, active_steps=100, storage=storage, items=items)
        plan[postingAgent.name].append(job)
        return plan

    @staticmethod
    def merge_shopping_lists(list1: ShopList, list2: ShopList) -> ShopList:
        """
        Takes two shopping lists and merges them into one.
        Note: Relies on the fact, that items_shopping_list takes the tools_shopping_list into account
        to be valid with regards to volume.
        """
        out = {agent: items for agent, items in list1.items()}
        for agent, items in list2.items():
            if agent not in out:
                out[agent] = {}

            for item, amount in items.items():
                if item not in out[agent]:
                    out[agent][item] = 0
                out[agent][item] += amount

        return out

    def move_to_shops_plan(self) -> Plans:
        """
        This method computes plans for placing agents on shops
        by repeatedly choosing the agent closest to each shop.
        Excess agents are not planned for.
        """
        def cost_of_plan(shop_name: str, agent_name: str) -> float:
            total = 0.0
            for cmd in self.ag_names[agent_name].plan_to(self.shops[shop_name]):
                if isinstance(cmd, Goto) or isinstance(cmd, Charge):
                    total += cmd.steps
            return total

        plans = {}
        agents = list(self.ag_names.keys())

        for shop in self.shops:
            if agents == []:
                break
            cheapest_agent = utils.minkey(agents, functools.partial(cost_of_plan, shop))
            agents.remove(cheapest_agent)
            plans[cheapest_agent] = self.ag_names[cheapest_agent].plan_to(self.shops[shop])

        # move remaining agents to nearest shops as well (in a futile attempt to fix buying of tools...)
        for agent_name in agents:
            cheapest_shop = utils.minkey(self.shops, functools.partial(cost_of_plan, agent_name=agent_name))
            plans[agent_name] = self.ag_names[agent_name].plan_to(self.shops[cheapest_shop])

        return plans

    @staticmethod
    def assembly_list_static(items: List[Dict[str, str]], products: Dict[str, Any]) -> List[Tuple[List[Tuple[str, int]], Tuple[str, int]]]:
        """
        Takes a list of items and splits it out into a list of assembly instructions
        Each assembly instruction is a 2-tuple where the first element is the list of consumed items (name and amount),
        and the second element is the produced item (name and amount)
        """
        instructions = Runner.assembly_list_rec_static(items, products)

        # Handle tools separately
        # We want instructions for assembling the maximum number of tools needed at once, not the sum of tools needed in total
        # Assumes that tools do not require tools in assembly
        item_names = {item['name'] for item in items}
        needed_tools = Runner.needed_tools_static(item_names, products)
        tool_items = [{'name': name, 'amount': str(amount)} for name, amount in needed_tools.items()]
        tool_instructions = Runner.assembly_list_rec_static(tool_items, products)

        return instructions + tool_instructions

    @staticmethod
    def assembly_list_rec_static(items: List[Dict[str, str]], products: Dict[str, Any]) -> Dict[Tuple[str, int], List[Tuple[str, int]]]:
        instructions = []

        for item in items:
            name = item['name']
            amount = 1
            if 'amount' in item:
                amount = int(item['amount'])

            recipe = products[item['name']]
            if not 'items' in recipe:
                continue

            new_instruction = ([], (name, amount))
            for consumed in recipe['items']:
                name_and_amount = (consumed['name'], int(consumed['amount']) * amount)
                new_instruction[0].append(name_and_amount)
            instructions.append(new_instruction)

            for instruction in Runner.assembly_list_rec_static(recipe['items'], products):
                consumed_items = [(consumed_name, consumed_amount * amount) for (consumed_name, consumed_amount) in instruction[0]]
                produced_item = (instruction[1][0], instruction[1][1] * amount)
                instructions.append((consumed_items, produced_item))

        return instructions

    def assembly_list(self, items: List[Dict[str, str]]) -> Dict[Tuple[str, int], Tuple[str, int]]:
        return self.assembly_list_static(items, self.products)

    def assembly_plan(self, alist: Dict[Tuple[str, int], Tuple[str, int]]) -> Plans:
        return self.assembly_plan_static(alist, self.agents, self.products, self.tool_names)

    @staticmethod
    def assembly_plan_static(alist: Dict[Tuple[str, int], List[Tuple[str, int]]], selfAgents, selfProducts, selfToolNames) -> Plans:
        """
        Takes an assembly list and returns plans for which agents assemble what based on what they've bought
        and are going to buy.
        """
        agent_items = {}  # type: Dict[str, List[Dict[str, str]]]
        for x in selfAgents:
            agent_items[x.name] = []
            for cmd in x.plan:
                if isinstance(cmd, Buy):
                    agent_items[x.name].append( {'name': cmd.item, 'amount': str(cmd.amount)})

        # Distribute among agents
        # type: Dict[str, List[Tuple[str, int]]]
        dist = {agent.name: [] for agent in selfAgents}

        for agent in selfAgents:
            for item in agent_items[agent.name]:
                item_name = item['name']

                for index, instruction in enumerate(alist):
                    if instruction is None:
                        continue # instruction has already been assigned

                    item_amount = int(item['amount']) # read item amount here as it might have changed

                    (consumed_items, produced_item) = instruction
                    for (consumed_name, consumed_amount) in consumed_items:
                        if item_name != consumed_name:
                            continue # item names don't match

                        if item_amount < consumed_amount:
                            continue # agent doesn't have enough of required item

                        # amounts must match exactly or remainder must occur exactly in different instruction
                        if item_amount != consumed_amount:
                            remainder = (consumed_name, item_amount - consumed_amount)
                            remainder_found = False
                            for index2, instruction2 in enumerate(alist):
                                if index == index2:
                                    continue # skip currently processed instruction

                                if instruction2 is None:
                                    continue # instruction has already been assigned

                                (consumed_items2, _) = instruction2
                                if remainder in consumed_items2:
                                    remainder_found = True
                                    break

                            if not remainder_found:
                                continue # amounts did not match and remainder was not found

                        # remove consumed items from agent inventory
                        # TODO: yikes.. a dict would be better, but this variable is also used further down
                        for item2 in agent_items[agent.name]:
                            if item2['name'] == item_name:
                                item2['amount'] = str(item_amount - consumed_amount)

                        dist[agent.name].append(produced_item)  # assign instruction to agent
                        alist[index] = None # mark instruction as assigned
                        break # move on to next instruction

        # # Old (but refactored) logic responsible for distributing assembly instructions to agents
        # for x in selfAgents:
        #     for it in agent_items[x.name]:
        #         name = it['name']
        #         amount = int(it['amount'])
        #
        #         for key in list(alist.keys()):
        #             (a_name, a_amount) = key
        #             name_matches = a_name == name
        #             amount_sufficient = a_amount <= amount
        #             amount_matches = amount == a_amount
        #             remainder_handled_later = (a_name, amount - a_amount) in alist
        #
        #             if name_matches and amount_sufficient and (amount_matches or remainder_handled_later):
        #                 # extract and assign one instruction
        #                 v = alist[key].pop()
        #                 dist[x.name].append(v)
        #                 # remove entry when list is empty
        #                 if alist[key] == []:
        #                     del alist[key]

        # Coordinate, tools, materials
        new_dist = {agent: [Assemble(item=item, amount=amount) for item, amount in items]
                    for agent, items in dist.items()}  # type: Dict[str, List[Union[Assist, Assemble]]]

        for agent, items in dist.items():
            for (item, amount) in items:
                needed_tools = selfProducts[item]['tools']
                needed_items = selfProducts[item]['items']

                for tool in needed_tools:
                    tool_name = tool['name']
                    tool_amount = tool['amount']

                    for assist in selfAgents:
                        if assist.name == agent:
                            continue

                        # doesn't take items consumed by assembly into account,
                        # because tools aren't consumed

                        soon_assembled = [{'name': name, 'amount': str(amount)} for name, amount in dist[assist.name]]
                        assist_items = soon_assembled + agent_items[assist.name]
                        can_assist = False
                        for assist_item in assist_items:
                            if assist_item['name'] == tool_name and assist_item['amount'] >= tool_amount:
                                can_assist = True
                                break

                        if can_assist:
                            if Assist(who=agent, item=item, amount=amount) not in new_dist[assist.name]:
                                new_dist[assist.name].append(Assist(who=agent, item=item, amount=amount))
                                break

                for needed in needed_items:
                    has_it_self = False
                    for has in agent_items[agent]:
                        if needed['name'] == has['name'] and amount * int(needed['amount']) <= int(has['amount']):
                            has_it_self = True

                    if has_it_self:
                        continue

                    for assist in selfAgents:
                        if assist.name == agent:
                            continue

                        soon_assembled = [{'name': name, 'amount': str(amount)} for name, amount in dist[assist.name]]
                        assist_items = soon_assembled + agent_items[assist.name]

                        # TODO: doesn't take items consumed by assembly into account, but probably should
                        for has in assist_items:
                            if needed['name'] == has['name'] and amount * int(needed['amount']) <= int(has['amount']) \
                                    and Assist(who=agent, item=item, amount=amount) not in new_dist[assist.name]:
                                new_dist[assist.name].append(Assist(who=agent, item=item, amount=amount))
                                break

        # Note: This should probably be a topological sort based on item
        # dependencies, but this seems to work for now
        def keyfn(job: Union[Assist, Assemble]) -> int:
            if isinstance(job, Assist):
                return keyfn(Assemble(item=job.item, amount=job.amount))
            elif job.item in selfToolNames:
                return 0
            elif 'tools' not in selfProducts[job.item]:
                return 1
            elif all(map(lambda a: selfProducts[a['name']]['assembled'] == 'false', selfProducts[job.item]['items'])):
                return 2
            else:
                return 3

        for jobs in new_dist.values():
            jobs.sort(key=keyfn)

        return cast(Plans, new_dist)

    def items_shopping_list(self, tools_list: ShopList, needed_items: Dict[str, int]) -> ShopList:
        return self.items_shopping_list_static(tools_list, needed_items, self.products, self.agents, self.ag_names)

    @staticmethod
    def items_shopping_list_static(tools_shopping_list: ShopList, needed_items: Dict[str, int], products: Dict[str, Any], agents: [Agent], ag_names: Dict[str, Agent]) -> ShopList:
        """
        Simply distribute task of buying base items to agents that can carry them.
        What tools are used with what base items is not considered for now...

        TODO: We need hint about what tools are involved with what bases in assembly?
        """
        shopping_list = defaultdict(dict)

        volumes = defaultdict(int)
        for agent, items in tools_shopping_list.items():
            for base_name, base_amount in items.items():
                recipe = products[base_name]
                volume = int(recipe['volume'])
                volumes[agent] += base_amount * volume

        for base_name, base_amount in needed_items.items():
            recipe = products[base_name]
            volume = base_amount * int(recipe['volume'])

            def can_carry(agent: str) -> bool:
                return volume + volumes[agent] < ag_names[agent].remaining_load()

            applicable_agents = list(filter(can_carry, [agent.name for agent in agents]))
            if len(applicable_agents) == 0:
                print("WARNING: No applicable agents for carrying items")
                continue

            chosen_agent = random.choice(applicable_agents)
            volumes[chosen_agent] += volume

            if not base_name in shopping_list[chosen_agent]:
                shopping_list[chosen_agent][base_name] = 0

            shopping_list[chosen_agent][base_name] += base_amount

        return dict(shopping_list)

    def old_items_shopping_list(self, tools_list: ShopList, needed_items: Dict[str, Dict[str, int]]) -> ShopList:
        """
        Takes a dict from base to tool to amount, of how much of each base should be assembled by that tool.
        Returns a shopping list of what things each agent should buy.

        Items in this function are consumed items. That is, the items are always consumed.

        TODO: Should take shop stock into account.

        TODO: We buy waay too much
        """
        dist = {}  # type: ShopList
        # type: Dict[str, int]
        volumes = {agent.name: 0 for agent in self.agents}

        for base, tools in needed_items.items():
            print("base: ", base)
            print("tools: ", tools)
            itemsBought = False
            for tool in tools:
                if tool == None:
                    print("no tools needed or already has them")

                possible_agents = [x for x in self.agents if x.role in TOOL2ROLES[tool]]

                def can_carry(agent: Agent) -> bool:
                    recipe = self.products[base]
                    volume = int(recipe['volume']) * max(list(tools.values()))

                    tools_volumes = 0
                    if agent.name in tools_list:
                        for t, amount in tools_list[agent.name].items():
                            if self.products[t]['assembled'] == 'false':
                                tools_volumes += int(recipe['volume'])
                            else:
                                tools_volumes += sum([max(base_amount.values()) * int(self.products[tool_base]['volume'])
                                                      for tool_base, base_amount
                                                      in self.needed_base_items([self.products[tool]]).items()])

                    return volume + volumes[agent.name] + tools_volumes < agent.remaining_load()

                agents = filter(can_carry, possible_agents)
                #TODO: Add extra filter to make sure that the agent that buys the base materials are at a shop where it can buy them. This avoids having an agent go to another shop and waste time.
                for agent in agents:
                    #We buy way to much. Problem is likely here.
                    if agent.name not in dist:
                        dist[agent.name] = {}

                    amount = tools[tool]
                    dist[agent.name][base] = amount
                    print('added ' + str(base) + ' to ' + agent.name + ' using ' + str(tool))
                    #print("amount_lol=", amount)
                    #print("dis[agent.name]=", dist[agent.name])
                    volumes[agent.name] += amount * \
                        int(self.products[base]['volume'])
                    itemsBought = True
                    break
                if itemsBought: #Dont make all possible agents buy stuff, 1 is enough. TODO: Make a better fix than this
                    break

        #print("dist_lol", dist)
        return dist

    def tools_shopping_list(self, needed_tools: Dict[str, int]):
        return self.tools_shopping_list_static(needed_tools, self.products, self.shops, self.agents, self.ag_names, TOOL2ROLES)

    @staticmethod
    def tools_shopping_list_static(needed_tools: Dict[str, int], products: Dict[str, Any], shops: Dict[str, Any], agents: [Agent], ag_names: Dict[str, Agent], tool2roles: Dict[str, Set[str]]) -> ShopList:
        """
        Returns a dict with agents as keys and what items they should purchase as values.

        the "tools" in this function are the tools needed to assemble an item that are NOT consumed. Any tool in the needed_tools list is NOT consumed.

        TODO: On the London-map, this strategy ends up buying base1 very expensively,
        because only the motorcycle can use tool3 and it ends up at shop2. Should be smarter.

        TODO: Thoroughly test the "already has tool"

        TODO: Take stock into account.
        """
        shopping_list = defaultdict(dict)

        # create mapping from tool names to names of agents that can use that tool
        tool2agents = defaultdict(set)
        for tool_name in needed_tools.keys():
            roles = tool2roles[tool_name]
            for agent in agents:
                if agent.role in roles:
                    tool2agents[tool_name].add(agent.name)

        for tool_name, usable_agents in tool2agents.items():
            recipe = products[tool_name]

            # if agents collectively have required amount of tool, then don't add it to the shopping list
            for agent in usable_agents:
                for item in ag_names[agent].info['items']:
                    if item['name'] == tool_name and int(item['amount']) >= needed_tools[tool_name]:
                        continue

            needed_base_items = Runner.needed_base_items_static({tool_name: needed_tools[tool_name]}, products)

            def cost(agent: str) -> int:
                shop = None  # type: Dict[str, Any]
                facil = ag_names[agent].info['inFacility']
                if facil.startswith('shop'):
                    shop = shops[facil]
                else:
                    for job in ag_names[agent].plan:
                        if isinstance(job, Goto) and job.target.startswith('shop'):
                            shop = shops[job.target]
                            break

                if not shop:
                    return sys.maxsize

                price_of_tool = 0
                for base_name, base_amount in needed_base_items.items():
                    base = shop['items'].get(base_name)
                    if base is None:
                        return sys.maxsize
                    price_of_tool += base_amount * int(base['cost'])

                return price_of_tool

            def can_carry(agent: str) -> bool:
                current_volume = 0
                if agent in shopping_list:
                    for item_name, item_amount in shopping_list[agent].items():
                        current_volume += item_amount * int(products[item_name]['volume'])

                volume = 0
                for base_name, base_amount in needed_base_items.items():
                    volume += base_amount * int(products[base_name]['volume'])

                return volume + current_volume <= ag_names[agent].remaining_load()

            applicable_agents = list(filter(can_carry, usable_agents))
            if len(applicable_agents) == 0:
                print("WARNING: No applicable agents for carrying items")
                continue

            best_agent = utils.minkey(applicable_agents, cost)
            if cost(best_agent) == sys.maxsize:
                print("WARNING: Chosen applicable agent cannot buy required item. Choosing alternate way.")

            for base_name, base_amount in needed_base_items.items():
                shopping_list[best_agent][base_name] = base_amount

        return dict(shopping_list)

    def needed_tools(self, item_names: Set[str]) -> Dict[str, int]:
        return self.needed_tools_static(item_names, self.products)

    @staticmethod
    def needed_tools_static(item_names: Set[str], products: Dict[str, Any]) -> Dict[str, int]:
        """
        Takes a list of item names and a dictionary describing all products.
        Returns a dictionary where keys are names of all the tools required
        in the assembly of the given items from only non-assembled items,
        and the value is the maximum quantity of that tool that is required
        in a single assembly operation.
        """
        tools = {}
        for item_name in item_names:
            recipe = products[item_name]
            if recipe['assembled'] == 'false':
                continue
            required_item_names = set()
            for tool in recipe['tools']:
                utils.update_dict(tools, tool['name'], int(tool['amount']), 1, max)
                required_item_names.add(tool['name'])
            for consumed in recipe['items']:
                required_item_names.add(consumed['name'])
            tools2 = Runner.needed_tools_static(required_item_names, products)
            tools = utils.merge_dicts(tools, tools2, max)
        return tools

    def needed_base_items(self, items: Dict[str, int]) -> Dict[str, int]:
        return self.needed_base_items_static(items, self.products)

    @staticmethod
    def needed_base_items_static(items: Dict[str, int], products: Dict[str, Any]) -> Dict[str, int]:
        """
        Takes a dictionary of items with item names as keys and item amounts as values.
        Returns a dictionary of base items needed to assemble items with names as keys and amounts as values.
        Tools and items needed to assemble tools are not considered.
        """
        base_items = defaultdict(int)
        for name, amount in items.items():
            recipe = products[name]
            if recipe['assembled'] == 'false':
                base_items[name] += amount
                continue
            consumed_items = defaultdict(int)
            for consumed_item in recipe['items']:
                consumed_items[consumed_item['name']] += int(consumed_item['amount'])
            base_items2 = Runner.needed_base_items_static(dict(consumed_items), products)
            for base_name, base_amount in base_items2.items():
                base_items[base_name] += amount * base_amount
        return dict(base_items)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-d', '--dummy', help='dummy agents', action='store_true')  # type: ignore
    parser.add_argument('-v', '--verbosity', type=int, choices=[0, 1, 2])  # type: ignore
    parser.add_argument('prefix', help="agent name prefix", choices=['a', 'b', 'pythondtu', 'dummy'])  # type: ignore
    args = parser.parse_args()

    if args.dummy:
        for i in range(1, NUM_OF_AGENTS + 1):
            Communicator(args.prefix + str(i), Queue(), Queue(), True).start()
            time.sleep(0.01)
            print('running dummies')
        while True:
            time.sleep(2)

    r = Runner(args.prefix)
    r.start()

    print('Stopped')
