#!/usr/bin/env bash

python_dir=$(pwd)
logs_directory="graphhopper_logs"
graphhopper_script="./graphhopper.sh"

if [ ! -d $logs_directory ]; then
    mkdir $logs_directory
fi

maps_directory="$1/massim/scripts/osm/"
graphhopper_directory=$2

for dir in $maps_directory $graphhopper_directory
do
    if [ ! -d $dir ]; then
        echo "$dir does not exist"
        exit
    fi
done

for i in $(python -c "from global_vars import *; print(str.join(' ', [str(i) for i in SIM_TO_MAP.keys()]))")
do
    port=$(python -c "from global_vars import *; print(SIM_TO_PORT[$i])")
    map=$(python -c "from global_vars import *; print(SIM_TO_MAP[$i])")
    echo "starting" $map 'on port' $port
    cd $graphhopper_directory
    JETTY_PORT=$port $graphhopper_script web "$maps_directory/$map" > "$python_dir/$logs_directory/$map.log" &
    cd $python_dir
done
