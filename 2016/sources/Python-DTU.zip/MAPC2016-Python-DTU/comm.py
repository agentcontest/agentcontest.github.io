import xml.etree.cElementTree as eT
import socket
import multiprocessing as mp
from global_vars import *
# import graphhopper
import utils
from commands import *
import time
import sys
import errno
import random

from typing import Dict, Any, List, Tuple, Union

Attrib = Dict[str, Any]
Command = Union[Buy, Assemble, Assist, Give, Receive, Deliver, Goto, Charge, Bid_for_job]
Plan = List[Command]

SEPARATOR = b'\0'
RECV_SIZE = 8192


class Communicator(mp.Process):
    def __init__(self, name: str, w_q: mp.Queue, r_q: mp.Queue, dummy: bool=False) -> None:
        mp.Process.__init__(self)
        self.auth = eT.fromstring('''<?xml version="1.0" encoding="UTF-8" standalone="no"?>
            <message type="auth-request"><authentication password="test" username="test"/></message>''')

        self.daemon = True
        self.name = name
        self.w_q = w_q
        self.r_q = r_q
        self.dummy = dummy
        self.running = False
        self.s = None  # type: socket.socket

    def connect(self) -> bool:
        try:
            print('Connecting...')
            self.s = socket.create_connection(ADDRESS, RETRY_DELAY)
            self.s.settimeout(None) # enable blocking mode until simulation starts
            return True
        except OSError as error:
            print('Error connecting to {}: {}'.format(ADDRESS, error))
            return False

    def reconnect(self) -> None:
        try:
            self.s.shutdown(socket.SHUT_RDWR)
            self.s.close()
        except OSError:
            pass
        time.sleep(RETRY_DELAY)
        print('Attempt to reconnect...')
        self.s = None
        while not self.connect():
            time.sleep(RETRY_DELAY)
        self.authenticate()

    def authenticate(self) -> None:
        auth_ele = self.auth.find('authentication')
        auth_ele.attrib['username'] = self.name
        auth_ele.attrib['password'] = PASSWORD
        self.s.send(eT.tostring(self.auth) + SEPARATOR)

    def handle_message(self, xml: str) -> None:
        message = eT.fromstring(xml)
        if not self.dummy:
            self.w_q.put((self.name, message))  # type: ignore
        typ = message.get('type')
        if typ == 'request-action':
            if self.dummy:
                identifier = message.find('perception').get('id')
                response = eT.Element('message', type='action')
                action = eT.SubElement(response, 'action', id=identifier, type='skip')
            else:
                response = self.r_q.get()
            self.s.send(eT.tostring(response) + SEPARATOR)
        elif typ == 'sim-start':
            # start expecting messages from server within a reasonable timeout
            # assume connection is lost otherwise and attempt to reconnect
            self.s.settimeout(TIMEOUT)

    def run(self) -> None:
        while not self.connect():
            time.sleep(RETRY_DELAY)
        self.authenticate()
        buffer = b''
        while True:
            try:
                data = self.s.recv(RECV_SIZE)
            except socket.timeout:
                print('Socket timeout')
                self.reconnect()
                buffer = b''
                continue
            except socket.error as e:
                if e.errno == errno.ECONNRESET:
                    # connection closed by server
                    data = b''
                else:
                    print('Socket error: {}'.format(e))
                    self.reconnect()
                    buffer = b''
                    continue
            if len(data) == 0:
                print('Connection closed by server')
                sys.exit(0)
            else:
                buffer += data
                index = buffer.find(SEPARATOR)
                while index != -1:
                    self.handle_message(buffer[0:index].decode())
                    buffer = buffer[index + 1:]
                    index = buffer.find(SEPARATOR)


class Agent:
    role = ''
    plan = []  # type: Plan
    info = {}  # type: Attrib
    name = ''

    def __init__(self, name: str, w_q: mp.Queue, r_q: mp.Queue, dummy: bool=False) -> None:
        self.auth = eT.fromstring('''<?xml version="1.0" encoding="UTF-8" standalone="no"?>
            <message type="auth-request"><authentication password="test" username="test"/></message>''')

        self.action = eT.fromstring(
            '''<?xml version="1.0" encoding="UTF-8"?><message type="action"><action id="" type="goto" /></message>''')
        self.daemon = True
        self.name = name
        self.r_q = r_q
        self.sim_info = None  # type: eT.Element
        self.info = {}  # type: Attrib
        self.role_info = None # type: eT.Element
        self.id = ''
        self.sim_id = -1
        self.role = ''
        self.speed = 0
        self.max_load = 0
        self.max_battery = 0
        self.tools = [] # type: List[str]
        self.total_steps = 0
        self.dummy = dummy
        self.running = True

        self.comm = Communicator(name, w_q, r_q, dummy)

        self.moving_to = ''
        self.reached_dest = True
        self.charging_stations = {}  # type: Dict[str, Attrib]
        self.dump_locations = {}  # type: Dict[str, Attrib]
        self.shops = {}  # type: Dict[str, Attrib]
        self.storages = {}  # type: Dict[str, Attrib]
        self.workshops = {}  # type: Dict[str, Attrib]
        self.score = 0

        self.plan = []  # type: Plan
        self.current_index = 0
        self.done = False

        self.ag_names = {}  # type: Dict[str, Agent]

    def initialize(self, sim_info: eT.Element) -> None:
        self.sim_info = sim_info
        self.role_info = sim_info.find('role')

        self.total_steps = self.sim_info.attrib['steps']  # type: ignore
        self.sim_id = int(self.sim_info.attrib['id'])  # type: ignore

        self.role = self.role_info.attrib['name'] # type: ignore
        self.speed = int(self.role_info.attrib['speed']) # type: ignore
        self.max_load = int(self.role_info.attrib['maxLoad']) # type: ignore
        self.max_battery = int(self.role_info.attrib['maxBattery']) # type: ignore

        for tool in self.role_info.findall('tool'):
            tool_name = tool.attrib['name']
            self.tools.append(tool_name)
            TOOL2ROLES.setdefault(tool_name, set()).add(self.role)
            print("tool_name: {}, agent name: {}".format(tool_name, self.role))

        self.print_info()

    def print_info(self) -> None:
        print('Simulation started, steps: {}, role: {}, speed: {}, maxLoad: {}, maxBattery: {}'.format(self.total_steps, self.role, self.speed, self.max_load, self.max_battery))

    def handle_last_action(self) -> None:
        if self.info['lastActionResult'] != 'successful':
            if 'wrong' in self.info['lastActionResult']:
                print('OBS OBS', self.name, self.info['lastActionResult'], ' : ', self.info['lastAction'])
            # TODO: this is from the old code
            elif 'away' in self.info['lastActionResult']:
                f = open(self.name[0] + "away.log", "a")
                f.write("".join(['OBS OBS', self.name, self.info['lastActionResult'], ' : ', self.info['lastAction']]) + '\n')
                f.close()
                print('OBS OBS', self.name, self.info['lastActionResult'], ' : ', self.info['lastAction'])
            elif 'failed_random' in self.info['lastActionResult']:
                self.current_index = max(0, self.current_index - 1)
                print(self.name, 'failed_random')
            else:
                print(self.name, self.info['lastActionResult'], ' : ', self.info['lastAction'])

        if self.info['charge'] == '0':
            print('OBS OBS', self.name, 'ran out of charge')

    def send_action(self, typ: str, param: str=None) -> None:
        action_ele = self.action.find('action')
        action_ele.clear()
        action_ele.attrib['id'] = self.id
        action_ele.attrib['type'] = typ
        if param is not None:
            action_ele.set('param', param)

        self.r_q.put(self.action)  # type: ignore

    def post_job(self):
        price = random.randint(1, 10)
        active_steps = random.randint(100, 300)
        storage = 'storage0'
        num_items = random.randint(3, 6)

        params = 'type=priced price={} active_steps={} storage={}'.format(price, active_steps, storage)
        for index in range(num_items):
            item_id = random.randint(1, 5)
            amount = random.randint(2, 20)
            params += ' item{}=item{} amount{}={}'.format(index + 1, item_id, index + 1, amount)
        self.send_action(POST_JOB, params)

    def execute_plan(self) -> None:
        """
        Continues execution of the current plan.
        """
        self.done = False

        if self.current_index >= len(self.plan):
            self.done = True
            if random.random() < 0.005:
                print(self.name + " posting job")
                self.post_job()
            else:
                self.send_action(SKIP)
            return

        job = self.plan[self.current_index]
        print(self.name + "_" + str(job))

        if isinstance(job, Buy):
            self.send_action(BUY, 'item=' + job.item + ' amount=' + str(job.amount))
            self.current_index += 1
        elif isinstance(job, Assemble):
            if 'workshop' in self.info['inFacility']:
                item = job.item
                amount = job.amount
                has_item = False
                for has in self.info['items']:
                    if has['name'] == item and int(has['amount']) == amount:
                        has_item = True
                        break

                if has_item:
                    self.current_index += 1
                    self.execute_plan()
                else:
                    self.send_action(ASSEMBLE, 'item=' + item)
            else:
                workshop_plan = self.plan_to(self.nearest(list(self.workshops.values()))[0])
                if workshop_plan == []:
                    print("WARNING: Assemble: workshop_plan is empty")
                    self.current_index += 1
                self.plan[self.current_index:self.current_index] = workshop_plan
                self.execute_plan()
        elif isinstance(job, Assist):
            fac = self.info['inFacility']
            print ("facilities: "+str(self.info['inFacility']))
            if 'workshop' in fac and fac == self.ag_names[job.who].info['inFacility']:
                self.send_action(ASSIST, 'assembler=' + job.who)

                other_has_item = False
                for has in self.ag_names[job.who].info['items']:
                    if has['name'] == job.item and int(has['amount']) == job.amount:
                        other_has_item = True
                        break

                if other_has_item:
                    self.current_index += 1
            else:
                # TODO: can probably benefit from something more coordinated
                # print ('aa prints: '+str(self.ag_names[job.who].nearest(list(self.workshops.values()))[0]))
                nearest_other = self.ag_names[job.who].nearest(list(self.workshops.values()))[0]
                if nearest_other['name'] == self.info['inFacility']:
                    self.send_action(SKIP)
                else:
                    workshop_plan = self.plan_to(nearest_other)
                    self.plan[self.current_index:self.current_index] = workshop_plan
                    self.execute_plan()
        elif isinstance(job, Give):
            got_it = False
            for has in self.ag_names[job.who].info['items']:
                if has['name'] == job.item and int(has['amount']) == job.amount:
                    got_it = True
                    break

            if got_it:
                self.current_index += 1
                self.execute_plan()
            else:
                self.send_action(GIVE, 'agent=' + job.who + ' item=' + job.item + ' amount=' + str(job.amount))
        elif isinstance(job, Receive):
            got_it = False
            for has in self.info['items']:
                if has['name'] == job.item and int(has['amount']) == job.amount:
                    got_it = True
                    break

            if got_it:
                self.current_index += 1
                self.execute_plan()
            else:
                self.send_action(RECEIVE)
        elif isinstance(job, Deliver):
            if self.info['inFacility'] == job.where:
                self.send_action(DELIVER_JOB, 'job=' + job.id)
                self.current_index += 1
            else:
                plan_there = self.plan_to(self.storages[job.where])
                if plan_there == []:
                    print("WARNING: Deliver: plan_there is empty!")
                    self.current_index += 1
                self.plan[self.current_index:self.current_index] = plan_there
                self.execute_plan()
        elif isinstance(job, Goto):
            if job.target == self.info['inFacility']:
                self.current_index += 1
                self.execute_plan()
            else:
                if self.info['routeLength'] == '0':
                    self.send_action(GOTO, 'facility=' + job.target)
                else:
                    self.send_action(CONTINUE)
        elif isinstance(job, Charge):
            # print ("aa job: "+job)
            atChargingStation = False
            # TODO: handle if not at charging station
            # TODO: run a loop to check through charging station dict and match agent.coord with charging station coordinates
            # TODO: charge only if at a charging station
            # print ( 'current agent location: '+str(self.info['lon'])+', '+str(self.info['lat']) )
            # print (self.info['charge'])
            # print (self.info['batteryCapacity'])

            for key in self.charging_stations:
                #print ('charging at locations: '+ str(self.charging_stations[key]['lon'])+', '+str(self.charging_stations[key]['lat']))
                if ( self.info['lon'] == self.charging_stations[key]['lon'] and self.info['lat'] == self.charging_stations[key]['lat'] ):
                    atChargingStation = True
                    break

            if atChargingStation:
                print ('Agent locations: '+ str(self.info['lon'])+', '+str(self.info['lat']) )
                if self.info['charge'] == self.info['batteryCapacity']:
                    self.current_index += 1
                    self.execute_plan()
                else:
                    print("Warning: agent " + self.name + " charging while not at charging station")
                    self.send_action(CHARGE)
            else:
                self.send_action(CHARGE)
        elif isinstance(job, Bid_for_job):
            self.send_action(BID_FOR_JOB, 'job=' + job.job + ' price=' + str(job.price))
            self.current_index += 1
        elif isinstance(job, Post_auction_job):
            params = 'type=auction max_price={} fine={} auction_steps={} active_steps={} storage={}'.format(job.max_price, job.fine, job.auction_steps, job.active_steps, job.storage)
            for index, (item, amount) in enumerate(job.items.items()):
                params += ' item{}={} amount{}={}'.format(index + 1, item, index + 1, amount)
            self.send_action(POST_JOB, params)
            self.current_index += 1
        elif isinstance(job, Post_priced_job):
            params = 'type=priced price={} active_steps={} storage={}'.format(job.price, job.active_steps, job.storage)
            for index, (item, amount) in enumerate(job.items.items()):
                params += ' item{}={} amount{}={}'.format(index + 1, item, index + 1, amount)
            self.send_action(POST_JOB, params)
            self.current_index += 1
        else:
            print(self.name, 'cannot understand command:', job)

    def add_to_plan(self, plan: Plan) -> None:
        """
        After the agent finishes it's current plan, continue with `plan`, a list of commands.
        """
        self.plan += plan

    def plan_to(self, target: Dict[str, Any]) -> Plan:
        """
        Returns a list of commands for reaching the target, possibly charging on the way.
        """
        # Distance and steps to the target, then the nearest charger
        target_charge_dist =\
            self.dist_to(target) + self.nearest_from(target, list(self.charging_stations.values()))[1]
        target_charge_steps = self.dist_to_steps(target_charge_dist)

        # If we can reach the target and still have room for charging, go for
        # the target immediately

        if self.available_steps() - target_charge_steps >= THRESHOLD[self.role]:
            return [Goto(target=target['name'], steps=self.steps_direct_to(target))]
        # if not, find the shortest route to the target while charging on the
        # way
        else:
            return self.shortest_charger_route(target)

    def available_steps(self) -> float:
        """How many steps does the agent have available before running out of charge."""
        return int(self.info['charge']) / 10

    def shortest_charger_route(self, target: Dict[str, Any]) -> Plan:
        """
        Returns a list of Goto and Charge commands, moving to and from and charging at a station,
        for which the route to target passing through that station, will be shortest,
        and the agent has enough charge to make it to the charger.

        NOTE: The criteria here is the shortest route, the most efficient could be interesting as well.

        TODO: Assuming only one charger has to be used on the route.
        """
        charging_stations = {ch[0]: ch[1] for ch in self.charging_stations.items()
                             if self.steps_direct_to(ch[1]) <= self.available_steps()}
        #charging_stations becomes empty if vehicle is out of charge! It then ends up with an error
        #for ch in self.charging_stations.items():
        #    print('stepsDirectTo=', self.steps_direct_to(ch[1]))

        if len(charging_stations) == 0:
            # TODO: This should never happen!
            print('WARNING: agent {} cannot reach any charging stations! (charge: {})'.format(self.name, self.info['charge']))
            return []

        shortest = None  # type: Tuple[Tuple[str, Dict[str, Any]], float]

        for ch in charging_stations.items():
            dist_to_ch = self.dist_to(ch[1])
            dist_from_ch = self.dist_between(ch[1], target)
            route_dist = dist_to_ch + dist_from_ch

            dist_target_nearest_charger = \
                self.dist_to_steps(
                    self.nearest_from(target, list(self.charging_stations.values()))[1])

            if shortest is None or route_dist < shortest[1] \
                    and int(self.info['batteryCapacity']) / 10 - dist_target_nearest_charger > THRESHOLD[self.role]:
                shortest = ch, route_dist

        return [
            Goto(target=shortest[0][0], steps=self.dist_to_steps(self.dist_to(shortest[0][1]))),
            Charge(steps=STEPS_TO_CHARGE),
            Goto(target=target['name'], steps=self.dist_to_steps( self.dist_between(shortest[0][1], target)))
        ]

    def dist_to_steps(self, dist: float) -> float:
        """ Converts a given distance to the number of steps it would take for the agent to move it. """
        #if 'Drone' in self.role:
        #    return utils.drone_route_length(dist) / self.speed
        #elif USE_GRAPHHOPPER:
        #    return graphhopper.route_length(dist) / self.speed
        #else:
        return utils.route_length(dist) / self.speed

    def steps_direct_to(self, target: Dict[str, Any]) -> float:
        """ Returns the number of steps it would take for self to reach target without charging. """
        return self.dist_to_steps(self.dist_to(target))

    def nearest_charger(self) -> Dict[str, Any]:
        """ Returns the nearest charger. """
        return self.nearest(list(self.charging_stations.values()))[0]

    def remaining_load(self) -> int:
        return int(self.info['loadCapacity']) - int(self.info['load'])

    def dist_to(self, x: Dict[str, Any]) -> float:
        return self.dist_between(self.info, x)

    def dist_between(self, a: Dict[str, Any], b: Dict[str, Any]) -> float:
        # if USE_GRAPHHOPPER and 'Drone' not in self.role:
        #     return graphhopper.distance_between(self.sim_id, a, b)
        # else:
            return utils.euclidean_dist(a, b)

    def nearest(self, ls: List[Dict[str, Any]]) -> Tuple[Dict[str, Any], float]:
        """
        Given a list `ls` of facilities/entities, returns the element in ls nearest self
        and the distance between them, in a tuple.
        """
        return self.nearest_from(self.info, ls)

    def nearest_from(self, x: Dict[str, Any], ls: List[Dict[str, Any]]) -> Tuple[Dict[str, Any], float]:
        """
        Given an entity x and list `ls` of facilities/entities, returns the element in ls nearest the entity
        and the distance between them, in a tuple.
        """
        with_dists = [(l, self.dist_between(x, l)) for l in ls]

        closest = with_dists[0]
        for l in with_dists:
            if l[1] < closest[1]:
                closest = l

        return closest
