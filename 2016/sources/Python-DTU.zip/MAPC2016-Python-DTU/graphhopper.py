import urllib.request
import json
from global_vars import *
from typing import Dict, Any


def distance_between(sim_id: int, a: Dict[str, Any], b: Dict[str, Any]) -> float:
    """
    IMPORTANT: To use this method, start a graphhopper server for each of the maps on the port specified in SIM_TO_PORT.
    This can be done by the ./startgraphhopper.sh script like this
    $ ./startgraphhopper.sh ~/Desktop/massim-2015-0.1/ ~/Desktop/graphhopper/
    """
    port = SIM_TO_PORT[ID_TO_SIM[sim_id]]

    request = 'http://localhost:{}/route?instructions=false&calc_points=true&' \
              'points_encoded=false&point={},{}&point={},{}'.format(
                  port, a['lat'], a['lon'], b['lat'], b['lon'])
    response = urllib.request.urlopen(request).read().decode()  # type: ignore

    parsed = json.loads(response)

    try:
        return parsed['paths'][0]['distance']
    except Exception as _:
        return -1


def route_length(dist: float) -> float:
    """
    Based on fitting, which is annoying and should be unnecessary, but it's accurate within one or two steps.
    """
    return 0.922165934704395 + 0.0118160339336563 * dist
