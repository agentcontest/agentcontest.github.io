package de.tub.mac16.ontology.Activities;

import de.tub.mac16.connection.MessageConstants;
import de.tub.mac16.ontology.*;
import de.tub.mac16.ontology.Helpers.Pair;
import de.tub.mac16.ontology.Helpers.Tuple;
import de.tub.mac16.ontology.Intentions.GiveIntention;
import de.tub.mac16.ontology.Intentions.GotoIntention;
import de.tub.mac16.ontology.Intentions.Intention;
import de.tub.mac16.routing.WaypointRouting;

import java.util.LinkedList;

/**
 * Created by holgerschuh on 29.08.16.
 */
public class DeliverToOtherAgentsActivity implements IActivity {
	private IActivity prevActivity = null;
	LinkedList<Pair<AgentState, ItemWithQuantity>> deliveries = new LinkedList<>();
	GotoIntention gotoIntention = null;
	GiveIntention giveIntention = null;
	AgentState reciever = null;
	ItemWithQuantity item = null;
	World world;
	int updatedLastInTurn = 0;
	LinkedList<Intention> intentionList;


	public void setWorld(World world) {
		this.world = world;
	}

	public DeliverToOtherAgentsActivity(World world, IActivity prevActivity) {
		this.world = world;
		this.prevActivity = prevActivity;
	}

	/**
	 * @return the intention that will be sent to the server in the next response, or null if this activity is done
	 */
	@Override
	public Intention getCurrentIntention() {
		if (deliveries.isEmpty() && reciever == null) return null;
		if (gotoIntention != null) return gotoIntention;
		if (giveIntention != null) return giveIntention;
		if (reciever == null) {
			Pair<AgentState, ItemWithQuantity> nextDelivery = deliveries.getFirst();
			reciever = nextDelivery.key;
			item = nextDelivery.value;
		}
		Location curLoc = world.self.currentLocation;
		Location destLoc = reciever.getLocation();
		if (!curLoc.equals(destLoc)) {
			gotoIntention = new GotoIntention(curLoc, destLoc, world.getDuration(curLoc, destLoc));
			return gotoIntention;
		} else {
			giveIntention = new GiveIntention(reciever, item);
			return giveIntention;
		}
	}

	/**
	 * Updates the current intention with the result from the server.
	 * If the current intention is done, advances to the next intention.
	 *
	 * @param result
	 * @param world
	 */
	@Override
	public void onResult(String result, World world) {
		if (gotoIntention != null) {
			gotoIntention.onResult(result, world);
			if (result.equals(MessageConstants.RESULT_SUCCESSFUL) && world.self.currentLocation.equals(reciever.getLocation())) {
				gotoIntention = null;
			}
		}
		if (giveIntention != null) {
			giveIntention.onResult(result, world);
			if (result.equals(MessageConstants.RESULT_SUCCESSFUL))
				giveIntention = null;
		}
	}

	/**
	 * @param world
	 * @return false if there are any intentions left to do
	 */
	@Override
	public boolean isComplete(World world) {
		return (deliveries.isEmpty() && reciever == null);
	}

	/**
	 * @return number of rounds this activity will take, without random failures
	 */
	@Override
	public int getDuration() {
		int ret = 0;
		for (Intention intention : getIntentions())
			ret += intention.getDuration();
		return ret;
	}

	@Override
	public int getCost() {
		int ret = 0;
		for (Intention intention : getIntentions())
			ret += intention.getCost();
		return ret;
	}

	/**
	 * Used for planning.
	 *
	 * @return my targetLocation after the last intention, or null if unchanged
	 */
	@Override
	public Location getLastLocation() {
		return deliveries.getLast().key.getLocation();
	}

	/**
	 * @return the difference in capacity after the activity,
	 * negative means less available - the agent uses more of its storage,
	 * positive means the agent frees up space in its storage
	 */
	@Override
	public int getCapacityDelta() {
		int ret = 0;
		ItemWithQuantity item;
		for (Pair<AgentState, ItemWithQuantity> pair : deliveries)
			ret -= pair.value.getVolume();
		return ret;
	}

	@Override
	public int getChargeDelta() {
		int ret = 0;
		for (Intention intention : getIntentions())
			ret += intention.getChargeDelta();
		return ret;
	}

	/**
	 * used for calculating the last location if this activity has no goto intentions
	 */
	@Override
	public IActivity getPrevActivity() {
		return prevActivity;
	}

	@Override
	public void setPrevActivity(IActivity activity) {
		prevActivity = activity;
	}

	@Override
	public LinkedList<Intention> getIntentions() {
		if (world.simulationStep == updatedLastInTurn) return intentionList;
		updatedLastInTurn = world.simulationStep;
		Location startingLoc = getStartingLocation();
		int startingCharge = startingCharge();
		Location lastLoc = deliveries.getLast().key.getLocation();
		LinkedList<Tuple<ILocation, Intention>> waypoints = packLocationIntentions();
		Activity answer = WaypointRouting.getFastestRouteVisitingAllWayPoints(startingLoc, startingCharge, lastLoc, waypoints, world).c;
		intentionList = answer.getIntentions();
		return intentionList;
	}

	private Location getStartingLocation() {
		Location startingLoc;
		if (getPrevActivity() != null) {
			startingLoc = getPrevActivity().getLastLocation();
		} else if (world != null) {
			startingLoc = world.self.currentLocation;
		} else return deliveries.getFirst().key.getLocation();
		return startingLoc;
	}

	private LinkedList<Tuple<ILocation, Intention>> packLocationIntentions() {
		LinkedList<Tuple<ILocation, Intention>> ret = new LinkedList<>();
		for (Pair<AgentState, ItemWithQuantity> pair : deliveries) {
			if (pair != deliveries.peekLast()) {
				GiveIntention giveIntention = new GiveIntention(pair.key, pair.value);
				ret.add(new Tuple<>(pair.key, giveIntention));
			}
		}
		return ret;
	}


	@Override
	public int chargeAfterActivityIsFinished() {
		int ret = startingCharge();
		for (Intention intention : getIntentions())
			ret += intention.getChargeDelta();
		return ret;
	}

	public int startingCharge() {
		if (getPrevActivity() != null) return getPrevActivity().chargeAfterActivityIsFinished();
		else return world.self.charge;
	}
}
