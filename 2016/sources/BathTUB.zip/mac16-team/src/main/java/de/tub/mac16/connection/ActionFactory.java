package de.tub.mac16.connection;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

/**
 * This class creates valid message content for ac server communication.
 *
 * @author axle
 */
public class ActionFactory {

	/**
	 * New factory, which is used to build new documents
	 */
	private static DocumentBuilderFactory documentbuilderfactory = DocumentBuilderFactory.newInstance();

	/**
	 * Method that creates a new AuthenticationAction in valid XML-Syntax.
	 *
	 * @param username - the username
	 * @param password - the password
	 * @return the corresponding xml-document
	 */
	public static Document getAuthenticationAction(String username, String password) {
		Document doc = null;
		try {
			doc = documentbuilderfactory.newDocumentBuilder().newDocument();
			Element root = doc.createElement("message");
			root.setAttribute("type", MessageConstants.MESSAGE_AUTH_RESPONSE);
			doc.appendChild(root);
			Element auth = doc.createElement("authentication");
			auth.setAttribute("username", username);
			auth.setAttribute("password", password);
			root.appendChild(auth);
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		}
		return doc;
	}

	/**
	 * Method that creates a new Action in valid XML-Syntax!
	 *
	 * @param action - one of the actions defined in MessageConstants.java
	 * @param param  the action parameter if any, if null the attribute will not be set
	 * @param id     - the id of the request message
	 * @return the corresponding xml-document
	 */
	public static Document getAction(String action, String param, String id) {
		assert action != null;
		assert id != null;

		Document doc = null;
		try {
			doc = documentbuilderfactory.newDocumentBuilder().newDocument();
			Element root = doc.createElement("message");
			root.setAttribute("type", "action");
			doc.appendChild(root);
			Element act = doc.createElement("action");
			act.setAttribute("type", action);
			act.setAttribute("id", id);
			if (param != null) {
				act.setAttribute("param", param);
			}
			root.appendChild(act);
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		}
		return doc;
	}
}
