package de.tub.mac16.routing;

import de.tub.mac16.ontology.Activities.Activity;
import de.tub.mac16.ontology.Facilities.ChargingStation;
import de.tub.mac16.ontology.Facilities.Facility;
import de.tub.mac16.ontology.Facilities.YellowPages;
import de.tub.mac16.ontology.Helpers.Quadruplet;
import de.tub.mac16.ontology.Helpers.Tree;
import de.tub.mac16.ontology.Helpers.Triple;
import de.tub.mac16.ontology.Helpers.Tuple;
import de.tub.mac16.ontology.ILocation;
import de.tub.mac16.ontology.Intentions.ChargeIntention;
import de.tub.mac16.ontology.Intentions.GotoIntention;
import de.tub.mac16.ontology.Intentions.Intention;
import de.tub.mac16.ontology.World;

import java.util.Collection;
import java.util.LinkedList;
import java.util.stream.Collectors;

/**
 * Created by marc on 24/08/16.
 */
public class WaypointRouting {

	/**
	 * Calculates a the fastest chargingstation-route to the destination, but doesn't consider
	 * the price for charging
	 *
	 * first loop: checks wether it is possible to reach the destination and charge later
	 * second loop: checks wether 1 chargingStation should be targeted before reaching the goal
	 *		(here the first stage of the TripleTree is build)
	 * third loop: in each step every leaf of the tree, which is represented by a
	 *		Triple <>(durationToCurrentChargingstation + chargingDuration, chargingDuration,
	 *		currentChargingstation), gets new children, which consist of the ChargingStations in range
	 *		- the path from the root of the tree to one of its leafs represents the route from
	 *		root.currentChargingStation to leaf current.ChargingStation, every ChargingStation only
	 *		exists once
	 *
	 * Routes with a lower number of ChargingStations are preferred, chooses the shortest route beyond
	 * all possible routes
	 *
	 * <p>
	 * Throws an {@link IllegalStateException} if no route could be found,
	 * which happens if no charging stations can be reached with the current charge.
	 *
	 * @param from startLocation
	 * @param charge your charge when u are at targetLocation
	 * @param to targetLocation
	 * @param world the current world
	 * @return Quadruplet<>(
	 *		roundsFromStartLocationToTargetLocation,
	 *		chargeAtTargetLocation,
	 *		ordered Vector of ChargingStations on route from startLocation to targetLocation,
	 *		ordered Vector of chargingDurations related to the element of the Vector
	 *			of ChargingStations with the same index)
	 */
	public static Quadruplet<Integer, Integer, LinkedList<Intention>, LinkedList<Integer>>
	getChargingStationRoute(ILocation from, int charge, ILocation to, World world) {

		Tree<Triple<Integer, Integer, ChargingStation>> root =
				new Tree<Triple<Integer, Integer, ChargingStation>>();
		LinkedList<Intention> intentions = new LinkedList<>();
		LinkedList<ChargingStation> stations = new LinkedList<>();
		LinkedList<Integer> numberOfCharges = new LinkedList<>();

		int reachRounds = charge / 10;
		int fullReachRounds = world.ownRole().batteryCapacity / 10;

		int durationForChargingAfterwards = world.getDuration(to.getLocation(),
				world.getNearestFacility(to.getLocation(), YellowPages.getChargingStations()).getLocation());
		int rounds = world.getDuration(from.getLocation(), to.getLocation());
		int chargeAtTarget = 10 * (reachRounds - rounds);

		if (rounds + durationForChargingAfterwards <= reachRounds) {
			intentions.addLast(new GotoIntention(from, to, rounds));
			return new Quadruplet<Integer, Integer, LinkedList<Intention>, LinkedList<Integer>>
					(rounds, chargeAtTarget, intentions, numberOfCharges);
		}

		int minRounds = Integer.MAX_VALUE;
		Tree<Triple<Integer, Integer, ChargingStation>> tripleTree = null;

		Collection<? extends Facility> stationsInRange = world.getFacilitiesInRange(
				from.getLocation(), charge, YellowPages.getChargingStations());
		if (stationsInRange.isEmpty()) {
			throw new IllegalStateException(
					world.self.username + " " +
							"TODO No reachable charging stations, need to call emergency service: "
							+ charge + " charge, "
							+ YellowPages.getChargingStations().size() + " stations");
		}

		int bestDurationFrom = Integer.MAX_VALUE;
		int bestDurationTo = Integer.MAX_VALUE;
		int bestChargingDuration = Integer.MAX_VALUE;

		for (Facility f : stationsInRange) {
			ChargingStation cs = (ChargingStation) f;
			int durationFrom = world.getDuration(from.getLocation(), cs.getLocation());
			int durationTo = world.getDuration(cs.getLocation(), to.getLocation());
			int chargingDuration = getChargingDuration(10 * (reachRounds - durationFrom), cs, world);
			Tree<Triple<Integer, Integer, ChargingStation>> tempTripleTree =
					new Tree<>(new Triple<>(durationFrom + chargingDuration, chargingDuration, cs));
			root.addChild(tempTripleTree);
			rounds = durationFrom + chargingDuration + durationTo;
			if (durationFrom <= reachRounds &&
					durationTo + durationForChargingAfterwards <= fullReachRounds &&
					rounds < minRounds) {
				minRounds = rounds;
				bestDurationFrom = durationFrom;
				bestDurationTo = durationTo;
				bestChargingDuration = chargingDuration;
				chargeAtTarget = 10 * (fullReachRounds - durationTo);
				tripleTree = tempTripleTree;
			}
		}

		if (tripleTree != null) {
			intentions.addLast(new GotoIntention(from, tripleTree.data.c, bestDurationFrom));
			intentions.addLast(new ChargeIntention(bestChargingDuration, tripleTree.data.c));
			intentions.addLast(new GotoIntention(tripleTree.data.c, to, bestDurationTo));
			stations.add(tripleTree.data.c);
			numberOfCharges.add(bestChargingDuration);
			return new Quadruplet<Integer, Integer, LinkedList<Intention>, LinkedList<Integer>>
					(minRounds, chargeAtTarget, intentions, numberOfCharges);
		}

		while (tripleTree == null) {
			LinkedList<Tree<Triple<Integer, Integer, ChargingStation>>> leaves = root.getLeaves();

			for (Tree<Triple<Integer, Integer, ChargingStation>> l : leaves) {
				LinkedList<Tree<Triple<Integer, Integer, ChargingStation>>> path = l.getPathToRoot();
				rounds = l.data.a;
				ChargingStation chargingStation = l.data.c;

				for (Facility f : world.getFacilitiesInRange(chargingStation.getLocation(),
						world.ownRole().batteryCapacity, YellowPages.getChargingStations())) {
					ChargingStation cs = (ChargingStation) f;
					boolean alreadyVisited = false;
					for (Tree<Triple<Integer, Integer, ChargingStation>> t : path)
						if (t.data.c.name.equals(cs.name)) {
							alreadyVisited = true;
							break;
						}

					if (!alreadyVisited) {

						int durationFrom = world.getDuration
								(chargingStation.getLocation(), cs.getLocation());
						int durationTo = world.getDuration(cs.getLocation(), to.getLocation());
						int chargingDuration = getChargingDuration
								(10 * (fullReachRounds - durationFrom), cs, world);
						Tree<Triple<Integer, Integer, ChargingStation>> temp = new Tree<>
								(new Triple<Integer, Integer, ChargingStation>
										(rounds + durationFrom + chargingDuration, chargingDuration, cs));
						l.addChild(temp);
						rounds += durationFrom + chargingDuration + durationTo;
						if (durationFrom <= fullReachRounds &&
								durationTo + durationForChargingAfterwards <= fullReachRounds &&
								rounds < minRounds) {
							minRounds = rounds;
							chargeAtTarget = 10 * (fullReachRounds - durationTo);
							tripleTree = temp;
						}
					}
				}
			}
		}

		LinkedList<Tree<Triple<Integer, Integer, ChargingStation>>> bestRoute =
				tripleTree.getPathToRoot();

		LinkedList<Integer> durations = new LinkedList<>();
		durations.addAll(bestRoute.stream()
				.map(aL -> aL.data.a)
				.collect(Collectors.toList()));

		stations.addAll(bestRoute.stream()
				.map(aL -> aL.data.c)
				.collect(Collectors.toList()));

		numberOfCharges.addAll(bestRoute.stream()
				.map(aL -> aL.data.b)
				.collect(Collectors.toList()));

		int tempDuration = durations.get(0) - numberOfCharges.get(0);
		intentions.addLast(new GotoIntention(from, stations.get(0),
				tempDuration));
		intentions.addLast(new ChargeIntention(numberOfCharges.get(0), stations.get(0)));
		for(int i = 1; i < stations.size(); i++) {
			tempDuration = durations.get(i) - (durations.get(i - 1) + numberOfCharges.get(i));
			intentions.addLast(new GotoIntention(stations.get(i - 1), stations.get(i), tempDuration));
			intentions.addLast(new ChargeIntention(numberOfCharges.get(i), stations.get(i)));
		}
		tempDuration = minRounds - durations.getLast();
		intentions.addLast(new GotoIntention(stations.getLast(), to, tempDuration));

		return new Quadruplet<Integer, Integer, LinkedList<Intention>, LinkedList<Integer>>
				(minRounds, chargeAtTarget, intentions, numberOfCharges);
	}

	/**
	 * Calculates the number of ChargeIntention's that are required to be sended to get full charge.
	 *
	 * //TODO only calculates the time to get full charge
	 *
	 */
	private static int getChargingDuration(int charge, ChargingStation cs, World world) {
		int rounds = 0;
		int sum = charge;
		while(sum < world.ownRole().batteryCapacity) {
			sum += cs.chargingRate;
			rounds++;
		}
		return rounds;
	}

	/**
	 * Calculates the fastest route (including wayPoints) to the destination
	 *
	 * Considers charging
	 * Considers all possible arrangements of the wayPoints and chooses the fastest
	 *
	 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	 * !!! wayPoints may not be ChargingStations !!!
	 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	 *
	 * @param from startLocation
	 * @param charge charge at from
	 * @param to targetLocation
	 * @param wayPointsWithIntentions locations that must be visited before reaching targetLocation
	 *				with a corresponding Intention, which is sended when the location is reached
	 * @param world the current world
	 * @return Triple<>(
	 *		roundsFromStartLocationToTargetLocation,
	 *		chargeAtTargetLocation,
	 *		Activity (including ChargeIntentions)
	 */
	public static Triple<Integer, Integer, Activity>
	getFastestRouteVisitingAllWayPoints
	(ILocation from, int charge, ILocation to, LinkedList<Tuple<ILocation, Intention>> wayPointsWithIntentions, World world) {

		Triple<Integer, Integer, Activity> triple = new Triple<>();
		Activity activity = new Activity(world, null);
		Quadruplet<Integer, Integer, LinkedList<Intention>, LinkedList<Integer>> chargingStations;
		LinkedList<Integer> bestCharges = new LinkedList<>();

		if(wayPointsWithIntentions == null || wayPointsWithIntentions.size() == 0) {

			chargingStations = getChargingStationRoute(from, charge, to, world);
			bestCharges.addLast(chargingStations.b);
			activity.intentions.addAll(chargingStations.c);
			triple.setData(chargingStations.a, chargingStations.b, activity);
		} else {

			LinkedList<LinkedList<Tuple<ILocation, Intention>>> allArragements =
					getArrangementsWithAllWayPoints(wayPointsWithIntentions);
			LinkedList<Intention> intentions = new LinkedList<>();
			int minRounds = Integer.MAX_VALUE;
			for(LinkedList<Tuple<ILocation, Intention>> arrangement : allArragements) {
				int currentRounds = 0;
				int currentCharge = charge;
				LinkedList<ILocation> locations = new LinkedList<>();
				LinkedList<Integer> charges = new LinkedList<>();
				intentions = new LinkedList<>();

				chargingStations = getChargingStationRoute
						(from, currentCharge, arrangement.get(0).a, world);
				currentRounds += chargingStations.a;
				currentCharge = chargingStations.b;

				locations.addLast(arrangement.get(0).a);
				charges.addLast(currentCharge);
				intentions.addAll(chargingStations.c);
				intentions.addLast(arrangement.get(0).b);

				for(int i = 1; i < arrangement.size(); i++) {
					chargingStations = getChargingStationRoute
							(arrangement.get(i - 1).a, currentCharge, arrangement.get(i).a, world);
					currentRounds += chargingStations.a;
					currentCharge = chargingStations.b;

					locations.addLast(arrangement.get(i).a);
					charges.addLast(currentCharge);
					intentions.addAll(chargingStations.c);
					intentions.addLast(arrangement.get(i).b);
				}

				chargingStations = getChargingStationRoute
						(arrangement.get(arrangement.size() - 1).a, currentCharge, to, world);
				currentRounds += chargingStations.a;
				currentCharge = chargingStations.b;

				locations.addLast(to);
				charges.addLast(currentCharge);
				intentions.addAll(chargingStations.c);

				if(minRounds > currentRounds) {
					minRounds = currentRounds;
					bestCharges = charges;
					activity = new Activity(world, null);
					activity.intentions.addAll(intentions);
					triple.setData(currentRounds, currentCharge, activity);
				}
			}
		}

		return triple;
	}

	private static LinkedList<LinkedList<Tuple<ILocation, Intention>>> getArrangementsWithAllWayPoints
			(LinkedList<Tuple<ILocation, Intention>> wayPointsWithIntentions) {

		LinkedList<LinkedList<Tuple<ILocation, Intention>>> list = new LinkedList<>();
		LinkedList<Tuple<ILocation, Intention>> visited = new LinkedList<>();
		arrangeAll(list, visited, wayPointsWithIntentions);
		return list;
	}

	private static void arrangeAll(LinkedList<LinkedList<Tuple<ILocation, Intention>>> list,
								   LinkedList<Tuple<ILocation, Intention>> visited,
								   LinkedList<Tuple<ILocation, Intention>> unvisited) {

		if(unvisited.isEmpty())
			list.add(visited);
		else
			for(Tuple<ILocation, Intention> li : unvisited) {
				LinkedList<Tuple<ILocation, Intention>> wpv = new LinkedList<>(visited);
				LinkedList<Tuple<ILocation, Intention>> wpuv = new LinkedList<>(unvisited);
				wpv.add(li);
				wpuv.remove(li);
				arrangeAll(list, wpv, wpuv);
			}
	}

	/**
	 * Calculates the fastest route considering some wayPoints
	 *
	 * for each ( LinkedList<Tuple<ILocation,Intention>> c: wayPointsWithIntentions)
	 *		only one ILocation of c must be targeted
	 *
	 *	!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	 *	!!! wayPoints may not be ChargingStations !!!
	 *	!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	 *
	 * @param from startLocation
	 * @param charge charge at from
	 * @param to targetLocation
	 * @param wayPointsWithIntentions	one of each collection in wayPoints must be visited
	 *									before reaching targetLocation
	 *									with a corresponding Intention,
	 *									which is sended when the location is reached
	 * @param world the current world
	 * @return Quadruplet<>(
	 *		roundsFromStartLocationToTargetLocation,
	 *		chargeAtTargetLocation,
	 *		Activity (including ChargeIntentions)
	 */
	public static Triple<Integer, Integer, Activity>
	getFastestRouteVisitingSomeWayPoints
	(ILocation from, int charge, ILocation to,
	 LinkedList<Tuple<LinkedList<ILocation>, Intention>> wayPointsWithIntentions, World world) {

		Triple<Integer, Integer, Activity> triple = null;
		LinkedList<LinkedList<Tuple<ILocation, Intention>>> arrangements = getArrangementsWithSomeWayPoints(wayPointsWithIntentions);
		int minRounds = Integer.MAX_VALUE;
		for(LinkedList<Tuple<ILocation, Intention>> arrangement : arrangements) {
			Triple<Integer, Integer, Activity> temp =
					getFastestRouteVisitingAllWayPoints(from, charge, to, arrangement, world);
			if(temp.a < minRounds) {
				minRounds = temp.a;
				triple = temp;
			}
		}

		return triple;
	}

	private static LinkedList<LinkedList<Tuple<ILocation, Intention>>> getArrangementsWithSomeWayPoints
			(LinkedList<Tuple<LinkedList<ILocation>, Intention>> wayPointsWithIntentions) {
		LinkedList<LinkedList<Tuple<ILocation, Intention>>> list = new LinkedList<>();
		LinkedList<Tuple<ILocation, Intention>> visited = new LinkedList<>();
		arrangeSome(list, wayPointsWithIntentions, visited);
		return list;
	}

	private static void arrangeSome(LinkedList<LinkedList<Tuple<ILocation, Intention>>> list,
									LinkedList<Tuple<LinkedList<ILocation>, Intention>> wayPoints,
									LinkedList<Tuple<ILocation, Intention>> visited) {

		if(wayPoints.isEmpty())
			list.add(visited);
		else {
			Tuple<LinkedList<ILocation>, Intention> locations = wayPoints.iterator().next();
			LinkedList<Tuple<LinkedList<ILocation>, Intention>> newWayPoints = new LinkedList<>(wayPoints);
			newWayPoints.remove(locations);
			for(ILocation li : locations.a) {
				LinkedList<Tuple<ILocation, Intention>> newVisited = new LinkedList<>(visited);
				newVisited.add(new Tuple<>(li, locations.b));
				arrangeSome(list, newWayPoints, newVisited);
			}
		}
	}
}
