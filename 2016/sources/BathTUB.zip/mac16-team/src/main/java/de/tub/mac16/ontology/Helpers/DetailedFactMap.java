package de.tub.mac16.ontology.Helpers;

import de.tub.mac16.ontology.Facilities.ChargingStation;
import de.tub.mac16.ontology.Facilities.Shop;

import java.util.HashMap;

public class DetailedFactMap<K, V extends DetailedFact> extends HashMap<K, V> {

	public V put(K key, V value) {
		V oldValue = this.get(key);

		if (oldValue != null) {
			if (value instanceof Shop) {
				Shop newShop = ((Shop) value);
				Shop oldShop = ((Shop) oldValue);
				if (newShop.detailedFact) {
					if (newShop.simulationStep < oldShop.simulationStep) return oldValue;
					if (newShop.simulationStep == oldShop.simulationStep) {
						if (newShop.calculatedFact && !oldShop.calculatedFact) return oldValue;
					}
				} else if (oldShop.detailedFact) return oldValue;
			}
			if (value instanceof ChargingStation) {
				ChargingStation newChargingStation = ((ChargingStation) value);
				ChargingStation oldChargingStation = ((ChargingStation) oldValue);
				if (newChargingStation.detailedFact) {
					if (newChargingStation.simulationStep <= oldChargingStation.simulationStep) return oldValue;
				} else if (oldChargingStation.detailedFact) return oldValue;
			}
		}
		return super.put(key, value);
	}
}
