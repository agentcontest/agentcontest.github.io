package de.tub.mac16.ontology.Intentions;

import de.tub.mac16.bean.DefaultDecisionBean;
import de.tub.mac16.connection.MessageConstants;
import de.tub.mac16.ontology.AgentState;
import de.tub.mac16.ontology.ItemWithQuantity;
import de.tub.mac16.ontology.World;

public class ReceiveIntention extends Intention {
	private final ItemWithQuantity item;
	private AgentState givingAgent;
	private String trueAction;
	private boolean tryToRecieve = false;
	private boolean recieveSuccess = false;


	public ReceiveIntention(ItemWithQuantity itemWithQuantity, AgentState fromAgent) {
		super(MessageConstants.ACTION_RECEIVE, "");
		this.item = itemWithQuantity;
		givingAgent = fromAgent;
		trueAction = action;
	}

	@Override
	public int getDuration() {
		// TODO wait for partner
		return 1;
		//throw new IllegalArgumentException("Not implemented");
	}

	@Override
	public int getCapacityDelta() {
		return -item.getVolume();
	}

	/**
	 * override this if intention is depending on some value in world
	 * (e.g. recieve only when other Agent gives .....)
	 *
	 * @param world
	 */
	@Override
	public void prepareToBeSend(World world) {
		if (world.self.getLocation().equals(givingAgent.getLocation())) {
			action = trueAction;
			tryToRecieve = true;
			log.debug("Try to recieve from " + givingAgent.username);
		} else {
			action = MessageConstants.ACTION_SKIP;
			tryToRecieve = false;
		}
	}

	/**
	 * Override this if the intention does not need to
	 * be run to be completed (eg. goto), or if it needs
	 * additional checks.
	 *
	 * @param world
	 */
	@Override
	public boolean isComplete(World world) {
		return recieveSuccess;
	}

	/**
	 * Called by {@link DefaultDecisionBean}
	 * to process the result from the server.
	 *
	 * @param result result of this action
	 * @param world
	 */
	@Override
	public void onResult(String result, World world) {
		super.onResult(result, world);
		if (tryToRecieve && world.self.lastActionResult.equals(MessageConstants.RESULT_SUCCESSFUL)) {
			recieveSuccess = true;
			log.debug("Recieved from " + givingAgent.username);
		}
	}
}
