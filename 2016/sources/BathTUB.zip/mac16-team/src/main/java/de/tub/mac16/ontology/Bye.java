package de.tub.mac16.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;

public class Bye implements IFact {

	private static final long serialVersionUID = 8260224997386794780L;

}
