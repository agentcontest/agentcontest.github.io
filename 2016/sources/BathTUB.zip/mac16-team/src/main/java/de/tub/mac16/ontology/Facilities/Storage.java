/**
 *
 */
package de.tub.mac16.ontology.Facilities;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac16.ontology.*;
import de.tub.mac16.ontology.Intentions.Intention;
import de.tub.mac16.ontology.Intentions.RetrieveIntention;

import java.util.HashMap;
import java.util.Map;

public class Storage extends Facility implements IFact, IPlaceWithItems, ILocation {

	private static final long serialVersionUID = -7921381933434345941L;

	public int totalCapacity;
	public int usedCapacity;
	public int price;
	private Workshop closestWorkshop = null;

	public Map<Item, Integer> stored;

	public Map<Item, Integer> delivered;

	public static synchronized Storage getOrCreateStorage(String name, Location location, int totalCapacity, int usedCapacity, int price) {
		if (YellowPages.getFacility(name) == null)
			YellowPages.putFacility(new Storage(name, location, totalCapacity, usedCapacity, price));
		return YellowPages.getFacility(name);
	}

	private Storage(String name, Location location, int totalCapacity, int usedCapacity, int price) {
		super(name, location);
		this.totalCapacity = totalCapacity;
		this.usedCapacity = usedCapacity;
		this.price = price;

		this.stored = new HashMap<>();
		this.delivered = new HashMap<>();
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public Integer getItemQuantity(Item item) {
		return stored.get(item);
	}

	@Override
	public Integer getItemCost(Item item) {
		if (stored.get(item) == null) return null;

		return stored.get(item);
	}

	@Override
	public Iterable<Item> getAvailableItems() {
		return stored.keySet();
	}

	@Override
	public Intention getItemIntention(ItemWithQuantity itemWithQuantity) {
		return new RetrieveIntention(itemWithQuantity);
	}

	public int getRemainingCapacity() {
		return totalCapacity - usedCapacity;
	}

	public synchronized Workshop getClosestWorkshop(World world) {
		if (closestWorkshop == null)
			closestWorkshop = (Workshop) world.getNearestFacility(this.getLocation(), YellowPages.getWorkshops(), "Car");
		return closestWorkshop;
	}
}
