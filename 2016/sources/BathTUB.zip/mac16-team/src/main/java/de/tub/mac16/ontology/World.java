package de.tub.mac16.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac16.LogUtil;
import de.tub.mac16.ontology.Activities.Activity;
import de.tub.mac16.ontology.Activities.JobActivity;
import de.tub.mac16.ontology.Activities.MetaActivity;
import de.tub.mac16.ontology.Facilities.Facility;
import de.tub.mac16.ontology.Facilities.Shop;
import de.tub.mac16.ontology.Facilities.YellowPages;
import de.tub.mac16.ontology.Intentions.BidForJobIntention;
import de.tub.mac16.ontology.Jobs.*;
import de.tub.mac16.routing.CityMap;
import org.apache.log4j.Logger;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * The place where the agent stores everything it knows.
 * <p>
 * World is not serializable, but many of its components are.
 * <p>
 * The update methods can both be called multiple times, which
 * is expected for {@link Perception}, but allowing multiple
 * {@link SimStart} makes the agent fault tolerant against
 * crashes of {@link de.tub.mac16.bean.DefaultDecisionBean}
 * or {@link de.tub.mac16.bean.ServerCommunicationBean},
 * and allows information to be kept despite reconnections.
 */
public class World {
	private final String username;
	private int simStartCounter = 0;
	private boolean gotAPerceptionAfterSimStart = false;

	public String worldId = null;
	public int totalSimulationSteps;
	public int seedCapital;
	public final Map<String, Item> items = new HashMap<>();
	public CityMap cityMap;
	//public final HashMap<String, Role> roles = new HashMap<>(4);
	public AgentState self;

	//public final Map<String, AgentState> teamAgents = new HashMap<>();
	public final Map<String, EnemyAgentState> enemyAgents = new HashMap<>();
	public EnemyTeamState enemyTeamState = new EnemyTeamState(seedCapital);

	//public final Map<String, Facility> facilities = new HashMap<>();
	//public final DetailedFactMap<String, ChargingStation> chargingStations = new DetailedFactMap<>();
	//public final DetailedFactMap<String, Shop> shops = new DetailedFactMap<>();
	//public final List<Storage> storages = new LinkedList<>();
	//public final List<Workshop> workshops = new LinkedList<>();
	//public final List<Dump> dumps = new LinkedList<>();

	public MetaActivity metaActivity = new MetaActivity();
	public final Map<String, JobActivity> ownJobActivities = new HashMap<>();

	private LinkedList<AuctionJob> waitingJobs = new LinkedList<>();

	private int teamMoney = 0;

	public String requestId;
	public int simulationStep = -1;

	private Logger log;

	public static double proximity = 0.;

	public World(String username) {
		this.username = username;
		log = LogUtil.get(this, username);
	}

	private boolean isOwnPerception = false;

	/**
	 * @return true iff at least one {@link Perception} was received after a {@link SimStart}
	 */
	public boolean isReady() {
		return gotAPerceptionAfterSimStart;
	}

	////////////////////////
	///// job planning /////
	////////////////////////

	public JobProposal getJobProposal(Job job, ItemWithQuantity item) {
		ownJobActivities.putIfAbsent(job.id, new JobActivity(job, this, metaActivity.getCurrentActivity()));
		JobActivity jobAct = ownJobActivities.get(job.id);
		ItemBatch itemBatch = getItemAvailability(Optional.ofNullable(jobAct.getLastLocation()).orElse(self.currentLocation), item);

		itemBatch.rounds += jobAct.getDuration() + metaActivity.getDuration();

		// TODO always delivers after buying, change to a smarter plan
		Location jobFacility = YellowPages.getFacility(job.storageId).getLocation();
		itemBatch.rounds += getDuration(itemBatch.place.getLocation(), jobFacility);
		// TODO maybe add charging time and cost too?

		// pick the largest quantity that still fits
		if (itemBatch.item.volume > 0) { // wow, volume can really be 0, and we would divide by zero
			int capacityLeft = ownRole().loadCapacity;
			capacityLeft -= self.load - metaActivity.getCapacityDelta() - jobAct.getCapacityDelta();
			int quantityLeft = capacityLeft / itemBatch.item.volume;
			itemBatch.quantity = Math.min(itemBatch.quantity, quantityLeft);
		}

		if ((metaActivity.getDuration() + jobAct.getDuration() + simulationStep) > job.end) return new JobProposal(null, job.id, self.username, jobAct.getCost());
		return new JobProposal(itemBatch, job.id, self.username, jobAct.getCost());
	}

	/**
	 * @param start the targetLocation to calculate from
	 * @param item  the item to calculate for
	 * @return the fastest way to get any quantity of that item type
	 */
	public ItemBatch getItemAvailability(Location start, ItemWithQuantity item) {
		assert item.quantity > 0;

		// TODO get item from storages, crafting
		Integer quantity = self.availableItems.get(item.item);
		if (self.availableItems.containsKey(item.item) && quantity > 0) {
			log.debug("will provide Items myself" + item + ", own quantity:" + quantity);
			return new ItemBatch(item.item, quantity, self, 0, 0);
		}

		Optional<Shop> fastestShop = streamShopsSellingItem(item.item).min(
				(o1, o2) -> getDuration(start, o1.getLocation()) - getDuration(start, o2.getLocation()));

		if (!fastestShop.isPresent()) {
			// all items should be buyable...? - this will be solved for sure with crafting
			throw new IllegalStateException(
					"no shop sells " + item + ", buyable items: " + YellowPages.getShops().stream()
					.flatMap(shop -> shop.stock.keySet().stream().map(i -> i.name))
					.distinct().sorted().collect(Collectors.toList()));
		}
		IPlaceWithItems place = fastestShop.get();

		// Quantitiy in place is null if we don't know how many items are in stock
		// -> defaults to full quantity if unknown stock
		// Quantitiy in place is 0 if item is not available in the shop
		int quantityInPlace = Optional.ofNullable(place.getItemQuantity(item.item)).orElse(item.quantity);
		if (quantityInPlace == 0) return null;
		int cost = Optional.ofNullable(place.getItemCost(item.item)).orElse(Integer.MAX_VALUE);

		int duration = getDuration(start, place.getLocation());
		return new ItemBatch(item.item, quantityInPlace, place, cost, duration);
	}

	/////////////////////////////
	///// movement planning /////
	/////////////////////////////

	public Role ownRole() {
		return Role.getRole(self.roleName);
	}

	public int getDuration(Location from, Location to, String rolename) {
		Integer length = CityMap.getRouteLength(from, to, rolename);
		if (length == null) return Integer.MAX_VALUE;
		int sum = length;
		int rounds = 0;
		while (sum > 0) {
			sum -= ownRole().speed;
			rounds++;
		}
		return rounds;
		//TODO test if ceilDiv works
//		return ceilDiv(length, ownRole().speed);
	}

	public int getDuration(Location from, Location to) {
		Integer length = CityMap.getRouteLength(from, to, ownRole().name);
		if (length == null) return Integer.MAX_VALUE;
		int sum = length;
		int rounds = 0;
		while ( sum > 0) {
			sum -= ownRole().speed;
			rounds++;
		}
		return rounds;
		//TODO test if ceilDiv works
//		return ceilDiv(length, ownRole().speed);
	}

	public Facility getNearestFacility(Location currentLocation, Iterable<? extends Facility> facilities, String rolename) {
		Facility nearestFacility = null;
		int minDuration = Integer.MAX_VALUE;
		for (Facility facility : facilities) {
			int duration = getDuration(currentLocation, facility.getLocation(), rolename);
			if (duration < minDuration) {
				minDuration = duration;
				nearestFacility = facility;
			}
		}
		return nearestFacility;
	}

	public Facility getNearestFacility(Location currentLocation, Iterable<? extends Facility> facilities) {
		Facility nearestFacility = null;
		int minDuration = Integer.MAX_VALUE;
		for (Facility facility : facilities) {
			int duration = getDuration(currentLocation, facility.getLocation());
			if (duration < minDuration) {
				minDuration = duration;
				nearestFacility = facility;
			}
		}
		return nearestFacility;
	}

	public Facility getNearestFacility(Location from, Stream<? extends Facility> facilities) {
		// we annotate each facility with its distance, using an object array to represent the tuple
		return (Facility) facilities
				.map(f -> new Object[]{f, getDuration(from, f.getLocation())})
				.min((a, b) -> (int) a[1] - (int) b[1])
				.orElse(null)[0];
	}

	public Set<? extends Facility> getFacilitiesInRange(Location point, int charge, Collection<? extends Facility> pointsOfInterest) {
		int batteryDuration = (charge / 10);
		return pointsOfInterest.stream()
				.filter(facility -> getDuration(point, facility.getLocation()) <= batteryDuration)
				.collect(Collectors.toSet());
	}

	public Stream<Shop> streamShopsSellingItem(Item item) {
		return YellowPages.getShops().stream().filter(shop -> {
			Integer itemQuantity = shop.getItemQuantity(item);
			return itemQuantity == null || itemQuantity > 0;
		});
	}

	//////////////////
	///// update /////
	//////////////////

	public void update(IFact fact) {
		// the order matters, special (inheriting) classes before general (inherited-from) classes
		if (fact instanceof SimStart) update((SimStart) fact);
		else if (fact instanceof Perception) update((Perception) fact);
		else if (fact instanceof AgentState) update((AgentState) fact);
			//else if (fact instanceof EnemyAgentState) update((EnemyAgentState) fact);
			//else if (fact instanceof BasicAgentState) update((BasicAgentState) fact);
			//else if (fact instanceof Shop) update((Shop) fact);
			//else if (fact instanceof Facility) update((Facility) fact);
			//else if (fact instanceof Role) update((Role) fact);
		else if (fact instanceof JobProposalRequest) update((JobProposalRequest) fact);
		else if (fact instanceof JobAssignment) update((JobAssignment) fact);
		else if (fact instanceof JobExecutionStart) update((JobExecutionStart) fact);
		//else throw new IllegalArgumentException("Unknown class " + fact.getClass());
	}

	private void update(JobProposalRequest request) {
		JobProposal proposal = getJobProposal(request.job, request.item);
		JobPlanner.getInstance().addProposal(proposal, AgentState.getOwnTeam(self).size());
	}

	private void update(JobAssignment assignment) {
		ItemBatch batch = assignment.proposal.itemBatch;
		if (batch.place.getName().equals(self.getName())) {
			ownJobActivities.get(assignment.job.id).deliverJob(assignment.job, batch.getVolume()); // TODO always delivers after buying, change to a smarter plan
			self.availableItems.put(batch.item, self.availableItems.get(batch.item) - batch.quantity);
		} else {
			ownJobActivities.get(assignment.job.id)
					.buyItem(batch) // TODO other ways to get items (crafting, agent storage, storages etc.)
					.deliverJob(assignment.job, batch.getVolume()); // TODO always delivers after buying, change to a smarter plan
		}
	}

	private void update(JobExecutionStart msg) {
		Job job = msg.job;
		if (job instanceof AuctionJob) {
			AuctionJob auctionJob = (AuctionJob) job;
			int bid = auctionJob.maxBid - 1;
			log.debug("Bidding " + bid + " for AuctionJob " + job.id);
			Activity biddingActivity = new Activity(this, null);
			biddingActivity.intentions.add(new BidForJobIntention(auctionJob, bid));
			metaActivity.addNewActivityAtFront(biddingActivity);
			waitingJobs.add(auctionJob);
		} else {
			log.debug("Starting Priced Job " + job);
			metaActivity.addActivity(ownJobActivities.get(job.id));
		}
	}

	public synchronized void update(SimStart simStart) {
		gotAPerceptionAfterSimStart = false;
		simStartCounter++;

		if (self != null) {
			log.warn("Received " + simStartCounter + " SimStart messages");
		}

		worldId = simStart.worldId;
		totalSimulationSteps = simStart.steps;
		seedCapital = simStart.seedCapital;

		simStart.items.stream().forEach(item -> items.put(item.name, item));
		//roles.put(simStart.role.name, simStart.role);

		if (self == null) {
			self = AgentState.getOrCreateAgentState(username, simStart.teamName, simStart.role.name);
			//self = AgentState.getAgent(username);
			//teamAgents.put(username, self);
		}

		// TODO infer cellSize and proximity from server messages
		cityMap = new CityMap(simStart.map, 0.001);
	}

	public synchronized void update(Perception perception) {
		isOwnPerception = username.equals(perception.self.username); // my perception, from server
		if (isOwnPerception) {
			requestId = perception.requestId;
			if (simulationStep < perception.simulationStep) {
				simulationStep = perception.simulationStep;
			} else {
				log.error("Time is going backwards, simulationStep: old=" + simulationStep + " >= new=" + perception.simulationStep);
			}
		}

		// Update team and enemy agents
		perception.agents.forEach(this::update);

		// Update self or team agent
		//teamAgents.get(perception.self.username).update(perception.self);

		// Update Facilities
		// needs to happen after enemies get updated
		perception.facilities.forEach(this::update);

		updateJobs(perception);

		gotAPerceptionAfterSimStart = gotAPerceptionAfterSimStart || (isOwnPerception && simStartCounter > 0);

		if (!gotAPerceptionAfterSimStart) {
			log.debug("Received Perception before SimStart: " + perception);
		}

		if (perception.teamState.money > teamMoney) {
			log.debug("MONEY PLUS! old: " + teamMoney + " new: " + perception.teamState.money);
		}
		teamMoney = perception.teamState.money;
		//Not working, distance between self.inFacility and self is allways 0.0
		//if(self.inFacility != null)updateProximity(self.inFacility);
	}

//	private synchronized void updateProximity(Facility facility) {
//		log.debug(self.getName() + " in facility " + facility.name);
//		double ownLat = self.getLocation().latitude;
//		double ownLon = self.getLocation().longitude;
//		double shopLat = facility.getLocation().latitude;
//		double shopLon = facility.getLocation().longitude;
//		double difLat = Math.abs(ownLat - shopLat);
//		double difLon = Math.abs(ownLon - shopLon);
//		double maxDif = Math.max(difLat, difLon);
//		log.debug("maxDiff: " + new Double(maxDif).toString());
//			if (maxDif > proximity) {
//				log.debug(self.getName() + " Location: " + self.getLocation().toString());
//				log.debug("shop " + facility.name + " Location: " + facility.getLocation().toString());
//				log.debug("Updating proximity, old proximity: " + proximity + " ,new proximity: " + maxDif);
//				proximity = maxDif;
//		}
//	}

	public void updateJobs(Perception perception) {
		for (Job job : perception.availableJobs) {
			JobPlanner.getInstance().addJob(job);
		}

		Iterator wji = waitingJobs.iterator();
		while (wji.hasNext()) {
			AuctionJob waitingJob = (AuctionJob) wji.next();
			for (Job jobTaken : perception.teamState.jobsTaken) {
				if (waitingJob.equals(jobTaken)) {
					log.debug("Starting Auction Job " + jobTaken.id);
					metaActivity.addActivity(ownJobActivities.get(waitingJob.id));
					wji.remove();
				}
			}
		}

		// TODO detect cancelled jobs, remove their activity
		// use metaActivity.removeActivity(ownJobActivities.get(failedJob.id))
	}

	//	public synchronized void update(BasicAgentState agent) {
//		if (agent instanceof AgentState) update((AgentState) agent);
//		else if (agent instanceof EnemyAgentState) update((EnemyAgentState) agent);
//		else if (self.teamName.equals(agent.teamName)) {
//			AgentState teamAgent = teamAgents.get(agent.username);
//			if (teamAgent == null) {
//				teamAgents.put(agent.username, new AgentState(agent));
//			} else {
//				teamAgent.update(agent);
//			}
//		} else {
//			update(new EnemyAgentState(agent, enemyTeamState, roles.get(agent.roleName)));
//		}
//	}
//
	public synchronized void update(AgentState agent) {
		/**TODO:dirty hack !!!!
		 */
		if (this.self.username.equals(agent.getName())) agent.setWorld(this);
//		if (!self.teamName.equals(agent.teamName))
//			throw new IllegalArgumentException("enemy is AgentState instance: " + agent.username);
//
//		AgentState teamAgent = teamAgents.get(agent.username);
//		if (teamAgent == null) {
//			teamAgents.put(agent.username, new AgentState(agent));
//		} else {
//			teamAgent.update(agent);
//		}
	}

	public synchronized void update(EnemyAgentState agent) {
		if (self.teamName.equals(agent.teamName))
			throw new IllegalArgumentException("enemy in our team: " + agent.username);

		if (!enemyAgents.containsKey(agent.username)) {
			enemyAgents.put(agent.username, new EnemyAgentState(agent, enemyTeamState, Role.getRole(agent.roleName)));
		} else {
			// TODO use EnemyAgent.update()
			enemyAgents.get(agent.username).lastLocation = enemyAgents.get(agent.username).getLocation();
			enemyAgents.get(agent.username).currentLocation = agent.getLocation();
		}
	}

//	public synchronized void update(Facility fac) {
//		facilities.put(fac.name, fac);
//		if (fac instanceof ChargingStation) chargingStations.put(fac.name, (ChargingStation) fac);
//		else if (fac instanceof Shop) update((Shop) fac);
//		else if (fac instanceof Storage) storages.add((Storage) fac);
//		else if (fac instanceof Workshop) workshops.add((Workshop) fac);
//		else if (fac instanceof Dump) dumps.add((Dump) fac);
//		else {
//			throw new IllegalArgumentException("Unknown facility type " + fac.getClass() + " " + fac);
//		}
//	}

//	public synchronized void update(Shop newShop) {
//		if (shops.get(newShop.name) != null && !newShop.detailedFact && shops.get(newShop.name).detailedFact && shops.get(newShop.name).simulationStep < simulationStep) {
//			Shop calculatedShop = new Shop(simulationStep, newShop.name, newShop.getLocation());
//			calculatedShop.calculatedFact = true;
//			calculatedShop.detailedFact = true;
//			calculatedShop.stock = shops.get(newShop.name).stock;
//			for (Shop.ShopStock shopStock : calculatedShop.stock.values()) {
//				if (shopStock != null && shopStock.restock != 0 && simulationStep % shopStock.restock == 0) {
//					shopStock.quantity += 1;
//					shopStock.minQuantity += 1;
//				}
//			}
//			shops.put(calculatedShop.name, calculatedShop);
//		} else {
//			shops.put(newShop.name, newShop);
//			if (isOwnPerception && newShop.detailedFact) {
//				double ownLat = self.getLocation().latitude;
//				double ownLon = self.getLocation().longitude;
//				double shopLat = newShop.getLocation().latitude;
//				double shopLon = newShop.getLocation().longitude;
//				double difLat = Math.abs(ownLat - shopLat);
//				double difLon = Math.abs(ownLon - shopLon);
//				double maxDif = Math.max(difLat, difLon);
//				synchronized (this) {
//					if (maxDif > proximity) {
//						log.debug(self.getName() + " Location: " + self.getLocation().toString());
//						log.debug("shop " + calculatedShop.getName() + " Location: " + calculatedShop.getLocation().toString());
//						log.debug("Updating proximity, old proximity: " + proximity + " ,new proximity: " + maxDif);
//						proximity = maxDif;
//					}
//				}
//			}
//		}
//	}

	//public synchronized void update(Role role) {
	//	roles.put(role.name, role);
	//}

}
