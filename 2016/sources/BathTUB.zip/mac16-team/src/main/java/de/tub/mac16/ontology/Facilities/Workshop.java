package de.tub.mac16.ontology.Facilities;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac16.ontology.ILocation;
import de.tub.mac16.ontology.Location;

public class Workshop extends Facility implements IFact, ILocation {

	private static final long serialVersionUID = -5835008537373333799L;

	public int price;

	private Workshop(String name, Location location, int price) {
		super(name, location);
		this.price = price;
	}

	public static synchronized Workshop getOrCreateWorkshop(String name, Location location, int price) {
		if (YellowPages.getFacility(name) == null) YellowPages.putFacility(new Workshop(name, location, price));
		return YellowPages.getFacility(name);
	}
}
