package de.tub.mac16.ontology;

/**
 * Created by oguzserbetci on 19/06/16.
 */
public class HasLocation {
}
