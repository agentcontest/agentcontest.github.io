package de.tub.mac16.bean;

import de.dailab.jiactng.agentcore.IAgentBean;
import de.dailab.jiactng.agentcore.action.AbstractMethodExposingBean;
import de.dailab.jiactng.agentcore.action.Action;
import de.dailab.jiactng.agentcore.comm.ICommunicationAddress;
import de.dailab.jiactng.agentcore.comm.message.IJiacMessage;
import de.tub.mac16.LogUtil;
import de.tub.mac16.connection.ActionFactory;
import de.tub.mac16.connection.MessageConstants;
import de.tub.mac16.ontology.Activities.DiscoverActivity;
import de.tub.mac16.ontology.Facilities.YellowPages;
import de.tub.mac16.ontology.Intentions.Intention;
import de.tub.mac16.ontology.Intentions.SkipIntention;
import de.tub.mac16.ontology.Jobs.JobPlanner;
import de.tub.mac16.ontology.World;
import org.w3c.dom.Document;

public class DefaultDecisionBean extends AbstractMethodExposingBean implements IDecisionBean {

	private World world;
	PerceptionBean perceptionBean;
	ServerCommunicationBean serverCommunicationBean;
	Action sendAction;
	private long deadline = Long.MAX_VALUE;

	private boolean discoverymode = true;

	@Override
	public void setWorld(World world) {
		this.world = world;
	}

	@Override
	public void doInit() throws Exception {
		setLog(LogUtil.get(this));
		super.doInit();
	}

	@Override
	public void doStart() {
		for (IAgentBean ab : thisAgent.getAgentBeans()) {
			if (ab instanceof PerceptionBean) {
				perceptionBean = (PerceptionBean) ab;
				if (perceptionBean.world != null) world = perceptionBean.world;
			}
			if (ab instanceof ServerCommunicationBean) {
				serverCommunicationBean = (ServerCommunicationBean) ab;
				setLog(LogUtil.get(this, serverCommunicationBean.username));
			}
		}
		// retrieving needed actions from own CommunicationBean
		sendAction = memory.read(new Action(
				"de.dailab.jiactng.agentcore.comm.ICommunicationBean#send",
				null, new Class[]{IJiacMessage.class,
				ICommunicationAddress.class}, null));
		if (sendAction == null)
			throw new RuntimeException("Could not find Communication");
	}

	@Override
	public void decide() {
		deadline = System.currentTimeMillis() + 1000; // TODO calculate based on request

		if (!world.isReady()) {
			log.error("Cannot decide, world is not ready!");
			return;
		}

		if (discoverymode) {
			discoverymode = false;
			if (YellowPages.getShops().stream().filter(shop -> shop.detailedFact == false).count() > 0)
				world.metaActivity.addActivity(new DiscoverActivity(world));
			else log.error(world.self.getName() + " DefaultDecisionBean has crashed");
		}

		if (world.self.lastActionResult.equals(MessageConstants.RESULT_FAILED_JOB_STATUS)) {
			world.metaActivity.removeActivity(world.metaActivity.getCurrentActivity());
		}

		log.debug(world.self.getName() + "Number of activities in metaactivity: " + world.metaActivity.activities.size());
//		if(	//true
//
//			world.self.username.equals("a5")  /*||
//			world.self.username.equals("a6")  ||
//			world.self.username.equals("a7")  ||
//			world.self.username.equals("a8")  ||
//			world.self.username.equals("a9")  ||
//			world.self.username.equals("a10") ||
//			world.self.username.equals("a11") ||
//			world.self.username.equals("a12")
//			*/
//		   	) {
//
//			if(world.simulationStep == 1) {
//				// test getFastestRouteVisitingAllWayPoints
//				/*
//				LinkedList<Tuple<ILocation, Intention>> wayPointsWithIntentions = new LinkedList<>();
//				wayPointsWithIntentions.add(new Tuple<ILocation, Intention>(world.facilities.get("shop4"), new SkipIntention()));
//				wayPointsWithIntentions.add(new Tuple<ILocation, Intention>(world.facilities.get("shop3"), new SkipIntention()));
//				wayPointsWithIntentions.add(new Tuple<ILocation, Intention>(world.facilities.get("shop2"), new SkipIntention()));
//				wayPointsWithIntentions.add(new Tuple<ILocation, Intention>(world.facilities.get("shop1"), new SkipIntention()));
//
//
//				Triple<Integer, Integer, Activity>
//					triple = new Activity(world, null).
//						getFastestRouteVisitingAllWayPoints
//						(world.self.currentLocation, world.self.charge,
//					   	world.facilities.get("shop0"), wayPointsWithIntentions, world);
//				*/
//
//				// test getFastestRouteVisitingSomeWayPoints
//				LinkedList<Tuple<LinkedList<ILocation>, Intention>> wayPoints = new LinkedList<>();
//				LinkedList<ILocation> locs_1 = new LinkedList<>();
//				locs_1.add(world.facilities.get("shop1"));
//				locs_1.add(world.facilities.get("shop2"));
//				LinkedList<ILocation> locs_2 = new LinkedList<>();
//				locs_2.add(world.facilities.get("shop3"));
//				locs_2.add(world.facilities.get("shop4"));
//				Tuple<LinkedList<ILocation>, Intention> locations_1 = new Tuple<>(locs_1, new SkipIntention());
//				Tuple<LinkedList<ILocation>, Intention> locations_2 = new Tuple<>(locs_2, new SkipIntention());
//				wayPoints.add(locations_1);
//				wayPoints.add(locations_2);
//				Triple<Integer, Integer, Activity>
//					triple = new Activity(world, null).
//						getFastestRouteVisitingSomeWayPoints
//						(world.self.currentLocation, world.self.charge,
//						  world.facilities.get("shop0"), wayPoints, world);
//
//				int duration = triple.a;
//				int chargeAtTarget = triple.b;
//				Activity activity = triple.c;
//
//				System.out.println("[[[" + world.self.username + " in Step "+ world.simulationStep +
//				" ]]] duration=" + duration + " chargeAtTarget=" + chargeAtTarget + " " + activity);
//
//				world.metaActivity.addActivity(activity);
//			}
//		}
//
//		world.metaActivity.onResult(world.self.lastActionResult, world);

		if (world.simulationStep > 0 && world.metaActivity.isComplete(world)) {
			JobPlanner.getInstance().startPlanningIfIdle(world);
			log.debug(world.self.getName() + "sending planner messages ...");
			perceptionBean.sendPlannerMessages();
		}

		world.metaActivity.onResult(world.self.lastActionResult, world);

		// TODO check what happens if another perception comes in (unexpectedly) while we are calculating

		// asynchronously send action response just before timeout, so we can use the time to plan job(s)
		this.setExecutionInterval(100); // TODO how to wake up myself in the future?
	}

	@Override
	public void execute() {
		if (deadline < System.currentTimeMillis() + 2 * getExecutionInterval()) {
			Intention intention = world.metaActivity.getCurrentIntention();
			if (intention != null) {
				intention.prepareToBeSend(world);
				sendActionResponse(intention);
				intention.onSent(world);
			} else {
				sendActionResponse(new SkipIntention());
			}
			deadline = Long.MAX_VALUE;
		}
	}

	public void sendActionResponse(Intention intention) {
		if (serverCommunicationBean == null) {
			// serverCommunicationBean crashed, reconnect
			for (IAgentBean ab : thisAgent.getAgentBeans()) {
				if (ab instanceof ServerCommunicationBean) {
					serverCommunicationBean = (ServerCommunicationBean) ab;
					break;
				}
			}
		}
		Document response = null;
		try {
			response = ActionFactory.getAction(intention.action,
					intention.param, world.requestId);
			
//			response = ActionFactory.getAction(MessageConstants.ACTION_SKIP, null, world.requestId);
			serverCommunicationBean.sendActionResponse(response);
//			log.info(world.self.username + " sent " + intention.action + " " + intention.param);
		} catch (NullPointerException e) {
			log.error("agent " + world.self.username + " Error sending response " + response, e);
		}
	}
}
