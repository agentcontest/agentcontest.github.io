package de.tub.mac16.ontology;

public interface ILocation {
	Location getLocation();
}
