package de.tub.mac16.ontology.Intentions;

import de.tub.mac16.connection.MessageConstants;
import de.tub.mac16.ontology.World;

public class SkipIntention extends Intention {
	public SkipIntention() {
		super(MessageConstants.ACTION_SKIP, "");
	}

	@Override
	public boolean isComplete(World world) {
		return true;
	}
}
