package de.tub.mac16.ontology.Facilities;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac16.ontology.ILocation;
import de.tub.mac16.ontology.Location;

public class Dump extends Facility implements IFact, ILocation {

	private static final long serialVersionUID = 3640316796435287739L;

	public int price;

	private Dump(String name, Location location, int price) {
		super(name, location);
		this.price = price;
	}

	public static synchronized Dump getOrCreateDump(String name, Location location, int price) {
		if (YellowPages.getFacility(name) == null) YellowPages.putFacility(new Dump(name, location, price));
		return YellowPages.getFacility(name);
	}
}
