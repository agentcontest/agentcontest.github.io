package de.tub.mac16.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac16.ontology.Facilities.Facility;
import de.tub.mac16.ontology.Jobs.Job;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Pure data class, no logic.
 */
public class Perception implements IFact {
	private static final long serialVersionUID = 8856781490395163392L;

	public final String requestId;
	public final int simulationStep;
	public final long timestamp;
	public final long deadline;

	public final AgentState self;
	public final TeamState teamState;

	public final List<BasicAgentState> agents = new LinkedList<>();
	public final Collection<Facility> facilities = new HashSet<>();
	public final Collection<Job> availableJobs = new HashSet<>();

	public Perception(String requestId, int simulationStep, long timestamp, long deadline, AgentState self, TeamState teamState) {
		this.requestId = requestId;
		this.simulationStep = simulationStep;
		this.timestamp = timestamp;
		this.deadline = deadline;
		this.self = self;
		this.teamState = teamState;
	}

	public Perception withAgents(BasicAgentState... agents) {
		Collections.addAll(this.agents, agents);
		return this;
	}

	public Perception withFacilities(Facility... facilities) {
		Collections.addAll(this.facilities, facilities);
		return this;
	}

	@Override
	public String toString() {
		List<String> facNames = facilities.stream().map(f -> f.name).sorted().collect(Collectors.toList());
		return "Perception{" +
				", requestId=" + requestId +
				", simulationStep=" + simulationStep +
				", timestamp=" + timestamp +
				", deadline=" + deadline +
				", availableJobs=" + availableJobs.size() +
				", facilities=" + facNames +
				", teamState=" + teamState +
				", self=" + self +
				'}';
	}
}
