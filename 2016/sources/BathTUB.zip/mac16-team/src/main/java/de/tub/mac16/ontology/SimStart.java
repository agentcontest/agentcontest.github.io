package de.tub.mac16.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;

import java.util.Collection;

/**
 * Pure data class, no logic.
 */
public class SimStart implements IFact {
	public final String worldId;
	public final String map;
	public final int seedCapital;
	public final int steps;
	public final String teamName;
	public final Role role;
	public final Collection<Item> items;

	public SimStart(String worldId, String map, int seedCapital, int steps, String teamName, Role role, Collection<Item> items) {
		this.worldId = worldId;
		this.map = map;
		this.seedCapital = seedCapital;
		this.steps = steps;
		this.teamName = teamName;
		this.role = role;
		this.items = items;
	}

	@Override
	public String toString() {
		return "SimStart{" +
				"worldId='" + worldId + '\'' +
				", map='" + map + '\'' +
				", seedCapital=" + seedCapital +
				", steps=" + steps +
				", teamName='" + teamName + '\'' +
				", role=" + role +
				", " + items.size() + " items}";
	}
}
