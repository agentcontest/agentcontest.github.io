package de.tub.mac16.ontology.Intentions;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac16.LogUtil;
import de.tub.mac16.connection.MessageConstants;
import de.tub.mac16.ontology.Activities.IActivity;
import de.tub.mac16.ontology.Location;
import de.tub.mac16.ontology.World;
import org.apache.log4j.Logger;

/**
 * Part of an {@link de.tub.mac16.ontology.Activities.Activity}.
 * <p>
 * Call onSent when sending to the server.
 * Call onResult to update with the result from the server.
 * Use isComplete instead of checking the state, subclasses may do different checks.
 */
public class Intention implements IFact {

	private static final long serialVersionUID = -5482169226353959121L;

	public String action;
	public String param;

	public State state;

	Logger log;

	public enum State {
		CREATED, // has not been sent to the server
		SENT, // has been sent to the server and is waiting for the result
		SUCCESSFUL, // the intention was executed and returned one of "successful", "successful_partial", "useless"
		FAILED, // the intention was executed unsuccessfully
	}

	public Intention(String action, String param) {
		log = LogUtil.get(this, null);
		this.action = action;
		this.param = param;
		this.state = State.CREATED;
	}

	/**
	 * override this if intention is depending on some value in world
	 * (e.g. recieve only when other Agent gives .....)
	 * @param world
	 */
	public void prepareToBeSend(World world) {
	}

	/**
	 * Override this if the intention does not need to
	 * be run to be completed (eg. goto), or if it needs
	 * additional checks.
	 */
	public boolean isComplete(World world) {
		return state == State.SUCCESSFUL;
	}

	/**
	 * Called by {@link de.tub.mac16.bean.DefaultDecisionBean}
	 * when sending this intention to the server.
	 */
	public void onSent(World world) {
		this.state = State.SENT;
	}

	/**
	 * Called by {@link de.tub.mac16.bean.DefaultDecisionBean}
	 * to process the result from the server.
	 *
	 * @param result result of this action
	 */
	public void onResult(String result, World world) {
		assert state == State.SENT;
		if (this.action.equals(world.self.lastAction) && this.param.equals(world.self.lastActionParam)){
			switch (result) {
				case MessageConstants.RESULT_USELESS:
					LogUtil.get(this).error("Useless action " + this);
					// fall through to successful
				case MessageConstants.RESULT_SUCCESSFUL_PARTIAL:
				case MessageConstants.RESULT_SUCCESSFUL:
					state = State.SUCCESSFUL;
					break;

				case MessageConstants.RESULT_UNKNOWN_ACTION:
					throw new IllegalArgumentException("Got " + result + " for " + this);

				default:
					state = State.FAILED;
			}
		} else {
			state = State.FAILED;
		}
	}

	/**
	 * Do not use. Artifact from implementing {@link IActivity}. Always throws an exception.
	 */
	public Intention getCurrentIntention() {
		throw new IllegalStateException("We should never need to call getCurrentIntention on an Intention");
	}

	/**
	 * If any intention needs more than 1 step in any case, it needs to @Override this method.
	 * All other intentions are assumed to be executed immediately.
	 */
	public int getDuration() {
		return 1;
	}

	public int getCost() {
		return 0;
	}

	/**
	 * Only goto changes the targetLocation, so we set a default of "unchanged" for every other intention.
	 * TODO does CallBreakdownService teleport us to the nearest charger? if so, it needs to @Override getLastLocation()
	 */
	public Location getLastLocation() {
		return null;
	}

	/**
	 * If any intention changes the capacity, it needs to @Override this method.
	 * All other intentions are assumed to not change the capacity.
	 */
	public int getCapacityDelta() {
		return 0;
	}


	public int getChargeDelta() {
		return 0;
	}


	@Override
	public String toString() {
		return "Intention{" +
				"action='" + action + '\'' +
				", param='" + param + '\'' +
				", state=" + state +
				'}';
	}
}
