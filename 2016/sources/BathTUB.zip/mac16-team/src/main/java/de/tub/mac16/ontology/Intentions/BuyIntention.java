package de.tub.mac16.ontology.Intentions;

import de.tub.mac16.connection.MessageConstants;
import de.tub.mac16.ontology.Item;
import de.tub.mac16.ontology.ItemWithQuantity;
import de.tub.mac16.ontology.World;

public class BuyIntention extends Intention {
	public Item item;
	public Integer quantity;
	public Integer cost;

	public BuyIntention(Item item, Integer cost, Integer quantity) {
		super(MessageConstants.ACTION_BUY, "item=" + item.name + " amount=" + quantity.toString());
		this.item = item;
		this.quantity = quantity;
		this.cost = cost;
	}

	public BuyIntention(ItemWithQuantity itemWithQuantity, int cost) {
		this(itemWithQuantity.item, cost, itemWithQuantity.quantity);
	}

	@Override
	public int getCapacityDelta() {
		return -item.volume * quantity;
	}

	@Override
	public void onResult(String result, World world) {
		super.onResult(result, world);
		// TODO update cost
		// TODO update duration if sold out
	}

	@Override
	public int getCost() {
		if (cost == null) {
			return 0; // TODO estimate price using average of known prices
		} else {
			return cost * quantity;
		}
	}

	// TODO what if the item is not available? if we need to wait, @Override getDuration()
}
