package de.tub.mac16.ontology.Intentions;

import de.tub.mac16.connection.MessageConstants;
import de.tub.mac16.ontology.Facilities.ChargingStation;
import de.tub.mac16.ontology.Helpers.Utils;
import de.tub.mac16.ontology.World;

public class ChargeIntention extends Intention {

	public int numberOfCharges;
	public final ChargingStation chargingStation;
	private int lastSuccesfulStep = -1;
	private int lastCharge = -1;

	public ChargeIntention(int numberOfCharges, ChargingStation chargingStation) {
		super(MessageConstants.ACTION_CHARGE, "");
		this.numberOfCharges = numberOfCharges;
		this.chargingStation = chargingStation;
	}

	@Override
	public void onSent(World world) {
		super.onSent(world);
		lastCharge = world.self.charge;
	}

	@Override
	public void onResult(String result, World world) {
		super.onResult(result, world);
		if (state == State.SUCCESSFUL) {

			if(lastSuccesfulStep != world.simulationStep && lastCharge != world.self.charge) {
				numberOfCharges--;
				lastSuccesfulStep = world.simulationStep;
				lastCharge = world.self.charge;
			}

			if(numberOfCharges > 0 && world.self.charge >= world.ownRole().batteryCapacity) {

				System.out.println("[ " + world.self.username + " in Step " + world.simulationStep 
					+ " ]: Battery already fully charged! - Less charges then expected needed: " 
					+ numberOfCharges + " charges left. -> numberOfCharges have been set to 0!");

				numberOfCharges = 0;
			}

			if(numberOfCharges > 0)
				state = State.SENT;
		}
	}

	@Override
	public int getDuration() {
		// TODO duration for queue + charging
		return numberOfCharges; 
	}

	@Override
	public int getCost() {
		return chargingStation.fuelPrice * numberOfCharges;
	}

	@Override
	public String toString() {
		return super.toString() + " charges=" + numberOfCharges;
	}
}
