package de.tub.mac16.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac16.ontology.Facilities.Facility;

import java.util.HashMap;
import java.util.List;

public class BasicAgentState implements IFact, ILocation {

	public final String username;
	public final String teamName;
	public final String roleName;

	public final HashMap<Item, Integer> items = new HashMap<>();

	public Location currentLocation;
	public Facility inFacility;
	public int queuePosition;
	public List<Location> route;
	public int routeLength;

	public BasicAgentState(String username, String teamName, String roleName) {
		this.username = username;
		this.teamName = teamName;
		this.roleName = roleName;
	}

	public BasicAgentState(BasicAgentState other) {
		this(other.username, other.teamName, other.roleName);
		update(other);
	}

	public void update(BasicAgentState other) {
		if (other == null) return;

		items.clear();
		items.putAll(other.items);

		currentLocation = other.currentLocation;
		inFacility = other.inFacility;
		queuePosition = other.queuePosition;
		route = other.route;
		routeLength = other.routeLength;
	}

	@Override
	public String toString() {
		return "BasicAgentState{" +
				"username='" + username + '\'' +
				", teamName='" + teamName + '\'' +
				", role='" + roleName + '\'' +
				", items=" + items +
				", currentLocation=" + currentLocation +
				", inFacility=" + inFacility +
				", queuePosition=" + queuePosition +
				", route=" + route +
				", routeLength=" + routeLength +
				'}';
	}

	@Override
	public Location getLocation() {
		return currentLocation;
	}
}
