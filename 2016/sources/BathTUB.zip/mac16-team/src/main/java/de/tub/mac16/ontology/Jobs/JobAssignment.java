package de.tub.mac16.ontology.Jobs;

import de.dailab.jiactng.agentcore.knowledge.IFact;

public class JobAssignment implements IFact {
	public final Job job;
	public final JobProposal proposal;

	public JobAssignment(Job job, JobProposal proposal) {
		this.job = job;
		this.proposal = proposal;
	}

	@Override
	public String toString() {
		return "JobAssignment{" +
				"job=" + job.id +
				", proposal=" + proposal +
				'}';
	}
}
