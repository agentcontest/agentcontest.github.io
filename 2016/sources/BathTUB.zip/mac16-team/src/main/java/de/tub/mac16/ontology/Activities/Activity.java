package de.tub.mac16.ontology.Activities;

import de.tub.mac16.LogUtil;
import de.tub.mac16.connection.MessageConstants;
import de.tub.mac16.ontology.*;
import de.tub.mac16.ontology.Facilities.*;
import de.tub.mac16.ontology.Intentions.*;
import de.tub.mac16.ontology.Jobs.Job;
import de.tub.mac16.routing.WaypointRouting;
import org.apache.log4j.Logger;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Optional;

/**
 * Consists of some {@link Intention}s, which are executed one after the other.
 * <p>
 * You can add multiple intentions at once:
 * {@code myActivity.goTo(someShop).buy(item1).buy(item2).goTo(workshop).assembleItem();}
 */
public class Activity implements IActivity {

	private final World world;
	private final Logger log;

	/**
	 * used for calculating the last targetLocation if this activity has no goto intentions
	 */
	IActivity prevActivity;

	public LinkedList<Intention> intentions = new LinkedList<>();

	public Activity(World world, IActivity prevActivity) {
		this.world = world;
		this.prevActivity = prevActivity;
		log = LogUtil.get(this, world.self.username);
	}

	/**
	 * Called by {@link de.tub.mac16.bean.DefaultDecisionBean}
	 * to update the current intention withthe result from the server.
	 * If the current intention is done, advance to the next intention.
	 */
	@Override
	public void onResult(String result, World world) {
		String lastAction = world.self.lastAction;
		String lastActionParam = world.self.lastActionParam;

		if (!result.equals(MessageConstants.RESULT_SUCCESSFUL)
				&& !result.equals(MessageConstants.RESULT_SUCCESSFUL_PARTIAL)
				&& !result.equals(MessageConstants.RESULT_FAILED_RANDOM)) {
			log.warn("ACTION FAILED for agent: " + world.self.username
					+ " Action: " + lastAction + " param: " + lastActionParam + " result: " + result);
		}

		Intention intention = getCurrentIntention();
		if (intention == null) {
			log.debug("calling onResult on empty Activity of " + world.self.username);
			return; // no intentions to update
		}

		if (!intention.action.equals(lastAction)
				|| !intention.param.equals(lastActionParam)) {
//			log.error("Last action from server did not match last action of " + world.self.username
//					+ "\nsent: " + intention
//					+ "\ngot from server: " + lastAction + " " + lastActionParam + "");
		}

		intention.onResult(result, world);

		// skip to next non-complete intention,
		// or retry current one if it is not complete yet
		while (intention.isComplete(world)) {
			intentions.poll();
			intention = getCurrentIntention();
			if (intention == null) break;
		}

		// check if we need to charge
		// TODO commented out for testpurposes
		if (intention instanceof GotoIntention) {
			considerCharge((GotoIntention) intention);
		}

		if (getCurrentIntention() == null) {
			onCompleted();
		}
	}

	public void onCompleted() {
//		log.debug("No intentions left in Activity of " + world.self.username);
		// TODO what do we do if we run out of intentions? we could have finished a job, maybe celebrate that?
	}

	/**
	 * @return the intention that will be sent to the server in the next response,
	 * or null if this activity is done
	 */
	@Override
	public Intention getCurrentIntention() {
		return intentions.peek();
	}

	/**
	 * @return if there are any intentions left to do
	 */
	@Override
	public boolean isComplete(World world) {
		return getCurrentIntention() == null;
	}

	@Override
	public int getDuration() {
		return intentions.stream().map(Intention::getDuration).reduce(0, Integer::sum);
	}

	@Override
	public int getCost() {
		return intentions.stream().map(Intention::getCost).reduce(0, Integer::sum);
	}

	@Override
	public Location getLastLocation() {
		Iterator<Intention> iterator = intentions.descendingIterator();
		while (iterator.hasNext()) {
			Location location = iterator.next().getLastLocation();
			if (location != null) {
				return location;
			}
		}

		if (prevActivity != null)
			return prevActivity.getLastLocation();

		// not sure if this always applies, but I have no better idea what to return here
		// and I believe this activity should always be the only active activity in this case
		return world.self.currentLocation;
	}

	@Override
	public int getCapacityDelta() {
		return intentions.stream().map(Intention::getCapacityDelta).reduce(0, Integer::sum);
	}

	@Override
	public int getChargeDelta() {
		return intentions.stream().map(Intention::getChargeDelta).reduce(0, Integer::sum);
	}

	/**
	 * used for calculating the last location if this activity has no goto intentions
	 */
	@Override
	public IActivity getPrevActivity() {
		return prevActivity;
	}

	@Override
	public void setPrevActivity(IActivity activity) {
		prevActivity = activity;
	}

	@Override
	public LinkedList<Intention> getIntentions() {
		return intentions;
	}

	@Override
	public int startingCharge() {
		if (getPrevActivity() != null) return getPrevActivity().chargeAfterActivityIsFinished();
		else return world.self.charge;
	}

	public Activity buyItem(Shop shop, Item item, int amount) {
		goTo(shop);
		intentions.addLast(new BuyIntention(item, Optional.ofNullable(shop.stock.get(item)).map(s -> s.cost).orElse(null), amount));
		return this;
	}

	public Activity buyItem(ItemBatch batch) {
		return buyItem((Shop) batch.place, batch.item, batch.quantity);
	}

	public Activity giveItem(Location location, AgentState agent, ItemWithQuantity item) {
		goTo(location);
		intentions.addLast(new GiveIntention(agent, item));
		return this;
	}

	public Activity recieveItem(AgentState fromAgent, ItemWithQuantity item) {
		intentions.addLast(new ReceiveIntention(item, fromAgent));
		return this;
	}

	public Activity assembleItem(Workshop workshop, Item item, int amount) {
		goTo(workshop);
		for (int i = 0; i < amount; i++)
			intentions.addLast(new AssembleIntention(item, workshop.price));
		return this;
	}

	public Activity assistAssemble(Workshop workshop, BasicAgentState agent, int amount) {
		goTo(workshop);
		for (int i = 0; i < amount; i++)
			intentions.addLast(new AssistAssembleIntention(agent));
		return this;
	}

	public Activity deliverJob(Job job, int deliveredVolume) {
		Storage storage = YellowPages.getFacility(job.storageId);
		goTo(storage);
		intentions.addLast(new DeliverJobIntention(job, deliveredVolume));
		return this;
	}

	public Activity goTo(Location location) {
		Location from = getLastLocation();
		int estimatedDuration = world.getDuration(from, location);
		this.intentions.addLast(new GotoIntention(from, location, estimatedDuration));
		return this;
	}

	public Activity goTo(Facility facility) {
		Location from = getLastLocation();
		int estimatedDuration = world.getDuration(from, facility.getLocation());
		this.intentions.addLast(new GotoIntention(from, facility, estimatedDuration));
		return this;
	}


	private void considerCharge(GotoIntention intention) {
		Facility f = world.self.inFacility;

		//TODO der akku wird jedesmal vollgeladen
		if (f != null && f instanceof ChargingStation && world.self.charge < world.ownRole().batteryCapacity) {
			ChargingStation chargingStation = (ChargingStation) f;
			intentions.addFirst(new ChargeIntention(1, chargingStation));
		} else {
			Location currentLocation = world.self.currentLocation;
			LinkedList<Intention> css = WaypointRouting.getChargingStationRoute(currentLocation, world.self.charge, intention.targetLocation, world).c;
			if (css.size() > 0) {
				//TODO nimmt sich nur erstes element aus der route, route gegebenenfalls zwischenspeichern
				intentions.addFirst(css.get(0));

				// TODO iterate and skip first instead of accessing by index
				for (int i = 1; i < intentions.size(); i++)
					if (intentions.get(i) instanceof GotoIntention && ((GotoIntention) intentions.get(i)).facility instanceof ChargingStation)
						intentions.remove(i);
					else
						break;
			}
		}
	}

	/**
	 * 10% failrate + 1 fail assumed
	 */
	private static int getMaxNumberActionsFail(int rounds) {
		int max_fails = rounds / 10;
		max_fails += 1;
		return max_fails;
	}

	@Override
	public String toString() {
		return "Activity" + intentions;
	}
}
