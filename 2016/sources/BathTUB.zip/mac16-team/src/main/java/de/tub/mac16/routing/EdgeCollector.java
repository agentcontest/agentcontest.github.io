package de.tub.mac16.routing;

import de.tub.mac16.ontology.Location;

import java.util.HashMap;

public class EdgeCollector {

	public HashMap<Location, HashMap<Location, Integer>> edges = new HashMap<>();

	public void addEdge(Location from, Location to, Integer routeLength) {
		HashMap<Location, Integer> destinations = edges.get(from);
		if (destinations == null) {
			destinations = new HashMap<>();
			edges.put(from, destinations);
		}
		// fast vehicles result in imprecise values, so we store the minimum. example: route has 5 nodes
		// bike:  moves 2 nodes at a time, needs 3 rounds, estimates 2 * 3 = 6 nodes, too much but at least an estimate
		// drone: moves 4 nodes at a time, needs 2 rounds, estimates 4 * 2 = 8 nodes, even worse estimate
		// truck: moves 1 nodes at a time, needs 5 rounds, estimates 1 * 5 = 5 nodes, more precise (exact!) value
		// in this case, drone does not override bike, but truck does override bike
		Integer oldLength = destinations.get(to);
		if (oldLength == null || oldLength > routeLength) {
			destinations.put(to, routeLength);
		}
	}
}
