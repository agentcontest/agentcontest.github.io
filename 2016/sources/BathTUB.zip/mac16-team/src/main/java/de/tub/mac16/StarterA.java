package de.tub.mac16;

import de.dailab.jiactng.agentcore.SimpleAgentNode;

import static de.tub.mac16.LogUtil.setLoggingSysProps;

public class StarterA {
	public static void main(String[] args) {
		setLoggingSysProps("teamA");
		SimpleAgentNode.main("classpath:teamA.xml", "tubmac16_log4j.properties");
	}
}
