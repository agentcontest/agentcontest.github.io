package de.tub.mac16.routing;

import com.graphhopper.GHRequest;
import com.graphhopper.GHResponse;
import com.graphhopper.GraphHopper;

import java.util.HashMap;

public class CachingGraphHopper extends GraphHopper {
	static HashMap<String, GHResponse> requestHash = new HashMap<>();

	@Override
	public synchronized GHResponse route(GHRequest request) {
		String key = request.toString();
		if (requestHash.containsKey(key)) return requestHash.get(key);
		GHResponse ret = super.route(request);
		requestHash.put(key, ret);
		return ret;
	}

	@Override
	public CachingGraphHopper forDesktop() {
		return (CachingGraphHopper) super.forDesktop();
	}
}
