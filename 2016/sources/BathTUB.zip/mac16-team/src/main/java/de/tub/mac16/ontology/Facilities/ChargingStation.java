package de.tub.mac16.ontology.Facilities;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac16.ontology.Helpers.DetailedFact;
import de.tub.mac16.ontology.ILocation;
import de.tub.mac16.ontology.Location;

/**
 * pure data class, no logic
 */
public class ChargingStation extends Facility implements IFact, DetailedFact, ILocation {

	private static final long serialVersionUID = -4791889547377805557L;

	public final int simulationStep;
	public boolean detailedFact = false;

	public final String name;
	public final int fuelPrice;
	public final int chargingRate;
	public final int slots;
	public int queueSize = -1;

	private ChargingStation(int simulationStep, String name, Location location, int fuelPrice, int chargingRate, int slots) {
		super(name, location);

		this.simulationStep = simulationStep;

		this.name = name;
		this.fuelPrice = fuelPrice;
		this.chargingRate = chargingRate;
		this.slots = slots;
	}

	public synchronized static ChargingStation getOrCreateChargingStation(int simulationStep, String name, Location location, int fuelPrice, int chargingRate, int slots) {
		if (YellowPages.getFacility(name) == null)
			YellowPages.putFacility(new ChargingStation(simulationStep, name, location, fuelPrice, chargingRate, slots));
		return YellowPages.getFacility(name);
	}


	@Override
	public String toString() {
		return super.toString() + " chargingRate=" + this.chargingRate;
	}
}
