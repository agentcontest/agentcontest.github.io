package de.tub.mac16.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;

import java.util.Map;

public class EnemyAgentState extends BasicAgentState implements IFact {
	private static final long serialVersionUID = -3093853455388360779L;

	public Location lastLocation;
	public Role role = null;
	public Map<Item, Integer> items;
	public EnemyTeamState teamState;

	//public Intention currentIntention;

	public EnemyAgentState(BasicAgentState basicAgentState, EnemyTeamState enemyTeamState, Role role) {
		super(basicAgentState);
		this.teamState = enemyTeamState;
		this.role = role;
	}

	public Integer getFreeLoadCapacity() {
		if (role == null) {
			return 0;
		}
		Integer freeLoadCapacity = role.loadCapacity;
		for (Item item : items.keySet()) {
			freeLoadCapacity -= items.get(item) * item.volume;
		}
		return freeLoadCapacity;
	}
}
