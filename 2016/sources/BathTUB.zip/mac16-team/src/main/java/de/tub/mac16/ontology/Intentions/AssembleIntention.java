package de.tub.mac16.ontology.Intentions;

import de.tub.mac16.connection.MessageConstants;
import de.tub.mac16.ontology.Item;

public class AssembleIntention extends Intention {
	public final Item item;
	public final int consumedItemsVolume;
	public int price;

	public AssembleIntention(Item item, int price) {
		super(MessageConstants.ACTION_ASSEMBLE, "item=" + item.name);
		this.item = item;
		this.price = price;
		consumedItemsVolume = item.calculateConsumedItemsVolume();
	}

	@Override
	public int getDuration() {
		// TODO wait for partner
		throw new IllegalArgumentException("Not implemented");
	}

	@Override
	public int getCost() {
		return price;
	}

	@Override
	public int getCapacityDelta() {
		return -item.volume + consumedItemsVolume;
	}
}
