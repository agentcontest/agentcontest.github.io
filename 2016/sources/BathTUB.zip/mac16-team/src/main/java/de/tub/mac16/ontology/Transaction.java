package de.tub.mac16.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;

import java.util.Map;

/**
 * Created by robinschmied on 21.06.16.
 */
public class Transaction implements IFact {
	public Map<String, EnemyAgentState> involvedEnemys;
	public Map<Item, Integer> maxQuantity;
	public Map<Item, Integer> minQuantity;

	public Transaction(Map<String, EnemyAgentState> involvedEnemys, Map<Item, Integer> maxQuantity, Map<Item, Integer> minQuantity) {
		this.involvedEnemys = involvedEnemys;
		this.maxQuantity = maxQuantity;
		this.minQuantity = minQuantity;
	}
}
