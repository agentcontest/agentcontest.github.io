package de.tub.mac16;

import de.dailab.jiactng.agentcore.SimpleAgentNode;

import static de.tub.mac16.LogUtil.setLoggingSysProps;

public class StarterB {
	public static void main(String[] args) {
		setLoggingSysProps("teamB");
		SimpleAgentNode.main("classpath:teamB.xml", "tubmac16_log4j.properties");
	}
}
