package de.tub.mac16.ontology.Facilities;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac16.ontology.ILocation;
import de.tub.mac16.ontology.Location;
import de.tub.mac16.ontology.ILocation;

public abstract class Facility implements IFact, ILocation {
	private static final long serialVersionUID = 8639229176581599704L;

	public String name;
	protected Location location;

	public Facility(String name, Location location) {
		this.location = location;
		this.name = name;
	}

	@Override
	public String toString() {
		return "Facility: " + name;
	}

	@Override
	public boolean equals(Object obj) {
		return obj != null
				&& obj instanceof Facility
				&& name.equals(((Facility) obj).name);
	}

	@Override
	public Location getLocation() {
		return location;
	}
}
