package de.tub.mac16.connection;

import de.tub.mac16.LogUtil;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;

//import org.apache.commons.logging.Log;

/**
 * Connection-Class, creates the server connection and
 * handles sending and receiving of Documents.
 */
public class ServerConnection {

	private InetSocketAddress socketaddress;

	private Socket socket;

	private InputStream inputstream;

	private OutputStream outputstream;

	private DocumentBuilderFactory documentbuilderfactory;

	private TransformerFactory transformerfactory;

	private final Logger log;
	public byte[] lastPacket;

	public ServerConnection(String host, int port, String username) throws IOException {
		socket = new Socket();
		socketaddress = new InetSocketAddress(host, port);
		log = LogUtil.get(this, username);

		try {
			socket.connect(socketaddress);
			inputstream = socket.getInputStream();
			outputstream = socket.getOutputStream();
			log.info(
					new StringBuffer("Initialising server connection done, host=")
							.append(host)
							.append(" port=")
							.append(port));
		} catch (IOException e) {
			log.error(
					new StringBuffer("Error during initialization! host=")
							.append(host)
							.append(" port=")
							.append(port));
			throw e;
		}
		documentbuilderfactory = DocumentBuilderFactory.newInstance();
		transformerfactory = TransformerFactory.newInstance();
	}

	/**
	 * This method retrieves a raw byte-stream and stores it into a byte-array.
	 *
	 * @return - a byte-array containing the received data
	 * @throws IOException
	 * @throws RuntimeException
	 */
	private byte[] receivePacket() throws IOException, RuntimeException {
		ByteArrayOutputStream buffer = new ByteArrayOutputStream();
		int read = inputstream.read();
		while (read > 0) {
			if (read == -1) {
				throw new RuntimeException("Socket Closed");
			}
			buffer.write(read);
			read = inputstream.read();
		}
		return buffer.toByteArray();
	}

	/**
	 * This method is used to receive a new document from the server.
	 *
	 * @return - the received document
	 * @throws IOException
	 * @throws RuntimeException
	 * @throws SAXException
	 * @throws ParserConfigurationException
	 */
	public Document receiveDocument() throws Exception {
		try {
			byte[] raw = receivePacket();
			lastPacket = raw;
			return documentbuilderfactory.newDocumentBuilder()
					.parse(new ByteArrayInputStream(raw));
		} catch (IOException e) {
			log.error("unable to read packets", e);
			throw e;
		} catch (RuntimeException e) {
			log.error("runtime exception occured!", e);
			throw e;
		} catch (SAXException e) {
			log.error("SAX exception occured!", e);
			throw e;
		} catch (ParserConfigurationException e) {
			log.error("parser configuration exception occured", e);
			throw e;
		}
	}

	/**
	 * This method is used to send a document instantly to the server.
	 *
	 * @param doc - the document to send
	 */
	public void sendDocument(Document doc) throws Exception {
		try {
			transformerfactory.newTransformer().transform(new DOMSource(doc), new StreamResult(outputstream));
			outputstream.write(0);
		} catch (TransformerConfigurationException e) {
			log.error("unable to configure transformer");
			throw e;
		} catch (TransformerException e) {
			log.error("unable to transform document");
			throw e;
		} catch (IOException e) {
			log.error("an io-exception occured!");
			throw e;
		}
	}
}
