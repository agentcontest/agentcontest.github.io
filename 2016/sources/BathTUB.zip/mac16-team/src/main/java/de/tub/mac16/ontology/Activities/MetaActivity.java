package de.tub.mac16.ontology.Activities;

import de.tub.mac16.ontology.Intentions.Intention;
import de.tub.mac16.ontology.Location;
import de.tub.mac16.ontology.World;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.function.Predicate;

/**
 * Contains multiple {@link Activity} that will be executed one after the other.
 */
public class MetaActivity implements IActivity {
	/**
	 * The activities the agent will do, in the order in which they will be done.
	 * <p>
	 * Access is private, in order to add/remove/find activities, you must use the respective methods.
	 */
	public LinkedList<IActivity> activities = new LinkedList<>();

	/**
	 * @param activity the activity that will be done after all already queued activities
	 */
	public void addActivity(IActivity activity) {
		activities.addLast(activity);
	}

	/**
	 * Finds the first activity matching the predicate.
	 *
	 * @param predicate a Predicate whose test() method returns true for the wanted activity
	 * @return the first matching activity
	 */
	public IActivity findActivity(Predicate<IActivity> predicate) {
		return activities.stream().filter(predicate).findFirst().orElse(null);
	}

	public void removeActivity(IActivity removedActivity) {
		if (!activities.contains(removedActivity)) return;
		if (activities.getLast() != removedActivity) {
			// update the following activity with its new predecessor
			IActivity nextAct = activities.get(1 + activities.indexOf(removedActivity));
			nextAct.setPrevActivity(removedActivity.getPrevActivity());
		}
		activities.remove(removedActivity);
	}

	public IActivity getCurrentActivity() {
		return activities.peekFirst();
	}

	@Override
	public Intention getCurrentIntention() {
		IActivity activity = getCurrentActivity();
		if (activity == null)
			return null;

		return activity.getCurrentIntention();
	}

	@Override
	public boolean isComplete(World world) {
		return activities.isEmpty();
	}

	@Override
	public void onResult(String result, World world) {
		IActivity currentActivity = activities.peekFirst();

		if (currentActivity == null) {
//			LogUtil.get(this).error("result for empty metaActivity: " + result);
			return;
		}

		currentActivity.onResult(result, world);

		// skip to next non-complete activity
		while (currentActivity.isComplete(world)) {
			removeActivity(currentActivity);
			currentActivity = activities.peekFirst();
			if (currentActivity == null) break;
		}
	}

	@Override
	public int getDuration() {
		return activities.stream().map(IActivity::getDuration).reduce(0, Integer::sum);
	}

	@Override
	public int getCost() {
		return activities.stream().map(IActivity::getDuration).reduce(0, Integer::sum);
	}

	@Override
	public Location getLastLocation() {
		// TODO could/should we cache this?
		Iterator<IActivity> iterator = activities.descendingIterator();
		while (iterator.hasNext()) {
			Location lastLocation = iterator.next().getLastLocation();
			if (lastLocation != null) { // changed during the activity
				return lastLocation;
			}
		}
		return null;
	}

	@Override
	public int getCapacityDelta() {
		// TODO could/should we cache this?
		return activities.stream().map(IActivity::getCapacityDelta).reduce(0, Integer::sum);
	}

	@Override
	public int getChargeDelta() {
		return activities.stream().map(IActivity::getChargeDelta).reduce(0, Integer::sum);
	}

	/**
	 * used for calculating the last location if this activity has no goto intentions
	 */
	@Override
	public IActivity getPrevActivity() {
		return null;
	}

	@Override
	public void setPrevActivity(IActivity activity) {

	}

	/**
	 * TODO implement properly if needed (could return all Intentions of all activities)
	 *
	 * @return nothing at the moment
	 */
	@Override
	public LinkedList<Intention> getIntentions() {
		return null;
	}

	@Override
	public int chargeAfterActivityIsFinished() {
		try {
			throw new Exception("Not Implemented");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}

	@Override
	public int startingCharge() {
		try {
			throw new Exception("Not Implemented");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}

	@Override
	public String toString() {
		return "MetaActivity" + activities;
	}

	public void addNewActivityAtFront(IActivity activity) {
		if (!activities.isEmpty()) {
			IActivity firstActivity = activities.getFirst();
			firstActivity.setPrevActivity(activity);
		}
		activities.addFirst(activity);
	}
}
