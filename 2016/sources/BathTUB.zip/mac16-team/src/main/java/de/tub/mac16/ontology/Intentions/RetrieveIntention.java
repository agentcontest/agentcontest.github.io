package de.tub.mac16.ontology.Intentions;

import de.tub.mac16.connection.MessageConstants;
import de.tub.mac16.ontology.Item;
import de.tub.mac16.ontology.ItemWithQuantity;

public class RetrieveIntention extends Intention {
	public Item item;
	public Integer quantity;

	public RetrieveIntention(Item item, Integer quantity) {
		super(MessageConstants.ACTION_RETRIEVE, "item=" + item.name + " amount=" + quantity.toString());
		this.item = item;
		this.quantity = quantity;
	}

	public RetrieveIntention(ItemWithQuantity itemWithQuantity) {
		this(itemWithQuantity.item, itemWithQuantity.quantity);
	}

	@Override
	public int getCapacityDelta() {
		return -item.volume * quantity;
	}
}
