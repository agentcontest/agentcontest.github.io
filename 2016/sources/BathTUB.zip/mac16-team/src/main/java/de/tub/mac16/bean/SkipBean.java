package de.tub.mac16.bean;

import de.dailab.jiactng.agentcore.IAgentBean;
import de.dailab.jiactng.agentcore.action.AbstractMethodExposingBean;
import de.dailab.jiactng.agentcore.action.Action;
import de.dailab.jiactng.agentcore.comm.ICommunicationAddress;
import de.dailab.jiactng.agentcore.comm.message.IJiacMessage;
import de.tub.mac16.LogUtil;
import de.tub.mac16.connection.ActionFactory;
import de.tub.mac16.ontology.Intentions.Intention;
import de.tub.mac16.ontology.Intentions.SkipIntention;
import de.tub.mac16.ontology.World;
import org.w3c.dom.Document;

public class SkipBean extends AbstractMethodExposingBean implements IDecisionBean {

	private World world;
	PerceptionBean perceptionBean;
	ServerCommunicationBean serverCommunicationBean;
	Action sendAction;

	@Override
	public void setWorld(World world) {
		this.world = world;
	}

	@Override
	public void doInit() throws Exception {
		setLog(LogUtil.get(this));
		super.doInit();
	}

	@Override
	public void doStart() {
		for (IAgentBean ab : thisAgent.getAgentBeans()) {
			if (ab instanceof PerceptionBean) {
				perceptionBean = (PerceptionBean) ab;
				if (perceptionBean.world != null) world = perceptionBean.world;
			}
			if (ab instanceof ServerCommunicationBean) {
				serverCommunicationBean = (ServerCommunicationBean) ab;
				setLog(LogUtil.get(this, serverCommunicationBean.username));
			}
		}
		// retrieving needed actions from own CommunicationBean
		sendAction = memory.read(new Action(
				"de.dailab.jiactng.agentcore.comm.ICommunicationBean#send",
				null, new Class[]{IJiacMessage.class,
				ICommunicationAddress.class}, null));
		if (sendAction == null)
			throw new RuntimeException("Could not find Communication");
	}

	@Override
	public void decide() {
		sendActionResponse(new SkipIntention());
	}

	public void sendActionResponse(Intention intention) {
		if (serverCommunicationBean == null) {
			// serverCommunicationBean crashed, reconnect
			for (IAgentBean ab : thisAgent.getAgentBeans()) {
				if (ab instanceof ServerCommunicationBean) {
					serverCommunicationBean = (ServerCommunicationBean) ab;
					break;
				}
			}
		}
		Document response = null;
		try {
			response = ActionFactory.getAction(intention.action,
					intention.param, world.requestId);
			serverCommunicationBean.sendActionResponse(response);
		} catch (NullPointerException e) {
			log.error("agent " + world.self.username + " Error sending response " + response, e);
		}
	}
}
