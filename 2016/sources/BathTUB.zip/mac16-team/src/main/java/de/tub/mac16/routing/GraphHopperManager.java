package de.tub.mac16.routing;

import com.graphhopper.GraphHopper;
import com.graphhopper.routing.util.EncodingManager;
import de.tub.mac16.LogUtil;
import org.apache.log4j.Logger;

import java.io.File;

public class GraphHopperManager {

	private static String mapName = null;
	private static CachingGraphHopper hopper = null;
	private static Logger log = LogUtil.get(GraphHopperManager.class);

	public static synchronized void init(String newMapName) {
		if (newMapName.equals(mapName)) {
			log.debug("Map " + mapName + " already loaded");
			return;
		}
		mapName = newMapName;

		log.debug("loading map " + mapName);
		long start = System.currentTimeMillis();

		hopper = new CachingGraphHopper().forDesktop();
		hopper.setOSMFile("osm" + File.separator + mapName + ".osm.pbf");
		hopper.setGraphHopperLocation("osm" + File.separator + "graphs" + File.separator + mapName);
		hopper.setEncodingManager(new EncodingManager(EncodingManager.CAR));

		// now this can take minutes if it imports or a few seconds for loading
		// of course this is dependent on the area you import
		hopper.importOrLoad();

		long end = System.currentTimeMillis();
		log.debug("loaded map " + mapName + " in " + (end - start) / 1000.0 + "s");
	}

	public static GraphHopper getHopper() {
		return hopper;
	}
}
