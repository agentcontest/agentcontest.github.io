package de.tub.mac16.ontology.Intentions;

import de.tub.mac16.connection.MessageConstants;

/**
 * Created by holger on 17.05.16.
 */
public class ContinueIntention extends Intention {
	public ContinueIntention() {
		super(MessageConstants.ACTION_CONTINUE, "");
	}
}
