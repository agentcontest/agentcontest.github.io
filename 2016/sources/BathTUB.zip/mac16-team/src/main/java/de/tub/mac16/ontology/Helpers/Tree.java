package de.tub.mac16.ontology.Helpers;

import java.util.LinkedList;

public class Tree<D> {

	public LinkedList<Tree<D>> children = new LinkedList<Tree<D>>();
	public Tree<D> parent = null;
	public D data = null;

	public Tree(){
	}

	public Tree(D data) {
		this.data = data;
	}

	public void addChild(Tree<D> t)
	{
		t.parent = this;
		this.children.add(t);
	}

	public void addChild(D data)
	{
		Tree<D> t = new Tree<D>(data);
		this.addChild(t);
	}

	public void addChildren(LinkedList<D> data){
		for(D d : data){
			this.addChild(d);
		}
	}

	public boolean isLeave() {
		return this.children.size() == 0;
	}

	public LinkedList<Tree<D>> getLeaves() {
		LinkedList<Tree<D>> leaves = new LinkedList<Tree<D>>();
		for(Tree<D> child : children)
			if(child.isLeave())
				leaves.add(child);
			else
				leaves.addAll(child.getLeaves());
		return leaves;
	}

	public LinkedList<Tree<D>> getPathToRoot()
	{
		LinkedList<Tree<D>> path = new LinkedList<Tree<D>>();
		Tree<D> current = this;
		while(current.parent != null)
		{
			path.add(0, current);
			current = current.parent;
		}
		return path;
	}

	@Override
	public String toString()
	{
		String str = "{ " + this.data + " }->Children[ ";
		for(Tree<D> t : this.children)
			str += t + " ";
		str += "]";
		return str;
	}
}


