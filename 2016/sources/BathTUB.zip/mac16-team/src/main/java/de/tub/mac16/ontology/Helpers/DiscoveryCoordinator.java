package de.tub.mac16.ontology.Helpers;

import de.tub.mac16.LogUtil;
import de.tub.mac16.ontology.AgentState;
import de.tub.mac16.ontology.Facilities.Shop;
import de.tub.mac16.ontology.Facilities.YellowPages;
import de.tub.mac16.ontology.Location;
import de.tub.mac16.ontology.Role;
import de.tub.mac16.ontology.World;
import de.tub.mac16.routing.CityMap;
import org.apache.log4j.Logger;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * used to distribute the agents in such a way that Discovery is done
 * in the fastest possible way.
 * Assumptions: Agents announce themselves that they enter discovery-mode
 * Problem: speedy agents may anounce late.
 * Solution: Recalculate targets every round. Whenever there is nothing left to
 * discover for Agent A then A may leave discovery-mode
 * Usage: initialize() first then call distributeAgents().
 */
public class DiscoveryCoordinator {
	public List<Shop> shopsToGo = new LinkedList<>();
	public World world;
	private Logger log;

	public DiscoveryCoordinator(World world) {
		log = LogUtil.get(this, null);
		this.world = world;
	}

	public void start() {
		initialize();
		distributeAgents();
	}


	public void initialize() {
		//System.out.println(world.self.username + " (re)enter discovery mode ...");
		StatusCoordinator.anounceDiscoveryModeOnOrOff(world.self, true);
	}

	public void cleanUp() {
		//System.out.println(world.self.username + " not in discovery mode any more ...");
		StatusCoordinator.anounceDiscoveryModeOnOrOff(world.self, false);
	}

	public synchronized List<Shop> distributeAgents() {
		shopsToGo = new LinkedList<>();
		List<Shop> yetUndiscoveredShops = notYetVisitedShops().collect(Collectors.toList());
		for (Shop shop : yetUndiscoveredShops) {
			System.out.println(/*world.self.username + */ " turn: " + shop.name + " undiscovered");
		}
		HashMap<AgentState, Integer> futureAgentTurn = new HashMap<>();
		HashMap<AgentState, Location> futureAgentLocation = new HashMap<>();
		List<AgentState> seekers = StatusCoordinator.getAgentsInDiscoveryMode();
		if (seekers.size() == 0) return shopsToGo;
		//log.debug("Agent: " + world.self.getName() + " Number of seekers: " + seekers.size());
		for (AgentState agent : seekers) {
			futureAgentLocation.put(agent, agent.currentLocation);
			futureAgentTurn.put(agent, world.simulationStep);
			//System.out.println(world.self.username + " seeker: " + agent.username);
		}

		distributeAgentsToOneShopEachRound(yetUndiscoveredShops, futureAgentTurn, futureAgentLocation);
		//if (shopsToGo.isEmpty()) cleanUp();
		//for (Shop shop : shopsToGo)
		//System.out.println("Result: " + world.self.username + " should go to " + shop.name);
		return shopsToGo;
	}

	public void distributeAgentsToOneShopEachRound(List<Shop> yetUndiscoveredShops,
	                                               HashMap<AgentState, Integer> futureAgentTurn,
	                                               HashMap<AgentState, Location> futureAgentLocation) {
		if (yetUndiscoveredShops.isEmpty()) return;
		CityMap map = world.cityMap;
		Set<AgentState> seekers = futureAgentLocation.keySet();
		Shop shopToBeVotedFor = yetUndiscoveredShops.get(0);
		AgentState winningAgent = null;
		int minimalSteps = Integer.MAX_VALUE;
		LinkedList<Pair<Integer, AgentState>> compareList;
		for (Shop shop : yetUndiscoveredShops) {
			compareList = new LinkedList<>();
			for (AgentState agent : seekers) {
				Integer steps = routeDuration(agent.currentLocation, shop.getLocation(), agent);
				steps += futureAgentTurn.get(agent);
				compareList.add(new Pair<>(steps, agent));
			}
			Collections.sort(compareList, (t1, t2) -> t1.key - t2.key);
			if (!compareList.isEmpty()) {
				int winningValue = compareList.get(0).key;
				if (winningValue < minimalSteps) {
					minimalSteps = winningValue;
					shopToBeVotedFor = shop;
					winningAgent = compareList.get(0).value;
				}
			} else log.error("CompareList is empty in DiscoveryCoordinator, Number of Seekers: " + seekers.size());
		}
		//System.out.println(world.self.username + "Lottery: " + winningAgent.username + " should goto " + shopToBeVotedFor.name);
		yetUndiscoveredShops.remove(shopToBeVotedFor);
		futureAgentTurn.put(winningAgent, futureAgentTurn.get(winningAgent) + minimalSteps);
		futureAgentLocation.put(winningAgent, shopToBeVotedFor.getLocation());
		if (winningAgent.username.equals(world.self.username) && !shopsToGo.contains(shopToBeVotedFor)) {
			shopsToGo.add(shopToBeVotedFor);
		}
		distributeAgentsToOneShopEachRound(yetUndiscoveredShops, futureAgentTurn, futureAgentLocation);
	}

	Stream<Shop> notYetVisitedShops() {
		return YellowPages.getShops().stream().filter(shop -> shop.detailedFact == false);
	}

	int routeDuration(Location from, Location to, AgentState agent) {
		return CityMap.getRouteLength(from, to, agent.roleName) / Role.getRole(agent.roleName).speed;
	}

}
