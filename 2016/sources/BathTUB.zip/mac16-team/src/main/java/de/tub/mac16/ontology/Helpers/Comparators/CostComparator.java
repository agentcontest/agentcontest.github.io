package de.tub.mac16.ontology.Helpers.Comparators;

import de.tub.mac16.ontology.ItemBatch;

import java.util.Comparator;

public class CostComparator implements Comparator<ItemBatch> {
	@Override
	public int compare(ItemBatch o1, ItemBatch o2) {
		return Integer.compare(o1.cost, o2.cost);
	}
}
