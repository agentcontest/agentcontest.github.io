package de.tub.mac16.ontology.Helpers;

public class Triple<A,B,C> {
		public A a;
		public B b;
		public C c;
		public Triple() {};
		public Triple(A a, B b, C c) {
			setData(a, b, c);
		}
		public void setData(A a, B b, C c) {
			this.a = a;
			this.b = b;
			this.c = c;
		}
	}
