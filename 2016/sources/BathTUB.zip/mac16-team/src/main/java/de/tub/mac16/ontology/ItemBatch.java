package de.tub.mac16.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;

public class ItemBatch extends ItemWithQuantity implements IFact {

	public IPlaceWithItems place;
	public int cost;
	public int rounds;

	public ItemBatch(Item item, int quantity, IPlaceWithItems place, int cost, int rounds) {
		super(item, quantity);
		this.place = place;
		this.cost = cost;
		this.rounds = rounds;
	}

	@Override
	public String toString() {
		return "ItemBatch{" +
				super.toString() +
				", place=" + place.getName() +
				", cost=" + cost +
				", rounds=" + rounds +
				'}';
	}
}
