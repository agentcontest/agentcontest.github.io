package de.tub.mac16.ontology.Intentions;

import de.tub.mac16.bean.DefaultDecisionBean;
import de.tub.mac16.connection.MessageConstants;
import de.tub.mac16.ontology.Jobs.Job;
import de.tub.mac16.ontology.World;

/**
 * Created by holger on 17.05.16.
 */
public class BidForJobIntention extends Intention {
	public Job job;
	public Integer price;

	public BidForJobIntention(Job job, Integer price) {
		super(MessageConstants.ACTION_BID_FOR_JOB, "job=" + job.id + " price=" + price.toString());
		this.job = job;
		this.price = price;
	}

	/**
	 * Called by {@link DefaultDecisionBean}
	 * to process the result from the server.
	 *
	 * @param result result of this action
	 * @param world
	 */
	@Override
	public void onResult(String result, World world) {
		super.onResult(result, world);
		if (MessageConstants.RESULT_FAILED_JOB_STATUS.equals(result))
			world.metaActivity.removeActivity(world.ownJobActivities.get(job.id));
	}
}
