package de.tub.mac16.ontology.Jobs;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac16.ontology.Item;
import de.tub.mac16.ontology.ItemWithQuantity;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * pure data class, no logic
 */
public abstract class Job implements IFact {
	private static final long serialVersionUID = -5447944137634251004L;

	public final String id;
	public final String storageId;
	public final int begin;
	public final int end;

	// filled by MessageParser, do not write/delete, just read
	public Map<Item, Integer> itemsRequired = new HashMap<>();

	public Job(String id, String storageId, int begin, int end) {
		this.id = id;
		this.storageId = storageId;
		this.begin = begin;
		this.end = end;
	}

	@Override
	public String toString() {
		String itemsRequiredString = itemsRequired.entrySet().stream()
				.map(e -> new ItemWithQuantity(e.getKey(), e.getValue()))
				.collect(Collectors.toSet())
				.toString();
		return "Job{" +
				"id='" + id + '\'' +
				", storageId='" + storageId + '\'' +
				", begin=" + begin +
				", end=" + end +
				", itemsRequired=" + itemsRequiredString;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		return id.equals(((Job) o).id);

	}

	@Override
	public int hashCode() {
		return id.hashCode();
	}
}
