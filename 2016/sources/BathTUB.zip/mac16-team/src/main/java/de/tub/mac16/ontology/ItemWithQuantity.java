package de.tub.mac16.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;

public class ItemWithQuantity implements IFact {
	public Item item;
	public Integer quantity;

	public ItemWithQuantity(Item item, Integer quantity) {
		this.item = item;
		this.quantity = quantity;
	}

	public int getVolume() {
		return item.volume * quantity;
	}

	@Override
	public String toString() {
		return quantity + "x " + item.name;
	}

	@Override
	public boolean equals(Object o) {
		if (!(o instanceof ItemWithQuantity)) return false;
		ItemWithQuantity other = (ItemWithQuantity) o;
		return item.equals(other.item) && quantity.equals(other.quantity);
	}

	@Override
	public int hashCode() {
		return item.hashCode() << 12 + quantity.hashCode();
	}
}
