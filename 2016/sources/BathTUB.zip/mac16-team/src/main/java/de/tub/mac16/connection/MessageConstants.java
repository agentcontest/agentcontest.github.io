package de.tub.mac16.connection;

public interface MessageConstants {
	/** states the action success */

	/**
	 * possible agent actions
	 */

	String ACTION_SKIP = "skip";
	String ACTION_GOTO = "goto";
	String ACTION_BUY = "buy";
	String ACTION_GIVE = "give";
	String ACTION_RECEIVE = "receive";
	String ACTION_STORE = "store";
	String ACTION_RETRIEVE = "retrieve";
	String ACTION_RETRIEVE_DELIVERED = "retrieve_delivered";
	String ACTION_DUMP = "dump";
	String ACTION_ASSEMBLE = "assemble";
	String ACTION_ASSIST_ASSEMBLE = "assist_assemble";
	String ACTION_DELIVER_JOB = "deliver_job";
	String ACTION_CHARGE = "charge";
	String ACTION_BID_FOR_JOB = "bid_for_job";
	String ACTION_POST_JOB = "post_job";
	String ACTION_CALL_BREAKDOWN_SERVICE = "call_breakdown_service";
	String ACTION_CONTINUE = "continue";
	String ACTION_ABORT = "abort";

	// possible action results

	/**
	 * default success result for anything
	 */
	String RESULT_SUCCESSFUL = "successful";

	/**
	 * the deliverJobAction was successful and the agent's items were delivered,
	 * but the job is not complete yet
	 */
	String RESULT_SUCCESSFUL_PARTIAL = "successful_partial";

	/**
	 * the deliverJobAction was "successful", but no items were delivered
	 */
	String RESULT_USELESS = "useless";

	// failures
	String RESULT_FAILED = "failed";
	String RESULT_FAILED_LOCATION = "failed_location";
	String RESULT_FAILED_UNKNOWN_ITEM = "failed_unknown_item";
	String RESULT_FAILED_UNKNOWN_AGENT = "failed_unknown_agent";
	String RESULT_FAILED_UNKNOWN_JOB = "failed_unknown_job";
	String RESULT_FAILED_UNKNOWN_FACILITY = "failed_unknown_facility";
	String RESULT_FAILED_NO_ROUTE = "failed_no_route";
	String RESULT_FAILED_ITEM_AMOUNT = "failed_item_amount";
	String RESULT_FAILED_CAPACITY = "failed_capacity";
	String RESULT_FAILED_WRONG_FACILITY = "failed_wrong_facility";
	String RESULT_FAILED_TOOLS = "failed_tools";
	String RESULT_FAILED_ITEM_TYPE = "failed_item_type";
	String RESULT_FAILED_JOB_STATUS = "failed_job_status";
	String RESULT_FAILED_JOB_TYPE = "failed_job_type";
	String RESULT_FAILED_COUNTERPART = "failed_counterpart";
	String RESULT_FAILED_WRONG_PARAM = "failed_wrong_param";
	String RESULT_FAILED_UNKNOWN_ERROR = "failed_unknown_error";
	String RESULT_FAILED_RANDOM = "failed_random";

	String RESULT_UNKNOWN_ACTION = "unknownAction";

	/**
	 * possible message types
	 */

	String MESSAGE_ACTION_REQUEST = "request-action";
	String MESSAGE_ACTION_RESPONSE = "action";
	String MESSAGE_AUTH_RESPONSE = "auth-response";
	String MESSAGE_AUTH_REQUEST = "auth-request";
	String MESSAGE_SIM_START = "sim-start";
	String MESSAGE_SIM_END = "sim-end";
	String MESSAGE_BYE = "bye";
}
