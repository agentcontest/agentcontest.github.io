package de.tub.mac16.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;

import java.util.Collection;

public class Message implements IFact {

	public String sender;
	public Collection<String> receivers;
	public IFact fact;

	public Message(String sender, Collection<String> receivers, IFact fact) {
		this.fact = fact;
		this.sender = sender;
		this.receivers = receivers;
	}
}
