package de.tub.mac16.connection;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac16.ontology.*;
import de.tub.mac16.ontology.Facilities.*;
import de.tub.mac16.ontology.Facilities.Shop.ShopStock;
import de.tub.mac16.ontology.Jobs.AuctionJob;
import de.tub.mac16.ontology.Jobs.Job;
import de.tub.mac16.ontology.Jobs.PricedJob;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Class to parse contest server messages
 *
 * @author axle
 */
public class MessageParser {
	private final Map<String, Item> items = new HashMap<>();

	public IFact parse(Document message) {
		Element root = message.getDocumentElement();
		String messageType = root.getAttribute("type").trim();

		if (messageType.equalsIgnoreCase(MessageConstants.MESSAGE_ACTION_REQUEST)) {
			return receivePerception(root);
		}
		if (messageType.equalsIgnoreCase(MessageConstants.MESSAGE_SIM_START)) {
			return receiveSimStart(root);
		}
		if (messageType.equalsIgnoreCase(MessageConstants.MESSAGE_SIM_END)) {
			return receiveSimEnd(root);
		}
		if (messageType.equalsIgnoreCase(MessageConstants.MESSAGE_BYE)) {
			return new Bye();
		}
		if (messageType.equalsIgnoreCase(MessageConstants.MESSAGE_AUTH_RESPONSE)) {
			return receiveAuth(root);
		}

		return null;
	}

	private IFact receivePerception(Element root) {
		Element perceptionNode = (Element) root.getElementsByTagName("perception").item(0);

		long timestamp = Long.parseLong(root.getAttribute("timestamp"));
		long deadline = Long.parseLong(perceptionNode.getAttribute("deadline"));
		String requestId = perceptionNode.getAttribute("id");

		Element simulationElement = (Element) perceptionNode.getElementsByTagName("simulation").item(0);
		int simulationStep = Integer.parseInt(simulationElement.getAttribute("step"));

		Element agentsElement = (Element) perceptionNode.getElementsByTagName("entities").item(0);
		List<AgentState> agents = parseEntities(agentsElement);

		Element facilitiesElement = (Element) perceptionNode.getElementsByTagName("facilities").item(0);
		List<Facility> facilities = parseFacilities(simulationStep, facilitiesElement);

		Element selfElement = (Element) perceptionNode.getElementsByTagName("self").item(0);
		AgentState self = parseSelf(selfElement, facilities);

		Element jobsElement = (Element) perceptionNode.getElementsByTagName("jobs").item(0);
		List<Job> jobs = parseJobs(jobsElement);

		Element teamElement = (Element) perceptionNode.getElementsByTagName("team").item(0);
		TeamState teamState = parseTeamState(teamElement, jobs);

		Perception perception = new Perception(requestId, simulationStep, timestamp, deadline, self, teamState);
		perception.agents.addAll(agents);
		perception.facilities.addAll(facilities);
		perception.availableJobs.addAll(jobs);
		return perception;
	}

	private List<Job> parseJobs(Element element) {
		List<Job> jobs = new LinkedList<>();

		for (Element e : getElementChildrenFromNode(element)) {
			Job job;
			String type = e.getTagName();

			switch (type) {
				case "pricedJob":
					job = new PricedJob(e.getAttribute("id"), e.getAttribute("storage"), Integer.parseInt(e.getAttribute("begin")), Integer.parseInt(e.getAttribute("end")), Integer.parseInt(e.getAttribute("reward")));
					break;
				case "auctionJob":
					job = new AuctionJob(e.getAttribute("id"), e.getAttribute("storage"), Integer.parseInt(e.getAttribute("begin")), Integer.parseInt(e.getAttribute("end")), Integer.parseInt(e.getAttribute("maxBid")), Integer.parseInt(e.getAttribute("fine")));
					break;
				default:
					throw new IllegalArgumentException("Unknown job type " + type);
			}

			Element itemsElement = (Element) e.getElementsByTagName("items").item(0);
			for (Element el : getElementChildrenFromNode(itemsElement)) {
				job.itemsRequired.put(itemForName(el.getAttribute("name")), Integer.parseInt(el.getAttribute("amount")));
			}
			jobs.add(job);
		}

		return jobs;
	}

	private static List<AgentState> parseEntities(Element element) {
		LinkedList<AgentState> entities = new LinkedList<>();

		for (Element e : getElementChildrenFromNode(element)) {
			AgentState entity = AgentState.getOrCreateAgentState(
					e.getAttribute("name"),
					e.getAttribute("team"),
					e.getAttribute("role"));
			entity.currentLocation = parseLocation(e);
			entities.add(entity);
		}

		return entities;
	}

	private AgentState parseSelf(Element element, List<Facility> facilities) {
		String name = element.getAttribute("name");
		AgentState self = AgentState.getAgent(name);

		String inFacility = element.getAttribute("inFacility");
		self.inFacility = facilities.stream()
				.filter(f -> inFacility.equals(f.name))
				.findAny().orElse(null);

		self.charge = Integer.parseInt(element.getAttribute("charge"));
		self.load = Integer.parseInt(element.getAttribute("load"));
		self.lastAction = element.getAttribute("lastAction");
		self.lastActionParam = element.getAttribute("lastActionParam");
		self.lastActionResult = element.getAttribute("lastActionResult");
		self.queuePosition = Integer.parseInt(element.getAttribute("fPosition"));
		self.routeLength = Integer.parseInt(element.getAttribute("routeLength"));
		self.route = parseRoute(element.getElementsByTagName("route").item(0));

		Element itemsElement = (Element) element.getElementsByTagName("items").item(0);
		for (Element e : getElementChildrenFromNode(itemsElement)) {
			String itemName = e.getAttribute("name");
			int itemAmount = Integer.parseInt(e.getAttribute("amount"));
			self.items.put(itemForName(itemName), itemAmount);
		}

		return self;
	}

	private static List<Location> parseRoute(Node routeElement) {
		if (routeElement == null) return null;

		LinkedList<Location> waypoints = new LinkedList<>();
		NodeList nodes = ((Element) routeElement).getElementsByTagName("n");
		for (int i = 0; i < nodes.getLength(); i++) {
			waypoints.add(parseLocation((Element) nodes.item(i)));
		}

		return waypoints;
	}

	private static TeamState parseTeamState(Element element, Collection<Job> jobs) {
		int money = Integer.parseInt(element.getAttribute("money"));
		TeamState teamState = new TeamState(money);

		Element jobsTaken = (Element) element.getElementsByTagName("jobs-taken").item(0);
		if (jobsTaken != null) {
			for (Element e : getElementChildrenFromNode(jobsTaken)) {
				teamState.jobsTaken.addAll(jobs.stream()
						.filter(j -> j.id.equalsIgnoreCase(e.getAttribute("id")))
						.collect(Collectors.toList()));
			}
		}

		Element jobsPosted = (Element) element.getElementsByTagName("jobs-posted").item(0);
		if (jobsPosted != null) {
			for (Element e : getElementChildrenFromNode(jobsPosted)) {
				teamState.jobsPosted.addAll(jobs.stream()
						.filter(j -> j.id.equalsIgnoreCase(e.getAttribute("id")))
						.collect(Collectors.toList()));
			}
		}

		return teamState;
	}

	private List<Facility> parseFacilities(int simulationStep, Element element) {
		List<Facility> facilities = new LinkedList<>();

		for (Element e : getElementChildrenFromNode(element)) {
			String name = e.getAttribute("name");
			Location location = parseLocation(e);
			if (e.getTagName().equalsIgnoreCase("chargingStation")) {
				ChargingStation f = ChargingStation.getOrCreateChargingStation(simulationStep, name, location,
						Integer.parseInt(e.getAttribute("price")),
						Integer.parseInt(e.getAttribute("rate")),
						Integer.parseInt(e.getAttribute("slots")));
				Element infoTag = (Element) e.getElementsByTagName("info").item(0);
				if (infoTag != null) {
					f.queueSize = Integer.parseInt(infoTag.getAttribute("qSize"));
					f.detailedFact = true;
				}
				facilities.add(f);
			} else if (e.getTagName().equalsIgnoreCase("dumpLocation")) {
				facilities.add(Dump.getOrCreateDump(name, location, Integer.parseInt(e.getAttribute("price"))));
			} else if (e.getTagName().equalsIgnoreCase("workshop")) {
				facilities.add(Workshop.getOrCreateWorkshop(name, location, Integer.parseInt(e.getAttribute("price"))));
			} else if (e.getTagName().equalsIgnoreCase("storage")) {
				facilities.add(Storage.getOrCreateStorage(name, location,
						Integer.parseInt(e.getAttribute("price")),
						Integer.parseInt(e.getAttribute("totalCapacity")),
						Integer.parseInt(e.getAttribute("usedCapacity"))));
			} else if (e.getTagName().equalsIgnoreCase("shop")) {
				Shop f = Shop.getOrCreateShop(simulationStep, name, location);
				f.currentSimulationStep = simulationStep;
				for (Element i : getElementChildrenFromNode(e)) {
					ShopStock stock = null;
					Element infoTag = (Element) i.getElementsByTagName("info").item(0);
					boolean put = true;
					if (infoTag != null) {
						stock = new ShopStock(
								Integer.parseInt(infoTag.getAttribute("cost")),
								Integer.parseInt(infoTag.getAttribute("amount")),
								Integer.parseInt(infoTag.getAttribute("restock")));
						f.detailedFact = true;
						f.simulationStep = simulationStep;
					} else if (f.detailedFact) put = false;
					if (put) f.stock.put(itemForName(i.getAttribute("name")), stock);
				}
				facilities.add(f);
			}
		}
		return facilities;
	}

	private static Location parseLocation(Element element) {
		double lat = Double.parseDouble(element.getAttribute("lat"));
		double lon = Double.parseDouble(element.getAttribute("lon"));
		return new Location(lat, lon);
	}

	private IFact receiveSimStart(Element root) {
		// read items first, they are used in Simulation and roleTools

		Element productsElement = (Element) root.getElementsByTagName("products").item(0);
		NodeList productList = productsElement.getElementsByTagName("product");

		// create the items, skip their requirements
		for (int i = 0; i < productList.getLength(); i++) {
			Element itemElement = (Element) productList.item(i);
			Item item = new Item(
					itemElement.getAttribute("name"),
					Integer.parseInt(itemElement.getAttribute("volume")),
					Boolean.parseBoolean(itemElement.getAttribute("assembled"))
			);
			items.put(item.name, item);
		}

		// now that all items are created, add their requirements
		for (int i = 0; i < productList.getLength(); i++) {
			Element itemElement = (Element) productList.item(i);
			Item item = itemForName(itemElement.getAttribute("name"));

			Element consumed = (Element) itemElement.getElementsByTagName("consumed").item(0);
			if (consumed != null) {
				NodeList consumedList = consumed.getElementsByTagName("item");
				for (int j = 0; j < consumedList.getLength(); j++) {
					Element consElement = (Element) consumedList.item(j);
					String consName = consElement.getAttribute("name");
					int consAmount = Integer.parseInt(consElement.getAttribute("amount"));
					Item consItem = itemForName(consName);
					item.itemsConsumed.put(consItem, consAmount);
				}
			}

			Element tools = (Element) itemElement.getElementsByTagName("tools").item(0);
			if (tools != null) {
				NodeList toolList = tools.getElementsByTagName("item");
				for (int j = 0; j < toolList.getLength(); j++) {
					Element toolElement = (Element) toolList.item(j);
					String toolName = toolElement.getAttribute("name");
					int toolAmount = Integer.parseInt(toolElement.getAttribute("amount"));
					Item toolItem = itemForName(toolName);
					item.toolsNeeded.put(toolItem, toolAmount);
				}
			}
		}

		Element roleElement = (Element) root.getElementsByTagName("role").item(0);
		Role ownRole = Role.getOrCreateRole(
				roleElement.getAttribute("name"),
				Integer.parseInt(roleElement.getAttribute("speed")),
				Integer.parseInt(roleElement.getAttribute("maxBattery")),
				Integer.parseInt(roleElement.getAttribute("maxLoad")));

		NodeList roleTools = roleElement.getElementsByTagName("tool");
		for (int i = 0; i < roleTools.getLength(); i++) {
			Element e = (Element) roleTools.item(i);
			Item item = itemForName(e.getAttribute("name"));
			ownRole.tools.add(item);
		}

		Element simulationElement = (Element) root.getElementsByTagName("simulation").item(0);
		return new SimStart(
				simulationElement.getAttribute("id"),
				simulationElement.getAttribute("map"),
				Integer.parseInt(simulationElement.getAttribute("seedCapital")),
				Integer.parseInt(simulationElement.getAttribute("steps")),
				simulationElement.getAttribute("team"),
				ownRole,
				items.values()
		);
	}

	private Item itemForName(String name) {
		Item item = items.get(name);
		if (item == null)
			throw new IllegalArgumentException("Unknown item " + name);
		return item;
	}

	private IFact receiveSimEnd(Element root) {
		SimEnd simEnd = new SimEnd();

		NodeList children = root.getElementsByTagName("sim-result");
		Element childSimResult = (Element) children.item(0);

		simEnd.setRanking(childSimResult.getAttribute("ranking"));
		simEnd.setScore(childSimResult.getAttribute("score"));

		return simEnd;
	}

	private IFact receiveAuth(Element root) {
		NodeList nodes = root.getElementsByTagName("authentication");

		String result = ((Element) nodes.item(0)).getAttribute("result");

		if (result.equalsIgnoreCase("ok")) {
			return new AuthResponse(true);
		} else {
			return new AuthResponse(false);
		}
	}

	/**
	 * This method extracts all of the Element-child-nodes from parent,
	 * and casts it to org.w3c.dom.Element
	 */
	private static LinkedList<Element> getElementChildrenFromNode(Node parent) {
		NodeList nodeChildren = parent.getChildNodes();
		LinkedList<Element> elementChildren = new LinkedList<>();

		for (int i = 0; i < nodeChildren.getLength(); i++) {
			if (nodeChildren.item(i).getNodeType() == Node.ELEMENT_NODE) {
				elementChildren.add((Element) nodeChildren.item(i));
			}
		}

		return elementChildren;
	}

}
