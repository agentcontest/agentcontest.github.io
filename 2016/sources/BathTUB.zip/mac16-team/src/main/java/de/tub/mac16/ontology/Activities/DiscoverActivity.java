package de.tub.mac16.ontology.Activities;

import de.tub.mac16.connection.MessageConstants;
import de.tub.mac16.ontology.Facilities.Shop;
import de.tub.mac16.ontology.Helpers.DiscoveryCoordinator;
import de.tub.mac16.ontology.Intentions.AbortIntention;
import de.tub.mac16.ontology.Intentions.GotoIntention;
import de.tub.mac16.ontology.Intentions.Intention;
import de.tub.mac16.ontology.Location;
import de.tub.mac16.ontology.Role;
import de.tub.mac16.ontology.World;

import java.util.LinkedList;
import java.util.List;

/**
 * Created by holgerschuh on 12.07.16.
 */
public class DiscoverActivity implements IActivity {

	DiscoveryCoordinator discoveryCoordinator;
	Shop nextDestination = null;
	World world;
	Boolean destinationUnreachable = false;
	Location lastLocation;
	Intention gotoIntention = null;
	private boolean initialized = false;
	private boolean abortSend = false;
	private List<Shop> shopsToGoTo;

	public DiscoverActivity(World world) {
		this.world = world;
		discoveryCoordinator = new DiscoveryCoordinator(world);
		discoveryCoordinator.initialize();
		//calculateNextDestination(world);
	}

	void calculateNextDestination(World world) {
		shopsToGoTo = discoveryCoordinator.distributeAgents();
		if (shopsToGoTo.isEmpty()) {
			initializeDiscoveryFinish(world);
		} else {
			if (nextDestination == null || !nextDestination.name.equals(shopsToGoTo.get(0))) {
				nextDestination = shopsToGoTo.get(0);
				Location ownpos = world.self.currentLocation;
				Location destpos = nextDestination.getLocation();
				gotoIntention = new GotoIntention(ownpos, nextDestination, world.getDuration(ownpos, destpos, world.self.roleName));
				for (Shop shop : shopsToGoTo)
					lastLocation = shop.getLocation();
			}
		}
	}

	/**
	 * @return the intention that will be sent to the server in the next response, or null if this activity is done
	 */
	@Override
	public Intention getCurrentIntention() {
		if (!initialized) {
			initialized = true;
			calculateNextDestination(world);
		}
		if (gotoIntention == null) {
			abortSend = true;
			return new AbortIntention();
		}
		return gotoIntention;
	}

	/**
	 * Updates the current intention with the result from the server.
	 * If the current intention is done, advances to the next intention.
	 *
	 * @param result
	 * @param world
	 */
	@Override
	public void onResult(String result, World world) {
		this.world = world;
		calculateNextDestination(world);
		if (result.equals(MessageConstants.RESULT_FAILED_NO_ROUTE)) {
			destinationUnreachable = true;
			initializeDiscoveryFinish(world);
		}
	}

	private void initializeDiscoveryFinish(World world) {
		discoveryCoordinator.cleanUp();
		lastLocation = world.self.getLocation();
		gotoIntention = null;
	}

	/**
	 * @param world
	 * @return false if there are any intentions left to do
	 */
	@Override
	public boolean isComplete(World world) {
		return (nextDestination == null && abortSend) || destinationUnreachable || gotoIntention == null;
	}

	/**
	 * @return number of rounds this activity will take, without random failures
	 */
	@Override
	public int getDuration() {
		int ret = 0;
		Location pos = world.self.getLocation();
		for (Shop shop : discoveryCoordinator.shopsToGo) {
			ret += world.getDuration(pos, shop.getLocation(), world.self.roleName);
		}
		return ret;
	}

	@Override
	public int getCost() {
		return getDuration() * 10;
	}

	/**
	 * Used for planning.
	 *
	 * @return my location after the last intention, or null if unchanged
	 */
	@Override
	public Location getLastLocation() {
		return lastLocation;
	}

	/**
	 * @return the difference in capacity after the activity,
	 * negative means less available - the agent uses more of its storage,
	 * positive means the agent frees up space in its storage
	 */
	@Override
	public int getCapacityDelta() {
		return 0;
	}

	@Override
	public int getChargeDelta() {
		return getCost();
	}

	/**
	 * used for calculating the last location if this activity has no goto intentions
	 */
	@Override
	public IActivity getPrevActivity() {
		return null;
	}

	@Override
	public void setPrevActivity(IActivity activity) {

	}

	@Override
	public LinkedList<Intention> getIntentions() {
		LinkedList<Intention> ret = new LinkedList<Intention>();
		Location start;
		Location end = world.self.getLocation();
		for (Shop shop : shopsToGoTo) {
			start = end;
			end = shop.getLocation();
			ret.add(new GotoIntention(start, end, world));
		}
		return ret;
	}

	@Override
	public int startingCharge() {
		return Role.getRole(world.self.roleName).batteryCapacity;
	}
}
