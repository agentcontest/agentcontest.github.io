package de.tub.mac16.routing;

import com.graphhopper.GHRequest;
import com.graphhopper.GHResponse;
import com.graphhopper.util.shapes.GHPoint;
import com.graphhopper.util.shapes.GHPoint3D;
import de.tub.mac16.ontology.Helpers.NestedHashMap;
import de.tub.mac16.ontology.Helpers.Pair;
import de.tub.mac16.ontology.Location;
import de.tub.mac16.ontology.Role;
import org.apache.log4j.Logger;

import java.io.Serializable;
import java.util.Iterator;
import java.util.LinkedList;

public class CityMap implements Serializable {
	private static final long serialVersionUID = 2L;

	public static double cellSize;
	private final static Logger log = Logger.getLogger("CityMap");

	public static final NestedHashMap<Location, Pair<Integer, Integer>> collectedRoutes = new NestedHashMap<>();

	public CityMap(String newMapName, double cellSize) {
		CityMap.cellSize = cellSize;
		try {
			GraphHopperManager.init(newMapName);
		} catch (IllegalStateException e) {
			log.error("map not found, relying on collectedRoutes", e);
		}
	}

	/**
	 * Store a route length in the cache.
	 *
	 * @param length the car route length between from and to
	 * @param speed  the speed of the agent that observed this route, or 999 for GraphHopper (used for overriding imprecise data)
	 */
	public static void addRouteLength(Location from, Location to, Integer length, int speed) {
		synchronized (collectedRoutes) {
			Pair<Integer, Integer> oldEntry = collectedRoutes.get(from, to);
			if (oldEntry != null) { // check if old or new is more precise
				Integer oldSpeed = oldEntry.value;
				if (oldSpeed < speed) return;
				Integer oldLength = oldEntry.key;
				// rather overestimate than underestimate the length
				// TODO imprecise values are always larger, except graphhopper which may be smaller
				if (oldSpeed == speed && oldLength > length) return;
			}
			collectedRoutes.addValue(from, to, new Pair<>(length, speed));
		}
	}

	public static int getRouteLength(Location from, Location to, Role role) {
		return getRouteLength(from, to, role.name);
	}

	public static int getDuration(Location from, Location to, Role role) {
		return getRouteLength(from, to, role.name) / role.speed;
	}

	/**
	 * @param roleName "Drone" for air route, anything else for car route
	 * @return null if no route, otherwise the length of the route in cellSize units
	 */
	public static int getRouteLength(Location from, Location to, String roleName) {
		if (roleName.toLowerCase().equals("drone"))
			return getNewAirRoute(from, to).size();
		else {
			Pair<Integer, Integer> lengthAndSpeed = collectedRoutes.get(from, to);
			if (lengthAndSpeed != null)
				return lengthAndSpeed.key;

			// not cached, calculate
			synchronized (collectedRoutes) {
				LinkedList<Location> route = getNewCarRoute(from, to);
				Integer length = null;
				if (route != null) {
					length = route.size();
				}
				addRouteLength(from, to, length, 999);
				return length;
			}
		}
	}

	private static LinkedList<Location> getNewAirRoute(Location from, Location to) {
		LinkedList<Location> waypoints = new LinkedList<>();

		final double fractions = getLength(from, to) / cellSize;

		Location loc = null;
		for (long i = 1; i <= fractions; i++) {
			loc = getIntermediateLoc(from, to, fractions, i);
			waypoints.add(loc);
		}
		if (!to.equals(loc)) {
			waypoints.add(to);
		}
		return waypoints;
	}

	private static LinkedList<Location> getNewCarRoute(Location from, Location to) {
		GHRequest req = new GHRequest(from.latitude, from.longitude, to.latitude, to.longitude)
				.setWeighting("shortest")
				.setVehicle("car");

		GHResponse rsp = GraphHopperManager.getHopper().route(req);

		if (rsp.hasErrors()) {
			log.error("No route found: " + rsp.getErrors());
			return null;
		}

		LinkedList<Location> waypoints = new LinkedList<>();

		Iterator<GHPoint3D> pIterator = rsp.getPoints().iterator();
		if (!pIterator.hasNext()) return null;
		GHPoint prevPoint = pIterator.next();

		double remainder = 0;
		Location loc = null;
		while (pIterator.hasNext()) {
			GHPoint nextPoint = pIterator.next();
			double length = getLength(prevPoint, nextPoint);
			if (length == 0) {
				prevPoint = nextPoint;
				continue;
			}

			long i = 0;
			for (; i * cellSize + remainder < length; i++) {
				loc = getIntermediateLoc(prevPoint, nextPoint, length, i * cellSize + remainder);
				if (!from.equals(loc)) {
					waypoints.add(loc);
				}
			}
			remainder = i * cellSize + remainder - length;
			prevPoint = nextPoint;
		}

		if (!to.equals(loc)) {
			waypoints.add(to);
		}

		return waypoints;
	}

	private static double getLength(Location loc1, Location loc2) {
		return Math.sqrt(Math.pow(loc1.longitude - loc2.longitude, 2)
				+ Math.pow(loc1.latitude - loc2.latitude, 2));
	}

	private static Location getIntermediateLoc(Location loc1, Location loc2, double fractions, long i) {
		double lon = (loc2.longitude - loc1.longitude) * i / fractions + loc1.longitude;
		double lat = (loc2.latitude - loc1.latitude) * i / fractions + loc1.latitude;
		return new Location(lat, lon);
	}

	private static double getLength(GHPoint loc1, GHPoint loc2) {
		return Math.sqrt(Math.pow(loc1.getLon() - loc2.getLon(), 2)
				+ Math.pow(loc1.getLat() - loc2.getLat(), 2));
	}

	private static Location getIntermediateLoc(GHPoint loc1, GHPoint loc2, double length, double i) {
		double lon = (loc2.getLon() - loc1.getLon()) * i / length + loc1.getLon();
		double lat = (loc2.getLat() - loc1.getLat()) * i / length + loc1.getLat();
		return new Location(lat, lon);
	}
}
