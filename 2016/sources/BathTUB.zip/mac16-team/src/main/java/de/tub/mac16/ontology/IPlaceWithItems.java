package de.tub.mac16.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac16.ontology.Intentions.Intention;

public interface IPlaceWithItems extends ILocation, IFact {

	String getName();

	Integer getItemQuantity(Item item);

	Integer getItemCost(Item item);

	Iterable<Item> getAvailableItems();

	Intention getItemIntention(ItemWithQuantity timedItemBatch);
}
