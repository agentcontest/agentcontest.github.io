package de.tub.mac16.ontology.Intentions;

import de.tub.mac16.connection.MessageConstants;
import de.tub.mac16.ontology.Item;

public class StoreIntention extends Intention {
	public Item item;
	public Integer quantity;

	public StoreIntention(Item item, Integer quantity) {
		super(MessageConstants.ACTION_STORE, "item=" + item.name + " amount=" + quantity.toString());
		this.item = item;
		this.quantity = quantity;
	}

	@Override
	public int getCapacityDelta() {
		return +item.volume * quantity;
	}
}
