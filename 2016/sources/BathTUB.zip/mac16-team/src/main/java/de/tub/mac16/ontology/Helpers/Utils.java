package de.tub.mac16.ontology.Helpers;

public class Utils {

	public static int ceilDiv(int a, int b) {
		if (a % b == 0) return a / b;
		return a / b + 1;
	}

}
