package de.tub.mac16.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac16.ontology.Facilities.Facility;
import de.tub.mac16.ontology.Facilities.Shop;
import de.tub.mac16.ontology.Jobs.Job;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

import static de.tub.mac16.ontology.Helpers.Utils.ceilDiv;

/**
 * Created by robinschmied on 21.06.16.
 */
public class EnemyTeamState implements IFact {
	public int money;

	public ArrayList<Job> jobsTaken = new ArrayList<>();
	public ArrayList<Job> jobsPosted = new ArrayList<>();
	public LinkedList<Transaction> transactions = new LinkedList<>();

	public EnemyTeamState(int money) {
		this.money = money;
	}

	public void addTransaction(Facility facility, EnemyAgentState enemyAgentState) {
		if (facility instanceof Shop) {
			Map<Item, Integer> maxQuantity = new HashMap<>();
			Map<Item, Integer> minQuantity = new HashMap<>();
			for (Item item : ((Shop) facility).stock.keySet()) {
				if (((Shop) facility).stock.get(item).quantity * item.volume < enemyAgentState.getFreeLoadCapacity()) {
					maxQuantity.put(item, ((Shop) facility).stock.get(item).quantity);
				} else {
					maxQuantity.put(item, ceilDiv(enemyAgentState.getFreeLoadCapacity(), item.volume));
				}
				minQuantity.put(item, 0);
			}
			Map<String, EnemyAgentState> enemys = new HashMap<>();
			enemys.put(enemyAgentState.username, enemyAgentState);
			Transaction t = new Transaction(enemys, maxQuantity, minQuantity);
			transactions.add(t);
		}
	}

	public String toString() {
		return "money = " + money
				+ ", jobsTaken = " + jobsTaken.size()
				+ ", jobsPosted = " + jobsPosted.size();
	}

	public void printTransactions() {
		int counter = 0;
		for (Transaction t : transactions) {
			System.out.print("id:" + counter + "|");
			for (Item i : t.maxQuantity.keySet()) {
				System.out.print(i.name + "|" + t.minQuantity.get(i) + "|" + t.maxQuantity.get(i) + "#");
			}
			System.out.println();
			counter++;
		}
	}
}
