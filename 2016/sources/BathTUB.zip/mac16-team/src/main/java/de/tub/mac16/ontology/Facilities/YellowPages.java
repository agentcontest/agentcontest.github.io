package de.tub.mac16.ontology.Facilities;

import java.util.Collection;
import java.util.HashMap;

/**
 * Created by holgerschuh on 24.08.16.
 */
public class YellowPages {
	private static HashMap<String, Facility> facilities = new HashMap<>();
	private static HashMap<String, Dump> dumps = new HashMap<>();
	private static HashMap<String, ChargingStation> chargingStations = new HashMap<>();
	private static HashMap<String, Shop> shops = new HashMap<>();
	private static HashMap<String, Storage> storages = new HashMap<>();
	private static HashMap<String, Workshop> workshops = new HashMap<>();

	public static Collection<Dump> getDumps() {
		return dumps.values();
	}

	public static Collection<ChargingStation> getChargingStations() {
		return chargingStations.values();
	}

	public static Collection<Shop> getShops() {
		return shops.values();
	}

	public static Collection<Storage> getStorages() {
		return storages.values();
	}

	public static Collection<Workshop> getWorkshops() {
		return workshops.values();
	}

	public static <T extends Facility> T getFacility(String name) {
		if (facilities.containsKey(name)) return (T) facilities.get(name);
		return null;
	}

	public static synchronized void resetFacilies() {
		facilities.clear();
		chargingStations.clear();
		dumps.clear();
		shops.clear();
		storages.clear();
		workshops.clear();
	}


	public static synchronized <T extends Facility> void putFacility(T facility) {
		facilities.put(facility.name, facility);
		if (facility instanceof Dump) dumps.put(((Dump) facility).name, (Dump) facility);
		if (facility instanceof ChargingStation)
			chargingStations.put(((ChargingStation) facility).name, (ChargingStation) facility);
		if (facility instanceof Shop) shops.put(((Shop) facility).name, (Shop) facility);
		if (facility instanceof Storage) storages.put(((Storage) facility).name, (Storage) facility);
		if (facility instanceof Workshop) workshops.put(((Workshop) facility).name, (Workshop) facility);
	}

}
