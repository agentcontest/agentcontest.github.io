package de.tub.mac16.ontology.Intentions;

import de.tub.mac16.connection.MessageConstants;

/**
 * Created by holger on 17.05.16.
 */
public class AbortIntention extends Intention {
	public AbortIntention() {
		super(MessageConstants.ACTION_ABORT, "");
	}
}
