package de.tub.mac16.ontology.Helpers;

import java.util.HashMap;

/**
 * Created by holgerschuh on 21.06.16.
 */
public class NestedHashMap<L, V> {
	public HashMap<L, HashMap<L, V>> values = new HashMap<>();

	public void addValue(L from, L to, V value) {
		HashMap<L, V> toHash = values.get(from);
		if (toHash == null) {
			toHash = new HashMap<L, V>();
			values.put(from, toHash);
		}
		toHash.put(to, value);
	}

	public V get(L from, L to) {
		HashMap<L, V> toHash = values.get(from);
		if (toHash == null) return null;
		return toHash.get(to);
	}

	public HashMap<L, V> get(L key) {
		return values.get(key);
	}

	public void clear() {
		for (HashMap<L, V> entry : values.values()) {
			entry.clear();
		}
		values.clear();
	}
}
