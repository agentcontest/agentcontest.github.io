package de.tub.mac16.ontology.Jobs;

import de.dailab.jiactng.agentcore.knowledge.IFact;

public class PricedJob extends Job implements IFact {

	private static final long serialVersionUID = -189932927724625750L;
	public int reward;

	public PricedJob(String id, String storageId, int begin, int end, int reward) {
		super(id, storageId, begin, end);
		this.reward = reward;
	}

	@Override
	public String toString() {
		return "Priced " + super.toString() + " reward: " + reward + "}";
	}
}
