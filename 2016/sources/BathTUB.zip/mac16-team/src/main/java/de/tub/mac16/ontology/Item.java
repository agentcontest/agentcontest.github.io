package de.tub.mac16.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;

import java.util.HashMap;
import java.util.Map;

/**
 * Represents an item (product or tool).
 * Pure data class, no logic.
 */
public class Item implements IFact {
	private static final long serialVersionUID = -3278829909666941045L;

	public final String name;
	public final int volume;
	public final boolean userAssembled;

	// requirements to assemble if usable.
	public final Map<Item, Integer> itemsConsumed = new HashMap<>();
	public final Map<Item, Integer> toolsNeeded = new HashMap<>();

	public Item(String name, int volume, boolean userAssembled) {
		this.name = name;
		this.volume = volume;
		this.userAssembled = userAssembled;
	}

	public int calculateConsumedItemsVolume() {
		int volume = 0;
		for (Map.Entry<Item, Integer> entry : itemsConsumed.entrySet()) {
			Item usedItem = entry.getKey();
			Integer usedAmount = entry.getValue();
			volume += usedItem.volume * usedAmount;
		}
		return volume;
	}

	public String toString() {
		String str = "Item{name: " + name + ", volume: " + volume + ", assembled: " + userAssembled;
		if (!itemsConsumed.isEmpty()) {
			str += ", consumed: [ ";
			for (Item i : itemsConsumed.keySet())
				str += itemsConsumed.get(i) + "x " + i.name + " ";
			str += "]";
		}
		if (!toolsNeeded.isEmpty()) {
			str += ", tools: [ ";
			for (Item i : toolsNeeded.keySet())
				str += toolsNeeded.get(i) + "x " + i.name + " ";
			str += "]";
		}
		return str + "}";
	}

	@Override
	public boolean equals(Object obj) {
		return obj instanceof Item && name.equals(((Item) obj).name);
	}

	@Override
	public int hashCode() {
		return name.hashCode();
	}
}
