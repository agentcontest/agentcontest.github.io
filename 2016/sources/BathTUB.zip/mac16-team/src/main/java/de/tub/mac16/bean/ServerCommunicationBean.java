package de.tub.mac16.bean;

import de.dailab.jiactng.agentcore.IAgentBean;
import de.dailab.jiactng.agentcore.action.AbstractMethodExposingBean;
import de.tub.mac16.LogUtil;
import de.tub.mac16.connection.ActionFactory;
import de.tub.mac16.connection.ServerConnection;
import de.tub.mac16.ontology.Authentication;
import org.w3c.dom.Document;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Manages the connection to the Agent Contest simulation server.
 *
 * @author axle
 */
public class ServerCommunicationBean extends AbstractMethodExposingBean {
	private String host = "localhost";
	private int port = 12300;
	public String username = "username";
	private String password = "passwort";

	/**
	 * The simulation server connection.
	 */
	private ServerConnection csConnection = null;

	/**
	 * The thread listening to simulation server messages.
	 */
	private ACControlThread ccThread;

	private PerceptionBean perceptionBean;

	private boolean firstConnect = true;
	private static final int FIRST_CONNECT_INTERVAL = 10000;
	private static final int CONNECT_INTERVAL = 100;

	/**
	 * Returns the name of the host where the simulation server is running.
	 *
	 * @return the name of the host
	 */
	public String getHost() {
		return host;
	}

	/**
	 * Sets the name of the host where the simulation server is running.
	 *
	 * @param host the name of the host
	 */
	public void setHost(String host) {
		this.host = host;
	}

	/**
	 * Returns the password the agent uses during authorization phase.
	 *
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Sets the password the agent uses during authorization phase.
	 *
	 * @param password the password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * Return the port number the simulation server is listening to.
	 *
	 * @return the port number
	 */
	public int getPort() {
		return port;
	}

	/**
	 * Sets the port number the simulation server is listening to.
	 *
	 * @param port the port number
	 */
	public void setPort(int port) {
		this.port = port;
	}

	/**
	 * Returns the name of the agent uses during authorization phase.
	 *
	 * @return the name
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * Sets the name of the agent uses during authorization phase.
	 *
	 * @param username the name
	 */
	public void setUsername(String username) {
		this.username = username;
		setLog(LogUtil.get(this, username));
	}

	/**
	 * Memorizes authentication data and initializes the server connection.
	 */
	@Override
	public void doInit() throws Exception {
		memory.write(new Authentication(username, password));
		log.debug(new StringBuffer("Username=").append(username));
	}

	@Override
	public void doStart() throws Exception {
		super.doStart();
		if (connect()) {
			firstConnect = false;
			setExecutionInterval(0);
		} else {
			setExecutionInterval(FIRST_CONNECT_INTERVAL);
		}
	}

	@Override
	public void doStop() throws Exception {
		closeUnderlyingConnection();
		super.doStop();
	}

	@Override
	public void execute() {
		if (connect()) {
			firstConnect = false;
			setExecutionInterval(0);
		} else {
			setExecutionInterval(firstConnect ? FIRST_CONNECT_INTERVAL
					: CONNECT_INTERVAL);
		}
	}

	private synchronized boolean connect() {
		if (csConnection != null) {
			log.debug("Connection is still alive?");
		} else {
			log.debug("connecting...");
		}

		try {
			csConnection = new ServerConnection(host, port, username);
			sendActionResponse(ActionFactory.getAuthenticationAction(username, password));
			// start listening to simulation server
			ccThread = new ACControlThread("serverComm: " + getBeanName());
			ccThread.start();
			log.info("connection succeeded");
			return true;
		} catch (IOException e) {
			log.error("connection failed!");
			closeUnderlyingConnection();
		}

		return false;
	}

	private void closeUnderlyingConnection() {
		csConnection = null;
		// avoid deadlock if this method was called out of the receiver thread
		if (ccThread != null && ccThread != Thread.currentThread()) {
			try {
				ccThread.join();
			} catch (InterruptedException ie) {
				log.warn("could not join with reader thread");
			}
			ccThread = null;
		}
	}

	@Expose(name = "sendActionResponse")
	public void sendActionResponse(Document doc) {
		try {
			csConnection.sendDocument(doc);
		} catch (Exception e) {
			log.error(e);
		}
	}

	/**
	 * Thread that listens to the simulation server. Contains the simulation
	 * loop.
	 */
	public class ACControlThread extends Thread {

		public ACControlThread(String name) {
			super(name);
		}

		/**
		 * The main control loop: receive documents in loop and parse them.
		 * Note: The first received message should be the authentication response.
		 */
		public void run() {
			log.info("Alive...");

			while (!isInterrupted() && csConnection != null) {
				try {
					Document message = csConnection.receiveDocument();

					if (perceptionBean == null) {
						for (IAgentBean ab : thisAgent.getAgentBeans()) {
							if (ab instanceof PerceptionBean) {
								perceptionBean = (PerceptionBean) ab;
								break;
							}
						}
					}
					if (perceptionBean == null) {
						log.error("No PerceptionBean");
						continue;
					}

					// write received xml message to raw/ if that directory exists
					// TODO do we want to keep it for the contest? or does it unnecessarily use our processing time?
					try {
						String msgType = message.getDocumentElement().getAttribute("type").trim();
						String fileName = String.format("raw/%s_%s_%s_%s.xml", msgType, username, perceptionBean.world.requestId, System.currentTimeMillis());
						BufferedWriter w = new BufferedWriter(new FileWriter(fileName));
						w.write(new String(csConnection.lastPacket));
						w.flush();
						w.close();
					} catch (Exception e) {
					}

					long t0 = System.currentTimeMillis();

					perceptionBean.processServerMessage(message);

					long t1 = System.currentTimeMillis();
					if (t1 - t0 >= 2000) {
						log.warn("long step duration: " + (t1 - t0) + "ms");
					}
				} catch (Exception e) {
					log.error("connection closed, opening again", e);
					closeUnderlyingConnection();
					setExecutionInterval(CONNECT_INTERVAL);
				}
			}
		}
	}
}
