package de.tub.mac16.bean;

import de.dailab.jiactng.agentcore.IAgentBean;
import de.dailab.jiactng.agentcore.action.AbstractMethodExposingBean;
import de.dailab.jiactng.agentcore.action.Action;
import de.dailab.jiactng.agentcore.comm.CommunicationAddressFactory;
import de.dailab.jiactng.agentcore.comm.ICommunicationAddress;
import de.dailab.jiactng.agentcore.comm.IGroupAddress;
import de.dailab.jiactng.agentcore.comm.message.IJiacMessage;
import de.dailab.jiactng.agentcore.comm.message.JiacMessage;
import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac16.LogUtil;
import de.tub.mac16.connection.MessageParser;
import de.tub.mac16.ontology.*;
import de.tub.mac16.ontology.Facilities.YellowPages;
import de.tub.mac16.ontology.Jobs.JobPlanner;
import org.sercho.masp.space.event.SpaceObserver;
import org.sercho.masp.space.event.WriteCallEvent;
import org.w3c.dom.Document;

import java.io.Serializable;
import java.util.Collection;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * This agent component handles all related to perception:
 * - Server messages
 * - Messages from other agents
 *
 * @author axle
 */
public class PerceptionBean extends AbstractMethodExposingBean {

	private String username;
	private MessageParser messageParser = new MessageParser();

	private ServerCommunicationBean serverCommunicationBean;
	private IDecisionBean decisionBean;

	/**
	 * Actions to communicate with other team members.
	 */
	private Action sendAction, registerAction;

	/**
	 * The channel where agents of one team share their knowledge.
	 */
	public IGroupAddress teamChannel;

	public World world;

	public String getTeamChannel() {
		return this.teamChannel.toString();
	}

	public void setTeamChannel(String teamChannel) {
		this.teamChannel = CommunicationAddressFactory
				.createGroupAddress(teamChannel);
	}

	@Override
	public void doInit() throws Exception {
		setLog(LogUtil.get(this));
		super.doInit();

		if (decisionBean == null) {
			for (IAgentBean ab : thisAgent.getAgentBeans()) {
				if (ab instanceof IDecisionBean) {
					decisionBean = (IDecisionBean) ab;
					break;
				}
			}
		}

		memory.attach((SpaceObserver<IFact>) event -> {
			if (event instanceof WriteCallEvent) {
				Object eventObj = ((WriteCallEvent) event).getObject();
				if (eventObj instanceof IJiacMessage) {
					IJiacMessage message = (IJiacMessage) eventObj;
					message = memory.remove(message);
					if (message != null) {
						IFact payload = message.getPayload();

						if (!(payload instanceof Message)) {
							log.warn("Unexpected payload " + payload.getClass().getName() + ' ' + payload);
						} else if (world == null) {
							// TODO save perception and update later
							log.error("Ignoring perception because world is still null");
						} else {
							Message msg = (Message) payload;
							boolean adressedToMe = msg.receivers != null ?
									msg.receivers.contains(username) // adressed to receivers
									: !username.equals(msg.sender); // adressed to everyone except the sender
							if (adressedToMe) {
								world.update(msg.fact);
								// the fact could be a job proposal request etc.
								sendPlannerMessages();
							}
						}
					}
				}
			}
		});
	}

	public void doStart() throws Exception {
		super.doStart();

		Authentication auth = memory.read(new Authentication(null, null));
		if (auth != null) {
			this.username = auth.getUsername();
			setLog(LogUtil.get(this, username));
			world = new World(username);
		} else {
			log.error("No authentication found");
		}

		// retrieving needed actions from own CommunicationBean
		sendAction = memory.read(new Action(
				"de.dailab.jiactng.agentcore.comm.ICommunicationBean#send",
				null, new Class[]{IJiacMessage.class,
				ICommunicationAddress.class}, null));
		if (sendAction == null)
			throw new RuntimeException("Could not find Communication... (sendAction)");

		registerAction = memory.read(new Action(
				"de.dailab.jiactng.agentcore.comm.ICommunicationBean#joinGroup",
				null, new Class[]{IGroupAddress.class}, null));
		if (registerAction == null)
			throw new RuntimeException("Could not find Communication... (registerAction)");

		invoke(registerAction, new Serializable[]{this.teamChannel});
	}

	public void processServerMessage(Document message) {
		IFact parseResult = messageParser.parse(message);

		if (parseResult instanceof SimStart) {
			// SimStart received
			SimStart simStart = (SimStart) parseResult;
			world.update(simStart);
			if (username.charAt(1) == '2') {
				log.debug(simStart);
				log.debug("Items: " + simStart.items.stream()
						.sorted((a, b) -> a.name.compareTo(b.name))
						.map(item -> "\n" + item.toString())
						.collect(Collectors.toList()));
			}
			//log.info(username + " is " + world.ownRole());
			sendIFact(world.ownRole(), null);
			decisionBean.setWorld(world);

		} else if (parseResult instanceof Perception) {
			// Perception received
			Perception perception = (Perception) parseResult;

			// send own perception to other agents
			// TODO only send relevant info
			//sendIFact(perception, null);

			world.update(perception);

			try {
				decisionBean.decide();
			} catch (Exception e) {
				log.error("DecisionBean failed: " + e, e);
			}

		} else if (parseResult instanceof SimEnd) {
			// SimEnd received
			SimEnd simEnd = (SimEnd) parseResult;
			//simEnd.setSimName(world.simulationId);

			YellowPages.resetFacilies();
			Role.resetRoles();
			AgentState.resetAgents();

			memory.write(simEnd);
			log.debug(simEnd);

		} else if (parseResult instanceof Bye) {
			Set<SimEnd> results = memory.readAllOfType(SimEnd.class);
			for (SimEnd rse : results) {
				log.info(rse);
			}
			System.out.flush();

			Runtime.getRuntime().halt(666);

		} else if (parseResult instanceof AuthResponse) {
			if (((AuthResponse) parseResult).isAuthSuccessful())
				log.info("Authentication ok");
			else log.error("Authentication failed!");
		}

	}

	public void sendPlannerMessages() {
		Message message;
		log.debug(world.self.getName() + " Starting to send .....");
		while ((message = JobPlanner.getInstance().pollMessage()) != null) {
			JiacMessage jiacMessage = new JiacMessage(message);
			log.debug(world.self + "sending: " + jiacMessage.toString());
			invoke(sendAction, new Serializable[]{jiacMessage, this.teamChannel});
		}
	}

	/**
	 * Sends an IFact to some team members.
	 *
	 * @param fact      the IFact object to send
	 * @param receivers names of the receiving agents (can include self),
	 *                  or null to send to all except self
	 */
	public void sendIFact(IFact fact, Collection<String> receivers) {
		Message message = new Message(world.self.username, receivers, fact);
		JiacMessage msg = new JiacMessage(message);
		invoke(sendAction, new Serializable[]{msg, this.teamChannel});
	}
}
