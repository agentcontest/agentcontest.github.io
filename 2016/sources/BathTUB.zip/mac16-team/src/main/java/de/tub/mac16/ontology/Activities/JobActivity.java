package de.tub.mac16.ontology.Activities;

import de.tub.mac16.ontology.Jobs.Job;
import de.tub.mac16.ontology.World;

/**
 * Tracks the additional actions to be executed by this agent to fulfill its part in the job.
 * When the job is accepted, this activity need to be added to the agent's metaActivity.
 */
public class JobActivity extends Activity {

	public final Job job; // TODO use this to track if we can still finish the job

	// TODO we could also track the assigned batches or the whole proposals/assignments

	public JobActivity(Job job, World world, IActivity prevActivity) {
		super(world, prevActivity);
		this.job = job;
	}

	@Override
	public String toString() {
		return "JobActivity{job=" + job + ", " + super.toString() + '}';
	}
}
