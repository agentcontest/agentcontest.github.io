package de.tub.mac16.ontology.Helpers;

public interface DetailedFact {
	int simulationStep = 0;
	boolean detailedFact = false;
	boolean calculatedFact = false;
}
