package de.tub.mac16.bean;

import de.tub.mac16.ontology.World;

public interface IDecisionBean {
	void decide();

	void setWorld(World world);
}
