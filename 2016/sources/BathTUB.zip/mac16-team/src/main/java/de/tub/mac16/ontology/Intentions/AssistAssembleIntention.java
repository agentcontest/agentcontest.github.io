package de.tub.mac16.ontology.Intentions;

import de.tub.mac16.connection.MessageConstants;
import de.tub.mac16.ontology.BasicAgentState;

public class AssistAssembleIntention extends Intention {
	public BasicAgentState agentState;

	public AssistAssembleIntention(BasicAgentState agentState) {
		super(MessageConstants.ACTION_ASSIST_ASSEMBLE, "assembler=" + agentState.username);
		this.agentState = agentState;
	}

	@Override
	public int getDuration() {
		// TODO wait for partner
		throw new IllegalArgumentException("Not implemented");
	}
}
