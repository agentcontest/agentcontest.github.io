package de.tub.mac16.ontology.Jobs;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac16.ontology.ItemBatch;

public class JobProposal implements IFact {
	private static final long serialVersionUID = -612188764200918196L;

	public final ItemBatch itemBatch;
	public final String forJob;
	public final String proposer;
	public final int cost;
	// TODO track how it would get executed

	public JobProposal(ItemBatch itemBatch, String forJob, String proposer, int cost) {
		this.itemBatch = itemBatch;
		this.forJob = forJob;
		this.proposer = proposer;
		this.cost = cost;
	}

	@Override
	public String toString() {
		return "JobProposal{proposer: " + proposer +
				", itemBatch:" + itemBatch.toString() +
				", forJob: " + forJob + "}";
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		JobProposal proposal = (JobProposal) o;

		if (itemBatch != null ? !itemBatch.equals(proposal.itemBatch) : proposal.itemBatch != null)
			return false;
		if (forJob != null ? !forJob.equals(proposal.forJob) : proposal.forJob != null)
			return false;
		return proposer != null ? proposer.equals(proposal.proposer) : proposal.proposer == null;

	}
}
