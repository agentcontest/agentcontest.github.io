package de.tub.mac16.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac16.ontology.Jobs.Job;

import java.util.LinkedList;

public class TeamState implements IFact {

	private static final long serialVersionUID = -5280840946993607856L;

	public int money;

	public LinkedList<Job> jobsTaken = new LinkedList<>();
	public LinkedList<Job> jobsPosted = new LinkedList<>();

	public TeamState(int money) {
		this.money = money;
	}

	@Override
	public String toString() {
		return "TeamState{" +
				"money=" + money +
				", jobsTaken=" + jobsTaken.size() +
				", jobsPosted=" + jobsPosted.size() +
				'}';
	}
}
