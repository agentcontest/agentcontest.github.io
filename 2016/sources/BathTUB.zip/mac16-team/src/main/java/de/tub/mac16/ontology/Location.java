package de.tub.mac16.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;

/**
 * Pure data class, no logic.
 */
public class Location implements IFact, ILocation {

	private static final long serialVersionUID = -2644139073497587869L;

	public final double longitude;
	public final double latitude;

	private static double proximity = 0.0002;

	public Location(double latitude, double longitude) {
		this.latitude = latitude;
		this.longitude = longitude;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Location other = (Location) obj;
		if (Math.round(this.latitude / proximity) != Math.round(other.latitude / proximity))
			return false;
		return Math.round(this.longitude / proximity) == Math.round(other.longitude / proximity);
	}

	/*
	 * Calculate distance between two points in latitude and longitude taking
	 * into account height difference. If you are not interested in height
	 * difference pass 0.0. Uses Haversine method as its base.
	 *
	 * lat1, lon1 Start point lat2, lon2 End point el1 Start altitude in meters
	 * el2 End altitude in meters
	 * @returns Distance in Meters
	 */
	public double distanceTo(Location location) {
		final int R = 6371; // Radius of the earth

		double latDistance = Math.toRadians(this.latitude - location.latitude);
		double lonDistance = Math.toRadians(this.longitude - location.longitude);
		double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
				+ Math.cos(Math.toRadians(location.latitude)) * Math.cos(Math.toRadians(this.latitude))
				* Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
		double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
		double distance = R * c * 1000; // convert to meters

		distance = Math.pow(distance, 2);

		return Math.sqrt(distance);
	}

	public boolean isCloseEnoughTo(Location otherLocation) {
		double latDif = Math.abs(otherLocation.latitude - latitude);
		double lonDif = Math.abs(otherLocation.longitude - longitude);
		return (latDif < World.proximity && lonDif < World.proximity);
	}

	@Override
	public String toString() {
		return "Location{lat=" + latitude + ", lon=" + longitude + '}';
	}

	@Override
	public Location getLocation() {
		return this;
	}
}
