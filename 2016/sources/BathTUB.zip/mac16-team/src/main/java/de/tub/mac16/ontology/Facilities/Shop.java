package de.tub.mac16.ontology.Facilities;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac16.ontology.Helpers.DetailedFact;
import de.tub.mac16.ontology.*;
import de.tub.mac16.ontology.Intentions.BuyIntention;
import de.tub.mac16.ontology.Intentions.Intention;

import java.io.Serializable;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class Shop extends Facility implements IFact, DetailedFact, IPlaceWithItems, ILocation {

	private static final long serialVersionUID = 8108015697433171253L;

	public int simulationStep;
	public int currentSimulationStep;
	public boolean detailedFact = false;

	public Map<Item, ShopStock> stock;

	private Shop(int simulationStep, String name, Location location) {
		super(name, location);
		this.simulationStep = simulationStep;
		this.currentSimulationStep = simulationStep;
		stock = new HashMap<>();
	}

	public static synchronized Shop getOrCreateShop(int simulationStep, String name, Location location) {
		if (YellowPages.getFacility(name) == null) YellowPages.putFacility(new Shop(simulationStep, name, location));
		return YellowPages.getFacility(name);
	}

	public static class ShopStock implements Serializable {

		private static final long serialVersionUID = 1L;

		public int cost;
		public int quantity;
		public int restock;
		public int minQuantity;

		public ShopStock(int cost, int quantity, int restock) {
			this.cost = cost;
			this.quantity = quantity;
			this.restock = restock;
			this.minQuantity = quantity;
		}

		@Override
		public String toString() {
			return String.format("%dx, %d$, %d restock", quantity, cost, restock);
		}
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public Integer getItemQuantity(Item item) {
		if (!stock.containsKey(item)) return 0;
		ShopStock stock = this.stock.get(item);
		if (stock == null) {
			return null;
		}
		return stock.quantity + Math.floorDiv(currentSimulationStep - (simulationStep - (stock.quantity % stock.restock)), stock.restock);
	}

	@Override
	public Integer getItemCost(Item item) {
		if (stock.get(item) == null) return null;

		ShopStock stockItem = stock.get(item);
		return stockItem.cost;
	}

	@Override
	public Iterable<Item> getAvailableItems() {
		return stock.keySet();
	}

	@Override
	public Intention getItemIntention(ItemWithQuantity itemWithQuantity) {
		return new BuyIntention(itemWithQuantity, stock.get(itemWithQuantity.item).cost);
	}

	@Override
	public String toString() {
		return super.toString()
				+ ", updated: " + simulationStep
				+ ", detailed: " + detailedFact
				+ ", stock: " + Arrays.toString(stock.entrySet().stream().map(e -> e.getKey().name + ": " + e.getValue()).toArray());
	}
}
