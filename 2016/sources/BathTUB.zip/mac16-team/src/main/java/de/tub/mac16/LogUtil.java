package de.tub.mac16;

import org.apache.log4j.Logger;

import java.text.SimpleDateFormat;
import java.util.Date;

public class LogUtil {

	public static Logger get(Object o, String username) {
		// TODO log username
		if (!(o instanceof Class)) o = o.getClass();
		return Logger.getLogger((Class) o);
	}

	public static Logger get(Object o) {
		return get(o, "?");
	}

	public static void setLoggingSysProps(String teamName) {
		System.setProperty("tubmac.startuptime", new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss").format(new Date()));
		System.setProperty("tubmac.teamname", teamName);
	}

	/**
	 * taken from org.apache.log4j.helpers.PatternParser.NamedPatternConverter.convert
	 *
	 * @param o         Object instance, whose class name will be shortened
	 * @param precision how many package names will be left
	 * @return class name of the object, with only the last "precision" package names
	 */
	public static String shortClassName(Object o, int precision) {
		String s = o.getClass().getName();
		int len = s.length();
		int end = len - 1;

		for (int i = precision; i > 0; --i) {
			end = s.lastIndexOf('.', end - 1);
			if (end == -1) {
				return s;
			}
		}

		return s.substring(end + 1, len);
	}

}
