package de.tub.mac16.ontology.Helpers;

public class Tuple<A,B>{

	public A a;
	public B b;

	public Tuple(A a, B b) {
		this.a = a; 
		this.b = b;
	}
}
