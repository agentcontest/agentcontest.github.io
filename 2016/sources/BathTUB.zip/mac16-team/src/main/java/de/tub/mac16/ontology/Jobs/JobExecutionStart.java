package de.tub.mac16.ontology.Jobs;

import de.dailab.jiactng.agentcore.knowledge.IFact;

public class JobExecutionStart implements IFact {
	public final Job job;

	public JobExecutionStart(Job job) {
		this.job = job;
	}

	@Override
	public String toString() {
		return "JobExecutionStart{" +
				"job=" + job.id +
				'}';
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		JobExecutionStart that = (JobExecutionStart) o;

		return job != null ? job.equals(that.job) : that.job == null;

	}
}
