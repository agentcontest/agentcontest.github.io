package de.tub.mac16.ontology.Intentions;

import de.tub.mac16.connection.MessageConstants;
import de.tub.mac16.ontology.Facilities.Facility;
import de.tub.mac16.ontology.ILocation;
import de.tub.mac16.ontology.Location;
import de.tub.mac16.ontology.Role;
import de.tub.mac16.ontology.World;
import de.tub.mac16.routing.CityMap;

import static de.tub.mac16.ontology.Helpers.Utils.ceilDiv;
import static de.tub.mac16.routing.CityMap.addRouteLength;

public class GotoIntention extends Intention {

	public final Facility facility;
	public final ILocation targetLocation;
	private final ILocation startLocation;
	private int remainingDuration;
	private int passedDuration = 0;
	private World world = null;

	public GotoIntention(ILocation start, ILocation target, int estimatedDuration) {
		super(MessageConstants.ACTION_GOTO, "");
		this.startLocation = start;
		this.targetLocation = target;
		remainingDuration = estimatedDuration;

		if(target instanceof Facility) {
			this.facility = (Facility) target;
			this.param = "facility=" + facility.name;
		} else {
			this.facility = null;
			this.param = "lat=" + targetLocation.getLocation().latitude + " lon=" + targetLocation.getLocation().longitude;
		}
	}

	/**
	 * if you use this the functions getCost and getDuration
	 * will only work correctly if you are a car or use them after
	 * first use of onResult() or isComplete()
	 *
	 * @param start
	 * @param target
	 */
	public GotoIntention(ILocation start, ILocation target) {
		super(MessageConstants.ACTION_GOTO, "");
		this.startLocation = start;
		this.targetLocation = target;
		remainingDuration = -1;

		if (target instanceof Facility) {
			this.facility = (Facility) target;
			this.param = "facility=" + facility.name;
		} else {
			this.facility = null;
			this.param = "lat=" + targetLocation.getLocation().latitude + " lon=" + targetLocation.getLocation().longitude;
		}
	}

	public GotoIntention(ILocation start, ILocation target, World world) {
		super(MessageConstants.ACTION_GOTO, "");
		this.startLocation = start;
		this.targetLocation = target;
		remainingDuration = -1;
		this.world = world;

		if (target instanceof Facility) {
			this.facility = (Facility) target;
			this.param = "facility=" + facility.name;
		} else {
			this.facility = null;
			this.param = "lat=" + targetLocation.getLocation().latitude + " lon=" + targetLocation.getLocation().longitude;
		}
	}

	@Override
	public boolean isComplete(World world) {
		this.world = world;
		return targetLocation.getLocation().equals(world.self.currentLocation);
	}

	@Override
	public int getDuration() {
		if (remainingDuration != -1) return remainingDuration;
		Role ownRole = Role.getRole("Car");
		if (world != null) {
			ownRole = Role.getRole(world.self.roleName);
		}
		return CityMap.getDuration(startLocation.getLocation(), targetLocation.getLocation(),ownRole);
	}

	@Override
	public int getCost() {
		return getDuration() * 10;
	}

	@Override
	public int getChargeDelta() {
		return getDuration() * -10;
	}

	@Override
	public Location getLastLocation() {
		return targetLocation.getLocation();
	}

	@Override
	public void onResult(String result, World world) {
		this.world = world;
		super.onResult(result, world);
		if (state == State.SUCCESSFUL) {
			passedDuration += 1;
		}

		int speed = world.ownRole().speed;
		remainingDuration = ceilDiv(world.self.routeLength, speed);

		if (world.self.routeLength > 0) {
			Integer length = world.self.routeLength + passedDuration * speed;
			addRouteLength(startLocation.getLocation(), world.self.currentLocation, length, speed);
		}
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		GotoIntention other = (GotoIntention) o;
		if (!targetLocation.equals(other.targetLocation)) return false;
		return facility != null ? facility.equals(other.facility) : other.facility == null;
	}

	@Override
	public int hashCode() {
		int result = facility != null ? facility.hashCode() : 0;
		result = 31 * result + targetLocation.hashCode();
		return result;
	}
}
