package de.tub.mac16.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

/**
 * Pure data class, no logic.
 */
public class Role implements IFact {

	private static final long serialVersionUID = 3964297799736342966L;

	private static HashMap<String, Role> roles = new HashMap<>();

	public final String name;
	public final int speed;
	public final int batteryCapacity;
	public final int loadCapacity;
	public final Set<Item> tools = new HashSet<>();

	public static Role getRole(String rolename) {
		return roles.get(rolename);
	}

	public static synchronized Role getOrCreateRole(String name, int speed, int batteryCapacity, int loadCapacity) {
		if (!roles.containsKey(name)) roles.put(name, new Role(name, speed, batteryCapacity, loadCapacity));
		return roles.get(name);
	}

	private Role(String name, int speed, int batteryCapacity, int loadCapacity) {
		this.name = name;
		this.speed = speed;
		this.batteryCapacity = batteryCapacity;
		this.loadCapacity = loadCapacity;
	}

	@Override
	public String toString() {
		String str = "Role - name: " + name + ", speed: " + speed + ", battery: " + batteryCapacity + ", load: " + loadCapacity;
		str += ", tools: [ ";
		for (Item i : this.tools)
			str += i.name + " ";
		str += "]";
		return str;
	}

	public static void resetRoles() {
		roles.clear();
	}
}
