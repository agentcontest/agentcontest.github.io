package de.tub.mac16.ontology.Helpers;

/**
 * Created by holgerschuh on 30.06.16.
 */
public class Pair<K, V> {
	public K key;
	public V value;

	public Pair(K key, V value) {
		this.key = key;
		this.value = value;
	}
}
