package de.tub.mac16.ontology.Intentions;

import de.tub.mac16.connection.MessageConstants;
import de.tub.mac16.ontology.Item;

public class DumpIntention extends Intention {
	public Item item;
	public Integer quantity;
	public int cost;

	public DumpIntention(Item item, Integer quantity, int cost) {
		super(MessageConstants.ACTION_DUMP, "item=" + item.name + " amount=" + quantity.toString());
		this.item = item;
		this.quantity = quantity;
	}

	@Override
	public int getCapacityDelta() {
		return +item.volume * quantity;
	}

	@Override
	public int getCost() {
		return cost * quantity;
	}
}
