package de.tub.mac16.ontology.Intentions;

import de.tub.mac16.connection.MessageConstants;

public class CallBreakdownServiceIntention extends Intention {
	public CallBreakdownServiceIntention() {
		super(MessageConstants.ACTION_CALL_BREAKDOWN_SERVICE, "");
	}

	// TODO does it teleport us to the nearest charger? if so, @Override getLastLocation()

	@Override
	public int getDuration() {
		// TODO how long does CallBreakdownServiceIntention take?
		throw new IllegalArgumentException("Not implemented");
	}
}
