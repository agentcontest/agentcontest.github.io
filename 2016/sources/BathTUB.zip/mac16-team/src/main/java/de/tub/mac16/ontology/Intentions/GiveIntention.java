package de.tub.mac16.ontology.Intentions;

import de.tub.mac16.bean.DefaultDecisionBean;
import de.tub.mac16.connection.MessageConstants;
import de.tub.mac16.ontology.AgentState;
import de.tub.mac16.ontology.ItemWithQuantity;
import de.tub.mac16.ontology.World;

public class GiveIntention extends Intention {
	public AgentState recieverAgent;
	public ItemWithQuantity item;
	private boolean giveSucceded = false;
	private boolean tryToGive = false;

	private String trueAction;
	private String trueParam;
	static final String WAITING_ACTION = MessageConstants.ACTION_SKIP;

	public GiveIntention(AgentState reciever, ItemWithQuantity item) {
		super(MessageConstants.ACTION_GIVE, "agent=" + reciever.username + " item=" + item.item.name + " amount=" + item.quantity.toString());
		this.recieverAgent = reciever;
		this.item = item;
		trueAction = action;
		trueParam = param;
	}

	/**
	 * override this if intention is depending on some value in world
	 * (e.g. recieve only when other Agent gives .....)
	 *
	 * @param world
	 */
	@Override
	public void prepareToBeSend(World world) {
		if (recieverAgent.getLocation().equals(world.self.getLocation())) {
			action = trueAction;
			param = trueParam;
			tryToGive = true;
			log.debug("Try to give to " + recieverAgent.username);
		} else {
			action = WAITING_ACTION;
			param = "";
			tryToGive = false;
		}
	}

	@Override
	public int getDuration() {
		// TODO wait for partner
		return 1;
		//throw new IllegalArgumentException("Not implemented");
	}

	@Override
	public int getCapacityDelta() {
		return +item.getVolume() * item.quantity;
	}

	/**
	 * Override this if the intention does not need to
	 * be run to be completed (eg. goto), or if it needs
	 * additional checks.
	 *
	 * @param world
	 */
	@Override
	public boolean isComplete(World world) {
		return giveSucceded;
	}

	/**
	 * Called by {@link DefaultDecisionBean}
	 * to process the result from the server.
	 *
	 * @param result result of this action
	 * @param world
	 */
	@Override
	public void onResult(String result, World world) {
		super.onResult(result, world);
		if (tryToGive) {
			if (world.self.lastActionResult.equals(MessageConstants.RESULT_SUCCESSFUL)) {
				giveSucceded = true;
				world.self.giveItemTo(item, recieverAgent);
				log.debug("Gave to " + recieverAgent.username);
			}
		}
	}


	@Override
	public int getCost() {
		return 0;
	}
}
