package de.tub.mac16.ontology.Jobs;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac16.ontology.Facilities.Shop;
import de.tub.mac16.ontology.Item;
import de.tub.mac16.ontology.ItemWithQuantity;
import de.tub.mac16.ontology.Message;
import de.tub.mac16.ontology.World;
import org.apache.log4j.Logger;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Singleton for organizing the planning process of any jobs.
 * It tracks incoming jobs and plans them one job at a time.
 * <p>
 * Agents should only interact with the planner through the public methods:
 * getInstance, addJob, startPlanningIfIdle, addProposal, pollMessage
 * <p>
 * The planning happens by distributing the items of a job to the agents
 * one item type at a time, until all items are assigned.
 * <p>
 * The messages needed for coordination are always sent by
 * the last agent to call a method of the planner object.
 */
public class JobPlanner implements IFact {

	private static JobPlanner instance = new JobPlanner();

	public static JobPlanner getInstance() {
		return instance;
	}

	/**
	 * Do not call the constructor directly. Use getInstance instead.
	 * It is private, so only one planner instance is ever created (Singleton).
	 */
	private JobPlanner() {
	}

	private Logger log = Logger.getLogger(this.getClass());

	/**
	 * When planning, this gets filled with messages to the agents.
	 * After calling any method on the planner, these messages need to be sent by the calling agent.
	 * <p>
	 * This queue exists because the JobPlanner itself cannot send messages,
	 * as it is not a full agent, but just a storage object with some utility functions.
	 */
	final LinkedList<Message> messages = new LinkedList<>();

	LinkedList<Job> nextJobs = new LinkedList<>();

	Job activeJob;

	/**
	 * The items required for the active job
	 * that are not yet assigned to agents.
	 * <p>
	 * This list is created in startPlanningNextJob
	 * and is ordered by which items to assign first.
	 */
	LinkedList<ItemWithQuantity> unassignedItems;

	ItemWithQuantity activeItem;

	/**
	 * Gets filled by agents asynchronously with their proposals for the activeItem.
	 * The last agent to propose calculates and assigns the best proposal.
	 */
	Map<String, JobProposal> proposals = new HashMap<>();

	/**
	 * Tracks the jobs that have already been planned, and their respective plans.
	 * This prevents the planner from planning a job multiple times.
	 */
	final HashMap<Job, LinkedList<JobProposal>> plannedJobs = new HashMap<>();

	/**
	 * currentTimeMillis when the planning of the active job started, used for measuring performance.
	 */
	long startTime;

	/**
	 * @return an unsent message, or null if there are none.
	 */
	public synchronized Message pollMessage() {
		return messages.poll();
	}

	/**
	 * Adds the job to the list of jobs to plan, if not already tracked.
	 */
	public synchronized void addJob(Job job) {
		if (!nextJobs.contains(job) && !plannedJobs.containsKey(job)) {
			log.debug("Adding new job " + job);
			nextJobs.add(job);
		}
	}

	/**
	 * If no job is currently being planned, this starts the planning process,
	 * which continues to plan until all known jobs are planned.
	 * <p>
	 * After calling this function, any queued messages have to be sent.
	 */
	public synchronized void startPlanningIfIdle(World world) {
		if (activeJob != null || nextJobs.isEmpty()) {
			log.debug(world.self.getName() + "job active: " + (activeJob != null));
			log.debug(world.self.getName() + "next Jobs empty: " + nextJobs.isEmpty());
			return;
		}

		Collections.sort(nextJobs, (j1, j2) -> {
			Integer[] itemCosts = new Integer[]{0, 0};
			Job[] jobs = new Job[]{j1, j2};

			// sum item costs assuming we have to buy them in shops
			for (int i = 0; i < 2; i++) {
				for (Item item : jobs[i].itemsRequired.keySet()) {
					LinkedList<Shop> knownShopsSellingItem = world
							.streamShopsSellingItem(item)
							// TODO
							.filter(shop -> shop.stock.get(item) != null)
							.collect(Collectors.toCollection(LinkedList::new));
					if (knownShopsSellingItem.isEmpty()) {
						return Integer.compare(j1.begin, j2.begin);
					}

					for (Shop s : knownShopsSellingItem)
						itemCosts[i] += s.stock.get(item).cost;

					itemCosts[i] /= knownShopsSellingItem.size();

					// TODO try to add some costs for a simple journey to n shops
					log.debug("Average costs for item" + item.name + " = " + itemCosts[i]);
				}
			}

			log.debug(itemCosts[0] + " equals " + itemCosts[1] + "?");
			return Integer.compare(itemCosts[0], itemCosts[1]);
		});

		startPlanningNextJob();
	}

	/**
	 * Enters a proposal of an agent to the currently planned item.
	 * If all proposals are collected, this triggers the selection of the best proposal.
	 * <p>
	 * After calling this function, any queued messages have to be sent.
	 */
	public synchronized void addProposal(JobProposal proposal, int teamSize) {
		proposals.put(proposal.proposer, proposal);
		if (proposals.size() >= teamSize) {
			handleProposals();
		} else {
//			log.debug("Got " + proposals.size() + "/" + teamSize + " proposals" +
//					" for " + activeItem + " in " + activeJob.id + ": " + proposals.keySet());
		}
	}

	/**
	 * Gets the next job to plan from nextJobs, stores it in activeJob,
	 * and marks it as being planned. Then calculates and stores
	 * the item assigning order in unassignedItems.
	 * Finally requests the agents to propose for this item.
	 */
	private void startPlanningNextJob() {
		log.debug("Start planing next Job ...");
		activeJob = nextJobs.poll();

		if (activeJob == null) {
			log.debug("No jobs left to plan");
			return;
		}

		log.debug("Starting planning for " + activeJob);
//		log.debug((activeJob.begin - world.simulationStep) + " rounds left to plan");

		plannedJobs.put(activeJob, new LinkedList<>());

		// sorting order: largest item, most total volume, lexicographically first name
		unassignedItems = activeJob.itemsRequired.entrySet().stream()
				.map(e -> new ItemWithQuantity(e.getKey(), e.getValue()))
				.sorted((a, b) -> {
					// large items first
					int volumes = -Integer.compare(a.item.volume, b.item.volume);
					if (volumes != 0) return volumes;
					// most total volume first
					int quantities = -Integer.compare(a.item.volume * a.quantity,
							b.item.volume * b.quantity);
					if (quantities != 0) return quantities;
					return a.item.name.compareTo(b.item.name);
				}).collect(Collectors.toCollection(LinkedList::new));

		log.debug("Number of Unassigned Items: " + unassignedItems.size());

		startTime = System.currentTimeMillis();

		planForNextItem();
	}

	/**
	 * If there is another item to assign, stores it in activeItem, and
	 * resets the proposals. Then requests the agents to propose for this item.
	 * If all items of the active job are assigned, evaluates the active job,
	 * and tells the agents to do it, or starts planning the next job if any.
	 */
	private void planForNextItem() {
		proposals.clear();
		if (activeItem == null || activeItem.quantity <= 0) {
			log.debug("no active Item or active Item Quantity <= 0");
			activeItem = unassignedItems.poll();
		}
		if (activeItem != null) {
			log.debug("qeued new JobProposalRequest");
			queueMessage(new JobProposalRequest(activeJob, activeItem), null);
			// TODO detect timeouts: if an agent crashes before it can answer, we wait indefinitely
		} else {
			long planningTime = System.currentTimeMillis() - startTime;
			log.debug("Done planning after " + planningTime + "ms for " + activeJob);

			String plan = plannedJobs.get(activeJob).stream()
					.map(proposal -> proposal.proposer + ": " + proposal.itemBatch)
					.reduce((l, r) -> l + ", " + r).orElse("<empty>");
			log.debug("Plan for " + activeJob.id + ": " + plan);

			finishPlanning();
		}
	}

	private void finishPlanning() {
		// TODO this method is untested: accept job yes/no, has next job yes/no

		boolean notAGoodJobToDo = false; // TODO do not accept jobs that are bad for us
		int cost = plannedJobs.get(activeJob).stream().mapToInt(p -> p.cost).reduce(0, Integer::sum);
		log.debug("Proposals for job " + activeJob + ":\n" + Arrays.toString(plannedJobs.get(activeJob).toArray()));
		if (activeJob instanceof PricedJob) {
			if (((PricedJob) activeJob).reward < cost) {
				notAGoodJobToDo = true;
			}
		}
		if (activeJob instanceof AuctionJob) {
			if (((AuctionJob) activeJob).maxBid < cost) {
				notAGoodJobToDo = true;
			}
		}

		if (notAGoodJobToDo) {
			log.debug("Bad " + activeJob + "with cost: " + cost + " is not profitable, planning next");
			startPlanningNextJob();
		} else {
			log.info(activeJob + " is profitable, with cost: " + cost + " starting");
			queueMessage(new JobExecutionStart(activeJob), null);
			activeJob = null;
		}
	}

	/**
	 * When receiving the last {@link JobProposal} (of 16) from another agent,
	 * this method assigns an agent to the current item
	 * according to the item's availability for this agent.
	 * All agents should have given their proposals before calling handleProposals.
	 */
	private void handleProposals() {
		JobProposal bestProposal = null;
		for (JobProposal proposal : proposals.values()) {
			if (proposal.itemBatch == null) {
				log.warn("Job is rejected. item "
						+ activeItem + " is not available ");
				startPlanningNextJob();
				return;
			}
			// heuristic: most of the time, quantity will be equal and maximal,
			// durations are already considered a bit by each agent
			if (bestProposal == null
					|| proposal.itemBatch.quantity > bestProposal.itemBatch.quantity
					|| proposal.itemBatch.rounds < bestProposal.itemBatch.rounds) {
				bestProposal = proposal;
			}
		}
		if (bestProposal == null) {
			log.error("No proposal for " + activeItem + ", ");
			startPlanningNextJob();
			return;
		}

		Integer quantity = bestProposal.itemBatch.quantity;
		if (quantity == null || quantity <= 0) {
			log.error("Bad proposal for " + activeItem + ": " + bestProposal);
			startPlanningNextJob();
			return;
		}
		if (quantity > activeItem.quantity)
			bestProposal.itemBatch.quantity = activeItem.quantity;

		plannedJobs.get(activeJob).add(bestProposal);

		ArrayList<String> receivers = new ArrayList<>(1);
		receivers.add(bestProposal.proposer);
		queueMessage(new JobAssignment(activeJob, bestProposal), receivers);

		activeItem.quantity -= bestProposal.itemBatch.quantity;
		planForNextItem();
	}

	/**
	 * Adds a {@link Message} to the messages list, which will later be sent by the agent that is currently interacting with the planner.
	 *
	 * @param fact      instance of either {@link JobProposalRequest}, {@link JobAssignment} , {@link JobExecutionStart}
	 * @param receivers collection of agents to send the message to, null for the whole team
	 */
	private void queueMessage(IFact fact, Collection<String> receivers) {
		log.debug("adding new messages to message qeue ... " + fact.toString());
		messages.add(new Message("JobPlanner", receivers, fact));
	}
}
