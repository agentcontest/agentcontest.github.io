package de.tub.mac16.ontology.Helpers;

public class Quadruplet<A,B,C,D> {
		public A a;
		public B b;
		public C c;
		public D d;
		public Quadruplet() {};
		public Quadruplet(A a, B b, C c, D d) {
			setData(a, b, c, d);
		}
		public void setData(A a, B b, C c, D d) {
			this.a = a;
			this.b = b;
			this.c = c;
			this.d = d;
		}
	}
