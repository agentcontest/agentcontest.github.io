package de.tub.mac16.ontology.Jobs;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac16.ontology.ItemWithQuantity;

public class JobProposalRequest implements IFact {
	public final Job job;
	public final ItemWithQuantity item;

	public JobProposalRequest(Job job, ItemWithQuantity item) {
		this.job = job;
		this.item = item;
	}

	@Override
	public String toString() {
		return "JobProposalRequest{" +
				"job=" + job.id +
				", item=" + item +
				'}';
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		JobProposalRequest other = (JobProposalRequest) o;

		if (job != null ? !job.equals(other.job) : other.job != null)
			return false;
		return item != null ? item.equals(other.item) : other.item == null;

	}
}
