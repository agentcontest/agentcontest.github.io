package de.tub.mac16.ontology.Activities;

import de.tub.mac16.ontology.Intentions.Intention;
import de.tub.mac16.ontology.Location;
import de.tub.mac16.ontology.World;

import java.util.LinkedList;

public interface IActivity {

	/**
	 * @return the intention that will be sent to the server in the next response, or null if this activity is done
	 */
	Intention getCurrentIntention();

	/**
	 * Updates the current intention with the result from the server.
	 * If the current intention is done, advances to the next intention.
	 */
	void onResult(String result, World world);

	/**
	 * @return false if there are any intentions left to do
	 */
	boolean isComplete(World world);

	/**
	 * @return number of rounds this activity will take, without random failures
	 */
	int getDuration();

	// TODO getCost - calculate from facilities (charging, shops, workshops, ...)

	int getCost();

	/**
	 * Used for planning.
	 *
	 * @return my targetLocation after the last intention, or null if unchanged
	 */
	Location getLastLocation();

	/**
	 * @return the difference in capacity after the activity,
	 * negative means less available - the agent uses more of its storage,
	 * positive means the agent frees up space in its storage
	 */
	int getCapacityDelta();

	int getChargeDelta();

	/**
	 * used for calculating the last location if this activity has no goto intentions
	 */
	IActivity getPrevActivity();

	void setPrevActivity(IActivity activity);

	LinkedList<Intention> getIntentions();

	default int chargeAfterActivityIsFinished() {
		int ret = startingCharge();
		for (Intention intention : getIntentions())
			ret += intention.getChargeDelta();
		return ret;
	}

	int startingCharge();
}