package de.tub.mac16.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;

/**
 * Pure data class, no logic.
 */
public class SimEnd implements IFact {

	private static final long serialVersionUID = 5719239935733798130L;

	private String simName;
	private String ranking;
	private String score;

	public void setSimName(String name) {
		this.simName = name;
	}

	public String getSimName() {
		return simName;
	}

	public void setRanking(String ranking) {
		this.ranking = ranking;
	}

	public String getRanking() {
		return ranking;
	}

	public void setScore(String score) {
		this.score = score;
	}

	public String getScore() {
		return score;
	}

	@Override
	public String toString() {
		return "Simulation: " + simName
				+ " Score: " + score
				+ " Ranking: " + ranking;
	}
}
