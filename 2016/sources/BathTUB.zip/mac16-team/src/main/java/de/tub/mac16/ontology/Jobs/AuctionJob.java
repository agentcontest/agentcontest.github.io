package de.tub.mac16.ontology.Jobs;

import de.dailab.jiactng.agentcore.knowledge.IFact;

public class AuctionJob extends Job implements IFact {

	private static final long serialVersionUID = -4710899280034861855L;
	public int fine;
	public int maxBid;
	public int ourBid = -1;

	public AuctionJob(String id, String storageId, int begin, int end, int maxBid, int fine) {
		super(id, storageId, begin, end);
		this.maxBid = maxBid;
		this.fine = fine;
	}

	@Override
	public String toString() {
		return "Auction " + super.toString() + " maxBid: " + maxBid + " ourBid: " + ourBid + "fine: " + fine + "}";
	}
}
