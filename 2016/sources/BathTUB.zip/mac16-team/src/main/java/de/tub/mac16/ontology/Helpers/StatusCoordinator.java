package de.tub.mac16.ontology.Helpers;

import de.tub.mac16.ontology.AgentState;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by holgerschuh on 26.06.16.
 */

//https://de.wikibooks.org/wiki/Muster:_Java:_Singleton

//package org.wikibooks.de.java.pattern;
//public class Singleton {
//
//	// Eine (versteckte) Klassenvariable vom Typ der eigene Klasse
//	private static Singleton instance;
//	// Verhindere die Erzeugung des Objektes über andere Methoden
//	private Singleton () {}
//	// Eine Zugriffsmethode auf Klassenebene, welches dir '''einmal''' ein konkretes
//	// Objekt erzeugt und dieses zurückliefert.
//	// Durch 'synchronized' wird sichergestellt dass diese Methode nur von einem Thread
//	// zu einer Zeit durchlaufen wird. Der nächste Thread erhält immer eine komplett
//	// initialisierte Instanz.
//	public static synchronized Singleton getInstance () {
//		if (Singleton.instance == null) {
//			Singleton.instance = new Singleton ();
//		}
//		return Singleton.instance;
//	}
//}

public class StatusCoordinator {
	private static StatusCoordinator instance;
	//inDiscoverMode<Agent,discovermodeYesOrNo>
	private static HashMap<AgentState, Boolean> inDiscoverMode = new HashMap<>();
	private static LinkedList<AgentState> hasEverEnteredDiscoverMode = new LinkedList<>();


	private StatusCoordinator() {
	}

	public static synchronized StatusCoordinator getInstance() {
		if (StatusCoordinator.instance == null) {
			StatusCoordinator.instance = new StatusCoordinator();
		}
		return StatusCoordinator.instance;
	}

	public static synchronized void anounceDiscoveryModeOnOrOff(AgentState agent, Boolean onOrOff) {
		inDiscoverMode.put(agent, onOrOff);
		if (onOrOff && !hasEverEnteredDiscoverMode.contains(agent)) hasEverEnteredDiscoverMode.add(agent);
	}

	public static synchronized Boolean agentInDiscoveryMode(AgentState agent) {
		if (!inDiscoverMode.containsKey(agent)) return false;
		return inDiscoverMode.get(agent);
	}

	public static synchronized Boolean agentHasEverEnteredDiscoveryMode(AgentState agent) {
		return hasEverEnteredDiscoverMode.contains(agent);
	}

	public static synchronized List<AgentState> getAgentsInDiscoveryMode() {
		LinkedList<AgentState> ret = new LinkedList<>();
		for (AgentState agent : inDiscoverMode.keySet()) {
			if (inDiscoverMode.get(agent)) ret.add(agent);
		}
		return ret;
	}

}
