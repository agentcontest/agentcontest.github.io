package de.tub.mac16.ontology.Intentions;

import de.tub.mac16.LogUtil;
import de.tub.mac16.connection.MessageConstants;
import de.tub.mac16.ontology.Jobs.Job;
import de.tub.mac16.ontology.World;

public class DeliverJobIntention extends Intention {
	public final Job job;
	public final int deliveredVolume;

	public DeliverJobIntention(Job job, int deliveredVolume) {
		super(MessageConstants.ACTION_DELIVER_JOB, "job=" + job.id);
		this.job = job;
		this.deliveredVolume = deliveredVolume;
	}

	@Override
	public void onResult(String result, World world) {
		if (result.equals(MessageConstants.RESULT_SUCCESSFUL)) {
			LogUtil.get(this).debug("Job " + job + " is delivered successfully!");
		} else if (!result.equals(MessageConstants.RESULT_SUCCESSFUL_PARTIAL)) {
			LogUtil.get(this).error("Job " + job + " is delivered " + result);
		}
		if (MessageConstants.RESULT_FAILED_JOB_STATUS.equals(result)) {
			world.self.availableItems.clear();
			world.self.availableItems.putAll(world.self.items);
			world.metaActivity.removeActivity(world.ownJobActivities.get(job.id));
		}
		super.onResult(result, world);
	}

	@Override
	public int getCapacityDelta() {
		return +deliveredVolume;
	}
}
