package de.tub.mac16.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac16.ontology.Helpers.NestedHashMap;
import de.tub.mac16.ontology.Intentions.ReceiveIntention;

import java.util.Collection;
import java.util.HashMap;
import java.util.stream.Stream;

public class AgentState extends BasicAgentState implements IFact, IPlaceWithItems {
	private static final long serialVersionUID = -3093853455388360779L;

	public int charge;
	public int load;

	public String lastAction;
	public String lastActionParam;
	public String lastActionResult;

	public HashMap<Item, Integer> availableItems = new HashMap<>();

	private static HashMap<String, AgentState> agents = new HashMap<>();
	private static NestedHashMap<String, AgentState> teams = new NestedHashMap<>();

	private AgentState(String username, String teamName, String roleName) {
		super(username, teamName, roleName);
	}

	private HashMap<String, ItemWithQuantity> giveItemTo = new HashMap<>();

	private World world = null;

	public World getWorld() {
		return world;
	}

	public void setWorld(World world) {
		this.world = world;
	}

	public static synchronized AgentState getOrCreateAgentState(String username, String teamName, String roleName) {
		if (!agents.containsKey(username)) {
			AgentState agent = new AgentState(username, teamName, roleName);
			agents.put(username, agent);
			teams.addValue(teamName, username, agent);
		}
		return agents.get(username);
	}

	public static AgentState getAgent(String agentname) {
		return agents.get(agentname);
	}

	public static Collection<AgentState> getOwnTeam(AgentState agent) {
		return teams.get(agent.teamName).values();
	}

	public static Stream<AgentState> getEnemies(AgentState agent) {
		return agents.values().stream().filter(a -> !a.teamName.equals(agent.teamName));
	}

	public static Collection<AgentState> getAgents() {
		return agents.values();
	}

	public static void resetAgents() {
		agents.clear();
		teams.clear();
	}


//	public AgentState(BasicAgentState other) {
//		super(other);
//		if (other instanceof AgentState) update((AgentState) other);
//	}
//
//	public void update(AgentState other) {
//		if (other == null) return;
//
//		super.update(other);
//
//		charge = other.charge;
//		load = other.load;
//		lastAction = other.lastAction;
//		lastActionParam = other.lastActionParam;
//		lastActionResult = other.lastActionResult;
//	}

	@Override
	public String toString() {
		return "AgentState{" +
				super.toString() +
				", charge=" + charge +
				", load=" + load +
				", lastAction='" + lastAction + '\'' +
				", lastActionParam='" + lastActionParam + '\'' +
				", lastActionResult='" + lastActionResult + '\'' +
				'}';
	}

	@Override
	public String getName() {
		return username;
	}

	@Override
	public Integer getItemQuantity(Item item) {
		return items.get(item);
	}

	@Override
	public Integer getItemCost(Item item) {
		if (!items.containsKey(item)) {
			return null;
		} else {
			return 0;
		}
	}

	@Override
	public Iterable<Item> getAvailableItems() {
		return availableItems.keySet();
	}

	@Override
	public ReceiveIntention getItemIntention(ItemWithQuantity itemWithQuantity) {
		throw new IllegalStateException("TODO make sure the other agent is giving the item to us in that round");
//		return new ReceiveIntention(itemWithQuantity);
	}

	public void giveItemTo(ItemWithQuantity item, AgentState agent) {
		giveItemTo.remove(agent.getName(), item);
	}


	public HashMap<String, ItemWithQuantity> outgoingDeliveries() {
		return giveItemTo;
	}

}
