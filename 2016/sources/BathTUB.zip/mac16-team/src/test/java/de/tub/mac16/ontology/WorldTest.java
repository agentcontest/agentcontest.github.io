package de.tub.mac16.ontology;

import de.tub.mac16.ontology.Facilities.Facility;
import de.tub.mac16.routing.CityMap;
import org.junit.Before;
import org.junit.Test;

import java.util.Collections;
import java.util.LinkedList;

import static org.junit.Assert.*;

public class WorldTest {

	public static final String username = "a1";
	private World world;

	private LinkedList<Item> items;
	private Role drone;
	private SimStart simStart;
	private AgentState self;

	@Before
	public void setUp() {
		items = new LinkedList<>();

		drone = new Role("Drone", 1, 42, 999);
		simStart = new SimStart("0", "unknownMap", 0, 999, "A", drone, items);

		self = new AgentState("a1", "A", "Drone");

		world = new World("a1");
	}

	@Test
	public void testUpdateSimStart() {
		world.update(simStart);
		assertWorldIntegrity();
	}

	@Test
	public void testDoubleSimStart() {
		world.update(simStart);
		world.update(simStart);
		assertWorldIntegrity();
	}

	private void assertWorldIntegrity() {
		assertNotNull(world.self);
		assertNotNull(world.cityMap);
		assertEquals("a1", world.self.username);
		assertEquals(drone.name, world.self.roleName);
		assertEquals(world.self, world.teamAgents.get(username));
		assertTrue(world.roles.containsValue(drone));
		assertEquals(items.size(), world.items.size());
	}

	@Test
	public void testUpdatePerception() {
		world.update(simStart);

		AgentState oldSelf = world.self;
		CityMap oldMap = world.cityMap;

		AgentState newSelf = new AgentState(self);
		newSelf.lastAction = "someAction";
		newSelf.lastActionParam = "someParam";
		newSelf.lastActionResult = "someResult";
		Location location = new Location(12, 34);
		newSelf.currentLocation = location;
		newSelf.charge = 23;
		Perception perception = new Perception("4", 3, 123, 234, newSelf, new TeamState(0))
				.withAgents(new BasicAgentState(newSelf));

		world.update(perception);

		assertWorldIntegrity();

		assertNotSame(self, world.self);
		assertEquals(oldSelf, world.self);
		assertEquals(oldMap, world.cityMap);

		assertEquals("4", world.requestId);
		assertEquals(3, world.simulationStep);

		assertEquals("someAction", world.self.lastAction);
		assertEquals("someParam", world.self.lastActionParam);
		assertEquals("someResult", world.self.lastActionResult);
		assertEquals(location, world.self.currentLocation);
		assertEquals(23, world.self.charge);

		// test that fields get updated after second update

		newSelf = new AgentState(self);
		newSelf.lastAction = "someOtherAction";
		newSelf.lastActionParam = "someOtherParam";
		newSelf.lastActionResult = "someOtherResult";
		location = new Location(56, 78);
		newSelf.currentLocation = location;
		newSelf.charge = 12;
		perception = new Perception("5", 4, 234, 123, newSelf, new TeamState(0))
				.withAgents(new BasicAgentState(newSelf));

		world.update(perception);

		assertWorldIntegrity();

		assertEquals("5", world.requestId);
		assertEquals(4, world.simulationStep);

		assertEquals("someOtherAction", world.self.lastAction);
		assertEquals("someOtherParam", world.self.lastActionParam);
		assertEquals("someOtherResult", world.self.lastActionResult);
		assertEquals(location, world.self.currentLocation);
		assertEquals(12, world.self.charge);
	}

	// TODO update shop: different info levels
	// TODO update charger: different info levels

	// TODO update enemy

	// TODO update JobAssignment: update JobActivity, different ways to get an item
	// TODO update JobExecutionStart: copy JobActivity intentions to Activity, send bid

	// TODO shopsSellingItem: different info levels
	// TODO getItemAvailability: get from shops, agents, storages, crafting
	// TODO getJobProposal: adjust batch

}
