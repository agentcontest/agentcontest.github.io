package de.tub.mac16.ontology.Jobs;

import de.tub.mac16.ontology.Facilities.Shop;
import de.tub.mac16.ontology.*;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class JobPlannerTest {

	JobPlanner planner = JobPlanner.getInstance();
	Job job;
	Item item1 = new Item("item1", 20, false);
	Item item2 = new Item("item2", 10, false);
	Item item3 = new Item("item3", 5, false);

	World world = new World("a1");

	@Before
	public void setUp() {
		job = new PricedJob("001", "0", 0, 10, 1000);
		job.itemsRequired.put(item2, 4);
		job.itemsRequired.put(item1, 3);
		job.itemsRequired.put(item3, 5);

		planner.messages.clear();
		planner.nextJobs.clear();
		planner.activeJob = null;
		planner.unassignedItems = null;
		planner.activeItem = null;
		planner.proposals.clear();
		planner.plannedJobs.clear();
	}

	/**
	 * TODO is this working as intended ?
	 *
	 * @param item
	 * @param amount
	 * @param proposer
	 * @return
	 */
	private JobProposal proposalForItem(Item item, int amount, String proposer) {
		IPlaceWithItems somewhere = new Shop(0, "shop0", new Location(0, 0));
		return new JobProposal(new ItemBatch(item, amount, somewhere, 0, 0), null, proposer, 0);
	}

	/**
	 * TODO is this working as intended ?
	 * @param batch
	 * @param proposer
	 * @return
	 */
	private JobProposal proposalForBatch(ItemBatch batch, String proposer) {
		return new JobProposal(batch, null, proposer,0);
	}

	@Test
	public void activeItem() {
		planner.addJob(job);
		planner.startPlanningIfIdle(world);
		assertEquals(new ItemWithQuantity(item1, 3), planner.activeItem);
		assertEquals(new ItemWithQuantity(item2, 4), planner.unassignedItems.peekFirst());
		assertEquals(new ItemWithQuantity(item3, 5), planner.unassignedItems.peekLast());
	}

	@Test
	public void activeItemAfterPartialProposal() {
		planner.addJob(job);
		planner.startPlanningIfIdle(world);
		planner.messages.poll();
		JobProposal proposal = proposalForItem(item1, 2, "a1");
		planner.addProposal(proposal, 1);

		assertEquals(new ItemWithQuantity(item1, 1), planner.activeItem);
		assertEquals(proposal, ((JobAssignment) planner.messages.getFirst().fact).proposal);
		assertTrue(planner.messages.getLast().fact instanceof JobProposalRequest);
	}

	@Test
	public void activeItemAfterMatchingProposal() {
		planner.addJob(job);
		planner.startPlanningIfIdle(world);
		planner.messages.poll();

		JobProposal proposal = proposalForItem(item1, 3, "a1");
		planner.addProposal(proposal, 1);

		assertEquals(new ItemWithQuantity(item2, 4), planner.activeItem);
		assertEquals(proposal, ((JobAssignment) planner.messages.getFirst().fact).proposal);
		assertTrue(planner.messages.getLast().fact instanceof JobProposalRequest);
	}

	@Test
	public void activeItemAfterOverProposal() {
		// if batch is too large, commitment is still just job requirement

		planner.addJob(job);
		planner.startPlanningIfIdle(world);
		planner.messages.poll();

		planner.addProposal(proposalForItem(item1, 9, "a1"), 1);

		assertEquals(new ItemWithQuantity(item2, 4), planner.activeItem);
		assertEquals(proposalForItem(item1, 3, "a1"),
				((JobAssignment) planner.messages.getFirst().fact).proposal);
		assertTrue(planner.messages.getLast().fact instanceof JobProposalRequest);
	}

	@Test
	public void handleProposalsChoosesQuickest() {
		planner.addJob(job);
		planner.startPlanningIfIdle(world);
		planner.messages.poll();

		ItemBatch slow = new ItemBatch(item1, 3, null, 1, 5);
		ItemBatch fast = new ItemBatch(item1, 3, null, 1, 1);
		planner.proposals.put("b1", proposalForBatch(slow, "b1"));
		planner.proposals.put("b2", proposalForBatch(slow, "b2"));
		planner.proposals.put("b3", proposalForBatch(fast, "b3"));
		planner.proposals.put("b4", proposalForBatch(slow, "b4"));
		planner.addProposal(proposalForBatch(slow, "b5"), 5);

		assertEquals(new ItemWithQuantity(item2, 4), planner.activeItem);
		assertEquals(proposalForItem(item1, 3, "b3"),
				((JobAssignment) planner.messages.getFirst().fact).proposal);
		assertTrue(planner.messages.getLast().fact instanceof JobProposalRequest);
	}

	@Test
	public void handleProposalsChoosesMost() {
		planner.addJob(job);
		planner.startPlanningIfIdle(world);
		planner.messages.poll();

		ItemBatch less = new ItemBatch(item1, 1, null, 1, 1);
		ItemBatch more = new ItemBatch(item1, 2, null, 1, 1);
		planner.proposals.put("b1", proposalForBatch(less, "b1"));
		planner.proposals.put("b2", proposalForBatch(less, "b2"));
		planner.proposals.put("b3", proposalForBatch(more, "b3"));
		planner.proposals.put("b4", proposalForBatch(less, "b4"));
		planner.addProposal(proposalForBatch(less, "b5"), 5);

		assertEquals(new ItemWithQuantity(item1, 1), planner.activeItem);
		assertEquals(proposalForItem(item1, 2, "b3"),
				((JobAssignment) planner.messages.getFirst().fact).proposal);
		assertTrue(planner.messages.getLast().fact instanceof JobProposalRequest);
	}

	// TODO different quantity and distance combos

	@Test
	public void addJobThenStartPlanningIfIdle() {
		planner.addJob(job);
		assertTrue(planner.messages.isEmpty());
		planner.startPlanningIfIdle(world);
		assertTrue(planner.messages.getFirst().fact instanceof JobProposalRequest);
	}

	@Test
	public void addJobAgain() {
		planner.addJob(job);
		planner.startPlanningIfIdle(world);
		planner.messages.poll();

		planner.addJob(job);
		assertTrue(planner.messages.isEmpty());
		assertTrue(planner.nextJobs.isEmpty());

		planner.startPlanningIfIdle(world);
		assertTrue(planner.messages.isEmpty());
		assertTrue(planner.nextJobs.isEmpty());
	}

	@Test
	public void addNewJob() {
		planner.addJob(job);
		planner.startPlanningIfIdle(world);
		planner.messages.poll();

		PricedJob newJob = new PricedJob("42", null, 5, 10, 1000);
		planner.addJob(newJob);

		assertTrue(planner.messages.isEmpty());
		assertEquals(newJob, planner.nextJobs.peek());
		assertEquals(1, planner.nextJobs.size());
	}

	@Test
	public void addOldJobAgain() {
		planner.addJob(job);
		planner.startPlanningIfIdle(world);
		finishJob();
		planner.messages.clear();

		planner.addJob(job);
		assertEquals(null, planner.activeJob);
		assertTrue(planner.nextJobs.isEmpty());
		assertTrue(planner.messages.isEmpty());
	}

	@Test
	public void finishJob() {
		planner.addJob(job);
		planner.startPlanningIfIdle(world);

		assertEquals(job, planner.activeJob);

		planner.addProposal(proposalForItem(item1, 3, "a1"), 1);
		planner.messages.clear();
		JobProposal p2 = proposalForItem(item2, 4, "a1");
		planner.addProposal(p2, 1);
		assertEquals(p2, ((JobAssignment) planner.messages.getFirst().fact).proposal);
		planner.messages.clear();
		JobProposal p3 = proposalForItem(item3, 5, "a1");
		planner.addProposal(p3, 1);

		assertEquals(p3, ((JobAssignment) planner.messages.getFirst().fact).proposal);
		assertEquals(new JobExecutionStart(job), planner.messages.get(1).fact);
		assertTrue(planner.plannedJobs.containsKey(job));
	}

	@Test
	public void lastJobDone() {
		finishJob();

		assertNull(planner.activeJob);
		assertNull(planner.activeItem);
		assertTrue(planner.nextJobs.isEmpty());
		assertTrue(planner.unassignedItems.isEmpty());
	}

	@Test
	public void dontPlanNextWhenJobDone() {
		Job newJob = new PricedJob("002", null, 5, 10, 1000);
		newJob.itemsRequired.put(item1, 7);
		newJob.itemsRequired.put(item2, 6);

		planner.addJob(job);
		planner.addJob(newJob);
		planner.startPlanningIfIdle(world);
		finishJob();

		assertEquals(null, planner.activeJob);
		assertEquals(null, planner.activeItem);
	}

}
