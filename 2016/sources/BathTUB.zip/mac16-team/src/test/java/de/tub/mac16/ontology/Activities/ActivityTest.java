package de.tub.mac16.ontology.Activities;

import de.tub.mac16.ontology.*;
import de.tub.mac16.ontology.Facilities.ChargingStation;
import de.tub.mac16.ontology.Facilities.Dump;
import de.tub.mac16.ontology.Facilities.Shop;
import de.tub.mac16.ontology.Intentions.GotoIntention;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.LinkedList;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class ActivityTest {

	private Activity activity;
	private World world;
	private AgentState self;
	private final int battCap = 999;

	@Before
	public void before() {
		world = new World("a1");

		world.update(new SimStart("0", "", 0, 999, "A", new Role("Drone", 1, battCap, 999), new LinkedList<>()));

		self = new AgentState("a1", "A", "Drone");
		self.currentLocation = new Location(0, 0);
		self.charge = battCap;

		Perception perc = new Perception("0", 0, 0, 0, self, new TeamState(0))
				.withAgents(self);
		world.update(perc);

		activity = new Activity(world, null);
	}

	@Test
	public void testNew() {
		assertTrue(activity.intentions.isEmpty());
		Assert.assertNull(activity.getCurrentIntention());
		assertTrue(activity.isComplete(world));
	}

	@Test
	public void testGoTo() {
		// add intention

		Location dumpLoc = new Location(cs(10), 0);
		Dump dump = new Dump("dump0", dumpLoc, 0);
		world.update(dump);
		Assert.assertEquals(activity, activity.goTo(dump));

		assertTrue(activity.intentions.getFirst() instanceof GotoIntention);
		GotoIntention firstIntention = (GotoIntention) activity.intentions.getFirst();
		Assert.assertEquals(dump, firstIntention.facility);
		Assert.assertEquals(dumpLoc, firstIntention.location);

		// execute first step

		activity.getCurrentIntention().onSent(world);

		self.lastAction = "goto";
		self.lastActionParam = "facility=dump0";
		self.lastActionResult = "success";
		self.charge = world.self.charge - 10;

		Location chgLoc = new Location(cs(20), 0);
		ChargingStation chg0 = new ChargingStation(0, "chg0", chgLoc, 0, 999, 99);
		Perception perc2 = new Perception("1", 0, 123, 234, self, new TeamState(0))
				.withAgents(self).withFacilities(chg0, dump);
		world.update(perc2);

		activity.onResult("success", world);

		// TODO check properly
		assertTrue(activity.getCurrentIntention() instanceof GotoIntention);

		// arrive
		activity.getCurrentIntention().onSent(world);
		self.lastAction = "goto";
		self.lastActionParam = "facility=dump0";
		self.lastActionResult = "success";
		self.charge = world.self.charge - 20;
		self.currentLocation = dumpLoc;

		Perception perc3 = new Perception("2", 1, 345, 456, self, new TeamState(0))
				.withAgents(self).withFacilities(chg0, dump);
		world.update(perc3);

		activity.onResult("success", world);

		// TODO check properly
		assertTrue(activity.isComplete(world));
	}

	private double cs(int n) {
		return world.cityMap.cellSize * n;
	}

	@Test
	public void testShop() {
		// doesnt move if already there
		// moves if not there
	}

	@Test
	public void testChargesOnce() {
	}

	@Test
	public void testChargesTwice() {
	}

	@Test
	public void testOnResult() {
	}

	@Test
	public void testOnResultSkipToFirstNonComplete() {
		Location loc = new Location(0, 0);
		Location loc2 = new Location(0, cs(2));
		Shop shop = new Shop(0, "shop", loc);
		ChargingStation chg = new ChargingStation(0, "chg0", loc2, 0, 999, 99);

		// after successfully executing goto(loc), agent is at shop, so it skips to goto(loc2)
		activity.goTo(loc).goTo(shop).goTo(loc2).goTo(chg);

		self.lastAction = "goto";
		self.lastActionParam = "lat=0.0 lon=0.0";
		self.lastActionResult = "success";
		Perception perc = new Perception("1", 0, 123, 234, self, new TeamState(0))
				.withAgents(self).withFacilities(chg, shop);

		activity.getCurrentIntention().onSent(world);
		world.update(perc);
		assertEquals("success", world.self.lastActionResult);
		activity.onResult("success", world);

		assertEquals(2, activity.intentions.size());
		assertEquals(new GotoIntention(loc, loc2, 2), activity.getCurrentIntention());
	}
}
