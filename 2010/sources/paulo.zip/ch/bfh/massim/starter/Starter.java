package ch.bfh.massim.starter;

import java.util.ArrayList;

import org.apache.log4j.PropertyConfigurator;

import ch.bfh.massim.framework.ComServerAgent;
import ch.bfh.massim.framework.mapagent.MapAgent;
import ch.bfh.massim.framework.planingunit.PlaningUnitAgent;
import ch.bfh.massim.framework.rolebasedagent.RolebaseAgent;

/**
 * Dummy helper class to run the agents.
 * Ugly but working, so our test suite MASSim-Manager is not needed. 
 * @author fuchs
 *
 */
public class Starter
{


    public static void main(String[] args)
    {
        int _number = 20;
        String _password = "";
        String _team = "PauLo";

        int _gamePort = 12300;
        String _host = "rvince.in.tu-clausthal.de";

        int _commPort = 10485;
        String _commHost = "localhost";

        ArrayList<RolebaseAgent> agents = new ArrayList<RolebaseAgent>();

        System.out.println("Starting Agents");

        // use the loader helper from log4j
        PropertyConfigurator.configure("conf/log4j.properties");

        ComServerAgent _csagent1 = new ComServerAgent("first Server", _commPort);

        try
        {
            Thread.sleep(500);
        }
        catch (InterruptedException e)
        {
        }

        MapAgent _magent1 = new MapAgent("MapAgent", _commHost, _commPort);
        PlaningUnitAgent _puagent1 = new PlaningUnitAgent("PlaningUnit", _commHost, _commPort, _magent1.get_map());

        try
        {
            Thread.sleep(2000);
        }
        catch (InterruptedException e)
        {
        }

        _csagent1.start();

        try
        {
            Thread.sleep(500);
        }
        catch (InterruptedException e)
        {
        }

        _magent1.start();
        _puagent1.start();

        try
        {
            Thread.sleep(2000);
        }
        catch (InterruptedException e)
        {
        }

        for (int i = 1; i <= _number; i++)
        {
            RolebaseAgent agent = new RolebaseAgent(_team + i, _commHost, _commPort, _host, _gamePort, _team + i,
                    _password);
            
            agents.add(agent);
        }
        
        for(RolebaseAgent agent : agents)
        {
            agent.start();
        }

    }

}
