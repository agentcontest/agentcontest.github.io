package ch.bfh.massim.framework;

/**
 * This agent can only start him self as a thread, and also stop him self.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public abstract class AbstractBaseAgent implements IAgent
{

    
    // name of the agent
    protected String _name;

    // is set, when the Agent has been interrupted
    private boolean _isInterrupted = false;

    // this objects only acts as a guard for the interrupt variable.
    private Object _guard = new Object();

    /**
     * @return true, if interrupted
     */
    public boolean isInterrupted()
    {
        synchronized (_guard)
        {
            return _isInterrupted;
        }
    }

    /**
     * set the Agent to interrupted state
     */
    public void interrupt()
    {
        synchronized (_guard)
        {
            _isInterrupted = true;
        }
    }

    /**
     * Creates the agent
     * 
     * @param name
     *            Name of the agent. It should be unique.
     */
    public AbstractBaseAgent(String name)
    {
        _name = name;
    }

    /**
     * Method to start the Agent
     */
    @Override
    public void start()
    {

        new Thread()
        {
            public void run()
            {
                preThread();
                agentThread();
                postThread();
            }
        }.start();
    }

    /**
     * Method to stop the Agent
     */
    @Override
    public void stop()
    {
        interrupt();
    }

    /**
     * This method is called, after the Agent has started
     */
    abstract protected void preThread();

    /**
     * This method should contain the main application of the Agent
     */
    abstract protected void agentThread();

    /**
     * This method is called, when the Agent will be stopped
     */
    abstract protected void postThread();
}
