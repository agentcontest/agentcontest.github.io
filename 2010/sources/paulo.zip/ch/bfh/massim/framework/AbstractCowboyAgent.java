package ch.bfh.massim.framework;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import ch.bfh.massim.framework.masmessages.MasMessage;
import ch.bfh.massim.framework.masmessages.MasMessageAction;
import ch.bfh.massim.framework.masmessages.MasMessageFactory;
import ch.bfh.massim.framework.masmessages.MasMessageRequestAction;

/**
 * This agent is able to interact with the MASSim-Server. It represents a cowboy
 * in the MASSim-Game.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public abstract class AbstractCowboyAgent extends ComClientAgent
{

    private int _MASSIMNetworkport;
    private String _MASSIMNetworkhost;
    private String _MASSIMName;
    private String _MASSIMPwd;

    protected MASSIMConnection _massimConn;

    /**
     * Creates a Cowboy Agent
     * 
     * @param name
     *            name of the agent
     * @param ComNetworkhost
     *            address of the ComServer
     * @param ComNetworkport
     *            port of the ComServer
     * @param MASSIMNetworkhost
     *            host of the MASSim-Server
     * @param MASSIMNetworkport
     *            port of the MASSim-Server
     * @param MASSIMName
     *            name of the agent to tell the MASSim-Server
     * @param MASSIMPwd
     *            password of the MASSim-Server
     */
    public AbstractCowboyAgent(String name, String ComNetworkhost, int ComNetworkport, String MASSIMNetworkhost,
            int MASSIMNetworkport, String MASSIMName, String MASSIMPwd)
    {
        super(name, ComNetworkhost, ComNetworkport, "1234", "CowboyAgent");
        this._MASSIMName = MASSIMName;
        this._MASSIMNetworkport = MASSIMNetworkport;
        this._MASSIMNetworkhost = MASSIMNetworkhost;
        this._MASSIMPwd = MASSIMPwd;

    }

    /**
     * @see ch.bfh.massim.framework.ComClientAgent#agentRun()
     */
    @Override
    public void agentRun() throws IOException, InterruptedException
    {

        try
        {
            if (_massimConn == null)
                return;
            if (_massimConn.hasPacket())
            {
                MasMessage message = _massimConn.receiveMessage();
                if (message != null)
                {
                    processMessage(message);
                }
            }
            Thread.sleep(100);
        }
        catch (SAXException e)
        {
            e.printStackTrace();
        }
        catch (ParserConfigurationException e)
        {
            e.printStackTrace();
        }

    }

    /**
     * @see ch.bfh.massim.framework.ComClientAgent#preThread()
     */
    @Override
    protected void preThread()
    {
        super.preThread();
        try
        {
            _massimConn = new MASSIMConnection(_MASSIMNetworkport, _MASSIMNetworkhost, _MASSIMName, _MASSIMPwd);

            if (!_massimConn.doAuthentication())
            {
                System.err.println("Authetification with Massimserver faild");
            }
            System.out.println("Authetification with Massimserver ok");

        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        catch (ConnectionNotEstablishedException e1)
        {
            e1.printStackTrace();
        }
    }

    /**
     * @see ch.bfh.massim.framework.ComClientAgent#postThread()
     */
    @Override
    protected void postThread()
    {
        super.postThread();
    }

    /**
     * Processes the incoming MasMessages. Splits them according their type.
     * 
     * @param message
     *            the message to handle
     * @return true if the message has been processed 
     */
    public boolean processMessage(MasMessage message)
    {
        if (message.get_type().equals("request-action"))
        {
            MasMessageRequestAction request = (MasMessageRequestAction) message;
            MasMessageAction action = MasMessageFactory.createActionMessage();
            action.setActionID(request.getPerceptionID());
            processRequestAction(request, action);
            try
            {
                _massimConn.sendMessage(action);
            }
            catch (IOException e)
            {
                e.printStackTrace();
                return false;
            }

            return true;
        }
        else if (message.get_type().equals("sim-start"))
        {
            processSimulationStart(message);
            return true;
        }
        else if (message.get_type().equals("sim-end"))
        {
            processSimulationEnd(message);
            return true;
        }
        else
        {
            processUnknownMessage(message);
            return true;
        }
    }

    /**
     * To implement for react on the "sim-end" message
     * 
     * @param message
     *            the message with the end simulation note to handle 
     */
    abstract protected void processSimulationEnd(MasMessage message);

    /**
     * To implement for react on the "sim-start" message
     * 
     * @param message
     *            the message with the sim start note to handle
     */
    abstract protected void processSimulationStart(MasMessage message);

    /**
     * To implement for react on the "request-action" message
     * 
     * @param message
     *            the request-action message to handle
     */
    abstract protected void processRequestAction(MasMessageRequestAction request, MasMessageAction action);

    /**
     * To implement for react on any other message.
     * 
     * @param message
     *            the message with an unkown type to handle
     */
    abstract protected void processUnknownMessage(MasMessage message);

}
