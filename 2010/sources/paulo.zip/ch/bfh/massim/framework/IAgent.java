/**
 * 
 */
package ch.bfh.massim.framework;

/**
 * All Agents have to Implement this Interface to easily start and stop the
 * agents.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public interface IAgent
{
    /**
     * Starts the Agent.
     */
    public void start();

    /**
     * Interrupts the Agent.
     */
    public void stop();
}
