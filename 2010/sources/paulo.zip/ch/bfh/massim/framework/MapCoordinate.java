package ch.bfh.massim.framework;

/**
 * Class to represent a map coordinate. This class is used so that other
 * classes, can access a given field by it's coordinate relative to the map.
 * This class provides methods to get and set informations regarding the
 * coordinate and it's relation to other coordinates (e.g euclidian distance).
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class MapCoordinate implements Cloneable
{
    private int _x;
    private int _y;

    /**
     * Default Constructor 
     * 
     * @param x
     *            x coordinate
     * @param y
     *            y coordinate
     */
    public MapCoordinate(int x, int y)
    {
        ;
        this._x = x;
        this._y = y;
    }

    /**
     * Copy constructor
     * 
     * @param coord
     *            coordinate to copy
     */
    public MapCoordinate(MapCoordinate coord)
    {
        this._x = coord._x;
        this._y = coord._y;
    }

    /**
     * @return the x coordinate
     */
    public int getX()
    {
        return _x;
    }

    /**
     * @param x
     *            the x coordinate to set
     */
    public void setX(int x)
    {
        this._x = x;
    }

    /**
     * @return the y coordinate
     */
    public int getY()
    {
        return _y;
    }

    /**
     * @param y
     *            the y coordinate to set
     */
    public void setY(int y)
    {
        this._y = y;
    }

    /**
     * Method to calculates the distance between two coordinates.
     * 
     * @param coord
     *            the second coordinate
     * @return the distance between the two coordinates
     */
    public int distance(MapCoordinate coord)
    {
        return Math.max(Math.abs(this._x - coord._x), Math.abs(this._y - coord._y));
    }

    /**
     * Method to calculate the euclidian distance
     * 
     * @param coord
     *            goal coordinates
     * @return euclidian distance between this and goal
     */
    public double euclidianDistance(MapCoordinate coord)
    {
        // a^2 + b^2 = c^2
        return Math.sqrt(Math.pow((this._x - coord._x), 2) + Math.pow((this._y - coord._y), 2));
    }

    /**
     * Method to subtract a coordinate
     * 
     * @param coord
     *            the coordinate to subtract
     * @return returns a new coordinate, as the result of the subtraction
     */
    public MapCoordinate subtract(MapCoordinate coord)
    {
        return new MapCoordinate(this._x - coord._x, this._y - coord._y);
    }

    /**
     * Method to add a coordinate
     * 
     * @param coord
     *            the coordinate to add
     * @return returns a new coordinate, as the result of the addition
     */
    public MapCoordinate add(MapCoordinate coord)
    {
        return new MapCoordinate(this._x + coord._x, this._y + coord._y);
    }

    /**
     * Method to check if the coordinate is on the map
     * 
     * @param map
     *            the map as an array of objects
     * @return true if the coordinate is on the map
     */
    public boolean isOnMap(Object[][] map)
    {
        if (map == null)
            return false;
        else
            return (_x >= 0 && _x < map.length && _y >= 0 && _y < map[0].length);
    }

    /**
     * 
     * @param coord
     *            coordinate to calculate the angle
     * @return the angle between this and the given coordinate
     */
    public double getAngle(MapCoordinate coord)
    {
        return Math.acos((this._x * coord._x + this._y * coord._y) / (this.length() * coord.length()));
    }

    /**
     * 
     * @return the length of this coordinate
     */
    private double length()
    {
        return Math.sqrt(this._x * this._x + this._y * this._y);
    }

    /**
     * @return the string representation of this coordinate
     */
    @Override
    public String toString()
    {
        return "(" + String.valueOf(_x) + "," + String.valueOf(_y) + ")";
    }

    /**
     * @return a clone of this coordinate
     */
    @Override
    public MapCoordinate clone() throws CloneNotSupportedException
    {
        try
        {
            return (MapCoordinate) super.clone();
        }
        catch (CloneNotSupportedException e)
        {
            return new MapCoordinate(this); // Not going to happen
        }
    }

    /**
     * @return whether two objects are equal
     */
    @Override
    public boolean equals(Object o)
    {
        if (o instanceof MapCoordinate)
        {
            MapCoordinate other = (MapCoordinate) o;
            return (other.getX() == _x && other.getY() == _y);
        }
        else
            return false;
    }

    /**
     * Method to get the center of multiple map coordinates.
     * 
     * @param coords
     *            coordinates
     * @return the center between the coordinates as a coordinate
     */
    public static MapCoordinate calculateCenter(MapCoordinate[] coords)
    {
        int sumx = 0;
        int sumy = 0;
        int count = coords.length;

        if (count == 0)
            return new MapCoordinate(0, 0);

        for (MapCoordinate coord : coords)
        {
            if (coord != null)
            {
                sumx += coord.getX();
                sumy += coord.getY();
            }
        }

        return new MapCoordinate(sumx / count, sumy / count);
    }

    /**
     * Helper method to move a list of coordinates in a given direction.
     * 
     * @param coordinates
     *            coordinates to move
     * @param direction
     *            direction to move to
     * @return coordinates moved by 1 step in the given direction
     */
    public static MapCoordinate[] pushDirection(MapCoordinate[] coordinates, Direction direction)
    {
        MapCoordinate[] pushed = new MapCoordinate[coordinates.length];

        for (int i = 0; i < coordinates.length; i++)
        {
            MapCoordinate current = coordinates[i];
            int curx = current.getX();
            int cury = current.getY();
            MapCoordinate pushedcoord = new MapCoordinate(0, 0);
            if (current != null)
            {
                switch (direction)
                {
                    case NORTH:
                    {
                        pushedcoord = new MapCoordinate(curx, cury - 1);
                        break;
                    }
                    case NORTHEAST:
                    {
                        pushedcoord = new MapCoordinate(curx + 1, cury - 1);
                        break;
                    }
                    case EAST:
                    {
                        pushedcoord = new MapCoordinate(curx + 1, cury);
                        break;
                    }
                    case SOUTHEAST:
                    {
                        pushedcoord = new MapCoordinate(curx + 1, cury + 1);
                        break;
                    }
                    case SOUTH:
                    {
                        pushedcoord = new MapCoordinate(curx, cury + 1);
                        break;
                    }
                    case SOUTHWEST:
                    {
                        pushedcoord = new MapCoordinate(curx - 1, cury + 1);
                        break;
                    }
                    case WEST:
                    {
                        pushedcoord = new MapCoordinate(curx - 1, cury);
                        break;
                    }
                    case NORTHWEST:
                    {
                        pushedcoord = new MapCoordinate(curx - 1, cury - 1);
                        break;
                    }
                    case NONE:
                    {
                        pushedcoord = new MapCoordinate(curx, cury);
                        break;
                    }
                }
            }
            pushed[i] = pushedcoord;
        }

        return pushed;
    }
}
