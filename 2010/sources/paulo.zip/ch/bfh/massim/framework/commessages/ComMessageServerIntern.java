/**
 * 
 */
package ch.bfh.massim.framework.commessages;

/**
 * This message is used intern in the ComServer.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class ComMessageServerIntern extends ComMessage
{

    private int _senderId;

    /**
     * creates the message
     * 
     * @param message
     *            message as bytecode
     * @param senderId
     *            server-intern-id of the sender
     */
    public ComMessageServerIntern(byte[] message, int senderId)
    {
        super(message);
        // _message = message;
        _senderId = senderId;
    }

    /**
     * get the sender id.
     * 
     * @return server-intern-sender-id
     */
    public int get_senderId()
    {
        return _senderId;
    }

}
