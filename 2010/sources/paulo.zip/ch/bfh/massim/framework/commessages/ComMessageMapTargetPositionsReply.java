package ch.bfh.massim.framework.commessages;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import ch.bfh.massim.framework.MapCoordinate;

/**
 * This message is used from the MapAgent to answer the
 * ComMessageTargetPositionReply. The message contains for each agent a
 * possition, which he uses as a waypoint.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class ComMessageMapTargetPositionsReply extends ComMessage
{

    /**
     * Creates a new Message
     * 
     * @param sendername
     *            name of the sender
     */
    public ComMessageMapTargetPositionsReply(String sendername)
    {
        super(sendername, "MapTargetPositionsReply");
    }

    /**
     * Transform Constructor
     * 
     * @param message
     *            the message
     */
    public ComMessageMapTargetPositionsReply(ComMessage message)
    {
        super(message.get_message());
    }

    /**
     * Adds a list of fields, which should be ignored by pathfinding.
     * 
     * @param ignoredList
     *            the ignore list
     */
    public void addIgnoreList(List<MapCoordinate> ignoredList)
    {
        Element el_list = this.get_bodyElement().getOwnerDocument().createElement("ignore");
        for (MapCoordinate coordinate : ignoredList)
        {
            Element el_coord = el_list.getOwnerDocument().createElement("coord");
            el_coord.setAttribute("x", String.valueOf(coordinate.getX()));
            el_coord.setAttribute("y", String.valueOf(coordinate.getY()));
            el_list.appendChild(el_coord);
        }
        this.get_bodyElement().appendChild(el_list);
    }

    /**
     * Gets a list of fields, which should be ignored by pathfinding.
     * 
     * @return the ignore list
     */
    public List<MapCoordinate> getIgnoreList()
    {
        List<MapCoordinate> list = new ArrayList<MapCoordinate>();
        NodeList nl = get_bodyElement().getChildNodes();
        for (int i = 0; i < nl.getLength(); i++)
        {
            Node n = nl.item(i);
            if (n.getNodeType() == Element.ELEMENT_NODE && n.getNodeName().equalsIgnoreCase("ignore"))
            {
                NodeList nl2 = n.getChildNodes();
                for (int j = 0; j < nl2.getLength(); j++)
                {
                    Node n2 = nl2.item(j);
                    if (n2.getNodeType() == Element.ELEMENT_NODE && n2.getNodeName().equalsIgnoreCase("coord"))
                    {

                        Element el = (Element) n2;
                        list.add(new MapCoordinate(Integer.parseInt(el.getAttribute("x")), Integer.parseInt(el
                                .getAttribute("y"))));
                    }
                }
                break;
            }
        }
        return list;
    }

    /**
     * Adds a map, with the targetcoordinate for each agent.
     * 
     * @param agentPos
     *            Map with the targetcoordinates of each agent.
     */
    public void addAgentsPos(Map<String, MapCoordinate> agentPos)
    {
        Element el_list = this.get_bodyElement().getOwnerDocument().createElement("agents");
        for (Entry<String, MapCoordinate> entry : agentPos.entrySet())
        {
            Element el_coord = el_list.getOwnerDocument().createElement("agent");
            el_coord.setAttribute("name", entry.getKey());
            el_coord.setAttribute("x", String.valueOf(entry.getValue().getX()));
            el_coord.setAttribute("y", String.valueOf(entry.getValue().getY()));
            el_list.appendChild(el_coord);
        }
        this.get_bodyElement().appendChild(el_list);
    }

    /**
     * gets the map, with the targetcoordinates for each agent
     * 
     * @return the map, with the targetcoordinates.
     */
    public Map<String, MapCoordinate> getAgentsPos()
    {
        Map<String, MapCoordinate> map = new HashMap<String, MapCoordinate>();
        NodeList nl = get_bodyElement().getChildNodes();
        for (int i = 0; i < nl.getLength(); i++)
        {
            Node n = nl.item(i);
            if (n.getNodeType() == Element.ELEMENT_NODE && n.getNodeName().equalsIgnoreCase("agents"))
            {
                NodeList nl2 = n.getChildNodes();
                for (int j = 0; j < nl2.getLength(); j++)
                {
                    Node n2 = nl2.item(j);
                    if (n2.getNodeType() == Element.ELEMENT_NODE && n2.getNodeName().equalsIgnoreCase("agent"))
                    {

                        Element el = (Element) n2;
                        map.put(el.getAttribute("name"), new MapCoordinate(Integer.parseInt(el.getAttribute("x")),
                                Integer.parseInt(el.getAttribute("y"))));
                    }
                }
                break;
            }
        }
        return map;
    }

}
