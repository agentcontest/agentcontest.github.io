/**
 * 
 */
package ch.bfh.massim.framework.commessages;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Main class for all the internal messages. This class provides all the
 * functionality used for sending messages from one agent to an other.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class ComMessage
{

    private byte[] _message;

    // private int _senderId;
    private Document _xmlDoc;
    private Element _bodyElement;
    private Element _receiverElement;

    private boolean _hasChangedDoc = false;
    private boolean _hasChangedByte = false;

    private static DocumentBuilderFactory _documentbuilderfactory;
    private static TransformerFactory _transformerfactory;

    /**
     * creates the static fields if they are not present
     */
    private ComMessage()
    {
        if (_documentbuilderfactory == null)
        {
            _documentbuilderfactory = DocumentBuilderFactory.newInstance();
        }
        if (_transformerfactory == null)
        {
            _transformerfactory = TransformerFactory.newInstance();
        }

    }

    /**
     * Creates a new message-skeleton, and ads the sender and the messagetype
     * 
     * @param sendername
     *            name of the sender
     * @param messagetype
     *            type of the message as a string
     */
    public ComMessage(String sendername, String messagetype)
    {
        this();

        _hasChangedDoc = true;
        // create an instance of the documentbuilderfactory, if it is the first
        // Message

        try
        {
            // Create new Document
            _xmlDoc = _documentbuilderfactory.newDocumentBuilder().newDocument();
            // Add root node "message"
            Element root = _xmlDoc.createElement("message");
            _xmlDoc.appendChild(root);

            // Append receiver Element
            Element receiver = _xmlDoc.createElement("receiver");
            root.appendChild(receiver);

            // Append sender Element
            Element sender = _xmlDoc.createElement("sender");
            Element agent = _xmlDoc.createElement("agent");
            agent.setAttribute("name", sendername);
            sender.appendChild(agent);
            root.appendChild(sender);

            Element body = _xmlDoc.createElement("body");
            body.setAttribute("type", messagetype);
            root.appendChild(body);

            root.setAttribute("timestamp", Long.toString((System.currentTimeMillis())));

        }
        catch (ParserConfigurationException e)
        {
            System.err.println("unable to create new document");
            e.printStackTrace();
        }

    }

    /**
     * Creates a new message, based on the byte-array. The xml-dom is only
     * created if needed.
     * 
     * @param message
     *            the message as a byte array
     */
    public ComMessage(byte[] message)
    {
        this();
        _hasChangedByte = true;
        _message = message;
    }

    /**
     * adds a new Receiver in to the Message Header
     * 
     * @param name
     *            Name of the Receiver
     */
    public void addReceiverAgent(String name)
    {
        Element receiver = get_receiverElement();
        if (receiver != null)
        {
            Element newNode = receiver.getOwnerDocument().createElement("agent");
            newNode.setAttribute("name", name);
            receiver.appendChild(newNode);
        }
        else
        {
            // TODO error if receiver is null
        }
    }

    /**
     * adds the "all"-tag to the receivers, so the message will be stend to all
     * connected agents.
     */
    public void addReceiverAll()
    {
        Element receiver = get_receiverElement();
        if (receiver != null)
        {
            receiver.appendChild(receiver.getOwnerDocument().createElement("all"));
        }
        else
        {
            // TODO error if receiver is null
        }
    }

    /**
     * adds a receiver group (not jet suported by the comserver)
     * 
     * @param name
     *            name of the group
     */
    public void addReceiverGroup(String name)
    {
        Element receiver = get_receiverElement();
        if (receiver != null)
        {
            Element newNode = receiver.getOwnerDocument().createElement("group");
            newNode.setAttribute("name", name);
            receiver.appendChild(newNode);
        }
        else
        {
            // TODO error if receiver is null
        }
    }

    /**
     * adds the server to the receiver list. So the server will keep the message
     * for him self.
     */
    public void addReceiverServer()
    {
        Element receiver = get_receiverElement();
        if (receiver != null)
        {
            receiver.appendChild(receiver.getOwnerDocument().createElement("server"));
        }
        else
        {
            // TODO error if receiver is null
        }
    }

    /**
     * returns the message as a xml-document
     * 
     * @return xml-document
     */
    public Document get_xmlDoc()
    {
        _hasChangedDoc = true;
        if (_hasChangedByte)
        {
            _bodyElement = null;
            _receiverElement = null;
            try
            {
                _xmlDoc = _documentbuilderfactory.newDocumentBuilder().parse(new ByteArrayInputStream(_message));
            }
            catch (Exception e)
            {
                System.out.println("message not parseble");
            }
            _hasChangedByte = false;
        }
        return _xmlDoc;
    }

    /**
     * returns the body element of the message. This element contains the
     * content of the message.
     * 
     * @return the body-element
     */
    public Element get_bodyElement()
    {
        if (_bodyElement == null)
        {
            Document doc = get_xmlDoc();
            if (doc != null)
            {
                // System.out.println("doc not null");
                Element root = doc.getDocumentElement();
                if (root != null)
                {
                    // System.out.println("root not null");
                    // NodeList childes = doc.getChildNodes();
                    NodeList nl = root.getChildNodes();
                    // System.out.println(nl.getLength() + " childnodes");
                    for (int i = 0; i < nl.getLength(); i++)
                    {
                        Node n = nl.item(i);
                        // System.out.println(n.getNodeName());
                        if (n.getNodeType() == Element.ELEMENT_NODE && n.getNodeName().equalsIgnoreCase("body"))
                        {
                            _bodyElement = (Element) n;
                            break;
                        }
                    }
                }
            }
        }
        return _bodyElement;
    }

    /**
     * returns the messagetype
     * 
     * @return messagetype as a string
     */
    public String get_messageType()
    {
        Element bodyElement = get_bodyElement();
        return bodyElement.getAttribute("type");
    }

    /**
     * returns the element containing all the receivers.
     * 
     * @return receiver-element
     */
    protected Element get_receiverElement()
    {
        if (_receiverElement == null)
        {
            Document doc = get_xmlDoc();
            if (doc != null)
            {
                Element root = doc.getDocumentElement();
                if (root != null)
                {
                    // NodeList childes = doc.getChildNodes();
                    NodeList nl = root.getChildNodes();
                    for (int i = 0; i < nl.getLength(); i++)
                    {
                        Node n = nl.item(i);
                        if (n.getNodeType() == Element.ELEMENT_NODE && n.getNodeName().equalsIgnoreCase("receiver"))
                        {
                            _receiverElement = (Element) n;
                            break;
                        }
                    }
                }
            }
        }
        return _receiverElement;
    }

    public String getSenderName()
    {
        Document doc = get_xmlDoc();
        if (doc != null)
        {
            Element root = doc.getDocumentElement();
            if (root != null)
            {
                // NodeList childes = doc.getChildNodes();
                NodeList nl = root.getChildNodes();
                for (int i = 0; i < nl.getLength(); i++)
                {
                    Node n = nl.item(i);
                    if (n.getNodeType() == Element.ELEMENT_NODE && n.getNodeName().equalsIgnoreCase("sender"))
                    {
                        Element sender = (Element) n;

                        NodeList nl2 = sender.getChildNodes();
                        for (int j = 0; j < nl2.getLength(); j++)
                        {
                            n = nl2.item(j);
                            if (n.getNodeType() == Element.ELEMENT_NODE && n.getNodeName().equalsIgnoreCase("agent"))
                            {
                                sender = (Element) n;
                                return sender.getAttribute("name");
                            }
                        }
                        break;
                    }
                }
            }
        }
        return "";
    }

    /**
     * returns the byte-code of the message
     * 
     * @return message as byte-code
     */
    public byte[] get_message()
    {
        if (_hasChangedDoc)
        {
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            try
            {
                _transformerfactory.newTransformer().transform(new DOMSource(get_xmlDoc()), new StreamResult(buffer));
            }
            catch (TransformerConfigurationException e)
            {
                e.printStackTrace();
            }
            catch (TransformerException e)
            {
                e.printStackTrace();
            }
            _message = buffer.toByteArray();
        }
        return _message;
    }

    /**
     * writes the message to an outputstream.
     * 
     * @param outputstream
     *            the outputstream
     * @throws IOException
     */
    public void sendMessage(OutputStream outputstream) throws IOException
    {
        outputstream.write(get_message());

        outputstream.write(0);
        outputstream.flush();
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        ByteArrayOutputStream temp = new ByteArrayOutputStream();
        try
        {
            _transformerfactory.newTransformer().transform(new DOMSource(get_xmlDoc()), new StreamResult(temp));
        }
        catch (TransformerConfigurationException e)
        {
            e.printStackTrace();
        }
        catch (TransformerException e)
        {
            e.printStackTrace();
        }
        return temp.toString();
    }
}
