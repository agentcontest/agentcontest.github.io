/**
 * 
 */
package ch.bfh.massim.framework.commessages;

import org.w3c.dom.Element;
import org.w3c.dom.Text;

/**
 * Represents a message just containig text.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class ComMessageText extends ComMessage
{

    /**
     * Creates the new message with the text
     * 
     * @param sender
     *            the sendername
     * @param text
     *            the content text
     * @param type
     *            type of the message
     */
    public ComMessageText(String sender, String text, ComMessageType type)
    {
        this(sender, text, type, null);
    }

    /**
     * creates the new message, and automaticle adds a receiver
     * 
     * @param sender
     *            the sendername
     * @param text
     *            the content text
     * @param type
     *            type of the message
     * @param receiver
     *            receivername
     */
    public ComMessageText(String sender, String text, ComMessageType type, String receiver)
    {
        super(sender, "text");
        if (type == ComMessageType.AGENT && receiver != null)
        {
            addReceiverAgent(receiver);
        }
        else if (type == ComMessageType.ALL)
        {
            addReceiverAll();
        }
        else if (type == ComMessageType.GROUP && receiver != null)
        {
            addReceiverGroup(receiver);
        }

        Element messagebody = this.get_bodyElement();

        Text textNode = messagebody.getOwnerDocument().createTextNode(text);
        messagebody.appendChild(textNode);
    }

}
