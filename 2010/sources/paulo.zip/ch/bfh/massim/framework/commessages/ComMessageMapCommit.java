package ch.bfh.massim.framework.commessages;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import ch.bfh.massim.framework.masmessages.MasMessageRequestAction;

/**
 * This message is used to send the local sight of an agent to the mapagent
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class ComMessageMapCommit extends ComMessage
{

    private Element _el_perception;

    /**
     * creates the message from a "request-action" of the MASSim-Server
     * 
     * @param sender
     * @param requestAction
     */
    public ComMessageMapCommit(String sender, MasMessageRequestAction requestAction)
    {
        super(sender, "Map-Commit");
        Node newPerception = get_xmlDoc().importNode(requestAction.getPerceptionNode(), true);
        _el_perception = (Element) get_bodyElement().appendChild(newPerception);
    }

    /**
     * creates the message from a ComMessage.
     * 
     * @param message
     *            the message
     */
    public ComMessageMapCommit(ComMessage message)
    {
        super(message.get_message());

        NodeList nl = get_bodyElement().getChildNodes();
        for (int i = 0; i < nl.getLength(); i++)
        {
            Node n = nl.item(i);
            if (n.getNodeType() == Element.ELEMENT_NODE && n.getNodeName().equalsIgnoreCase("perception"))
            {
                _el_perception = (Element) n;
                break;
            }
        }
    }

    /**
     * returns the x position
     * 
     * @return x position
     */
    public int get_posx()
    {
        String num = _el_perception.getAttribute("posx");
        return Integer.parseInt(num);
    }

    /**
     * returns the y position
     * 
     * @return y position
     */
    public int get_posy()
    {
        String num = _el_perception.getAttribute("posy");
        return Integer.parseInt(num);
    }

    /**
     * returns the number of the step
     * 
     * @return step number of steps
     */
    public int get_step()
    {
        String num = _el_perception.getAttribute("step");
        return Integer.parseInt(num);
    }

    /**
     * returns the list with all the cells in it.
     * 
     * @return list of all the cells
     */
    public NodeList get_cellList()
    {
        return _el_perception.getChildNodes();
    }
}
