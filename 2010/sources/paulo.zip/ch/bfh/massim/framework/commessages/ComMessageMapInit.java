package ch.bfh.massim.framework.commessages;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import ch.bfh.massim.framework.masmessages.MasMessageSimStart;

/**
 * this message is used to initiate a new simulation on the mapagent.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class ComMessageMapInit extends ComMessage
{

    private Element _el_simulation;

    /**
     * crates the message, on base of the "sim-start" message from the
     * MASSim-server.
     * 
     * @param sender
     *            the sendername
     * @param simStart
     *            the "sim-start" message
     */
    public ComMessageMapInit(String sender, MasMessageSimStart simStart)
    {
        super(sender, "Map-Init");
        Node newSim = get_xmlDoc().importNode(simStart.getSimulationNode(), true);
        _el_simulation = (Element) get_bodyElement().appendChild(newSim);
    }

    /**
     * converts a ComMessage to a MapInitComMessage
     * 
     * @param message
     *            the message, which will be converted to to a MapInit-Message
     */
    public ComMessageMapInit(ComMessage message)
    {
        super(message.get_message());

        NodeList nl = get_bodyElement().getChildNodes();
        for (int i = 0; i < nl.getLength(); i++)
        {
            Node n = nl.item(i);
            if (n.getNodeType() == Element.ELEMENT_NODE && n.getNodeName().equalsIgnoreCase("simulation"))
            {
                _el_simulation = (Element) n;
                break;
            }
        }
    }

    /**
     * returns the current simulation id
     * 
     * @return the simulationid
     */
    public String get_simID()
    {
        String sid = _el_simulation.getAttribute("id");
        // System.err.println("sid");
        return sid;
    }

    /**
     * returns the current own Team
     * 
     * @return the own Team
     */
    public String get_ownID()
    {
        String sid = _el_simulation.getAttribute("opponent");
        String own = (sid.equals("B")) ? "A" : "B";

        return own;
    }

    /**
     * returns the current opponent Team
     * 
     * @return the opponent Team
     */
    public String get_opID()
    {
        String sid = _el_simulation.getAttribute("opponent");
        return sid;
    }

    /**
     * returns the size of the map (x)
     * 
     * @return x-size of the map
     */
    public int get_gsizex()
    {
        String sid = _el_simulation.getAttribute("gsizex");
        return Integer.parseInt(sid);
    }

    /**
     * returns the size of the map (y)
     * 
     * @return y-size of the map
     */
    public int get_gsizey()
    {
        String sid = _el_simulation.getAttribute("gsizey");
        return Integer.parseInt(sid);
    }

    /**
     * returns the coordinates of the corral
     * 
     * @return coral coordinations x0
     */
    public int get_corralx0()
    {
        String sid = _el_simulation.getAttribute("corralx0");
        return Integer.parseInt(sid);
    }

    /**
     * returns the coordinates of the corral
     * 
     * @return coral coordinations x1
     */
    public int get_corralx1()
    {
        String sid = _el_simulation.getAttribute("corralx1");
        return Integer.parseInt(sid);
    }

    /**
     * returns the coordinates of the corral
     * 
     * @return coral coordinations y0
     */
    public int get_corraly0()
    {
        String sid = _el_simulation.getAttribute("corraly0");
        return Integer.parseInt(sid);
    }

    /**
     * returns the coordinates of the corral
     * 
     * @return coral coordinations y1
     */
    public int get_corraly1()
    {
        String sid = _el_simulation.getAttribute("corraly1");
        return Integer.parseInt(sid);
    }

}
