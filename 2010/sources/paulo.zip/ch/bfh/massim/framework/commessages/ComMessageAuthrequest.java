/**
 * 
 */
package ch.bfh.massim.framework.commessages;

import org.w3c.dom.Element;

/**
 * This message is used to authenticate an agent by the ComServer.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class ComMessageAuthrequest extends ComMessage
{

    /**
     * 
     * @param username
     *            name of the agent
     * @param pwd
     *            password of the agent (not jet used)
     * @param group
     *            group of the agent (not jet used)
     */
    public ComMessageAuthrequest(String username, String pwd, String group)
    {
        super(username, "auth-request");
        addReceiverServer();
        Element messagebody = this.get_bodyElement();
        Element auth = messagebody.getOwnerDocument().createElement("authentication");
        auth.setAttribute("username", username);
        auth.setAttribute("password", pwd);
        auth.setAttribute("group", group);
        messagebody.appendChild(auth);
    }
}
