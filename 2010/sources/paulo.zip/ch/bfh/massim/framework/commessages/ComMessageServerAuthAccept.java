/**
 * 
 */
package ch.bfh.massim.framework.commessages;

import java.util.Iterator;
import java.util.Set;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * the ComServer sends this message to the agents, when the authentification got
 * accepted
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class ComMessageServerAuthAccept extends ComMessage
{

    /**
     * Creates the authaccepted message. It also contains a list of all already
     * connected agents.
     * 
     * @param servername
     *            name of the server
     * @param receivername
     *            name of the receiver
     * @param allagents
     *            list of all connected agents
     */
    public ComMessageServerAuthAccept(String servername, String receivername, Set<String> allagents)
    {
        super(servername, "auth-accept");

        addReceiverAgent(receivername);

        Element messagebody = this.get_bodyElement();
        Document doc = messagebody.getOwnerDocument();

        Element auth = doc.createElement("agentlist");

        for (Iterator<String> iterator = allagents.iterator(); iterator.hasNext();)
        {
            String string = iterator.next();
            Element agent = doc.createElement("agent");
            agent.setAttribute("name", string);
            auth.appendChild(agent);
        }

        messagebody.appendChild(auth);
    }

}
