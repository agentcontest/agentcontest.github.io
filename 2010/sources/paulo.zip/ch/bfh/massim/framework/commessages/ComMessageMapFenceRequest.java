/**
 * 
 */
package ch.bfh.massim.framework.commessages;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import ch.bfh.massim.framework.MapCoordinate;

/**
 * This message is used from a CowboyAgent, to ask the map for more information
 * about a fence.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class ComMessageMapFenceRequest extends ComMessage
{

    /**
     * Creates a new message to ask the map about fence information.
     * 
     * @param sendername
     *            name of the sender
     * @param fencecoord
     *            a coordinate on the fence.
     */
    public ComMessageMapFenceRequest(String sendername, MapCoordinate fencecoord)
    {
        super(sendername, "MapFenceRequest");
        addReceiverAgent("MapAgent");
        Element messagebody = this.get_bodyElement();
        Element el = messagebody.getOwnerDocument().createElement("coord");
        el.setAttribute("x", String.valueOf(fencecoord.getX()));
        el.setAttribute("y", String.valueOf(fencecoord.getY()));
        messagebody.appendChild(el);
    }

    /**
     * Transform Constructor
     * 
     * @param message
     *            the message
     */
    public ComMessageMapFenceRequest(ComMessage message)
    {
        super(message.get_message());
    }

    /**
     * 
     * @return the coordinate from the fence
     */
    public MapCoordinate getFenceCoord()
    {
        NodeList nl = get_bodyElement().getChildNodes();
        for (int i = 0; i < nl.getLength(); i++)
        {
            Node n = nl.item(i);
            if (n.getNodeType() == Element.ELEMENT_NODE && n.getNodeName().equalsIgnoreCase("coord"))
            {
                Element el = (Element) n;
                return new MapCoordinate(Integer.parseInt(el.getAttribute("x")), Integer.parseInt(el.getAttribute("y")));
            }
        }
        return null;
    }

}
