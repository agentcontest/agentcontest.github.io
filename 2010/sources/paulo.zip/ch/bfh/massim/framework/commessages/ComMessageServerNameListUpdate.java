/**
 * 
 */
package ch.bfh.massim.framework.commessages;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * this message is send to all the agents, if a new agent connects to the
 * comserver. It contains a list of all connected agents.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class ComMessageServerNameListUpdate extends ComMessage
{

    private Element _el_agentlist;

    /**
     * Creates the new namelistupdate
     * 
     * @param servername
     *            name of the server
     * @param allagents
     *            list of all agents connected to the server.
     */
    public ComMessageServerNameListUpdate(String servername, Set<String> allagents)
    {
        super(servername, "namelist-update");

        addReceiverAll();

        Element messagebody = this.get_bodyElement();
        Document doc = messagebody.getOwnerDocument();

        _el_agentlist = doc.createElement("agentlist");

        for (String string : allagents)
        {
            Element agent = doc.createElement("agent");
            agent.setAttribute("name", string);
            _el_agentlist.appendChild(agent);
        }

        messagebody.appendChild(_el_agentlist);
    }

    /**
     * Transform constructor
     * 
     * @param message
     *            the message which has to be casted
     */
    public ComMessageServerNameListUpdate(ComMessage message)
    {
        super(message.get_message());

        NodeList nl = get_bodyElement().getChildNodes();
        for (int i = 0; i < nl.getLength(); i++)
        {
            Node n = nl.item(i);
            if (n.getNodeType() == Element.ELEMENT_NODE && n.getNodeName().equalsIgnoreCase("agentlist"))
            {
                _el_agentlist = (Element) n;
                break;
            }
        }
    }

    /**
     * gets a list of all known agents.
     * 
     * @return list of agents.
     */
    public List<String> getAgentList()
    {
        List<String> agentList = new ArrayList<String>();
        if (_el_agentlist != null)
        {
            NodeList nl = _el_agentlist.getChildNodes();
            for (int i = 0; i < nl.getLength(); i++)
            {
                Node n = nl.item(i);
                if (n.getNodeType() == Element.ELEMENT_NODE && n.getNodeName().equalsIgnoreCase("agent"))
                {
                    Element el = (Element) n;
                    agentList.add(el.getAttribute("name"));
                }
            }
        }
        return agentList;
    }

}
