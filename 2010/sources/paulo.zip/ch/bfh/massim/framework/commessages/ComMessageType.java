package ch.bfh.massim.framework.commessages;

/**
 * contains all the receiver types: GROUP, AGENT, ALL
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public enum ComMessageType
{
    GROUP, AGENT, ALL
}
