/**
 * Contains the important message types, used for the internal communication between 
 * all the agents.
 */
package ch.bfh.massim.framework.commessages;