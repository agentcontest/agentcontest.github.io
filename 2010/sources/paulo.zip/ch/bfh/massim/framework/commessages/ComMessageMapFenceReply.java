/**
 * 
 */
package ch.bfh.massim.framework.commessages;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import ch.bfh.massim.framework.MapCoordinate;

/**
 * This message is used from the MapAgent to answer the
 * ComMessageMapFenceRequest. The message contains all known information of a
 * fence.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class ComMessageMapFenceReply extends ComMessage
{

    /**
     * Creates the Message
     * 
     * @param sendername
     *            Name of the Sender
     */
    public ComMessageMapFenceReply(String sendername)
    {
        super(sendername, "MapFenceReply");

    }

    /**
     * Transform Constructor
     * 
     * @param message
     *            the message to cast
     */
    public ComMessageMapFenceReply(ComMessage message)
    {
        super(message.get_message());
    }

    /**
     * Add an open end to the message. An open end is a end of the fence, where
     * the next field is unknown.
     * 
     * @param coord
     *            Position of the open end
     */
    public void addOpenEnd(MapCoordinate coord)
    {
        Element messagebody = this.get_bodyElement();

        Element el = messagebody.getOwnerDocument().createElement("openend");
        el.setAttribute("x", String.valueOf(coord.getX()));
        el.setAttribute("y", String.valueOf(coord.getY()));
        messagebody.appendChild(el);
    }

    /**
     * Adds the coordinate of the switch belonging to the fence.
     * 
     * @param coord
     *            coordinate of the switch
     */
    public void addSwitch(MapCoordinate coord)
    {
        Element messagebody = this.get_bodyElement();
        Element el = messagebody.getOwnerDocument().createElement("switch");
        el.setAttribute("x", String.valueOf(coord.getX()));
        el.setAttribute("y", String.valueOf(coord.getY()));
        messagebody.appendChild(el);
    }

    /**
     * Gets the coordinate of an end of the switch, where the next field is
     * blocked.
     * 
     * @param coord
     *            coordinate of the field
     */
    public void addClosedEnd(MapCoordinate coord)
    {
        Element messagebody = this.get_bodyElement();
        Element el = messagebody.getOwnerDocument().createElement("closedend");
        el.setAttribute("x", String.valueOf(coord.getX()));
        el.setAttribute("y", String.valueOf(coord.getY()));
        messagebody.appendChild(el);
    }

    /**
     * Get an open end to the message. An open end is a end of the fence, where
     * the next field is unknown.
     * 
     * @return Position of the open end
     */
    public MapCoordinate getOpenEnd()
    {
        NodeList nl = get_bodyElement().getChildNodes();
        for (int i = 0; i < nl.getLength(); i++)
        {
            Node n = nl.item(i);
            if (n.getNodeType() == Element.ELEMENT_NODE && n.getNodeName().equalsIgnoreCase("openend"))
            {
                Element el = (Element) n;
                return new MapCoordinate(Integer.parseInt(el.getAttribute("x")), Integer.parseInt(el.getAttribute("y")));
            }
        }
        return null;
    }

    /**
     * Gets the coordinate of an end of the switch, where the next field is
     * blocked.
     * 
     * @return coordinate of the field
     */
    public MapCoordinate getClosedEnd()
    {
        NodeList nl = get_bodyElement().getChildNodes();
        for (int i = 0; i < nl.getLength(); i++)
        {
            Node n = nl.item(i);
            if (n.getNodeType() == Element.ELEMENT_NODE && n.getNodeName().equalsIgnoreCase("closedend"))
            {
                Element el = (Element) n;
                return new MapCoordinate(Integer.parseInt(el.getAttribute("x")), Integer.parseInt(el.getAttribute("y")));
            }
        }
        return null;
    }

    /**
     * Gets the coordinate of the switch belonging to the fence.
     * 
     * @return coord coordinate of the switch
     */
    public MapCoordinate getSwitchEnd()
    {
        NodeList nl = get_bodyElement().getChildNodes();
        for (int i = 0; i < nl.getLength(); i++)
        {
            Node n = nl.item(i);
            if (n.getNodeType() == Element.ELEMENT_NODE && n.getNodeName().equalsIgnoreCase("switch"))
            {
                Element el = (Element) n;
                return new MapCoordinate(Integer.parseInt(el.getAttribute("x")), Integer.parseInt(el.getAttribute("y")));
            }
        }
        return null;
    }

}
