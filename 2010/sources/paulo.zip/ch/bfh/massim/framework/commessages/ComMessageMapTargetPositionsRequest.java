package ch.bfh.massim.framework.commessages;

import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import ch.bfh.massim.framework.MapCoordinate;

/**
 * This message is used to ask the MapAgent to calculate the targets, each agent
 * has to go. The MapAgent will calculate the targets, so that a group of agents
 * can pass a fence.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class ComMessageMapTargetPositionsRequest extends ComMessage
{

    /**
     * Creates a new message
     * 
     * @param sendername
     *            name of the sender
     * @param agents
     *            list of the agents in the group
     * @param waypoint
     *            the next waypoint of the path, the group will travel
     */
    public ComMessageMapTargetPositionsRequest(String sendername, List<String> agents, MapCoordinate waypoint)
    {
        super(sendername, "MapTargetPositionRequest");
        addReceiverAgent("MapAgent");
        Element messagebody = this.get_bodyElement();

        for (String agent : agents)
        {
            Element el = messagebody.getOwnerDocument().createElement("agent");
            el.setAttribute("name", agent);
            messagebody.appendChild(el);
        }

        Element el = messagebody.getOwnerDocument().createElement("waypoint");
        el.setAttribute("x", String.valueOf(waypoint.getX()));
        el.setAttribute("y", String.valueOf(waypoint.getY()));
        messagebody.appendChild(el);

    }

    /**
     * Transform constructor
     * 
     * @param message
     *            the message
     */
    public ComMessageMapTargetPositionsRequest(ComMessage message)
    {
        super(message.get_message());
    }

    /**
     * get the list with all the agents in the group
     * 
     * @return list with the name of the agents
     */
    public List<String> getAgentNames()
    {
        List<String> agents = new ArrayList<String>();
        NodeList nl = get_bodyElement().getChildNodes();
        for (int i = 0; i < nl.getLength(); i++)
        {
            Node n = nl.item(i);
            if (n.getNodeType() == Element.ELEMENT_NODE && n.getNodeName().equalsIgnoreCase("agent"))
            {
                Element el = (Element) n;
                agents.add(el.getAttribute("name"));
            }
        }
        return agents;
    }

    /**
     * gets the waypoint, the group is heading for.
     * 
     * @return the waypoint
     */
    public MapCoordinate getWaypoint()
    {
        NodeList nl = get_bodyElement().getChildNodes();
        for (int i = 0; i < nl.getLength(); i++)
        {
            Node n = nl.item(i);
            if (n.getNodeType() == Element.ELEMENT_NODE && n.getNodeName().equalsIgnoreCase("waypoint"))
            {
                Element el = (Element) n;
                return new MapCoordinate(Integer.parseInt(el.getAttribute("x")), Integer.parseInt(el.getAttribute("y")));
            }
        }
        return null;
    }
}
