package ch.bfh.massim.framework;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.apache.log4j.Logger;

import ch.bfh.massim.framework.commessages.ComMessage;

/**
 * Is a agent, which is able to communicate with the ComServerAgent, and the
 * other ComClientAgents
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public abstract class ComClientAgent extends AbstractBaseAgent
{

    private static Logger log = Logger.getLogger(ComClientAgent.class);

    private int _networkport;
    private String _networkhost;

    private String _comUser;
    private String _comPwd;
    private String _comGroup;

    /**
     * Object do establish the connection to the ComServerAgent
     */
    protected ComClientConnection _comConnection;

    /**
     * Queue of all messages arrived, but not jet handeled.
     */
    private List<ComMessage> _inbox = new LinkedList<ComMessage>();

    /**
     * List of all agents connected to the ServerAgent.
     */
    protected List<String> _agents = new LinkedList<String>();

    /**
     * Creates a new ComClientAgent
     * 
     * @param name
     *            name of the Agent
     * @param networkhost
     *            networkaddress of the ComServer
     * @param networkport
     *            networkport of the ComServer
     * @param password
     *            password for the ComServer *not used jet*
     * @param group
     *            group name the Agent belongs to *not used jet*
     */
    public ComClientAgent(String name, String networkhost, int networkport, String password, String group)
    {
        super(name);
        _networkhost = networkhost;
        _networkport = networkport;

        _comUser = name;
        _comPwd = password;
        _comGroup = group;

    }

    /**
     * 
     * @return the connection to the server
     */
    public ComClientConnection getConnection()
    {
        return _comConnection;
    }

    /**
     * @see ch.bfh.massim.framework.AbstractBaseAgent#preThread()
     */
    @Override
    protected void preThread()
    {
        log.debug("Start Agent Thread '" + this._name + "'");
        try
        {
            _comConnection = new ComClientConnection(_networkhost, _networkport);
            _comConnection.sendAuthentication(_comUser, _comPwd, _comGroup);
            ComMessage message = receiveComMessageB("auth-accept");
            processComAuthAccept(message);
            System.out.println("got accepted by ComServer");
        }
        catch (ConnectionNotEstablishedException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

    }

    /**
     * @see ch.bfh.massim.framework.AbstractBaseAgent#postThread()
     */
    @Override
    protected void postThread()
    {
        _comConnection.close();
        log.debug("End Agent Thread '" + this._name + "'");
    }

    /**
     * @see masFramework.AbstractBaseAgent#agentThread()
     */
    @Override
    protected void agentThread()
    {
        try
        {
            while (!isInterrupted())
            {
                agentRun();
                checkForAutomaticComMessages();
            }
        }
        catch (IOException e)
        {
            System.err.println("IOException");
            e.printStackTrace();
            return;
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * This Method is called in a loop, till the agent is interrupted.
     * 
     * @throws IOException
     * @throws InterruptedException
     */
    abstract protected void agentRun() throws IOException, InterruptedException;

    /**
     * Checks the connection if there is a new Message and ads it to the inbox.
     * (non Blocking)
     */
    private void addIncomingMessagesToList()
    {
        while (_comConnection.hasPacket())
        {
            try
            {
                log.trace("add Incoming Message to List");
                _inbox.add(_comConnection.receiveMessage());
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }
    }

    /**
     * Checks the connection if there is a new Message and ads it to the inbox.
     * (Blocking)
     */
    private ComMessage addIncomingMessageToListB()
    {
        try
        {
            ComMessage message = _comConnection.receiveMessage();
            log.trace("add Incoming Message to List");
            _inbox.add(message);
            return message;
        }
        catch (IOException e)
        {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Checks, if there are Messages, which will be handled automatically by the
     * ComClient.
     */
    protected void checkForAutomaticComMessages()
    {
        addIncomingMessagesToList();
        ArrayList<ComMessage> al = new ArrayList<ComMessage>(_inbox);
        for (ComMessage message : al)
        {
            handleAutomaticComMessage(message);
        }
    }

    /**
     * Receives a message of a specific Type. (non Blocking)
     * 
     * @param type
     *            type of the Message
     * @return the first Message with the right type, or null, if no such
     *         message has arrived
     */
    public ComMessage receiveComMessage(String type)
    {
        addIncomingMessagesToList();
        ArrayList<ComMessage> al = new ArrayList<ComMessage>(_inbox);
        for (ComMessage message : al)
        {
            if (message.get_messageType().compareToIgnoreCase(type) == 0)
            {
                _inbox.remove(message);
                return message;
            }
            else
            {
                handleAutomaticComMessage(message);
            }
        }
        return null;
    }

    /**
     * Receives a message of a specific Type. (Blocking)
     * 
     * @param type
     *            type of the Message
     * @return the first Message with the right type.
     */
    public ComMessage receiveComMessageB(String type)
    {
        addIncomingMessagesToList();
        ArrayList<ComMessage> al = new ArrayList<ComMessage>(_inbox);
        for (ComMessage message : al)
        {
            System.out.println("check Message " + message.get_messageType());
            if (message.get_messageType().equalsIgnoreCase(type))
            {
                _inbox.remove(message);
                return message;
            }
            handleAutomaticComMessage(message);
        }

        while (true)
        {
            ComMessage message = addIncomingMessageToListB();
            System.out.println("check Message " + message.get_messageType());
            if (message.get_messageType().equalsIgnoreCase(type))
            {
                System.out.println("got Message " + message.get_messageType());
                _inbox.remove(message);
                return message;
            }
            else
            {
                handleAutomaticComMessage(message);
            }
        }
    }

    /**
     * Handles the message, if it is a specific Message
     * 
     * @param message
     *            The message to handle
     */
    protected void handleAutomaticComMessage(ComMessage message)
    {
        if (message.get_messageType().equalsIgnoreCase("namelist-update"))
        {
            processComNameListUpdate(message);
            _inbox.remove(message);
        }
    }

    /**
     * Process the "namelist-update" messages
     * 
     * @param message the namelist-update message to handle
     */
    protected void processComNameListUpdate(ComMessage message)
    {
        //System.out.println("process namelistupdate");
    }

    /**
     * Process the "auth-accept" messages
     * 
     * @param message the auth-accept message to handle
     */
    protected void processComAuthAccept(ComMessage message)
    {
        // unused
    }

    /**
     * 
     * @return the name in the com-environement
     */
    public String getComName()
    {
        return _comUser;
    }
}
