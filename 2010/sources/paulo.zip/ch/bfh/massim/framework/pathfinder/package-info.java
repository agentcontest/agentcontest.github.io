/**
 * Contains the classes needed for path calculation. This is shared logic for many classes.
 */
package ch.bfh.massim.framework.pathfinder;