package ch.bfh.massim.framework.pathfinder;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.PriorityQueue;

import ch.bfh.massim.framework.IMapField;
import ch.bfh.massim.framework.MapCoordinate;
import ch.bfh.massim.framework.mapagent.MapFieldGround;
import ch.bfh.massim.framework.mapagent.MapFieldObject;

/**
 * Class to find a path from A to B. This class is used so that other classes,
 * can create a path between two points with different criteria. This class
 * provides methods to get and set criteria and then to get a path between two
 * points with these criteria in mind.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class PathFinder
{

    private MapCoordinate _start;
    private MapCoordinate _goal;
    private IMapField[][] _map;
    private boolean[][] _closed;
    private int _xsize;
    private int _ysize;

    private boolean _ignoreobstacles;
    private boolean _ignoreunknownground;
    private boolean _ignoreunknowncontent;
    private boolean _ignorecows;
    private boolean _ignoreagents;
    private boolean _ignoreclosedfence;

    private double _closedfenceweight;
    private double _openfenceweight;

    private PriorityQueue<PathField> _openlist;

    /**
     * Default constructor. Doesn't ignore obstacles but ignores unknown content
     * and ground. Does not add additional weight to fences. Use the setter
     * methods to change this behavior.
     */
    public PathFinder()
    {
        _ignoreobstacles = false;
        _ignoreunknownground = true;
        _ignoreunknowncontent = true;
        _ignorecows = true;
        _ignoreagents = true;
        _ignoreclosedfence = true;
        _closedfenceweight = 0f;
        _openfenceweight = 0f;
    }

    /**
     * External method to invoke the search without coordinates to ignore.
     * 
     * @param map
     *            The map we are working on, coordinates are relative to this
     *            map
     * @param start
     *            The starting point
     * @param goal
     *            The field we would like to reach
     * @return The shortest path between start and goal as a list of coordinates
     */
    public List<MapCoordinate> getPath(IMapField map[][], MapCoordinate start, MapCoordinate goal)
    {
        return getPath(map, start, goal, null);
    }

    /**
     * External method to invoke the search with coordinates to ignore.
     * 
     * @param map
     *            The map we are working on, coordinates are relative to this
     *            map
     * @param start
     *            The starting point
     * @param goal
     *            The field we would like to reach
     * @param ignoreFields
     *            Additional fields which are ignored in the search
     * @return The shortest path between start and goal as a list of coordinates
     */
    public List<MapCoordinate> getPath(IMapField map[][], MapCoordinate start, MapCoordinate goal,
            List<MapCoordinate> ignoreFields)
    {
        _start = start;
        _goal = goal;
        _map = map;
        _xsize = map.length;

        if (_xsize == 0)
        {
            return null;
        }
        this._ysize = map[0].length;

        _closed = new boolean[_xsize][_ysize];

        for (int i = 0; i < _xsize; i++)
        {
            for (int j = 0; j < _ysize; j++)
            {
                _closed[i][j] = false;
            }
        }

        if (ignoreFields != null)
        {
            for (MapCoordinate coord : ignoreFields)
            {
                if (coord.isOnMap(map))
                {
                    _closed[coord.getX()][coord.getY()] = true;
                }
            }
        }

        List<MapCoordinate> path = findPath();
        if (path != null)
            Collections.reverse(path);
        return path;
    }

    /**
     * Get the path to the nearest possible field of the goal.
     * 
     * @param map
     *            the map we are working on, coordinates are relative to this
     *            map
     * @param start
     *            the starting point
     * @param goal
     *            the field we would like to reach
     * @return The shortest path between start and goal as a list of coordinates
     */
    public List<MapCoordinate> getPathToNearestGoal(IMapField map[][], MapCoordinate start, MapCoordinate goal)
    {
        return getPathToNearestGoal(map, start, goal, null);
    }

    /**
     * Get the path to the nearest possible field of the goal.
     * 
     * @param map
     *            the map we are working on, coordinates are relative to this
     *            map
     * @param start
     *            the starting point
     * @param goal
     *            the field we would like to reach
     * @param ignorefields
     *            additional fields which should be ignored
     * @return the shortest path between start and goal as a list of coordinates
     */
    public List<MapCoordinate> getPathToNearestGoal(IMapField map[][], MapCoordinate start, MapCoordinate goal,
            List<MapCoordinate> ignorefields)
    {
        if (goal.equals(start))
        {
            List<MapCoordinate> thepath = new ArrayList<MapCoordinate>(1);
            thepath.add(start);
            return thepath;
        }

        goal = getNearestNotblockedField(map, goal, start);

        if (!start.isOnMap(map))
        {
            start = getNearestNotblockedField(map, start, goal);
        }

        List<MapCoordinate> thepath = getPath(map, start, goal, ignorefields);

        // nearest, if the targetfield is occupied
        if (thepath == null)
        {
            for (int j = 1; j < map.length; j++)
            {
                List<MapCoordinate> neigbourgs = getNeighbors(goal, j, map.length, map[0].length);
                if (neigbourgs.size() == 0)
                    return null;
                for (int i = 0; i < neigbourgs.size(); i++)
                {
                    MapCoordinate newTarget = null;
                    int distNewTarget = Integer.MAX_VALUE;
                    for (MapCoordinate mapCoordinate : neigbourgs)
                    {
                        if (mapCoordinate.distance(start) < distNewTarget)
                        {
                            newTarget = mapCoordinate;
                            distNewTarget = mapCoordinate.distance(start);
                        }
                    }
                    if (!isBlocked(map[newTarget.getX()][newTarget.getY()]))
                    {
                        // return newTarget;
                        thepath = getPath(map, start, newTarget, ignorefields);
                        if (thepath != null)
                            return thepath;
                    }
                }
            }
        }

        return thepath;
    }

    /**
     * Method to actually find a path with the given settings.
     * 
     * @return the coordinates to the goal, inverse order
     */
    private List<MapCoordinate> findPath()
    {
        // Reset
        _openlist = new PriorityQueue<PathField>();
        PathField parent = null;

        // Create start, current and goal node
        IMapField starter = _map[_start.getX()][_start.getY()];
        PathField startf = new PathField(parent, starter, _start, 0f, 0f, 0f);
        _openlist.add(startf);

        PathField currentNode = null;
        if (_goal == null)
            return null;
        IMapField ender = _map[_goal.getX()][_goal.getY()];
        PathField goalf = new PathField(parent, ender, _goal, 0f, 0f, 0f);

        List<MapCoordinate> pathFound = new ArrayList<MapCoordinate>();

        while (!_openlist.isEmpty())
        {
            try
            {
                currentNode = _openlist.remove();

                if (currentNode.sameField(goalf))
                {
                    pathFound = getPathToHere(currentNode);
                    return pathFound;
                }

                expandNode(currentNode);

                MapCoordinate coord = currentNode.getCoordinate();
                _closed[coord.getX()][coord.getY()] = true;
            }
            catch (NoSuchElementException e)
            {
            }

        }

        return null;
    }

    /**
     * Method to expand a node. Adds the surrounding fields of a given field to
     * the open list according to the current rules.
     * 
     * @param currentNode
     *            the current node we would like to expend
     * 
     * 
     */
    private void expandNode(PathField currentNode)
    {
        ArrayList<PathField> successors = getSuccessors(currentNode);

        for (PathField successor : successors)
        {
            MapCoordinate coord = successor.getCoordinate();

            if (_closed[coord.getX()][coord.getY()])
                continue;

            // if the successor already is on the Open List,
            // but with a longer way to the goal, then ignore it
            if (_openlist.contains(successor))
            {
                PathField oldField = null;

                for (PathField pathField : _openlist)
                {
                    if (pathField.equals(successor))
                    {
                        oldField = pathField;
                        break;
                    }
                }
                if (oldField != null)
                {
                    if (oldField.getF() < successor.getF())
                    {
                        continue;
                    }
                }
            }
            // Otherwise: set the new parent

            successor.setParent(currentNode);

            // Update steps to reach the node in the Open List
            // Or add node to list if not already in it
            _openlist.remove(successor);
            _openlist.add(successor);
        }
    }

    /**
     * Helper method to get successors of a node. In our case these are the
     * surrounding fields of a given field.
     * 
     * @param current
     *            the parent field
     * @return a list of surrounding nodes according to the ignore rules
     */
    private ArrayList<PathField> getSuccessors(PathField current)
    {
        ArrayList<PathField> successors = new ArrayList<PathField>();

        if (current == null)
            return successors;

        int curx = current.getCoordinate().getX();
        int cury = current.getCoordinate().getY();

        int maxx = (curx == _xsize - 1) ? curx : curx + 1;
        int maxy = (cury == _ysize - 1) ? cury : cury + 1;

        int minx = (curx == 0) ? curx : curx - 1;
        int miny = (cury == 0) ? cury : cury - 1;

        for (int i = miny; i <= maxy; i++)
        {
            for (int j = minx; j <= maxx; j++)
            {

                // Ignore current field
                if (i == cury && j == curx)
                    continue;

                IMapField cfield = _map[j][i];

                if (isBlocked(cfield))
                {
                    continue;
                }

                MapCoordinate ccoord = new MapCoordinate(j, i);

                // Additional cost
                double ac = 0f;

                if (cfield.get_ground().equals(MapFieldGround.fenceopen))
                    ac = _openfenceweight;

                if (cfield.get_ground().equals(MapFieldGround.fenceclosed))
                    ac = _closedfenceweight;

                // Steps to here is parent + 1
                double sh = current.getStepsToHere() + 1;

                // Steps to go: as diagonal moves are allowed,
                // the minimum steps to go is Math.Max(x to goal, y to goal)
                double sg = Math.max(Math.abs(_goal.getX() - j), Math.abs(_goal.getY() - i));

                PathField cpf = new PathField(current, cfield, ccoord, ac, sh, sg);

                cpf.setEuclidian(ccoord.euclidianDistance(_goal));
                successors.add(cpf);
            }
        }

        return successors;
    }

    /**
     * Helper Method to return a path.
     * 
     * @param goal
     *            the goal node
     * @return the path to the goal node, inverse order
     */
    private ArrayList<MapCoordinate> getPathToHere(PathField goal)
    {
        ArrayList<MapCoordinate> path = new ArrayList<MapCoordinate>();
        path.add(goal.getCoordinate());

        PathField cparent = goal.getParent();
        if (cparent != null)
        {
            path.add(cparent.getCoordinate());

            while (cparent.getParent() != null)
            {
                path.add(cparent.getParent().getCoordinate());
                cparent = cparent.getParent();
            }
        }

        return path;

    }

    /**
     * returns the neighbors of a mapcoordinate with a given distance "r".
     * 
     * @param coord
     *            the central coordinate
     * @param r
     *            the distance
     * @param maxX
     *            max of the map in x direction
     * @param maxY
     *            max of the map in y direction
     * @return list with the neighbors
     */
    private List<MapCoordinate> getNeighbors(MapCoordinate coord, int r, int maxX, int maxY)
    {
        List<MapCoordinate> neighbors = new ArrayList<MapCoordinate>();

        if (coord == null)
            return neighbors;

        int i;
        int j;
        int ipos = coord.getX();
        int jpos = coord.getY();
        int imax = maxX;
        int jmax = maxY;
        for (int k = 0; k < 2 * r; k++)
        {
            // top stripe
            i = ipos - r + k;
            j = jpos - r;
            if (i >= 0 && j >= 0 && i < imax && j < jmax)
            {
                neighbors.add(new MapCoordinate(i, j));
            }
            // right stripe
            i = ipos + r;
            j = jpos - r + k;
            if (i >= 0 && j >= 0 && i < imax && j < jmax)
            {
                neighbors.add(new MapCoordinate(i, j));
            }
            // bottom stripe
            i = ipos + r - k;
            j = jpos + r;
            if (i >= 0 && j >= 0 && i < imax && j < jmax)
            {
                neighbors.add(new MapCoordinate(i, j));
            }
            // left stripe
            i = ipos - r;
            j = jpos + r - k;
            if (i >= 0 && j >= 0 && i < imax && j < jmax)
            {
                neighbors.add(new MapCoordinate(i, j));
            }
        }
        return neighbors;
    }

    /**
     * returns the nearest field on the map, which is not occupied.
     * 
     * @param map
     *            the map
     * @param goal
     *            the goal
     * @param startField
     *            the start point
     * @return the nearest free field
     */
    public MapCoordinate getNearestNotblockedField(IMapField[][] map, MapCoordinate goal, MapCoordinate startField)
    {
        // nearest on the map if the targetfield is outside the map
        // moves the targetfield in the map area
        if (goal.getX() < 0)
        {
            goal.setX(0);
        }
        else if (goal.getX() >= map.length)
        {
            goal.setX(map.length - 1);
        }
        if (goal.getY() < 0)
        {
            goal.setY(0);
        }
        else if (goal.getY() >= map[0].length)
        {
            goal.setY(map[0].length - 1);
        }

        // nearest, if the targetfield is occupied
        if (isBlocked(map[goal.getX()][goal.getY()]))
        {
            
            try
            {
            for (int j = 1; j < map.length; j++)
            {
                List<MapCoordinate> neigbourgs = getNeighbors(goal, j, map.length, map[0].length);
                if (neigbourgs.size() == 0)
                    return goal;
                for (int i = 0; i < neigbourgs.size(); i++)
                {
                    MapCoordinate newTarget = null;
                    int distNewTarget = Integer.MAX_VALUE;
                    for (MapCoordinate mapCoordinate : neigbourgs)
                    {
                        if (mapCoordinate.distance(startField) < distNewTarget)
                        {
                            newTarget = mapCoordinate;
                            distNewTarget = mapCoordinate.distance(startField);
                        }
                    }
                    if (!isBlocked(map[newTarget.getX()][newTarget.getY()]))
                    {
                        return newTarget;
                    }
                }
            }
            }
            catch (ArrayIndexOutOfBoundsException e)
            {
                return goal;
            }
        }

        return goal;
    }

    /**
     * Checks if the field is blocked by a object which can't be passed.
     * 
     * @param field
     *            the field to check
     * @return true if the field is blocked
     */
    public boolean isBlocked(IMapField field)
    {
        if (field == null)
            return true;

        // If we don't ignore unknown grounds, then don't add unknown
        // grounds
        if (!_ignoreunknownground)
        {
            if (field.get_ground().equals(MapFieldGround.unknown))
                return true;
        }

        // If we don't ignore agents, then don't add agents
        if (!_ignoreagents)
        {
            if (field.get_object().equals(MapFieldObject.agent) || field.get_object().equals(MapFieldObject.enemyagent))
                return true;
        }

        // If we don't ignore cows, then don't add cows
        if (!_ignorecows)
        {
            if (field.get_object().equals(MapFieldObject.cow))
                return true;
        }

        // If we don't ignore unknown grounds, then don't add unknown
        // grounds
        if (!_ignoreunknownground)
        {
            if (field.get_ground().equals(MapFieldGround.unknown))
                return true;
        }

        // If we don't ignore unknown objects, then don't add unknown
        // objects
        if (!_ignoreunknowncontent)
        {
            if (field.get_object().equals(MapFieldObject.unknown))
                return true;
        }

        // If we don't ignore obstacles, then don't add obstacles
        if (!_ignoreobstacles)
        {
            if (field.get_ground().equals(MapFieldGround.obstacle)
                    || field.get_ground().equals(MapFieldGround.fenceswitch))
            {
                return true;
            }
        }

        // If we don't ignore obstacles, then don't add obstacles
        if (!_ignoreclosedfence)
        {
            if (field.get_ground().equals(MapFieldGround.fenceclosed))
            {
                return true;
            }
        }

        return false;

    }

    /**
     * @return whether obstacles (such as trees) are ignored (path goes through)
     */
    public boolean isIgnoreobstacles()
    {
        return _ignoreobstacles;
    }

    /**
     * @param ignoreobstacles
     *            whether obstacles (such as trees) are ignored (path goes
     *            through)
     */
    public void setIgnoreobstacles(boolean ignoreobstacles)
    {
        this._ignoreobstacles = ignoreobstacles;
    }

    /**
     * @return whether unknown grounds are ignored (path goes through)
     */
    public boolean isIgnoreunknownground()
    {
        return _ignoreunknownground;
    }

    /**
     * @param ignoreunknownground
     *            whether unknown grounds are ignored (path goes through)
     */
    public void setIgnoreunknownground(boolean ignoreunknownground)
    {
        this._ignoreunknownground = ignoreunknownground;
    }

    /**
     * @return whether unknown contents are ignored (path goes through)
     */
    public boolean isIgnoreunknowncontent()
    {
        return _ignoreunknowncontent;
    }

    /**
     * @param ignoreunknowncontent
     *            whether unknown contents are ignored (path goes through)
     */
    public void setIgnoreunknowncontent(boolean ignoreunknowncontent)
    {
        this._ignoreunknowncontent = ignoreunknowncontent;
    }

    /**
     * @return the additional weight of a closed fence
     */
    public double getClosedfenceweight()
    {
        return _closedfenceweight;
    }

    /**
     * @param closedfenceweight
     *            the additional weight of a closed fence
     */
    public void setClosedfenceweight(double closedfenceweight)
    {
        this._closedfenceweight = closedfenceweight;
    }

    /**
     * @return the additional weight of a open fence
     */
    public double getOpenfenceweight()
    {
        return _openfenceweight;
    }

    /**
     * @param openfenceweight
     *            the additional weight of a closed fence
     */
    public void setOpenfenceweight(double openfenceweight)
    {
        this._openfenceweight = openfenceweight;
    }

    /**
     * @return whether cows are ignored (path goes through)
     */
    public boolean isIgnorecows()
    {
        return _ignorecows;
    }

    /**
     * @param ignorecows
     *            cows are ignored (path goes through)
     */
    public void setIgnorecows(boolean ignorecows)
    {
        this._ignorecows = ignorecows;
    }

    /**
     * @return whether agents are ignored (path goes through)
     */
    public boolean isIgnoreagents()
    {
        return _ignoreagents;
    }

    /**
     * @param ignoreagents
     *            whether agents are ignored (path goes through)
     */
    public void setIgnoreagents(boolean ignoreagents)
    {
        this._ignoreagents = ignoreagents;
    }

    /**
     * @return whether closed fences are ignored
     */
    public boolean isIgnoreclosedfence()
    {
        return _ignoreclosedfence;
    }

    /**
     * @param ignoreclosedfence
     *            whether closed fences are ignored
     */
    public void setIgnoreclosedfence(boolean ignoreclosedfence)
    {
        this._ignoreclosedfence = ignoreclosedfence;
    }

}