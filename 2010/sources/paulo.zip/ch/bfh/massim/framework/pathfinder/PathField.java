package ch.bfh.massim.framework.pathfinder;

import ch.bfh.massim.framework.IMapField;
import ch.bfh.massim.framework.MapCoordinate;
import ch.bfh.massim.framework.mapagent.MapFieldGround;
import ch.bfh.massim.framework.mapagent.MapFieldObject;

/**
 * Class to represent a field in a path. This class is used so that other
 * classes, such as the PathFinder, can treat a given step in a path with a
 * object representing the field on the map.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class PathField implements Comparable<Object>
{
    private MapCoordinate _coordinate;
    private IMapField _field;
    private PathField _parent;
    private double _additionalCost;
    private double _stepsToHere;
    private double _stepsToGo;
    private double _euclidian;
    private double _f;

    /**
     * Default constructor.
     * 
     * @param parent
     *            parent node, might be null
     * @param field
     *            the IField in this field, used for field content
     * @param coord
     *            the coordinates relative to the current map
     * @param ac
     *            additional costs (e.g. a open fence > an empty field)
     * @param sh
     *            steps taken to reach this field
     * @param sg
     *            approximate steps to the goal (straight distance)
     */
    public PathField(PathField parent, IMapField field, MapCoordinate coord, double ac, double sh, double sg)
    {
        this._coordinate = coord;
        this._field = field;
        this._parent = parent;
        this._additionalCost = ac;
        this._stepsToHere = sh;
        this._stepsToGo = sg;

        _f = sh + sg;
    }

    /**
     * Equals which does not take care of the field weight.
     * 
     * @param other
     *            the other field
     * @return whether the both fields are the same on the map
     */
    public boolean sameField(PathField other)
    {
        return (this._coordinate.equals(other._coordinate));
    }

    /**
     * @return the ground
     */
    public MapFieldGround getGround()
    {
        return _field.get_ground();
    }

    /**
     * @return the object on the field
     */
    public MapFieldObject getObject()
    {
        return _field.get_object();
    }

    /**
     * @return the coordinate
     */
    public MapCoordinate getCoordinate()
    {
        return _coordinate;
    }

    /**
     * @param coordinate
     *            the coordinate
     */
    public void setCoordinate(MapCoordinate coordinate)
    {
        this._coordinate = coordinate;
    }

    /**
     * @return the field
     */
    public IMapField getField()
    {
        return _field;
    }

    /**
     * @param field
     *            the field (content)
     */
    public void setField(IMapField field)
    {
        this._field = field;
    }

    /**
     * @return the parent
     */
    public PathField getParent()
    {
        return _parent;
    }

    /**
     * @param parent
     *            the parent field
     */
    public void setParent(PathField parent)
    {
        this._parent = parent;
    }

    /**
     * @return the additionalCost
     */
    public double getAdditionalCost()
    {
        return _additionalCost;
    }

    /**
     * @param additionalCost
     *            the additionalCost to set
     */
    public void setAdditionalCost(double additionalCost)
    {
        this._additionalCost = additionalCost;
    }

    /**
     * @return the stepsToHere
     */
    public double getStepsToHere()
    {
        return _stepsToHere;
    }

    /**
     * @param stepsToHere
     *            the stepsToHere to set
     */
    public void setStepsToHere(double stepsToHere)
    {
        this._stepsToHere = stepsToHere;
        _f = stepsToHere + _stepsToGo;
    }

    /**
     * @return the stepsToGo
     */
    public double getStepsToGo()
    {
        return _stepsToGo;
    }

    /**
     * @param stepsToGo
     *            the stepsToGo to set
     */
    public void setStepsToGo(double stepsToGo)
    {
        this._stepsToGo = stepsToGo;
        _f = _stepsToHere + stepsToGo;
    }

    /**
     * @return the f
     */
    public double getF()
    {
        return _f;
    }

    /**
     * @return the euclidian distance to the goal
     */
    public double getEuclidian()
    {
        return _euclidian;
    }

    /**
     * @param euclidian
     *            the euclidian distance to set
     */
    public void setEuclidian(double euclidian)
    {
        this._euclidian = euclidian;
    }

    @Override
    public int compareTo(Object other)
    {
        if (!(other instanceof PathField))
            return 0;

        PathField o = (PathField) other;

        double fown = _f + _additionalCost;
        double fother = o._f + o._additionalCost;

        if (fother < fown)
        {
            return 1;
        }
        else if (fother > fown)
        {
            return -1;
        }

        else
        {
            if (o._euclidian < _euclidian)
            {
                return 1;
            }
            else if (o._euclidian > _euclidian)
            {
                return -1;
            }
            return 0;
        }
    }

    /**
     * @return string representation of the path field
     */
    public String toString()
    {
        return (this._coordinate.toString() + ": " + _field.get_ground() + " " + _field.get_object());
    }

    /**
     * Equals method.
     * 
     * @return whether two objects are equal
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof PathField)
        {
            return this._coordinate.equals(((PathField) obj)._coordinate);
        }
        else
            return false;
    }

}
