package ch.bfh.massim.framework;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import org.apache.log4j.Logger;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import ch.bfh.massim.framework.commessages.ComMessage;
import ch.bfh.massim.framework.commessages.ComMessageServerAuthAccept;
import ch.bfh.massim.framework.commessages.ComMessageServerIntern;
import ch.bfh.massim.framework.commessages.ComMessageServerNameListUpdate;

/**
 * This Class is the communication server for the Agents. All the communication
 * between the agents goes over this Agent.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class ComServerAgent extends AbstractBaseAgent
{

    private static Logger log = Logger.getLogger(ComServerAgent.class);

    private static final int SLEEPTIME = 5;
    // private static final int ACCEPTTIMEOUT = 200;

    private int _port;
    // private ServerSocket _serverSocket;
    // private List<ComServerSocketContainer> _newSocketList;
    private Map<Integer, ComServerSocketContainer> _socketMap;
    private Queue<ComMessageServerIntern> _inbox;
    /**
     * Contains all agents, which completed the authorization. Is used to
     * transform a id to a Name.
     */
    private Map<String, Integer> _nameMatchTable;
    /**
     * Contains all agents, which completed the authorization. Is used to
     * transform a name to a id.
     */
    private Map<Integer, String> _idMatchTable;

    private XMLInputFactory _xmlInputFactory;

    /**
     * Creates the server
     * 
     * @param name
     *            name of the server
     * @param port
     *            port on which the server listens
     */
    public ComServerAgent(String name, int port)
    {
        super(name);
        // System.err.println("starting server " + name + " port: " + port);
        _port = port;

        _xmlInputFactory = XMLInputFactory.newInstance();
    }

    /**
     * @see ch.bfh.massim.framework.AbstractBaseAgent#agentThread()
     */
    @Override
    protected void agentThread()
    {
        log.debug("Start Server Thread '" + _name + "'");
        // _newSocketList = Collections.synchronizedList(new
        // ArrayList<ComServerSocketContainer>());
        _socketMap = Collections.synchronizedMap(new HashMap<Integer, ComServerSocketContainer>());
        _inbox = new LinkedBlockingQueue<ComMessageServerIntern>();
        _nameMatchTable = new HashMap<String, Integer>();
        _idMatchTable = new HashMap<Integer, String>();

        // Thread to accept the connections
        Thread acceptorThread = new ComServerAcceptor(_port, _socketMap, _inbox);
        acceptorThread.start();

        // Thread messageHandlerThread = new ComServerMessageHandler(_inbox);
        // messageHandlerThread.start();

        while (!isInterrupted())
        {
            // Handle the messages in the inbox
            ComMessageServerIntern message = getMessageFromInbox();
            if (message != null)
            {
                handleMessage(message);
            }
            else
            {
                // Allow other threads to act, and make a short sleep, to lower
                // processor-load
                // Thread.yield();
                try
                {
                    Thread.sleep(SLEEPTIME);
                }
                catch (InterruptedException e)
                {
                    interrupt();
                }
            }
            Thread.yield();
        }
        System.out.println("isInterrupted");
        acceptorThread.interrupt();
        // messageHandlerThread.interrupt();

        try
        {
            // messageHandlerThread.join();
            acceptorThread.join();
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }

        System.out.println("End Server Thread '" + _name + "'");
    }

    /**
     * returns a message, if there is one in the inbox
     * 
     * @return the message or null
     */
    ComMessageServerIntern getMessageFromInbox()
    {
        if (!_inbox.isEmpty())
        {
            ComMessageServerIntern message = _inbox.poll();
            return message;
            // handleMessage(message);
        }
        else
        {
            return null;
        }
    }

    /**
     * processes a message
     * 
     * @param message
     *            the message
     */
    protected void handleMessage(ComMessageServerIntern message)
    {

        ByteArrayInputStream in = new ByteArrayInputStream(message.get_message());
        try
        {
            XMLStreamReader xmlStreamReader = _xmlInputFactory.createXMLStreamReader(in);
            while (xmlStreamReader.hasNext())
            {
                int event = xmlStreamReader.nextTag();
                if (event == XMLStreamConstants.START_ELEMENT)
                {

                    if (xmlStreamReader.getLocalName().equals("receiver"))
                    {
                        processXMLReceiver(xmlStreamReader, message);
                        break;
                    }
                }
            }
            xmlStreamReader.close();

        }
        catch (XMLStreamException e)
        {
            e.printStackTrace();
        }

    }

    /**
     * process the receiver tag of a massage
     * 
     * @param xmlStreamReader the stream reader
     * @param message the massage we are interested in
     * @throws XMLStreamException errors in the stream
     */
    private void processXMLReceiver(XMLStreamReader xmlStreamReader, ComMessageServerIntern message)
            throws XMLStreamException
    {

        log.trace("process the receivers of the message");
        // set the counter, to recoginze if we leaf the "receiver"-Tag
        int stackCounter = 0;
        while (xmlStreamReader.hasNext() && stackCounter >= 0)
        {
            int event = xmlStreamReader.next();
            if (event == XMLStreamConstants.START_ELEMENT)
            {
                // System.out.println("start element: " +
                // xmlStreamReader.getLocalName());
                // if (!xmlStreamReader.isStandalone()) stackCounter++;
                // sent To Server
                if (xmlStreamReader.getLocalName().equals("server"))
                {
                    sendToServer(message);
                }
                // send To All
                else if (xmlStreamReader.getLocalName().equals("all"))
                {
                    sentToAll(message);
                }
                // send To Agent
                else if (xmlStreamReader.getLocalName().equals("agent"))
                {
                    if (xmlStreamReader.getAttributeLocalName(0) == "name")
                    {
                        sentToAgent(message, xmlStreamReader.getAttributeValue(0));
                    }
                }
                // send To Group
                else if (xmlStreamReader.getLocalName().equals("group"))
                {
                    if (xmlStreamReader.getAttributeLocalName(0) == "name")
                    {
                        sentToGroup(message, xmlStreamReader.getAttributeValue(0));
                    }
                }
            }
            else if (event == XMLStreamConstants.END_ELEMENT)
            {
                stackCounter--;
            }
        }

    }

    /**
     * send the message to a group *not jet implemented*
     * 
     * @param message
     * @param groupname
     */
    private void sentToGroup(ComMessageServerIntern message, String groupname)
    {
        // TODO: implement

    }

    /**
     * Sends the message to a agent
     * 
     * @param message the message to send 
     * @param agentname
     *            name of the agent
     */
    private void sentToAgent(ComMessageServerIntern message, String agentname)
    {
        log.debug("forward a message to " + agentname);
        Integer receiverID = _nameMatchTable.get(agentname);
        if (receiverID != null)
        {
            ComServerSocketContainer container = _socketMap.get(receiverID);
            if (container != null)
            {
                try
                {
                    container.sendPackage(message.get_message());
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }
            }
            else
            {
                // TODO Log some error
            }
        }
        else
        {
            // TODO Log some error
        }
    }

    /**
     * sends the message to all connected agents
     * 
     * @param message the message to send
     */
    private void sentToAll(ComMessageServerIntern message)
    {
        log.debug("forward a message to all");

        for (Iterator<Integer> iterator = _nameMatchTable.values().iterator(); iterator.hasNext();)
        {
            Integer receiverID = (Integer) iterator.next();
            if (message.get_senderId() != receiverID.intValue())
            {
                ComServerSocketContainer container = _socketMap.get(receiverID);
                if (container != null)
                {
                    try
                    {
                        container.sendPackage(message.get_message());
                    }
                    catch (IOException e)
                    {
                        e.printStackTrace();
                    }
                }
                else
                {
                    // TODO Log some error
                }
            }
        }

    }

    /**
     * the message is handled by the server
     * 
     * @param message the message to send to the server
     */
    private void sendToServer(ComMessageServerIntern message)
    {
        log.debug("forward a message to server");

        Element body = message.get_bodyElement();
        String type = body.getAttribute("type");

        if (type.equalsIgnoreCase("auth-request"))
        {
            handleAuthRequest(message);
        }
    }

    /**
     * handels the auth-request message. creates all the nessecary objects to
     * establish the connection to the Agent.
     * 
     * @param message the message with the auth request
     */
    private void handleAuthRequest(ComMessageServerIntern message)
    {
        log.trace("handle a authrequest");
        Element body = message.get_bodyElement();
        NodeList nl = body.getElementsByTagName("authentication");
        if (nl.getLength() > 0)
        {
            Element auth = (Element) nl.item(0);
            String username = auth.getAttribute("username");
            String group = auth.getAttribute("group");
            String password = auth.getAttribute("password");

            if (addNewUser(username, password, group, message.get_senderId()))
            {
                ComServerSocketContainer container = _socketMap.get(message.get_senderId());
                if (container != null)
                {
                    ComMessage authaccept = new ComMessageServerAuthAccept(this._name, username, _nameMatchTable
                            .keySet());
                    try
                    {
                        container.sendPackage(authaccept.get_message());
                    }
                    catch (IOException e)
                    {
                        e.printStackTrace();
                    }

                    // send namelist-update to all other agents

                }
                else
                {
                    // TODO some error
                }

                // send namelist-update to all other agents
                ComMessage namelistupdate = new ComMessageServerNameListUpdate(this._name, _nameMatchTable.keySet());
                for (Iterator<Integer> iterator = _nameMatchTable.values().iterator(); iterator.hasNext();)
                {
                    Integer receiverID = (Integer) iterator.next();
                    if (message.get_senderId() != receiverID.intValue())
                    {
                        ComServerSocketContainer allcontainer = _socketMap.get(receiverID);
                        if (container != null)
                        {
                            try
                            {
                                allcontainer.sendPackage(namelistupdate.get_message());
                            }
                            catch (IOException e)
                            {
                                e.printStackTrace();
                            }
                        }
                        else
                        {
                            // TODO Log some error
                        }
                    }
                }
            }
            else
            {
                // TODO Response with auth-rejected to Sender
            }
        }
    }

    /**
     * Adds the user to the server. Now it is usable for sending and receiving
     * messages.
     * 
     * @param username the agent username
     * @param password the agent password
     * @param group the team the agent is in
     * @param id the unique id of the agent
     * @return true if the authentication succeeded
     */
    private boolean addNewUser(String username, String password, String group, int id)
    {
        // TODO handle group argument
        // TODO handle password argument
        // System.out.println("Authorize new user: " + username + " (" + group +
        // ")" + id + "(pw:" + password + ")");
        log.debug("Authorize new user: " + username + " group:" + group + " id:" + id + " pw:" + password);

        _nameMatchTable.put(username, id);
        _idMatchTable.put(id, username);
        return true;
    }

    /**
     * @see ch.bfh.massim.framework.AbstractBaseAgent#postThread()
     */
    @Override
    protected void postThread()
    {
        // TODO Auto-generated method stub

    }

    /**
     * @see ch.bfh.massim.framework.AbstractBaseAgent#preThread()
     */
    @Override
    protected void preThread()
    {
        // TODO Auto-generated method stub

    }

}
