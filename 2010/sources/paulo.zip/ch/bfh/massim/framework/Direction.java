package ch.bfh.massim.framework;

/**
 * Helper enum to represent a direction. The integer values correspond to the
 * MASSim values for directions, except the additional 9 which is "none".
 * Directions are: 0: north 1: northeast 2: east 3: southeast 4: south 5:
 * southwest 6: west 7: northwest 8: none
 * 
 * @author Christian Loosli & Adrian Pauli
 */
public enum Direction
{
    NORTH, NORTHEAST, EAST, SOUTHEAST, SOUTH, SOUTHWEST, WEST, NORTHWEST, NONE
}
