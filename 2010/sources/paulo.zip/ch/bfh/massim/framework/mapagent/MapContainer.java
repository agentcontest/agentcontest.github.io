package ch.bfh.massim.framework.mapagent;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import ch.bfh.massim.framework.IMapField;
import ch.bfh.massim.framework.MapCoordinate;
import ch.bfh.massim.framework.commessages.ComMessageMapCommit;
import ch.bfh.massim.framework.commessages.ComMessageMapFenceReply;
import ch.bfh.massim.framework.commessages.ComMessageMapFenceRequest;
import ch.bfh.massim.framework.commessages.ComMessageMapInit;
import ch.bfh.massim.framework.commessages.ComMessageMapTargetPositionsReply;
import ch.bfh.massim.framework.commessages.ComMessageMapTargetPositionsRequest;
import ch.bfh.massim.framework.cowherd.Cow;

/**
 * This class contains the whole data from the map. For each field in the "real"
 * map there is a representation of it in this class.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class MapContainer implements Cloneable
{

    /**
     * This enum is used to identify the direction of the fence. If it is in x
     * or y direction.
     * 
     * @author Christian Loosli & Adrian Pauli
     * 
     */
    public enum Direction
    {
        inX, inY, unknown
    }

    private String _simID = "";
    private String _ownteam = "";
    private String _oppteam = "";
    private boolean _isInit = false;
    private int _step = -1;
    private MapField[][] _map;
    private Map<String, MapCoordinate> _agentPos = new HashMap<String, MapCoordinate>();
    private Map<String, Cow> _cowList = new HashMap<String, Cow>();
    private int[] corralBorder = { 0, 0, 0, 0 };

    /**
     * Clones the object.
     * 
     * @see java.lang.Object#clone()
     */
    @SuppressWarnings("unchecked")
    public synchronized MapContainer clone() throws CloneNotSupportedException
    {
        MapContainer clone = (MapContainer) super.clone();

        clone._map = (MapField[][]) _map.clone();
        for (int i = 0; i < _map.length; i++)
        {
            for (int j = 0; j < _map[0].length; j++)
            {
                clone._map[i][j] = (MapField) _map[i][j].clone();
            }
        }
        clone._agentPos = (Map<String, MapCoordinate>) ((HashMap<String, MapCoordinate>) _agentPos).clone();
        clone._cowList = (Map<String, Cow>) ((HashMap<String, Cow>) _cowList).clone();

        return clone;
    }

    /**
     * @return the map as an array of MapField
     */
    public MapField[][] getMap()
    {
        return _map;
    }

    /**
     * 
     * @return true if the map is alreadi initialized
     */
    public synchronized boolean isInit()
    {
        return _isInit;
    }

    /**
     * 
     * @return numer of the current Step of the game
     */
    public int getStep()
    {
        return _step;
    }

    /**
     * @return unique ID of the current simulation.
     */
    public String get_simID()
    {
        return _simID;
    }

    /**
     * @return unique ID of the own team.
     */
    public String get_ownTeam()
    {
        return _ownteam;
    }

    /**
     * @return unique ID of the own team.
     */
    public String get_oppTeam()
    {
        return _oppteam;
    }

    /**
     * Resets the Map and creates a new one.
     * 
     * @param message
     *            MapInit message, which contains the information about the
     *            current map.
     */
    public synchronized void init(ComMessageMapInit message)
    {
        _isInit = true;

        // saves the new id
        _simID = message.get_simID();
        _ownteam = message.get_ownID();
        _oppteam = message.get_opID();

        // create the new array with the map
        _map = new MapField[message.get_gsizex()][message.get_gsizey()];

        // fill the Map with unknown Fields
        for (int i = 0; i < _map.length; i++)
        {
            for (int j = 0; j < _map[i].length; j++)
            {
                _map[i][j] = new MapField();
            }
        }

        int left = message.get_corralx0();
        int right = message.get_corralx1();
        int top = message.get_corraly0();
        int bottom = message.get_corraly1();

        corralBorder[0] = top;
        corralBorder[1] = right;
        corralBorder[2] = bottom;
        corralBorder[3] = left;

        // set the corral
        for (int i = left; i <= right; i++)
        {
            for (int j = top; j <= bottom; j++)
            {
                _map[i][j].set_ground(MapFieldGround.mycorral);
            }
        }

        _cowList = new HashMap<String, Cow>();
        _agentPos = new HashMap<String, MapCoordinate>();
    }

    /**
     * Updates the map with the local sight of an agent.
     * 
     * @param message
     *            message containing the local sight
     */
    public synchronized void update(ComMessageMapCommit message)
    {

        //System.out.println("new update");

        int posx = message.get_posx();
        int posy = message.get_posy();
        _step = message.get_step();

        // update sender position
        String sendername = message.getSenderName();
        if (sendername.length() > 0)
        {
            _agentPos.put(sendername, new MapCoordinate(posx, posy));
        }

        NodeList nl = message.get_cellList();
        // System.out.println("Length:" + nl.getLength() );
        for (int i = 0; i < nl.getLength(); i++)
        {
            Node n = nl.item(i);
            if (n.getNodeType() == Element.ELEMENT_NODE && n.getNodeName().equalsIgnoreCase("cell"))
            {
                Element e = (Element) n;
                int x = Integer.parseInt(e.getAttribute("x")) + posx;
                int y = Integer.parseInt(e.getAttribute("y")) + posy;

                MapField field = _map[x][y];
                field.set_lastSeen(_step);

                Node child = e.getFirstChild();

                field.set_ground(MapFieldGround.empty);
                field.set_object(MapFieldObject.none);

                while (child != null)
                {

                    if (child.getNodeType() == Element.ELEMENT_NODE)
                    {
                        if (child.getNodeName().equalsIgnoreCase("obstacle"))
                        {
                            field.set_ground(MapFieldGround.obstacle);
                        }
                        else if (child.getNodeName().equalsIgnoreCase("switch"))
                        {
                            field.set_ground(MapFieldGround.fenceswitch);
                        }
                        else if (child.getNodeName().equalsIgnoreCase("fence"))
                        {
                            Element elemChild = (Element) child;
                            String open = elemChild.getAttribute("open");
                            if (open.equalsIgnoreCase("true"))
                            {
                                field.set_ground(MapFieldGround.fenceopen);
                            }
                            else if (open.equalsIgnoreCase("false"))
                            {
                                field.set_ground(MapFieldGround.fenceclosed);
                            }
                        }
                        else if (child.getNodeName().equalsIgnoreCase("corral"))
                        {
                            Element elemChild = (Element) child;
                            String type = elemChild.getAttribute("type");
                            if (type.equalsIgnoreCase("ally"))
                            {
                                field.set_ground(MapFieldGround.mycorral);
                            }
                            else if (type.equalsIgnoreCase("enemy"))
                            {
                                field.set_ground(MapFieldGround.enemycorral);
                            }
                        }
                        else if (child.getNodeName().equalsIgnoreCase("agent"))
                        {
                            Element elemChild = (Element) child;
                            String type = elemChild.getAttribute("type");
                            if (type.equalsIgnoreCase("ally"))
                            {
                                field.set_object(MapFieldObject.agent);
                            }
                            else if (type.equalsIgnoreCase("enemy"))
                            {
                                field.set_object(MapFieldObject.enemyagent);
                            }
                        }
                        else if (child.getNodeName().equalsIgnoreCase("cow"))
                        {
                            Element elemChild = (Element) child;
                            String cowID = elemChild.getAttribute("ID");
                            field.set_object(MapFieldObject.cow);
                            field.set_objectID(Integer.parseInt(cowID));
                            handleCow(x, y, cowID, _step);
                        }
                    }
                    child = child.getNextSibling();
                }
            }
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString()
    {
        String result = "\n";
        for (int i = 0; i < _map.length; i++)
        {
            result += "|";
            for (int j = 0; j < _map[i].length; j++)
            {
                if (_map[i][j].get_object() == MapFieldObject.agent)
                {
                    result += "A";
                }
                else if (_map[i][j].get_object() == MapFieldObject.enemyagent)
                {
                    result += "E";
                }
                else if (_map[i][j].get_object() == MapFieldObject.cow)
                {
                    result += "C";
                }
                else if (_map[i][j].get_ground() == MapFieldGround.empty)
                {
                    result += " ";
                }
                else if (_map[i][j].get_ground() == MapFieldGround.mycorral)
                {
                    result += "c";
                }
                else if (_map[i][j].get_ground() == MapFieldGround.obstacle)
                {
                    result += "o";
                }
                else if (_map[i][j].get_ground() == MapFieldGround.unknown)
                {
                    result += "?";
                }
                else
                {
                    result += "!";
                }

            }
            result += "|\n";
        }
        return result;
    }

    public MapCoordinate getAgentPosition(String agentname)
    {
        if (_agentPos.containsKey(agentname))
        {
            return _agentPos.get(agentname);
        }
        else
        {
           // System.err.println("Agent " + agentname + " not in list. listsize:" + _agentPos.size());
        }
        return null;
    }

    /**
     * Returns the map as a xml-document.
     * 
     * @param step
     *            the current step-id
     * @return the map as a xml-document
     */
    public synchronized Document getNewMapDoc(int step)
    {
        // Create new Document
        Document result;
        try
        {
            result = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();

            // Add root node "map"
            Element root = result.createElement("map");
            root.setAttribute("step", String.valueOf(step));
            root.setAttribute("simID", String.valueOf(_simID));
            result.appendChild(root);

            // Add the cells
            for (int i = 0; i < _map.length; i++)
            {
                for (int j = 0; j < _map[i].length; j++)
                {
                    Element cell = result.createElement("cell");
                    cell.setAttribute("x", String.valueOf(i));
                    cell.setAttribute("y", String.valueOf(j));

                    _map[i][j].appendXML(cell);

                    root.appendChild(cell);
                }
            }

            return result;

        }
        catch (ParserConfigurationException e)
        {
            return null;
        }
    }

    /**
     * Method which updates the cow list.
     * 
     * @param x
     *            x coordinate of the cow encountered
     * @param y
     *            y coordinate of the cow encountered
     * @param id
     *            unique id of the cow encountered
     * @param seen
     *            step the cow has been seen
     */
    public void handleCow(int x, int y, String id, int seen)
    {
        Cow seenCow = new Cow();
        MapCoordinate coordinate = new MapCoordinate(x, y);

        if (_cowList.containsKey(id))
        {
            seenCow = _cowList.remove(id);
            MapCoordinate oc = seenCow.getCoordinate();
            MapCoordinate cc = new MapCoordinate(x, y);

            if (oc.isOnMap(_map) && (!(oc.equals(cc))))
            {
                MapField oldField = _map[oc.getX()][oc.getY()];

                String oldId = String.valueOf(oldField.get_objectID());

                if (oldId.equals(id))
                {
                    oldField.set_object(MapFieldObject.none);
                }
            }

        }

        seenCow.setId(id);
        seenCow.setCoordinate(coordinate);
        seenCow.setLastSeen(seen);
        _cowList.put(id, seenCow);

    }

    /**
     * Get a cow from the list
     * 
     * @param id
     *            cow id
     * @return cow element with id = id
     */
    public Cow getCow(String id)
    {
        if (_cowList.containsKey(id))
        {
            return _cowList.get(id);
        }
        else
        {
            // System.err.println("Cow " + id + " not in list. listsize:" + _cowList.size());
        }
        return null;
    }

    /**
     * Method to get all cows.
     * 
     * @return Map of Cows, format is Map<CowId, Cow>
     */
    public Map<String, Cow> getCowList()
    {
        return _cowList;
    }

    /**
     * Generates an answer message, if a agent will know the position of a
     * fence.
     * 
     * @param newMessage
     * @return the fence reply message
     */
    public ComMessageMapFenceReply fenceRequest(ComMessageMapFenceRequest newMessage, String sender)
    {
        MapCoordinate fenceCoord = newMessage.getFenceCoord();

        ComMessageMapFenceReply reply = new ComMessageMapFenceReply(sender);

        reply.addReceiverAgent(newMessage.getSenderName());

        MapCoordinate pTestCoord = fenceCoord;
        MapCoordinate nTestCoord = fenceCoord;

        boolean noFencep = false;
        boolean noFencen = false;

        MapCoordinate pCoord = null;
        MapCoordinate nCoord = null;

        Direction dir = Direction.unknown;

        // find x or y direction
        if (isFence(_map, fenceCoord.add(new MapCoordinate(1, 0)))
                || isFence(_map, fenceCoord.add(new MapCoordinate(-1, 0))))
        {
            dir = Direction.inX;
            pCoord = new MapCoordinate(1, 0);
            nCoord = new MapCoordinate(-1, 0);
        }
        else if (isFence(_map, fenceCoord.add(new MapCoordinate(0, 1)))
                || isFence(_map, fenceCoord.add(new MapCoordinate(0, -1))))
        {
            dir = Direction.inY;
            pCoord = new MapCoordinate(0, 1);
            nCoord = new MapCoordinate(0, -1);
        }
        else
        {
            reply.addOpenEnd(fenceCoord);
        }

        if (dir != Direction.unknown && pCoord != null && nCoord != null)
        {

            for (int i = 1; i < Math.max(_map.length, _map[0].length); i++)
            {

                if (!noFencep)
                {
                    pTestCoord = pTestCoord.add(pCoord);
                    if (isFenceSwitch(_map, pTestCoord))
                    {
                        reply.addSwitch(pTestCoord);
                        noFencep = true;
                    }
                    else if (isUnknown(_map, pTestCoord))
                    {
                        reply.addOpenEnd(pTestCoord.subtract(pCoord));
                        noFencep = true;
                    }
                    else if (!isFence(_map, pTestCoord))
                    {
                        reply.addClosedEnd(pTestCoord.subtract(pCoord));
                        noFencep = true;
                    }
                }

                if (!noFencen)
                {
                    nTestCoord = nTestCoord.add(nCoord);
                    if (isFenceSwitch(_map, nTestCoord))
                    {
                        reply.addSwitch(nTestCoord);
                        noFencen = true;
                    }
                    else if (isUnknown(_map, nTestCoord))
                    {
                        reply.addOpenEnd(nTestCoord.subtract(nCoord));
                        noFencen = true;
                    }
                    else if (!isFence(_map, nTestCoord))
                    {
                        reply.addClosedEnd(nTestCoord.subtract(nCoord));
                        noFencen = true;
                    }
                }
            }

        }
        return reply;
    }

    /**
     * Checks if the given coordinate is a fenceswitch on the given map.
     * 
     * @param map
     *            the map
     * @param coord
     *            the coordinate to check
     * @return true if the coordinate is a fenceswitch
     */
    private boolean isFenceSwitch(IMapField[][] map, MapCoordinate coord)
    {
        if (coord.isOnMap(map))
        {
            if (map[coord.getX()][coord.getY()].get_ground() == MapFieldGround.fenceswitch)
            {
                return true;
            }
        }
        return false;
    }

    /**
     * Checks if the given coordinate is a fence on the given map.
     * 
     * @param map
     *            the map
     * @param coord
     *            the coordinate to check
     * @return true if the coordinate is a fence
     */
    private boolean isFence(IMapField[][] map, MapCoordinate coord)
    {
        if (coord.isOnMap(map))
        {
            if (map[coord.getX()][coord.getY()].get_ground() == MapFieldGround.fenceopen
                    || map[coord.getX()][coord.getY()].get_ground() == MapFieldGround.fenceclosed)
            {
                return true;
            }
        }
        return false;
    }

    /**
     * Checks if the given coordinate is a unknown field on the given map.
     * 
     * @param map
     *            the map
     * @param coord
     *            the coordinate to check
     * @return true if the coordinate is a unknown field
     */
    private boolean isUnknown(MapField[][] map, MapCoordinate coord)
    {
        if (coord.isOnMap(map))
        {
            if (map[coord.getX()][coord.getY()].get_lastSeen() <= 0)
            {
                return true;
            }
        }
        return false;
    }

    /**
     * @param map
     *            the map as an array of MapFields
     */
    public void set_map(MapField[][] map)
    {
        _map = map;
    }

    /**
     * @param cowList
     *            the list of cows
     */
    public void set_cowList(Map<String, Cow> cowList)
    {
        _cowList = cowList;
    }

    /**
     * @return the corralBorder {topy, rightx, bottomy, leftx}
     */
    public int[] getCorralBorder()
    {
        return corralBorder;
    }

    /**
     * Handles the targetPositionRequest. This method is called, if the MapAgent
     * get a message form an Agent, to calculate the best targets for a group of
     * Agents.
     * 
     * @param newMessage
     *            the incoming MapTargetPositionRequest message
     * @param sender
     *            the sender of the message
     * @return the new generatet replay for the agents.
     */
    public ComMessageMapTargetPositionsReply targetPositionRequest(ComMessageMapTargetPositionsRequest newMessage,
            String sender)
    {
        // create the map with the positions of the agents
        List<String> agents = newMessage.getAgentNames();
        Map<String, MapCoordinate> agentsPos = new HashMap<String, MapCoordinate>();

        //String out = "Map received: ";
        for (String agent : agents)
        {
            agentsPos.put(agent, _agentPos.get(agent));
        //    out += agent + _agentPos.get(agent) + " ";
        }
        //System.out.println(out);

        MapCoordinate waypoint = newMessage.getWaypoint();
        System.out.println("Map received: wp" + waypoint);

        MapFenceCalculation calc = new MapFenceCalculation(_map, agentsPos, waypoint);

        Map<String, MapCoordinate> agentTargetPositions = calc.calculateWithFencePath();

        List<MapCoordinate> ignoredList = calc.getIgnoredList();

//        out = "Map reply: ";
//        for (Entry<String, MapCoordinate> entry : agentTargetPositions.entrySet())
//        {
//            out += entry.getKey() + entry.getValue() + " ";
//        }
//        System.out.println(out);

        ComMessageMapTargetPositionsReply reply = new ComMessageMapTargetPositionsReply(sender);

        reply.addAgentsPos(agentTargetPositions);
        reply.addIgnoreList(ignoredList);

        return reply;
    }

}
