package ch.bfh.massim.framework.mapagent;

/**
 * All possible states of the movable objects on the map.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public enum MapFieldObject
{
    cow, agent, enemyagent, unknown, none
}
