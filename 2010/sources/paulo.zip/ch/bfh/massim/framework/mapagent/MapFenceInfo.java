package ch.bfh.massim.framework.mapagent;

import java.util.HashMap;
import java.util.Map;

import ch.bfh.massim.framework.IMapField;
import ch.bfh.massim.framework.MapCoordinate;
import ch.bfh.massim.framework.mapagent.MapFieldGround;

/**
 * This Class represents a Fence. It contains all the important information
 * about a fence.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class MapFenceInfo
{
    /**
     * This enum is used to identify the direction of the fence. If it is in x
     * or y direction.
     * 
     * @author Christian Loosli & Adrian Pauli
     * 
     */
    public enum direction
    {
        inX, inY, unknown
    }

    private direction dir = direction.unknown;
    private MapCoordinate switchcoord;
    private MapCoordinate endPoint;
    private MapCoordinate startPoint;
    private MapCoordinate leaderSideCoord;
    private MapCoordinate otherSideCoord;
    private boolean isOpen;
    private MapCoordinate agentpos;

    /**
     * Map with all the agents before the fence.
     */
    public Map<String, MapCoordinate> _agentBefore = new HashMap<String, MapCoordinate>();
    /**
     * Map with all the agents after the fence.
     */
    public Map<String, MapCoordinate> _agentAfter = new HashMap<String, MapCoordinate>();

    /**
     * Creates a new instance.
     * 
     * @param map
     *            the map, the fence is on
     * @param fenceCoord
     *            must be a fence field. this is not checked in the method.
     */
    public MapFenceInfo(IMapField[][] map, MapCoordinate fenceCoord, MapCoordinate leaderPos)
    {

        agentpos = leaderPos;

        // set the openstatus
        if (fenceCoord.isOnMap(map))
        {
            if (map[fenceCoord.getX()][fenceCoord.getY()].get_ground() == MapFieldGround.fenceopen)
            {
                isOpen = true;
            }
            else
            {
                isOpen = false;
            }
        }

        findFenceMainPoints(map, fenceCoord);

        if (switchcoord != null)
        {
            findFenceOpenPoints(map, fenceCoord, leaderPos);
        }

        // throw new NotImplementedException();
    }

    /**
     * Checks, if to fenceInfos contains information about the same fence.
     * 
     * @param fenceInfo
     *            the other fenceInfo
     * @return true, if both are the same fence
     */
    public boolean isSameFence(MapFenceInfo fenceInfo)
    {
        if (switchcoord != null && fenceInfo.switchcoord != null)
        {
            return switchcoord.equals(fenceInfo.switchcoord);
        }
        else if (dir == fenceInfo.dir)
        {
            if (dir == direction.inX)
            {
                if (startPoint.getX() == fenceInfo.startPoint.getX())
                {
                    return true;
                }
                else if (startPoint.getY() == fenceInfo.startPoint.getY())
                {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Finds the mainPoints of the fence, like the switch or the ends.
     * 
     * @param map
     *            the map
     * @param fenceCoord
     *            a fence coordinate
     */
    private void findFenceMainPoints(IMapField[][] map, MapCoordinate fenceCoord)
    {
        MapCoordinate testCoord;

        boolean noFencexp = false;
        boolean noFencexn = false;
        boolean noFenceyp = false;
        boolean noFenceyn = false;

        MapCoordinate pCoord = fenceCoord;
        MapCoordinate nCoord = fenceCoord;

        boolean pIsStart = false;

        for (int i = 1; i < Math.max(map.length, map[0].length); i++)
        {

            if (!noFencexp)
            {
                testCoord = fenceCoord.add(new MapCoordinate(i, 0));

                if (isFenceSwitchOrUnknown(map, testCoord, switchcoord != null))
                {
                    pIsStart = true;
                    this.switchcoord = testCoord;
                }

                if (!isFence(map, testCoord))
                {
                    noFencexp = true;
                }
                else
                {
                    dir = direction.inX;
                    pCoord = testCoord;
                }
            }

            if (!noFencexn)
            {
                testCoord = fenceCoord.add(new MapCoordinate(-i, 0));
                if (isFenceSwitchOrUnknown(map, testCoord, switchcoord != null))
                {
                    pIsStart = false;
                    this.switchcoord = testCoord;
                }

                if (!isFence(map, testCoord))
                {
                    noFencexn = true;
                }
                else
                {
                    dir = direction.inX;
                    nCoord = testCoord;
                }
            }

            if (!noFenceyp)
            {
                testCoord = fenceCoord.add(new MapCoordinate(0, i));
                if (isFenceSwitchOrUnknown(map, testCoord, switchcoord != null))
                {
                    pIsStart = true;
                    this.switchcoord = testCoord;
                }
                if (!isFence(map, testCoord))
                {
                    noFenceyp = true;
                }
                else
                {
                    dir = direction.inY;
                    pCoord = testCoord;
                }
            }

            if (!noFenceyn)
            {
                testCoord = fenceCoord.add(new MapCoordinate(0, -i));
                if (isFenceSwitchOrUnknown(map, testCoord, switchcoord != null))
                {
                    pIsStart = false;
                    this.switchcoord = testCoord;
                }
                if (!isFence(map, testCoord))
                {
                    noFenceyn = true;
                }
                else
                {
                    dir = direction.inY;
                    nCoord = testCoord;
                }
            }

        }

        if (switchcoord != null)
        {
            if (pIsStart)
            {
                this.startPoint = pCoord;
                this.endPoint = nCoord;
                // this.fixedStartPoint = true;
            }
            else
            {
                this.startPoint = nCoord;
                this.endPoint = pCoord;
                // this.fixedStartPoint = true;
            }
        }
        else
        {
            if (dir == direction.inX)
            {
                if (pCoord.getX() == map.length - 1)
                {
                    this.startPoint = pCoord;
                    this.endPoint = nCoord;
                    if (endPoint.getX() > 0)
                    {
                        // fixedEndPoint = true;
                    }
                }
                else
                {
                    this.startPoint = nCoord;
                    this.endPoint = pCoord;
                    // fixedEndPoint = true;
                }
            }
            else if (dir == direction.inY)
            {
                if (pCoord.getY() == map[0].length - 1)
                {
                    this.startPoint = pCoord;
                    this.endPoint = nCoord;
                    if (endPoint.getY() > 0)
                    {
                        // fixedEndPoint = true;
                    }
                }
                else
                {
                    this.startPoint = nCoord;
                    this.endPoint = pCoord;
                    // fixedEndPoint = true;
                }
            }

        }
    }

    /**
     * Checks, if the coordinate is a switch, or a unknown field.
     * 
     * @param map
     *            the map
     * @param coord
     *            the coordinate
     * @param switchfound
     *            true, if already a switch has been found
     * @return true, if its unknown or switch
     */
    public boolean isFenceSwitchOrUnknown(IMapField[][] map, MapCoordinate coord, boolean switchfound)
    {
        if (coord.isOnMap(map))
        {
            if (map[coord.getX()][coord.getY()].get_ground() == MapFieldGround.fenceswitch)
            {
                return true;
            }
            if (map[coord.getX()][coord.getY()].get_ground() == MapFieldGround.unknown && !switchfound)
            {
                return true;
            }
        }
        return false;
    }

    /**
     * Checks, if the coordinate is on the fence.
     * 
     * @param map
     *            the map
     * @param coord
     *            the coordinate
     * @return true, if the coordinate is on the fence.
     */
    public boolean isFence(IMapField[][] map, MapCoordinate coord)
    {
        if (coord.isOnMap(map))
        {
            if (map[coord.getX()][coord.getY()].get_ground() == MapFieldGround.fenceopen
                    || map[coord.getX()][coord.getY()].get_ground() == MapFieldGround.fenceclosed)
            {
                return true;
            }
        }
        return false;
    }

    /**
     * Finds the position to use the switch of the fence
     * 
     * @param map
     *            the map
     * @param fence
     *            a fence coordinate
     * @param agentPos
     *            the position of the agent, which will use the switch.
     */
    private void findFenceOpenPoints(IMapField[][] map, MapCoordinate fence, MapCoordinate agentPos)
    {

        if (switchcoord.getX() == fence.getX())
        {
            if (agentPos.getX() < switchcoord.getX())
            {
                leaderSideCoord = new MapCoordinate(switchcoord.getX() - 1, switchcoord.getY());
                otherSideCoord = new MapCoordinate(switchcoord.getX() + 1, switchcoord.getY());

            }
            else
            {
                leaderSideCoord = new MapCoordinate(switchcoord.getX() + 1, switchcoord.getY());
                otherSideCoord = new MapCoordinate(switchcoord.getX() - 1, switchcoord.getY());
            }
        }
        else
        {

            if (agentPos.getY() < switchcoord.getY())
            {
                leaderSideCoord = new MapCoordinate(switchcoord.getX(), switchcoord.getY() - 1);
                otherSideCoord = new MapCoordinate(switchcoord.getX(), switchcoord.getY() + 1);
            }
            else
            {
                leaderSideCoord = new MapCoordinate(switchcoord.getX(), switchcoord.getY() + 1);
                otherSideCoord = new MapCoordinate(switchcoord.getX(), switchcoord.getY() - 1);
            }

        }
    }

    /**
     * Used to calculate the position before the switch.
     * 
     * @return coordinate to add to the switch to get the coordinate before the
     *         switch
     */
    public MapCoordinate getBeforCorrection()
    {
        if (dir == direction.inX)
        {
            if (startPoint.getY() > agentpos.getY())
            {
                return new MapCoordinate(0, 1);
            }
            else
            {
                return new MapCoordinate(0, -1);
            }
        }
        else
        {
            if (startPoint.getX() > agentpos.getX())
            {
                return new MapCoordinate(1, 0);
            }
            else
            {
                return new MapCoordinate(-1, 0);
            }
        }
    }

    /**
     * Checks if its on the fence
     * 
     * @param localmp
     *            the coordinate
     * @return true if the coordinate is on the fence.
     */
    public boolean isOnFence(MapCoordinate localmp)
    {
        if (dir == direction.inX)
        {
            if (startPoint.getY() == localmp.getY())
            {
                return true;
            }
        }
        else
        {
            if (startPoint.getX() == localmp.getX())
            {
                return true;
            }
        }
        return false;
    }

    /**
     * @return the direction
     */
    public direction getDir()
    {
        return dir;
    }

    /**
     * @return the switch coordinate
     */
    public MapCoordinate getSwitchcoord()
    {
        return switchcoord;
    }

    /**
     * @return the endPoint
     */
    public MapCoordinate getEndPoint()
    {
        return endPoint;
    }

    /**
     * @return the startPoint
     */
    public MapCoordinate getStartPoint()
    {
        return startPoint;
    }

    /**
     * @return the leaderSideCoord
     */
    public MapCoordinate getLeaderSideCoord()
    {
        return leaderSideCoord;
    }

    /**
     * @return the otherSideCoord
     */
    public MapCoordinate getOtherSideCoord()
    {
        return otherSideCoord;
    }

    /**
     * @return if the fence is open
     */
    public boolean isOpen()
    {
        return isOpen;
    }

    /**
     * Gets the correction for the coordinate before the switch. Its used to add
     * it to the ignorelist.
     * 
     * @param switchcoord
     *            the coordinate of the switch
     * @return the coordinate to add to the switchcoordinate.
     */
    public MapCoordinate getStartCoordCorrection(MapCoordinate switchcoord)
    {
        MapCoordinate coord = this.startPoint.subtract(switchcoord);
        if (coord.getX() > 0)
            coord.setX(1);
        if (coord.getX() < 0)
            coord.setX(-1);
        if (coord.getY() > 0)
            coord.setY(1);
        if (coord.getY() < 0)
            coord.setY(-1);
        return coord;
    }
}
