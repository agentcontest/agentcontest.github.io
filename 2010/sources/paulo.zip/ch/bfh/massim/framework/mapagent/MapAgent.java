package ch.bfh.massim.framework.mapagent;

import java.io.File;
import java.io.IOException;

import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;

import ch.bfh.massim.framework.ComClientAgent;
import ch.bfh.massim.framework.commessages.ComMessage;
import ch.bfh.massim.framework.commessages.ComMessageMapCommit;
import ch.bfh.massim.framework.commessages.ComMessageMapFenceReply;
import ch.bfh.massim.framework.commessages.ComMessageMapFenceRequest;
import ch.bfh.massim.framework.commessages.ComMessageMapInit;
import ch.bfh.massim.framework.commessages.ComMessageMapTargetPositionsReply;
import ch.bfh.massim.framework.commessages.ComMessageMapTargetPositionsRequest;

/**
 * The MapAgent receives the local sight of the other agents, and connects them
 * to a global map. The global Map is managed by the MapAgent. It also saves a
 * the map in a xml-log.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class MapAgent extends ComClientAgent
{

    // private MapField[][] _map;
    private MapContainer _map = new MapContainer();
    private int _lastStep = -1;

    /**
     * Creats and starts the MapAgent
     * 
     * @param name
     *            name of the MapAgent
     * @param networkhost
     *            hostaddress of the ComServerAgent
     * @param networkport
     *            port of the ComServerAgent
     */
    public MapAgent(String name, String networkhost, int networkport)
    {
        super(name, networkhost, networkport, "1234", "MapAgent");
    }

    /**
     * @see ch.bfh.massim.framework.ComClientAgent#preThread()
     */
    @Override
    protected void preThread()
    {
        super.preThread();

        // initalizing...
    }

    /**
     * @see ch.bfh.massim.framework.ComClientAgent#agentRun()
     */
    @Override
    protected void agentRun() throws IOException, InterruptedException
    {
        ComMessage message = this.receiveComMessage("Map-Commit");
        while (message != null)
        {
            // System.err.println("MapAgent: " + message.toString());
            processMapCommit(message);

            message = this.receiveComMessage("Map-Commit");
        }

        message = this.receiveComMessage("Map-Init");
        while (message != null)
        {
            // System.err.println("MapAgent: " + message.toString());
            processMapInit(message);

            message = this.receiveComMessage("Map-Init");
        }

        message = this.receiveComMessage("MapFenceRequest");
        while (message != null)
        {
            // System.err.println("MapAgent: " + message.toString());
            processFenceRequest(message);

            message = this.receiveComMessage("MapFenceRequest");
        }

        message = this.receiveComMessage("MapTargetPositionRequest");
        while (message != null)
        {
            // System.err.println("MapAgent: " + message.toString());
            proccesTargetPositionRequest(message);

            message = this.receiveComMessage("MapTargetPositionRequest");
        }

        Thread.sleep(5);

    }

    /**
     * Logs the map into a xml-file on the computer.
     * 
     * @param lastStep
     *            number of the step
     */
    protected void log(int lastStep)
    {
        Document doc = _map.getNewMapDoc(lastStep);

        if (lastStep < 0)
            return;

        try
        {
            // Prepare the DOM document for writing
            Source source = new DOMSource(doc);

            String team = _map.get_ownTeam();
            String simid = _map.get_simID();
            String[] id = simid.split("-");

            String gamename = "gamename";
            String simname = "simname";

            if (id.length >= 2)
            {
                gamename = id[0];
                simname = id[1];
            }

            File folder = new File("logs/" + gamename + "/" + simname + "/" + "map/" + team);

            folder.mkdirs();

            File file = new File("logs/" + gamename + "/" + simname + "/" + "map/" + team + "/" + _lastStep + ".xml");
            try
            {
                file.createNewFile();
            }
            catch (IOException e)
            {
            }

            StreamResult result = new StreamResult(file.toURI().getPath());

            // Write the DOM document to the file
            Transformer xformer = TransformerFactory.newInstance().newTransformer();
            xformer.transform(source, result);
        }
        catch (TransformerConfigurationException e)
        {
        }
        catch (TransformerException e)
        {
        }
    }

    /**
     * Processes the map-init message. this message comes at the beginning of a
     * simulation.
     * 
     * @param message
     *            the message
     */
    private void processMapInit(ComMessage message)
    {
        ComMessageMapInit newMessage = new ComMessageMapInit(message);

        if (newMessage.get_simID() != _map.get_simID())
        {
            _map.init(newMessage);
        }

    }

    /**
     * Processes the map-commit message. this message comes at every step from
     * every agent.
     * 
     * @param message
     *            the incoming message
     */
    protected void processMapCommit(ComMessage message)
    {
        ComMessageMapCommit newMessage = new ComMessageMapCommit(message);
        if (_lastStep != newMessage.get_step())
        {
            log(_lastStep);
            _lastStep = newMessage.get_step();
            // System.err.println(_map.toString());
        }
        _map.update(newMessage);
    }

    /**
     * Handles the FenceRequest Message. It returns a message to the agent,
     * containing information about the asked fence.
     * 
     * @param message
     *            the fencerequest Message
     */
    protected void processFenceRequest(ComMessage message)
    {
        ComMessageMapFenceRequest newMessage = new ComMessageMapFenceRequest(message);

        ComMessageMapFenceReply reply = _map.fenceRequest(newMessage, this._name);

        try
        {
            _comConnection.sendMessage(reply);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * Handles the TargetPositionRequest. Returns a message, containing the
     * optimal position to go for each member of a group.
     * 
     * @param message
     *            the TargetPositionRequest message
     */
    protected void proccesTargetPositionRequest(ComMessage message)
    {
        ComMessageMapTargetPositionsRequest newMessage = new ComMessageMapTargetPositionsRequest(message);

        ComMessageMapTargetPositionsReply reply = _map.targetPositionRequest(newMessage, this._name);
        reply.addReceiverAgent(newMessage.getSenderName());

        try
        {
            _comConnection.sendMessage(reply);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * @return the _map
     */
    public MapContainer get_map()
    {
        return _map;
    }

}