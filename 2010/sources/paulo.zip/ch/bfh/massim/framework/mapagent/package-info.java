/**
 * Contains classes and sub packages which provide the objects and
 * containers needed for a map agent. The map agent provides a shared map 
 * for all agents by collecting the local view of each agent and 
 * merging these views to a big one. 
 */
package ch.bfh.massim.framework.mapagent;