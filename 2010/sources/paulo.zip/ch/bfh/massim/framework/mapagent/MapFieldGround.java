/**
 * 
 */
package ch.bfh.massim.framework.mapagent;

/**
 * All possible states for the map-ground.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public enum MapFieldGround
{
    unknown, empty, obstacle, mycorral, enemycorral, fenceswitch, fenceclosed, fenceopen
}
