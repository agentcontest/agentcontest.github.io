package ch.bfh.massim.framework.mapagent;

import org.w3c.dom.Element;

import ch.bfh.massim.framework.IMapField;

/**
 * Represents a field from the map.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class MapField implements IMapField, Cloneable
{

    private MapFieldGround _ground;
    private MapFieldObject _object;

    private int _lastSeen = -1;
    private int _objectID = -1;

    /**
     * @return the _object
     */
    public MapFieldObject get_object()
    {
        return _object;
    }

    /**
     * @param object
     *            the _object to set
     */
    public void set_object(MapFieldObject object)
    {
        _object = object;
    }

    /**
     * @return the _objectID
     */
    public int get_objectID()
    {
        return _objectID;
    }

    /**
     * @param objectID
     *            the _objectID to set
     */
    public void set_objectID(int objectID)
    {
        _objectID = objectID;
    }

    /**
     * Creates a new field.
     */
    public MapField()
    {
        _ground = MapFieldGround.unknown;
        _object = MapFieldObject.unknown;
    }

    /**
     * @return the _ground
     */
    public MapFieldGround get_ground()
    {
        return _ground;
    }

    /**
     * @param ground
     *            the _ground to set
     */
    public void set_ground(MapFieldGround ground)
    {
        _ground = ground;
    }

    /**
     * @return the _lastSeen
     */
    public int get_lastSeen()
    {
        return _lastSeen;
    }

    /**
     * @param lastSeen
     *            the _lastSeen to set
     */
    public void set_lastSeen(int lastSeen)
    {
        _lastSeen = lastSeen;
    }

    /**
     * Appends the content of the field to a xml-element.
     * 
     * @param cell
     *            xml-element
     */
    public void appendXML(Element cell)
    {
        Element el;
        cell.setAttribute("lastSeen", String.valueOf(_lastSeen));
        if (_object == MapFieldObject.agent)
        {
            el = cell.getOwnerDocument().createElement("agent");
            el.setAttribute("type", "ally");
        }
        else if (_object == MapFieldObject.enemyagent)
        {
            el = cell.getOwnerDocument().createElement("agent");
            el.setAttribute("type", "enemy");
        }
        else if (_object == MapFieldObject.cow)
        {
            el = cell.getOwnerDocument().createElement("cow");
            el.setAttribute("ID", String.valueOf(_objectID));
        }
        else if (_ground == MapFieldGround.empty)
        {
            el = cell.getOwnerDocument().createElement("empty");
        }
        else if (_ground == MapFieldGround.obstacle)
        {
            el = cell.getOwnerDocument().createElement("obstacle");
        }
        else if (_ground == MapFieldGround.fenceswitch)
        {
            el = cell.getOwnerDocument().createElement("switch");
        }
        else if (_ground == MapFieldGround.fenceopen)
        {
            el = cell.getOwnerDocument().createElement("fence");
            el.setAttribute("open", "true");
        }
        else if (_ground == MapFieldGround.fenceclosed)
        {
            el = cell.getOwnerDocument().createElement("fence");
            el.setAttribute("open", "false");
        }
        else if (_ground == MapFieldGround.mycorral)
        {
            el = cell.getOwnerDocument().createElement("corral");
            el.setAttribute("type", "ally");
        }
        else if (_ground == MapFieldGround.enemycorral)
        {
            el = cell.getOwnerDocument().createElement("corral");
            el.setAttribute("type", "enemy");
        }
        else
        {
            el = cell.getOwnerDocument().createElement("unknown");
        }

        cell.appendChild(el);
    }

    /**
     * @see java.lang.Object#clone()
     */
    @Override
    protected Object clone() throws CloneNotSupportedException
    {
        return super.clone();
    }
}
