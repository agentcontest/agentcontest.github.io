package ch.bfh.massim.framework.masmessages;

import java.util.HashMap;
import java.util.Map;

import org.w3c.dom.Element;

import ch.bfh.massim.framework.MapCoordinate;

/**
 * Represents the "action" message.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class MasMessageAction extends MasMessage
{
    private Element _el_action;
    private static Map<Integer, String> dir_point;

    /**
     * Generates a new action-message.
     */
    public MasMessageAction()
    {
        super("action");
        if (dir_point == null)
        {
            createDirPoint();
        }
        _el_action = _xmlDoc.createElement("action");
        _xmlDoc.getDocumentElement().appendChild(_el_action);
    }

    /**
     * Creates the "dir_point" hashmap.
     */
    private void createDirPoint()
    {
        dir_point = new HashMap<Integer, String>();

        dir_point.put(0, "north");
        dir_point.put(1, "northeast");
        dir_point.put(2, "east");
        dir_point.put(3, "southeast");
        dir_point.put(4, "south");
        dir_point.put(5, "southwest");
        dir_point.put(6, "west");
        dir_point.put(7, "northwest");

        dir_point.put(-1, "skip");
    }

    /**
     * Set the move, the agent will make.
     * 
     * @param direction
     *            direction as an integer
     */
    public void setMove(int direction)
    {
        setMove(dir_point.get(direction));
    }

    /**
     * Set the move, the agent will make.
     * 
     * @param direction
     *            as a string
     */
    public void setMove(String direction)
    {
        _el_action.setAttribute("type", direction);
    }

    /**
     * Set the move, the agent will make.
     * 
     * @param coord
     *            a coordinate with the next step (z.b (1,0), (0,1))
     */
    public void setMove(MapCoordinate coord)
    {
        int direction;
        if (coord.getX() == 1 && coord.getY() == 0)
        {
            direction = 2;
        }
        else if (coord.getX() == 1 && coord.getY() == 1)
        {
            direction = 3;
        }
        else if (coord.getX() == 0 && coord.getY() == 1)
        {
            direction = 4;
        }
        else if (coord.getX() == -1 && coord.getY() == 1)
        {
            direction = 5;
        }
        else if (coord.getX() == -1 && coord.getY() == 0)
        {
            direction = 6;
        }
        else if (coord.getX() == -1 && coord.getY() == -1)
        {
            direction = 7;
        }
        else if (coord.getX() == 0 && coord.getY() == -1)
        {
            direction = 0;
        }
        else if (coord.getX() == 1 && coord.getY() == -1)
        {
            direction = 1;
        }
        else
        {
            direction = -1;
        }
        setMove(direction);
    }

    /**
     * Sets the actionID, which has to be taken from the RequestAction-message
     * 
     * @param id
     *            the id of the move
     */
    public void setActionID(int id)
    {
        _el_action.setAttribute("id", String.valueOf(id));
    }
}
