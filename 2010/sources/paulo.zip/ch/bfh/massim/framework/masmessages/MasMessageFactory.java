package ch.bfh.massim.framework.masmessages;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * Used to create the right class for the received messages.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class MasMessageFactory
{
    /**
     * Creates a MasMessages according to the xml-document.
     * 
     * @param xmlDoc
     *            the xml-document
     * @return the MasMessage
     */
    public MasMessage createMessage(Document xmlDoc)
    {
        Element el_root = xmlDoc.getDocumentElement();

        if (el_root == null)
        {
            System.err.println("No document element found");
        }
        if (el_root.getNodeName().equals("message"))
        {

            String type = el_root.getAttribute("type");
            if (type.equals("request-action"))
            {
                return new MasMessageRequestAction(xmlDoc, type);
            }
            else if (type.equals("sim-start"))
            {
                return new MasMessageSimStart(xmlDoc, type);
            }

        }
        else
        {
            System.err.println("Unknown document received");
        }

        return null;
    }

    /**
     * Creates the action-message
     * 
     * @return the message
     */
    public static MasMessageAction createActionMessage()
    {
        return new MasMessageAction();
    }

}
