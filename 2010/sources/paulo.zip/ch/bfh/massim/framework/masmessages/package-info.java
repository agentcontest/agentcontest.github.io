/**
 * Contains classes representing massim messages and the logic needed to create them. 
 */
package ch.bfh.massim.framework.masmessages;