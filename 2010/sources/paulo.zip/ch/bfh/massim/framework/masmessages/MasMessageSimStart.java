/**
 * 
 */
package ch.bfh.massim.framework.masmessages;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Represents the "sim-start"-message form the MASSim-Server.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class MasMessageSimStart extends MasMessage
{

    Element _el_simulation;

    /**
     * Creates the message, given from a xml-document.
     * 
     * @param xmlDoc
     *            the xml-document
     * @param type
     *            type of the message
     */
    public MasMessageSimStart(Document xmlDoc, String type)
    {
        super(xmlDoc, type);
        NodeList nl = xmlDoc.getDocumentElement().getChildNodes();
        for (int i = 0; i < nl.getLength(); i++)
        {
            Node n = nl.item(i);
            if (n.getNodeType() == Element.ELEMENT_NODE && n.getNodeName().equalsIgnoreCase("simulation"))
            {
                _el_simulation = (Element) n;
                break;
            }
        }
    }

    /**
     * Returns the simulation-node from the xml-document
     * 
     * @return the simulation-node
     */
    public Node getSimulationNode()
    {
        return _el_simulation;
    }

}
