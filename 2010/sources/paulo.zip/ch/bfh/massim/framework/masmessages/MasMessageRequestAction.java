/**
 * 
 */
package ch.bfh.massim.framework.masmessages;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import ch.bfh.massim.framework.IMapField;
import ch.bfh.massim.framework.MapCoordinate;

/**
 * Represents the "request-action" from the MASSim-Server.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class MasMessageRequestAction extends MasMessage
{
    private Element _el_perception;
    private IMapField[][] _map;

    /**
     * creates the message from a given xml-document
     * 
     * @param xmlDoc
     *            the xml document (received from the massim-server)
     * @param type
     *            type of the message
     */
    public MasMessageRequestAction(Document xmlDoc, String type)
    {
        super(xmlDoc, type);
        // _el_perception = xmlDoc.get("perception");

        NodeList nl = xmlDoc.getDocumentElement().getChildNodes();
        for (int i = 0; i < nl.getLength(); i++)
        {
            Node n = nl.item(i);
            if (n.getNodeType() == Element.ELEMENT_NODE && n.getNodeName().equalsIgnoreCase("perception"))
            {
                _el_perception = (Element) n;
                break;
            }
        }
    }

    /**
     * Transformation constructor
     * 
     * @param message
     *            the message
     */
    public MasMessageRequestAction(MasMessage message)
    {
        this(message.get_xmldoc(), message.get_type());
    }

    /**
     * Returns the id from the perception tag. is used for the action-message.
     * 
     * @return the id
     */
    public int getPerceptionID()
    {
        return Integer.parseInt(_el_perception.getAttribute("id"));
    }

    /**
     * Returns the perception-node of the xml-document.
     * 
     * @return the perception node
     */
    public Node getPerceptionNode()
    {
        return _el_perception;
    }

    /**
     * Returns the current global position of the agent.
     * 
     * @return position of the agent
     */
    public MapCoordinate getAgentPos()
    {
        Element el_perception = (Element) getPerceptionNode();
        return new MapCoordinate(Integer.parseInt(el_perception.getAttribute("posx")), Integer.parseInt(el_perception
                .getAttribute("posy")));
    }

    /**
     * Returns the map as an array of IMapField.
     * 
     * @return the map as array
     */
    public IMapField[][] getMap()
    {

        if (_map == null)
        {
            _map = new MasMapField[17][17];
            NodeList nl = _el_perception.getChildNodes();
            for (int i = 0; i < nl.getLength(); i++)
            {
                Node n = nl.item(i);
                if (n.getNodeType() == Element.ELEMENT_NODE && n.getNodeName().equalsIgnoreCase("cell"))
                {
                    Element e = (Element) n;
                    int x = Integer.parseInt(e.getAttribute("x")) + 8;
                    int y = Integer.parseInt(e.getAttribute("y")) + 8;
                    NodeList nl2 = e.getChildNodes();
                    for (int j = 0; j < nl2.getLength(); j++)
                    {
                        Node n2 = nl2.item(j);
                        if (n2.getNodeType() == Element.ELEMENT_NODE)
                        {
                            _map[x][y] = new MasMapField(n2);
                        }
                    }
                }
            }
        }

        return _map;
    }
}
