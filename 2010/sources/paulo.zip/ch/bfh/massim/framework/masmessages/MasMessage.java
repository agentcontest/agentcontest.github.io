package ch.bfh.massim.framework.masmessages;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * Mainclass for all the messages coming from the MASSim-Server. All messages
 * from the MASSim-Server is capsuled with this class.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class MasMessage
{

    protected Document _xmlDoc;
    private String _type;

    private static DocumentBuilderFactory documentbuilderfactory;
    private static TransformerFactory transformerfactory;

    /**
     * Creates the static fields if they are not present.
     */
    private MasMessage()
    {
        if (documentbuilderfactory == null)
        {
            documentbuilderfactory = DocumentBuilderFactory.newInstance();
        }
        if (transformerfactory == null)
        {
            transformerfactory = TransformerFactory.newInstance();
        }
    }

    /**
     * Creates a new message to a given type
     * 
     * @param type
     *            type of the message as a string.
     */
    public MasMessage(String type)
    {
        this();
        try
        {
            _xmlDoc = documentbuilderfactory.newDocumentBuilder().newDocument();
        }
        catch (ParserConfigurationException e)
        {
            System.err.println("parser config error");
            e.printStackTrace();
            // System.exit(1);
        }

        Element el_response = _xmlDoc.createElement("message");
        _xmlDoc.appendChild(el_response);
        el_response.setAttribute("type", type);
    }

    /**
     * Creates the message, if there already exists the xml-document of it.
     * 
     * @param xmlDoc
     *            the xml document
     * @param type
     *            the type of the message as a string
     */
    public MasMessage(Document xmlDoc, String type)
    {
        this();
        _xmlDoc = xmlDoc;
        _type = type;
    }

    /**
     * Writes the message in to the outputstream
     * 
     * @param outputstream
     *            adds the Message to this outputstream
     * @throws IOException
     */
    public void sendMessage(OutputStream outputstream) throws IOException
    {
        outputstream.write(getByteMessage());
        outputstream.write(0);
        outputstream.flush();
    }

    /**
     * Creates and returns the XmlDoc as a byte-Array
     * 
     * @return byte array containing the Message
     */
    private byte[] getByteMessage()
    {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        try
        {
            transformerfactory.newTransformer().transform(new DOMSource(_xmlDoc), new StreamResult(buffer));
        }
        catch (TransformerConfigurationException e)
        {
            e.printStackTrace();
        }
        catch (TransformerException e)
        {
            e.printStackTrace();
        }
        return buffer.toByteArray();
    }

    /**
     * Returns the type of the message.
     * 
     * @return the _type
     */
    public String get_type()
    {
        return _type;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        ByteArrayOutputStream temp = new ByteArrayOutputStream();
        try
        {
            transformerfactory.newTransformer().transform(new DOMSource(_xmlDoc), new StreamResult(temp));
        }
        catch (TransformerConfigurationException e)
        {
            e.printStackTrace();
        }
        catch (TransformerException e)
        {
            e.printStackTrace();
        }
        return temp.toString();
    }

    /**
     * Returns the xml tree of the document
     * 
     * @return the xml tree of the document
     */
    public Document get_xmldoc()
    {
        return _xmlDoc;
    }

}
