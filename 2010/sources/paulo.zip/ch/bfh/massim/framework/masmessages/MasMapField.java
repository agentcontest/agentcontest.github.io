package ch.bfh.massim.framework.masmessages;

import org.w3c.dom.Element;
import org.w3c.dom.Node;

import ch.bfh.massim.framework.IMapField;
import ch.bfh.massim.framework.mapagent.MapFieldGround;
import ch.bfh.massim.framework.mapagent.MapFieldObject;

/**
 * This class is used to represent a Mapfield from the map in the
 * MasMessageRequestAction.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class MasMapField implements IMapField
{

    private Node _xmlNode;
    private MapFieldGround _ground;
    private MapFieldObject _object;
    private boolean isParsed = false;

    /**
     * Creates the MapField.
     * 
     * @param contentNode
     *            xml-node representing the field.
     */
    public MasMapField(Node contentNode)
    {
        _xmlNode = contentNode;
    }

    /**
     * 
     * @see ch.bfh.massim.framework.IMapField#get_ground()
     */
    @Override
    public MapFieldGround get_ground()
    {
        if (!isParsed)
        {
            fillFields();
        }
        return _ground;
    }

    /**
     * 
     * @see ch.bfh.massim.framework.IMapField#get_object()
     */
    @Override
    public MapFieldObject get_object()
    {
        if (!isParsed)
        {
            fillFields();
        }
        return _object;
    }

    /**
     * fills the private fields.
     */
    private void fillFields()
    {
        _ground = MapFieldGround.unknown;
        _object = MapFieldObject.none;
        if (_xmlNode.getNodeType() == Element.ELEMENT_NODE)
        {
            if (_xmlNode.getNodeName().equalsIgnoreCase("obstacle"))
            {
                _ground = MapFieldGround.obstacle;
            }
            else if (_xmlNode.getNodeName().equalsIgnoreCase("empty"))
            {
                _ground = MapFieldGround.empty;
                _object = MapFieldObject.none;
            }
            else if (_xmlNode.getNodeName().equalsIgnoreCase("switch"))
            {
                _ground = MapFieldGround.fenceswitch;
            }
            else if (_xmlNode.getNodeName().equalsIgnoreCase("fence"))
            {
                Element elemChild = (Element) _xmlNode;
                String open = elemChild.getAttribute("open");
                if (open.equalsIgnoreCase("true"))
                {
                    _ground = MapFieldGround.fenceopen;
                }
                else if (open.equalsIgnoreCase("false"))
                {
                    _ground = MapFieldGround.fenceclosed;
                }
            }
            else if (_xmlNode.getNodeName().equalsIgnoreCase("corral"))
            {
                Element elemChild = (Element) _xmlNode;
                String type = elemChild.getAttribute("type");
                if (type.equalsIgnoreCase("ally"))
                {
                    _ground = MapFieldGround.mycorral;
                }
                else if (type.equalsIgnoreCase("enemy"))
                {
                    _ground = MapFieldGround.enemycorral;
                }
            }
            else if (_xmlNode.getNodeName().equalsIgnoreCase("agent"))
            {
                Element elemChild = (Element) _xmlNode;
                String type = elemChild.getAttribute("type");
                if (type.equalsIgnoreCase("ally"))
                {
                    _object = MapFieldObject.agent;
                }
                else if (type.equalsIgnoreCase("enemy"))
                {
                    _object = MapFieldObject.enemyagent;
                }
            }
            else if (_xmlNode.getNodeName().equalsIgnoreCase("cow"))
            {
                _object = MapFieldObject.cow;
            }
        }
        isParsed = true;
    }

}
