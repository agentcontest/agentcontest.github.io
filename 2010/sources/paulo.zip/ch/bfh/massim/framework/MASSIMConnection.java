package ch.bfh.massim.framework;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import ch.bfh.massim.framework.masmessages.MasMessage;
import ch.bfh.massim.framework.masmessages.MasMessageFactory;

/**
 * Is used to connect to the MASSim-Server. It can send and receive messages
 * from the MASSim-Server
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class MASSIMConnection
{

    private static Logger log = Logger.getLogger(MASSIMConnection.class);

    private InetSocketAddress socketaddress;
    private Socket socket;

    private InputStream inputstream;
    private OutputStream outputstream;
    protected String username;
    private String password;

    protected DocumentBuilderFactory documentbuilderfactory = DocumentBuilderFactory.newInstance();;
    private TransformerFactory transformerfactory = TransformerFactory.newInstance();;
    private MasMessageFactory masmessagefactory = new MasMessageFactory();

    private static final int CONNECT_TRYS = 15;
    private static final int MILLISEC_BETWEEN_CONNECT = 2000;

    /**
     * Creates the class, and connects to the MASSim-Server
     * 
     * @param networkport
     *            port of the MASSim-Server
     * @param networkhost
     *            hostname of the MASSim-Server
     * @param username
     *            username against the MASSim-Server
     * @param password
     *            password to connect to the MASSim-SErver
     * @throws ConnectionNotEstablishedException
     */
    public MASSIMConnection(int networkport, String networkhost, String username, String password)
            throws ConnectionNotEstablishedException
    {
        super();

        this.username = username;
        this.password = password;

        socket = new Socket();
        socketaddress = new InetSocketAddress(networkhost, networkport);
        int connectcount = 0;
        while (!socket.isConnected() && connectcount < CONNECT_TRYS)
        {
            connectcount++;
            try
            {
                socket.connect(socketaddress);
                inputstream = socket.getInputStream();
                outputstream = socket.getOutputStream();
            }
            catch (IOException e)
            {

                log.info("connect to Massim refused (try " + connectcount + ")");
                try
                {
                    Thread.sleep(MILLISEC_BETWEEN_CONNECT);
                }
                catch (InterruptedException e1)
                {
                    e1.printStackTrace();
                }
            }
        }

        if (!socket.isConnected())
        {
            log.error("Not able to Connect to MASSIMServer!");
            throw new ConnectionNotEstablishedException("MASSIMServer not Responding");
        }
    }

    /**
     * Provides a easy way for the authentication against a server. It must be
     * called before the agent is bind to the server and the outputstream is
     * initialized.
     * 
     * @param username
     *            Username of the actual agent.
     * @param password
     *            Password associated with the username.
     * @throws IOException
     *             When the conection have not been initialized.
     */
    public void sendAuthentication(String username, String password) throws IOException
    {

        try
        {
            Document doc = documentbuilderfactory.newDocumentBuilder().newDocument();
            Element root = doc.createElement("message");
            root.setAttribute("type", "auth-request");
            doc.appendChild(root);

            Element auth = doc.createElement("authentication");
            auth.setAttribute("username", username);
            auth.setAttribute("password", password);
            root.appendChild(auth);

            this.sendDocument(doc);

        }
        catch (ParserConfigurationException e)
        {
            System.err.println("unable to create new document for authentication.");
            e.printStackTrace();
        }
    }

    /**
     * Waits for an authentication response from the server. It must be called
     * after the <code>sendAuthentication</code> method call.
     * 
     * @return true when the authentication hat been succesful, false othercase.
     * @throws IOException
     *             When the conection have not been initialized.
     */
    public boolean receiveAuthenticationResult() throws IOException
    {

        try
        {
            Document doc = receiveDocument();
            Element root = doc.getDocumentElement();
            if (root == null)
                return false;
            if (!root.getAttribute("type").equalsIgnoreCase("auth-response"))
                return false;
            NodeList nl = root.getChildNodes();
            Element authresult = null;
            for (int i = 0; i < nl.getLength(); i++)
            {
                Node n = nl.item(i);
                if (n.getNodeType() == Element.ELEMENT_NODE && n.getNodeName().equalsIgnoreCase("authentication"))
                {
                    authresult = (Element) n;
                    break;
                }
            }
            if (!authresult.getAttribute("result").equalsIgnoreCase("ok"))
                return false;
        }
        catch (SAXException e)
        {
            e.printStackTrace();
            return false;
        }
        catch (ParserConfigurationException e)
        {
            e.printStackTrace();
            return false;
        }

        return true;
    }

    /**
     * Unifies the authentication process. It sends the authentication and then
     * waits for the response from the server.
     * 
     * @return true when the authentication hat been succesful, false othercase.
     * @throws IOException
     *             When the conection have not been initialized.
     * @see #sendAuthentication(String, String) sendAuthentication
     * @see #receiveAuthenticationResult() receiveAuthenticationResult
     */
    public boolean doAuthentication() throws IOException
    {
        sendAuthentication(username, password);
        return receiveAuthenticationResult();
    }

    /**
     * This method manages the reception of a packet from the server. It takes
     * no parameters and suposes the authentication is done and hat succeed. It
     * also writes to stderr the contents of the package.
     * 
     * @return a byte array with the response from the server.
     * @throws IOException
     *             When the conection have not been initialized.
     * @throws SocketClosedException
     */
    public byte[] receivePacket() throws IOException
    {

        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        // inputstream.available()
        int read = inputstream.read();
        while (read != 0)
        {
            if (read == -1)
            {
                // throw new SocketClosedException();
            }
            buffer.write(read);
            read = inputstream.read();
        }
        // String s = "Server -> Agent: AgentName "
        // +this.username+"\n"+buffer.toString();

        // System.err.println(s);
        // synchronized (logger) {
        // logger.log(Level.ALL, s);
        // }

        return buffer.toByteArray();
    }

    /**
     * Receives a packet from the server using the
     * <code>receivePacket<code> method
		 * and converts the received data to a XML Document object.
     * 
     * @return A valid XML Document object.
     * @throws SAXException
     *             When the received data is not wellformed.
     * @throws IOException
     *             When the conection have not been initialized.
     * @throws ParserConfigurationException
     * @throws SocketClosedException
     * @see #receivePacket() receivePacket
     */
    public Document receiveDocument() throws SAXException, IOException, ParserConfigurationException
    {

        byte[] raw = receivePacket();
        Document doc = documentbuilderfactory.newDocumentBuilder().parse(new ByteArrayInputStream(raw));
        return doc;
    }

    /**
     * Receives a packet and creates a MasMessage-Class around it.
     * 
     * @return the received message.
     * @throws SAXException
     * @throws IOException
     * @throws ParserConfigurationException
     */
    public MasMessage receiveMessage() throws SAXException, IOException, ParserConfigurationException
    {
        return masmessagefactory.createMessage(receiveDocument());
    }

    /**
     *Sends an specified XML Document to the server.
     * 
     * @param doc
     *            An XML Document object containing the message to send.
     * @throws IOException
     */
    public void sendDocument(Document doc) throws IOException
    {

        try
        {
            transformerfactory.newTransformer().transform(new DOMSource(doc), new StreamResult(outputstream));

            ByteArrayOutputStream temp = new ByteArrayOutputStream();
            transformerfactory.newTransformer().transform(new DOMSource(doc), new StreamResult(temp));
            // String s = "Agent -> Server:\n" + temp.toString();
            // System.err.println(s);
            // logger.log(Level.ALL,s);
            outputstream.write(0);
            outputstream.flush();
        }
        catch (TransformerConfigurationException e)
        {
            System.err.println("transformer config error");
            e.printStackTrace();
            // System.exit(1);
        }
        catch (TransformerException e)
        {
            System.err.println("transformer error error");
            e.printStackTrace();
            // System.exit(1);
        }
    }

    /**
     * check if there is a message in the "instream"
     * 
     * @return whether the instream is available
     * @throws IOException
     */
    public boolean hasPacket() throws IOException
    {
        return inputstream.available() > 0;
    }

    /**
     * sends the message to the MASSim-Server.
     * 
     * @param message
     *            The Message
     * @throws IOException
     */
    public void sendMessage(MasMessage message) throws IOException
    {
        message.sendMessage(outputstream);
    }
}
