package ch.bfh.massim.framework.cowherd;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Stack;

import ch.bfh.massim.framework.MapCoordinate;
import ch.bfh.massim.framework.mapagent.MapContainer;
import ch.bfh.massim.framework.mapagent.MapField;
import ch.bfh.massim.framework.mapagent.MapFieldGround;
import ch.bfh.massim.framework.mapagent.MapFieldObject;
import ch.bfh.massim.framework.pathfinder.PathFinder;

/**
 * Class to classify cow herds. This class is used so that other classes can
 * create and get a list of available cow herds. his class provides methods to
 * put all cows on a map in herds and classify them.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class HerdClassifier
{

    private static Map<String, HerdClassifier> classifiers = new HashMap<String, HerdClassifier>();
    private boolean[][] _checked;
    private ArrayList<CowHerd> _foundherds;
    private ArrayList<CowHerd> _freeherds;
    private ArrayList<String> _herdids;
    private PathFinder _pf;

    /**
     * Default constructor.
     */
    private HerdClassifier()
    {
        _pf = new PathFinder();
        _pf.setIgnoreagents(true);
        _pf.setIgnorecows(true);
        _pf.setIgnoreunknowncontent(true);
        _pf.setIgnoreunknownground(true);
        _pf.setIgnoreobstacles(false);
        _herdids = new ArrayList<String>();
    }

    /**
     * Method to return the instance for a given team.
     * 
     * @param team
     *            the team which owns this classifier
     * @return the classifier owned by this team, created if none existed before
     */
    public static HerdClassifier getInstance(String team)
    {
        if (classifiers.containsKey(team))
        {
            return (classifiers.get(team));
        }
        else
        {
            HerdClassifier classifier = new HerdClassifier();
            classifiers.put(team, classifier);
            return classifier;
        }
    }

    /**
     * Public exposed method to find and classify herds. Be careful, this method
     * will add the cows to the herds, and therefore changes their herdID.
     * 
     * @param mapc
     *            map container to work on
     * @param depth
     *            search depth (radius of the search cloud)
     * @return a list of found herds
     * 
     * 
     */
    public List<CowHerd> classifyHerds(MapContainer mapc, int depth, int seen, List<String> guidedIDs)
    {
        _foundherds = new ArrayList<CowHerd>();
        _freeherds = new ArrayList<CowHerd>();
        ArrayList<CowHerd> guidedherds = new ArrayList<CowHerd>();
        MapField[][] map = mapc.getMap();

        if (map.length <= 0)
            return _foundherds;

        _checked = new boolean[map.length][map[0].length];

        // Go trough the map and start the search
        // for every cow which has not already been treated.
        for (int i = 0; i < map.length; i++)
        {
            for (int j = 0; j < map[0].length; j++)
            {
                MapField mf = map[i][j];
                if (mf.get_object().equals(MapFieldObject.cow))
                {
                    if (!_checked[i][j])
                    {
                        int diff = mapc.getStep() - mf.get_lastSeen();
                        if (diff <= seen)
                            startSearch(mapc, i, j, depth, seen);
                    }
                }
            }
        }

//        _herdids.clear();
//
//        // Check for herds we already guide
//        for (String id : guidedIDs)
//        {
//            int max = -1;
//            int cur = 0;
//            CowHerd maxh = null;
//
//            for (CowHerd cherd : _foundherds)
//            {
//                cur = cherd.getAmountOfCowsWithID(id);
//                if (cur > max)
//                {
//                    maxh = cherd;
//                    max = cur;
//                }
//            }
//
//            if (maxh != null)
//            {
//                maxh.setAllUniqueID(id);
//                guidedherds.add(maxh);
//                _herdids.add(id);
//                _foundherds.remove(maxh);
//            }
//        }

        _freeherds.addAll(_foundherds);
//        for (CowHerd herd : _freeherds)
//        {
//            if (herd != null)
//                herd.setAllUniqueID("");
//        }

        return guidedherds;
    }

    /**
     * Public exposed method to find and classify herds. Be careful, this method
     * will add the cows to the herds, and therefore change their herdID.
     * 
     * @param mapc
     *            map container to work on
     * @param depth
     *            search depth (radius of the search cloud)
     * @return a list of found herds
     * 
     * 
     */
    public List<CowHerd> classifyHerds(MapContainer mapc, int depth, int seen)
    {
        ArrayList<String> guided = new ArrayList<String>();
        return classifyHerds(mapc, depth, seen, guided);
    }

    /**
     * Helper method to start a depth search from a given coordinate.
     * 
     * @param mapc
     *            map container to work on
     * @param x
     *            x coordinate of first cow
     * @param y
     *            y coordinate of first cow
     * @param depth
     *            search depth
     */
    private void startSearch(MapContainer mapc, int x, int y, int depth, int seen)
    {
        int freefield = 0;
        int cowfield = 0;
        double density = 0;
        boolean InOwnCorral = false;
        boolean freeCow = false;
        boolean InEnemyCorral = false;

        MapField[][] map = mapc.getMap();
        Stack<Cow> cows = new Stack<Cow>();

        ArrayList<Cow> tcows = new ArrayList<Cow>();
        String herdid = "tempid";

        MapField initial = map[x][y];

        String id = String.valueOf(initial.get_objectID());
        Cow cow = mapc.getCow(id);

        // Add our first cow on the stack
        if (cow != null)
            cows.add(cow);

        // Walk through the stack until it is empty
        while (cows.size() > 0)
        {
            Cow current = cows.pop();
            if (current == null)
                continue;

            MapCoordinate coord = current.getCoordinate();

            if (coord == null)
                continue;

            int cy = coord.getY();
            int cx = coord.getX();

            MapField[][] minimap = new MapField[(2 * depth) + 1][(2 * depth) + 1];

            for (int i = cx - depth, mx = 0; i <= cx + depth; i++, mx++)
            {
                for (int j = cy - depth, my = 0; j <= cy + depth; j++, my++)
                {
                    try
                    {
                        MapField mf = map[i][j];
                        minimap[mx][my] = mf;
                    }
                    catch (ArrayIndexOutOfBoundsException e)
                    {
                        continue;
                    }
                }
            }

            // Check in the circle around the found cow for other cows.
            // Add not already treated cows to the stack so they will
            // be handled later
            for (int i = cx - depth, mx = 0; i <= cx + depth; i++, mx++)
            {
                for (int j = cy - depth, my = 0; j <= cy + depth; j++, my++)
                {
                    try
                    {
                        if (_checked[i][j])
                            continue;

                        _checked[i][j] = true;

                        MapField mf = map[i][j];

                        // Check if we found a cow
                        if (mf.get_object().equals(MapFieldObject.cow))
                        {

                            // If this cow is not currently seen, ignore it
                            int diff = mapc.getStep() - mf.get_lastSeen();
                            if (diff > seen)
                                continue;

                            MapCoordinate goal = new MapCoordinate(mx, my);
                            MapCoordinate start = new MapCoordinate(depth, depth);

                            List<MapCoordinate> path = _pf.getPath(minimap, start, goal);

                            // No path between this cow and the center cow?
                            // Ignore it,but probe for it later with another
                            // center cow.
                            if (path == null)
                            {
                                _checked[i][j] = false;
                                continue;
                            }

                            String cid = String.valueOf(mf.get_objectID());
                            Cow ccow = mapc.getCow(cid);
                            if (ccow != null)
                            {
                                if (mf.get_ground().equals(MapFieldGround.empty))
                                {
                                    ccow.setStatus(CowHerdStatus.FREE);
                                    freeCow = true;
                                }

                                if (mf.get_ground().equals(MapFieldGround.mycorral))
                                {
                                    ccow.setStatus(CowHerdStatus.INOWNCORRAL);
                                    InOwnCorral = true;
                                }

                                if (mf.get_ground().equals(MapFieldGround.enemycorral))
                                {
                                    ccow.setStatus(CowHerdStatus.INENEMYCORRAL);
                                    InEnemyCorral = true;
                                }

                                if (!tcows.contains(ccow))
                                {
                                    cows.add(ccow);
                                    cowfield++;
                                }
                            }
                        }
                        else
                            freefield++;
                    }
                    catch (ArrayIndexOutOfBoundsException e)
                    {
                        continue;
                    }
                }
            }
            tcows.add(current);
        }

        // No cows found
        if (tcows.size() == 0)
            return;

        int total = freefield + cowfield;

        if (total > 0)
            density = (double) cowfield / total;

        CowHerd herd = new CowHerd(herdid);

        if (InOwnCorral)
            herd.setStatus(CowHerdStatus.INOWNCORRAL);

        if (InEnemyCorral)
            herd.setStatus(CowHerdStatus.INENEMYCORRAL);

        // overwrite corrals. If at least one cow is not in the corral the herd
        // is not considered to be in a corral.
        if (freeCow)
            herd.setStatus(CowHerdStatus.FREE);

        herd.addCows(tcows);
        herd.setDensity(density);
        _foundherds.add(herd);
    }

    /**
     * @return a list of herds not treated yet.
     */
    public List<CowHerd> getFreeHerds()
    {
        return _freeherds;
    }

    /**
     * 
     * @return the next free unique herd id.
     */
    public String getNextHerdID()
    {
        String herd = "maxint";

        for (int i = 1; i < Integer.MAX_VALUE; i++)
        {
            if (!_herdids.contains("herd" + i))
            {
                return "herd" + i;
            }
        }

        return herd;
    }
}
