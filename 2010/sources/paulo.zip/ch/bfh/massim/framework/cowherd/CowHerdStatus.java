package ch.bfh.massim.framework.cowherd;

/**
 * 
 * Enum to represent a cow herd status Default is FREE, UNKNOWN is for unknown
 * state, Cowboys can set GUIDED, Classifier will set INOWNCORRAL or
 * INENEMYCORRAL.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public enum CowHerdStatus
{
    FREE, UNKNOWN, GUIDED, INOWNCORRAL, INENEMYCORRAL
}
