package ch.bfh.massim.framework.cowherd;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import ch.bfh.massim.framework.MapCoordinate;

/**
 * Class to represent a cow herd. This class is used so that other classes, such
 * as the classifier, can keep track of a given list of cows as a herd. This
 * class provides methods to get and set informations regarding this herd.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class CowHerd
{

    private String _uniqueID;
    private ArrayList<Cow> _cows;
    private Map<String, Integer> _ids;
    private int _width;
    private int _height;
    private double _density;
    private CowHerdStatus _status;

    public CowHerd(String uniqueID)
    {
        _uniqueID = uniqueID;
        _cows = new ArrayList<Cow>();
        _density = 0f;
        _height = 0;
        _width = 0;
        _status = CowHerdStatus.UNKNOWN;
        _ids = new HashMap<String, Integer>();
    }

    /**
     * Add a cow to the list (sets herd id to this herd id).
     * 
     * @param cow
     *            the cow to add
     */
    public void addCow(Cow cow)
    {
        if (_cows.contains(cow))
            _cows.remove(cow);

        String currentid = cow.getHerdid();
        if (currentid == null)
            currentid = "";
        if (_ids.containsKey(currentid))
        {
            Integer amount = _ids.get(currentid);
            amount++;
            _ids.remove(currentid);
            _ids.put(currentid, amount);
        }
        else
        {
            Integer amount = 1;
            _ids.put(currentid, amount);
        }

        _cows.add(cow);
    }

    /**
     * Add cows to the list (does not set the cow herd id to this herd id).
     * 
     * @param cowlist
     *            the cows to add
     */
    public void addCows(List<Cow> cowlist)
    {
        for (Cow ccow : cowlist)
        {
            if (ccow != null)
            {
                addCow(ccow);
            }
        }
    }

    /**
     * Remove a cow from the herd (sets herd id to "").
     * 
     * @param cow
     *            the cow to remove
     */
    public void removeCow(Cow cow)
    {
        if (_cows.contains(cow))
        {
            _cows.remove(cow.getId());

            String currentid = cow.getHerdid();
            if (currentid == null)
                currentid = "";

            if (_ids.containsKey(currentid))
            {
                Integer amount = _ids.get(currentid);
                amount--;
                _ids.remove(currentid);
                _ids.put(currentid, amount);
            }
            else
            {
                Integer amount = 1;
                _ids.put(currentid, amount);
            }

            cow.setHerdid("");
        }
    }

    /**
     * Method to check whether this herd contains a specific cow.
     * 
     * @param cow
     *            cow we check
     * @return whether this cow is in the herd or not
     */
    public boolean containsCow(Cow cow)
    {
        return _cows.contains(cow);
    }

    /**
     * Method to get the weighted center of a herd.
     * 
     * @return weighted center
     */
    public MapCoordinate getWeightedCenter()
    {
        Cow middle = null;
        int mindist = -1;
        int curdist = 0;

        for (int i = 0; i < _cows.size(); i++)
        {
            Cow current = _cows.get(i);
            if (current == null)
                continue;

            MapCoordinate currcoor = current.getCoordinate();

            for (Cow other : _cows)
            {
                MapCoordinate othcoor = other.getCoordinate();
                curdist += currcoor.distance(othcoor);
            }

            if (curdist < mindist || mindist < 0)
            {
                middle = current;
                mindist = curdist;
            }
        }

        if (middle != null)
        {
            MapCoordinate center = middle.getCoordinate();
            return center;
        }

        return null;
    }

    /**
     * Method to get the weighted center of a herd.
     * 
     * @return weighted center
     */
    public MapCoordinate getGeometricCenter()
    {
        int[] boarder = getBorder();
        int midx = (boarder[3] + boarder[1]) / 2;
        int midy = (boarder[2] + boarder[0]) / 2;

        MapCoordinate center = new MapCoordinate(midx, midy);

        return center;

    }

    /**
     * Method to get the maximal euclidian distance from any cow to the center
     * 
     * @return max euclidian distance from a cow to the center
     */
    public double getMaxEuclidianDistanceToGeometricCenter()
    {
        double dist = 0.0;
        MapCoordinate cent = getGeometricCenter();

        for (Cow cow : _cows)
        {
            MapCoordinate cowc = cow.getCoordinate();
            double cdist = cowc.euclidianDistance(cent);

            if (cdist > dist)
                dist = cdist;
        }
        return dist;
    }

    /**
     * Method to get the ends.
     * 
     * @return top, right, down, left boarder coordinate (y,x,y,x)
     */
    public int[] getBorder()
    {
        int minx = -1;
        int maxx = -1;
        int miny = -1;
        int maxy = -1;

        for (Cow ccow : _cows)
        {
            MapCoordinate coor = ccow.getCoordinate();
            int curx = coor.getX();
            int cury = coor.getY();

            if (curx < minx || minx < 0)
            {
                minx = curx;
            }

            if (cury < miny || miny < 0)
            {
                miny = cury;
            }

            if (curx > maxx || maxx < 0)
            {
                maxx = curx;
            }

            if (cury > maxy || maxy < 0)
            {
                maxy = cury;
            }
        }

        int[] ret = { miny, maxx, maxy, minx };

        return ret;

    }

    /**
     * Method to log the herd for reviewGUI.
     * 
     * @param gameid
     *            game ID
     * @param simid
     *            simulation ID
     * @param team
     *            team
     * @param step
     *            current step
     * @param goalID
     *            the ID of the goal, used for the filename
     */
    public void logHerd(String gameid, String simid, String team, int step, int goalID)
    {;
        
        // Create new Document
        Document pathxml;
        try
        {
            pathxml = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();

            // Add root node "herd"
            Element root = pathxml.createElement("herd");
            root.setAttribute("step", String.valueOf(step));
            root.setAttribute("simID", simid);
            pathxml.appendChild(root);

            ArrayList<MapCoordinate> coords = new ArrayList<MapCoordinate>();

            for (Cow cow : _cows)
            {
                coords.add(cow.getCoordinate());
            }

            for (MapCoordinate coord : coords)
            {
                Element cell = pathxml.createElement("cell");
                cell.setAttribute("x", String.valueOf(coord.getX()));
                cell.setAttribute("y", String.valueOf(coord.getY()));
                root.appendChild(cell);
            }

            // Prepare the DOM document for writing
            Source source = new DOMSource(pathxml);

            String foldername = "logs/" + gameid + "/" + simid;
            foldername += "/" + "herd/" + team;
            foldername += "/" + "herd_" + goalID;

            File folder = new File(foldername);

            folder.mkdirs();

            File file = new File(foldername + "/" + step + ".xml");
            try
            {
                file.createNewFile();
            }
            catch (IOException e)
            {
            }

            StreamResult result = new StreamResult(file.toURI().getPath());

            // Write the DOM document to the file
            Transformer xformer = TransformerFactory.newInstance().newTransformer();
            xformer.transform(source, result);
        }
        catch (TransformerConfigurationException e)
        {
        }
        catch (TransformerException e)
        {
        }
        catch (ParserConfigurationException e)
        {

        }
    }

    /**
     * @return the uniqueID
     */
    public String getUniqueID()
    {
        return _uniqueID;
    }

    /**
     * Set the uniqueID
     * 
     * @param uniqueID
     *            uniqueID
     */
    public void setUniqueID(String uniqueID)
    {
        this._uniqueID = uniqueID;
    }

    /**
     * Set the uniqueID for the herd and all cows
     * 
     * @param uniqueID
     *            uniqueID
     */
    public void setAllUniqueID(String uniqueID)
    {
        this._uniqueID = uniqueID;

        for (Cow ccow : _cows)
        {
            ccow.setHerdid(uniqueID);
        }
    }

    public Integer getAmountOfCowsWithID(String id)
    {
        if (_ids.containsKey(id))
        {
            return _ids.get(id);
        }
        else
            return new Integer(0);
    }

    /**
     * Method to get a map of all herd ids reported in this herd
     * 
     * @return a map with <ID, amount> of ids of cows in this herd
     */
    public Map<String, Integer> getIDs()
    {
        return _ids;
    }

    /**
     * @return the cows
     */
    public ArrayList<Cow> getCows()
    {
        return _cows;
    }

    /**
     * @return the width
     */
    public int getWidth()
    {
        return _width;
    }

    /**
     * @return the height
     */
    public int getHeight()
    {
        return _height;
    }

    /**
     * @return the density
     */
    public double getDensity()
    {
        return _density;
    }

    /**
     * @param width
     *            the width to set
     */
    public void setWidth(int width)
    {
        this._width = width;
    }

    /**
     * @param height
     *            the height to set
     */
    public void setHeight(int height)
    {
        this._height = height;
    }

    /**
     * @param density
     *            the density to set
     */
    public void setDensity(double density)
    {
        this._density = density;
    }

    /**
     * 
     * @return the cow herd status
     * @see ch.bfh.massim.framework.cowherd.CowHerdStatus
     */
    public CowHerdStatus getStatus()
    {
        return _status;
    }

    /**
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj == null)
            return false;

        if (obj instanceof CowHerd)
        {
            CowHerd other = (CowHerd) obj;
            return other.getUniqueID().equals(this._uniqueID);
        }
        else
            return false;
    }

    /**
     * Method to set the status for the herd.
     * 
     * @param status
     *            the cow herd status
     * @see ch.bfh.massim.framework.cowherd.CowHerdStatus
     */
    public void setStatus(CowHerdStatus status)
    {
        if (status != null)
            this._status = status;
        else
            this._status = CowHerdStatus.UNKNOWN;
    }

    /**
     * Method to set the status for the herd an all cows in it.
     * 
     * @param status
     *            the cow herd status
     * @see ch.bfh.massim.framework.cowherd.CowHerdStatus
     */
    public void setAllStatus(CowHerdStatus status)
    {
        if (status != null)
        {
            this._status = status;
            for (Cow cow : _cows)
            {
                cow.setStatus(status);
            }
        }
        else
            this._status = CowHerdStatus.UNKNOWN;
    }

    /**
     * Method to convert the herd to a string.
     * 
     * @return herd as a string as uniqueID with size cows and density density
     */
    public String toString()
    {
        String st = "";
        st += _uniqueID;
        st += " with " + _cows.size() + " cows and densitiy " + _density;
        return st;
    }

}
