/**
 * Contains the classes and enums needed for representing and working with cows 
 * and cow herds. Contains the herd classifier. This is shared logic used
 * by many classes
 */
package ch.bfh.massim.framework.cowherd;