package ch.bfh.massim.framework.cowherd;

import ch.bfh.massim.framework.MapCoordinate;

/**
 * Class to represent a cow for a herd. This class is used so that other
 * classes, such as cow herd, can keep track of a given cow as an object. This
 * class provides methods to get and set informations regarding this cow.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class Cow implements Cloneable
{
    private String _uniqueID;
    private MapCoordinate _coordinate;
    private String _herdid;
    private int _lastSeen;
    private CowHerdStatus _status;

    /**
     * Default constructor with id and coordinate.
     * 
     * @param id
     *            cow id (unique)
     * @param coordinate
     *            cow coordinate
     */
    public Cow(String id, MapCoordinate coordinate)
    {
        this._uniqueID = id;
        this._coordinate = coordinate;
        this._status = CowHerdStatus.UNKNOWN;
    }

    /**
     * Default constructor without fields
     */
    public Cow()
    {
        this(null, null);
    }

    /**
     * @return the id (unique)
     */
    public String getId()
    {
        return _uniqueID;
    }

    /**
     * @param id
     *            the unique id to set
     */
    public void setId(String id)
    {
        this._uniqueID = id;
    }

    /**
     * @return the coordinate of the cow
     */
    public MapCoordinate getCoordinate()
    {
        return _coordinate;
    }

    /**
     * @param coordinate
     *            the coordinate of the cow
     */
    public void setCoordinate(MapCoordinate coordinate)
    {
        this._coordinate = coordinate;
    }

    /**
     * @return the herdid
     */
    public String getHerdid()
    {
        return _herdid;
    }

    /**
     * @param herdid
     *            the herdid to set
     */
    public void setHerdid(String herdid)
    {
        this._herdid = herdid;
    }

    /**
     * @return the step the cow has been seen
     */
    public int getLastSeen()
    {
        return _lastSeen;
    }

    /**
     * @param lastSeen
     *            the step the cow has been seen
     */
    public void setLastSeen(int lastSeen)
    {
        this._lastSeen = lastSeen;
    }

    /**
     * @return a clone of this cow
     */
    @Override
    public Object clone() throws CloneNotSupportedException
    {
        Cow clone = (Cow) super.clone();
        clone.setCoordinate(_coordinate.clone());
        return clone;
    }

    /**
     * @return whether two objects are equal
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj instanceof Cow)
        {
            Cow other = (Cow) obj;
            return other._uniqueID.equals(_uniqueID);
        }
        else
            return false;
    }

    /**
     * @return string representation of this cow
     */
    @Override
    public String toString()
    {
        return "cow: id=" + _uniqueID + " coordinate=" + _coordinate.toString() + " herd=" + _herdid;
    }

    /**
     * @return hash code of this cow (actually of the unique id of this cow)
     */
    @Override
    public int hashCode()
    {
        return _uniqueID.hashCode();
    }

    /**
     * @return the status of this cow
     */
    public CowHerdStatus getStatus()
    {
        return _status;
    }

    /**
     * @param status
     *            the status to set
     */
    public void setStatus(CowHerdStatus status)
    {
        this._status = status;
    }

}
