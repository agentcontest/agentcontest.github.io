package ch.bfh.massim.framework;

import ch.bfh.massim.framework.mapagent.MapFieldGround;
import ch.bfh.massim.framework.mapagent.MapFieldObject;

/**
 * Represents a field on the map
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public interface IMapField
{
    /**
     * 
     * @return the object on the field
     */
    public MapFieldObject get_object();

    /**
     * 
     * @return the ground of the field
     */
    public MapFieldGround get_ground();
}
