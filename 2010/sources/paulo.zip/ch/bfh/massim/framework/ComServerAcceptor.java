/**
 * 
 */
package ch.bfh.massim.framework;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.Map;
import java.util.Queue;

import org.apache.log4j.Logger;

import ch.bfh.massim.framework.commessages.ComMessageServerIntern;

/**
 * The purpose of this class is to listen on a networkport and to accept new
 * connection. For each connection, it creates a new Thread
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class ComServerAcceptor extends Thread
{

    private static Logger log = Logger.getLogger(ComServerAcceptor.class);

    private int _port;
    private Map<Integer, ComServerSocketContainer> _socketMap;
    private ServerSocket _serverSocket;
    private Queue<ComMessageServerIntern> _inbox;

    private static final int ACCEPTTIMEOUT = 200;
    private static int _nextID = 0;

    /**
     * 
     * @param port
     *            port to listen at
     * @param socketMap
     *            map to which the new connection are added
     * @param inbox
     *            inbox of the server
     */
    public ComServerAcceptor(int port, Map<Integer, ComServerSocketContainer> socketMap,
            Queue<ComMessageServerIntern> inbox)
    {
        super();
        _port = port;
        _socketMap = socketMap;
        _inbox = inbox;
    }

    /**
     * @see java.lang.Thread#run()
     */
    public void run()
    {
        try
        {
            log.trace("Start Server Thread acceptor");
            _serverSocket = new ServerSocket(_port);
            while (!isInterrupted())
            {
                // Waits on new connections
                _serverSocket.setSoTimeout(ACCEPTTIMEOUT);
                try
                {
                    Socket newSocket = _serverSocket.accept();
                    // create a new container for the Socket, with a unique id
                    int id = getSocketId();
                    ComServerSocketContainer newSocketContainer = new ComServerSocketContainer(newSocket, id, _inbox);
                    _socketMap.put(id, newSocketContainer);

                    new Thread(newSocketContainer).start();
                    // newSocketContainer.run();
                }
                catch (SocketTimeoutException ex)
                {
                    // continue;
                }
            }
            synchronized (_serverSocket)
            {
                for (ComServerSocketContainer socketContainer : _socketMap.values())
                {
                    socketContainer.close();
                }

            }

            _serverSocket.close();
            log.trace("End Server Thread acceptor");
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * Generates new unique ids.
     * 
     * @return new id
     */
    private Integer getSocketId()
    {
        int id = _nextID;
        _nextID++;
        return new Integer(id);
    }

}
