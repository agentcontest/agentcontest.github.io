package ch.bfh.massim.framework;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Queue;

import org.apache.log4j.Logger;

import ch.bfh.massim.framework.commessages.ComMessageServerIntern;

/**
 * For each connection to the server, he creates an instance of this class. It
 * holds the connection an can receives the messages.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class ComServerSocketContainer implements Runnable
{

    private static Logger log = Logger.getLogger(ComServerAcceptor.class);

    private static final int SLEEPTIME = 5;

    private Socket _socket;
    private InputStream _istream;
    private OutputStream _ostream;
    private String _name;
    private int _id;
    private boolean isInterrupted = false;
    private Queue<ComMessageServerIntern> _inbox;

    /**
     * creates the socketcontainer
     * 
     * @param socket
     *            the socket
     * @param id
     *            unique id of the socket
     * @param inbox
     *            the inbox, in which it drops the new messages
     * @throws IOException
     */
    public ComServerSocketContainer(Socket socket, int id, Queue<ComMessageServerIntern> inbox) throws IOException
    {
        _socket = socket;
        _id = id;
        _inbox = inbox;
    }

    /**
     * closes and ends the thread
     * 
     * @throws IOException
     */
    public void close() throws IOException
    {
        this.isInterrupted = true;
    }

    /**
     * sets the name of the agent connected to the socket
     * 
     * @param _name
     *            name of the agent
     */
    public void setAgentName(String _name)
    {
        this._name = _name;
    }

    /**
     * name of the agent connected to the socket
     * 
     * @return name of the agent connected to the socket
     */
    public String getAgentName()
    {
        return _name;
    }

    /**
     * if there is a incoming packet
     * 
     * @return true if it has a packet
     * @throws IOException
     */
    public boolean hasPacket() throws IOException
    {
        return _istream.available() > 0;
    }

    /**
     * Receives a incoming packet
     * 
     * @return the new packet
     * @throws IOException
     */
    public byte[] receivePacket() throws IOException
    {

        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        int read = _istream.read();
        while (read != 0)
        {
            if (read == -1)
            {
                return null;
                // throw new Exception("Socket closed");
            }
            buffer.write(read);
            read = _istream.read();
        }

        return buffer.toByteArray();
    }

    /**
     * sends the message to the connected agent
     * 
     * @param message
     *            the message
     * @throws IOException
     */
    public void sendPackage(byte[] message) throws IOException
    {
        if (!isInterrupted)
        {
            _ostream.write(message);
            _ostream.write(0);
            _ostream.flush();
        }
    }

    /**
     * @see java.lang.Runnable#run()
     */
    @Override
    public void run()
    {
        log.trace("Start Server Thread '" + _name + "' Socket " + _id);
        try
        {
            _istream = _socket.getInputStream();
            _ostream = _socket.getOutputStream();

            while (!isInterrupted)
            {
                if (hasPacket())
                {
                    byte[] packet = receivePacket();
                    if (packet != null)
                    {
                        // System.out.println("SOCKETCONTAINER: Packet not null "
                        // + _id);
                        ComMessageServerIntern message = new ComMessageServerIntern(packet, _id);
                        _inbox.add(message);
                    }
                }
                else
                {
                    try
                    {
                        Thread.sleep(SLEEPTIME);
                    }
                    catch (InterruptedException e)
                    {
                        isInterrupted = true;
                    }
                }
                Thread.yield();
            }

            _istream.close();
            _ostream.close();
            _socket.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        log.trace("End Server Thread '" + _name + "' Socket " + _id);
    }
}
