/**
 * 
 */
package ch.bfh.massim.framework;

/**
 * Exception used by the ComServer
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class ConnectionNotEstablishedException extends Exception
{


    private static final long serialVersionUID = -4405743803114858359L;

    /**
	 * Default constructor
	 */
    public ConnectionNotEstablishedException()
    {
    }

    /**
     * Constructor with message
     * @param message message thrown
     */
    public ConnectionNotEstablishedException(String message)
    {
        super(message);
    }

    /**
     * Constructor with throwable cause
     * @param cause the cause for this exception
     */
    public ConnectionNotEstablishedException(Throwable cause)
    {
        super(cause);
    }

    /**
     * Constructor with message and cause 
     * @param message message thrown
     * @param cause the cause for this exception
     */
    public ConnectionNotEstablishedException(String message, Throwable cause)
    {
        super(message, cause);
    }

}
