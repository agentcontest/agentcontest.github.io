package ch.bfh.massim.framework.planingunit;

/**
 * Represents the agents in the PlaningUnit.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class AgentPlaning
{
    private String _agentName;
    private boolean _isFree = true;

    /**
     * Creates the AgentPlaning
     * 
     * @param agentname
     *            name of the agent
     */
    public AgentPlaning(String agentname)
    {
        _agentName = agentname;
    }

    /**
     * @return if the agent is free.
     */
    public boolean isFree()
    {
        return _isFree;
    }

    /**
     * @param isFree
     *            if the agent is free or not
     */
    public void setFree(boolean isFree)
    {
        _isFree = isFree;
    }

    /**
     * @return the name of the agent
     */
    public String get_agentName()
    {
        return _agentName;
    }

}
