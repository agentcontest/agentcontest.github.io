/**
 * 
 */
package ch.bfh.massim.framework.planingunit;

import ch.bfh.massim.framework.ComClientConnection;

/**
 * Basic implementation for the ICreator.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public abstract class BaseCreator implements ICreator
{

    protected ComClientConnection _con;

    /**
     * @see ch.bfh.massim.framework.planingunit.ICreator#setConnection(ch.bfh.massim.framework.ComClientConnection)
     */
    @Override
    public void setConnection(ComClientConnection con)
    {
        _con = con;
    }

}
