package ch.bfh.massim.framework.planingunit;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.InvalidPropertiesFormatException;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Properties;

import ch.bfh.massim.framework.ComClientAgent;
import ch.bfh.massim.framework.commessages.ComMessage;
import ch.bfh.massim.framework.commessages.ComMessageServerNameListUpdate;
import ch.bfh.massim.framework.mapagent.MapContainer;

/**
 * The planing unit coordinates the agent. It creates and organizes the goals.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class PlaningUnitAgent extends ComClientAgent
{

    private MapContainer _map;
    private List<ICreator> _creators = new ArrayList<ICreator>();
    private List<AgentPlaning> _agents = new ArrayList<AgentPlaning>(20);
    private String _simID = "";

    /**
     * Creates the Planing Unit
     * 
     * @param name
     *            name of the agent
     * @param networkhost
     *            host of the ComServer
     * @param networkport
     *            port of the ComServer
     * @param map
     *            the map from the MapAgent
     */
    public PlaningUnitAgent(String name, String networkhost, int networkport, MapContainer map)
    {
        super(name, networkhost, networkport, "1234", "PlaningUnit");
        _map = map;

        loadCreators();
    }

    /**
     * @see ch.bfh.massim.framework.ComClientAgent#processComNameListUpdate(ch.bfh.massim.framework.commessages.ComMessage)
     */
    @Override
    protected void processComNameListUpdate(ComMessage message)
    {
        ComMessageServerNameListUpdate listMessage = new ComMessageServerNameListUpdate(message);
        List<String> agentlist = listMessage.getAgentList();

        // add new agents
        for (String agentname : agentlist)
        {
            boolean exists = false;
            // seek through existing agents
            for (AgentPlaning agent : _agents)
            {
                if (agent.get_agentName().equals(agentname))
                {
                    exists = true;
                    break;
                }
            }
            // add if not found
            if (!exists)
            {
                if (!agentname.equalsIgnoreCase("MapAgent") && !agentname.equalsIgnoreCase("PlaningUnit"))
                {
                    _agents.add(new AgentPlaning(agentname));
                }
            }
        }

        super.processComNameListUpdate(message);
    }

    /**
     * Loads the creators from the properties file.
     */
    private void loadCreators()
    {
        Properties prop = new Properties();
        FileInputStream fis;
        try
        {
            fis = new FileInputStream("conf/framework/framework_properties.xml");
            prop.loadFromXML(fis);
            // prop.list(System.out);

            String number = prop.getProperty("creatorNumber");
            if (number != null)
            {
                int inumber = Integer.parseInt(number);
                for (int i = 1; i <= inumber; i++)
                {
                    ICreator creator = (ICreator) Class.forName(prop.getProperty("creator" + i)).newInstance();
                    _creators.add(creator);
                    System.out.println("load Creator " + prop.getProperty("creator" + i));
                }
            }

        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (InvalidPropertiesFormatException e)
        {
            e.printStackTrace();
        }
        catch (InstantiationException e)
        {
            e.printStackTrace();
        }
        catch (IllegalAccessException e)
        {
            e.printStackTrace();
        }
        catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * @see ch.bfh.massim.framework.ComClientAgent#preThread()
     */
    @Override
    protected void preThread()
    {
        super.preThread();

        for (ICreator creator : _creators)
        {
            creator.setConnection(this._comConnection);
        }
    }

    /**
     * @see ch.bfh.massim.framework.ComClientAgent#agentRun()
     */
    @Override
    protected void agentRun() throws IOException, InterruptedException
    {

        // System.err.println("***agentrun planingunit*** crators:" +
        // _creators.size());
        if (_map.isInit() && _map.getStep() >= 2)
        {
            try
            {	
                MapContainer mapCopy = _map.clone();
                
                // reset the planing Unit
                if (_simID != mapCopy.get_simID()) {
                	_simID = mapCopy.get_simID();
                	for(AgentPlaning agent : _agents) {
                		agent.setFree(true);
                	}
                    for (ICreator creator : _creators)
                    {
                        creator.clear();
                    }
                }

                PriorityQueue<IGoal> goals = new PriorityQueue<IGoal>(4, new GoalPriorityComperator());

                // calculate and update the Goals
                for (ICreator creator : _creators)
                {
                    creator.calculateGoals(mapCopy, goals);
                }

                // Find free Agents
                List<AgentPlaning> freeAgents = getFreeAgents();

                // System.err.println("***free Agents ***" + freeAgents.size() +
                // "*** free goals" + goals.size());

                // Select the Goals and set the roles to Agents
                assignAgents(goals, freeAgents, mapCopy);

            }
            catch (CloneNotSupportedException e)
            {
                e.printStackTrace();
                // System.exit(1);
            }
        }

        Thread.sleep(500);
    }

    /**
     * Assigns the free agents to the goals
     * 
     * @param goals
     *            goals ordered by their priority
     * @param freeAgents
     *            list of free agents
     * @param map
     *            the map
     */
    private void assignAgents(PriorityQueue<IGoal> goals, List<AgentPlaning> freeAgents, MapContainer map)
    {
        IGoal goal = goals.poll();
        while (goal != null && freeAgents.size() > 0)
        {
            if (!goal.isInProgress() && goal.getAgentNumber() <= freeAgents.size())
            {
                AgentPlaning[] assignedAgents = new AgentPlaning[goal.getAgentNumber()];
                for (int i = 0; i < goal.getAgentNumber(); i++)
                {
                    assignedAgents[i] = freeAgents.remove(0);
                }
                goal.setAgents(assignedAgents, map);
            }
            goal = goals.poll();
        }
    }

    /**
     * @return all the currently free agents.
     */
    private List<AgentPlaning> getFreeAgents()
    {
        List<AgentPlaning> freeAgents = new ArrayList<AgentPlaning>();
        for (AgentPlaning agent : _agents)
        {
            if (agent.isFree())
            {
                freeAgents.add(agent);
            }
        }
        return freeAgents;
    }

}
