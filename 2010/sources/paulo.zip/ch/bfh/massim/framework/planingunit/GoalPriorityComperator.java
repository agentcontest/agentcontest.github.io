package ch.bfh.massim.framework.planingunit;

import java.util.Comparator;

/**
 * Compares the goals by their priority.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class GoalPriorityComperator implements Comparator<IGoal>
{

    /**
     * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
     */
    @Override
    public int compare(IGoal o1, IGoal o2)
    {
        if (o1.getPriority() > o2.getPriority())
        {
            return -1;
        }
        if (o1.getPriority() < o2.getPriority())
        {
            return 1;
        }
        return 0;
    }

}
