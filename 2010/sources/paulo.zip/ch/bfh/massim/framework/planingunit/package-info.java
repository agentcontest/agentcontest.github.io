/**
 * Contains classes used for the planing unit. The planing unit creates 
 * weighted partial goals for the game goals we want to reach in order to play a good game. 
 * It assigns roles and agents to the goals. 
 */
package ch.bfh.massim.framework.planingunit;