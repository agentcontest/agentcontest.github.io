package ch.bfh.massim.framework.planingunit;

import ch.bfh.massim.framework.mapagent.MapContainer;

/**
 * All Goals in the PlaningUnit must implement this interface.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public interface IGoal
{
    /**
     * @return the priority of the goal
     */
    int getPriority();

    /**
     * @return the number of agents the goal needs.
     */
    int getAgentNumber();

    /**
     * Calculate the priority for a given set of Agents. (not used yet)
     * 
     * @param agents
     *            the agents designated for this goal
     * @return priority considering the agents
     */
    int getPriorityWithAgents(AgentPlaning[] agents);

    /**
     * @return if the goal is started.
     */
    boolean isInProgress();

    /**
     * Starts the goal and send the roles to the agent
     * 
     * @param agents
     *            the agents used in this goal
     * @param map
     *            the map we are playing on
     */
    void setAgents(AgentPlaning[] agents, MapContainer map);

    /**
     * releases the Agents set in this goal
     */
    void releaseAgents();
}
