package ch.bfh.massim.framework.planingunit;

import java.util.PriorityQueue;

import ch.bfh.massim.framework.ComClientConnection;
import ch.bfh.massim.framework.mapagent.MapContainer;

/**
 * All Creators in the PlaningUnit have to implement this interface. The
 * Creators can create new Goals.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public interface ICreator
{

    /**
     * Update goals and create new goals. All the goals are insert in the
     * priority queue. The Creator can use the map to determine new goals.
     * 
     * @param map
     *            MapContainer containing the current map.
     * @param goals
     *            PriorityQueue, which keeps all goals sorted by their priority.
     */
    void calculateGoals(MapContainer map, PriorityQueue<IGoal> goals);

    /**
     * Sets the Connection object. It is used for the connection between the
     * goal ant the agents
     * 
     * @param con
     *            ConnectionObject from the Planing Unit.
     */
    void setConnection(ComClientConnection con);

	void clear();
}
