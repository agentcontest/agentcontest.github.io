/**
 * Contains classes and sub packages which provide shared logic used 
 * through the application. Everything that is needed by multiple packages 
 * should be in this package or a subpackage. Mainly shared logic such 
 * as communication logic, path finding logic and herd handling logic. 
 */
package ch.bfh.massim.framework;