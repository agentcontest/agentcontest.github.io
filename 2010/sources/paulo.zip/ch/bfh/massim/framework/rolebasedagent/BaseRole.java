package ch.bfh.massim.framework.rolebasedagent;

import ch.bfh.massim.framework.masmessages.MasMessage;
import ch.bfh.massim.framework.masmessages.MasMessageAction;
import ch.bfh.massim.framework.masmessages.MasMessageRequestAction;

/**
 * This class is implemented, simplify the implementation of the IRole
 * interface.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public abstract class BaseRole implements IRole
{

    protected String _name;
    protected RolebaseAgent _parent;

    /**
     * Creates the role with a name
     * 
     * @param name
     *            the name of the role
     */
    public BaseRole(String name)
    {
        _name = name;
    }

    /**
     * @see ch.bfh.massim.framework.rolebasedagent.IRole#getName()
     */
    @Override
    public String getName()
    {
        return _name;
    }

    /**
     * @see ch.bfh.massim.framework.rolebasedagent.IRole#processRequestAction(ch.bfh.massim.framework.masmessages.MasMessageRequestAction,
     *      ch.bfh.massim.framework.masmessages.MasMessageAction)
     */
    @Override
    public abstract void processRequestAction(MasMessageRequestAction request, MasMessageAction action);

    /**
     * @see ch.bfh.massim.framework.rolebasedagent.IRole#processUnknownMessage(ch.bfh.massim.framework.masmessages.MasMessage)
     */
    @Override
    public void processUnknownMessage(MasMessage message)
    {

    }

    /**
     * @see ch.bfh.massim.framework.rolebasedagent.IRole#setRoleMessage(ch.bfh.massim.framework.rolebasedagent.RoleMessage)
     */
    @Override
    public abstract void setRoleMessage(RoleMessage rm);

    /**
     * @see ch.bfh.massim.framework.rolebasedagent.IRole#setParent(ch.bfh.massim.framework.rolebasedagent.RolebaseAgent)
     */
    @Override
    public void setParent(RolebaseAgent agent)
    {
        _parent = agent;
    }
}
