package ch.bfh.massim.framework.rolebasedagent;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.InvalidPropertiesFormatException;
import java.util.Map;
import java.util.Properties;

import ch.bfh.massim.framework.AbstractCowboyAgent;
import ch.bfh.massim.framework.commessages.ComMessage;
import ch.bfh.massim.framework.commessages.ComMessageMapCommit;
import ch.bfh.massim.framework.commessages.ComMessageMapInit;
import ch.bfh.massim.framework.masmessages.MasMessage;
import ch.bfh.massim.framework.masmessages.MasMessageAction;
import ch.bfh.massim.framework.masmessages.MasMessageRequestAction;
import ch.bfh.massim.framework.masmessages.MasMessageSimStart;

/**
 * The RolebaseAgent is a agent, which can take roles to act. The roles have to
 * implement the IRole Interface.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class RolebaseAgent extends AbstractCowboyAgent
{

    private Map<String, IRole> _roleContainer = new HashMap<String, IRole>();
    private IRole _role;

    /**
     * Creates the Agent
     * 
     * @param name
     *            name of the agent
     * @param ComNetworkhost
     *            host of the ComClientServer
     * @param ComNetworkport
     *            port of the ComClientServer
     * @param MASSIMNetworkhost
     *            host of the MASSim-Server
     * @param MASSIMNetworkport
     *            port of the MASSim-Server
     * @param MASSIMName
     *            name against the MASSim-Server
     * @param MASSIMPwd
     *            password against the MASSim-Server
     */
    public RolebaseAgent(String name, String ComNetworkhost, int ComNetworkport, String MASSIMNetworkhost,
            int MASSIMNetworkport, String MASSIMName, String MASSIMPwd)
    {
        super(name, ComNetworkhost, ComNetworkport, MASSIMNetworkhost, MASSIMNetworkport, MASSIMName, MASSIMPwd);

        IRole drole = new DefaultRole();
        drole.setParent(this);
        _roleContainer.put(drole.getName(), drole);
        _role = drole;
        loadRole();
    }

    /**
     * Loads the roles from the properties file.
     */
    private void loadRole()
    {
        Properties prop = new Properties();
        FileInputStream fis;
        try
        {
            fis = new FileInputStream("conf/framework/framework_properties.xml");
            prop.loadFromXML(fis);
            // prop.list(System.out);

            String number = prop.getProperty("roleNumber");
            if (number != null)
            {
                int inumber = Integer.parseInt(number);
                for (int i = 1; i <= inumber; i++)
                {
                    IRole role = (IRole) Class.forName(prop.getProperty("role" + i)).newInstance();
                    role.setParent(this);
                    _roleContainer.put(role.getName(), role);
                    // System.err.println("load role " + prop.getProperty("role"
                    // + i));
                }
            }

        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (InvalidPropertiesFormatException e)
        {
            e.printStackTrace();
        }
        catch (InstantiationException e)
        {
            e.printStackTrace();
        }
        catch (IllegalAccessException e)
        {
            e.printStackTrace();
        }
        catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

    }

    /**
     * @see ch.bfh.massim.framework.AbstractCowboyAgent#processRequestAction(ch.bfh.massim.framework.masmessages.MasMessageRequestAction,
     *      ch.bfh.massim.framework.masmessages.MasMessageAction)
     */
    @Override
    protected void processRequestAction(MasMessageRequestAction request, MasMessageAction action)
    {
        sendUpdateToMap(request);
        _role.processRequestAction(request, action);
    }

    /**
     * @see ch.bfh.massim.framework.AbstractCowboyAgent#processSimulationEnd(ch.bfh.massim.framework.masmessages.MasMessage)
     */
    @Override
    protected void processSimulationEnd(MasMessage message)
    {

    }

    /**
     * @see ch.bfh.massim.framework.AbstractCowboyAgent#processSimulationStart(ch.bfh.massim.framework.masmessages.MasMessage)
     */
    @Override
    protected void processSimulationStart(MasMessage message)
    {
        sendInitToMap(message);
    }

    /**
     * @see ch.bfh.massim.framework.AbstractCowboyAgent#processUnknownMessage(ch.bfh.massim.framework.masmessages.MasMessage)
     */
    @Override
    protected void processUnknownMessage(MasMessage message)
    {
        _role.processUnknownMessage(message);
    }

    /**
     * @see ch.bfh.massim.framework.AbstractCowboyAgent#preThread()
     */
    @Override
    protected void preThread()
    {
        super.preThread();

    }

    /**
     * @see ch.bfh.massim.framework.AbstractCowboyAgent#agentRun()
     */
    @Override
    public void agentRun() throws IOException, InterruptedException
    {
        ComMessage message = receiveComMessage("role");
        if (message != null)
        {
            RoleMessage rm = new RoleMessage(message);
            String sr = rm.getRole();
            // System.err.println("********** got new role " + sr + " ******");
            if (_roleContainer.containsKey(sr))
            {
                _role = _roleContainer.get(sr);
            }
            else
            {
                _role = _roleContainer.get("default");
                System.err.println("********** role " + sr + " not known ******");
            }
            _role.setRoleMessage(rm);
        }

        super.agentRun();
    }

    /**
     * Sent the map to the MapAgent
     * 
     * @param request
     *            the message from the MASSim-Server
     */
    private void sendUpdateToMap(MasMessage request)
    {
        MasMessageRequestAction requestAction = (MasMessageRequestAction) request;
        ComMessage sendMessage = new ComMessageMapCommit(this._name, requestAction);
        sendMessage.addReceiverAgent("MapAgent");
        try
        {
            if (_comConnection != null)
                _comConnection.sendMessage(sendMessage);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * Sent the initialization to the MapAgent.
     * 
     * @param message
     *            the message from the MASSim-Server
     */
    private void sendInitToMap(MasMessage message)
    {

        MasMessageSimStart simStart = (MasMessageSimStart) message;
        ComMessage sendMessage = new ComMessageMapInit(this._name, simStart);
        sendMessage.addReceiverAgent("MapAgent");
        try
        {
            if (_comConnection != null)
                _comConnection.sendMessage(sendMessage);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}
