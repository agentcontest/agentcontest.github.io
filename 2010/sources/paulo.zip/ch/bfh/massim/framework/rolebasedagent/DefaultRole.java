package ch.bfh.massim.framework.rolebasedagent;

import ch.bfh.massim.framework.masmessages.MasMessageAction;
import ch.bfh.massim.framework.masmessages.MasMessageRequestAction;

/**
 * This role is given to the agent as default. An agent with the default role
 * doesn't move.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class DefaultRole extends BaseRole
{
    /**
     * Creates the default role
     */
    public DefaultRole()
    {
        super("default");
    }

    /**
     * @see ch.bfh.massim.framework.rolebasedagent.BaseRole#processRequestAction(ch.bfh.massim.framework.masmessages.MasMessageRequestAction,
     *      ch.bfh.massim.framework.masmessages.MasMessageAction)
     */
    @Override
    public void processRequestAction(MasMessageRequestAction request, MasMessageAction action)
    {
        action.setMove(-1);
    }

    /**
     * @see ch.bfh.massim.framework.rolebasedagent.BaseRole#setRoleMessage(ch.bfh.massim.framework.rolebasedagent.RoleMessage)
     */
    @Override
    public void setRoleMessage(RoleMessage rm)
    {
        // do nothing - not used
    }
}
