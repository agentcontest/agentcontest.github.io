/**
 * Contains classes needed to handle roles. 
 */
package ch.bfh.massim.framework.rolebasedagent;