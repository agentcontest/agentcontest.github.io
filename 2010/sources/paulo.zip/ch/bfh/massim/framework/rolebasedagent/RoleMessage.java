package ch.bfh.massim.framework.rolebasedagent;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import ch.bfh.massim.framework.commessages.ComMessage;

/**
 * This class is used, to send a message to a agent, to give him a role.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class RoleMessage extends ComMessage
{

    private String _role = "";
    protected Element _el_role;

    /**
     * Creates the message.
     * 
     * @param role
     *            the name of the role
     * @param sendername
     *            the name of the sender
     * @param receiver
     *            the name of the receiver
     */
    public RoleMessage(String role, String sendername, String receiver)
    {
        super(sendername, "role");
        _role = role;
        addReceiverAgent(receiver);
        Element messagebody = this.get_bodyElement();
        _el_role = messagebody.getOwnerDocument().createElement("role");
        _el_role.setAttribute("type", role);
        messagebody.appendChild(_el_role);
    }

    /**
     * Creates the message
     * 
     * @param role
     *            the name of the role
     * @param sendername
     *            the name of the sender
     */
    public RoleMessage(String role, String sendername)
    {
        super(sendername, "role");
        _role = role;
        // addReceiverAgent(receiver);
        Element messagebody = this.get_bodyElement();
        _el_role = messagebody.getOwnerDocument().createElement("role");
        _el_role.setAttribute("type", role);
        messagebody.appendChild(_el_role);
    }

    /**
     * Transformation Constructor
     * 
     * @param message
     *            the message to cast
     */
    public RoleMessage(ComMessage message)
    {
        super(message.get_message());

        NodeList nl = get_bodyElement().getChildNodes();
        for (int i = 0; i < nl.getLength(); i++)
        {
            Node n = nl.item(i);
            if (n.getNodeType() == Element.ELEMENT_NODE && n.getNodeName().equalsIgnoreCase("role"))
            {
                _el_role = (Element) n;
                break;
            }
        }
    }

    /**
     * 
     * @return name of the role
     */
    public String getRole()
    {
        if (_role.length() == 0)
        {
            if (_el_role != null)
            {
                _role = _el_role.getAttribute("type");
            }
        }
        return _role;
    }
}
