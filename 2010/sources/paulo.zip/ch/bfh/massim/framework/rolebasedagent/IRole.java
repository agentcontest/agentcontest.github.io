package ch.bfh.massim.framework.rolebasedagent;

import ch.bfh.massim.framework.masmessages.MasMessage;
import ch.bfh.massim.framework.masmessages.MasMessageAction;
import ch.bfh.massim.framework.masmessages.MasMessageRequestAction;

/**
 * To define a role for the agents, this interface must be implemented. The
 * roles also have to be written in the properties file
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public interface IRole
{
    /**
     * 
     * @return the unique name of the role.
     */
    public String getName();

    /**
     * The method is called, when the agent gets the ActionReqeust from the
     * MASSim-Server
     * 
     * @param request
     *            the ActionRequest
     * @param action
     *            the reply. The method has to add the direction to this object.
     */
    public void processRequestAction(MasMessageRequestAction request, MasMessageAction action);

    /**
     * Is called if an unknown messagetype arrives.
     * 
     * @param message
     *            the unknown message
     */
    public void processUnknownMessage(MasMessage message);

    /**
     * Give the message, which sets the role to the agent, to the role.
     * 
     * @param rm
     *            the rolemessage
     */
    public void setRoleMessage(RoleMessage rm);

    /**
     * Sets the parent of this role
     * 
     * @param agent
     *            the agent, using this role
     */
    public void setParent(RolebaseAgent agent);
}
