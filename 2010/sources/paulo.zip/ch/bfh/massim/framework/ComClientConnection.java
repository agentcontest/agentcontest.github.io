package ch.bfh.massim.framework;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;

import org.apache.log4j.Logger;

import ch.bfh.massim.framework.commessages.ComMessage;
import ch.bfh.massim.framework.commessages.ComMessageAuthrequest;

/**
 * Represents the connection form a ComClient to the ComServer
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class ComClientConnection
{

    private InetSocketAddress _socketaddress;
    private Socket _socket;

    private static final int CONNECT_TRYS = 15;
    private static final int MILLISEC_BETWEEN_CONNECT = 2000;

    protected InputStream inputstream;
    protected OutputStream outputstream;

    private static Logger log = Logger.getLogger(ComClientConnection.class);

    /**
     * Creates the connection to a ComServer
     * 
     * @param networkport
     *            port of the comServer
     * @param networkhost
     *            hostname of the comServer
     * @throws ConnectionNotEstablishedException
     */
    public ComClientConnection(String networkhost, int networkport) throws ConnectionNotEstablishedException
    {
        super();
        // _networkport = networkport;
        // _networkhost = networkhost;
        log.trace("creating a comConection on '" + networkhost + "' " + networkport);
        _socket = new Socket();
        _socketaddress = new InetSocketAddress(networkhost, networkport);
        int connectcount = 0;
        while (!_socket.isConnected() && connectcount < CONNECT_TRYS)
        {
            connectcount++;
            try
            {
                _socket.connect(_socketaddress);
                inputstream = _socket.getInputStream();
                outputstream = _socket.getOutputStream();
            }
            catch (IOException e)
            {
                log.info("connect to ComClient refused : " + networkhost + ":" + networkport + " (try " + connectcount
                        + ")");
                try
                {
                    Thread.sleep(MILLISEC_BETWEEN_CONNECT);
                }
                catch (InterruptedException e1)
                {
                    e1.printStackTrace();
                }
            }
        }

        if (!_socket.isConnected())
        {
            log.error("Not able to Connect to ComClientServer!");
            throw new ConnectionNotEstablishedException("ComClientServer not Responding");
        }
    }

    /**
     * close the connection
     */
    public void close()
    {
        try
        {
            inputstream.close();
            outputstream.close();
            _socket.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * Sends the authentification to the ComServer
     * 
     * @param username
     *            name of the Client
     * @param password
     *            password *not used jet*
     * @param group
     *            group of the Client *not used jet*
     * @throws IOException
     */
    public void sendAuthentication(String username, String password, String group) throws IOException
    {
        ComMessage message = new ComMessageAuthrequest(username, password, group);
        sendMessage(message);
    }

    /**
     * check if there is a message in the "instream"
     * 
     * @return true if there is a packet
     * @throws IOException
     */
    public boolean hasPacket()
    {

        try
        {
            return inputstream.available() > 0;
        }
        catch (IOException e)
        {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * receives a Message from the Server (blocking)
     * 
     * @return the message received from the server
     * @throws IOException
     */
    public ComMessage receiveMessage() throws IOException
    {
        // log.trace("receive a Message");
        return new ComMessage(receivePacket());
    }

    /**
     * sends a message
     * 
     * @param message
     *            the message to send
     * @throws IOException
     */
    public void sendMessage(ComMessage message) throws IOException
    {
        message.sendMessage(outputstream);
    }

    /**
     * receives the message as a tcp/ip packet (blocking)
     * 
     * @return byte array representation of the message
     * @throws IOException
     */
    public byte[] receivePacket() throws IOException
    {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        int read = inputstream.read();
        while (read != 0)
        {
            if (read == -1)
            {
                return null;
                // throw new Exception("Socket closed");
            }
            buffer.write(read);
            read = inputstream.read();
        }
        return buffer.toByteArray();
    }

}
