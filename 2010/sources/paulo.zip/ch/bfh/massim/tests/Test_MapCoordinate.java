package ch.bfh.massim.tests;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import ch.bfh.massim.framework.MapCoordinate;

/**
 * o Class to test the map coordinate. This class is used so that the common
 * methods on coordinates used by many classes can be tested. This class
 * provides test cases and set up methods.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class Test_MapCoordinate
{

    private static MapCoordinate topLeft;
    private static MapCoordinate bottomRight;
    private static MapCoordinate topRight;
    private static MapCoordinate bottomLeft;
    private static MapCoordinate between;
    private static MapCoordinate center;
    private static MapCoordinate outOfBounds;

    /**
     * Method to set everything up. Instantiates the objects needed for the
     * tests. Will be called before the first test. Creates a big test map with
     * cows and obstacles on it, used for the tests,
     * 
     * @throws Exception
     *             not used and not the case
     */
    @BeforeClass
    public static void setUpClass() throws Exception
    {
        topLeft = new MapCoordinate(0, 0);
        bottomRight = new MapCoordinate(10, 10);
        topRight = new MapCoordinate(10, 0);
        bottomLeft = new MapCoordinate(0, 10);
        between = new MapCoordinate(5, 7);
        center = new MapCoordinate(5, 5);
        outOfBounds = new MapCoordinate(1, 12);
    }

    /**
     * Method to test the basics such as equals and toString
     * 
     * @throws CloneNotSupportedException
     */
    @Test
    public void testBasics() throws CloneNotSupportedException
    {
        // Format is: (x,y)
        assertEquals(topLeft.toString(), "(0,0)");
        assertEquals(bottomRight.toString(), "(10,10)");

        assertFalse(topRight.equals(bottomLeft));
        assertFalse(topRight.equals(null));
        assertFalse(topRight.equals("topRight"));

        MapCoordinate topRightClone = topRight.clone();
        MapCoordinate topRightCopy = new MapCoordinate(topRight);
        MapCoordinate topRightDup = new MapCoordinate(10, 0);

        assertTrue(topRight.equals(topRightClone));
        assertTrue(topRight.equals(topRightCopy));
        assertTrue(topRight.equals(topRightDup));
    }

    /**
     * Method to test for the absolute distance between two coordinates. As
     * diagonal moves are allowed, the distance is measured as min(|x1 - x2|,|y1
     * - y2|)
     */
    @Test
    public void testDistance()
    {
        // left to right: 10
        assertEquals(topLeft.distance(topRight), 10);
        // diagonal over the field: 10
        assertEquals(topLeft.distance(bottomRight), 10);
        // straight down: 10
        assertEquals(topLeft.distance(bottomLeft), 10);
        // 5 diagonal, two vertical = 7
        assertEquals(topLeft.distance(between), 7);
    }

    /**
     * Method to test the euclidian distance between two coordinates. The
     * distance is measured as (x1 - x2)^2 + (y1 - y2)^2
     */
    @Test
    public void testEuclidDistance()
    {
        // left to right: 10
        assertEquals(topLeft.euclidianDistance(topRight), 10, 0);
        // diagonal over the field: ~ 14.14
        assertEquals(topLeft.euclidianDistance(bottomRight), 14.14, 0.1);
        // straight down: 10
        assertEquals(topLeft.euclidianDistance(bottomLeft), 10, 0);
        // diagonal = ~ 8,6
        assertEquals(topLeft.euclidianDistance(between), 8.6, 0.1);
    }

    /**
     * Method to test the calculation of the center of coordinates. As we use
     * the four edges, the center has to be the center of a 0-10x0-10 field,
     * which is 5,5
     */
    @Test
    public void calucateCenter()
    {
        MapCoordinate[] coordinates = { topLeft, bottomRight, topRight, bottomLeft };

        assertEquals(MapCoordinate.calculateCenter(coordinates), center);
    }

    /**
     * Method to test the calculation whether a coordinate is on the map. On a
     * 11x11 (0 - 10) map, all coordinates except outOfBound should be on the
     * map.
     */
    @Test
    public void isOnMap()
    {
        Object[][] map = new Object[11][11];
        assertTrue(center.isOnMap(map));
        assertTrue(topLeft.isOnMap(map));
        assertTrue(bottomLeft.isOnMap(map));
        assertTrue(topRight.isOnMap(map));
        assertTrue(bottomRight.isOnMap(map));
        assertFalse(outOfBounds.isOnMap(map));
    }

    /**
     * Method to test coordinate addition and subtraction
     */
    @Test
    public void testArithmetic()
    {
        MapCoordinate add = topLeft.add(between);
        MapCoordinate sub = bottomRight.subtract(between);

        // 0,0 + 5,7 -> 5,7
        MapCoordinate addition = new MapCoordinate(5, 7);

        // 10,10 - 5,7 -> 5,3
        MapCoordinate subtraction = new MapCoordinate(5, 3);

        assertEquals(sub, subtraction);
        assertEquals(add, addition);
    }
}
