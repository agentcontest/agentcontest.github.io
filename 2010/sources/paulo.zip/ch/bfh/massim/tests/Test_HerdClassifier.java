package ch.bfh.massim.tests;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;

import ch.bfh.massim.framework.MapCoordinate;
import ch.bfh.massim.framework.cowherd.Cow;
import ch.bfh.massim.framework.cowherd.CowHerd;
import ch.bfh.massim.framework.cowherd.CowHerdStatus;
import ch.bfh.massim.framework.cowherd.HerdClassifier;
import ch.bfh.massim.framework.mapagent.MapContainer;
import ch.bfh.massim.framework.mapagent.MapField;
import ch.bfh.massim.framework.mapagent.MapFieldGround;
import ch.bfh.massim.framework.mapagent.MapFieldObject;

/**
 * Class to test the herd classifier. This class is used so classifying herds
 * can be tested. This class provides test cases and set up methods.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class Test_HerdClassifier
{

    private static MapField[][] bigmap;
    private static MapContainer mc;
    private static HerdClassifier classify;
    private static CowHerd herd1;
    private static CowHerd herd2;
    private static CowHerd herd3;
    private static CowHerd herd4;
    private static CowHerd herd5;
    private static CowHerd herd6;
    private static CowHerd herd7;
    private static final int DEPTH = 3;
    private static final int MAXI = 60;
    private static final int MAXJ = 60;

    /**
     * Method to set everything up. Instantiates the objects needed for the
     * tests. Will be called before the first test. Creates a big test map with
     * cows and obstacles on it, used for the tests,
     * 
     * @throws Exception
     *             not used and not the case
     */
    @BeforeClass
    public static void setUpClass() throws Exception
    {
        mc = new MapContainer();
        classify = HerdClassifier.getInstance("A");

        bigmap = new MapField[MAXI][MAXJ];
        HashMap<String, Cow> cows = new HashMap<String, Cow>();

        for (int i = 0; i < MAXI; i++)
        {
            for (int j = 0; j < MAXJ; j++)
            {
                bigmap[i][j] = new MapField();
                if (i == 0 || i == MAXI - 1 || j == 0 || j == MAXJ - 1)
                    bigmap[i][j].set_ground(MapFieldGround.obstacle);
                else
                    bigmap[i][j].set_ground(MapFieldGround.empty);
                bigmap[i][j].set_object(MapFieldObject.none);
            }
        }

        for (int i = 0; i < 30; i++)
        {
            bigmap[i][30].set_ground(MapFieldGround.obstacle);
        }

        // Small with high density
        for (int i = 3; i < 8; i++)
        {
            for (int j = 5; j < 10; j++)
            {
                if (j % 2 == 0)
                {
                    bigmap[i][j] = new MapField();
                    bigmap[i][j].set_ground(MapFieldGround.mycorral);
                    bigmap[i][j].set_object(MapFieldObject.cow);
                    String id = i + "" + j;
                    bigmap[i][j].set_objectID(Integer.valueOf(id));
                    Cow cow = new Cow();
                    cow.setId(id);
                    MapCoordinate coord = new MapCoordinate(i, j);
                    cow.setCoordinate(coord);
                    cows.put(id, cow);
                }
            }
        }

        // Small with low density
        for (int i = 52; i < 56; i++)
        {
            for (int j = 6; j < 9; j++)
            {
                if (j % 2 == 0 && i % 2 == 0)
                {
                    bigmap[i][j] = new MapField();
                    bigmap[i][j].set_ground(MapFieldGround.enemycorral);
                    bigmap[i][j].set_object(MapFieldObject.cow);
                    String id = i + "" + j;
                    bigmap[i][j].set_objectID(Integer.valueOf(id));
                    Cow cow = new Cow();
                    cow.setId(id);
                    MapCoordinate coord = new MapCoordinate(i, j);
                    cow.setCoordinate(coord);
                    cows.put(id, cow);
                }
            }
        }

        // Some cows
        for (int i = 1; i < 30; i++)
        {
            for (int j = 50; j < 59; j++)
            {
                if (j % 3 == 0)
                {
                    bigmap[i][j] = new MapField();
                    bigmap[i][j].set_ground(MapFieldGround.empty);
                    bigmap[i][j].set_object(MapFieldObject.cow);
                    String id = i + "" + j;
                    bigmap[i][j].set_objectID(Integer.valueOf(id));
                    Cow cow = new Cow();
                    cow.setId(id);
                    MapCoordinate coord = new MapCoordinate(i, j);
                    cow.setCoordinate(coord);
                    cows.put(id, cow);
                }
            }
        }

        // Big with low density
        for (int i = 40; i < 59; i++)
        {
            for (int j = 30; j < 59; j++)
            {
                if (j % 3 == 0 && i % 2 == 0)
                {
                    bigmap[i][j] = new MapField();
                    bigmap[i][j].set_ground(MapFieldGround.empty);
                    bigmap[i][j].set_object(MapFieldObject.cow);
                    String id = i + "" + j;
                    bigmap[i][j].set_objectID(Integer.valueOf(id));
                    Cow cow = new Cow();
                    cow.setId(id);
                    MapCoordinate coord = new MapCoordinate(i, j);
                    cow.setCoordinate(coord);
                    cows.put(id, cow);
                }
            }
        }

        // Herd above the trees
        bigmap[5][28] = new MapField();
        bigmap[5][28].set_ground(MapFieldGround.empty);
        bigmap[5][28].set_object(MapFieldObject.cow);
        String id = "100" + 5 + "" + 28;
        bigmap[5][28].set_objectID(Integer.valueOf(id));
        Cow cow = new Cow();
        cow.setId(id);
        MapCoordinate coord = new MapCoordinate(5, 28);
        cow.setCoordinate(coord);
        cows.put(id, cow);

        bigmap[3][29] = new MapField();
        bigmap[3][29].set_ground(MapFieldGround.empty);
        bigmap[3][29].set_object(MapFieldObject.cow);
        id = "100" + 3 + "" + 29;
        bigmap[3][29].set_objectID(Integer.valueOf(id));
        cow = new Cow();
        cow.setId(id);
        coord = new MapCoordinate(3, 29);
        cow.setCoordinate(coord);
        cows.put(id, cow);

        // Herd below the trees
        bigmap[5][31] = new MapField();
        bigmap[5][31].set_ground(MapFieldGround.empty);
        bigmap[5][31].set_object(MapFieldObject.cow);
        id = "100" + 5 + "" + 31;
        bigmap[5][31].set_objectID(Integer.valueOf(id));
        cow = new Cow();
        cow.setId(id);
        coord = new MapCoordinate(5, 31);
        cow.setCoordinate(coord);
        cows.put(id, cow);

        bigmap[3][33] = new MapField();
        bigmap[3][33].set_ground(MapFieldGround.empty);
        bigmap[3][33].set_object(MapFieldObject.cow);
        id = "100" + 3 + "" + 33;
        bigmap[3][33].set_objectID(Integer.valueOf(id));
        cow = new Cow();
        cow.setId(id);
        coord = new MapCoordinate(3, 33);
        cow.setCoordinate(coord);
        cows.put(id, cow);

        // Herd around the trees
        bigmap[28][29] = new MapField();
        bigmap[28][29].set_ground(MapFieldGround.empty);
        bigmap[28][29].set_object(MapFieldObject.cow);
        id = "100" + 28 + "" + 29;
        bigmap[28][29].set_objectID(Integer.valueOf(id));
        cow = new Cow();
        cow.setId(id);
        coord = new MapCoordinate(28, 29);
        cow.setCoordinate(coord);
        cows.put(id, cow);

        bigmap[28][31] = new MapField();
        bigmap[28][31].set_ground(MapFieldGround.empty);
        bigmap[28][31].set_object(MapFieldObject.cow);
        id = "100" + 28 + "" + 31;
        bigmap[28][31].set_objectID(Integer.valueOf(id));
        cow = new Cow();
        cow.setId(id);
        coord = new MapCoordinate(28, 31);
        cow.setCoordinate(coord);
        cows.put(id, cow);

        mc.set_map(bigmap);
        mc.set_cowList(cows);

        long fstarttime = System.currentTimeMillis();
        classify.classifyHerds(mc, DEPTH, 0);
        long fstoptime = System.currentTimeMillis();

        List<CowHerd> herds = classify.getFreeHerds();

        long time = fstoptime - fstarttime;

        for (CowHerd cherd : herds)
        {
            int[] b = cherd.getBorder();
            MapCoordinate wc = cherd.getWeightedCenter();
            MapCoordinate gc = cherd.getGeometricCenter();
            bigmap[wc.getX()][wc.getY()].set_lastSeen(1);
            bigmap[gc.getX()][gc.getY()].set_lastSeen(2);

            System.out.println(cherd + " center: weighted " + wc + " geometric " + gc + " top: " + b[0] + " right: "
                    + b[1] + " bottom: " + b[2] + " left: " + b[3] + " state " + cherd.getStatus());
        }

        printMap(bigmap);

        System.out.println("");
        System.out.println("");

        System.out.println("It took " + time + " ms to search on " + MAXI + "x" + MAXJ + " with depth " + DEPTH);

        herd1 = herds.get(0);
        herd2 = herds.get(1);
        herd3 = herds.get(2);
        herd4 = herds.get(3);
        herd5 = herds.get(4);
        herd6 = herds.get(5);
        herd7 = herds.get(6);
    }

    /**
     * Method to test for counting the found herds. The test checks for each
     * herd found, whether the herd size is correct and for two herds whether
     * the density is in an acceptable range. This test looks whether - All
     * herds are found - Herds separated by an unavoidable obstacle are
     * separated - Herds separated by a avoidable obstacle are not separated -
     * Herd density is correct
     * 
     * Additionally the time needed for calculations is measured and printed out
     * to the console. The time is not used for the unit test, as it might vary
     * depending on the machine running the tests on.
     * 
     * For better visualization, the map is printed out to console. The
     * geometric center of each herd is represented by a G, the weighted center
     * by a capital C, each cow as a c and obstacles as T.
     */
    @Test
    public void testClassifyAndCount()
    {
        // 29 * 3
        assertEquals(herd1.getCows().size(), 87);
        // 2 * 5
        assertEquals(herd2.getCows().size(), 10);
        // 1 * 2
        assertEquals(herd3.getCows().size(), 2);
        // 1 * 2
        assertEquals(herd4.getCows().size(), 2);
        // 1 * 2
        assertEquals(herd5.getCows().size(), 2);
        // 10 * 10
        assertEquals(herd6.getCows().size(), 100);
        // 2 * 2
        assertEquals(herd7.getCows().size(), 4);

        assertTrue(herd1.getDensity() > 0.1);
        assertTrue(herd1.getDensity() < 0.5);
    }

    /**
     * Method to test checking for herd borders. This test makes sure that the
     * outer borders of each herd are calculated correctly.
     */
    @Test
    public void testBorders()
    {
        int[] bord1 = herd1.getBorder();
        int[] bord2 = herd2.getBorder();
        int[] bord3 = herd3.getBorder();
        int[] bord4 = herd4.getBorder();
        int[] bord5 = herd5.getBorder();
        int[] bord6 = herd6.getBorder();
        int[] bord7 = herd7.getBorder();

        int[] cbord1 = { 51, 29, 57, 1 };
        int[] cbord2 = { 6, 7, 8, 3 };
        int[] cbord3 = { 28, 5, 29, 3 };
        int[] cbord4 = { 31, 5, 33, 3 };
        int[] cbord5 = { 29, 28, 31, 28 };
        int[] cbord6 = { 30, 58, 57, 40 };
        int[] cbord7 = { 6, 54, 8, 52 };

        for (int i = 0; i < 4; i++)
        {
            assertEquals(bord1[i], cbord1[i]);
            assertEquals(bord2[i], cbord2[i]);
            assertEquals(bord3[i], cbord3[i]);
            assertEquals(bord4[i], cbord4[i]);
            assertEquals(bord5[i], cbord5[i]);
            assertEquals(bord6[i], cbord6[i]);
            assertEquals(bord7[i], cbord7[i]);
        }
    }

    /**
     * Method to test checking for geometric herd centers. This test makes sure
     * that the centers of each herd are calculated correctly. Weighted centers
     * are not calculated as in formations such as the given ones all cows could
     * be weighted centers.
     */
    @Test
    public void testCenter()
    {
        MapCoordinate gc1 = new MapCoordinate(15, 54);
        MapCoordinate gc2 = new MapCoordinate(5, 7);
        MapCoordinate gc3 = new MapCoordinate(4, 28);
        MapCoordinate gc4 = new MapCoordinate(4, 32);
        MapCoordinate gc5 = new MapCoordinate(28, 30);
        MapCoordinate gc6 = new MapCoordinate(49, 43);
        MapCoordinate gc7 = new MapCoordinate(53, 7);

        assertEquals(gc1, herd1.getGeometricCenter());
        assertEquals(gc2, herd2.getGeometricCenter());
        assertEquals(gc3, herd3.getGeometricCenter());
        assertEquals(gc4, herd4.getGeometricCenter());
        assertEquals(gc5, herd5.getGeometricCenter());
        assertEquals(gc6, herd6.getGeometricCenter());
        assertEquals(gc7, herd7.getGeometricCenter());
    }

    /**
     * Method to test checking for the herd status. This test makes sure that
     * the status of each herd is calculated correctly.
     */
    @Test
    public void testState()
    {
        assertEquals(herd1.getStatus(), CowHerdStatus.FREE);
        assertEquals(herd2.getStatus(), CowHerdStatus.INOWNCORRAL);
        assertEquals(herd3.getStatus(), CowHerdStatus.FREE);
        assertEquals(herd4.getStatus(), CowHerdStatus.FREE);
        assertEquals(herd5.getStatus(), CowHerdStatus.FREE);
        assertEquals(herd6.getStatus(), CowHerdStatus.FREE);
        assertEquals(herd7.getStatus(), CowHerdStatus.INENEMYCORRAL);
    }

    /**
     * Helper Method to draw the map
     * 
     * @param map
     *            the map
     */
    public static void printMap(MapField[][] map)
    {
        System.out.println("");
        System.out.println("");

        int maxx = map.length;
        if (maxx == 0)
            return;
        int maxy = map[0].length;

        for (int cy = 0; cy < maxy; cy++)
        {
            String line = "";

            for (int cx = 0; cx < maxx; cx++)
            {

                MapField mapField = map[cx][cy];

                if (mapField.get_lastSeen() == 1)
                {
                    line += "C";
                }
                else if (mapField.get_lastSeen() == 2)
                {
                    line += "G";
                }
                else if (mapField.get_lastSeen() == -1)
                {
                    if (mapField.get_ground() == MapFieldGround.obstacle)
                    {
                        line += "T";
                    }

                    if (mapField.get_object() == MapFieldObject.cow)
                    {
                        line += "c";
                    }
                    else if (mapField.get_ground() == MapFieldGround.empty)
                    {
                        line += " ";
                    }

                }
            }

            System.out.println(line);

        }
    }
}
