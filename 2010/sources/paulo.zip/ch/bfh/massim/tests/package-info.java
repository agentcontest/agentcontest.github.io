/**
 * Contains the JUnit test classes and tools needed by those classes. 
 */
package ch.bfh.massim.tests;