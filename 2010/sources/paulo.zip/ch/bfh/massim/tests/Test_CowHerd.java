package ch.bfh.massim.tests;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import ch.bfh.massim.framework.MapCoordinate;
import ch.bfh.massim.framework.cowherd.Cow;
import ch.bfh.massim.framework.cowherd.CowHerd;

/**
 * Class to test the cow herd. This class is used so that the common methods on
 * cow herds used by many classes can be tested. Some things, such as the
 * density, are tested in the HerdClassifier tests, as they can't be calculated
 * without a herd classifier. This class provides test cases and set up methods.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class Test_CowHerd
{
    private static MapCoordinate topLeft;
    private static MapCoordinate bottomRight;
    private static MapCoordinate topRight;
    private static MapCoordinate bottomLeft;
    private static Cow ctopLeft;
    private static Cow cbottomRight;
    private static Cow ctopRight;
    private static Cow cbottomLeft;
    private static Cow coutside;
    private static CowHerd herd1;
    private static CowHerd herd2;
    private static MapCoordinate center;
    private static MapCoordinate outside;

    /**
     * Set up method. Instantiates the objects needed for the tests. Will be
     * called before the first test. Creates a big test map with cows and
     * obstacles on it, used for the tests,
     * 
     * @throws Exception
     *             not used and not the case
     */
    @BeforeClass
    public static void setUpClass() throws Exception
    {
        topLeft = new MapCoordinate(0, 0);
        bottomRight = new MapCoordinate(10, 10);
        topRight = new MapCoordinate(10, 0);
        bottomLeft = new MapCoordinate(0, 10);
        center = new MapCoordinate(5, 5);

        ctopLeft = new Cow("cow1", topLeft);
        cbottomRight = new Cow("cow2", bottomRight);
        ctopRight = new Cow("cow3", topRight);
        cbottomLeft = new Cow();
        cbottomLeft.setId("cow4");
        cbottomLeft.setCoordinate(bottomLeft);
        outside = new MapCoordinate(20, 20);
        coutside = new Cow("cow5", outside);

        herd1 = new CowHerd("herd1");
        herd2 = new CowHerd("herd2");

        herd1.addCow(ctopLeft);
        herd1.addCow(ctopRight);
        herd1.addCow(cbottomLeft);
        herd1.addCow(cbottomRight);

        herd2.addCow(coutside);

    }

    /**
     * Method to test the basics such as equals and uniqueID.
     * 
     * @throws CloneNotSupportedException
     */
    @Test
    public void testBasics() throws CloneNotSupportedException
    {
        assertFalse(herd1.equals(herd2));
        assertFalse(herd1.equals(null));
        assertFalse(herd1.equals("anystring"));

        assertTrue(herd1.equals(herd1));
        assertTrue(herd1.getUniqueID().equals("herd1"));
    }

    /**
     * Method to test the center calculations.
     */
    @Test
    public void testCalculateCenter()
    {
        // Geometric center between 4 edge cows is the center
        assertEquals(herd1.getGeometricCenter(), center);
        // Geometric center of one cow is the cow
        assertEquals(herd2.getGeometricCenter(), outside);
        // Weighted center of one cow is the cow
        assertEquals(herd2.getWeightedCenter(), outside);
    }

    /**
     * Method to test the herd size.
     */
    @Test
    public void testHerdSize()
    {
        assertEquals(herd1.getCows().size(), 4);
        assertEquals(herd2.getCows().size(), 1);
    }
}
