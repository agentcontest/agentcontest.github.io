package ch.bfh.massim.tests;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import ch.bfh.massim.framework.MapCoordinate;
import ch.bfh.massim.framework.mapagent.MapField;
import ch.bfh.massim.framework.mapagent.MapFieldGround;
import ch.bfh.massim.framework.mapagent.MapFieldObject;
import ch.bfh.massim.framework.pathfinder.PathFinder;

/**
 * Class to test the path finder. This class is used for testing the search for
 * paths. This class provides test cases and set up methods.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class Test_PathFinder
{

    private static PathFinder pf;
    private static MapCoordinate sstart;
    private static MapCoordinate sgoal;
    private static MapCoordinate ogoal;
    private static MapCoordinate bstart;
    private static MapCoordinate bgoal;
    private static MapCoordinate closed;
    private static MapField[][] smallmap;
    private static MapField[][] bigmap;
    private static ArrayList<MapCoordinate> obstpath;
    private static ArrayList<MapCoordinate> purepath;
    private static ArrayList<MapCoordinate> altpath;
    private static ArrayList<MapCoordinate> bigpath;
    private static ArrayList<MapCoordinate> bigignorepath;
    private static ArrayList<MapCoordinate> closedcords;

    /**
     * Method to set everything up. Instantiates the objects needed for the
     * tests. Will be called before the first test. Creates a small and a big
     * test map used for the tests, and creates the objects on it.
     * 
     * @throws Exception
     *             not used and not the case
     */
    @BeforeClass
    public static void setUpClass() throws Exception
    {
        pf = new PathFinder();

        sstart = new MapCoordinate(2, 5);
        sgoal = new MapCoordinate(2, 2);
        ogoal = new MapCoordinate(0, 1);

        obstpath = new ArrayList<MapCoordinate>();
        altpath = new ArrayList<MapCoordinate>();
        purepath = new ArrayList<MapCoordinate>();

        int maxi = 80;
        int maxj = 80;

        bstart = new MapCoordinate(maxi / 2, 3);
        bgoal = new MapCoordinate(maxi / 2, maxj - 3);

        closedcords = new ArrayList<MapCoordinate>();

        bigpath = new ArrayList<MapCoordinate>();
        bigignorepath = new ArrayList<MapCoordinate>();

        closed = new MapCoordinate((maxi / 2) - 1, 4);
        closedcords = new ArrayList<MapCoordinate>();
        closedcords.add(closed);

        smallmap = new MapField[8][8];

        for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                smallmap[i][j] = new MapField();
                if (i == 0 || i == 7 || j == 0 || j == 7)
                    smallmap[i][j].set_ground(MapFieldGround.obstacle);
                else
                    smallmap[i][j].set_ground(MapFieldGround.empty);
                smallmap[i][j].set_object(MapFieldObject.none);
            }
        }

        smallmap[1][3].set_ground(MapFieldGround.obstacle);
        smallmap[2][3].set_ground(MapFieldGround.obstacle);
        smallmap[3][3].set_ground(MapFieldGround.obstacle);
        smallmap[4][3].set_ground(MapFieldGround.obstacle);
        smallmap[1][3].set_ground(MapFieldGround.obstacle);
        smallmap[4][4].set_ground(MapFieldGround.obstacle);
        smallmap[4][5].set_ground(MapFieldGround.obstacle);

        bigmap = new MapField[maxi][maxj];
        for (int i = 0; i < maxi; i++)
        {
            for (int j = 0; j < maxj; j++)
            {
                bigmap[i][j] = new MapField();
                if (i == 0 || i == maxi - 1 || j == 0 || j == maxj - 1)
                    bigmap[i][j].set_ground(MapFieldGround.obstacle);
                else
                    bigmap[i][j].set_ground(MapFieldGround.empty);
                bigmap[i][j].set_object(MapFieldObject.none);
            }
        }

        for (int i = 2; i < maxi - 1; i++)
        {
            bigmap[i][maxj / 2].set_ground(MapFieldGround.obstacle);
        }

    }

    /**
     * Method to reset everything. Will set the lastSeen values of the maps back
     * to zero to get a fresh environment for each test. This method is called
     * before each test.
     * 
     * @throws Exception
     */
    @Before
    public void setUp() throws Exception
    {
        for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                smallmap[i][j].set_lastSeen(0);
            }
        }

        for (int i = 0; i < 80; i++)
        {
            for (int j = 0; j < 80; j++)
            {
                bigmap[i][j].set_lastSeen(0);
            }
        }
    }

    /**
     * Method to test on a small map with obstacles: 9 steps maximum as it will
     * walk around the obstacles. This test checks for the path length, which
     * also makes sure that a path has been found. Additionally, the setup and
     * solution is printed out to the console for better visualization. The time
     * taken for the path calculation is measured and printed out on console as
     * well. This time is not used for the unit test, as it might vary depending
     * on the machine the test runs on.
     */
    @Test
    public void testsmallObstacles()
    {
        long fstarttime = System.currentTimeMillis();
        List<MapCoordinate> p1 = pf.getPath(smallmap, sstart, sgoal);
        long fstoptime = System.currentTimeMillis();

        System.out.println("Timer test on a small (8x8) map:");
        System.out.println("");

        System.out.println(" 0 TTTTTTTT");
        System.out.println(" 1 T      T");
        System.out.println(" 2 T G    T");
        System.out.println(" 3 TTTTT  T");
        System.out.println(" 4 T   T  T");
        System.out.println(" 5 T S T  T");
        System.out.println(" 6 T      T");
        System.out.println(" 7 TTTTTTTT");
        System.out.println("   01234567");

        System.out.println("");
        System.out.println("Path with obstacles (T):");
        System.out.println("Time: " + (fstoptime - fstarttime) + " ms");

        if (p1 == null)
            System.out.println("No path found (with obstacles");
        else
        {
            obstpath.addAll(p1);

            System.out.println("Needed " + obstpath.size() + " steps");

            for (MapCoordinate coord : obstpath)
            {
                smallmap[coord.getX()][coord.getY()].set_lastSeen(1);
                System.out.print(coord.toString());
                System.out.print(" | ");
            }
        }

        printMap(smallmap);

        assertTrue(p1.size() <= 9);
    }

    /**
     * Method to test on a small map with obstacles: Checks whether the next
     * free field calculation works when the target is an obstacle.
     * Additionally, the setup and solution is printed out to the console for
     * better visualization. The time taken for the path calculation is measured
     * and printed out on console as well. This time is not used for the unit
     * test, as it might vary depending on the machine the test runs on.
     */
    @Test
    public void testsmallObstaclesNextFreeField()
    {
        long fstarttime = System.currentTimeMillis();
        List<MapCoordinate> p1 = pf.getPathToNearestGoal(smallmap, sstart, ogoal);
        long fstoptime = System.currentTimeMillis();

        System.out.println("Timer test on a small (8x8) map to nearest non blocked:");
        System.out.println("");

        System.out.println(" 0 TTTTTTTT");
        System.out.println(" 1 T      T");
        System.out.println(" 2 GR     T");
        System.out.println(" 3 TTTTT  T");
        System.out.println(" 4 T   T  T");
        System.out.println(" 5 T S T  T");
        System.out.println(" 6 T      T");
        System.out.println(" 7 TTTTTTTT");
        System.out.println("   01234567");

        System.out.println("");
        System.out.println("Path with obstacles (T) to R instead of G:");
        System.out.println("Time: " + (fstoptime - fstarttime) + " ms");

        if (p1 == null)
            System.out.println("No path found (with obstacles");
        else
        {
            altpath.addAll(p1);

            System.out.println("Needed " + altpath.size() + " steps");

            for (MapCoordinate coord : altpath)
            {
                smallmap[coord.getX()][coord.getY()].set_lastSeen(1);
                System.out.print(coord.toString());
                System.out.print(" | ");
            }
        }

        printMap(smallmap);

        assertTrue(p1.size() <= 10);
    }

    /**
     * Method to test on a small map without obstacles: 4 steps maximum as it
     * will walk through the obstacles on a straight path. This test checks for
     * the path length, which also makes sure that a path has been found.
     * Additionally, the solution is printed out to the console for better
     * visualization. The time taken for the path calculation is measured and
     * printed out on console as well. This time is not used for the unit test,
     * as it might vary depending on the machine the test runs on.
     */
    @Test
    public void testsmallNoObstacles()
    {
        pf.setIgnoreobstacles(true);
        long ostarttime = System.currentTimeMillis();
        List<MapCoordinate> p2 = pf.getPath(smallmap, sstart, sgoal);
        long ostoptime = System.currentTimeMillis();

        System.out.println("");
        System.out.println("");
        System.out.println("Path without obstacles:");
        System.out.println("Time: " + (ostoptime - ostarttime) + " ms");

        if (p2 == null)
            System.out.println("No path found (without obstacles");
        else
        {
            purepath.addAll(p2);
            System.out.println("Needed " + purepath.size() + " steps");

            for (MapCoordinate coord : purepath)
            {
                smallmap[coord.getX()][coord.getY()].set_lastSeen(1);
                System.out.print(coord.toString());
                System.out.print(" | ");
            }
        }

        printMap(smallmap);
        assertTrue(p2.size() <= 4);
    }

    /**
     * Method to test on a small map without obstacles: 79 steps maximum as it
     * will walk around the obstacles on a diagonal path. This test checks for
     * the path length, which also makes sure that a path has been found.
     * Additionally, the solution is printed out to the console for better
     * visualization. The time taken for the path calculation is measured and
     * printed out on console as well. This time is not used for the unit test,
     * as it might vary depending on the machine the test runs on.
     */
    @Test
    public void testbigWithoutIgnore()
    {
        System.out.println("");
        System.out.println("");
        System.out.println("");

        System.out.println("Timer test on a big (80x80) map:");
        System.out.println("");
        pf.setIgnoreobstacles(false);

        long starttime = System.currentTimeMillis();
        List<MapCoordinate> p3 = pf.getPath(bigmap, bstart, bgoal);
        long stoptime = System.currentTimeMillis();
        System.out.println("Time: " + (stoptime - starttime) + " ms");

        System.out.println("");
        System.out.println("Path on 80x80 with obstacles (T):");

        if (p3 == null)
            System.out.println("No path found (with obstacles");
        else
        {
            bigpath.addAll(p3);

            System.out.println("Needed " + bigpath.size() + " steps");

            for (MapCoordinate coord : bigpath)
            {
                bigmap[coord.getX()][coord.getY()].set_lastSeen(1);
                System.out.print(coord.toString());
                System.out.print(" | ");
            }
        }

        printMap(bigmap);

        assertTrue(bigpath.size() <= 79);
    }

    /**
     * Method to test on a small map without obstacles: 79 steps maximum as it
     * will walk around the obstacles on a diagonal path. This test checks for
     * the path length, which also makes sure that a path has been found. This
     * time the field which would be taken as a first step is set on the ignore
     * list, the algorithm has to find a path with equal length around it. The
     * solution is printed out to the console for better visualization. The time
     * taken for the path calculation is measured and printed out on console as
     * well. This time is not used for the unit test, as it might vary depending
     * on the machine the test runs on.
     */
    @Test
    public void testbigWithIgnore()
    {
        System.out.println("");
        System.out.println("");
        System.out.println("");

        System.out.println("Timer test on a big (80x80) map with ignore field:");
        System.out.println("");
        pf.setIgnoreobstacles(false);

        long starttime = System.currentTimeMillis();
        for (MapCoordinate ccoord : closedcords)
        {
            System.out.println(ccoord);
        }
        List<MapCoordinate> p3 = pf.getPath(bigmap, bstart, bgoal, closedcords);
        long stoptime = System.currentTimeMillis();
        System.out.println("Time: " + (stoptime - starttime) + " ms");

        System.out.println("");
        System.out.println("Path on 80x80 with obstacles (T):");

        if (p3 == null)
            System.out.println("No path found (with ignored fields");
        else
        {
            bigignorepath.addAll(p3);

            System.out.println("Needed " + bigignorepath.size() + " steps");

            for (MapCoordinate coord : bigignorepath)
            {
                bigmap[coord.getX()][coord.getY()].set_lastSeen(1);
                System.out.print(coord.toString());
                System.out.print(" | ");
            }
        }

        printMap(bigmap);

        assertTrue(bigignorepath.size() <= 79);
        assertFalse(bigignorepath.contains(closed));
    }

    /**
     * Helper Method to draw the path on the map. Will print out a map on the
     * console. The lastSeen value is used to mark a path found on this map.
     * 
     * @param map
     *            the map
     */
    public static void printMap(MapField[][] map)
    {
        System.out.println("");
        System.out.println("");

        int maxx = map.length;
        if (maxx == 0)
            return;
        int maxy = map[0].length;

        for (int cy = 0; cy < maxy; cy++)
        {
            String line = "";

            for (int cx = 0; cx < maxx; cx++)
            {

                MapField mapField = map[cx][cy];

                if (mapField.get_lastSeen() == 1)
                {
                    line += "x";
                }
                else
                {
                    if (mapField.get_ground() == MapFieldGround.obstacle)
                    {
                        line += "T";
                    }
                    else if (mapField.get_ground() == MapFieldGround.empty)
                    {
                        line += " ";
                    }
                }
            }

            System.out.println(line);

        }
    }
}
