package ch.bfh.massim.tests;

import ch.bfh.massim.framework.mapagent.MapField;
import ch.bfh.massim.framework.mapagent.MapFieldGround;
import ch.bfh.massim.framework.mapagent.MapFieldObject;

public class MapGenerator
{

    public static MapField[][] generateEmptyMap(int xmax, int ymax)
    {
        MapField[][] map = new MapField[xmax][ymax];

        for (int i = 0; i < xmax; i++)
        {
            for (int j = 0; j < ymax; j++)
            {
                map[i][j] = new MapField();
                map[i][j].set_ground(MapFieldGround.empty);
                map[i][j].set_object(MapFieldObject.none);
            }
        }

        return map;
    }

    public static void setObject(MapField[][] map, int x, int y, MapFieldObject obj)
    {
        map[x][y].set_object(obj);
    }

    public static void setGround(MapField[][] map, int x, int y, MapFieldGround ground)
    {
        map[x][y].set_ground(ground);
    }

    public static void setLine(MapField[][] map, int startx, int starty, int size, boolean inX, MapFieldObject obj,
            MapFieldGround ground)
    {
        // map[startx][starty].set_object(MapFieldObject.none);
        // map[startx][starty].set_ground(MapFieldGround.fenceswitch);

        if (inX)
        {
            for (int i = 0; i < size; i++)
            {
                map[startx + i][starty].set_ground(ground);
                map[startx + i][starty].set_object(obj);
            }
        }
        else
        {
            for (int i = 0; i < size; i++)
            {
                map[startx][starty + i].set_ground(ground);
                map[startx][starty + i].set_object(obj);
            }
        }
    }

    public static void printMap(MapField[][] map)
    {
        System.out.println("");
        System.out.println("");

        int maxx = map.length;
        if (maxx == 0)
            return;
        int maxy = map[0].length;

        for (int cy = 0; cy < maxy; cy++)
        {
            String line = "";

            for (int cx = 0; cx < maxx; cx++)
            {

                MapField mapField = map[cx][cy];

                if (mapField.get_lastSeen() == 1)
                {
                    line += "x";
                }
                else
                {
                    if (mapField.get_ground() == MapFieldGround.obstacle)
                    {
                        line += "T";
                    }
                    else if (mapField.get_ground() == MapFieldGround.empty)
                    {
                        line += " ";
                    }
                    else if (mapField.get_ground() == MapFieldGround.fenceswitch)
                    {
                        line += "s";
                    }
                    else if (mapField.get_ground() == MapFieldGround.fenceclosed)
                    {
                        line += "f";
                    }
                }
            }

            System.out.println(line);

        }

    }
}
