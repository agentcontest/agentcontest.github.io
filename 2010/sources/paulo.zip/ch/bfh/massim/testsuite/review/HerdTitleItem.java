package ch.bfh.massim.testsuite.review;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * Class to represent all herds as a title in a list. This class is used as a
 * title for a list. This class provides methods to show, hide and manipulate
 * the items in the list.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class HerdTitleItem extends JPanel implements IRightTitleItem
{

    private final String TITLE = "created herds";

    private static final long serialVersionUID = -6267884357065230154L;
    private JButton _toggle;
    private JButton _activate;
    private JButton _deactivate;
    private String _directory;
    private ReviewGUI _mainGui;
    private boolean _open;

    private ArrayList<IRightBodyItem> _items;
    private HashMap<String, HerdBodyItem> _fields;

    private Random _rand;

    private ImageIcon _iadd;
    private ImageIcon _irem;
    private ImageIcon _iact;
    private ImageIcon _idea;

    /**
     * Default constructor.
     * 
     * @param mainGui
     *            the gui this item is bound to
     */
    public HerdTitleItem(ReviewGUI mainGui)
    {
        this.setPreferredSize(new Dimension(240, 30));
        this.setMaximumSize(new Dimension(240, 30));

        _mainGui = mainGui;
        _toggle = new JButton();
        _open = false;
        _activate = new JButton();
        _deactivate = new JButton();
        _items = new ArrayList<IRightBodyItem>();
        _fields = new HashMap<String, HerdBodyItem>();
        _rand = new Random();

        // Button Icons
        try
        {
            URL url = new java.net.URL(getClass().getResource("img/buttons/list-add.png"), "list-add.png");
            _iadd = new ImageIcon(url);

            url = new java.net.URL(getClass().getResource("img/buttons/list-remove.png"), "list-remove.png");
            _irem = new ImageIcon(url);

            url = new java.net.URL(getClass().getResource("img/buttons/list-activate.png"), "list-activate.png");
            _iact = new ImageIcon(url);

            url = new java.net.URL(getClass().getResource("img/buttons/list-deactivate.png"), "list-deactivate.png");
            _idea = new ImageIcon(url);

        }
        catch (Exception e)
        {
            String message = "Image loading failed";
            String where = "Right list Button Initialisation";
            String possol = "Check whether the img/buttons/ folder exists";

            mainGui.showErrorDialog(message, where, possol, e);
        }

        _toggle = new JButton(_iadd);
        _toggle.setPreferredSize(new Dimension(30, 20));
        _activate = new JButton(_iact);
        _activate.setPreferredSize(new Dimension(30, 20));
        _deactivate = new JButton(_idea);
        _deactivate.setPreferredSize(new Dimension(30, 20));

        _toggle.addActionListener(new ToggleListener());
        _activate.addActionListener(new ActivateListener());
        _deactivate.addActionListener(new DeactivateListener());

        this.add(_toggle);
        this.add(new JLabel(TITLE));
        this.add(_activate);
        this.add(_deactivate);

    }

    /**
     * Method to create a list of paths List will be empty if open is false.
     */
    public void createList()
    {
        _items.clear();

        if (!_open)
            return;

        File folder = new File(_directory);
        if (folder != null)
        {
            File[] folders = folder.listFiles();
            
            if (folders == null)
                return;

            String sep = File.pathSeparator;
            
            for (int i = 0; i < folders.length; i++)
            {
            	String path = folders[i].getPath();
            	// workaround for windows ...
            	if(sep.equals(";"))
            		path = path.replace('\\' , '/');
            	
                String split[] = path.split("/");

                if (split.length < 2)
                    continue;

                String team = split[split.length - 2];
                String target = split[split.length - 1];
                String id = team + "_" + target;

                HerdBodyItem hbi = null;

                if (_fields.containsKey(id))
                {
                    hbi = _fields.get(id);
                }
                else
                {
                    Color col = new Color(_rand.nextInt(120) + 100, _rand.nextInt(120) + 100, _rand.nextInt(120) + 100);

                    hbi = new HerdBodyItem(id, col, false, folders[i].getPath(), _mainGui);
                    _fields.put(id, hbi);
                }

                _items.add(hbi);
            }
        }

        _mainGui.updateRightList(false);
    }

    /**
     * @return all Items in this list
     */
    @Override
    public ArrayList<IRightBodyItem> getAllItems()
    {
        return _items;
    }

    @Override
    public String getTitle()
    {
        return TITLE;
    }

    /**
     * @return the directory used for this items
     */
    public String getDirectory()
    {
        return _directory;
    }

    /**
     * @param directory
     *            the directory used for this items
     */
    public void setDirectory(String directory)
    {
        this._directory = directory;
    }

    /**
     * Inner class for the toggle button Will toggle the open boolean and then
     * call createList() and finally updateRightList() of the ReviewGUI.
     * 
     * @author Christian Loosli
     */
    class ToggleListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            if (_open)
            {
                _toggle.setIcon(_iadd);
                _open = false;
                createList();
                _mainGui.updateRightList(false);
            }
            else
            {
                _toggle.setIcon(_irem);
                _open = true;
                createList();
                _mainGui.updateRightList(false);
            }
        }
    }

    /**
     * Inner class for the activate button. Will set all paths active.
     * 
     * @author Christian Loosli & Adrian Pauli
     */
    class ActivateListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            for (IRightBodyItem citem : _items)
            {
                citem.setActivated(true);
            }
            _mainGui.updateRightList(false);
        }
    }

    /**
     * Inner class for the deactivate button. Will set all paths deactivated.
     * 
     * @author Christian Loosli & Adrian Pauli
     */
    class DeactivateListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            for (IRightBodyItem citem : _items)
            {
                citem.setActivated(false);
            }
            _mainGui.updateRightList(false);
        }
    }

}
