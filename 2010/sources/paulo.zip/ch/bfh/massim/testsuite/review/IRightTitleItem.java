package ch.bfh.massim.testsuite.review;

import java.util.ArrayList;

/**
 * Interface to represent all objects as a title in a list. This Interface is
 * used as a title for a list.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public interface IRightTitleItem
{
    String getTitle();

    ArrayList<IRightBodyItem> getAllItems();
}
