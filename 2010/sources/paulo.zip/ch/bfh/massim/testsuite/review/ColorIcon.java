package ch.bfh.massim.testsuite.review;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.Icon;

/**
 * Class to represent a color icon. This class is used as a container for a
 * color, which can be used on buttons or other objects. This class provides
 * methods to get and set settings and to paint the icon.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class ColorIcon implements Icon
{

    private final int WIDTH = 24;
    private final int HEIGHT = 24;

    private Color _color;

    /**
     * Default constructor.
     * 
     * @param color
     *            color used for this color icon
     */
    public ColorIcon(Color color)
    {
        _color = color;
    }

    /**
     * Overwritten paintIcon method. Will paint a color box as an icon.
     */
    public void paintIcon(Component c, Graphics g, int x, int y)
    {
        Graphics2D g2d = (Graphics2D) g.create();

        g2d.setColor(_color);
        g2d.fillRect(x + 2, y + 5, WIDTH - 5, HEIGHT - 10);

        g2d.dispose();
    }

    /**
     * @return the icon width
     */
    public int getIconWidth()
    {
        return WIDTH;
    }

    /**
     * @return the icon height
     */
    public int getIconHeight()
    {
        return HEIGHT;
    }
}
