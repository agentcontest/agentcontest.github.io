package ch.bfh.massim.testsuite.review;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * Class to read XML game informations. This class is used to read map
 * information such as cows or agents out of xml files. This class provides
 * methods to read the information provided as a xml file.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class XMLLogParser
{
    private String _gamename;
    private String _simname;
    private String _logdir;
    private String _roundlogdir;
    private String _maplogdir;

    private int _number_of_agents;
    private int _number_of_cows;
    private int _number_of_fences;
    private int _number_of_obstacles;
    private int _number_of_steps;
    private int _sizex;
    private int _sizey;
    private int _step;
    private int _team0_score;
    private int _team1_score;
    private int _roundstate;

    private String[][][] _gameobjects;
    private String[][][] _mapobjects;
    private int[][][] _mapviewstate;

    private String _teamname0;
    private String _teamname1;

    private DocumentBuilderFactory _dbf;
    private DocumentBuilder _db;

    /**
     * Default constructor.
     * 
     * @param logdir
     *            the log root directory, relative to the program root directory
     * @param gamename
     *            the name of the game, also folder name under $logdir
     * @param gamelogdir
     *            directory in $logdir containing the game logs
     * @param roundlogdir
     *            directory in $logdir containing the round logs
     * @param maplogdir
     *            directory in $logdir containing the map logs
     * @throws IOException
     * @throws SAXException
     */
    public XMLLogParser(String logdir, String gamename, String simname, String gamelogdir, String roundlogdir,
            String maplogdir) throws SAXException, IOException
    {
        _dbf = DocumentBuilderFactory.newInstance();

        try
        {
            _db = _dbf.newDocumentBuilder();
        }
        catch (ParserConfigurationException e)
        {
            System.out.println("94 XML Parser error occured: " + e.getMessage());
        }

        _gamename = gamename;
        _simname = simname;
        _logdir = logdir;
        _roundlogdir = roundlogdir;
        _maplogdir = maplogdir;

        // Set first round
        setupRoundState(1);

        // Initialize Arrays according to our size
        _gameobjects = new String[1][_sizex][_sizey];
        _mapobjects = new String[1][_sizex][_sizey];
        _mapviewstate = new int[1][_sizex][_sizey];
    }

    /**
     * Method to set the state to a given round. Use before calling the getters
     * in order to get state from a given round.
     * 
     * @param round
     *            the round we want to set the state to
     * @throws IOException
     * @throws SAXException
     */
    public void setupRoundState(int round) throws SAXException, IOException
    {
        // already up to date?
        if (_roundstate == round)
            return;

        File file = new File(_logdir + "/" + _gamename + "/" + _simname + "/" + _roundlogdir + "/" + round + ".xml");
        Document doc;

        doc = _db.parse(file);
        doc.getDocumentElement().normalize();
        NodeList nodeLst = doc.getElementsByTagName("state");

        Node fstNode = nodeLst.item(0);

        if (fstNode == null)
        {
            System.out.println("Failed to obtain round information");
        }

        if (fstNode.getNodeType() == Node.ELEMENT_NODE)
        {
            Element fstElmnt = (Element) fstNode;

            _number_of_agents = Integer.parseInt(fstElmnt.getAttribute("number-of-agents"));
            _number_of_cows = Integer.parseInt(fstElmnt.getAttribute("number-of-cows"));
            _number_of_fences = Integer.parseInt(fstElmnt.getAttribute("number-of-fences"));
            _number_of_obstacles = Integer.parseInt(fstElmnt.getAttribute("number-of-obstacles"));
            _number_of_steps = Integer.parseInt(fstElmnt.getAttribute("number-of-steps"));
            _sizex = Integer.parseInt(fstElmnt.getAttribute("sizex"));
            _sizey = Integer.parseInt(fstElmnt.getAttribute("sizey"));
            _step = Integer.parseInt(fstElmnt.getAttribute("step"));
            _team0_score = Integer.parseInt(fstElmnt.getAttribute("team0-score"));
            _team1_score = Integer.parseInt(fstElmnt.getAttribute("team1-score"));
            _teamname0 = fstElmnt.getAttribute("teamname0");
            _teamname1 = fstElmnt.getAttribute("teamname1");

        }
        _roundstate = round;
    }

    /**
     * Method to get the objects according to the massim server.
     * 
     * @param from
     *            from which round
     * @param to
     *            to which round
     * @return field content for [round]Field[x][y]
     * @throws IOException
     * @throws SAXException
     */
    public String[][][] getRoundLogContent(int from, int to) throws SAXException, IOException
    {
        _gameobjects = new String[Math.abs(to - from) + 1][_sizex + 1][_sizey + 1];

        for (int r = from, st = 0; r <= to; r++, st++)
        {
            setupRoundState(r);

            File file = new File(_logdir + "/" + _gamename + "/" + _simname + "/" + _roundlogdir + "/" + r + ".xml");
            Document doc;

            doc = _db.parse(file);
            doc.getDocumentElement().normalize();

            NodeList st1Lst = doc.getElementsByTagName("stable1");
            for (int s = 0; s < st1Lst.getLength(); s++)
            {
                Node fstNode = st1Lst.item(s);
                if (fstNode.getNodeType() == Node.ELEMENT_NODE)
                {
                    Element fstElmnt = (Element) fstNode;
                    int x = Integer.parseInt(fstElmnt.getAttribute("posx"));
                    int y = Integer.parseInt(fstElmnt.getAttribute("posy"));

                    _gameobjects[st][x][y] = "stable1";
                }
            }

            NodeList treeLst = doc.getElementsByTagName("tree");

            for (int s = 0; s < treeLst.getLength(); s++)
            {
                Node fstNode = treeLst.item(s);

                if (fstNode.getNodeType() == Node.ELEMENT_NODE)
                {
                    Element fstElmnt = (Element) fstNode;
                    int x = Integer.parseInt(fstElmnt.getAttribute("posx"));
                    int y = Integer.parseInt(fstElmnt.getAttribute("posy"));

                    _gameobjects[0][x][y] = "tree";

                }
            }

            NodeList st2Lst = doc.getElementsByTagName("stable2");

            for (int s = 0; s < st2Lst.getLength(); s++)
            {
                Node fstNode = st2Lst.item(s);

                if (fstNode.getNodeType() == Node.ELEMENT_NODE)
                {
                    Element fstElmnt = (Element) fstNode;
                    int x = Integer.parseInt(fstElmnt.getAttribute("posx"));
                    int y = Integer.parseInt(fstElmnt.getAttribute("posy"));

                    _gameobjects[st][x][y] = "stable2";

                }
            }

            NodeList agentLst = doc.getElementsByTagName("agent");
            for (int s = 0; s < agentLst.getLength(); s++)
            {

                Node fstNode = agentLst.item(s);

                if (fstNode.getNodeType() == Node.ELEMENT_NODE)
                {
                    Element fstElmnt = (Element) fstNode;
                    int x = Integer.parseInt(fstElmnt.getAttribute("posx"));
                    int y = Integer.parseInt(fstElmnt.getAttribute("posy"));
                    String team = fstElmnt.getAttribute("team");

                    if (team.equals(_teamname0))
                        _gameobjects[st][x][y] = "agent0";
                    else
                        _gameobjects[st][x][y] = "agent1";
                }
            }

            NodeList cowLst = doc.getElementsByTagName("cow");

            for (int s = 0; s < cowLst.getLength(); s++)
            {
                Node fstNode = cowLst.item(s);

                if (fstNode.getNodeType() == Node.ELEMENT_NODE)
                {
                    Element fstElmnt = (Element) fstNode;
                    int x = Integer.parseInt(fstElmnt.getAttribute("posx"));
                    int y = Integer.parseInt(fstElmnt.getAttribute("posy"));
                    _gameobjects[st][x][y] = "cow";
                }
            }

            NodeList swtLst = doc.getElementsByTagName("switch");

            for (int s = 0; s < swtLst.getLength(); s++)
            {
                Node fstNode = swtLst.item(s);

                if (fstNode.getNodeType() == Node.ELEMENT_NODE)
                {
                    Element fstElmnt = (Element) fstNode;
                    int x = Integer.parseInt(fstElmnt.getAttribute("posx"));
                    int y = Integer.parseInt(fstElmnt.getAttribute("posy"));
                    _gameobjects[st][x][y] = "switch";
                }
            }

            NodeList fncLst = doc.getElementsByTagName("fence");

            for (int s = 0; s < fncLst.getLength(); s++)
            {
                Node fstNode = fncLst.item(s);

                if (fstNode.getNodeType() == Node.ELEMENT_NODE)
                {
                    Element fstElmnt = (Element) fstNode;
                    int x = Integer.parseInt(fstElmnt.getAttribute("posx"));
                    int y = Integer.parseInt(fstElmnt.getAttribute("posy"));
                    _gameobjects[st][x][y] = "fence";
                }
            }

            NodeList obsLst = doc.getElementsByTagName("obstacle");

            for (int s = 0; s < obsLst.getLength(); s++)
            {
                Node fstNode = obsLst.item(s);

                if (fstNode.getNodeType() == Node.ELEMENT_NODE)
                {
                    Element fstElmnt = (Element) fstNode;
                    int x = Integer.parseInt(fstElmnt.getAttribute("posx"));
                    int y = Integer.parseInt(fstElmnt.getAttribute("posy"));
                    _gameobjects[st][x][y] = "obstacle";
                }
            }

            NodeList unkLst = doc.getElementsByTagName("unknown");

            for (int s = 0; s < unkLst.getLength(); s++)
            {
                Node fstNode = unkLst.item(s);

                if (fstNode.getNodeType() == Node.ELEMENT_NODE)
                {
                    Element fstElmnt = (Element) fstNode;
                    int x = Integer.parseInt(fstElmnt.getAttribute("posx"));
                    int y = Integer.parseInt(fstElmnt.getAttribute("posy"));
                    _gameobjects[st][x][y] = "unknown";
                }
            }
        }
        return _gameobjects;
    }

    /**
     * Method to parse the map agent log to get the viewstate (last seen).
     * 
     * @param from
     *            the starting round
     * @param to
     *            the ending round
     * @return the last seen value for [round] field[x][y] as amount of rounds
     *         since last seen
     * @throws IOException
     * @throws SAXException
     */
    public int[][][] getMapLogViewstate(String teamname, int from, int to) throws SAXException, IOException
    {
        _mapviewstate = new int[Math.abs(from - to) + 1][_sizex + 1][_sizey + 1];

        for (int r = from, st = 0; r <= to; r++, st++)
        {
            setupRoundState(r);

            File file = new File(_logdir + "/" + _gamename + "/" + _simname + "/" + _maplogdir + "/" + teamname + "/"
                    + r + ".xml");
            Document doc;

            doc = _db.parse(file);
            doc.getDocumentElement().normalize();
            NodeList nodeLst = doc.getElementsByTagName("cell");

            for (int s = 0; s < nodeLst.getLength(); s++)
            {

                Node fstNode = nodeLst.item(s);

                if (fstNode.getNodeType() == Node.ELEMENT_NODE)
                {

                    Element fstElmnt = (Element) fstNode;
                    int x = Integer.parseInt(fstElmnt.getAttribute("x"));
                    int y = Integer.parseInt(fstElmnt.getAttribute("y"));

                    int lastSeen = Integer.parseInt(fstElmnt.getAttribute("lastSeen"));

                    _mapviewstate[st][x][y] = lastSeen;
                }
            }
        }
        return _mapviewstate;
    }

    /**
     * Method to parse the map agent log to get the content according to map
     * agent.
     * 
     * @param from
     *            the starting round
     * @param to
     *            the ending round
     * @return the field content [round] field[x][y]
     * @throws IOException
     * @throws SAXException
     */
    public String[][][] getMapLogContent(String teamname, int from, int to) throws SAXException, IOException
    {
        _mapobjects = new String[Math.abs(to - from) + 1][_sizex + 1][_sizey + 1];

        for (int r = from, st = 0; r <= to; r++, st++)
        {
            setupRoundState(r);
            File file = new File(_logdir + "/" + _gamename + "/" + _simname + "/" + _maplogdir + "/" + teamname + "/"
                    + r + ".xml");
            Document doc;

            doc = _db.parse(file);
            doc.getDocumentElement().normalize();
            NodeList nodeLst = doc.getElementsByTagName("cell");
            String ownagent = "";
            String enemyagent = "";
            String owncorral = "";
            String enemycorral = "";

            ownagent = (teamname.equals("A")) ? "agent0" : "agent1";
            enemyagent = (teamname.equals("A")) ? "agent1" : "agent0";
            owncorral = (teamname.equals("A")) ? "stable1" : "stable2";
            enemycorral = (teamname.equals("A")) ? "stable2" : "stable1";

            for (int s = 0; s < nodeLst.getLength(); s++)
            {

                Node fstNode = nodeLst.item(s);

                if (fstNode.getNodeType() == Node.ELEMENT_NODE)
                {
                    Element fstElmnt = (Element) fstNode;
                    int x = Integer.parseInt(fstElmnt.getAttribute("x"));
                    int y = Integer.parseInt(fstElmnt.getAttribute("y"));

                    Node child = fstNode.getFirstChild();

                    String fcontent = "unknown";
                    String ftype = "";

                    if (child != null)
                    {
                        fcontent = child.getNodeName();

                        if (fcontent.equals("agent"))
                        {
                            Node tnode = child.getAttributes().item(0);
                            if (tnode != null)
                            {
                                ftype = tnode.getNodeValue();
                                if (ftype.equals("ally"))
                                    fcontent = ownagent;
                                else if (ftype.equals("enemy"))
                                    fcontent = enemyagent;
                            }
                        }

                        if (fcontent.equals("fence"))
                        {
                            Node tnode = child.getAttributes().item(0);
                            if (tnode != null)
                            {
                                ftype = tnode.getNodeValue();
                                if (ftype.equals("false"))
                                    fcontent = "fence";
                                else
                                    fcontent = "fenceopen";
                            }
                        }

                        if (fcontent.equals("corral"))
                        {
                            Node tnode = child.getAttributes().item(0);
                            if (tnode != null)
                            {
                                ftype = tnode.getNodeValue();
                                if (ftype.equals("ally"))
                                    fcontent = owncorral;
                                else if (ftype.equals("enemy"))
                                    fcontent = enemycorral;
                            }
                        }
                    }

                    _mapobjects[st][x][y] = fcontent;
                }
            }
        }
        return _mapobjects;
    }

    /**
     * @return the number_of_agents
     */
    public int getNumber_of_agents()
    {
        return _number_of_agents;
    }

    /**
     * @return the number_of_cows
     */
    public int getNumber_of_cows()
    {
        return _number_of_cows;
    }

    /**
     * @return the number_of_fences
     */
    public int getNumber_of_fences()
    {
        return _number_of_fences;
    }

    /**
     * @return the number_of_obstacles
     */
    public int getNumber_of_obstacles()
    {
        return _number_of_obstacles;
    }

    /**
     * @return the number_of_steps
     */
    public int getNumber_of_steps()
    {
        return _number_of_steps;
    }

    /**
     * @return the width of the gamefield
     */
    public int getSizex()
    {
        return _sizex;
    }

    /**
     * @return the height of the gamefield
     */
    public int getSizey()
    {
        return _sizey;
    }

    /**
     * @return the step
     */
    public int getStep()
    {
        return _step;
    }

    /**
     * @return the score of team0
     */
    public int getTeam0_score()
    {
        return _team0_score;
    }

    /**
     * @return the score of team1
     */
    public int getTeam1_score()
    {
        return _team1_score;
    }

    /**
     * @return the name of team0
     */
    public String getTeamname0()
    {
        return _teamname0;
    }

    /**
     * @return the name of team1
     */
    public String getTeamname1()
    {
        return _teamname1;
    }

    /**
     * @return the the map objects on the map according to massive
     */
    public String[][][] getGameobjects()
    {
        return _gameobjects;
    }

    /**
     * @return the map objects according to the map agent
     */
    public String[][][] getMapobjects()
    {
        return _mapobjects;
    }

    /**
     * @return the view state (last seen) of the fields in given rounds
     */
    public int[][][] getMapviewstate()
    {
        return _mapviewstate;
    }

    /**
     * @return the simulation name
     */
    public String getSimname()
    {
        return _simname;
    }

    /**
     * @param simname
     *            the simulation name
     */
    public void setSimname(String simname)
    {
        this._simname = simname;
    }

}
