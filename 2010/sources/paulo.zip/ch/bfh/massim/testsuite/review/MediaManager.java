package ch.bfh.massim.testsuite.review;

import java.awt.Image;
import java.net.URL;

/**
 * Class for managing media. Keeping memory usage down as we only need one
 * instance of each possible graphic object. Uses a singleton pattern, use
 * getInstance() instead of a constructor.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class MediaManager
{
    URL url;

    private Image _ired_agent;
    private Image _iblue_agent;
    private Image _iagent;
    private Image _icow;
    private Image _ired_stable;
    private Image _iblue_stable;
    private Image _iswitch;
    private Image _ifence;
    private Image _ifenceopen;
    private Image _itree;
    private Image _igrass;
    private Image _iunknown;
    private Image _iobstacle;
    private Image _ifog;

    private String _subdir = "img";

    private static MediaManager instance;

    /**
     * Default Constructor Loads all images for later usage.
     */
    private MediaManager()
    {
        try
        {
            url = new java.net.URL(getClass().getResource(_subdir + "/" + "red_agent.png"), "red_agent.png");
            _ired_agent = javax.imageio.ImageIO.read(url);

            url = new java.net.URL(getClass().getResource(_subdir + "/" + "blue_agent.png"), "blue_agent.png");
            _iblue_agent = javax.imageio.ImageIO.read(url);

            url = new java.net.URL(getClass().getResource(_subdir + "/" + "agent.png"), "agent.png");
            _iagent = javax.imageio.ImageIO.read(url);

            url = new java.net.URL(getClass().getResource(_subdir + "/" + "cow.png"), "cow.png");
            _icow = javax.imageio.ImageIO.read(url);

            url = new java.net.URL(getClass().getResource(_subdir + "/" + "fence.png"), "fence.png");
            _ifence = javax.imageio.ImageIO.read(url);

            url = new java.net.URL(getClass().getResource(_subdir + "/" + "fenceopen.png"), "fenceopen.png");
            _ifenceopen = javax.imageio.ImageIO.read(url);

            url = new java.net.URL(getClass().getResource(_subdir + "/" + "grass.png"), "grass.png");
            _igrass = javax.imageio.ImageIO.read(url);

            url = new java.net.URL(getClass().getResource(_subdir + "/" + "red_stable.png"), "red_stable.png");
            _ired_stable = javax.imageio.ImageIO.read(url);

            url = new java.net.URL(getClass().getResource(_subdir + "/" + "blue_stable.png"), "blue_stable.png");
            _iblue_stable = javax.imageio.ImageIO.read(url);

            url = new java.net.URL(getClass().getResource(_subdir + "/" + "switch.png"), "switch.png");
            _iswitch = javax.imageio.ImageIO.read(url);

            url = new java.net.URL(getClass().getResource(_subdir + "/" + "tree.png"), "tree.png");
            _itree = javax.imageio.ImageIO.read(url);

            url = new java.net.URL(getClass().getResource(_subdir + "/" + "fog.png"), "fog.png");
            _ifog = javax.imageio.ImageIO.read(url);

            url = new java.net.URL(getClass().getResource(_subdir + "/" + "obstacle.png"), "obstacle.png");
            _iobstacle = javax.imageio.ImageIO.read(url);

            url = new java.net.URL(getClass().getResource(_subdir + "/" + "unknown.png"), "unknown.png");
            _iunknown = javax.imageio.ImageIO.read(url);

        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
    }

    /**
     * @return the media manager instance
     */
    public static MediaManager getInstance()
    {
        if (instance == null)
            instance = new MediaManager();
        return instance;
    }

    /**
     * Method to get an Image by type.
     * 
     * @param type
     *            the image type (e.g. red_agent)
     * @return the Image connected to this type
     */
    public Image getImage(String type)
    {
        // Unfortunately, switch statements over a string are java 7 only
        // We could use enums, but this would be complicated as well

        if (type == null)
            return null;

        if (type.equalsIgnoreCase("fog"))
            return _ifog;
        if (type.equalsIgnoreCase("unknown"))
            return _iunknown;
        if (type.equalsIgnoreCase("grass"))
            return _igrass;
        if (type.equalsIgnoreCase("red_agent"))
            return _ired_agent;
        if (type.equalsIgnoreCase("blue_agent"))
            return _iblue_agent;
        if (type.equalsIgnoreCase("cow"))
            return _icow;
        if (type.equalsIgnoreCase("red_stable"))
            return _ired_stable;
        if (type.equalsIgnoreCase("blue_stable"))
            return _iblue_stable;
        if (type.equalsIgnoreCase("switch"))
            return _iswitch;
        if (type.equalsIgnoreCase("fence"))
            return _ifence;
        if (type.equalsIgnoreCase("fenceopen"))
            return _ifenceopen;
        if (type.equalsIgnoreCase("tree"))
            return _itree;
        if (type.equalsIgnoreCase("obstacle"))
            return _iobstacle;
        if (type.equalsIgnoreCase("agent"))
            return _iagent;
        // Not found?
        return null;
    }
}
