/**
 * Contains the classes and interfaces needed for the MASSim-Review GUI. 
 * The MASSim Reviewer can be launched as a stand alone application.
 */
package ch.bfh.massim.testsuite.review;