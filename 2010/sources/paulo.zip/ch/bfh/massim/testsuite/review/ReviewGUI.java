package ch.bfh.massim.testsuite.review;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.ButtonGroup;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import org.xml.sax.SAXException;

/**
 * Class to represent the MASSim-Review GUI. This class is used as a container
 * for several panels needed to manage a list of games. This class provides
 * methods to get and set layouts and content.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class ReviewGUI extends JFrame
{

    private static final long serialVersionUID = 525427298748235331L;

    private JFrame _mainwin;

    private JPanel _left;
    private AddListener _addlistener;
    private RemoveListener _removelistener;

    private JScrollPane _leftscrolllist;
    private DefaultListModel _leftListModel;
    private GameSelectionChangedListener _gsclistener;
    private JList _gamelist;
    private JButton _addgame;
    private JButton _removegame;
    private GraphicPanel[][] _map;
    private int _fieldwidth;
    private int _fieldheight;
    private int _round;
    private int _rounds;
    private String _gamename;
    private String _simname;
    private String _team0;
    private String _team1;

    private JPanel _center;
    private JTabbedPane _centertabbed;

    private JPanel _statistictab;
    private JLabel _lteamaname;
    private JLabel _lteambname;
    private JLabel _lgamename;
    private JLabel _lsimname;
    private JLabel _laaverage;
    private JLabel _lbaverage;
    private JLabel _lacows;
    private JLabel _lbcows;
    private JLabel _lwinner;
    private JLabel _lstarttime;
    private JLabel _lendtime;
    private JLabel _lplaytime;

    private JPanel _replaytab;
    private JPanel _field;
    private JPanel _playcontrols;
    private JButton _play;
    private JButton _forward;
    private JButton _backward;
    private JButton _gotoround;
    private ImageIcon _iplay;
    private ImageIcon _ipause;
    private ImageIcon _iforward;
    private ImageIcon _ibackward;
    private JTextField _roundfield;
    private PlayButtonListener _playblistener;
    private ForwardButtonListener _fwblistener;
    private BackwardButtonListener _bwblistener;
    private GoButtonListener _goblistener;
    private SliderChangeListener _sclistener;
    private Timer _steptimer;
    private UpdateTask _updater;
    private int _speed;

    private JSlider _replayspeed;
    private boolean _playing;

    private boolean _useteamA;
    private boolean _useteamB;
    private boolean _useroundlogs;
    private JCheckBox _fogofwar;
    private boolean _showfow;
    private ButtonGroup _source;
    private JRadioButton _steamA;
    private JRadioButton _steamB;
    private JRadioButton _sgamelog;

    private JPanel _right;
    private PathTitleItem _pti;
    private HerdTitleItem _hti;
    private JPanel _rightcontainer;
    private JScrollPane _rightscrolllist;

    private XMLLogParser _logparser;
    private XMLStatisticParser _statparser;
    private String[][][] _gobjectmap;
    private int[][][] _fogmap;

    /**
     * Default Constructor.
     */
    public ReviewGUI()
    {
        _mainwin = this;
        this._round = 1;
        _gamename = "";
        _simname = "";

        // Prepare the content
        setupLeftList();
        setupCenterPane();
        setupRightList();

        setButtonState(false);

        // Set the layout
        this.setLayout(new BorderLayout());

        // add the components, then go
        this.add(_left, BorderLayout.WEST);
        this.add(_center, BorderLayout.CENTER);
        this.add(_right, BorderLayout.EAST);

        repaint();
    }

    /**
     * Method to prepare the game list on the left side. Creates the left
     * JPanel.
     */
    private void setupLeftList()
    {
        _left = new JPanel();
        JPanel lcontrols = new JPanel();

        _gsclistener = new GameSelectionChangedListener();

        // Setup an item list with single selection mode
        _leftListModel = new DefaultListModel();
        _gamelist = new JList(_leftListModel);
        _gamelist.addListSelectionListener(_gsclistener);
        _gamelist.setFixedCellHeight(20);
        _gamelist.setFixedCellWidth(200);
        _gamelist.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // Set up a scroll list, so we can scroll in the game list
        _leftscrolllist = new JScrollPane(_gamelist);
        _leftscrolllist.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        _leftscrolllist.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        _leftscrolllist.setOpaque(false);

        // Add the add and remove game buttons with the corresponding action
        // listeners
        _addgame = new JButton("Add");
        _addlistener = new AddListener();
        _addgame.addActionListener(_addlistener);
        _removegame = new JButton("Remove");
        _removelistener = new RemoveListener();
        _removegame.addActionListener(_removelistener);
        _removegame.setEnabled(false);
        lcontrols.add(_addgame);
        lcontrols.add(_removegame);

        // Layout and size
        _left.setLayout(new BoxLayout(_left, BoxLayout.Y_AXIS));
        _left.setSize(190, 500);
        _left.setMinimumSize(new Dimension(240, 100));
        _leftscrolllist.setSize(240, 420);
        lcontrols.setMaximumSize(new Dimension(270, 20));

        // add the scroll list and the buttons to our left Panel
        _left.add(_leftscrolllist);
        _left.add(lcontrols);
        lcontrols.add(_addgame);
        lcontrols.add(_removegame);
    }

    /**
     * Method to prepare the tabbed view in the center. Creates the center
     * JPanel.
     */
    private void setupCenterPane()
    {
        _center = new JPanel();
        _centertabbed = new JTabbedPane();

        _center.setSize(600, 450);

        setupStatisticTab();
        setupReplayTab();

        _center.setLayout(new BoxLayout(_center, BoxLayout.Y_AXIS));
        _center.add(_centertabbed);
    }

    /**
     * Method to prepare the object list on the right side. Creates the right
     * JPanel.
     */
    private void setupRightList()
    {

        this._pti = new PathTitleItem(this);
        this._hti = new HerdTitleItem(this);
        _right = new JPanel();
        _rightcontainer = new JPanel();
        _rightcontainer.setLayout(new BoxLayout(_rightcontainer, BoxLayout.Y_AXIS));

        // Set up a scroll list, so we can scroll in the displayable list

        _rightscrolllist = new JScrollPane(_rightcontainer);
        _rightscrolllist.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        _rightscrolllist.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        _rightscrolllist.setOpaque(false);

        _right.setLayout(new BoxLayout(_right, BoxLayout.Y_AXIS));

        _right.setSize(260, 500);
        _right.setMinimumSize(new Dimension(260, 100));
        _rightscrolllist.setMinimumSize(new Dimension(260, 550));

        // add the scroll list
        _right.add(_rightscrolllist);
        updateRightList(false);

    }

    /**
     * Method to create and add the statistics tab to centertabbed.
     */
    private void setupStatisticTab()
    {
        _statistictab = new JPanel();
        _statistictab.setSize(580, 420);

        _lteamaname = new JLabel();
        _lteambname = new JLabel();
        _lgamename = new JLabel();
        _lsimname = new JLabel();
        _laaverage = new JLabel();
        _lbaverage = new JLabel();
        _lacows = new JLabel();
        _lbcows = new JLabel();
        _lwinner = new JLabel();
        _lstarttime = new JLabel();
        _lendtime = new JLabel();
        _lplaytime = new JLabel();

        _statistictab.setLayout(new GridLayout(6, 5));

        _statistictab.add(new JLabel("Game:"));
        _statistictab.add(_lgamename);
        _statistictab.add(new JLabel(" "));
        _statistictab.add(new JLabel("Simulation:"));
        _statistictab.add(_lsimname);

        _statistictab.add(new JLabel("From:"));
        _statistictab.add(_lstarttime);
        _statistictab.add(new JLabel("           To"));
        _statistictab.add(_lendtime);
        _statistictab.add(_lplaytime);

        _statistictab.add(new JLabel("Winner:"));
        _statistictab.add(_lwinner);
        _statistictab.add(new JLabel(""));
        _statistictab.add(new JLabel(""));
        _statistictab.add(new JLabel(""));

        _statistictab.add(new JLabel("Team:"));
        _statistictab.add(_lteamaname);
        _statistictab.add(new JLabel(""));
        _statistictab.add(new JLabel("Team:"));
        _statistictab.add(_lteambname);

        _statistictab.add(new JLabel("Cows:"));
        _statistictab.add(_lacows);
        _statistictab.add(new JLabel(""));
        _statistictab.add(new JLabel("Cows:"));
        _statistictab.add(_lbcows);

        _statistictab.add(new JLabel("Average cows:"));
        _statistictab.add(_laaverage);
        _statistictab.add(new JLabel(""));
        _statistictab.add(new JLabel("Average cows:"));
        _statistictab.add(_lbaverage);

        String tooltip = "<html>Game Statistics:<br>";
        tooltip += "- See brief statistics of the game played<br>";
        tooltip += "- Compare team results";
        tooltip += "</html>";
        _centertabbed.addTab("Game Statistics", null, _statistictab, tooltip);
    }

    /**
     * Method to create and add the replay tab to centertabbed.
     */
    private void setupReplayTab()
    {
        _replaytab = new JPanel();
        _replaytab.setLayout(new BorderLayout());

        _steptimer = new Timer();
        _updater = new UpdateTask();

        _field = new JPanel();
        _field.setMinimumSize(new Dimension(650, 400));
        _field.setMaximumSize(new Dimension(1200, 1200));

        JPanel controlpart = new JPanel();
        controlpart.setLayout(new BoxLayout(controlpart, BoxLayout.Y_AXIS));
        controlpart.setMaximumSize(new Dimension(1200, 80));
        controlpart.setMinimumSize(new Dimension(400, 80));
        controlpart.setPreferredSize(new Dimension(400, 80));

        JPanel options = new JPanel();
        options.setAlignmentX(Component.CENTER_ALIGNMENT);
        options.setMinimumSize(new Dimension(440, 30));
        options.setPreferredSize(new Dimension(440, 30));
        options.setMaximumSize(new Dimension(440, 30));

        _source = new ButtonGroup();
        _sgamelog = new JRadioButton("MASSim", true);
        _steamA = new JRadioButton("Team A");
        _steamB = new JRadioButton("Team B");

        _source.add(_sgamelog);
        _source.add(_steamA);
        _source.add(_steamB);

        _sgamelog.addChangeListener(new SourceChangeListener());
        _steamA.addChangeListener(new SourceChangeListener());
        _steamB.addChangeListener(new SourceChangeListener());

        options.add(new JLabel("Source:"));

        options.add(_sgamelog);
        options.add(_steamA);
        options.add(_steamB);

        _fogofwar = new JCheckBox("Fog", false);
        _fogofwar.addItemListener(new ItemListener()
        {
            public void itemStateChanged(ItemEvent e)
            {
                _showfow = (e.getStateChange() == ItemEvent.SELECTED);
                if (!_useroundlogs)
                {
                    updateFieldView();
                    redrawField();
                }
            }
        });

        options.add(_fogofwar);

        _playcontrols = new JPanel();
        _playcontrols.setMaximumSize(new Dimension(1200, 50));
        _playcontrols.setMinimumSize(new Dimension(300, 50));

        // Button Icons
        try
        {
            URL ipl = new java.net.URL(getClass().getResource("img/buttons/play.png"), "play.png");
            _iplay = new ImageIcon(ipl);

            URL ips = new java.net.URL(getClass().getResource("img/buttons/pause.png"), "pause.png");
            _ipause = new ImageIcon(ips);

            URL ifw = new java.net.URL(getClass().getResource("img/buttons/fwd.png"), "fwd.png");
            _iforward = new ImageIcon(ifw);

            URL ibw = new java.net.URL(getClass().getResource("img/buttons/bwd.png"), "bwd.png");
            _ibackward = new ImageIcon(ibw);

        }
        catch (Exception e)
        {
            String message = "Image loading failed";
            String where = "Player Control Button Initialisation";
            String possol = "Check whether the img/buttons/ folder exists";

            showErrorDialog(message, where, possol, e);
        }

        _play = new JButton(_iplay);
        _forward = new JButton(_iforward);
        _backward = new JButton(_ibackward);

        _playblistener = new PlayButtonListener();
        _fwblistener = new ForwardButtonListener();
        _bwblistener = new BackwardButtonListener();

        _play.addActionListener(_playblistener);
        _forward.addActionListener(_fwblistener);
        _backward.addActionListener(_bwblistener);

        _gotoround = new JButton("Go");
        _goblistener = new GoButtonListener();
        _gotoround.addActionListener(_goblistener);
        _roundfield = new JTextField("1");
        _roundfield.setPreferredSize(new Dimension(45, 27));

        int Speed_Min = -20;
        int Speed_Max = 20;
        int Speed_Init = 0; // initial speed

        _replayspeed = new JSlider(JSlider.HORIZONTAL, Speed_Min, Speed_Max, Speed_Init);
        _replayspeed.setPreferredSize(new Dimension(85, 48));
        _replayspeed.setMaximumSize(new Dimension(400, 48));
        _replayspeed.setMinimumSize(new Dimension(85, 48));
        _sclistener = new SliderChangeListener();
        _replayspeed.addChangeListener(_sclistener);
        _speed = Speed_Init;

        // Turn on tick marks, so that only steps of delta 1 are possible
        _replayspeed.setMajorTickSpacing(1);
        _replayspeed.setMinorTickSpacing(1);
        _replayspeed.setPaintTicks(false);
        _replayspeed.setSnapToTicks(true);

        _playcontrols.add(_backward);
        _playcontrols.add(_play);
        _playcontrols.add(_forward);

        _playcontrols.add(new JLabel(" Round: "));
        _playcontrols.add(_roundfield);
        _playcontrols.add(_gotoround);

        _playcontrols.add(new JLabel(" Speed: "));
        _playcontrols.add(_replayspeed);

        controlpart.add(options);
        controlpart.add(_playcontrols);

        _replaytab.add(controlpart, BorderLayout.SOUTH);
        _replaytab.add(_field, BorderLayout.CENTER);

        String tooltip = "<html>Game Replay:<br>";
        tooltip += "- Replays the game round per round<br>";
        tooltip += "- It's possible to jump to a specific round";
        tooltip += "</html>";
        _centertabbed.addTab("Game Replay", null, _replaytab, tooltip);
    }

    /**
     * Method to go to the next round. Checks first whether a next round is
     * available, then loads it.
     */
    public void nextRound()
    {

        if (_round == _rounds)
        {
            setPlaying(false);
            String message = "Last round reached";
            String title = "Information: Last round reached";
            int type = JOptionPane.INFORMATION_MESSAGE;
            JOptionPane.showMessageDialog(_mainwin, message, title, type);
            return;
        }
        else
        {
            _round++;
            _roundfield.setText(String.valueOf(_round));
            redrawField();
        }
    }

    /**
     * Method to go to the previous round. Checks first whether a next round is
     * available, then loads it.
     */
    public void previousRound()
    {
        if (_round <= 1)
        {
            setPlaying(false);
            String message = "First round reached";
            String title = "Information: First round reached";
            int type = JOptionPane.INFORMATION_MESSAGE;
            JOptionPane.showMessageDialog(_mainwin, message, title, type);
            return;
        }
        else
        {
            _round--;
            _roundfield.setText(String.valueOf(_round));
            redrawField();
        }
    }

    /**
     * Method to go to a specified round.
     * 
     * @param round
     *            the round which should be loaded.
     */
    public void gotoRound(int round)
    {
        if (round <= 0 || round > _rounds)
        {
            _playing = false;
            String message = "Invalid round number";
            String title = "Information: invalid round number";
            int type = JOptionPane.INFORMATION_MESSAGE;
            JOptionPane.showMessageDialog(_mainwin, message, title, type);
            return;
        }
        else
        {
            this._round = round;
            redrawField();
        }
    }

    /**
     * Method which creates the field after loading a game. Sets the width and
     * height and loads the first round.
     */
    public void recreateField()
    {
        _field.removeAll();
        _field.repaint();

        try
        {
            _logparser = new XMLLogParser("logs", _gamename, _simname, "game", "round", "map");

        }
        catch (SAXException e)
        {
            setPlaying(false);
            String message = "XML parsing failed";
            String where = "Load initial game state";
            String possol = "Contact the developers";
            showErrorDialog(message, where, possol, e);
            return;
        }
        catch (IOException e)
        {
            setPlaying(false);
            String message = "Log file loading failed";
            String where = "Load initial game state";
            String possol = "Check whether logs for this game exist";
            showErrorDialog(message, where, possol, e);
            return;
        }

        _fieldwidth = _logparser.getSizex();
        _fieldheight = _logparser.getSizey();
        _rounds = _logparser.getNumber_of_steps();
        _team0 = _logparser.getTeamname0();
        _team1 = _logparser.getTeamname1();

        _map = new GraphicPanel[_fieldwidth][_fieldheight];
        _gobjectmap = _logparser.getGameobjects();

        _field.setLayout(new GridLayout(_fieldwidth, _fieldheight));

        for (int i = 0; i < _fieldwidth; i++)
        {
            for (int j = 0; j < _fieldheight; j++)
            {
                _map[j][i] = new GraphicPanel(null);
                _field.add(_map[j][i]);
            }
        }

        setImmutables();
        redrawField();

        repaint(10);

        setButtonState(true);
    }

    /**
     * Method to redraw the changed objects of the whole field.
     */
    public void redrawField()
    {
        updateFieldView();

        updateFieldObjects();

        updateFieldDisplays();

        for (int i = 0; i < _fieldwidth; i++)
        {
            for (int j = 0; j < _fieldheight; j++)
            {
                _map[i][j].paintChangedComponent();
            }
        }

    }

    /**
     * Method to force redraw the whole field.
     */
    public void forceRedrawField()
    {
        updateFieldView();

        updateFieldObjects();

        updateFieldDisplays();

        for (int i = 0; i < _fieldwidth; i++)
        {
            for (int j = 0; j < _fieldheight; j++)
            {
                _map[i][j].repaint();
            }
        }
    }

    /**
     * Method to set immutable objects, only called once per map load.
     */
    public void setImmutables()
    {

        if (_logparser == null)
            return;

        try
        {
            _gobjectmap = _logparser.getRoundLogContent(1, 1);
        }
        catch (SAXException e)
        {
            setPlaying(false);
            String message = "XML parsing failed";
            String where = "Set fixed field objects from gamelog, round 1";
            String possol = "Contact the developers";

            showErrorDialog(message, where, possol, e);
            return;
        }
        catch (IOException e)
        {
            setPlaying(false);
            String message = "Log file loading failed";
            String where = "Set fixed field objects from gamelog, round 1";
            String possol = "Check whether a log file for this round exists";
            showErrorDialog(message, where, possol, e);
            return;
        }

        for (int i = 0; i < _fieldwidth; i++)
        {
            for (int j = 0; j < _fieldheight; j++)
            {
                // set initial fog
                _map[i][j].setDrawFog(_showfow);

                String object = _gobjectmap[0][i][j];

                if (object == null)
                {
                    _map[i][j].updateType("grass");
                    continue;
                }
                else if (object.equalsIgnoreCase("tree"))
                {
                    _map[i][j].updateType("tree");
                    _map[i][j].setMutable(false);
                    continue;
                }
            }
        }

    }

    /**
     * Method to update the list on the right.
     * 
     * @param recreate
     *            whether the list should be forced to be recreated.
     */
    public void updateRightList(boolean recreate)
    {
        _rightcontainer.removeAll();
        _rightcontainer.add(_pti);

        // Needed, as neither A nor B is possible
        String teamname = "";

        if (_useteamA)
            teamname = "A";
        else if (_useteamB)
            teamname = "B";

        if (recreate)
        {
            if (teamname.equals(""))
            {
                _pti.setDirectory("");
                _pti.createList();
            }
            else
            {
                _pti.setDirectory("logs/" + _gamename + "/" + _simname + "/path/" + teamname);
                _pti.createList();
            }
        }

        for (IRightBodyItem item : _pti.getAllItems())
        {
            if (item instanceof PathBodyItem)
                _rightcontainer.add((PathBodyItem) item);
        }

        _rightcontainer.add(_hti);
        if (recreate)
        {
            if (teamname.equals(""))
            {
                _hti.setDirectory("");
                _hti.createList();
            }
            else
            {
                _hti.setDirectory("logs/" + _gamename + "/" + _simname + "/herd/" + teamname);
                _hti.createList();
            }
        }

        for (IRightBodyItem item : _hti.getAllItems())
        {
            if (item instanceof HerdBodyItem)
                _rightcontainer.add((HerdBodyItem) item);
        }

        _rightcontainer.updateUI();

        redrawField();
    }

    /**
     * Method which updates the fieldObjects from the selected XML Logsource.
     */
    private void updateFieldObjects()
    {

        if (_logparser == null)
            return;

        try
        {
            if (_useroundlogs)
                _gobjectmap = _logparser.getRoundLogContent(_round, _round);
            else if (_useteamA)
                _gobjectmap = _logparser.getMapLogContent(_team0, _round, _round);
            else if (_useteamB)
                _gobjectmap = _logparser.getMapLogContent(_team1, _round, _round);
        }
        catch (SAXException e)
        {
            setPlaying(false);
            String message = "XML parsing failed";
            String where = "Update field objects from gamelog";
            String possol = "Contact the developers";

            showErrorDialog(message, where, possol, e);
            return;
        }
        catch (IOException e)
        {
            setPlaying(false);
            String message = "Log file loading failed";
            String where = "Update field objects from gamelog";
            String possol = "Check whether a log file for this round exists";
            showErrorDialog(message, where, possol, e);
            return;
        }

        for (int i = 1; i < _fieldwidth - 1; i++)
        {
            for (int j = 1; j < _fieldheight - 1; j++)
            {
                String object = _gobjectmap[0][i][j];

                if (object == null)
                {
                    _map[i][j].updateType("grass");
                    continue;
                }
                if (object.equalsIgnoreCase("unknown"))
                {
                    _map[i][j].updateType("unknown");
                    continue;
                }
                if (object.equalsIgnoreCase("grass") || object.equalsIgnoreCase("empty"))
                {
                    _map[i][j].updateType("grass");
                    continue;
                }
                else if (object.equalsIgnoreCase("tree"))
                {
                    _map[i][j].updateType("tree");
                    _map[i][j].setMutable(false);
                    continue;
                }
                else if (object.equalsIgnoreCase("cow"))
                {
                    _map[i][j].updateType("cow");
                    continue;
                }
                else if (object.equalsIgnoreCase("agent0"))
                {
                    _map[i][j].updateType("red_agent");
                    continue;
                }
                else if (object.equalsIgnoreCase("agent1"))
                {
                    _map[i][j].updateType("blue_agent");
                    continue;
                }
                if (object.equalsIgnoreCase("stable1"))
                {
                    _map[i][j].updateType("red_stable");
                    continue;
                }
                else if (object.equalsIgnoreCase("stable2"))
                {
                    _map[i][j].updateType("blue_stable");
                    continue;
                }
                else if (object.equalsIgnoreCase("switch"))
                {
                    _map[i][j].updateType("switch");
                    continue;
                }
                else if (object.equalsIgnoreCase("fence"))
                {
                    _map[i][j].updateType("fence");
                    continue;
                }
                else if (object.equalsIgnoreCase("fenceopen"))
                {
                    _map[i][j].updateType("fenceopen");
                    continue;
                }
                else if (object.equalsIgnoreCase("obstacle"))
                {
                    _map[i][j].updateType("obstacle");
                    continue;
                }
            }
        }
    }

    /**
     * Method to set all buttons to a given state. Useful if we want do
     * deacitave all buttons, e.g. when no game is loaded.
     * 
     * @param state
     *            the state the buttons should be in. true = enabled, false =
     *            disabled.
     */
    private void setButtonState(boolean state)
    {
        _play.setEnabled(state);
        _forward.setEnabled(state);
        _backward.setEnabled(state);
        _gotoround.setEnabled(state);
        _replayspeed.setEnabled(state);
        _fogofwar.setEnabled(state);
        _sgamelog.setEnabled(state);
        _steamA.setEnabled(state);
        _steamB.setEnabled(state);
    }

    /**
     * Method to update the fog of war for the game field.
     */
    private void updateFieldView()
    {

        if (_logparser == null)
            return;

        // Simple case: FoW disabled after being enabled, just disable fog for
        // each field
        if (!_showfow || _useroundlogs)
        {
            for (int i = 0; i < _fieldwidth; i++)
            {
                for (int j = 0; j < _fieldheight; j++)
                {
                    _map[i][j].setDrawFog(false);
                }
            }
            return;
        }

        try
        {
            if (_useteamA)
                _fogmap = _logparser.getMapLogViewstate(_team0, _round, _round);
            else if (_useteamB)
                _fogmap = _logparser.getMapLogViewstate(_team1, _round, _round);
        }
        catch (SAXException e)
        {
            setPlaying(false);
            String message = "XML parsing failed";
            String where = "Update fog of war from map agent";
            String possol = "Contact the developers";

            showErrorDialog(message, where, possol, e);
            return;
        }
        catch (IOException e)
        {
            setPlaying(false);
            String message = "Log file loading failed";
            String where = "Update fog of war from map agent";
            String possol = "Check whether a map agent log file for this round exists";
            showErrorDialog(message, where, possol, e);
            return;
        }

        if (_fogmap == null)
            return;

        for (int i = 0; i < _fieldwidth; i++)
        {
            for (int j = 0; j < _fieldheight; j++)
            {

                int fieldstate = _fogmap[0][i][j];
                if (fieldstate <= -1)
                {
                    _map[i][j].setIntensity(1.0f);
                }
                else if (fieldstate < (_round))
                {
                    _map[i][j].setIntensity(0.5f);
                }
                else if (fieldstate == (_round))
                {
                    _map[i][j].setIntensity(0.0f);
                    _map[i][j].setSeen(true);
                }
                _map[i][j].setDrawFog(_showfow);
                _map[i][j].setFogcolor(new Color(0, 0, 0));
            }
        }

    }

    /**
     * Method to update the statistics tab.
     */
    private void updateStatistics()
    {
        try
        {
            _statparser = new XMLStatisticParser("logs", _gamename, _simname, "game");
            _lgamename.setText(_statparser.getGamename());
            _lsimname.setText(_statparser.getSimname());

            _lstarttime.setText(String.valueOf(_statparser.getFromtime()));
            _lendtime.setText(String.valueOf(_statparser.getTotime()));
            _lplaytime.setText("Total: " + String.valueOf(_statparser.getTotaltime()));

            _lteamaname.setText(_statparser.getTeamaname());
            _lteamaname.setForeground(_statparser.getAcolor());
            _lteambname.setText(_statparser.getTeambname());
            _lteambname.setForeground(_statparser.getBcolor());

            String winner = _statparser.getGamewinner();
            _lwinner.setForeground(new Color(0, 0, 0));

            if (winner.equals(_lteamaname.getText()))
                _lwinner.setForeground(_statparser.getAcolor());
            else if (winner.equals(_lteambname.getText()))
                _lwinner.setForeground(_statparser.getBcolor());
            _lwinner.setText(winner);

            _lacows.setText(String.valueOf(_statparser.getAcows()));
            _lbcows.setText(String.valueOf(_statparser.getBcows()));

            _laaverage.setText(String.valueOf(_statparser.getAaverage()));
            _lbaverage.setText(String.valueOf(_statparser.getBaverage()));

        }
        catch (SAXException e)
        {
            String message = "XML parsing failed";
            String where = "Load statistics";
            String possol = "Contact the developers";
            showErrorDialog(message, where, possol, e);
            return;
        }
        catch (IOException e) // should not happen, here we check for it
        {
            String message = "Log file loading failed";
            String where = "Load statistics";
            String possol = "Check whether logs for this game exist";
            showErrorDialog(message, where, possol, e);
            return;
        }

    }

    /**
     * Method to update the additional things to display.
     */
    private void updateFieldDisplays()
    {
        for (Component comp : _rightcontainer.getComponents())
        {
            if (comp instanceof IRightBodyItem)
            {
                IRightBodyItem it = (IRightBodyItem) comp;
                if (it.isActivated())
                    _map = it.updateMap(_map, _round);
            }

        }
    }

    /**
     * Method to get all simulations of a game.
     * 
     * @param gamename
     *            the game we want the simulations from
     * @return a list of simulations
     */
    private ArrayList<String> getSimulations(String gamename)
    {
        File folder = new File("logs/" + gamename);
        File[] listOfFolders = folder.listFiles();

        ArrayList<String> folders = new ArrayList<String>();

        if (listOfFolders == null)
        {
            String error = "No game found";
            String where = "getSimulations";
            String possol = "Make sure the folder " + gamename + " exists";
            this.showErrorDialog(error, where, possol, null);
            return null;
        }

        for (int i = 0; i < listOfFolders.length; i++)
        {
            // Files only, no directories
            if (listOfFolders[i].isDirectory())
            {
                if (listOfFolders[i].getName().startsWith("sim"))
                {
                    folders.add(gamename + "-" + listOfFolders[i].getName().substring(3));
                }
            }
        }

        return folders;
    }

    /**
     * Method to change to a new game.
     * 
     * @param gamename
     *            name of the game
     */
    private void newGame(String gamename, String simname)
    {
        if (this._gamename.equals(gamename) && this._simname.equals(simname))
            return;
        else
        {
            this._gamename = gamename;
            this._simname = simname;
            this._round = 1;
            this._roundfield.setText("1");
            updateStatistics();
            updateRightList(true);
            recreateField();
            try
            {
                Thread.sleep(1000);
            }
            catch (InterruptedException e)
            {
            }
        }
    }

    /**
     * Method to update the step timer.
     */
    public void updateTimer()
    {
        if (!_playing)
        {
            _updater.cancel();
        }
        else
        {
            // We allow steps of 500ms in both sides, so
            // slider at max == 10500 - (20 * 500) -> 0.5 seconds per step
            // slider at min == 10500 - (1 * 500) -> 10 seconds per step
            // in both directions, so steps are either backward or forward
            int delay = (4200 - (Math.abs(_speed)) * 200);
            _updater.cancel();
            _updater = new UpdateTask();
            _steptimer.schedule(_updater, delay, delay);
        }
    }

    /**
     * Method to add games to the game list.
     * 
     * @param gname
     *            game name, which is also the foldername in $logdir
     */
    public void addGame(String gname)
    {
        int index = _gamelist.getSelectedIndex(); // get selected index
        if (index == -1)
        { // no selection, so insert at beginning
            index = 0;
        }
        else
        { // add after the selected item
            index++;
        }

        ArrayList<String> simulations = getSimulations(gname);

        if (simulations == null)
            return;

        for (String simu : simulations)
        {
            _leftListModel.insertElementAt(simu, index);
        }

        if (_leftListModel.getSize() > 0)
            // We have new games, re-enable the button
            _removegame.setEnabled(true);
    }

    /**
     * Method for a pretty error message with debug information.
     * 
     * @param error
     *            The error occurred, according to us
     * @param where
     *            The position it occurred. Method name as an example.
     * @param possol
     *            A possible solution for the user
     * @param e
     *            The exception thrown, .message() will be printed
     */
    public void showErrorDialog(String error, String where, String possol, Exception e)
    {
        String title = "A problem ocurred in the application";
        int type = JOptionPane.ERROR_MESSAGE;
        String spacer = "------------------------------";

        String first = "We are sorry, but a problem occurred in the application.";

        String desc = "Problem description:";
        String solve = "You could try the following possible solution:";
        String debinf = "Please give this information to the developers:";
        String loc = "The problem occurred at:";

        String message = first + "\n\n" + desc + "\n" + error;
        message += "\n" + spacer + "\n";
        message += solve + "\n" + possol + "\n" + spacer + "\n";
        message += debinf + "\n" + loc + "\n" + where + "\n";
        if (e != null)
            message += "Additional Info: \n" + e.getMessage();

        JOptionPane.showMessageDialog(_mainwin, message, title, type);
    }

    /*
     * *************************** Getter / Setter ***************************
     */

    /**
     * @return whether we are in playback mode
     */
    public boolean getPlaying()
    {
        return _playing;
    }

    /**
     * @param playing
     *            whether we are in playback mode
     */
    public void setPlaying(boolean playing)
    {
        if (playing)
        {
            this._playing = true;
            _play.setIcon(_ipause);
        }
        else
        {
            this._playing = false;
            _play.setIcon(_iplay);
        }

        updateTimer();
    }

    /**
     * @return whether team A is used as source
     */
    public boolean isUseteamA()
    {
        return _useteamA;
    }

    /**
     * @return whether team B is used as source
     */
    public boolean isUseteamB()
    {
        return _useteamB;
    }

    /**
     * Inner Class for the Play/Pause Button.
     * 
     * @author Christian Loosli & Adrian Pauli
     * 
     */
    class PlayButtonListener implements ActionListener
    {
        public void actionPerformed(ActionEvent event)
        {
            setPlaying(!_playing);
        }
    }

    /**
     * Inner Class for the Forward Button.
     * 
     * @author Christian Loosli & Adrian Pauli
     * 
     */
    class ForwardButtonListener implements ActionListener
    {
        public void actionPerformed(ActionEvent event)
        {
            nextRound();
        }
    }

    /**
     * Inner Class for the Backward Button.
     * 
     * @author Christian Loosli & Adrian Pauli
     * 
     */
    class BackwardButtonListener implements ActionListener
    {
        public void actionPerformed(ActionEvent event)
        {
            previousRound();
        }
    }

    /**
     * Inner Class for the Go Button.
     * 
     * @author Christian Loosli & Adrian Pauli
     * 
     */
    class GoButtonListener implements ActionListener
    {
        public void actionPerformed(ActionEvent event)
        {
            String round = _roundfield.getText();
            try
            {
                int gtround = Integer.parseInt(round);
                gotoRound(gtround);
            }
            catch (NumberFormatException e)
            {
                String message = "Invalid round number";
                String title = "Information: invalid round number";
                int type = JOptionPane.INFORMATION_MESSAGE;
                JOptionPane.showMessageDialog(_mainwin, message, title, type);
                return;
            }
        }
    }

    /**
     * Inner class for the add button
     * 
     * @author Christian Loosli & Adrian Pauli
     */
    class AddListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            JFileChooser fc = new JFileChooser();
            fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            File dir = new File("logs/");
            fc.setCurrentDirectory(dir);
            fc.showOpenDialog(_mainwin);

            String name = "";

            File selFile = fc.getSelectedFile();

            if (selFile != null)
            {
                name = selFile.getName();
            }

            addGame(name);
        }
    }

    /**
     * Inner class for the remove button.
     * 
     * @author Christian Loosli & Adrian Pauli
     */
    class RemoveListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            int index = _gamelist.getSelectedIndex();

            _leftListModel.removeElementAt(index);

            int size = _leftListModel.getSize();

            if (size == 0)
            { // Nobody's left, disable remove button
                _removegame.setEnabled(false);
            }
            else
            { // Select an index.
                if (index == _leftListModel.getSize())
                {
                    // removed item in last position
                    index--;
                }

                _gamelist.setSelectedIndex(index);
            }
        }
    }

    /**
     * Listener Class for selection change events in game list.
     * 
     * @author Christian Loosli & Adrian Pauli
     */
    class GameSelectionChangedListener implements ListSelectionListener
    {
        public void valueChanged(ListSelectionEvent evt)
        {
            int index = _gamelist.getSelectedIndex();

            if (_leftListModel.size() > 0 && index >= 0)
            {
                if (_leftListModel.get(index) instanceof String)
                {
                    try
                    {
                        String fullgamename = (String) _leftListModel.get(index);
                        String[] names = fullgamename.split("-");
                        String newgamename = names[0];
                        String simname = "sim" + names[1];
                        newGame(newgamename, simname);
                    }
                    catch (Exception e)
                    {
                        String error = "Failed to load the game";
                        String where = "String splitup";
                        String possol = "Make sure the folder structure in logs is correct";
                        showErrorDialog(error, where, possol, e);
                    }
                }
            }
        }
    }

    /**
     * Inner class for listening to slider changes.
     * 
     * @author Christian Loosli & Adrian Pauli
     * 
     */
    class SliderChangeListener implements ChangeListener
    {
        public void stateChanged(ChangeEvent e)
        {
            JSlider source = (JSlider) e.getSource();
            // Don't react if the user is still adjusting
            if (!source.getValueIsAdjusting())
            {
                _speed = source.getValue();
                updateTimer();
            }
        }
    }

    /**
     * Inner class for source radio box changes.
     * 
     * @author Christian Loosli & Adrian Pauli
     * 
     */
    class SourceChangeListener implements ChangeListener
    {
        public void stateChanged(ChangeEvent e)
        {
            boolean changed = false;

            if (_useroundlogs != _sgamelog.isSelected())
            {
                _useroundlogs = _sgamelog.isSelected();
                changed = true;
            }
            if (_useteamA != _steamA.isSelected())
            {
                _useteamA = _steamA.isSelected();
                changed = true;
            }
            if (_useteamB != _steamB.isSelected())
            {
                _useteamB = _steamB.isSelected();
                changed = true;
            }

            if (changed)
            {
                updateRightList(true);
                redrawField();
            }

        }
    }

    /**
     * Inner Class for the Timer Task for playback mode.
     * 
     * @author Christian Loosli & Adrian Pauli
     * 
     */
    class UpdateTask extends TimerTask
    {
        public void run()
        {
            if (_speed < 0)
            {
                if (_round > 1)
                    previousRound();
            }
            else if (_speed > 0)
            {
                if (_round < _rounds)
                    nextRound();
            }
        }
    }
}
