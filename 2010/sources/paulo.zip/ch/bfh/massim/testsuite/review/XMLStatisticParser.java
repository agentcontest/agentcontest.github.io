package ch.bfh.massim.testsuite.review;

import java.awt.Color;
import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * Class to read XML game informations. This class is used to read statistic
 * information such game length, teams and the game winner out of xml files.
 * This class provides methods to read the information provided as a xml file.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class XMLStatisticParser
{

    private String _gamename;
    private String _simname;
    private String _logdir;
    private String _gamelogdir;

    private String _teamaname;
    private String _teambname;
    private String _gamewinner;
    private Color _acolor;
    private Color _bcolor;

    private final Color RED = new Color(255, 0, 0);
    private final Color BLUE = new Color(0, 0, 255);

    private long _fromtime;
    private long _totime;
    private long _totaltime;
    private int _acows;
    private int _bcows;
    private double _aaverage;
    private double _baverage;

    private DocumentBuilderFactory _dbf;
    private DocumentBuilder _db;

    /**
     * Default constructor.
     * 
     * @param logdir
     *            general logdir
     * @param gamename
     *            game name
     * @param simname
     *            simulation name
     * @param gamelogdir
     *            directory of the report.xml file
     * @throws SAXException
     *             Parser exception
     * @throws IOException
     *             File not found (should be checked though)
     */
    public XMLStatisticParser(String logdir, String gamename, String simname, String gamelogdir) throws SAXException,
            IOException
    {

        _dbf = DocumentBuilderFactory.newInstance();

        try
        {
            _db = _dbf.newDocumentBuilder();
        }
        catch (ParserConfigurationException e)
        {
            System.out.println("94 XML Parser error occured: " + e.getMessage());
        }

        _logdir = logdir;
        _gamename = gamename;
        _simname = simname;
        _gamelogdir = gamelogdir;
        _teamaname = "n/a";
        _teambname = "n/a";
        _gamewinner = "n/a";
        _acolor = RED;
        _bcolor = BLUE;
        _fromtime = 0;
        _totime = 0;
        _totaltime = _totime - _fromtime;
        _acows = 0;
        _bcows = 0;
        _aaverage = 0f;
        _baverage = 0f;

        File file = new File(logdir + "/" + gamename + "/" + gamelogdir + "/report.xml");
        Document doc;

        // Check for not found file, so we can die gracefully here
        if (file == null)
            return;

        if (!file.exists())
            return;

        doc = _db.parse(file);
        doc.getDocumentElement().normalize();

        NodeList teamLst = doc.getElementsByTagName("team");
        {
            for (int s = 0; s < teamLst.getLength(); s++)
            {
                Node fstNode = teamLst.item(s);
                if (fstNode.getNodeType() == Node.ELEMENT_NODE)
                {
                    Element fstElmnt = (Element) fstNode;
                    if (s == 0)
                        _teamaname = fstElmnt.getAttribute("name");
                    else if (s == 1)
                        _teambname = fstElmnt.getAttribute("name");

                }
            }
        }

        NodeList matchLst = doc.getElementsByTagName("match");
        {
            for (int s = 0; s < matchLst.getLength(); s++)
            {
                Node fstNode = matchLst.item(s);
                if (fstNode.getNodeType() == Node.ELEMENT_NODE)
                {
                    Element fstElmnt = (Element) fstNode;
                    String red = fstElmnt.getAttribute("red");

                    if (red.equals(_teamaname))
                    {
                        _acolor = RED;
                        _bcolor = BLUE;
                    }
                    else if (red.equals(_teambname))
                    {
                        _bcolor = RED;
                        _acolor = BLUE;
                    }

                }
            }
        }

        NodeList simLst = doc.getElementsByTagName("simulation");

        for (int s = 0; s < simLst.getLength(); s++)
        {
            Node fstNode = simLst.item(s);
            if (fstNode.getNodeType() == Node.ELEMENT_NODE)
            {
                Element fstElmnt = (Element) fstNode;
                String name = fstElmnt.getAttribute("name");
                String[] split = name.split("-");
                String sname = "";

                if (split.length >= 2)
                {
                    sname = split[1];
                }

                if (sname.equals(simname))
                {
                    _fromtime = Long.parseLong(fstElmnt.getAttribute("starttime"));
                    _totime = Long.parseLong(fstElmnt.getAttribute("endtime"));

                    _totaltime = _totime - _fromtime;
                }
                else
                    continue;
            }
        }

        NodeList resultLst = doc.getElementsByTagName("result");

        for (int s = 0; s < resultLst.getLength(); s++)
        {
            Node fstNode = resultLst.item(s);
            if (fstNode.getNodeType() == Node.ELEMENT_NODE)
            {
                Element fstElmnt = (Element) fstNode;
                String name = fstElmnt.getAttribute("simulation");
                String[] split = name.split("-");
                String sname = "";

                if (split.length >= 2)
                {
                    sname = split[1];
                }

                if (sname.equals(simname))
                {
                    _aaverage = Double.parseDouble(fstElmnt.getAttribute("Aaveragescore"));
                    _baverage = Double.parseDouble(fstElmnt.getAttribute("Baveragescore"));
                    _acows = Integer.parseInt(fstElmnt.getAttribute("Acowsincorral"));
                    _bcows = Integer.parseInt(fstElmnt.getAttribute("Bcowsincorral"));

                    if (_aaverage == _baverage)
                        _gamewinner = "draw";
                    else
                        _gamewinner = (_aaverage > _baverage) ? _teamaname : _teambname;

                }
                else
                    continue;
            }
        }
    }

    /**
     * @return the gamename
     */
    public String getGamename()
    {
        return _gamename;
    }

    /**
     * @return the simname
     */
    public String getSimname()
    {
        return _simname;
    }

    /**
     * @return the general log directory
     */
    public String getLogdir()
    {
        return _logdir;
    }

    /**
     * @return the game log directory
     */
    public String getGamelogdir()
    {
        return _gamelogdir;
    }

    /**
     * @return the name of team a
     */
    public String getTeamaname()
    {
        return _teamaname;
    }

    /**
     * @return the name of team b
     */
    public String getTeambname()
    {
        return _teambname;
    }

    /**
     * @return the name of the winning team
     */
    public String getGamewinner()
    {
        return _gamewinner;
    }

    /**
     * @return the color of team a
     */
    public Color getAcolor()
    {
        return _acolor;
    }

    /**
     * @return the color of team b
     */
    public Color getBcolor()
    {
        return _bcolor;
    }

    /**
     * @return the time the simulation started
     */
    public long getFromtime()
    {
        return _fromtime;
    }

    /**
     * @return the time the simulation ended
     */
    public long getTotime()
    {
        return _totime;
    }

    /**
     * @return the total time played
     */
    public long getTotaltime()
    {
        return _totaltime;
    }

    /**
     * @return the cows in corral a
     */
    public int getAcows()
    {
        return _acows;
    }

    /**
     * @return the cows in corral b
     */
    public int getBcows()
    {
        return _bcows;
    }

    /**
     * @return the average number of cows in corral a
     */
    public double getAaverage()
    {
        return _aaverage;
    }

    /**
     * @return the average number of cows in corral b
     */
    public double getBaverage()
    {
        return _baverage;
    }

}
