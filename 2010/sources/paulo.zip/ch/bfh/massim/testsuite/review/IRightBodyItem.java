package ch.bfh.massim.testsuite.review;

import java.awt.Color;

/**
 * Interface to represent an object as an item in a list. This Interface is used
 * as a container for an object which can be used in lists.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public interface IRightBodyItem
{
    String getUniqueID();

    void setUniqueID(String uniqueID);

    Color getColor();

    GraphicPanel[][] updateMap(GraphicPanel[][] map, int step);

    boolean isActivated();

    void setActivated(boolean activated);
}
