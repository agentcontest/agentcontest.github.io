package ch.bfh.massim.testsuite.review;

import java.awt.Dimension;
import javax.swing.JFrame;

/**
 * Class to start the MASSim-Review This class is used as a main entry point.
 * This class provides a main method.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class ReviewViewer
{
    /**
     * Method used as an entry point. Launches the MASSim-Review GUI.
     * 
     * @param args
     *            game names which should be added at the start
     */
    public static void main(String[] args)
    {
        ReviewGUI maingui = new ReviewGUI();

        maingui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        maingui.setTitle("MASSim-Review");
        maingui.setSize(new Dimension(1200, 720));
        maingui.setMinimumSize(new Dimension(910, 550));

        if (args.length > 0)
        {
            for (int i = 0; i < args.length; i++)
            {
                maingui.addGame(args[i]);
            }
        }

        maingui.setVisible(true);
    }
}
