package ch.bfh.massim.testsuite.review;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.AbstractButton;
import javax.swing.ButtonModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JColorChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import ch.bfh.massim.framework.MapCoordinate;

/**
 * Class to represent a herd as an item in a list. This class is used as a
 * container for a herd, which can be used in lists. This class provides methods
 * to get and set settings and to update a map with the cows in this herd.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class HerdBodyItem extends JPanel implements IRightBodyItem
{

    private static final long serialVersionUID = 4572744672792462552L;
    private String uniqueId;
    private Color _color;
    private JCheckBox _activated;
    private JButton _bcolor;
    private JLabel _id;
    private ReviewGUI _mainGui;
    private String _folder;
    private int _firstround;
    private int _lastround;
    private ArrayList<File> _files;

    /**
     * Default constructor.
     * 
     * @param uniqueID
     *            unique ID, usually team_sx-xy_gx-gy (team_foldername)
     * @param color
     *            color
     * @param activated
     *            whether the path is activated
     * @param folder
     *            folder the path files are in
     * @param mainGui
     *            mainGui using this element
     */
    public HerdBodyItem(String uniqueID, Color color, boolean activated, String folder, ReviewGUI mainGui)
    {
        this.setPreferredSize(new Dimension(240, 30));
        this.setMaximumSize(new Dimension(240, 30));

        this.uniqueId = uniqueID;
        this._color = color;
        this._folder = folder;
        this._mainGui = mainGui;

        this._activated = new JCheckBox();
        this._activated.setSelected(activated);
        this._activated.addChangeListener(new CheckChangeListener());

        this._bcolor = new JButton();
        _bcolor.setIcon(new ColorIcon(color));
        this._bcolor.addActionListener(new ColorListener());
        this._bcolor.setPreferredSize(new Dimension(30, 20));
        this._bcolor.setMinimumSize(new Dimension(30, 20));

        this._id = new JLabel(uniqueID);
        this._id.setPreferredSize(new Dimension(160, 30));
        this._id.setMaximumSize(new Dimension(160, 30));

        this.add(this._activated);
        this.add(_id);
        this.add(this._bcolor);

        this._files = new ArrayList<File>();

        int highest = 0;
        int smallest = -1;

        File root = new File(folder);
        if (root != null)
        {
            _files.addAll(Arrays.asList(root.listFiles()));

            // Unfortunately Java does not sort filenames naturally, so 1000
            // comes before 20

            for (File cf : _files)
            {
                String file = cf.getName();
                String name = file.substring(0, file.indexOf('.'));
                int current = Integer.parseInt(name);
                if (current > highest)
                    highest = current;
                if (current < smallest || smallest < 0)
                    smallest = current;
            }

            this._firstround = smallest;
            this._lastround = highest;
        }
    }

    /**
     * Method to update a given map container with information related to this
     * item. Will open the XML log related to this item and the current step and
     * set the color and alpha value in the corresponding map field.
     * 
     * @param map
     *            the map container used
     * @param step
     *            the current step
     * @return the map updated accordingly
     */
    @Override
    public GraphicPanel[][] updateMap(GraphicPanel[][] map, int step)
    {

        if (map == null)
            return null;
        if (map[1][1] == null)
            return map;
        if (step > _lastround || step < _firstround)
            return map;

        XMLAdditionalParser xp = XMLAdditionalParser.getInstance();

        File file = null;

        for (int i = step; i >= 0; i--)
        {
            file = new File(_folder + "/" + i + ".xml");
            if (file.exists())
            {
                break;
            }
        }

        ArrayList<MapCoordinate> coords = xp.getCells(file);

        if (coords == null)
            return map;

        for (MapCoordinate coord : coords)
        {
            if (coord.isOnMap(map))
            {
                map[coord.getX()][coord.getY()].setFogcolor(_color);
                map[coord.getX()][coord.getY()].setIntensity(0.8f);
                map[coord.getX()][coord.getY()].setDrawFog(true);
            }
        }
        return map;
    }

    /**
     * @return the color set to this item
     */
    @Override
    public Color getColor()
    {
        return _color;
    }

    /**
     * @return the uniqueID of this item
     */
    @Override
    public String getUniqueID()
    {
        return uniqueId;
    }

    /**
     * @param uniqueID
     *            the unique ID of this item
     */
    @Override
    public void setUniqueID(String uniqueID)
    {
        this.uniqueId = uniqueID;

    }

    /**
     * @return whether this item is activated
     */
    @Override
    public boolean isActivated()
    {
        return _activated.isSelected();
    }

    /**
     * Method to set the field activated or not. This does not force a field
     * redraw, take care of it.
     * 
     * @param activated
     *            whether the field should be activated
     */
    public void setActivated(boolean activated)
    {
        this._activated.setSelected(activated);
    }

    /**
     * Inner class for the color button.
     * 
     * @author Christian Loosli & Adrian Pauli
     */
    class ColorListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            Color newcol = JColorChooser.showDialog(_mainGui, "select a color", null);
            if (newcol != null)
            {
                _color = newcol;
                _bcolor.setIcon(new ColorIcon(_color));
                _mainGui.redrawField();
            }
        }
    }

    /**
     * Inner class for listening to checkbox changes.
     * 
     * @author Christian Loosli & Adrian Pauli
     * 
     */
    class CheckChangeListener implements ChangeListener
    {
        public void stateChanged(ChangeEvent e)
        {
            AbstractButton abstractButton = (AbstractButton) e.getSource();
            ButtonModel buttonModel = abstractButton.getModel();
            boolean pressed = buttonModel.isPressed();
            if (pressed)
            {
                _mainGui.redrawField();
            }
        }
    }
}
