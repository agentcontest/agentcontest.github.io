package ch.bfh.massim.testsuite.review;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import ch.bfh.massim.framework.MapCoordinate;

/**
 * Class to read XML game informations. This class is used to read additional
 * information such as herd or paths out of xml files. This class provides
 * methods to read the information provided as a xml file.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class XMLAdditionalParser
{

    private static XMLAdditionalParser instance;
    private DocumentBuilderFactory _dbf;
    private DocumentBuilder _db;

    /**
     * Private Constructor because of the singleton pattern.
     */
    private XMLAdditionalParser()
    {

        _dbf = DocumentBuilderFactory.newInstance();

        try
        {
            _db = _dbf.newDocumentBuilder();
        }
        catch (ParserConfigurationException e)
        {
            System.out.println("94 XML Parser error occured: " + e.getMessage());
        }
    }

    /**
     * Method to get the instance. Use this instead of the constructor.
     * 
     * @return the instance of the additional xml parser
     */
    public static XMLAdditionalParser getInstance()
    {
        if (instance == null)
        {
            instance = new XMLAdditionalParser();
        }

        return instance;
    }

    /**
     * Method to get all cells (paths, herds, ...) out of a xml file.
     * 
     * @param file
     *            the xml file to parse
     * @return a list of coordinates
     */
    public ArrayList<MapCoordinate> getCells(File file)
    {
        ArrayList<MapCoordinate> coordinates = new ArrayList<MapCoordinate>();

        Document doc;

        try
        {
            doc = _db.parse(file);
            doc.getDocumentElement().normalize();
            NodeList nodeLst = doc.getElementsByTagName("cell");

            for (int s = 0; s < nodeLst.getLength(); s++)
            {

                Node fstNode = nodeLst.item(s);

                if (fstNode.getNodeType() == Node.ELEMENT_NODE)
                {

                    Element fstElmnt = (Element) fstNode;
                    int x = Integer.parseInt(fstElmnt.getAttribute("x"));
                    int y = Integer.parseInt(fstElmnt.getAttribute("y"));

                    MapCoordinate coord = new MapCoordinate(x, y);
                    coordinates.add(coord);
                }
            }

            return coordinates;
        }
        catch (SAXException e)
        {
            return null;
        }
        catch (IOException e)
        {
            return null;
        }

    }

}
