package ch.bfh.massim.testsuite.review;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;

import javax.swing.JPanel;

/**
 * Class to represent a a graphic panel with an object and fog of war. This
 * class overrides the paintComponent Method, so a Image (png, jpeg, gif ...) is
 * drawn as the background and overlaid by fog of war afterwards.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
class GraphicPanel extends JPanel
{
    private static final long serialVersionUID = 3921174702773359808L;

    private Image _img;
    private String _type;
    private Color _fogcolor;
    private float _intensity;
    private boolean _changed;
    private boolean _mutable;
    private boolean _seen;
    private boolean _drawfog;

    private MediaManager _mm;

    /**
     * Default constructor.
     * 
     * @param type
     *            The type of content, has to be known by MediaManager
     *            getImage() method
     */
    public GraphicPanel(String type)
    {
        _mm = MediaManager.getInstance();
        _img = _mm.getImage(type);
        _type = type;
        _intensity = 1.0f;
        _mutable = true;
        _drawfog = true;
        _seen = false;
        _changed = true;
        _fogcolor = new Color(0, 0, 0);
    }

    /**
     * Default constructor.
     * 
     * @param type
     *            The type of content, has to be known by MediaManager
     *            getImage() method
     * @param intensity
     *            Fog intensity, 1.0f being completely behind fog, 0.0f
     *            completely visible.
     */
    public GraphicPanel(String type, float intensity)
    {
        this(type);
        this._intensity = intensity;
    }

    /**
     * Default constructor with additional mutable information.
     * 
     * @param type
     *            The type of content, has to be known by MediaManager
     * @param intensity
     *            Fog intensity, 1.0f being completely behind fog, 0.0f
     *            completely visible.
     * @param mutable
     *            Whether an object is mutable. Will never be redrawn and has no
     *            fog once seen if not
     */
    public GraphicPanel(String type, float intensity, boolean mutable)
    {
        this(type);
        this._intensity = intensity;
        this._mutable = mutable;
    }

    /**
     * Overwritten paintComponent method, to paint the image after the
     * components Will scale the image down or up to the size of the panel.
     */
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        if (this._img != null)
            g.drawImage(this._img, 0, 0, this.getSize().width, this.getSize().height, this);

        // If we have a fog image and draw fog in general, draw it
        if (_drawfog)
        {
            // Do not draw invisible fog, this only takes CPU time
            if (!(_intensity == 0.0f))
            {
                // Alpha is used so the fog is translucent. Nice effect
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, _intensity));
                g2.setColor(_fogcolor);
                g2.fillRect(0, 0, this.getSize().width, this.getSize().height);
                g2.dispose();
            }
        }
        g.dispose();
        _changed = false;
    }

    /**
     * Only paint changed components. Use this for manual repainting, e.g. when
     * the round changed.
     */
    public boolean paintChangedComponent()
    {
        if (_changed)
        {
            this.repaint(10);
            return true;
        }
        return false;
    }

    /**
     * Method to update the type. If the same type as before is set, the graphic
     * wont be updated.
     * 
     * @param image
     *            the image name used by MediaManager
     */
    public void updateType(String type)
    {
        // catch users supplying us null as argument
        if (type != null)
        {
            // catch an already set type of null, which is possible
            if (this._type != null)
            {
                // do not change anything if we already had this type
                if (this._type.equals(type))
                    return;
            }
            this._img = _mm.getImage(type);
            this._type = type;
            _changed = true;
        }
    }

    /**
     * Method to force set the type and therefore change the image shown.
     * 
     * @param image
     *            the image name used by MediaManager
     */
    public void setType(String type)
    {
        this._img = _mm.getImage(type);
        this._type = type;
        _changed = true;
    }

    /**
     * @param intensity
     *            fog intensity: 1.0f means image covered by fog, 0.0f image is
     *            visible
     */
    public void setIntensity(float intensity)
    {
        // Again, don't change when there are no changes
        if (intensity == this._intensity)
            return;
        this._intensity = intensity;
        _changed = true;
    }

    /**
     * @param seen
     *            Whether this object has been seen at least once
     */
    public void setSeen(boolean seen)
    {
        this._seen = seen;
    }

    /**
     * @param draw
     *            Whether we draw fog (if needed) or not at all
     */
    public void setDrawFog(boolean draw)
    {
        if (this._drawfog != draw)
        {
            this._drawfog = draw;
            this._changed = true;
        }
    }

    /**
     * @param mutable
     *            Whether the object might change during gameplay (e.g. moving
     *            objects)
     */
    public void setMutable(boolean mutable)
    {
        this._mutable = mutable;
    }

    /**
     * @return the fogcolor
     */
    public Color getFogcolor()
    {
        return _fogcolor;
    }

    /**
     * @param fogcolor
     *            the fogcolor to set
     */
    public void setFogcolor(Color fogcolor)
    {
        this._fogcolor = fogcolor;
    }

    /**
     * @return whether an object is mutable
     */
    public boolean isMutable()
    {
        return _mutable;
    }

    /**
     * @return whether an object has been seen
     */
    public boolean isSeen()
    {
        return _seen;
    }
}
