package ch.bfh.massim.testsuite.review;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * Class to represent all paths as a title in a list. This class is used as a
 * title for a list. This class provides methods to show, hide and manipulate
 * the items in the list.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class PathTitleItem extends JPanel implements IRightTitleItem
{

    private final String TITLE = "created paths";

    private static final long serialVersionUID = -6267884357065230154L;
    private JButton _toggle;
    private JButton _activate;
    private JButton _deactivate;
    private String _directory;
    private ReviewGUI _mainGui;
    private boolean _open;

    private ArrayList<IRightBodyItem> _items;
    private HashMap<String, PathBodyItem> _paths;

    private Random _rand;

    private ImageIcon _iadd; // add button
    private ImageIcon _irem; // remove button
    private ImageIcon _iact; // activate all button
    private ImageIcon _idea; // deactivate all button

    /**
     * Default constructor.
     * 
     * @param mainGui
     *            the GUI this item is bound to
     */
    public PathTitleItem(ReviewGUI mainGui)
    {
        _mainGui = mainGui;
        _toggle = new JButton();
        _open = false;
        _activate = new JButton();
        _deactivate = new JButton();
        _items = new ArrayList<IRightBodyItem>();
        _paths = new HashMap<String, PathBodyItem>();
        _rand = new Random();

        this.setPreferredSize(new Dimension(240, 30));
        this.setMaximumSize(new Dimension(240, 30));

        // Button Icons
        try
        {
            URL url = new java.net.URL(getClass().getResource("img/buttons/list-add.png"), "list-add.png");
            _iadd = new ImageIcon(url);

            url = new java.net.URL(getClass().getResource("img/buttons/list-remove.png"), "list-remove.png");
            _irem = new ImageIcon(url);

            url = new java.net.URL(getClass().getResource("img/buttons/list-activate.png"), "list-activate.png");
            _iact = new ImageIcon(url);

            url = new java.net.URL(getClass().getResource("img/buttons/list-deactivate.png"), "list-deactivate.png");
            _idea = new ImageIcon(url);

        }
        catch (Exception e)
        {
            String message = "Image loading failed";
            String where = "Right list Button Initialisation";
            String possol = "Check whether the img/buttons/ folder exists";

            mainGui.showErrorDialog(message, where, possol, e);
        }

        _toggle = new JButton(_iadd);
        _toggle.setPreferredSize(new Dimension(30, 20));
        _activate = new JButton(_iact);
        _activate.setPreferredSize(new Dimension(30, 20));
        _deactivate = new JButton(_idea);
        _deactivate.setPreferredSize(new Dimension(30, 20));

        _toggle.addActionListener(new ToggleListener());
        _activate.addActionListener(new ActivateListener());
        _deactivate.addActionListener(new DeactivateListener());

        this.add(_toggle);
        this.add(new JLabel(TITLE));
        this.add(_activate);
        this.add(_deactivate);

    }

    /**
     * Method to create a list of paths. List will be empty if the open variable
     * is set to false. Will call the updateRightList() method of the main gui
     * when finished.
     */
    public void createList()
    {
        _items.clear();

        if (!_open)
            return;

        File folder = new File(_directory);
        if (folder != null)
        {
            File[] folders = folder.listFiles();

            if (folders == null)
                return;
            
            String sep = File.pathSeparator;
            
            for (int i = 0; i < folders.length; i++)
            {
            	String path = folders[i].getPath();
            	// workaround for windows ...
            	if(sep.equals(";"))
            		path = path.replace('\\' , '/');
            	
                String split[] = path.split("/");

                if (split.length < 2)
                    continue;

                String team = split[split.length - 2];
                String target = split[split.length - 1];
                String id = team + "_" + target;

                PathBodyItem pbi = null;

                if (_paths.containsKey(id))
                {
                    pbi = _paths.get(id);
                }
                else
                {
                    Color col = new Color(_rand.nextInt(160) + 80, _rand.nextInt(160) + 80, _rand.nextInt(160) + 80);

                    pbi = new PathBodyItem(id, col, false, folders[i].getPath(), _mainGui);
                    _paths.put(id, pbi);
                }

                _items.add(pbi);
            }
        }

        _mainGui.updateRightList(false);
    }

    /**
     * @return the items in this list
     */
    public ArrayList<IRightBodyItem> getItems()
    {
        return _items;
    }

    /**
     * Method to get all body items belonging to this title.
     * 
     * @return all body items belonging to this tile
     */
    @Override
    public ArrayList<IRightBodyItem> getAllItems()
    {
        return _items;
    }

    /**
     * @return the title (text displayed in the list)
     */
    @Override
    public String getTitle()
    {
        return TITLE;
    }

    /**
     * @return the directory used for this list
     */
    public String getDirectory()
    {
        return _directory;
    }

    /**
     * @param directory
     *            the directory used for this list
     */
    public void setDirectory(String directory)
    {
        this._directory = directory;
    }

    /**
     * Inner class for the toggle button Will toggle the open boolean and then
     * call createList() and finally updateRightList() of the ReviewGUI
     * 
     * @author Christian Loosli & Adrian Pauli
     */
    class ToggleListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            if (_open)
            {
                _toggle.setIcon(_iadd);
                _open = false;
                createList();
                _mainGui.updateRightList(false);
            }
            else
            {
                _toggle.setIcon(_irem);
                _open = true;
                createList();
                _mainGui.updateRightList(false);
            }
        }
    }

    /**
     * Inner class for the activate button. Will set all paths active.
     * 
     * @author Christian Loosli & Adrian Pauli
     */
    class ActivateListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            for (IRightBodyItem citem : _items)
            {
                citem.setActivated(true);
            }
            _mainGui.updateRightList(false);
        }
    }

    /**
     * Inner class for the deactivate button. Will set all paths deactivated.
     * 
     * @author Christian Loosli & Adrian Pauli
     */
    class DeactivateListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            for (IRightBodyItem citem : _items)
            {
                citem.setActivated(false);
            }
            _mainGui.updateRightList(false);
        }
    }

}
