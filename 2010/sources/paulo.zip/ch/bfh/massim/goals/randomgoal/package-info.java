/**
 * Contains the classes needed for the goal representation of 
 * a random moving agent. 
 */
package ch.bfh.massim.goals.randomgoal;