package ch.bfh.massim.goals.randomgoal;

import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;

import ch.bfh.massim.framework.mapagent.MapContainer;
import ch.bfh.massim.framework.planingunit.BaseCreator;
import ch.bfh.massim.framework.planingunit.IGoal;

/**
 * Creates RandomGoals.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class RandomCreator extends BaseCreator
{

    private List<IGoal> _runningGoals = new ArrayList<IGoal>();

    /**
     * @see ch.bfh.massim.framework.planingunit.ICreator#calculateGoals(ch.bfh.massim.framework.mapagent.MapContainer,
     *      java.util.PriorityQueue)
     */
    @Override
    public void calculateGoals(MapContainer map, PriorityQueue<IGoal> goals)
    {

        while (_runningGoals.size() < 21)
        {
            IGoal newGoal = new RandomGoal(_con);
            _runningGoals.add(newGoal);
            // goals.add(newGoal);
        }
        goals.addAll(_runningGoals);

    }

	@Override
	public void clear() {
		// TODO Auto-generated method stub
		
	}
}
