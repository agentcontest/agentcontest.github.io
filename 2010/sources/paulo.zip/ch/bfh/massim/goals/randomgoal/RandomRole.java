package ch.bfh.massim.goals.randomgoal;

import java.util.Random;

import ch.bfh.massim.framework.masmessages.MasMessageAction;
import ch.bfh.massim.framework.masmessages.MasMessageRequestAction;
import ch.bfh.massim.framework.rolebasedagent.*;

/**
 * Role where the agent walks in random directions.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class RandomRole extends BaseRole
{

    Random rand = new Random();


    public RandomRole()
    {
        super("random");
    }

    @Override
    public void processRequestAction(MasMessageRequestAction request, MasMessageAction action)
    {
        int dir = rand.nextInt(8);
        action.setMove(dir);
    }

    @Override
    public void setRoleMessage(RoleMessage rm)
    {
        // not used
    }
}
