package ch.bfh.massim.goals.randomgoal;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import ch.bfh.massim.framework.ComClientConnection;
import ch.bfh.massim.framework.commessages.ComMessage;
import ch.bfh.massim.framework.mapagent.MapContainer;
import ch.bfh.massim.framework.planingunit.AgentPlaning;
import ch.bfh.massim.framework.planingunit.IGoal;
import ch.bfh.massim.framework.rolebasedagent.RoleMessage;

/**
 * Goal, which tells the agents to walk in random direction.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class RandomGoal implements IGoal
{

    private boolean inProgress = false;
    private List<AgentPlaning> _agentList = new ArrayList<AgentPlaning>();
    private ComClientConnection _con;

    /**
     * Default constructor
     * @param con connection to the com client
     */
    public RandomGoal(ComClientConnection con)
    {
        _con = con;
    }

    /**
     * @return the number of agents
     */
    @Override
    public int getAgentNumber()
    {
        return 1;
    }

    /**
     * @return the goal priority 
     */
    @Override
    public int getPriority()
    {
        return 1;
    }

    /**
     * @param agents agents designated for this goal
     * @return the priority with given agents
     */
    @Override
    public int getPriorityWithAgents(AgentPlaning[] agents)
    {
        return 11;
    }

    /**
     * @return whether the goal is in progress
     */
    @Override
    public boolean isInProgress()
    {
        return inProgress;
    }

    /**
     * @param agents agents to set for this goal
     * @param map map we are playing on
     */
    @Override
    public void setAgents(AgentPlaning[] agents, MapContainer map)
    {
        inProgress = true;
        for (AgentPlaning agentPlaning : agents)
        {
            // System.err.println("***** set new Role to an " + agentPlaning.get_agentName() + " ****");
            _agentList.add(agentPlaning);
            agentPlaning.setFree(false);
            sendRoleToAgent(agentPlaning.get_agentName(), "random");
        }

    }

    /**
     * Method to send the role to an agent.
     * @param agent agent who should receive the role
     * @param rolename name of the role
     */
    private void sendRoleToAgent(String agent, String rolename)
    {
        ComMessage message = new RoleMessage(rolename, "PlaningUnit", agent);
        try
        {
            _con.sendMessage(message);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * Method to release all agents of this goal.
     */
    @Override
    public void releaseAgents()
    {
        inProgress = false;
        for (AgentPlaning agent : _agentList)
        {
            agent.setFree(true);
            sendRoleToAgent(agent.get_agentName(), "base");
        }
        _agentList.clear();
    }

}
