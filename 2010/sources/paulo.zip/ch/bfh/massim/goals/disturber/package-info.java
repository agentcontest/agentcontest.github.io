/**
 * Contains the classes needed for the goal representation of 
 * disturbing the enemy.
 */
package ch.bfh.massim.goals.disturber;