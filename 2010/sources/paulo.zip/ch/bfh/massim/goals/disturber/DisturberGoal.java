package ch.bfh.massim.goals.disturber;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import ch.bfh.massim.framework.ComClientConnection;
import ch.bfh.massim.framework.commessages.ComMessage;
import ch.bfh.massim.framework.cowherd.CowHerd;
import ch.bfh.massim.framework.mapagent.MapContainer;
import ch.bfh.massim.framework.planingunit.AgentPlaning;
import ch.bfh.massim.framework.planingunit.IGoal;
import ch.bfh.massim.framework.rolebasedagent.RoleMessage;

/**
 * Class to represent a disturber goal. This class is used so that disturbing
 * the enemy can be represented as a goal. This class provides methods defined
 * in the IGoal interface and helper methods.
 * 
 * @author @author Christian Loosli & Adrian Pauli
 * 
 */
public class DisturberGoal implements IGoal
{

    private boolean _inProgress = false;
    private List<AgentPlaning> _agentList = new ArrayList<AgentPlaning>();
    private ComClientConnection _con;
    private MapContainer _map;
    private CowHerd _herd;

    /**
     * Default constructor
     * 
     * @param con
     *            the com client connection
     * @param herd
     *            the herd to keep
     */
    public DisturberGoal(ComClientConnection con, CowHerd herd)
    {
        _con = con;
        _herd = herd;
    }

    /**
     * Method to update the situation. Will check for open parts in the enemy
     * corral and assign cowGuards to it.
     */
    public void updateSituation()
    {
        // TODO: Logic
    }

    /**
     * Amount of agents. Currently hardcoded to 2, as it seemed to be a good
     * value in tests.
     * 
     * @return number of agents
     */
    @Override
    public int getAgentNumber()
    {
        return 2;
    }

    /**
     * Priority of the goal. Currently 10 * herd size. Herding is more
     * important, so 30 * herd size, but keeping is more important than
     * disturbing, which has 10 * herd size.
     * 
     * @return goal priority
     */
    @Override
    public int getPriority()
    {
        return 10 * _herd.getCows().size();
    }

    /**
     * Priority with agents. Currently the same as without agents.
     * 
     * @return goal priority
     */
    @Override
    public int getPriorityWithAgents(AgentPlaning[] agents)
    {
        return _herd.getCows().size();
    }

    /**
     * Whether this method goal is in progress
     * 
     * @return true if this goal is in progress, false otherwhise
     */
    @Override
    public boolean isInProgress()
    {
        return _inProgress;
    }

    /**
     * Method to assign agents to this goal
     * 
     * @param agents
     *            Agents assigned to this goal
     * @param map
     *            Map we are playing on
     */
    @Override
    public void setAgents(AgentPlaning[] agents, MapContainer map)
    {
        _inProgress = true;
        for (int i = 0; i < agents.length; i++)
        {

            AgentPlaning agentPlaning = agents[i];

            _agentList.add(agentPlaning);
            agentPlaning.setFree(false);
        }

        _inProgress = true;
    }

    /**
     * Helper method to send a role to an agent
     * 
     * @param agent
     *            agent to send the role to
     * @param rolename
     *            name of the role
     */
    private void sendRoleToAgent(String agent, String rolename)
    {
        ComMessage message = new RoleMessage(rolename, "PlaningUnit", agent);
        try
        {
            _con.sendMessage(message);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * Method to release the agents assigned to this goal. Will set the agent
     * role to random.
     */
    @Override
    public void releaseAgents()
    {
        _inProgress = false;
        for (AgentPlaning agent : _agentList)
        {
            agent.setFree(true);
            sendRoleToAgent(agent.get_agentName(), "random");
        }
        _agentList.clear();
    }

    /**
     * Method to update the map
     * 
     * @param map
     *            map container
     */
    public void updateMap(MapContainer map)
    {
        this._map = map;
    }

    /**
     * Setter for the herd
     * 
     * @param herd
     *            the cow herd
     */
    public void updateHerd(CowHerd herd)
    {
        this._herd = herd;
    }

    /**
     * @return the cowherd
     */
    public CowHerd get_herd()
    {
        return _herd;
    }

    /**
     * @param herd
     *            the cowherd to set
     */
    public void set_herd(CowHerd herd)
    {
        _herd = herd;
    }

    /**
     * @return the map
     */
    public MapContainer get_map()
    {
        return _map;
    }

}
