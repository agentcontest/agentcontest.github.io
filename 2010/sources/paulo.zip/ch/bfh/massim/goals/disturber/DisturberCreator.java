package ch.bfh.massim.goals.disturber;

import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;

import ch.bfh.massim.framework.cowherd.CowHerd;
import ch.bfh.massim.framework.cowherd.CowHerdStatus;
import ch.bfh.massim.framework.cowherd.HerdClassifier;
import ch.bfh.massim.framework.mapagent.MapContainer;
import ch.bfh.massim.framework.planingunit.BaseCreator;
import ch.bfh.massim.framework.planingunit.IGoal;

/**
 * Class to create disturber goals. This class is used to create goals which try
 * to disturb the enemy. This class provides methods defined in BaseCreator and
 * helper methods needed.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class DisturberCreator extends BaseCreator
{
    private List<DisturberGoal> _runningGoals = new ArrayList<DisturberGoal>();
    private HerdClassifier _classify;
    private int _laststep = -1;
    private int _lastupdate = -1;

    // settings:
    private final int STEPWAIT = 4;
    private final int NUMBEROFGOALS = 2;
    // Search depth for the herd classifier
    private final int DEPTH = 3;
    // Rounds since the cow was seen for the classifier.
    // We are only interested in currently seen cows
    private final int SEEN = 0;

    /**
     * Method to calculate the goals
     * 
     * @param map
     *            the map we are playing on
     * @param goals
     *            a priority queue to put the gaols in
     */
    @Override
    public void calculateGoals(MapContainer map, PriorityQueue<IGoal> goals)
    {
        if (_lastupdate == map.getStep())
            return;

        _lastupdate = map.getStep();

        // update goals only all "stepwait" steps
        if (_laststep < 0 || (map.getStep() - _laststep >= STEPWAIT))
        {
            _laststep = map.getStep();

            _classify = HerdClassifier.getInstance(map.get_ownTeam());
            ArrayList<CowHerd> herds = new ArrayList<CowHerd>();
            herds.addAll(_classify.classifyHerds(map, DEPTH, SEEN));

            // only keep goals in progress
            List<DisturberGoal> newGoals = new ArrayList<DisturberGoal>();

            for (DisturberGoal goal : _runningGoals)
            {
                CowHerd goalherd = goal.get_herd();

                if (!herds.contains(goalherd))
                {
                    goal.releaseAgents();
                }

                if (goal.isInProgress())
                {

                    if (goalherd == null)
                    {
                        goal.releaseAgents();
                    }
                    else
                    {

                        // Provide updated info to the goal
                        goal.updateHerd(herds.get(herds.indexOf(goalherd)));
                        newGoals.add(goal);

                    }
                }
            }

            for (CowHerd herd : herds)
            {
                // Only add a goal for herds that are in enemy corral state.
                if (herd.getStatus().equals(CowHerdStatus.INENEMYCORRAL))
                {
                    if (newGoals.size() < NUMBEROFGOALS)
                    {
                        DisturberGoal goal = new DisturberGoal(_con, herd);
                        newGoals.add(goal);

                        // Log the herd
                        // String simID = map.get_simID();
                        // String team = map.get_ownTeam();

                        // int step = map.getStep();
                        // String fullid[] = simID.split("-");
                        // String gameid = "";
                        // String simid = "";

                        // if (fullid.length >= 2)
                        // {
                        //    gameid = fullid[0];
                        //    simid = fullid[1];

                        // }

                        //herd.logHerd(gameid, simid, team, step);
                    }
                }
            }

            _runningGoals = newGoals;
            goals.addAll(_runningGoals);

        }

        // Pass the new map each round
        for (DisturberGoal goal : _runningGoals)
        {
            if (goal.isInProgress())
            {
                goal.updateMap(map);
                goal.updateSituation();
            }
        }

    }
    
	@Override
	public void clear() {
		// TODO Auto-generated method stub
		_runningGoals.clear();
		_laststep = -1;
		_lastupdate = -1;
	}
}
