package ch.bfh.massim.goals;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import ch.bfh.massim.framework.ComClientConnection;
import ch.bfh.massim.framework.MapCoordinate;
import ch.bfh.massim.roles.followwaypoints.FollowWPAssistantRoleMessage;
import ch.bfh.massim.roles.followwaypoints.FollowWPLeaderRoleMessage;

/**
 * This class provieds basic function to create FollowWP roles.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class FollowWPInitiatior
{

    /**
     * Creates a list of waypoints out of a path
     * 
     * @param path
     *            the path we want waypoints of
     * @param startstep
     *            the start field for the first waypoint
     * @param endstep
     *            the end field for the last waypoint
     * @param stepsize
     *            the stepsize between two waypoints
     * @return a list with waypoints
     */
    public static List<MapCoordinate> createWaypointPath(List<MapCoordinate> path, int startstep, int endstep,
            int stepsize)
    {
        // only take every fifth element as waypoint
        List<MapCoordinate> wpPath = new ArrayList<MapCoordinate>();
        if (path.size() >= startstep + endstep)
        {
            for (int i = startstep; i < path.size() - endstep; i += stepsize)
            {
                wpPath.add(path.get(i));
            }
        }
        if (path.size() > endstep)
        {
            wpPath.add(path.get(path.size() - (endstep + 1)));
        }
        else
        {
            wpPath.add(path.get(0));
        }
        return wpPath;
    }

    /**
     * Creates and sends the Rolemessage to the leader
     * 
     * @param waypointPath
     *            list with waypoints
     * @param assistants
     *            list with assitant agents
     * @param leader
     *            the leader name
     * @param conn
     *            the connection to the ComServer
     */
    public static void sendRoleToLeader(List<MapCoordinate> waypointPath, List<String> assistants, String leader,
            ComClientConnection conn)
    {
        // inform agent
        FollowWPLeaderRoleMessage message = new FollowWPLeaderRoleMessage("PlaningUnit", leader);
        message.addWpList(waypointPath);
        message.addAssistants(assistants);

        try
        {
            conn.sendMessage(message);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * Sends the RoleMessage to the agents
     * 
     * @param assistants
     *            the agents
     * @param leader
     *            the leader
     * @param conn
     *            the connection to the ComServer
     */
    public static void sendRoleToAssistants(List<String> assistants, String leader, ComClientConnection conn)
    {
        if (assistants != null && assistants.size() > 0)
        {
            for (String agent : assistants)
            {
                FollowWPAssistantRoleMessage message = new FollowWPAssistantRoleMessage("PlaningUnit");
                message.addLeader(leader);

                message.addReceiverAgent(agent);

                try
                {
                    conn.sendMessage(message);
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }
            }
        }
    }

}
