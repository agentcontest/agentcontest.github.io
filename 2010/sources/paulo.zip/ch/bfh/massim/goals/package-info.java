/**
 * Contains sub packages which represent the different goals.
 */
package ch.bfh.massim.goals;