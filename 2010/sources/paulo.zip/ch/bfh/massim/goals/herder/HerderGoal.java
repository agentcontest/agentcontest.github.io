package ch.bfh.massim.goals.herder;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import ch.bfh.massim.framework.ComClientConnection;
import ch.bfh.massim.framework.Direction;
import ch.bfh.massim.framework.MapCoordinate;
import ch.bfh.massim.framework.cowherd.CowHerd;
import ch.bfh.massim.framework.mapagent.MapContainer;
import ch.bfh.massim.framework.pathfinder.PathFinder;
import ch.bfh.massim.framework.planingunit.AgentPlaning;
import ch.bfh.massim.framework.planingunit.IGoal;
import ch.bfh.massim.goals.FollowWPInitiatior;
import ch.bfh.massim.roles.followwaypoints.FollowWPLeaderRoleMessage;

/**
 * Class to represent a herder goal. This class is used so that herding can be
 * represented as a goal. This class provides methods defined in the IGoal
 * interface and helper methods.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class HerderGoal implements IGoal
{

    private boolean _inProgress = false;
    private List<AgentPlaning> _agentList = new ArrayList<AgentPlaning>();
    private Map<AgentPlaning, Position> _posList = new HashMap<AgentPlaning, Position>();
    private ComClientConnection _con;
    private CowHerd _herd;
    private PathFinder _pathfinder;
    private ArrayList<MapCoordinate> _path;
    private MapContainer _map;
    private HerderStatus _status;
    private MapCoordinate _preparingTarget;
    
    private static int lastid = 0;
    private int _goalid = -1;

    /**
     * Default constructor.
     * 
     * @param con
     *            the com client connection
     * @param herd
     *            the herd to keep
     */
    public HerderGoal(ComClientConnection con, CowHerd herd)
    {
        _con = con;
        _herd = herd;
        _pathfinder = new PathFinder();
        _status = HerderStatus.newHerd;
        _path = new ArrayList<MapCoordinate>();
    }

    /**
     * Helper method to check the situation and act accordingly.
     */
    public void updateSituation()
    {
        try
        {
            if (!_inProgress)
                return;

            switch (_status)
            {
                case newHerd:
                {
                    generatePathHome();
                    break;
                }
                case pathFound:
                {
                    startPreparing();
                    break;
                }
                case preparingHerders:
                {
                    checkPreparing();
                    break;
                }
                case preparedHerders:
                {
                    startEntangleHerd();
                    break;
                }
                case entanglingHerd:
                {
                    checkEntangleHerd();
                    break;
                }
                case movingHerd:
                {
                    checkMoveHerd();
                    break;
                }
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
            System.exit(0);
        }

    }

    /**
     * Method to update the _map.
     * 
     * @param map
     *            the new map
     */
    public void updateMap(MapContainer map)
    {
        this._map = map;
    }

    /**
     * Method to update the herd.
     * 
     * @param herd
     *            the cow herd
     */
    public void updateHerd(CowHerd herd)
    {
        this._herd = herd;
    }

    /**
     * Method to create a path leading the herd home. Creates a path from the
     * herd center to the corral center
     */
    private void generatePathHome()
    {
        _status = HerderStatus.working;
        _pathfinder.setIgnoreclosedfence(true);
        _pathfinder.setIgnorecows(true);
        _pathfinder.setIgnoreobstacles(false);
        _pathfinder.setIgnoreagents(true);
        _pathfinder.setIgnoreunknownground(false);
        _pathfinder.setIgnoreunknowncontent(false);

        MapCoordinate start = _herd.getGeometricCenter();

        int[] corralcoord = _map.getCorralBorder();

        int corcentx = (corralcoord[3] + corralcoord[1]) / 2;
        int corcenty = (corralcoord[2] + corralcoord[0]) / 2;

        MapCoordinate goal = new MapCoordinate(corcentx, corcenty);

        List<MapCoordinate> cpath = _pathfinder.getPathToNearestGoal(_map.getMap(), start, goal);

        _path.clear();

        if (cpath != null)
        {
            _path.addAll(cpath);
            _status = HerderStatus.pathFound;
            logPath(_map, _path, "homewards");
            updateSituation();
        }
    }

    /**
     * Helper method to start preparing. Gathers the agents around for
     * entangling so that it is more or less synchronized.
     */
    private void startPreparing()
    {
        _status = HerderStatus.working;
        // System.err.println("***** " + _herd.getUniqueID() + " Start preparing agents *****");

        List<MapCoordinate> coords = new ArrayList<MapCoordinate>();
        for (AgentPlaning agent : _agentList)
        {
            coords.add(_map.getAgentPosition(agent.get_agentName()));
        }

        MapCoordinate target = _herd.getGeometricCenter();
        MapCoordinate centercoord = MapCoordinate.calculateCenter(coords.toArray(new MapCoordinate[0]));

        centercoord = _pathfinder.getNearestNotblockedField(_map.getMap(), centercoord, target);

        List<MapCoordinate> path = _pathfinder.getPathToNearestGoal(_map.getMap(), centercoord, target);

        if (path != null)
        {
            List<MapCoordinate> wpPath = FollowWPInitiatior.createWaypointPath(path, 8, 8, 8);

            List<String> al = new ArrayList<String>();
            for (int i = 1; i < _agentList.size(); i++)
            {
                al.add(_agentList.get(i).get_agentName());
            }

            // System.err.println("**herder preparing: leader " + _agentList.get(0).get_agentName() + " assistnumber:"
            //        + al.size());

            FollowWPInitiatior.sendRoleToLeader(wpPath, al, _agentList.get(0).get_agentName(), _con);
            FollowWPInitiatior.sendRoleToAssistants(al, _agentList.get(0).get_agentName(), _con);
            _preparingTarget = target;
        }

        _status = HerderStatus.preparingHerders;
        // updateSituation();
    }

    /**
     * Helper method to start preparing. Gathers the agents around for
     * entangling so that it is more or less synchronized.
     */
    private void checkPreparing()
    {
        _status = HerderStatus.working;

        MapCoordinate target = _herd.getGeometricCenter();

        List<MapCoordinate> coords = new ArrayList<MapCoordinate>();
        for (AgentPlaning agent : _agentList)
        {
            coords.add(_map.getAgentPosition(agent.get_agentName()));
        }
        MapCoordinate centercoord = MapCoordinate.calculateCenter(coords.toArray(new MapCoordinate[0]));

        if (_preparingTarget == null || _preparingTarget.distance(target) > 4)
        {
            startPreparing();
        }
        else if (_preparingTarget.distance(centercoord) < (int) _herd.getMaxEuclidianDistanceToGeometricCenter() + 5)
        {
            _status = HerderStatus.preparedHerders;
            updateSituation();
        }
        else
        {
            _status = HerderStatus.preparingHerders;
        }

        // updateSituation();
    }

    /**
     * Helper method to entangle the herd.
     */
    private void startEntangleHerd()
    {
        _status = HerderStatus.working;

        double radius = _herd.getMaxEuclidianDistanceToGeometricCenter() + 1;
        MapCoordinate center = _herd.getGeometricCenter();

        int[] herdborder = _herd.getBorder();
        int herdtop = herdborder[0];
        int herdright = herdborder[1];
        int herdbottom = herdborder[2];
        int herdleft = herdborder[3];

        ArrayList<MapCoordinate> herdbox = new ArrayList<MapCoordinate>();

        for (int j = herdtop + 1; j < herdbottom - 1; j++)
        {
            for (int i = herdleft + 1; i < herdright - 1; i++)
            {
                MapCoordinate cur = new MapCoordinate(i, j);
                if (center.euclidianDistance(cur) < radius)
                {
                    herdbox.add(cur);
                }
                herdbox.add(cur);
            }
        }

        generatePathHome();
        
        MapCoordinate wpHerd;
        MapCoordinate wpFence;
        if(_path.size() > 20) {
        	wpFence = _path.get(20);
        	wpHerd = _path.get(10);
        }
        else if (_path.size() > 10)
        {
            wpHerd = _path.get(10);
            wpFence = _path.get(10);
        }
        else
        {
            if (_path.size() > 0)
            {
                wpHerd = _path.get(_path.size() - 1);
                wpFence = wpHerd;
            }
            else
            {
                wpHerd = null;
                wpFence = null;
            }
        }
        
        Map<String, MapCoordinate> agentsPos = new HashMap<String, MapCoordinate>();
        Map<String, MapCoordinate> agentTargetPositions = new HashMap<String, MapCoordinate>();;
        if (wpHerd != null) {
        	
        	for(AgentPlaning agent : _agentList) {
        		agentsPos.put(agent.get_agentName(), _map.getAgentPosition(agent.get_agentName()));
        	}
        	
            MapFenceCalculation2 calc = new MapFenceCalculation2(_map.getMap(), agentsPos, wpFence);
            agentTargetPositions = calc.calculateWithFencePath();	
        }
        
        int size = _agentList.size();
        for (Entry<String, MapCoordinate> element : agentTargetPositions.entrySet()) {
        	if(element.getValue() != null) size--;
        }
               
        double startAngle = Math.toRadians(80);
        double endAngle = Math.toRadians(360) - startAngle;

        double stepAngle = (endAngle - startAngle);
        if (size > 1)
        {
            stepAngle = (endAngle - startAngle) / (size - 1);
        }
        
        int step = 0;
        for (int i = 0; i < _agentList.size() && wpHerd != null; i++)
        {
            AgentPlaning agent = _agentList.get(i);
            MapCoordinate target = agentTargetPositions.get(agent.get_agentName());
            if (target == null) {
            
            	target = getAgentPositionByAngle(center, wpHerd, radius, startAngle + step * stepAngle);
            	step++;
            	// System.err.println("calculated herder target with radius: " + radius + " and angle " + startAngle + i
            	//        * stepAngle + " and result: " + target);
            }
            
            String agentname = agent.get_agentName();

            MapCoordinate ownPos = _map.getAgentPosition(agentname);

            if (ownPos == null)
                continue;

            _pathfinder.setIgnoreunknownground(true);
            _pathfinder.setIgnoreunknowncontent(true);

            List<MapCoordinate> path = _pathfinder.getPathToNearestGoal(_map.getMap(), ownPos, target, herdbox);// ,

            if (path == null)
                continue;

            logPath(_map, path, agentname + "-entangle");

            // only take every fifth element as waypoint
            List<MapCoordinate> wpPath = new ArrayList<MapCoordinate>();
            for (int j = 2; j < path.size(); j += 2)
            {
                wpPath.add(path.get(j));
            }
            wpPath.add(path.get(path.size() - 1));

            // inform agent
            FollowWPLeaderRoleMessage message = new FollowWPLeaderRoleMessage("PlaningUnit", agentname);
            message.addWpList(wpPath);

            try
            {
                _con.sendMessage(message);
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }
        _status = HerderStatus.entanglingHerd;
    }

    /**
     * Helper method to entangle the herd
     */
    private void checkEntangleHerd()
    {
        _status = HerderStatus.working;

        startEntangleHerd();

        _status = HerderStatus.entanglingHerd;
    }

    /**
     * Helper method check the status of the herd moving
     */
    private void checkMoveHerd()
    {

        generatePathHome();
        updateAgentPositions(_agentList);
    }

    /**
     * Method to initially place the agents around the herd.
     * 
     * @param agents
     *            agents available
     */
    private void updateAgentPositions(List<AgentPlaning> agents)
    {
        Direction direction = getDirection();

        _posList.clear();

        switch (direction)
        {
            case NONE:
            {
                if (agents.size() == 3)
                {
                    _posList.put(agents.get(0), Position.TOP_MID);
                    _posList.put(agents.get(1), Position.LEFT_MID);
                    _posList.put(agents.get(2), Position.RIGHT_MID);
                }
                else if (agents.size() == 6)
                {
                    _posList.put(agents.get(0), Position.TOP_MID_LEFT);
                    _posList.put(agents.get(1), Position.TOP_MID_RIGHT);
                    _posList.put(agents.get(2), Position.LEFT_TOP);
                    _posList.put(agents.get(3), Position.LEFT_BOTTOM);
                    _posList.put(agents.get(4), Position.RIGHT_TOP);
                    _posList.put(agents.get(5), Position.RIGHT_BOTTOM);
                }
                break;
            }
            case NORTH:
            {
                if (agents.size() == 3)
                {
                    _posList.put(agents.get(0), Position.BOTTOM_MID);
                    _posList.put(agents.get(1), Position.LEFT_MID);
                    _posList.put(agents.get(2), Position.RIGHT_MID);
                }
                else if (agents.size() == 6)
                {
                    _posList.put(agents.get(0), Position.BOTTOM_MID_LEFT);
                    _posList.put(agents.get(1), Position.BOTTOM_MID_RIGHT);
                    _posList.put(agents.get(2), Position.LEFT_TOP);
                    _posList.put(agents.get(3), Position.LEFT_BOTTOM);
                    _posList.put(agents.get(4), Position.RIGHT_TOP);
                    _posList.put(agents.get(5), Position.RIGHT_BOTTOM);
                }
                break;
            }
            case NORTHEAST:
            {
                if (agents.size() == 3)
                {
                    _posList.put(agents.get(0), Position.TOP_LEFT_EDGE);
                    _posList.put(agents.get(1), Position.BOTTOM_LEFT_EDGE);
                    _posList.put(agents.get(2), Position.BOTTOM_RIGHT_EDGE);
                }
                else if (agents.size() == 6)
                {
                    _posList.put(agents.get(0), Position.TOP_MID_LEFT);
                    _posList.put(agents.get(1), Position.LEFT_TOP);
                    _posList.put(agents.get(2), Position.LEFT_BOTTOM);
                    _posList.put(agents.get(3), Position.BOTTOM_MID_LEFT);
                    _posList.put(agents.get(4), Position.BOTTOM_MID_RIGHT);
                    _posList.put(agents.get(5), Position.RIGHT_BOTTOM);
                }
                break;
            }
            case EAST:
            {
                if (agents.size() == 3)
                {
                    _posList.put(agents.get(0), Position.TOP_MID);
                    _posList.put(agents.get(1), Position.LEFT_MID);
                    _posList.put(agents.get(2), Position.BOTTOM_MID);
                }
                else if (agents.size() == 6)
                {
                    _posList.put(agents.get(0), Position.TOP_MID_LEFT);
                    _posList.put(agents.get(1), Position.TOP_MID_RIGHT);
                    _posList.put(agents.get(2), Position.LEFT_TOP);
                    _posList.put(agents.get(3), Position.LEFT_BOTTOM);
                    _posList.put(agents.get(4), Position.BOTTOM_MID_LEFT);
                    _posList.put(agents.get(5), Position.BOTTOM_MID_RIGHT);
                }
                break;
            }
            case SOUTHEAST:
            {
                if (agents.size() == 3)
                {
                    _posList.put(agents.get(0), Position.TOP_LEFT_EDGE);
                    _posList.put(agents.get(1), Position.TOP_RIGHT_EDGE);
                    _posList.put(agents.get(2), Position.BOTTOM_LEFT_EDGE);
                }
                else if (agents.size() == 6)
                {
                    _posList.put(agents.get(0), Position.TOP_MID_LEFT);
                    _posList.put(agents.get(1), Position.TOP_MID_RIGHT);
                    _posList.put(agents.get(2), Position.LEFT_TOP);
                    _posList.put(agents.get(3), Position.LEFT_BOTTOM);
                    _posList.put(agents.get(4), Position.RIGHT_TOP);
                    _posList.put(agents.get(5), Position.BOTTOM_MID_LEFT);
                }
                break;
            }
            case SOUTH:
            {
                if (agents.size() == 3)
                {
                    _posList.put(agents.get(0), Position.TOP_MID);
                    _posList.put(agents.get(1), Position.LEFT_MID);
                    _posList.put(agents.get(2), Position.RIGHT_MID);
                }
                else if (agents.size() == 6)
                {
                    _posList.put(agents.get(0), Position.TOP_MID_LEFT);
                    _posList.put(agents.get(1), Position.TOP_MID_RIGHT);
                    _posList.put(agents.get(2), Position.LEFT_TOP);
                    _posList.put(agents.get(3), Position.LEFT_BOTTOM);
                    _posList.put(agents.get(4), Position.RIGHT_TOP);
                    _posList.put(agents.get(5), Position.RIGHT_BOTTOM);
                }
                break;
            }
            case SOUTHWEST:
            {
                if (agents.size() == 3)
                {
                    _posList.put(agents.get(0), Position.TOP_LEFT_EDGE);
                    _posList.put(agents.get(1), Position.TOP_RIGHT_EDGE);
                    _posList.put(agents.get(2), Position.BOTTOM_RIGHT_EDGE);
                }
                else if (agents.size() == 6)
                {
                    _posList.put(agents.get(0), Position.TOP_MID_LEFT);
                    _posList.put(agents.get(1), Position.TOP_MID_RIGHT);
                    _posList.put(agents.get(2), Position.RIGHT_TOP);
                    _posList.put(agents.get(3), Position.RIGHT_BOTTOM);
                    _posList.put(agents.get(4), Position.BOTTOM_MID_RIGHT);
                    _posList.put(agents.get(5), Position.LEFT_TOP);
                }
                break;
            }

            case WEST:
            {
                if (agents.size() == 3)
                {
                    _posList.put(agents.get(0), Position.TOP_MID);
                    _posList.put(agents.get(1), Position.BOTTOM_MID);
                    _posList.put(agents.get(2), Position.RIGHT_MID);
                }
                else if (agents.size() == 6)
                {
                    _posList.put(agents.get(0), Position.TOP_MID_LEFT);
                    _posList.put(agents.get(1), Position.TOP_MID_RIGHT);
                    _posList.put(agents.get(2), Position.BOTTOM_MID_LEFT);
                    _posList.put(agents.get(3), Position.BOTTOM_MID_RIGHT);
                    _posList.put(agents.get(4), Position.RIGHT_TOP);
                    _posList.put(agents.get(5), Position.RIGHT_BOTTOM);
                }
                break;
            }
            case NORTHWEST:
            {
                if (agents.size() == 3)
                {
                    _posList.put(agents.get(0), Position.TOP_RIGHT_EDGE);
                    _posList.put(agents.get(1), Position.BOTTOM_RIGHT_EDGE);
                    _posList.put(agents.get(2), Position.BOTTOM_LEFT_EDGE);
                }
                else if (agents.size() == 6)
                {
                    _posList.put(agents.get(0), Position.TOP_MID_RIGHT);
                    _posList.put(agents.get(1), Position.RIGHT_TOP);
                    _posList.put(agents.get(2), Position.RIGHT_BOTTOM);
                    _posList.put(agents.get(3), Position.BOTTOM_MID_RIGHT);
                    _posList.put(agents.get(4), Position.BOTTOM_MID_LEFT);
                    _posList.put(agents.get(5), Position.LEFT_BOTTOM);
                }
                break;
            }
        }
    }

    /**
     * Helper method to update the current direction the herd should head
     * towards. Calculated by using a mean weight over the next steps (up to 10
     * steps) of the path from the herd home
     */
    private Direction getDirection()
    {
        MapCoordinate cur = _path.get(0);
        int lenght = (_path.size() >= 10) ? 10 : _path.size();

        int north = 0;
        int west = 0;
        int south = 0;
        int east = 0;

        for (int i = 1; i < lenght; i++)
        {
            MapCoordinate next = _path.get(i);
            int cury = cur.getY();
            int curx = cur.getX();
            int nxty = next.getY();
            int nxtx = next.getX();

            // northwest, north or northeast
            if (cury > nxty)
            {
                if (curx < nxtx)
                {
                    north++;
                    east++;
                }
                else if (curx == nxtx)
                {
                    north++;
                }
                else if (curx > nxtx)
                {
                    north++;
                    west++;
                }
            }

            // west, none or east
            if (cury == nxty)
            {
                if (curx < nxtx)
                    east++;
                else if (cury > nxty)
                    west++;
            }

            // southwest, south or southeast
            if (cury < nxty)
            {
                if (curx < nxtx)
                {
                    south++;
                    east++;
                }
                else if (curx == nxtx)
                {
                    south++;
                }
                else if (curx > nxtx)
                {
                    south++;
                    west++;
                }
            }
            cur = next;
        }

        Direction direction = Direction.NONE;

        // northwest, north or northeast
        if (north > south)
        {
            if (east > west)
                direction = Direction.NORTHEAST;
            else if (east == west)
                direction = Direction.NORTH;
            else if (east < east)
                direction = Direction.NORTHWEST;
        }

        // west, none or east
        if (north == south)
        {
            if (east > west)
                direction = Direction.EAST;
            else if (east == west)
                direction = Direction.NONE;
            else if (east < west)
                direction = Direction.WEST;
        }

        // southwest, south or southeast
        if (north < south)
        {
            if (east > west)
                direction = Direction.SOUTHEAST;
            else if (east == west)
                direction = Direction.SOUTH;
            else if (east < west)
                direction = Direction.SOUTHWEST;
        }

        return direction;
    }

    /**
     * Method to release the agents assigned to this goal. Will set the agent
     * role to random.
     */
    @Override
    public void releaseAgents()
    {
        _inProgress = false;

        for (AgentPlaning agent : _agentList)
        {
            agent.setFree(true);
        }
        _agentList.clear();
    }

    /**
     * Amount of agents. Currently hardcoded to 6, as it seemed to be a good
     * value in tests.
     * 
     * @return number of agents
     */
    @Override
    public int getAgentNumber()
    {
        return 6;
    }

    /**
     * Priority of the goal. Currently 30 * herd size. Herding is more
     * important, so 30 * herd size, but keeping with 20 * herd size is more
     * important than disturbing, which has 10 * herd size.
     * 
     * @return goal priority
     */
    @Override
    public int getPriority()
    {
        return _herd.getCows().size() * 30;
    }

    /**
     * Priority with agents. Currently the same as without agents.
     * 
     * @return goal priority
     */
    @Override
    public int getPriorityWithAgents(AgentPlaning[] agents)
    {
        return _herd.getCows().size() * 30;
    }

    /**
     * Whether this method goal is in progress
     * 
     * @return true if this goal is in progress, false otherwise
     */
    @Override
    public boolean isInProgress()
    {
        return _inProgress;
    }

    /**
     * Method to assign agents to this goal
     * 
     * @param agents
     *            Agents assigned to this goal
     * @param map
     *            Map we are playing on
     */
    @Override
    public void setAgents(AgentPlaning[] agents, MapContainer map)
    {
        for (int i = 0; i < agents.length; i++)
        {

            AgentPlaning agentPlaning = agents[i];

            _agentList.add(agentPlaning);
            agentPlaning.setFree(false);
        }

        _inProgress = true;

    }

    /**
     * Getter for the herd
     * 
     * @return the cowherd
     */
    public CowHerd get_herd()
    {
        return _herd;
    }

    /**
     * 
     * @return the unique goalID
     */
    public int getGoalID() {
    	if (_goalid < 0) {
    		_goalid = lastid++;
    	}
    	return _goalid;
    }
    
    /**
     * Helper method to log the path from the herd to the corral
     * 
     * @param map
     *            map the path is on
     * @param path
     *            path as a list of coordinates
     */
    public void logPath(MapContainer map, List<MapCoordinate> path, String name)
    {
        String step = "";

        // Create new Document
        Document pathxml;
        try
        {
            pathxml = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();

            // Add root node "map"
            Element root = pathxml.createElement("map");
            step = String.valueOf(map.getStep());
            root.setAttribute("step", step);
            root.setAttribute("simID", String.valueOf(map.get_simID()));
            pathxml.appendChild(root);

            for (MapCoordinate coord : path)
            {
                Element cell = pathxml.createElement("cell");
                cell.setAttribute("x", String.valueOf(coord.getX()));
                cell.setAttribute("y", String.valueOf(coord.getY()));
                root.appendChild(cell);
            }

            // Prepare the DOM document for writing
            Source source = new DOMSource(pathxml);

            String team = map.get_ownTeam();
            String simid = map.get_simID();
            String[] id = simid.split("-");

            String gamename = "gamename";
            String simname = "simname";

            if (id.length >= 2)
            {
                gamename = id[0];
                simname = id[1];
            }

            String foldername = "logs/" + gamename + "/" + simname;
            foldername += "/" + "path/" + team;
            foldername += "/herd" + getGoalID() + "-" + name;

            File folder = new File(foldername);

            folder.mkdirs();

            File file = new File(foldername + "/" + (map.getStep() + 1) + ".xml");
            try
            {
                file.createNewFile();
            }
            catch (IOException e)
            {
            }

            StreamResult result = new StreamResult(file.toURI().getPath());

            // Write the DOM document to the file
            Transformer xformer = TransformerFactory.newInstance().newTransformer();
            xformer.transform(source, result);
        }
        catch (TransformerConfigurationException e)
        {
        }
        catch (TransformerException e)
        {
        }
        catch (ParserConfigurationException e)
        {
            e.printStackTrace();
        }
    }

    private MapCoordinate getAgentPositionByAngle(MapCoordinate center, MapCoordinate wp, double radius, double angle)
    {
        MapCoordinate direction = wp.subtract(center);

        // calculate new direction (turn direction by angle)
        double x = Math.cos(angle) * direction.getX() - Math.sin(angle) * direction.getY();
        double y = Math.sin(angle) * direction.getX() + Math.cos(angle) * direction.getY();

        // factor to set the length of the vector to the radius
        double factor = radius / Math.sqrt(x * x + y * y);

        x = x * factor;
        y = y * factor;

        return center.add(new MapCoordinate((int) x, (int) y));
    }

    /**
     * Helper enum for the goal status
     * 
     * @author Christian Loosli & Adrian Pauli
     * 
     */
    private enum HerderStatus
    {
        none, working, newHerd, pathFound, preparingHerders, preparedHerders, entanglingHerd, entangledHerd, movingHerd, waitingForFenceOpen, movingHerdIn
    }

    /**
     * Helper enum for positions relative to the herd
     * 
     * @author Christian Loosli & Adrian Pauli
     * 
     */
    private enum Position
    {
        TOP_MID, TOP_MID_RIGHT, TOP_RIGHT_EDGE, RIGHT_TOP, RIGHT_MID, RIGHT_BOTTOM, BOTTOM_RIGHT_EDGE, BOTTOM_MID_RIGHT, BOTTOM_MID, BOTTOM_MID_LEFT, BOTTOM_LEFT_EDGE, LEFT_BOTTOM, LEFT_MID, LEFT_TOP, TOP_LEFT_EDGE, TOP_MID_LEFT
    }
    

}
