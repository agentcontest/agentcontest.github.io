package ch.bfh.massim.goals.herder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import ch.bfh.massim.framework.IMapField;
import ch.bfh.massim.framework.MapCoordinate;
import ch.bfh.massim.framework.mapagent.MapFenceInfo;
import ch.bfh.massim.framework.mapagent.MapFieldGround;
import ch.bfh.massim.framework.pathfinder.PathFinder;

/**
 * This Class contains some methotes to handle fencerelatet tasks. It can be
 * used to calculate the positions of fences.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class MapFenceCalculation2
{
    private IMapField[][] _map;
    private MapCoordinate _waypoint;
    private Map<String, MapCoordinate> _agentPosition;
    private PathFinder _pf = new PathFinder();

    private List<MapCoordinate> _ignoredList = new ArrayList<MapCoordinate>();

    /**
     * Creates a new Instance of this class.
     * 
     * @param map
     *            the map, where the path should be found on
     * @param agentPos
     *            the position of all the agents in a group
     * @param waypoint
     *            the waypoint the agents are heading for
     */
    public MapFenceCalculation2(IMapField[][] map, Map<String, MapCoordinate> agentPos, MapCoordinate waypoint)
    {
        _map = map;
        _waypoint = waypoint;
        _agentPosition = agentPos;

        _pf.setIgnoreagents(true);
        _pf.setIgnorecows(true);
        _pf.setIgnoreunknowncontent(false);
        _pf.setIgnoreclosedfence(true);
    }

    /**
     * Adds for all agents the waypoint as target.
     * 
     * @return a Map, containing the individual target for each agent.
     */
    public Map<String, MapCoordinate> calculateSimpleWaypointPath()
    {
        Map<String, MapCoordinate> targetMap = new HashMap<String, MapCoordinate>();
        for (Entry<String, MapCoordinate> element : _agentPosition.entrySet())
        {
            targetMap.put(element.getKey(), null);
        }
        return targetMap;
    }

    /**
     * Calculates the induvidual target for each Agent, by considering the
     * fence. The fences can be passed, if the Agents uses this target
     * positions.
     * 
     * @return a Map, containing the individual target for each agent.
     *         Considering fences.
     */
    public Map<String, MapCoordinate> calculateWithFencePath()
    {

        List<MapFenceInfo> globalFenceList = new ArrayList<MapFenceInfo>();

        // System.err.println("Number of Agents: " + _agentPosition.size());

        // if no fence is found => return waypoints for each agent
        Map<String, MapCoordinate> targetMap = calculateSimpleWaypointPath();

        for (Entry<String, MapCoordinate> element : _agentPosition.entrySet())
        {

            // get the path to the waypoint
            List<MapCoordinate> path = _pf.getPath(_map, element.getValue(), _waypoint);

            if (path != null && path.size() > 0)
            {

                // add new targetpoint, which is in the local sight of the agent
                if (path.size() > 8)
                {
                    //targetMap.put(element.getKey(), path.get(8));
                }

                // get all the fences on that path
                List<MapFenceInfo> fenceList = getFencesOnPath(path, element.getValue(), _map);

                // System.err.println("Gates found " + element.getKey() + ": " + fenceList.size());

                // seek the fences in the global fence list
                for (MapFenceInfo fenceInfo : fenceList)
                {
                    MapFenceInfo found = null;
                    for (MapFenceInfo globalFenceInfo : globalFenceList)
                    {
                        if (globalFenceInfo.isSameFence(fenceInfo))
                        {
                            found = globalFenceInfo;
                            break;
                        }
                    }
                    if (found != null)
                    {
                        // TODO: sort the globalFenceList
                        globalFenceList.remove(found);
                        globalFenceList.add(found);
                        found._agentBefore.put(element.getKey(), element.getValue());
                    }
                    else
                    {
                        globalFenceList.add(fenceInfo);
                        fenceInfo._agentBefore.put(element.getKey(), element.getValue());
                    }
                }
            }
        }

        for (Entry<String, MapCoordinate> element : _agentPosition.entrySet())
        {
            // fill the after-list
            for (MapFenceInfo fenceInfo : globalFenceList)
            {
                if (!fenceInfo._agentBefore.containsKey(element.getKey()))
                {
                    fenceInfo._agentAfter.put(element.getKey(), element.getValue());
                }
            }
        }

        if (globalFenceList.size() > 0)
        {
            List<String> usedList = new ArrayList<String>();

            for (MapFenceInfo fenceInfo : globalFenceList)
            {

                MapCoordinate coordBefor = null, coordAfter = null;

                if (fenceInfo.getSwitchcoord() != null)
                {

                    coordBefor = fenceInfo.getLeaderSideCoord();
                    coordAfter = fenceInfo.getOtherSideCoord();

                    _ignoredList.add(fenceInfo.getStartPoint());

                }
                else
                {

                    // TODO calculate the open end !!
                    MapCoordinate correction = fenceInfo.getBeforCorrection();
                    MapCoordinate target = fenceInfo.getStartPoint();
                    coordBefor = target.subtract(correction);
                    coordAfter = target.add(correction);

                    // _ignoredList.add(target.add(fenceInfo.getStartCoordCorrection(target)));
                }

                // System.err.println("Fence: befor:" + fenceInfo._agentBefore.size() + " after:"
                //        + fenceInfo._agentAfter.size());

                if (fenceInfo._agentBefore.size() > 1 && coordBefor != null)
                {
                    String nearestAgent = getNearestAgent(fenceInfo._agentBefore, coordBefor, usedList);
                    if (!nearestAgent.isEmpty())
                    {
                        targetMap.put(nearestAgent, coordBefor);
                        usedList.add(nearestAgent);
                        // System.err.println("Agent " + nearestAgent + " goes befor " + coordBefor);
                    }
                }

                if (fenceInfo._agentAfter.size() > 0 && coordAfter != null)
                {
                    String nearestAgent = getNearestAgent(fenceInfo._agentAfter, coordAfter, usedList);
                    if (!nearestAgent.isEmpty())
                    {
                        targetMap.put(nearestAgent, coordAfter);
                        usedList.add(nearestAgent);
                        // System.err.println("Agent " + nearestAgent + " goes after " + coordAfter);
                    }
                }
            }
        }
        return targetMap;
    }

    /**
     * Get the nearest agent from a given coordinate
     * 
     * @param agentList
     *            the list of agents to choose from
     * @param coord
     *            the coordinate
     * @param usedList
     *            the list of agents, which already have something to do.
     * @return name of the nearest, free agent
     */
    private String getNearestAgent(Map<String, MapCoordinate> agentList, MapCoordinate coord, List<String> usedList)
    {
        String nearest = "";
        int distance = Integer.MAX_VALUE;
        for (Entry<String, MapCoordinate> element : agentList.entrySet())
        {
            if (!usedList.contains(element.getKey()))
            {
                int newDistance = element.getValue().distance(coord);
                if (newDistance < distance)
                {
                    distance = newDistance;
                    nearest = element.getKey();
                }
            }
        }
        return nearest;
    }

    /**
     * Recognizes all the fences on a Path.
     * 
     * @param path
     *            the path
     * @param map
     *            the map
     * @return list with all the coordinates crossing a fence
     */
    private List<MapCoordinate> fenceRecognizion(List<MapCoordinate> path, IMapField[][] map)
    {
        List<MapCoordinate> result = new ArrayList<MapCoordinate>();
        for (int i = 0; i < path.size(); i++)
        {
            MapCoordinate coord = path.get(i);
            IMapField field = map[coord.getX()][coord.getY()];
            if (field.get_ground() == MapFieldGround.fenceclosed || field.get_ground() == MapFieldGround.fenceopen)
            {
                result.add(coord);
            }
        }
        return result;
    }

    /**
     * Get all the fences, the path is crossing.
     * 
     * @param path
     *            the path
     * @param leaderpos
     *            the position of the leader
     * @param map
     *            the map
     * @return a list with all the fences
     */
    private List<MapFenceInfo> getFencesOnPath(List<MapCoordinate> path, MapCoordinate leaderpos, IMapField[][] map)
    {
        List<MapCoordinate> fencePoints = fenceRecognizion(path, map);
        List<MapFenceInfo> result = new ArrayList<MapFenceInfo>();
        for (MapCoordinate coord : fencePoints)
        {
            result.add(new MapFenceInfo(map, coord, leaderpos));
        }
        return result;
    }

    /**
     * @return a list with all the coordinates which shoud be ignored by the
     *         pathfinding.
     */
    public List<MapCoordinate> getIgnoredList()
    {
        return _ignoredList;
    }

}
