package ch.bfh.massim.goals.herder;

import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;

import ch.bfh.massim.framework.cowherd.CowHerd;
import ch.bfh.massim.framework.cowherd.CowHerdStatus;
import ch.bfh.massim.framework.cowherd.HerdClassifier;
import ch.bfh.massim.framework.mapagent.MapContainer;
import ch.bfh.massim.framework.planingunit.BaseCreator;
import ch.bfh.massim.framework.planingunit.IGoal;

/**
 * Class to create herder goals. This class is used to create goals which try to
 * move cows to the own corral. This class provides methods defined in
 * BaseCreator and helper methods needed.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class HerderCreator extends BaseCreator {

	private List<HerderGoal> _runningGoals = new ArrayList<HerderGoal>();
	private List<String> _herdids = new ArrayList<String>();
	private HerdClassifier _classify;
	private int _laststep = -1;
	private int _lastupdate = -1;

	// settings:
	private final int STEPWAIT = 4;
	private final int NUMBEROFGOALS = 4;
	// Search depth for the herd classifier
	private final int DEPTH = 2;
	// Rounds since the cow was seen for the classifier.
	// We are only interested in currently seen cows
	private final int SEEN = 1000;

	/**
	 * Method to calculate the goals.
	 * 
	 * @param map
	 *            the map we are playing on
	 * @param goals
	 *            a priority queue to fill the goals in
	 */
	@Override
	public void calculateGoals(MapContainer map, PriorityQueue<IGoal> goals) {

		if (_lastupdate == map.getStep())
			return;

		_lastupdate = map.getStep();

		// update goals only all "stepwait" steps
		if (_laststep < 0 || (map.getStep() - _laststep >= STEPWAIT)) {
			_laststep = map.getStep();

			_classify = HerdClassifier.getInstance(map.get_ownTeam());

			ArrayList<CowHerd> guidedherds = new ArrayList<CowHerd>();
			ArrayList<CowHerd> freeherds = new ArrayList<CowHerd>();
			guidedherds.addAll(_classify.classifyHerds(map, DEPTH, SEEN, _herdids));
			freeherds.addAll(_classify.getFreeHerds());

			System.out.println("---");
			System.out.println("number of herdes: " + freeherds.size());
			int a = 0;
			for (CowHerd cowHerd : freeherds) {
				a += cowHerd.getCows().size();
			}
			System.out.println("number of Cows: " + a);
			
			
			ArrayList<CowHerd> allherds = new ArrayList<CowHerd>();
			//allherds.addAll(guidedherds);
			allherds.addAll(freeherds);

			// only keep goals in progress
			List<HerderGoal> newGoals = new ArrayList<HerderGoal>();

			for (HerderGoal goal : _runningGoals) {
				if (goal.isInProgress()) {
					CowHerd goalherd = goal.get_herd();
					System.out.println("Goal herd center: " + goalherd.getGeometricCenter());
					CowHerd best = null;
					int dist = Integer.MAX_VALUE;
					int besti = -1;
					//int herdsize = -1;
					for (int i = 0; i < allherds.size(); i++) {
						int tmp = allherds.get(i).getGeometricCenter().distance(goalherd.getGeometricCenter());
						
						int herdsize = allherds.get(i).getCows().size();
						
						if (tmp < dist && herdsize >= 3) {
							//if ((newherdsize > herdsize) || ) {
								dist = tmp;
								best = allherds.get(i);
								besti = i;
							//}
						}
					}

					if (best != null) {
						if (goalherd.getStatus().equals(CowHerdStatus.INOWNCORRAL)) // goal
																					// check
						{
							
							goal.releaseAgents();
						} else {
							System.out.println("Herd update distance:" + dist + " newcenter: " + best.getGeometricCenter() );
							goal.updateHerd(best);
							newGoals.add(goal);
							allherds.remove(besti);
							logHerd(map, best, goal.getGoalID());
						}
					} else {
						System.out.println("Herd disparu");
						goal.releaseAgents();
					}

				}

				/*
				 * 
				 * CowHerd goalherd = goal.get_herd();
				 * 
				 * 
				 * 
				 * 
				 * if (!guidedherds.contains(goalherd)) { goal.releaseAgents();
				 * _herdids.remove(goalherd.getUniqueID()); } else { CowHerd
				 * listherd = guidedherds.get(guidedherds.indexOf(goalherd));
				 * 
				 * if (goal.isInProgress()) { if (goalherd == null) {
				 * goal.releaseAgents(); } else { if
				 * (goalherd.getStatus().equals(CowHerdStatus.INOWNCORRAL)) //
				 * goal // check { goal.releaseAgents(); } else { // Provide
				 * updated info to the goal goal.updateHerd(listherd);
				 * newGoals.add(goal); logHerd(map, listherd); }
				 * 
				 * } } }
				 */
			}

			for (CowHerd herd : allherds) {

				// Only add a goal for herds that are in free or unknown state.
				// The other ones will be treated
				// by the disturber and keeper creators.
				if ((herd.getStatus().equals(CowHerdStatus.FREE) || herd.getStatus().equals(CowHerdStatus.UNKNOWN) ) && herd.getCows().size() >= 3) {
					if (newGoals.size() < NUMBEROFGOALS) {
						HerderGoal goal = new HerderGoal(_con, herd);
						newGoals.add(goal);
						herd.setAllUniqueID(_classify.getNextHerdID());
						_herdids.add(herd.getUniqueID());
						//logHerd(map, herd);
					}
				}
			}

			_runningGoals = newGoals;
			goals.addAll(_runningGoals);

		}

		// Pass the new map each round
		for (HerderGoal goal : _runningGoals) {
			if (goal.isInProgress()) {
				goal.updateMap(map);
				goal.updateSituation();
			}
		}

	}

	/**
	 * Helper method to log the herd.
	 * 
	 * @param map
	 *            the map we are playing on
	 * @param herd
	 *            the heard to log
	 */
	private void logHerd(MapContainer map, CowHerd herd, int goalID) {

		// Log the herd
		String simID = map.get_simID();
		String team = map.get_ownTeam();

		int step = map.getStep();
		String fullid[] = simID.split("-");
		String gameid = "";
		String simid = "";

		if (fullid.length >= 2) {
			gameid = fullid[0];
			simid = fullid[1];

		}

		herd.logHerd(gameid, simid, team, step, goalID);
	}
	
	@Override
	public void clear() {
		_runningGoals.clear();
		_herdids.clear();
		_lastupdate = -1;
		_laststep = -1;
	}

}
