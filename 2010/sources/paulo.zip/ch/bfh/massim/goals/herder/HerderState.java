package ch.bfh.massim.goals.herder;

/**
 * 
 * Enum to represent a cow herd status Default is FREE, UNKNOWN is for unknown
 * state.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public enum HerderState
{
    free, unknown, unableToReachGoal, leadToHerd, followToHerd, entangleHerd, entangledHerd, leadHerdHome, followHerdHome, waitForOpenFence, openFence;

    /**
     * Method to convert from string to enum.
     * 
     * @param token
     *            the string to convert
     * @return the corresponding enum
     */
    public static HerderState type(String token)
    {
        return HerderState.valueOf(token);
    }

    /**
     * Method to convert from enum to string.
     * 
     * @param t
     *            enum to convert
     * @return string representing the enum
     */
    public static String token(HerderState t)
    {
        return t.name();
    }
}
