/**
 * Contains the classes and enums needed for the goal representation of 
 * bringing cows home to the own corral.
 */
package ch.bfh.massim.goals.herder;