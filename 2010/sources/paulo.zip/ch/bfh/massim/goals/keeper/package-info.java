/**
 * Contains the classes needed for the goal representation of 
 * keeping cows in the own corral.
 */
package ch.bfh.massim.goals.keeper;