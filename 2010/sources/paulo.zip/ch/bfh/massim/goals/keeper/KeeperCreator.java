package ch.bfh.massim.goals.keeper;

import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;

import ch.bfh.massim.framework.cowherd.CowHerd;
import ch.bfh.massim.framework.cowherd.CowHerdStatus;
import ch.bfh.massim.framework.cowherd.HerdClassifier;
import ch.bfh.massim.framework.mapagent.MapContainer;
import ch.bfh.massim.framework.planingunit.BaseCreator;
import ch.bfh.massim.framework.planingunit.IGoal;

/**
 * Class to create keeper goals. This class is used to create goals which try to
 * keep own cows in the corral. This class provides methods defined in
 * BaseCreator and helper methods needed.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class KeeperCreator extends BaseCreator
{
    private List<KeeperGoal> _runningGoals = new ArrayList<KeeperGoal>();
    private HerdClassifier _classify;
    private int _laststep = -1;
    private int _lastupdate = -1;

    // settings:
    private final int STEPWAIT = 4;
    private final int NUMBEROFGOALS = 2;
    // Search depth for the herd classifier
    private final int DEPTH = 3;
    // Rounds since the cow was seen for the classifier.
    // We are only interested in currently seen cows
    private final int SEEN = 0;

    /**
     * Method to calculate the goals.
     * 
     * @param map
     *            the map we are playing on
     * @param goals
     *            a priority queue to fill the goals in
     */
    @Override
    public void calculateGoals(MapContainer map, PriorityQueue<IGoal> goals)
    {
        if (_lastupdate == map.getStep())
            return;

        _lastupdate = map.getStep();

        // update goals only all "stepwait" steps
        if (_laststep < 0 || (map.getStep() - _laststep >= STEPWAIT))
        {
            _laststep = map.getStep();

            _classify = HerdClassifier.getInstance(map.get_ownTeam());
            ArrayList<CowHerd> herds = new ArrayList<CowHerd>();
            herds.addAll(_classify.classifyHerds(map, DEPTH, SEEN));

            // only keep goals in progress
            List<KeeperGoal> newGoals = new ArrayList<KeeperGoal>();

            for (KeeperGoal goal : _runningGoals)
            {
                CowHerd goalherd = goal.get_herd();

                if (!herds.contains(goalherd))
                {
                    goal.releaseAgents();
                }

                if (goal.isInProgress())
                {

                    if (goalherd == null)
                    {
                        goal.releaseAgents();
                    }
                    else
                    {

                        // Provide updated info to the goal
                        goal.updateHerd(herds.get(herds.indexOf(goalherd)));
                        newGoals.add(goal);

                    }
                }
            }

            for (CowHerd herd : herds)
            {
                // Only add a goal for herds that are in own corral
                if (herd.getStatus().equals(CowHerdStatus.INOWNCORRAL))
                {
                    if (newGoals.size() < NUMBEROFGOALS)
                    {
                        KeeperGoal goal = new KeeperGoal(_con, herd);
                        newGoals.add(goal);

                        // Log the herd
                        // String simID = map.get_simID();
                        // String team = map.get_ownTeam();

                        // int step = map.getStep();
                        // String fullid[] = simID.split("-");
                        // String gameid = "";
                        // String simid = "";

                        // if (fullid.length >= 2)
                        // {
                        //    gameid = fullid[0];
                        //    simid = fullid[1];

                        // }

                        //herd.logHerd(gameid, simid, team, step);
                    }
                }
            }

            _runningGoals = newGoals;
            goals.addAll(_runningGoals);

        }

        // Pass the new map each round
        for (KeeperGoal goal : _runningGoals)
        {
            if (goal.isInProgress())
            {
                goal.updateMap(map);
                goal.updateSituation();
            }
        }

    }

	@Override
	public void clear() {
		// TODO Auto-generated method stub
		_runningGoals.clear();
		_laststep = -1;
		_lastupdate = -1;
	}
}
