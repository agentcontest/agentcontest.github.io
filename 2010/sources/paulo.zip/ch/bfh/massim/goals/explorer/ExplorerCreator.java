/**
 * 
 */
package ch.bfh.massim.goals.explorer;

import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;

import ch.bfh.massim.framework.mapagent.MapContainer;
import ch.bfh.massim.framework.mapagent.MapField;
import ch.bfh.massim.framework.planingunit.BaseCreator;
import ch.bfh.massim.framework.planingunit.IGoal;

/**
 * This Creator generates Goals, so that the Map can be explored. The goles uses
 * the FollowWP-roles to work.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class ExplorerCreator extends BaseCreator
{

    private List<ExplorerGoal> _runningGoals = new ArrayList<ExplorerGoal>();
    private int _laststep = -1;

    // settings:
    private final int stepwait = 5;
    private final int numberofgoals = 4;
    private final int viewsize = 17;

    /**
     * Method to calculate the goals
     * @param map map we are currently playing on 
     * @param goals the priority queue to fill the goals in 
     */
    @Override
    public void calculateGoals(MapContainer map, PriorityQueue<IGoal> goals)
    {

        // update goals only all "stepwait" steps
        if (_laststep < 0 || (map.getStep() - _laststep >= stepwait))
        {
            _laststep = map.getStep();

            // create mean map
            int[][] meanMap = createMeanMap(map.getMap());

            //System.err.println("meanmap:");
            //printMap(meanMap);

            // only keep goals in progress
            List<ExplorerGoal> newGoals = new ArrayList<ExplorerGoal>();
            for (ExplorerGoal goal : _runningGoals)
            {
                if (goal.isInProgress())
                {
                    // check if goal is reached, then release agents
                    int x = goal.getMeanFieldX();
                    int y = goal.getMeanFieldY();
                    if (meanMap[x][y] > 0)
                    {
                        goal.update(map);
                        newGoals.add(goal);
                        meanMap[x][y] = 0;
                    }
                    else
                    {
                        goal.releaseAgents();
                    }
                }
            }

            while (newGoals.size() < numberofgoals)
            {
                // create weightedMap
                int[][] weightedMap = createWeightedMap(meanMap);
                // System.err.println("weightedMap:");
                // printMap(weightedMap);

                // get Max Value
                int imax = 0, jmax = 0;
                int maxval = 0;
                for (int i = 0; i < weightedMap.length; i++)
                {
                    for (int j = 0; j < weightedMap[0].length; j++)
                    {
                        if (weightedMap[i][j] > maxval)
                        {
                            maxval = weightedMap[i][j];
                            imax = i;
                            jmax = j;
                        }
                    }
                }

                if (maxval > 0)
                {
                    // calculate target pos
                    double iViewSize = (double) map.getMap().length / meanMap.length;
                    double jViewSize = (double) map.getMap()[0].length / meanMap[0].length;
                    int targetx = (int) ((iViewSize * imax) + (iViewSize / 2));
                    int targety = (int) ((jViewSize * jmax) + (jViewSize / 2));

                    // create goal
                    ExplorerGoal goal = new ExplorerGoal(_con, imax, jmax, targetx, targety, maxval);
                    newGoals.add(goal);

                    // update meanmap
                    meanMap[imax][jmax] = 0;
                }
                else
                {
                    break;
                }
            }

            _runningGoals = newGoals;
            goals.addAll(_runningGoals);
        }
    }

    /**
     * Adds to the MeanMap the additional points from the neighbors.
     * 
     * @param map
     *            the MeanMap
     * @return the WeightedMap
     */
    private int[][] createWeightedMap(int[][] map)
    {
        int imax = map.length;
        int jmax = map[0].length;
        int[][] weightedMap = new int[imax][jmax];
        for (int i = 0; i < imax; i++)
        {
            for (int j = 0; j < jmax; j++)
            {
                weightedMap[i][j] = map[i][j] + getWeight(map, i, j);
            }
        }
        return weightedMap;
    }

    /**
     * Gets the weight of a field.
     * 
     * @param map
     *            the map
     * @param ipos
     *            the x pos of the field
     * @param jpos
     *            the y pos of the field
     * @return the weight
     */
    private int getWeight(int[][] map, int ipos, int jpos)
    {
        int imax = map.length;
        int jmax = map[0].length;
        int rings = Math.max(imax, jmax);

        int totalsum = 0;

        for (int r = 1; r < rings; r++)
        {
            int i, j;
            int sum = 0;
            int count = 0;
            for (int k = 0; k < 2 * r; k++)
            {
                // top stripe
                i = ipos - r + k;
                j = jpos - r;
                if (i >= 0 && j >= 0 && i < imax && j < jmax)
                {
                    sum += map[i][j];
                    count++;
                }
                // right stripe
                i = ipos + r;
                j = jpos - r + k;
                if (i >= 0 && j >= 0 && i < imax && j < jmax)
                {
                    sum += map[i][j];
                    count++;
                }
                // bottom stripe
                i = ipos + r - k;
                j = jpos + r;
                if (i >= 0 && j >= 0 && i < imax && j < jmax)
                {
                    sum += map[i][j];
                    count++;
                }
                // left stripe
                i = ipos - r;
                j = jpos + r - k;
                if (i >= 0 && j >= 0 && i < imax && j < jmax)
                {
                    sum += map[i][j];
                    count++;
                }
            }
            if (count > 0)
            {
                totalsum += sum / (count * (r + 1));
            }
        }

        return totalsum;
    }

    /**
     * Creates a map by counting the unknown fields in an area with almost the
     * size of the viewrange of the cowboy agents.
     * 
     * @param map
     *            the original map
     * @return the MeanMap
     */
    private int[][] createMeanMap(MapField[][] map)
    {

        // breite der MeanMap
        int imax = map.length / viewsize + 1;
        int jmax = map[0].length / viewsize + 1;

        // groesse der Felder der MeanMap
        double iViewSize = (double) map.length / imax;
        double jViewSize = (double) map[0].length / imax;

        int[][] newmap = new int[imax][jmax];

        for (int i = 0; i < imax; i++)
        {
            int ipos = (int) (i * iViewSize);
            for (int j = 0; j < jmax; j++)
            {
                int jpos = (int) (j * jViewSize);
                newmap[i][j] = getMeanValue(map, ipos, jpos, (int) iViewSize, (int) jViewSize);
            }
        }

        return newmap;
    }

    /**
     * Summes the unknown fields of an arean.
     * 
     * @param map
     *            the map
     * @param ipos
     *            the x position
     * @param jpos
     *            the y position
     * @param iViewSize
     *            size of the area x
     * @param jViewSize
     *            size of the area y
     * @return
     */
    private int getMeanValue(MapField[][] map, int ipos, int jpos, int iViewSize, int jViewSize)
    {
        // System.err.println("calc mean with " + ipos + " " + jpos);
        int mean = 0;
        for (int i = ipos; i < ipos + iViewSize; i++)
        {
            for (int j = jpos; j < jpos + jViewSize; j++)
            {
                if (map[i][j].get_lastSeen() < 0)
                {
                    mean++;
                }
            }
        }
        return mean;
    }

    /**
     * Prints the map to the console.
     * 
     * @param map
     *            the map
     */
    @SuppressWarnings("unused") // debug only
    private void printMap(int[][] map)
    {
        int imax = map.length;
        int jmax = map[0].length;
        System.out.println("+-------------------------+");
        for (int i = 0; i < imax; i++)
        {
            String line = "| ";
            for (int j = 0; j < jmax; j++)
            {
                line += map[i][j] + " ";
            }
            System.out.println(line + "|");
        }
        System.out.println("+-------------------------+");
    }

	@Override
	public void clear() {
		_runningGoals.clear();
		_laststep = -1;
	}

}
