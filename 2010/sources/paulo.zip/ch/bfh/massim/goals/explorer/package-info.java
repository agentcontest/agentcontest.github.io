/**
 * Contains the classes needed for the goal representation of 
 * exploring the map. 
 */
package ch.bfh.massim.goals.explorer;