package ch.bfh.massim.goals.explorer;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import ch.bfh.massim.framework.ComClientConnection;
import ch.bfh.massim.framework.MapCoordinate;
import ch.bfh.massim.framework.mapagent.MapContainer;
import ch.bfh.massim.framework.pathfinder.PathFinder;
import ch.bfh.massim.framework.planingunit.AgentPlaning;
import ch.bfh.massim.framework.planingunit.IGoal;
import ch.bfh.massim.goals.FollowWPInitiatior;

/**
 * This goal is created by the ExplorerCreator. It has a target and tries to
 * move the agents to this target.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class ExplorerGoal implements IGoal
{
    private PathFinder _pathfinder = new PathFinder();

    private int _prio;
    private int _mfieldX;
    private int _mfieldY;
    private ComClientConnection _con;
    private MapCoordinate _target;

    private AgentPlaning _leader;
    private AgentPlaning[] _assistant;

    private boolean _inProgress = false;

    /**
     * Creates the explorer goal
     * 
     * @param con
     *            connection to the ComServer
     * @param mfieldX
     *            mean map position x
     * @param mfieldY
     *            mean map psoition y
     * @param targetx
     *            target of the exploration x
     * @param targety
     *            target of the exploration y
     * @param prio
     *            priority of the gaol
     */
    public ExplorerGoal(ComClientConnection con, int mfieldX, int mfieldY, int targetx, int targety, int prio)
    {
        _con = con;
        _mfieldX = mfieldX;
        _mfieldY = mfieldY;
        _target = new MapCoordinate(targetx, targety);
        _prio = prio;
    }

    /**
     * @see ch.bfh.massim.framework.planingunit.IGoal#getAgentNumber()
     */
    @Override
    public int getAgentNumber()
    {
        return 2;
    }

    /**
     * @see ch.bfh.massim.framework.planingunit.IGoal#getPriority()
     */
    @Override
    public int getPriority()
    {
        return _prio;
    }

    /**
     * @see ch.bfh.massim.framework.planingunit.IGoal#getPriorityWithAgents(ch.bfh.massim.framework.planingunit.AgentPlaning[])
     */
    @Override
    public int getPriorityWithAgents(AgentPlaning[] agents)
    {
        return 0;
    }

    /**
     * @see ch.bfh.massim.framework.planingunit.IGoal#isInProgress()
     */
    @Override
    public boolean isInProgress()
    {
        return _inProgress;
    }

    /**
     * @see ch.bfh.massim.framework.planingunit.IGoal#releaseAgents()
     */
    @Override
    public void releaseAgents()
    {
        _leader.setFree(true);
        for (AgentPlaning assist : _assistant)
        {
            assist.setFree(true);
        }

        _inProgress = false;
    }

    /**
     * @see ch.bfh.massim.framework.planingunit.IGoal#setAgents(ch.bfh.massim.framework.planingunit.AgentPlaning[],
     *      ch.bfh.massim.framework.mapagent.MapContainer)
     */
    @Override
    public void setAgents(AgentPlaning[] agents, MapContainer map)
    {
        _assistant = new AgentPlaning[agents.length - 1];
        for (int i = 0; i < agents.length; i++)
        {
            agents[i].setFree(false);
            if (i == 0)
            {
                _leader = agents[i];
            }
            else
            {
                _assistant[i - 1] = agents[i];
            }
        }
        updateLeader(map);

        updateAssistant();

        _inProgress = true;
    }

    /**
     * sent the role to the assistants
     */
    private void updateAssistant()
    {
        List<String> assistants = new ArrayList<String>(_assistant.length);
        for (AgentPlaning agent : _assistant)
        {
            assistants.add(agent.get_agentName());
        }
        FollowWPInitiatior.sendRoleToAssistants(assistants, _leader.get_agentName(), _con);
    }

    /**
     * send and create the role to the leader
     * 
     * @param map
     *            the current map we are playing on
     */
    private void updateLeader(MapContainer map)
    {
        MapCoordinate leaderPos = map.getAgentPosition(_leader.get_agentName());

        List<MapCoordinate> coords = new ArrayList<MapCoordinate>();
        coords.add(leaderPos);

        for (AgentPlaning agent : _assistant)
        {
            coords.add(map.getAgentPosition(agent.get_agentName()));
        }

        try
        {
            // calculate centerpoint of the group
            MapCoordinate centercoord = MapCoordinate.calculateCenter(coords.toArray(new MapCoordinate[0]));

            centercoord = _pathfinder.getNearestNotblockedField(map.getMap(), centercoord, _target);

            List<MapCoordinate> path = _pathfinder.getPath(map.getMap(), centercoord, _target);

            if (path == null)
                return;

            logPath(map, path);

            // only take every eight element as waypoint
            List<MapCoordinate> wpPath = FollowWPInitiatior.createWaypointPath(path, 8, 0, 8);

            // inform agent
            List<String> al = new ArrayList<String>();
            for (AgentPlaning assistant : _assistant)
            {
                al.add(assistant.get_agentName());
            }

            FollowWPInitiatior.sendRoleToLeader(wpPath, al, _leader.get_agentName(), _con);

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    /**
     * 
     * @return x position in the MeanMap
     */
    public int getMeanFieldX()
    {
        return _mfieldX;
    }

    /**
     * 
     * @return y position in the MeanMap
     */
    public int getMeanFieldY()
    {
        return _mfieldY;
    }

    /**
     * update the goal
     * 
     * @param map
     *            the map
     */
    public void update(MapContainer map)
    {
        updateLeader(map);
    }

    /**
     * Writes a log for the path, so that it can be watched in the reviewGui
     * 
     * @param map
     *            the map
     * @param path
     *            the path
     */
    public void logPath(MapContainer map, List<MapCoordinate> path)
    {
        String step = "";

        // Create new Document
        Document pathxml;
        try
        {
            pathxml = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();

            // Add root node "map"
            Element root = pathxml.createElement("map");
            step = String.valueOf(map.getStep());
            root.setAttribute("step", step);
            root.setAttribute("simID", String.valueOf(map.get_simID()));
            pathxml.appendChild(root);

            for (MapCoordinate coord : path)
            {
                Element cell = pathxml.createElement("cell");
                cell.setAttribute("x", String.valueOf(coord.getX()));
                cell.setAttribute("y", String.valueOf(coord.getY()));
                root.appendChild(cell);
            }

            // Prepare the DOM document for writing
            Source source = new DOMSource(pathxml);

            String team = map.get_ownTeam();
            String simid = map.get_simID();
            String[] id = simid.split("-");

            String gamename = "gamename";
            String simname = "simname";

            if (id.length >= 2)
            {
                gamename = id[0];
                simname = id[1];
            }

            String foldername = "logs/" + gamename + "/" + simname;
            foldername += "/" + "path/" + team;
            foldername += "/" + _mfieldX + "_" + _mfieldY;
            foldername += "-" + _target.getX() + "_" + _target.getY();

            File folder = new File(foldername);

            folder.mkdirs();

            File file = new File(foldername + "/" + (map.getStep() + 1) + ".xml");
            try
            {
                file.createNewFile();
            }
            catch (IOException e)
            {
            }

            StreamResult result = new StreamResult(file.toURI().getPath());

            // Write the DOM document to the file
            Transformer xformer = TransformerFactory.newInstance().newTransformer();
            xformer.transform(source, result);
        }
        catch (TransformerConfigurationException e)
        {
        }
        catch (TransformerException e)
        {
        }
        catch (ParserConfigurationException e)
        {
            e.printStackTrace();
        }
    }

}
