package ch.bfh.massim.roles.cowguard;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import ch.bfh.massim.framework.Direction;
import ch.bfh.massim.framework.MapCoordinate;
import ch.bfh.massim.framework.commessages.ComMessage;
import ch.bfh.massim.framework.rolebasedagent.RoleMessage;

/**
 * Class representing a cow guard role message. This class extends RoleMessage.
 * The message is used to give a agent with the CowGuard role a initial list of
 * fields which he should cover. Along with the fields the direction of the cows
 * relative to this fields will be given. He should try to prevent cows coming
 * from this direction to cross the fields.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class CowGuardRoleMessage extends RoleMessage
{

    /**
     * Default constructor
     * 
     * @param sendername
     *            sender of this message
     * @param receiver
     *            receiver of this message
     */
    public CowGuardRoleMessage(String sendername, String receiver)
    {
        super("CowGuard", sendername, receiver);
    }

    /**
     * Method to add coordinates and directions to this message
     * 
     * @param coordinates
     *            fields the agent should guard
     * @param direction
     *            direction from which the cows will come.
     */
    public void addCoordinates(List<MapCoordinate> coordinates, Direction direction)
    {
        for (MapCoordinate coordinate : coordinates)
        {
            Element el_coord = _el_role.getOwnerDocument().createElement("coord");
            el_coord.setAttribute("x", String.valueOf(coordinate.getX()));
            el_coord.setAttribute("y", String.valueOf(coordinate.getY()));
            el_coord.setAttribute("d", direction.toString());
            _el_role.appendChild(el_coord);
        }
    }

    /**
     * Method to add coordinates and directions to this message
     * 
     * @param behavior
     *            the desired behavior
     */
    public void addBehavior(Behavior behavior)
    {
        Element el_behavior = _el_role.getOwnerDocument().createElement("behavior");
        el_behavior.setAttribute("b", behavior.toString());
        _el_role.appendChild(el_behavior);
    }

    /**
     * Method to read out the coordinates with direction out of the message.
     * 
     * @return a Map with coordinate->direction tuples. Duplicates are not
     *         allowed, for each field only one direction is applicable.
     * 
     */
    public Map<MapCoordinate, Direction> getCoordinatess()
    {
        Map<MapCoordinate, Direction> coords = new HashMap<MapCoordinate, Direction>();
        NodeList nl = _el_role.getChildNodes();
        for (int i = 0; i < nl.getLength(); i++)
        {
            Node n = nl.item(i);
            if (n.getNodeType() == Element.ELEMENT_NODE && n.getNodeName().equalsIgnoreCase("coord"))
            {
                Element coord = (Element) n;
                MapCoordinate coordinate = new MapCoordinate(Integer.parseInt(coord.getAttribute("x")), Integer
                        .parseInt(coord.getAttribute("y")));
                Direction dir = Direction.valueOf(coord.getAttribute("d"));

                coords.put(coordinate, dir);
            }
        }
        return coords;
    }

    /**
     * Method to read out the behavior out of the message.
     * 
     * @return behavior of the agent.
     * 
     */
    public Behavior getBehavior()
    {
        Behavior behavior = Behavior.UNKNOWN;

        NodeList nl = _el_role.getChildNodes();
        for (int i = 0; i < nl.getLength(); i++)
        {
            Node n = nl.item(i);
            if (n.getNodeType() == Element.ELEMENT_NODE && n.getNodeName().equalsIgnoreCase("behavior"))
            {
                Element behav = (Element) n;
                behavior = Behavior.valueOf(behav.getAttribute("b"));
            }
        }
        return behavior;
    }

    /**
     * Cast constructor
     * 
     * @param message
     *            original ComMessage which is a CowGuardRoleMessage
     */
    public CowGuardRoleMessage(ComMessage message)
    {
        super(message);
    }

}
