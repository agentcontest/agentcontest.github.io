/**
 * 
 */
package ch.bfh.massim.roles.cowguard;

import java.util.HashMap;
import java.util.Map;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import ch.bfh.massim.framework.Direction;
import ch.bfh.massim.framework.MapCoordinate;
import ch.bfh.massim.framework.commessages.ComMessage;

/**
 * Class representing a cow guard field update message. This class extends
 * ComMessage. The message is used to give a agent with the CowGuard role a new
 * list of fields which he should cover. Along with the fields the direction of
 * the cows relative to this fields will be given. He should try to prevent cows
 * coming from this direction to cross the fields.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class CowGuardFieldMessage extends ComMessage
{

    /**
     * Default constructor
     * 
     * @param sender
     *            original sender of the message
     * @param coords
     *            list of coordinates for the fields to guard
     * @param direction
     *            direction of the cows relative to the fields
     */
    public CowGuardFieldMessage(String sender, MapCoordinate[] coords, Direction direction)
    {
        super(sender, "cowguardfieldmessage");

        Element messagebody = this.get_bodyElement();

        for (MapCoordinate coordinate : coords)
        {
            Element el_coord = messagebody.getOwnerDocument().createElement("coord");
            el_coord.setAttribute("x", String.valueOf(coordinate.getX()));
            el_coord.setAttribute("y", String.valueOf(coordinate.getY()));
            el_coord.setAttribute("d", direction.toString());
            messagebody.appendChild(el_coord);
        }

    }

    /**
     * Cast constructor
     * 
     * @param message
     *            original ComMessage which is a CowGuardFieldMessage
     */
    public CowGuardFieldMessage(ComMessage message)
    {
        super(message.get_message());
    }

    /**
     * Method to read out the coordinates with direction out of the message.
     * 
     * @return a Map with coordinate->direction tuples. Duplicates are not
     *         allowed, for each field only one direction is applicable.
     * 
     */
    public Map<MapCoordinate, Direction> getCoordinates()
    {
        Element messagebody = this.get_bodyElement();

        Map<MapCoordinate, Direction> coords = new HashMap<MapCoordinate, Direction>();

        NodeList nl = messagebody.getChildNodes();

        for (int i = 0; i < nl.getLength(); i++)
        {
            Node n = nl.item(i);
            if (n.getNodeType() == Element.ELEMENT_NODE && n.getNodeName().equalsIgnoreCase("coord"))
            {
                Element coord = (Element) n;
                MapCoordinate coordinate = new MapCoordinate(Integer.parseInt(coord.getAttribute("x")), Integer
                        .parseInt(coord.getAttribute("y")));
                Direction dir = Direction.valueOf(coord.getAttribute("d"));

                coords.put(coordinate, dir);
            }
        }
        return coords;
    }

}
