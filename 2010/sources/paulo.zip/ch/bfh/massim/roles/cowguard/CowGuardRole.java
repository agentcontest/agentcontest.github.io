package ch.bfh.massim.roles.cowguard;

import java.util.HashMap;
import java.util.List;

import ch.bfh.massim.framework.Direction;
import ch.bfh.massim.framework.MapCoordinate;
import ch.bfh.massim.framework.commessages.ComMessage;
import ch.bfh.massim.framework.masmessages.MasMessageAction;
import ch.bfh.massim.framework.masmessages.MasMessageRequestAction;
import ch.bfh.massim.framework.pathfinder.PathFinder;
import ch.bfh.massim.framework.rolebasedagent.*;

/**
 * Class representing a cow guard. A cow guard is an agent that has a list of
 * fields which he guards. He will try to make sure that no cow moves over this
 * fields from a direction associated with each field.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class CowGuardRole extends BaseRole
{

    private CowGuardRoleMessage _message;
    private PathFinder _pf;
    private HashMap<MapCoordinate, Direction> _guardFields;
    private Behavior _behavior;
    int ymid = 0;
    int xmid = 0;
    int ytop = 0;
    int ybtm = 0;
    int xlft = 0;
    int xrgt = 0;

    public CowGuardRole()
    {
        super("CowGuard");
        _pf = new PathFinder();
        _pf.setIgnoreagents(false);
        _pf.setIgnorecows(false);
        _pf.setIgnoreclosedfence(false);
        _guardFields = new HashMap<MapCoordinate, Direction>();
        _behavior = Behavior.UNKNOWN;
    }

    /**
     * Method to handle a action request. Will calculate the next position to go
     * to depending on the behavior, the fields to guard and the cows. Read the
     * corresponding method for each behavior.
     * 
     * @param request
     *            the move request action
     * @param action
     *            the massim action message
     */
    @Override
    public void processRequestAction(MasMessageRequestAction request, MasMessageAction action)
    {
        // get the new requested action (if any)
        updateBehavior();
        // get the new fields to guard (if any)
        updateFields();

        MapCoordinate target = null;

        switch (_behavior)
        {
            case FIXED_MID_GUARD:
            {
                target = calculateFixedGuardMove(request);
                break;
            }
            case FREE_GUARD:
            {
                target = calculateFreeGuardMove(request);
                break;
            }
            case OUT_OF_WAY_GUARD:
            {
                target = calculateOutOfWayMove(request);
                break;
            }
            case SUSPEND:
            default:
            {
                break;
            }
        }

        MapCoordinate mypos = request.getAgentPos();

        if (target != null && !target.equals(mypos))
        {
            // calculate the local coordinate on the array
            MapCoordinate localmp = new MapCoordinate(8, 8);
            MapCoordinate localwp = target.subtract(mypos).add(localmp);

            // calculate the path, with consideration of the moving object on
            // the map
            List<MapCoordinate> path = _pf.getPathToNearestGoal(request.getMap(), localmp, localwp);

            // get the next step
            if (path != null && path.size() > 0)
            {

                MapCoordinate nextField = path.get(0);
                if (nextField.equals(localmp) && path.size() > 1)
                {
                    nextField = path.get(1);
                }
                // calculate the coordinate in reference of the local position
                nextField = nextField.subtract(localmp);
                action.setMove(nextField);
            }
        }
    }

    /**
     * Method to calculate the next move for a guard trying to stay at a fix
     * point relative to the fields he guards
     * 
     * @param request
     *            the request message
     * @return the position the agent should move towards
     */
    private MapCoordinate calculateFixedGuardMove(MasMessageRequestAction request)
    {
        MapCoordinate guardcoord = null;
        Direction guarddir = getOppositeWeightedDir();

        switch (guarddir)
        {
            case NORTH:
            {
                guardcoord = new MapCoordinate(xmid, ytop - 2);
                break;
            }
            case NORTHEAST:
            {
                guardcoord = new MapCoordinate(xrgt + 2, ytop - 2);
                break;
            }
            case EAST:
            {
                guardcoord = new MapCoordinate(xrgt + 2, ymid);
                break;
            }
            case SOUTHEAST:
            {
                guardcoord = new MapCoordinate(xrgt + 2, ybtm + 2);
                break;
            }
            case SOUTH:
            {
                guardcoord = new MapCoordinate(xmid, ybtm + 2);
                break;
            }
            case SOUTHWEST:
            {
                guardcoord = new MapCoordinate(xlft - 2, ybtm + 2);
                break;
            }
            case WEST:
            {
                guardcoord = new MapCoordinate(xlft - 2, ymid);
                break;
            }
            case NORTHWEST:
            {
                guardcoord = new MapCoordinate(xlft - 2, ytop - 2);
                break;
            }
            case NONE:
            {
                guardcoord = new MapCoordinate(xlft, ytop);
                break;
            }
        }
        return guardcoord;
    }

    /**
     * Method to calculate the next move for a guard which is free in his
     * movement.
     * 
     * @param request
     *            the request message
     * @return the position the agent should move towards
     */
    private MapCoordinate calculateFreeGuardMove(MasMessageRequestAction request)
    {
        MapCoordinate guardcoord = null;

        // TODO: weight the fields according to cows moving toward them,
        // then move to defend the most weighted field

        return guardcoord;
    }

    /**
     * Method to calculate the next move for a guard which should stay out of
     * the way. Moves the guard a bit away from the fields to guard. This can be
     * used if a line of cows is incoming, as an example when a keeper should
     * suspend it's keeping for incoming new cows
     * 
     * @param request
     *            the request message
     * @return the position the agent should move towards
     */
    private MapCoordinate calculateOutOfWayMove(MasMessageRequestAction request)
    {
        MapCoordinate guardcoord = null;
        Direction guarddir = getOppositeWeightedDir();

        switch (guarddir)
        {
            case NORTH:
            {
                guardcoord = new MapCoordinate(xlft - 2, ytop - 2);
                break;
            }
            case NORTHEAST:
            {
                guardcoord = new MapCoordinate(xlft - 2, ytop);
                break;
            }
            case EAST:
            {
                guardcoord = new MapCoordinate(xrgt + 2, ytop - 2);
                break;
            }
            case SOUTHEAST:
            {
                guardcoord = new MapCoordinate(xlft - 2, ybtm);
                break;
            }
            case SOUTH:
            {
                guardcoord = new MapCoordinate(xlft - 1, ybtm + 2);
                break;
            }
            case SOUTHWEST:
            {
                guardcoord = new MapCoordinate(xrgt + 2, ybtm);
                break;
            }
            case WEST:
            {
                guardcoord = new MapCoordinate(xlft - 2, ytop - 2);
                break;
            }
            case NORTHWEST:
            {
                guardcoord = new MapCoordinate(xlft - 2, ytop);
                break;
            }
            case NONE:
            {
                guardcoord = new MapCoordinate(xlft, ytop);
                break;
            }
        }
        return guardcoord;
    }

    /**
     * Helper method to calculate a middle position to oppose the cows coming
     * from the direction specified for each field.
     * 
     * @return direction a guard should stand to stand in the weighted middle
     *         against the incoming cows
     */
    private Direction getOppositeWeightedDir()
    {
        int x = 0;
        int y = 0;
        Direction guarddir = Direction.NONE;

        // Calculate mean direction in which we have to guard
        for (Direction dir : _guardFields.values())
        {
            switch (dir)
            {
                case EAST:
                {
                    x--;
                    break;
                }
                case NORTH:
                {
                    y--;
                    break;
                }
                case NORTHEAST:
                {
                    x--;
                    y--;
                    break;
                }
                case NORTHWEST:
                {
                    x++;
                    y--;
                    break;
                }
                case SOUTH:
                {
                    y++;
                    break;
                }
                case SOUTHEAST:
                {
                    x--;
                    y++;
                    break;
                }
                case SOUTHWEST:
                {
                    x++;
                    y++;
                    break;
                }
                case WEST:
                {
                    x++;
                    break;
                }
                case NONE:
                {
                    break;
                }
            }
        }

        // Cows from West, Northwest or Southwest
        if (x > 0)
        {
            if (y > 0) // Southwest
                guarddir = Direction.NORTHEAST;
            else if (y < 0) // Northwest
                guarddir = Direction.SOUTHEAST;
            else
                // West
                guarddir = Direction.EAST;
        }
        // Cows from East, Northeast or Southeast
        else if (x < 0)
        {
            if (y > 0) // Southeast
                guarddir = Direction.NORTHWEST;
            else if (y < 0) // Northeast
                guarddir = Direction.SOUTHWEST;
            else
                // East
                guarddir = Direction.WEST;
        }
        // Cows from North or South
        else
        {
            if (y > 0) // South
                guarddir = Direction.NORTH;
            else if (y < 0) // North
                guarddir = Direction.SOUTH;
            else
                // Middle ... well ...
                guarddir = Direction.NONE;
        }

        return guarddir;
    }

    /**
     * Helper method to update ymid mean y coordinate xmid mean x coordinate
     * ytop topmost coordinate ybtm bottommost coordinate xlft leftmost
     * coordinate xrgt rightmost coordinate
     */
    private void updatePositions()
    {
        int minx = -1;
        int maxx = -1;
        int miny = -1;
        int maxy = -1;

        for (MapCoordinate coor : _guardFields.keySet())
        {
            int curx = coor.getX();
            int cury = coor.getY();

            if (curx < minx || minx < 0)
            {
                minx = curx;
            }

            if (cury < miny || miny < 0)
            {
                miny = cury;
            }

            if (curx > maxx || maxx < 0)
            {
                maxx = curx;
            }

            if (cury > maxy || maxy < 0)
            {
                maxy = cury;
            }
        }

        ymid = (miny + maxy) / 2;
        xmid = (minx + maxx) / 2;
        ytop = miny;
        ybtm = maxy;
        xlft = minx;
        xrgt = maxx;
    }

    /**
     * Helper method which receives cow guard action messages to update the
     * desired behavior of this agent
     */
    private void updateBehavior()
    {
        ComMessage cm = _parent.receiveComMessage("cowguardbehaviormessage");
        ComMessage lastcm = null;
        while (cm != null)
        {
            lastcm = cm;
            cm = _parent.receiveComMessage("cowguardbehaviormessage");
        }

        if (lastcm != null)
        {
            CowGuardBehaviorMessage cgam = new CowGuardBehaviorMessage(lastcm);
            _behavior = cgam.getBehavior();
        }
    }

    /**
     * Helper method which receives cow guard field messages to update the
     * fields this agent should guard.
     */
    private void updateFields()
    {
        ComMessage cm = _parent.receiveComMessage("cowguardlinemessage");
        ComMessage lastcm = null;
        while (cm != null)
        {
            lastcm = cm;
            cm = _parent.receiveComMessage("cowguardfieldmessage");
        }

        if (lastcm != null)
        {
            CowGuardFieldMessage cgfm = new CowGuardFieldMessage(lastcm);
            _guardFields.clear();
            _guardFields.putAll(cgfm.getCoordinates());
        }

        updatePositions();
    }

    @Override
    public void setRoleMessage(RoleMessage rm)
    {
        _message = new CowGuardRoleMessage(rm);
        _guardFields.putAll(_message.getCoordinatess());
        _behavior = _message.getBehavior();
        updatePositions();
    }

    /**
     * @return the _message
     */
    public CowGuardRoleMessage get_message()
    {
        return _message;
    }

}
