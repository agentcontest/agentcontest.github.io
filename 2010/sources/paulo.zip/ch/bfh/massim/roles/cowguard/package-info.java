/**
 * Contains the classes needed for the cowguard role. 
 * This role is not used yet. 
 */
package ch.bfh.massim.roles.cowguard;