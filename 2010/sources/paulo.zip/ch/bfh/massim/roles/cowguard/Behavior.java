package ch.bfh.massim.roles.cowguard;

/**
 * Enum representing possible behavior patterns for a CowGuard Agent. Possible
 * Actions are, with corresponding ordinal value: 0: UNKNOWN: unknown pattern.
 * Agent won't do anything 1: FREE_GUARD: agent is free in it's movement, but
 * has to guard the fields 2: FIXED_MID_GUARD: agent tries to stay relative to
 * the middle of the fields to guard 3: OUT_OF_WAY_GUARD: agent will stay out of
 * the way but still tries to keep cows behind the fields 4: OUT_OF_WAY_SUSPEND:
 * agent will stay out of the way and suspend it's actions 5: SUSPEND: agent
 * won't move
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public enum Behavior
{
    UNKNOWN, FREE_GUARD, FIXED_MID_GUARD, OUT_OF_WAY_GUARD, SUSPEND
}
