/**
 * 
 */
package ch.bfh.massim.roles.cowguard;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import ch.bfh.massim.framework.commessages.ComMessage;

/**
 * Class representing a cow guard action message. This message is used to tell a
 * guard which behavior pattern should be applied when calculating moves.
 * 
 * @see ch.bfh.massim.roles.cowguard.Behavior
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class CowGuardBehaviorMessage extends ComMessage
{

    /**
     * Default constructor
     * 
     * @param sender
     *            original sender of the message
     * @param behavior
     *            action defined in Action enum
     */
    public CowGuardBehaviorMessage(String sender, Behavior behavior)
    {
        super(sender, "cowguardbehaviormessage");

        Element messagebody = this.get_bodyElement();

        Element eldir = messagebody.getOwnerDocument().createElement("behavior");
        eldir.setAttribute("b", behavior.toString());
        messagebody.appendChild(eldir);
    }

    /**
     * Cast Constructor
     * 
     * @param message
     *            ComMessage which is a CowGuardActionMessage
     */
    public CowGuardBehaviorMessage(ComMessage message)
    {
        super(message.get_message());
    }

    /**
     * Method to get the action out of the message
     * 
     * @return Behavior defined in Behavior enum
     */
    public Behavior getBehavior()
    {
        Element messagebody = this.get_bodyElement();

        Behavior action = Behavior.UNKNOWN;

        NodeList nl = messagebody.getChildNodes();

        for (int i = 0; i < nl.getLength(); i++)
        {
            Node n = nl.item(i);
            if (n.getNodeType() == Element.ELEMENT_NODE && n.getNodeName().equalsIgnoreCase("action"))
            {
                Element act = (Element) n;
                action = Behavior.valueOf(act.getAttribute("b"));
            }
        }
        return action;
    }
}
