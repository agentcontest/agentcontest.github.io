package ch.bfh.massim.roles.followwaypoints;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import ch.bfh.massim.framework.commessages.ComMessage;
import ch.bfh.massim.framework.rolebasedagent.RoleMessage;

/**
 * This role is used by the PlaningUnit, to give the assistant role to an agent.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class FollowWPAssistantRoleMessage extends RoleMessage
{

    /**
     * Creates the message
     * 
     * @param sendername
     *            name of the sender
     * @param receiver
     *            name of the receiver
     */
    public FollowWPAssistantRoleMessage(String sendername, String receiver)
    {
        super("followWPAssistant", sendername, receiver);
    }

    /**
     * Creates the message
     * 
     * @param sendername
     *            name of the sender
     */
    public FollowWPAssistantRoleMessage(String sendername)
    {
        super("followWPAssistant", sendername);
    }

    /**
     * Transformation constructor
     * 
     * @param message
     *            the message
     */
    public FollowWPAssistantRoleMessage(ComMessage message)
    {
        super(message);
    }

    /**
     * adds the corresponding leader name
     * 
     * @param leader
     *            leader name
     */
    public void addLeader(String leader)
    {
        Element el_assistant = _el_role.getOwnerDocument().createElement("leader");
        el_assistant.setAttribute("name", leader);
        _el_role.appendChild(el_assistant);
    }

    /**
     * Gets the leader name.
     * 
     * @return the leader name
     */
    public String getLeader()
    {
        String leadername = "";
        NodeList nl = _el_role.getChildNodes();
        for (int i = 0; i < nl.getLength(); i++)
        {
            Node n = nl.item(i);
            if (n.getNodeType() == Element.ELEMENT_NODE && n.getNodeName().equalsIgnoreCase("leader"))
            {
                Element leader = (Element) n;
                leadername = leader.getAttribute("name");
                break;
            }
        }
        return leadername;
    }
}
