/**
 * 
 */
package ch.bfh.massim.roles.followwaypoints;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import ch.bfh.massim.framework.IMapField;
import ch.bfh.massim.framework.MapCoordinate;
import ch.bfh.massim.framework.commessages.ComMessage;
import ch.bfh.massim.framework.commessages.ComMessageMapTargetPositionsReply;
import ch.bfh.massim.framework.commessages.ComMessageMapTargetPositionsRequest;
import ch.bfh.massim.framework.masmessages.MasMessageAction;
import ch.bfh.massim.framework.masmessages.MasMessageRequestAction;
import ch.bfh.massim.framework.pathfinder.PathFinder;
import ch.bfh.massim.framework.rolebasedagent.BaseRole;
import ch.bfh.massim.framework.rolebasedagent.RoleMessage;

/**
 * The agent with this role leades a group of agents on a path with waypoints.
 * He uses the MapAgent for the fencehandling.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class FollowWPLeaderRole extends BaseRole
{

    /**
     * Position of the fence
     * 
     * @author Christian Loosli & Adrian Pauli
     * 
     */
    enum fencePos
    {
        before, behind, fencestart
    }

    private FollowWPLeaderRoleMessage _message;
    private List<MapCoordinate> _waypoints;
    private Map<String, MapCoordinate> _assistantsPos = new HashMap<String, MapCoordinate>();
    private Map<String, MapCoordinate> _assistantsLocal = new HashMap<String, MapCoordinate>();
    private PathFinder _pf;

    /**
     * Default constructor
     */
    public FollowWPLeaderRole()
    {
        super("followWPLeader");
        _pf = new PathFinder();
        _pf.setIgnoreagents(false);
        _pf.setIgnorecows(false);
    }

  /**
   * Method to act on a request message
   * @param request the request message
   * @param action the action message to reply with
   */
    @Override
    public void processRequestAction(MasMessageRequestAction request, MasMessageAction action)
    {
        // set defaultmove
        action.setMove(-1);

        try
        {

            // long starttime = System.currentTimeMillis();

            // calculate some usings
            MapCoordinate leaderPos = request.getAgentPos();
            MapCoordinate localmp = new MapCoordinate(8, 8);
            MapCoordinate localCorrection = leaderPos.subtract(localmp);
            IMapField[][] map = request.getMap();

            // update the agent position (local and global);
            updateAgentPositions(request.getAgentPos(), localCorrection);

            // get the waypoint (waypoint is reached, when all agents are in a
            // radius of 7 and one is closer then 2)
            MapCoordinate waypoint = getWaypoint(leaderPos, localCorrection);

            // get fenceinfo from the mapagent
            ComMessageMapTargetPositionsRequest targetRequest = new ComMessageMapTargetPositionsRequest(_parent
                    .getComName(), new ArrayList<String>(_assistantsPos.keySet()), waypoint);
            ComMessage cm = null;
            try
            {
                _parent.getConnection().sendMessage(targetRequest);
                cm = _parent.receiveComMessage("MapTargetPositionsReply");
                int i = 0;
                while (cm == null && i < 40)
                {
                    cm = _parent.receiveComMessage("MapTargetPositionsReply");
                    try
                    {
                        Thread.sleep(20);
                    }
                    catch (InterruptedException e)
                    {
                        e.printStackTrace();
                    }
                    i++;
                }
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }

            if (cm != null)
            {
                ComMessageMapTargetPositionsReply reply = new ComMessageMapTargetPositionsReply(cm);

                Map<String, MapCoordinate> agentTargetPositions = reply.getAgentsPos();
                List<MapCoordinate> ignoredList = reply.getIgnoreList();

                String out = "**Leader recieved: ";
                for (Entry<String, MapCoordinate> entry : agentTargetPositions.entrySet())
                {
                    out += entry.getKey() + entry.getValue() + " ";
                }
                //System.out.println(out);

                // send the position to the agents
                sendPositionsToAgents(agentTargetPositions, ignoredList);

                // do the move
                calculateLeaderMove(agentTargetPositions, localmp, waypoint, map, action, ignoredList, localCorrection);
            }

            // long endtime = System.currentTimeMillis();
            // System.err.println("time used for leader calc " + _parent.getComName() + ": " + (endtime - starttime));

        }
        catch (Exception e)
        {
            e.printStackTrace();
            System.out.println("agent " + _parent.getComName() + " is the braker");
        }
    }

    /**
     * Calculates the direction of the Leader
     * 
     * @param agentTargetPositions
     *            the target position of all agents
     * @param localLeaderPos
     *            the position of the leader
     * @param waypoint
     *            the waypoint we are heading to
     * @param map
     *            the map we are playing on
     * @param action
     *            the action reply message
     * @param ignoredList
     *            the list of coordinates to ignore
     * @param localCorrection
     *            the local correction
     */
    private void calculateLeaderMove(Map<String, MapCoordinate> agentTargetPositions, MapCoordinate localLeaderPos,
            MapCoordinate waypoint, IMapField[][] map, MasMessageAction action, List<MapCoordinate> ignoredList,
            MapCoordinate localCorrection)
    {
        for (Entry<String, MapCoordinate> element : agentTargetPositions.entrySet())
        {
            // System.err.println("test " + element.getKey() + " aginst: " + _parent.getComName());
            if (element.getKey().equalsIgnoreCase(_parent.getComName()))
            {

                //System.out.println("Leader will go to target " + element.getValue().subtract(localCorrection));
                //System.out.println("Leader has position " + localLeaderPos);

                if (localLeaderPos.equals(element.getValue()))
                {
                    // do no move
                    break;
                }

                List<MapCoordinate> globalIgnore = new ArrayList<MapCoordinate>();
                for (int i = 0; i < ignoredList.size(); i++)
                {
                    globalIgnore.add(ignoredList.get(i).subtract(localCorrection));

                }

                List<MapCoordinate> path = _pf.getPathToNearestGoal(map, localLeaderPos, element.getValue().subtract(
                        localCorrection), globalIgnore);

                if (path != null)
                {
                    MapCoordinate nextField = path.get(0);
                    if (nextField.equals(localLeaderPos) && path.size() > 1)
                    {
                        nextField = path.get(1);
                    }
                    nextField = nextField.subtract(localLeaderPos);
                    // System.err.println("Leader goes " + nextField + " with target " + element.getValue());
                    action.setMove(nextField);
                }
            }
        }
    }

    /**
     * Sends the targetposition to the assistants
     * 
     * @param agentTargetPositions
     *            the target of all agents
     * @param ignoredList
     *            the list of coordinates to ignore
     */
    private void sendPositionsToAgents(Map<String, MapCoordinate> agentTargetPositions, List<MapCoordinate> ignoredList)
    {

        for (Entry<String, MapCoordinate> element : agentTargetPositions.entrySet())
        {

            //System.out.println("targetcoord for " + element.getKey() + " " + element.getValue());

            if (!element.getKey().equalsIgnoreCase(_parent.getComName()))
            {
                NextPositionMessage posmessage = new NextPositionMessage(_parent.getComName(), element.getValue());

                posmessage.addIgnoredList(ignoredList);

                posmessage.addReceiverAgent(element.getKey());
                try
                {
                    _parent.getConnection().sendMessage(posmessage);
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }
            }
        }

    }

    /**
     * gets the new positions of the assistants
     * 
     * @param leaderPos
     *            position of the leader
     * @param localCorrection
     *            the local correction
     */
    private void updateAgentPositions(MapCoordinate leaderPos, MapCoordinate localCorrection)
    {
        // get assistants positions
        getAssistPositions();
        _assistantsPos.put(_parent.getComName(), leaderPos);

        for (Entry<String, MapCoordinate> element : _assistantsPos.entrySet())
        {
            _assistantsLocal.put(element.getKey(), element.getValue().subtract(localCorrection));
        }
    }

    /**
     * Calculate the next waypoint
     * 
     * @param leaderPos
     *            the position of the leader
     * @param localCorrection
     *            the local correction
     * @return the next Waypoint
     */
    private MapCoordinate getWaypoint(MapCoordinate leaderPos, MapCoordinate localCorrection)
    {
        MapCoordinate waypointGlobal = leaderPos;
        if (_waypoints.size() > 0)
        {
            waypointGlobal = _waypoints.get(0);

            boolean waypointReached = false;
            for (MapCoordinate coord : _assistantsPos.values())
            {
                if (coord.distance(waypointGlobal) > 6)
                {
                    waypointReached = false;
                    break;
                }
                else if (coord.distance(waypointGlobal) < 2)
                {
                    waypointReached = true;
                }
            }
            if (waypointReached)
            {
                if (_waypoints.size() > 1)
                {
                    _waypoints.remove(0);
                    waypointGlobal = _waypoints.get(0);
                }
            }
        }
        return waypointGlobal;// .subtract(localCorrection);
    }

    /**
     * @see ch.bfh.massim.framework.rolebasedagent.BaseRole#setRoleMessage(ch.bfh.massim.framework.rolebasedagent.RoleMessage)
     */
    @Override
    public void setRoleMessage(RoleMessage rm)
    {
        _message = new FollowWPLeaderRoleMessage(rm);
        _waypoints = _message.getWaypoints();
        // _assistants = _message.getAssistants();
        _assistantsPos.clear();
    }

    /**
     * Retrieves the position of the assistant agents
     */
    private void getAssistPositions()
    {
        ComMessage cm = _parent.receiveComMessage("nextpos");
        // ComMessage lastcm = null;
        while (cm != null)
        {
            NextPositionMessage npm = new NextPositionMessage(cm);
            String sender = npm.getSenderName();
            if (npm.getPos() != null)
            {
                _assistantsPos.put(sender, npm.getPos());
            }
            cm = _parent.receiveComMessage("nextpos");
        }
    }
}
