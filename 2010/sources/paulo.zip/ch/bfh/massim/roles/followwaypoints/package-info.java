/**
 * Contains the classes needed for the follow waypoint role. 
 * Contains the leader and assistant roles and the corresponding messages.  
 */
package ch.bfh.massim.roles.followwaypoints;