/**
 * 
 */
package ch.bfh.massim.roles.followwaypoints;

import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import ch.bfh.massim.framework.MapCoordinate;
import ch.bfh.massim.framework.commessages.ComMessage;

/**
 * This message is used to exchange the current position an the targets.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class NextPositionMessage extends ComMessage
{

    /**
     * Creates the message
     * 
     * @param sender
     *            the name of the sender
     * @param coord
     *            the coordinate
     */
    public NextPositionMessage(String sender, MapCoordinate coord)
    {
        super(sender, "nextpos");

        Element messagebody = this.get_bodyElement();

        Element el = messagebody.getOwnerDocument().createElement("coord");
        el.setAttribute("x", String.valueOf(coord.getX()));
        el.setAttribute("y", String.valueOf(coord.getY()));
        messagebody.appendChild(el);
    }

    /**
     * Transform Constructor
     * 
     * @param message
     *            the message to cast
     */
    public NextPositionMessage(ComMessage message)
    {
        super(message.get_message());
    }

    /**
     * 
     * @return the position in the message
     */
    public MapCoordinate getPos()
    {
        NodeList nl = get_bodyElement().getChildNodes();
        for (int i = 0; i < nl.getLength(); i++)
        {
            Node n = nl.item(i);
            if (n.getNodeType() == Element.ELEMENT_NODE && n.getNodeName().equalsIgnoreCase("coord"))
            {
                Element el = (Element) n;
                return new MapCoordinate(Integer.parseInt(el.getAttribute("x")), Integer.parseInt(el.getAttribute("y")));
            }
        }
        return null;
    }

    /**
     * Adds a list of coordinates to the message. This coordinates should be
     * ignored by the pathfinding.
     * 
     * @param ignoredList
     *            a list of coordinates which should be ignored
     */
    public void addIgnoredList(List<MapCoordinate> ignoredList)
    {
        Element el_list = this.get_bodyElement().getOwnerDocument().createElement("ignore");
        for (MapCoordinate coordinate : ignoredList)
        {
            Element el_coord = el_list.getOwnerDocument().createElement("coord");
            el_coord.setAttribute("x", String.valueOf(coordinate.getX()));
            el_coord.setAttribute("y", String.valueOf(coordinate.getY()));
            el_list.appendChild(el_coord);
        }
        this.get_bodyElement().appendChild(el_list);
    }

    /**
     * gets a list of coordinates to the message. This coordinates should be
     * ignored by the pathfinding.
     * 
     * @return the ignore-list
     */
    public List<MapCoordinate> getIgnoredList()
    {
        List<MapCoordinate> list = new ArrayList<MapCoordinate>();
        NodeList nl = get_bodyElement().getChildNodes();
        for (int i = 0; i < nl.getLength(); i++)
        {
            Node n = nl.item(i);
            if (n.getNodeType() == Element.ELEMENT_NODE && n.getNodeName().equalsIgnoreCase("ignore"))
            {
                NodeList nl2 = n.getChildNodes();
                for (int j = 0; j < nl2.getLength(); j++)
                {
                    Node n2 = nl2.item(j);
                    if (n2.getNodeType() == Element.ELEMENT_NODE && n2.getNodeName().equalsIgnoreCase("coord"))
                    {

                        Element el = (Element) n2;
                        list.add(new MapCoordinate(Integer.parseInt(el.getAttribute("x")), Integer.parseInt(el
                                .getAttribute("y"))));
                    }
                }
                break;
            }
        }
        return list;
    }
}
