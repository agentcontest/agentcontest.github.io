package ch.bfh.massim.roles.followwaypoints;

import java.util.ArrayList;
import java.util.List;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import ch.bfh.massim.framework.MapCoordinate;
import ch.bfh.massim.framework.commessages.ComMessage;
import ch.bfh.massim.framework.rolebasedagent.RoleMessage;

/**
 * This role is used by the PlaningUnit, to give the leader role to an agent.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class FollowWPLeaderRoleMessage extends RoleMessage
{

    /**
     * Creates the message
     * 
     * @param sendername
     *            name of the sender
     * @param receiver
     *            name of the receiver
     */
    public FollowWPLeaderRoleMessage(String sendername, String receiver)
    {
        super("followWPLeader", sendername, receiver);
    }

    /**
     * Adds the Waypointlist to the message.
     * 
     * @param coordinates
     *            list with the waypoints as MapCoordinates
     */
    public void addWpList(List<MapCoordinate> coordinates)
    {
        for (MapCoordinate coordinate : coordinates)
        {
            Element el_coord = _el_role.getOwnerDocument().createElement("coord");
            el_coord.setAttribute("x", String.valueOf(coordinate.getX()));
            el_coord.setAttribute("y", String.valueOf(coordinate.getY()));
            _el_role.appendChild(el_coord);
        }
    }

    /**
     * Adds the agents to the message
     * 
     * @param assistants
     *            list with the name of the assistants
     */
    public void addAssistants(List<String> assistants)
    {
        for (String string : assistants)
        {
            Element el_assistant = _el_role.getOwnerDocument().createElement("assist");
            el_assistant.setAttribute("name", string);
            _el_role.appendChild(el_assistant);
        }
    }

    /**
     * 
     * @return list with the name of the assistants
     */
    public List<String> getAssistants()
    {
        List<String> assistants = new ArrayList<String>();
        NodeList nl = _el_role.getChildNodes();
        for (int i = 0; i < nl.getLength(); i++)
        {
            Node n = nl.item(i);
            if (n.getNodeType() == Element.ELEMENT_NODE && n.getNodeName().equalsIgnoreCase("assist"))
            {
                Element assist = (Element) n;
                assistants.add(assist.getAttribute("name"));
            }
        }
        return assistants;
    }

    /**
     * 
     * @return list with the waypoints as MapCoordinates
     */
    public List<MapCoordinate> getWaypoints()
    {
        List<MapCoordinate> coords = new ArrayList<MapCoordinate>();
        NodeList nl = _el_role.getChildNodes();
        for (int i = 0; i < nl.getLength(); i++)
        {
            Node n = nl.item(i);
            if (n.getNodeType() == Element.ELEMENT_NODE && n.getNodeName().equalsIgnoreCase("coord"))
            {
                Element coord = (Element) n;
                coords.add(new MapCoordinate(Integer.parseInt(coord.getAttribute("x")), Integer.parseInt(coord
                        .getAttribute("y"))));
            }
        }
        return coords;
    }

    /**
     * Transformation Constructor
     * 
     * @param message
     *            the message to cast
     */
    public FollowWPLeaderRoleMessage(ComMessage message)
    {
        super(message);
    }

}
