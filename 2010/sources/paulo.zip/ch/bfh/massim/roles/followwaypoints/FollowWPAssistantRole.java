package ch.bfh.massim.roles.followwaypoints;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import ch.bfh.massim.framework.MapCoordinate;
import ch.bfh.massim.framework.commessages.ComMessage;
import ch.bfh.massim.framework.masmessages.MasMessageAction;
import ch.bfh.massim.framework.masmessages.MasMessageRequestAction;
import ch.bfh.massim.framework.pathfinder.PathFinder;
import ch.bfh.massim.framework.rolebasedagent.BaseRole;
import ch.bfh.massim.framework.rolebasedagent.RoleMessage;

/**
 * The agent with this role listen to the FollowWPLeaderRole for all information
 * about the movement. A group of agents following waypoints has only one
 * leader.
 * 
 * @author Christian Loosli & Adrian Pauli
 * 
 */
public class FollowWPAssistantRole extends BaseRole
{

    private FollowWPAssistantRoleMessage _message;
    private String _leader = "";
    private PathFinder _pf;
    private MapCoordinate _target;
    private List<MapCoordinate> _ignoreList = new ArrayList<MapCoordinate>();

    public FollowWPAssistantRole()
    {
        super("followWPAssistant");
        _pf = new PathFinder();
        _pf.setIgnoreagents(false);
        _pf.setIgnorecows(false);
        _pf.setIgnoreclosedfence(false);
    }

    /**
     * @see ch.bfh.massim.framework.rolebasedagent.BaseRole#processRequestAction(ch.bfh.massim.framework.masmessages.MasMessageRequestAction,
     *      ch.bfh.massim.framework.masmessages.MasMessageAction)
     */
    @Override
    public void processRequestAction(MasMessageRequestAction request, MasMessageAction action)
    {
        try
        {
            Thread.sleep(800);
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }

        // check for a new target
        updateTarget();

        // set defaultmove
        action.setMove(-1);

        // read the position of the agent
        MapCoordinate mypos = request.getAgentPos();
        // MapCoordinate leaderupdate = mypos;

        if (_target != null && !_target.equals(mypos))
        {

            // calculate the local coordinate on the array
            MapCoordinate localmp = new MapCoordinate(8, 8);
            MapCoordinate localwp = _target.subtract(mypos).add(localmp);

            List<MapCoordinate> localIgnoreList = new ArrayList<MapCoordinate>();
            for (int i = 0; i < _ignoreList.size(); i++)
            {
                localIgnoreList.add(_ignoreList.get(i).subtract(mypos).add(localmp));
            }

            //System.out.println("FOLLOW WP ASSISTANT: " + localmp + " wp: " + localwp + " ");

            // calculate the path, with consideration of the moving object on
            // the map
            List<MapCoordinate> path = _pf.getPathToNearestGoal(request.getMap(), localmp, localwp, localIgnoreList);

            //System.out.println("FOLLOW WP ASSISTANT: path calculated ");

            // get the next step
            if (path != null && path.size() > 0)
            {

                String spath = "Local Path: " + path.size();
                for (MapCoordinate mapCoordinate : path)
                {
                    spath += mapCoordinate;
                }
                //System.out.println(spath);

                MapCoordinate nextField = path.get(0);
                if (nextField.equals(localmp) && path.size() > 1)
                {
                    nextField = path.get(1);
                }
                // calculate the coordinate in reference of the local position
                nextField = nextField.subtract(localmp);
                action.setMove(nextField);
                // leaderupdate = mypos.add(nextField);
            }
        }
        // sendPosToLeader(leaderupdate);
        sendPosToLeader(mypos);
    }

    /**
     * receives the target from the leader
     */
    private void updateTarget()
    {
        ComMessage cm = _parent.receiveComMessage("nextpos");
        ComMessage lastcm = null;
        while (cm != null)
        {
            lastcm = cm;
            cm = _parent.receiveComMessage("nextpos");
        }

        if (lastcm != null)
        {
            NextPositionMessage npm = new NextPositionMessage(lastcm);
            _target = npm.getPos();
            _ignoreList = npm.getIgnoredList();
        }
    }

    /**
     * Send the new position to the leader
     * 
     * @param coord
     *            position of the assistant
     */
    private void sendPosToLeader(MapCoordinate coord)
    {
        NextPositionMessage posmessage = new NextPositionMessage(_parent.getComName(), coord);
        // System.err.println("sendmessage to leader " + _parent.getComName() + " " + coord);
        posmessage.addReceiverAgent(_leader);
        try
        {
            _parent.getConnection().sendMessage(posmessage);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * @see ch.bfh.massim.framework.rolebasedagent.BaseRole#setRoleMessage(ch.bfh.massim.framework.rolebasedagent.RoleMessage)
     */
    @Override
    public void setRoleMessage(RoleMessage rm)
    {
        _message = new FollowWPAssistantRoleMessage(rm);
        _leader = _message.getLeader();
    }

}
