import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Monitor extends JFrame {
	static Monitor f;

	public static void main(String[] args) throws Exception {
		EventQueue.invokeAndWait(new Runnable() {
			public void run() {
				f = new Monitor();
				f.setVisible(true);
			}
		});

		while (true) {
			f.repaint();

			Thread.sleep(250);
		}
	}

	public Monitor() {
		setSize(600, 600);
		setLayout(new BorderLayout());
		add(new Panel(), BorderLayout.CENTER);
	}
}

class Panel extends JPanel {
	Graphics buffer;
	Image offscreen;
	Dimension dim;

	public Panel() {
		dim = new Dimension(600, 600);
		offscreen = new BufferedImage(dim.width, dim.height,
				BufferedImage.TYPE_INT_RGB);
		buffer = offscreen.getGraphics();
	}

	public void paint(Graphics g) {
		BufferedImage img;
		try {
			img = ImageIO.read(new File("heatmap.png"));
			buffer.drawImage(img, 0, 0, 600, 600, null);
			g.drawImage(offscreen, 0, 0, this);
		} catch (Exception e) {
		}

	}

	@Override
	public void update(Graphics g) {
		paint(g);
	}

	// @Override
	// public void paintComponent(Graphics g) {
	// try {
	// BufferedImage img = ImageIO.read(new File("heatmap.png"));
	// g.drawImage(img, 0, 0, 600, 600, null);
	// } catch (Exception e) {
	// }
	//
	// }
}
