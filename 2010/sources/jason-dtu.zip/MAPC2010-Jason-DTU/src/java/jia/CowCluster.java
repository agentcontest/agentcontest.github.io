package jia;

import java.util.ArrayList;

public class CowCluster {
	ArrayList<Vec> cows = new ArrayList<Vec>();
	ArrayList<Target> targets = new ArrayList<Target>();
	Vec stdDev;
	public int x, y, size;
	public int pathLength;
	
	public CowCluster() {
		size = 0;
	}
	
	public void addCow(int x, int y) {
		cows.add(new Vec(x, y));
		size++;
	}
	
	public void calcMeanAndStdDev() {
		Vec mean = Vec.mean(cows);
		this.x = (int) mean.x;
		this.y = (int) mean.y;
		
		stdDev = Vec.stddev(cows, mean);
	}
	
	public CowCluster clone(){
		CowCluster clone = new CowCluster();
		
		for(Vec v : cows){
			clone.addCow(v.getX(), v.getY());
		}
		
		clone.calcMeanAndStdDev();
		return clone;
	}
	
}