﻿Multi-Agent Programming Contest 2010 - Jason-DTU

Participants from DTU Informatics:

- Jørgen Villadsen - Supervisor - Associate professor

- Niklas Skamriis Boss

- Andreas Schmidt Jensen

- Steen Vester 

- Mikko Berggren Ettienne

Department of Informatics and Mathematical Modelling
Technical University of Denmark (DTU)

http://www.imm.dtu.dk/~jv/MAS

----------

MAPC.mas2j - project file

mapc.properties - properties file for our algorithms

src/ - source code
