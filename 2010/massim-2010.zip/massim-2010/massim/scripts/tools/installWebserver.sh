#!/bin/bash -x
# disable selinux
system-config-securitylevel-tui --disabled -q

# set mail alias
echo "root:	mko@tu-clausthal.de" >> /etc/aliases
newaliases

# install packages
yum install httpd httpd-devel screen java-1.6.0-openjdk php subversion java-1.6.0-openjdk-devel

# install maven
cd /usr/local/
wget ftp://ftp.uni-erlangen.de/pub/mirrors/apache/maven/binaries/apache-maven-2.2.1-bin.tar.bz2
tar xvfj apache-maven-2.2.1-bin.tar.bz2 
ln -s apache-maven-2.2.1 maven
echo "export M2_HOME=/usr/local/maven" >> /root/.bashrc
echo "export PATH=\${M2_HOME}/bin:\${PATH}" >> /root/.bashrc
source /root/.bashrc

# install tomcat and tomcat connector
cd /usr/local/
wget http://ftp-stud.hs-esslingen.de/pub/Mirrors/ftp.apache.org/dist/tomcat/tomcat-6/v6.0.29/bin/apache-tomcat-6.0.29.tar.gz
tar xvfz apache-tomcat*.tar.gz
ln -s /usr/local/apache-tomcat-6.0.29 tomcat

wget http://www.apache.org/dist/tomcat/tomcat-connectors/jk/source/jk-1.2.30/tomcat-connectors-1.2.30-src.tar.gz
tar xvfz tomcat-connectors-1.2.30-src.tar.gz
cd tomcat-connectors-1.2.30-src/native
./configure --with-apxs=/usr/sbin/apxs
make
make install

# checkout massim
mkdir -p /home/massim/
cd /home/massim/
svn co svn://vz103.in.tu-clausthal.de/massim

# configure tomcat
hostname=$( dnsdomainname -f )
cp -r /home/massim/massim/trunk/webapp/webserver/jk /usr/local/tomcat/conf/
sed -i.bak 's#<Server port="8005" shutdown="SHUTDOWN">#<Server port="8005" shutdown="SHUTDOWN">\n  <Listener className="org.apache.jk.config.ApacheConfig" modJk="/etc/httpd/modules/mod_jk.so" workersConfig="/usr/local/tomcat/conf/jk/workers.properties" />#g' /usr/local/tomcat/conf/server.xml
sed -i "s#</Engine>#<Host name=\"$hostname\" appBase=\"/home/massim/www/webapps\" unpackWARs=\"true\" autoDeploy=\"true\" xmlValidation=\"false\" xmlNamespaceAware=\"false\">\n<Context path=\"/massim\" docBase=\"massim\" debug=\"0\" reloadable=\"true\"/>\n<Listener className=\"org.apache.jk.config.ApacheConfig\" append=\"true\" forwardAll=\"false\" modJk=\"/etc/httpd/modules/mod_jk.so\" />\n</Host>\n</Engine>#g" /usr/local/tomcat/conf/server.xml

# configure apache
sed -i.bak '0,/AllowOverride None/s//AllowOverride All/' /etc/httpd/conf/httpd.conf
echo "Include /usr/local/tomcat/conf/auto/mod_jk.conf" >> /etc/httpd/conf/httpd.conf

# install massim to maven repository
cd /home/massim/massim/trunk/massim/
mvn install

# install webapp
mkdir -p /home/massim/www/webapps/
cd /home/massim/massim/trunk/webapp/
mvn package
cp /home/massim/massim/trunk/webapp/target/massim.war /home/massim/www/webapps/

# start tomcat
/usr/local/tomcat/bin/startup.sh
sleep 10

# (re-)start apache
mkdir -p /home/massim/htpasswd
cp /home/massim/massim/trunk/webapp/webserver/htpasswd/.htusers /home/massim/htpasswd/
/etc/init.d/httpd restart

# start massim server
cd /home/massim/massim/trunk/massim/scripts/
screen ./startServer.sh
