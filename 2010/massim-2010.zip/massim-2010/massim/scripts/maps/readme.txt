circlesTwo:
- easy skill
- corrals quite close, thus a very high competing factor
- not that many cows, thus stealing might happen
- topology very simple and almost no fences

spiralsTwo:
- medium skill
- challenge: cows have to be pushed down a curvy road
- very high probalility that the teams meet and compete

prarieTwo
- hard skill
- major part of the map is instantly known at the beginning, thus exploration is not that demanding
- quite a lot of fences, thus a challenge for any fences-algorith,
- not that many cows
- the agents are very scattered, thus a challenge for coordination/cooperation
