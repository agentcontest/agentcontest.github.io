# MASSim 2010

This is a repackaged version of the 2010 MASSim version featuring the Cow & Cowboys scenario.

The versions of 

* MASSim
* EISMASSim
* Javaagents, and
* the Webapp

have been taken from the end of 2010; so potential bugfixes etc. should be already included.

## Running

To run the server, navigate to ``massim/scripts`` and execute one of the scripts as needed.
