package massim.javaagents;

/**
 * An agent-specification consists of an agent-name, 
 * a name of an entity, and a class-name.
 * 
 * @author tristanbehrens
 *
 */
public class AgentSpec {
	
	public String name;
	public String entity;
	public String team;
	public String className;
	
}