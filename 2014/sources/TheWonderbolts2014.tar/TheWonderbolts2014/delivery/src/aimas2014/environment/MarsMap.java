package aimas2014.environment;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.javatuples.Pair;

import aimas2014.planning.GlobalBeliefs;
import aimas2014.search.BestFirstSearch;
import aimas2014.search.GoalConditionType;
import aimas2014.search.MarsNodePredicate;
import aimas2014.search.MarsSearchNode;
import aimas2014.search.SearchNodeType;
import aimas2014.search.actions.ActionType;
import aimas2014.search.actions.GotoAction;
import aimas2014.search.actions.RechargeAction;

public class MarsMap {
	
	public final Map<String, MarsNode> nodes = new HashMap<>();
	public final Set<MarsNode> exploredNodes = new HashSet<>();
	public final Set<MarsNode> unexploredNodes = new HashSet<>();

	public final Map<MarsNodePair, MarsNodePath> nodeToNodePaths = new HashMap<>();
	
	public final static int UNKNOWN_DISTANCE = Integer.MAX_VALUE;

	public synchronized MarsNode getNode(String name) {
		MarsNode node = nodes.get(name);

		if (null == node) {
			node = new MarsNode(name);

			nodes.put(name, node);
			calculateNodeCentralities(3);

			nodeToNodePaths.clear();
		}

		return node;
	}

	public int distance(MarsNode a, MarsNode b) {
		MarsNodePair p = new MarsNodePair(a, b);

		if (!nodeToNodePaths.containsKey(p)) {
			BestFirstSearch.Solution sol = BestFirstSearch.lowestEnergyPath(a, b);

			if (sol.sound()) {
				MarsSearchNode n = ((MarsSearchNode) sol.terminalNode);
				
				MarsNodePath nodePath = new MarsNodePath();
				nodePath.energy = n.totalEnergySpent;
				
				nodePath.searchPath.add(n);
				
				while (null != n.parentNode) {
					n = (MarsSearchNode) n.parentNode;
					
					nodePath.searchPath.add(n);
				}
				
				nodeToNodePaths.put(p, nodePath);
			} else {
				return UNKNOWN_DISTANCE;
			}
		}
		
		return nodeToNodePaths.get(p).energy;
	}
	
	public MarsNodePath path(MarsNode a, MarsNode b) {
		MarsNodePair p = new MarsNodePair(a, b);
		distance(a, b);
		
		return nodeToNodePaths.get(p);
	}
	
	public BestFirstSearch.Solution nearestUnprobedNode(MarsNode fromNode, int currentEnergy, int maxEnergy, final Collection<MarsNode> takenNodes) {
		MarsSearchNode initial = new MarsSearchNode(fromNode, currentEnergy, maxEnergy);
        
        List<ActionType> actionLibrary = new ArrayList<>();
        
        actionLibrary.add(new GotoAction());
        actionLibrary.add(new RechargeAction());
        
		return BestFirstSearch.plan(initial, actionLibrary, new GoalConditionType() {
			
			@Override
			public boolean suceeded(SearchNodeType s) {
				if (s instanceof MarsSearchNode) {
					MarsSearchNode other = (MarsSearchNode) s;
				
					return !other.nodeProbed && !takenNodes.contains(other.node);
				}
				
				return false;
			}
		});
	}

	public void calculateNodeCentralities(int depth) {
		for (MarsNode n : nodes.values()) {
			n.centrality = n.weight + nodeCentrality(n.neighbours.keySet(), n, depth, 1);
		}
	}

	private int nodeCentrality(Collection<MarsNode> neighbours, MarsNode parent, int depth, int counter) {
		int centrality = 0;

		if (depth > 0) {
			for (MarsNode n : neighbours) {
				List<MarsNode> neighborsWithoutParent = new ArrayList<>(n.neighbours.keySet());

				neighborsWithoutParent.remove(parent);

				centrality += n.weight * 2 + nodeCentrality(neighborsWithoutParent, n, depth - 1, counter + 1)
						/ counter;
			}
		}

		return centrality;
	}
	
	public int countNodesIf(MarsNodePredicate predicate) {
		int result = 0;

		for (MarsNode node : nodes.values()) {
			if (predicate.test(node))
				result += 1;
		}

		return result;
	}
	
	public int numNodes() {
		return nodes.size();
	}
	
	public int numUnsurveyedNodes() {
		return countNodesIf(new MarsNodePredicate() {
			@Override
			public boolean test(MarsNode node) {
				return !node.allEdgesSurveyed();
			}
		});
	}
	
	public int numProbedNodes() {
		return countNodesIf(new MarsNodePredicate() {
			@Override
			public boolean test(MarsNode node) {
				return node.state.probed;
			}
		});
	}
	
	public void outputToDot(GlobalBeliefs globalBeliefs, Collection<Pair<String, Collection<MarsNode>>> coloredGroups) {
		String filename = String.format("marsmap_%s_step_%d", "global", globalBeliefs.agentStep);

		Map<MarsNode, String> colorings = new HashMap<>();
		
		for (Pair<String, Collection<MarsNode>> p: coloredGroups) {
			for (MarsNode m: p.getValue1()) {
				colorings.put(m, p.getValue0());
			}
		}
		
		for (MarsNode m: globalBeliefs.map.nodes.values()) {
			if (!colorings.keySet().contains(m))
				colorings.put(m, "white");
		}
		
		BufferedWriter out = null;
		try {
			FileWriter fstream = new FileWriter(String.format("dot/%s.dot", filename));
			out = new BufferedWriter(fstream);

			out.write("graph MarsMap {\n");
			
			for (MarsNode node : nodes.values()) {
				String label = String.format("%s (%d/%d)", node.name, node.weight, node.centrality);
				String shape = node.state.probed ? "diamond" : "ellipse";
				
				String fillcolor = colorings.get(node);
				
				out.write(String.format("%s [label=\"%s\" style=filled shape=%s fillcolor=%s]\n", node.name, label,
						shape, fillcolor));
			}
			
			Set<MarsNodePair> drawnEdges = new HashSet<>();

			for (MarsNode node : nodes.values()) {
				for (Entry<MarsNode, Integer> nb : node.neighbours.entrySet()) {
					
					String label = nb.getValue() == MarsNode.UNKNOWN_EDGE_WEIGHT ? "" : Integer.toString(nb.getValue());
					String color = "black"; 
					String style = nb.getValue() == MarsNode.UNKNOWN_EDGE_WEIGHT ? "dotted" : "solid";
					
					MarsNodePair p = new MarsNodePair(node,  nb.getKey());
					
					if (!drawnEdges.contains(p))
						out.write(String.format("%s -- %s [label=\"%s\" color=%s style=%s]\n",
								node.name, nb.getKey().name, label, color, style));
					
					drawnEdges.add(p);
				}
			}

			out.write("}\n");
			out.close();
			
			Runtime.getRuntime().exec(String.format("fdp -Tpng dot/%s.dot -o ps/%s.png", filename, filename));
		} catch (IOException e) {
			System.err.println("Error: " + e.getMessage());
			
			if (out != null) {
				try {
					out.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
	}
}
