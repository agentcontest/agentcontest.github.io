package aimas2014.environment;


import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import aimas2014.agents.PositionedEntity;

public class MarsNode implements PositionedEntity {
    public final String name;
    public int weight = 1;
    public Integer centrality = 0;
    
    public final static int UNKNOWN_EDGE_WEIGHT = Integer.MAX_VALUE;

    public class NodeState {
        public boolean probed = false;
    }

    public final Map<MarsNode, Integer> neighbours = new HashMap<>();
    public final NodeState state = new NodeState();

    public MarsNode(String name) {
        this.name = name;
    }

    public int numKnownEdges() {
    	int result = 0;
    	
    	for (Integer e: neighbours.values()) {
    		if (UNKNOWN_EDGE_WEIGHT == e)
    			result += 1;
    	}
    	
        return neighbours.size() - result;
    }

    public boolean allEdgesSurveyed() {
    	return numKnownEdges() == neighbours.size();
    }
    
    public void addEdge(MarsNode endpoint, int weight) {
        if (!neighbours.containsKey(endpoint)) {
            neighbours.put(endpoint, weight);
        }
    }

    public void setEdgeCost(MarsNode endpoint, int weight) {
        neighbours.put(endpoint, weight);
    }

    public Set<Entry<MarsNode, Integer>> getNeighbours() {
        return neighbours.entrySet();
    }
    
    public Map<MarsNode, Integer> getNeighboursAsMap() {
        return neighbours;
    }

    @Override
    public boolean equals(Object obj) {
        return obj instanceof MarsNode && ((MarsNode) obj).name.equals(name);
    }

    @Override
    public int hashCode() {
        return name.hashCode();
    }

    @Override
    public String toString() {
        return String.format("%s (probed=%b, weight=%d)", name, state.probed, weight);
    }
    
    public int calculateScore() {
    	int score = weight;
    	Set<MarsNode> counted = new HashSet<>();
    	counted.add(this);
    	for (MarsNode node1: neighbours.keySet()) {
			for (MarsNode node2 : node1.neighbours.keySet()) {
				if(!counted.contains(node2)){
					score += node2.weight;
					counted.add(node2);
				}
			}
			if(!counted.contains(node1)){
				score += node1.weight;
				counted.add(node1);
			}
		}
    	return score;
    }

	@Override
	public MarsNode getPosition() {
		return this;
	}

	@Override
	public String getEntityName() {
		return name;
	}
}
