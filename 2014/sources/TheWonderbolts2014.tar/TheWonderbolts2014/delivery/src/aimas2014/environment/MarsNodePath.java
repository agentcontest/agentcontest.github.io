package aimas2014.environment;

import java.util.ArrayList;
import java.util.List;

import aimas2014.search.MarsSearchNode;

public class MarsNodePath {
	public final List<MarsSearchNode> searchPath = new ArrayList<>();
	public int energy;
}