package aimas2014.environment;

public class MarsNodePair {
	public final MarsNode a, b;
	public final int score;

	public MarsNodePair(MarsNode a, MarsNode b) {
		super();
		this.a = a;
		this.b = b;
		this.score = 0;
	}

	public MarsNodePair(MarsNode a, MarsNode b, int score) {
		super();
		this.a = a;
		this.b = b;
		this.score = score;
	}
	
	@Override
	public int hashCode() {
		return new Integer(a.hashCode() + b.hashCode() + score).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj instanceof MarsNodePair) {
			final MarsNodePair other = (MarsNodePair) obj;
			
			return (a.equals(other.a) && b.equals(other.b) || a.equals(other.b) && b.equals(other.a)) && score == other.score;
		}

		return super.equals(obj);
	}
}