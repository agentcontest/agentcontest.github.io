package aimas2014.agents;

import aimas2014.agent.strategies.IdleStrategy;

public class AIMASIdiotAgent extends AIMASAgent {
	public AIMASIdiotAgent(String name,String team) {
		super(name,team);
		
		strategy = new IdleStrategy();
	}
}

