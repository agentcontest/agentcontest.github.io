package aimas2014.agents;

import aimas2014.agent.strategies.DefaultSentinelStrategy;
import aimas2014.planning.GlobalBeliefs;


public class AIMASSentinelAgent extends AIMASAgent {
	public AIMASSentinelAgent(String name,String team) {
		super(name,team);
	}
	
	@Override
	public void initialize(GlobalBeliefs globalBeliefs) {
		super.initialize(globalBeliefs);
		strategy = new DefaultSentinelStrategy();
	}
}

