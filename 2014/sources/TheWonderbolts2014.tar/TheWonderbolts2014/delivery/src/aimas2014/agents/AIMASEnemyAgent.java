package aimas2014.agents;

import aimas2014.environment.MarsNode;

public class AIMASEnemyAgent implements PositionedEntity {
	public final String name;
	public final String team;
	
	public String type = "Unknown";
	public String status = "normal";
	
	public int agentStepLastSeen = -1;
	public int agentStepInspected = -1;
	
	public MarsNode position = null;
	public int energy = -1;
    public int maxEnergy = -1;
    public int health = -1;
    public int maxHealth = -1;
    public int visRange = -1;
    public int strength = -1;
	
	public AIMASEnemyAgent(String name, String team, MarsNode position, String status) {
		this.name = name;
		this.team = team;
		
		this.position = position;
		this.status = status;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((team == null) ? 0 : team.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null)
			return false;

		if (!(obj instanceof AIMASEnemyAgent))
			return false;
		
		AIMASEnemyAgent other = (AIMASEnemyAgent) obj;
		
		return name.equals(other.name) && team.equals(other.team);
	}

	@Override
	public MarsNode getPosition() {
		return position;
	}
	
	public String getEntityName() {
		return name;
	}
}
