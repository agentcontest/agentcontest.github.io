package aimas2014.agents;

import aimas2014.environment.MarsNode;

public interface PositionedEntity {
	public abstract MarsNode getPosition();
	public abstract String getEntityName();
}
