package aimas2014.agents;

import aimas2014.search.actions.InspectAction;

public class AIMASInspectorAgent extends AIMASAgent {
    
    public AIMASInspectorAgent(String name, String team) {
        super(name, team);
        
        actionLibrary.add(new InspectAction());
    }
}
