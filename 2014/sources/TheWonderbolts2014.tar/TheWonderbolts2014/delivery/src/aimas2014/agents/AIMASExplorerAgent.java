package aimas2014.agents;

import aimas2014.search.actions.GotoAction;
import aimas2014.search.actions.ProbeAction;
import aimas2014.setup.Config;

public class AIMASExplorerAgent extends AIMASAgent {
    
    public AIMASExplorerAgent(String name, String team) {
        super(name, team);
        
        actionLibrary.add(new ProbeAction());
        
        int costUnsurveyedEdge = (int) Config.get("COST_UNSURVEYED_EDGE", 5.0);
        
        GotoAction m = new GotoAction(costUnsurveyedEdge);
        
        actionLibrary.remove(m);
        actionLibrary.add(m);
    }
    
}
