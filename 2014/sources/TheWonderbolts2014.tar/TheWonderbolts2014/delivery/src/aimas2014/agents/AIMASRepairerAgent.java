package aimas2014.agents;

import aimas2014.agent.strategies.DefaultRepairerStrategy;
import aimas2014.planning.GlobalBeliefs;
import aimas2014.search.actions.RepairAction;


public class AIMASRepairerAgent extends AIMASAgent {
	public AIMASRepairerAgent(String name,String team) {
		super(name,team);
	
		actionLibrary.add(new RepairAction());
		actionLibraryDisabled.add(new RepairAction());
	}
	
	@Override
	public void initialize(GlobalBeliefs globalBeliefs) {
		super.initialize(globalBeliefs);
		strategy = new DefaultRepairerStrategy();
	}
}

