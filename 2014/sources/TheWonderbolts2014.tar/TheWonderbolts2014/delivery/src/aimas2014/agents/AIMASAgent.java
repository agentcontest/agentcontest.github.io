package aimas2014.agents;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import massim.javaagents.Agent;
import massim.javaagents.agents.MarsUtil;
import aimas2014.agent.strategies.AgentStrategy;
import aimas2014.agent.strategies.DefaultStrategy;
import aimas2014.environment.MarsNode;
import aimas2014.goals.IdleGoal;
import aimas2014.goals.SurveyNodeGoal;
import aimas2014.goals.WeightedDesire;
import aimas2014.planning.AgentGoal;
import aimas2014.planning.AgentPlan;
import aimas2014.planning.GlobalBeliefs;
import aimas2014.planning.GlobalPlanner;
import aimas2014.planning.LocalBeliefs;
import aimas2014.planning.LocalPlanner;
import aimas2014.search.actions.ActionType;
import aimas2014.search.actions.GotoAction;
import aimas2014.search.actions.RechargeAction;
import aimas2014.search.actions.SurveyAction;
import eis.iilang.Action;
import eis.iilang.Percept;

public abstract class AIMASAgent extends Agent implements PositionedEntity {

	protected static boolean DEBUG_MODE = true;

	protected List<AgentGoal> intentions;
	protected List<WeightedDesire> desires;
	public final Set<ActionType> actionLibrary = new HashSet<>();
	public final Set<ActionType> actionLibraryDisabled = new HashSet<>();

	protected AgentPlan plan;
	protected Action lastAction = MarsUtil.skipAction();

	public LocalBeliefs beliefs;

	protected LocalPlanner localPlanner;

	public AgentStrategy strategy;

	public AIMASAgent(String name, String team) {
		super(name, team);

		actionLibrary.add(new GotoAction());
		actionLibrary.add(new RechargeAction());
		actionLibrary.add(new SurveyAction());

		actionLibraryDisabled.add(new GotoAction());
		actionLibraryDisabled.add(new RechargeAction());
	}

	@Override
	public String toString() {
		return getName();
	}

	protected void debugPrint(Object obj) {
		if (DEBUG_MODE)
			System.out.format("%s (%s): %s\n", getName(), beliefs.role, obj.toString());
	}

	protected void debugErrorPrint(Object obj) {
		if (DEBUG_MODE)
			System.err.format("%s (%s%s): %s\n", getName(), beliefs.role, beliefs.health == 0 ? ",disabled" : "", obj.toString());
	}

	@Override
	public int hashCode() {
		return getName().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj instanceof AIMASAgent)
			return getName().equals(((AIMASAgent) obj).getName());

		return super.equals(obj);
	}

	public void handlePercepts(Collection<Percept> percepts) {
		localPlanner.revise(beliefs, percepts);
	}

	public void clearDesires() {
		desires.clear();
	}

	public void receiveDesires(final List<WeightedDesire> groupDesires) {
		desires.addAll(groupDesires);
	}

	public void plan() {
		desires.addAll(strategy.options(beliefs));

		List<ActionType> actionsAvailable = new ArrayList<>();

		if (beliefs.health == 0)
			actionsAvailable.addAll(actionLibraryDisabled);
		else
			actionsAvailable.addAll(actionLibrary);

		intentions.clear();
		intentions.addAll(strategy.intentions(beliefs, actionsAvailable, desires));
		
		if (desires.size() > 0 && desires.get(0).goal instanceof IdleGoal)
			debugErrorPrint(String.format("Idling because of: %s", desires.toString()));
		
		if (desires.size() > 0 && desires.get(0).goal instanceof SurveyNodeGoal)
			debugErrorPrint(String.format("Surveying because of: %s", desires.toString()));
		
		plan = localPlanner.plan(beliefs, actionsAvailable, intentions);
	}

	public Action execute() {
		if (null != plan && !plan.isEmpty()) {
			Action a = plan.next();

			lastAction = a;

			return a;
		}

		return MarsUtil.rechargeAction();
	}

	public Action getLastAction() {
		return lastAction;
	}

	@Override
	public void handlePercept(Percept p) {
	}

	@Override
	public Action step() {
		return null;
	}

	@Override
	public MarsNode getPosition() {
		return beliefs.position;
	}

	@Override
	public String getEntityName() {
		return getName();
	}

	public void initialize(GlobalBeliefs globalBeliefs) {
		plan = null;

		intentions = new ArrayList<>();
		desires = new ArrayList<>();
		lastAction = MarsUtil.skipAction();
		localPlanner = new LocalPlanner(this);

		strategy = new DefaultStrategy();

		beliefs = new LocalBeliefs();
		beliefs.globalBeliefs = globalBeliefs;
		beliefs.globalBeliefs.agents.put(getName(), this);
		beliefs.map = globalBeliefs.map;
		beliefs.name = getName();
	}
}
