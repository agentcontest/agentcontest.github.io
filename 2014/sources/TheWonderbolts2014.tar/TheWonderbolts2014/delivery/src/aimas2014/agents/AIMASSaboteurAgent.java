package aimas2014.agents;

import aimas2014.agent.strategies.DefaultSaboteurStrategy;
import aimas2014.planning.GlobalBeliefs;
import aimas2014.search.actions.AttackAction;


public class AIMASSaboteurAgent extends AIMASAgent {
	public AIMASSaboteurAgent(String name,String team) {
		super(name,team);
		
		actionLibrary.add(new AttackAction());
	}
	
	@Override
	public void initialize(GlobalBeliefs globalBeliefs) {
		super.initialize(globalBeliefs);
		strategy = new DefaultSaboteurStrategy();
	}
}

