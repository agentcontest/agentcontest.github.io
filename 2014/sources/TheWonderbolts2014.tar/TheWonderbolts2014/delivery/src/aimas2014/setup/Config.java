package aimas2014.setup;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Config {

	private final static Map<String, Double> variables = new HashMap<>();

	public static double get(String key, double def) {
		if (!variables.containsKey(key))
			variables.put(key, def);

		return variables.get(key);
	}

	public static double get(String key) {
		return get(key, 0.5);
	}

	public static void parseFile(final String filePath) {
		try {
			FileInputStream inStream = new FileInputStream(filePath);
			DataInputStream dataInStream = new DataInputStream(inStream);
			BufferedReader br = new BufferedReader(new InputStreamReader(dataInStream));
			String line;

			Pattern pattern = Pattern.compile("^(\\w+)\\s*=?\\s*([0-9.]+)f?");

			while ((line = br.readLine()) != null) {
				Matcher matcher = pattern.matcher(line);

				if (!matcher.matches()) {
					continue;
				}

				variables.put(matcher.group(1), Double.parseDouble(matcher.group(2)));
			}

			br.close();
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		Runtime.getRuntime().addShutdownHook(new Thread() {
			@Override
			public void run() {
				PrintWriter writer;
				
				List<Entry<String, Double>> entries = new ArrayList<>(variables.entrySet());
				
				Collections.sort(entries, new Comparator<Entry<String, Double>>() {

					@Override
					public int compare(Entry<String, Double> o1, Entry<String, Double> o2) {
						return o1.getKey().compareTo(o2.getKey());
					}
				});
				
				try {
					writer = new PrintWriter(filePath, "UTF-8");
					writer.print("");
					
					for (Entry<String, Double> e : entries) {
						writer.format("%s = %.03f\n", e.getKey(), e.getValue());
					}

					writer.close();
					
				} catch (FileNotFoundException | UnsupportedEncodingException e1) {
					e1.printStackTrace();
				}
			}
		});
	}
}