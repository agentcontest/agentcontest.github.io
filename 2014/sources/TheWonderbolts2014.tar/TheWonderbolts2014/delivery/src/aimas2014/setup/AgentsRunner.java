package aimas2014.setup;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import massim.javaagents.Agent;
import aimas2014.agents.AIMASAgent;
import aimas2014.agents.AIMASEnemyAgent;
import aimas2014.goals.WeightedDesire;
import aimas2014.groups.AIMASGroup;
import aimas2014.groups.RootGroup;
import aimas2014.planning.GlobalBeliefs;
import aimas2014.planning.GlobalPlanner;
import eis.EnvironmentInterfaceStandard;
import eis.exceptions.ActException;
import eis.exceptions.NoEnvironmentException;
import eis.exceptions.PerceiveException;
import eis.iilang.Action;
import eis.iilang.Percept;

public class AgentsRunner {
    
    private GlobalBeliefs globalBeliefs;
    private GlobalPlanner globalPlanner;
    
    private final Set<AIMASAgent> agents = new HashSet<>();
    private final Set<AIMASGroup> groups = new HashSet<>();
    
    private final EnvironmentInterfaceStandard ei;
	private final String team;
    
    public AgentsRunner(String team, EnvironmentInterfaceStandard ei) {
    	this.team = team;
    	this.ei = ei;
    }
    
    public void addAgent(AIMASAgent agent) {
        agents.add(agent);
    }
    
    public void initialize() {
    	globalBeliefs = new GlobalBeliefs();
    	globalPlanner = new GlobalPlanner();
    	globalBeliefs.teamName = team;
    	
    	groups.clear();
        groups.add(new RootGroup(null, globalBeliefs));

        for (AIMASAgent agent: agents) {
        	agent.initialize(globalBeliefs);
        }
        
        for (AIMASGroup group : groups) {
        	group.members.addAll(agents);
			group.initialize();
        }
        
        //new Thread(globalPlanner).start();
    }
    
    public void step() {
    	int simulationStep = Integer.MAX_VALUE;
    	
    	if (null != globalBeliefs)
    		simulationStep = globalBeliefs.simulationStep;
    	
    	Map<AIMASAgent, Collection<Percept>> agentPercepts = new HashMap<>();
    	
    	for (AIMASAgent agent : agents) {
     		try {
				Map<String, Collection<Percept>> percepts = ei.getAllPercepts(agent.getName());
				
				Collection<Percept> ret = new ArrayList<Percept>();
				
				for (Collection<Percept> ps : percepts.values()) {
					ret.addAll(ps);
				}
				
				agentPercepts.put(agent, ret);
			} catch (PerceiveException | NoEnvironmentException e) {
				System.out.println("No perceptions received in time. Waiting for next turn...");
				
				return;
			}
        }
    	
    	for (Collection<Percept> pc: agentPercepts.values()) {
			
			int step = -1;
			
			for ( Percept p : pc ) {
				if (p.getName().equals("step")) {
					step = new Integer(p.getParameters().get(0).toProlog()).intValue();
					break;
				}
			}
			
			if (step != -1 && step < simulationStep) {
				initialize();
				
				break;
			}
    	}
    	
    	globalBeliefs.agentStep += 1;
    	
        for (AIMASAgent agent : agents) {
        	agent.clearDesires();
        	
        	if (!agentPercepts.containsKey(agent)) {
        		System.err.println("No perceptions available for " + agent.getName());
        		
        		return;
        	}
        	
            try {
                agent.handlePercepts(agentPercepts.get(agent));
            } catch (Exception e) {
                System.err.println(agent + " failed while handling perceptions: ");
                
                e.printStackTrace();
            }
        }
        
        for (AIMASGroup group : groups) {
            List<WeightedDesire> desires = new ArrayList<>();
            
            group.propagateDesires(desires);
        }
        
        for (AIMASAgent agent : agents) {
        	agent.plan();
        }
        
        List<AIMASAgent> sortedAgents = new ArrayList<>(agents);
        Collections.sort(sortedAgents, new Comparator<AIMASAgent>() {

			@Override
			public int compare(AIMASAgent o1, AIMASAgent o2) {
				return o1.beliefs.role.compareTo(o2.beliefs.role);
			}
		});
        
        for (AIMASAgent agent : sortedAgents) {
            try {
                final String agentName = agent.getName();
                final Action action = agent.execute();
                
                if (null == action)
                    continue;
                
                try {
                    Agent.getEnvironmentInterface().performAction(agentName, action);
                } catch (ActException e) {
                    // e.printStackTrace();
                    System.out.println("agent \"" + agentName + "\" action \"" + action.toProlog() + "\" failed!");
                    System.out.println("message:" + e.getMessage());
                    System.out.println("cause:" + e.getCause());
                }
            } catch (Exception e) {
                e.printStackTrace();
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e1) {
                    e1.printStackTrace();
                }
            }
        }
    }
}
