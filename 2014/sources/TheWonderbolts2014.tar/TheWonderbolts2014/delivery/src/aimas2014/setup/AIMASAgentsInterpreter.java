package aimas2014.setup;

import java.util.HashMap;
import java.util.Map;

import massim.javaagents.Agent;
import massim.javaagents.AgentSpec;
import massim.javaagents.AgentsInterpreter;
import aimas2014.agents.AIMASAgent;
import apltk.core.StepResult;
import eis.EnvironmentInterfaceStandard;
import eis.exceptions.AgentException;
import eis.exceptions.RelationException;

public class AIMASAgentsInterpreter extends AgentsInterpreter {

    public AIMASAgentsInterpreter() {
        super();
    }

    public AIMASAgentsInterpreter(String configFile) {
        super(configFile);
    }

    private final Map<String, AgentsRunner> runners = new HashMap<>();

    @Override
    public void addEnvironment(EnvironmentInterfaceStandard ei) {
        Agent.setEnvironmentInterface(ei);
        
        // process agent-specs
        for (AgentSpec as : agentSpecs) {

            if (!runners.containsKey(as.team))
                runners.put(as.team, new AgentsRunner(as.team, ei));
            
            Agent agent = Agent.createAgentFromClass(as.name, as.team, as.className);

            if (agent instanceof AIMASAgent) {
            	System.out.println("Agent found: " + agent.getClass());
                runners.get(as.team).addAgent(((AIMASAgent) agent));
            }

            try {
                ei.registerAgent(agent.getName());
            } catch (AgentException e1) {
                e1.printStackTrace();
            }

            try {
                ei.associateEntity(agent.getName(), as.entity);
            } catch (RelationException e) {
                e.printStackTrace();
            }

            ei.attachAgentListener(agent.getName(), this);
        }
        
        ei.attachEnvironmentListener(this);
    }

    @Override
    public StepResult step() {
        for (AgentsRunner runner : runners.values()) {
            runner.step();
        }

        return new StepResult();
    }

}
