package aimas2014.planning;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.PriorityQueue;
import java.util.Set;

import org.paukov.combinatorics.Factory;
import org.paukov.combinatorics.Generator;
import org.paukov.combinatorics.ICombinatoricsVector;

import aimas2014.agents.AIMASAgent;
import aimas2014.agents.AIMASEnemyAgent;
import aimas2014.agents.AIMASExplorerAgent;
import aimas2014.environment.MarsMap;
import aimas2014.environment.MarsNode;
import aimas2014.environment.MarsNodePair;
import aimas2014.environment.MarsNodePath;
import aimas2014.setup.Config;

public class Utilities {
	private static Set<MarsNode> coloredNodes = new HashSet<MarsNode>();
	private static AIMASExplorerAgent dummyAgent = null;
	private static MarsNode currentNode = null;
	private static HashMap<HashSet<MarsNode>, Integer> groupsScore = null;

	public static List<MarsNode> getScoreOptimizingConfigurationFor(
			GlobalBeliefs beliefs, int numberOfAgents) throws Exception {

		MarsMap map = beliefs.map;
		String teamName = beliefs.teamName;

		// Converting the map to an array
		MarsNode[] nodes = new MarsNode[map.nodes.size()];
		int i = 0;
		for (Entry<String, MarsNode> entry : map.nodes.entrySet()) {
			nodes[i] = entry.getValue();
			i++;
		}

		// Sorting the array by centrality score
		Arrays.sort(nodes, new Comparator<MarsNode>() {
			public int compare(MarsNode arg0, MarsNode arg1) {
				if (arg0.centrality < arg1.centrality) {
					return 1;
				}
				return -1;
			}
		});

		if (nodes.length > 22) {
			nodes = Arrays.copyOfRange(nodes, 0, 22);
		}

		ICombinatoricsVector<MarsNode> initialVector = Factory
				.createVector(nodes);
		Generator<MarsNode> gen = Factory.createSimpleCombinationGenerator(
				initialVector, numberOfAgents);

		ArrayList<AIMASAgent> agent = new ArrayList<AIMASAgent>();
		agent.add(getDummyAgent(beliefs));

		int bestScore = 0;
		MarsNode[] bestChoice = null;
		for (ICombinatoricsVector<MarsNode> combination : gen) {
			MarsNode[] potentialNodes = combination.getVector().toArray(
					new MarsNode[] {});
			Map<MarsNode, ArrayList<AIMASAgent>> positions = new HashMap<MarsNode, ArrayList<AIMASAgent>>();

			for (int j = 0; j < potentialNodes.length; j++) {
				positions.put(potentialNodes[j], agent);
			}

			Map<MarsNode, ArrayList<AIMASEnemyAgent>> enemyPositions = new HashMap<MarsNode, ArrayList<AIMASEnemyAgent>>();
			for (AIMASEnemyAgent enemy : beliefs.opponentAgents.values()) {
				if (!enemyPositions.containsKey(enemy.position)) {
					enemyPositions.put(enemy.position,
							new ArrayList<AIMASEnemyAgent>());
				}
				enemyPositions.get(enemy.position).add(enemy);
			}

			int score = getScoreFor(positions, enemyPositions, teamName);
			if (score > bestScore) {
				bestScore = score;
				bestChoice = potentialNodes;
			}
		}

		if (bestChoice == null) {
			return null;
		} else {
			System.out.println("A configuration with a score of " + bestScore
					+ " was found.");
		}

		return Arrays.asList(bestChoice);
	}
	
	public static List<HashSet<MarsNode>> getGreedyScoreOptimizingConfigurationFor(GlobalBeliefs beliefs, int numAgents){
		int rootBestScore = Integer.MIN_VALUE;
		MarsNode rootBestNode = null;
		for (MarsNode node1 : beliefs.map.nodes.values()) {
			int score = node1.calculateScore();
			if (score > rootBestScore) {
				rootBestScore = score;
				rootBestNode = node1; 
			}
		}
		
		HashSet<MarsNode> firstGroup = new HashSet<MarsNode>();
		firstGroup.add(rootBestNode);
		List<HashSet<MarsNode>> groups = new ArrayList<HashSet<MarsNode>>();
		groups.add(firstGroup);
		
		// Dummy agent
		ArrayList<AIMASAgent> dummy = new ArrayList<AIMASAgent>();
		dummy.add(getDummyAgent(beliefs));

		Set<MarsNode> nodesFromGroups = new HashSet<MarsNode>();
		nodesFromGroups.add(rootBestNode);
		
		int bestScore = Integer.MIN_VALUE;
		MarsNode bestNode = null;
		while (nodesFromGroups.size() < numAgents) {	
			for (MarsNode node : beliefs.map.nodes.values()) {
				if (nodesFromGroups.contains(node)) {
					continue; 
				}
				
				Map<MarsNode, ArrayList<AIMASAgent>> potentialPositions = new HashMap<>();
	
				potentialPositions.put(node, dummy);
				for (MarsNode groupNode : nodesFromGroups) {
					potentialPositions.put(groupNode, dummy);
				}
				int score = getScoreFor(potentialPositions, new HashMap<MarsNode, ArrayList<AIMASEnemyAgent>>(), beliefs.teamName);
				if (score > bestScore) {
					bestScore = score;
					bestNode = node;
				}
			}
			assignBestNodeToCorrectGroup(bestNode, groups);
			nodesFromGroups.add(bestNode);
		}
		
		sortGroupsByScore(groups, beliefs, dummy);

		// Restructure groups
		double groupCount = Config.get("CAHG_MAX_NUMBER_OF_GROUPS", 4.0);
		if (groups.size() > groupCount) {
			List<HashSet<MarsNode>> groupsToDelete = new ArrayList<>(
					groups.subList((int) groupCount, groups.size()));
			groups.removeAll(groupsToDelete);

			int numberOfNodesToAdd = 0;
			for (HashSet<MarsNode> hashSet : groupsToDelete) {
				numberOfNodesToAdd += hashSet.size();
			}

			for (int i = 0; i < numberOfNodesToAdd; i++) {
				Set<MarsNode> nodesFromGroups1 = new HashSet<MarsNode>();
				for (HashSet<MarsNode> givenGroup : groups) {
					nodesFromGroups1.addAll(givenGroup);
				}
				MarsNode bestNode1 = chooseBestNode(nodesFromGroups1, beliefs, dummy);
				assignBestNodeToCorrectGroup(bestNode1, groups);
			}
		}

		sortGroupsByScore(groups, beliefs, dummy);
		
		System.out.println("Formed " + groups.size() + " group(s)");
		int combinedScore = 0;
		for (Set<MarsNode> set : groups) {
			System.out.println("Size: " + set.size() + " Score: "
					+ groupsScore.get(set));
			combinedScore += groupsScore.get(set);
		}
		System.out.println("Combined score " + combinedScore);

		
		return groups;
	}

//	public static <T> List<HashSet<MarsNode>> getGreedyScoreOptimizingConfigurationForOld(
//			GlobalBeliefs beliefs, int numAgents) {
//		if (numAgents <= 0 || beliefs.map.nodes.isEmpty()) {
//			System.out.println("Agentcount " + numAgents + " Mapsize "
//					+ beliefs.map.nodes.size());
//			return null;
//		}
//
//		PriorityQueue<MarsNode> nodes = constructPriorityQueue(beliefs);
//
//		currentNode = nodes.poll();
//		HashSet<MarsNode> firstGroup = new HashSet<MarsNode>();
//		firstGroup.add(currentNode);
//		List<HashSet<MarsNode>> groups = new ArrayList<HashSet<MarsNode>>();
//		groups.add(firstGroup);
//
//		// Dummy agent
//		ArrayList<AIMASAgent> dummy = new ArrayList<AIMASAgent>();
//		dummy.add(getDummyAgent(beliefs));
//
//		for (int j = 0; j < numAgents; j++) {
//			// Getting nodes from all groups
//			Set<MarsNode> nodesFromGroups = new HashSet<MarsNode>();
//			for (HashSet<MarsNode> givenGroup : groups) {
//				nodesFromGroups.addAll(givenGroup);
//			}
//
//			if (nodesFromGroups.size() == numAgents) {
//				break;
//			}
//
//			// Choosing potential neighbours of neighbours and nodes with high
//			// centrality score
//			MarsNode bestNode = chooseBestNode(nodes, nodesFromGroups, beliefs,
//					dummy);
//
//			// Check if found node belongs to a group
//			assignBestNodeToCorrectGroup(bestNode, groups);
//
//			currentNode = bestNode;
//		}
//
//		// Sort groups by score
//		sortGroupsByScore(groups, beliefs, dummy);
//
//		// Restructure groups
//		double groupCount = Config.get("CAHG_MAX_NUMBER_OF_GROUPS", 1.0);
//		if (groups.size() > groupCount) {
//			System.out.println("RESIZE!");
//			List<HashSet<MarsNode>> groupsToDelete = new ArrayList<>(
//					groups.subList((int) groupCount, groups.size()));
//			groups.removeAll(groupsToDelete);
//
//			System.out.println("Size after groups has been removed: "
//					+ groups.size());
//
//			int numberOfNodesToAdd = 0;
//			for (HashSet<MarsNode> hashSet : groupsToDelete) {
//				numberOfNodesToAdd += hashSet.size();
//			}
//
//			for (int i = 0; i < numberOfNodesToAdd; i++) {
//				Set<MarsNode> nodesFromGroups = new HashSet<MarsNode>();
//				for (HashSet<MarsNode> givenGroup : groups) {
//					nodesFromGroups.addAll(givenGroup);
//				}
//				MarsNode bestNode = chooseBestNode(null, nodesFromGroups,
//						beliefs, dummy);
//				assignBestNodeToCorrectGroup(bestNode, groups);
//			}
//		}
//
//		sortGroupsByScore(groups, beliefs, dummy);
//
//		System.out.println("GROUPS of size: " + groups.size());
//		int combinedScore = 0;
//		for (Set<MarsNode> set : groups) {
//			System.out.println("Size: " + set.size() + " Score: "
//					+ groupsScore.get(set));
//			combinedScore += groupsScore.get(set);
//		}
//		System.out.println("Combined score " + combinedScore);
//
//		return groups;
//	}

	private static void sortGroupsByScore(List<HashSet<MarsNode>> groups,
			GlobalBeliefs beliefs, ArrayList<AIMASAgent> dummy) {
		groupsScore = new HashMap<HashSet<MarsNode>, Integer>();
		for (HashSet<MarsNode> group : groups) {
			Map<MarsNode, ArrayList<AIMASAgent>> positions = new HashMap<>();
			for (MarsNode groupMember : group) {
				positions.put(groupMember, dummy);
			}
			int score = getScoreFor(positions,
					new HashMap<MarsNode, ArrayList<AIMASEnemyAgent>>(),
					beliefs.teamName);
			groupsScore.put(group, score);
		}

		Collections.sort(groups, new Comparator<HashSet<MarsNode>>() {
			public int compare(HashSet<MarsNode> o1, HashSet<MarsNode> o2) {
				return -Integer.compare(groupsScore.get(o1),
						groupsScore.get(o2));
			}
		});
	}

	private static void assignBestNodeToCorrectGroup(MarsNode bestNode,	List<HashSet<MarsNode>> groups) {
		// Check if found node belongs to a group
		List<HashSet<MarsNode>> groupsBestNodeBelongsTo = new ArrayList<HashSet<MarsNode>>();
		for (HashSet<MarsNode> givenGroup : groups) {
			for (MarsNode groupMember : givenGroup) {
				NeighboursAndNeightboursNeighboursTuple ns = getNeighboursAndNeighboursNeighbours(groupMember);
				if (ns.neighboursNeighbours.contains(bestNode)) {
					groupsBestNodeBelongsTo.add(givenGroup);
					break;
				}
			}
		}

		// Merge / add groups
		if (groupsBestNodeBelongsTo.isEmpty()) {
			HashSet<MarsNode> newGroup = new HashSet<MarsNode>();
			newGroup.add(bestNode);
			groups.add(newGroup);
		} else {
			HashSet<MarsNode> group = groupsBestNodeBelongsTo.get(0);
			group.add(bestNode);
			for (int i = 1; i < groupsBestNodeBelongsTo.size(); i++) {
				group.addAll(groupsBestNodeBelongsTo.get(i));
				groups.remove(groupsBestNodeBelongsTo.get(i));
			}
		}
	}
	
	private static MarsNode chooseBestNode(Set<MarsNode> nodesFromGroups, GlobalBeliefs beliefs,
			ArrayList<AIMASAgent> dummy) {
		int bestScore = Integer.MIN_VALUE;
		MarsNode bestNode = null;
		
		for (MarsNode groupNodeOuter : nodesFromGroups) {
			NeighboursAndNeightboursNeighboursTuple n = getNeighboursAndNeighboursNeighbours(groupNodeOuter);
		
			// Look at neighbours neighbours
			for (MarsNode nn : n.neighboursNeighbours) {
				Map<MarsNode, ArrayList<AIMASAgent>> potentialPositions = new HashMap<>();
	
				if (!intersect(nn.getNeighboursAsMap().keySet(), nodesFromGroups)) {
					potentialPositions.put(nn, dummy);
					for (MarsNode groupNode : nodesFromGroups) {
						potentialPositions.put(groupNode, dummy);
					}
					int score = getScoreFor(potentialPositions,
							new HashMap<MarsNode, ArrayList<AIMASEnemyAgent>>(),
							beliefs.teamName);
					if (score > bestScore) {
						bestScore = score;
						bestNode = nn;
					}
				}
			}
		}

		return bestNode;
	}

	private static MarsNode chooseBestNodeOld(PriorityQueue<MarsNode> nodes,
			Set<MarsNode> nodesFromGroups, GlobalBeliefs beliefs,
			ArrayList<AIMASAgent> dummy) {
		NeighboursAndNeightboursNeighboursTuple n = getNeighboursAndNeighboursNeighbours(currentNode);

		Set<MarsNode> bestFromCentralityQueueNodes = new HashSet<MarsNode>();
		if (nodes != null) {
			while (bestFromCentralityQueueNodes.size() < 5) {
				MarsNode nodeFromQueue = nodes.poll();
				if (nodeFromQueue == null) {
					break;
				}

				if (nodeFromQueue != null) {
					boolean usable = true;
					for (MarsNode distNode : nodesFromGroups) {
						MarsNodePath path = beliefs.map.path(nodeFromQueue,
								distNode);
						int distance = Integer.MAX_VALUE;
						if (path != null) {
							distance = path.searchPath.size() - 1;
						}

						if (distance != Integer.MAX_VALUE
								&& (distance <= 2 || distance % 2 != 0)) {
							usable = false;
							break;
						}
					}
					if (usable) {
						bestFromCentralityQueueNodes.add(nodeFromQueue);
					}
				}
			}
		}

		int bestScore = Integer.MIN_VALUE;
		MarsNode bestNode = null;

		// Look at neighbours neighbours
		for (MarsNode nn : n.neighboursNeighbours) {
			Map<MarsNode, ArrayList<AIMASAgent>> potentialPositions = new HashMap<>();

			if (!intersect(nn.getNeighboursAsMap().keySet(), nodesFromGroups)) {
				potentialPositions.put(nn, dummy);
				for (MarsNode groupNode : nodesFromGroups) {
					potentialPositions.put(groupNode, dummy);
				}
				int score = getScoreFor(potentialPositions,
						new HashMap<MarsNode, ArrayList<AIMASEnemyAgent>>(),
						beliefs.teamName);
				if (score > bestScore) {
					bestScore = score;
					bestNode = nn;
				}
			}
		}

		// Look at nodes from queue
		for (MarsNode nq : bestFromCentralityQueueNodes) {
			Map<MarsNode, ArrayList<AIMASAgent>> potentialPositions = new HashMap<>();
			potentialPositions.put(nq, dummy);
			for (MarsNode groupNode : nodesFromGroups) {
				potentialPositions.put(groupNode, dummy);
			}
			int score = getScoreFor(potentialPositions,
					new HashMap<MarsNode, ArrayList<AIMASEnemyAgent>>(),
					beliefs.teamName);
			if (score > bestScore) {
				bestScore = score;
				bestNode = nq;
			}
		}

		if (nodes != null) {
			nodes.addAll(bestFromCentralityQueueNodes);
			nodes.remove(bestNode);
		}
		return bestNode;
	}

	private static PriorityQueue<MarsNode> constructPriorityQueue(
			GlobalBeliefs beliefs) {
		int size = beliefs.map.nodes.size() > 0 ? beliefs.map.nodes.size() : 1;

		PriorityQueue<MarsNode> nodes = new PriorityQueue<>(size,
				new Comparator<MarsNode>() {
					public int compare(MarsNode arg0, MarsNode arg1) {
						if (arg0.calculateScore() < arg1.calculateScore()) {
							return 1;
						}
						return -1;
					}
				});

		for (MarsNode marsNode : beliefs.map.nodes.values()) {
			nodes.add(marsNode);
		}
		return nodes;
	}

	private static boolean intersect(Set<MarsNode> set1, Set<MarsNode> set2) {
		Set<MarsNode> a;
		Set<MarsNode> b;
		if (set1.size() < set2.size()) {
			a = set1;
			b = set2;
		} else {
			a = set2;
			b = set1;
		}

		for (MarsNode marsNode : a) {
			if (b.contains(marsNode))
				return true;
		}

		return false;
	}

	private static class NeighboursAndNeightboursNeighboursTuple {

		public final Set<MarsNode> neighbours;
		public final Set<MarsNode> neighboursNeighbours;

		public NeighboursAndNeightboursNeighboursTuple(
				Set<MarsNode> neighbours, Set<MarsNode> neighboursNeighbours) {
			super();
			this.neighbours = neighbours;
			this.neighboursNeighbours = neighboursNeighbours;
		}

	}

	private static NeighboursAndNeightboursNeighboursTuple getNeighboursAndNeighboursNeighbours(
			MarsNode node) {
		Set<MarsNode> neighbours = node.getNeighboursAsMap().keySet();
		Set<MarsNode> neighboursNeighbours = new HashSet<>();
		for (MarsNode marsNode : neighbours) {
			neighboursNeighbours.addAll(marsNode.getNeighboursAsMap().keySet());
		}
		neighboursNeighbours.removeAll(neighbours);
		neighboursNeighbours.remove(node);
		return new NeighboursAndNeightboursNeighboursTuple(neighbours,
				neighboursNeighbours);
	}

	public static int getScoreFor(
			Map<MarsNode, ArrayList<AIMASAgent>> ourPositions,
			Map<MarsNode, ArrayList<AIMASEnemyAgent>> enemyPositions,
			String teamName) {
		coloredNodes.clear();

		// Step 1
		for (Entry<MarsNode, ArrayList<AIMASAgent>> entry : ourPositions
				.entrySet()) {
			MarsNode node = entry.getKey();
			if (isDominated(node, ourPositions, enemyPositions) == 1) {
				coloredNodes.add(node);
			}
		}

		// Step 2
		Set<MarsNode> newColoredNodes = new HashSet<>();
		for (MarsNode coloredNode : coloredNodes) {
			for (MarsNode neighbour : coloredNode.getNeighboursAsMap().keySet()) {
				if (!coloredNodes.contains(neighbour)) {
					int ourCounter = 0;
					int enemyCounter = 0;

					for (MarsNode neighboursNeighbour : neighbour
							.getNeighboursAsMap().keySet()) {
						int dominated = isDominated(neighboursNeighbour,
								ourPositions, enemyPositions);
						if (dominated == 1)
							ourCounter++;
						else if (dominated == -1)
							enemyCounter++;
					}

					if (ourCounter > 1 && ourCounter > enemyCounter) {
						newColoredNodes.add(neighbour);
					}
				}
			}
		}
		coloredNodes.addAll(newColoredNodes);

		// Calculating the score
		int score = 0;
		for (MarsNode node : coloredNodes) {
			score += node.weight;
		}
		if (coloredNodes.size() > 0) {
			return score;
		}
		return score;
	}

	private static int isDominated(MarsNode node,
			Map<MarsNode, ArrayList<AIMASAgent>> ourPositions,
			Map<MarsNode, ArrayList<AIMASEnemyAgent>> enemyPositions) {
		if (ourPositions.containsKey(node) && enemyPositions.containsKey(node)) {
			if (ourPositions.get(node).size() > enemyPositions.get(node).size())
				return 1;
			else if (ourPositions.get(node).size() < enemyPositions.get(node)
					.size())
				return -1;
		} else if (ourPositions.containsKey(node)) {
			return 1;
		} else if (enemyPositions.containsKey(node)) {
			return -1;
		}
		return 0;
	}

	public static List<MarsNodePair> getMaxProbedScoreSets(GlobalBeliefs beliefs) {
		List<MarsNodePair> sortedPairs = new ArrayList<>();

		List<MarsNode> probedNodes = new ArrayList<>();
		for (MarsNode node : beliefs.map.nodes.values()) {
			if (node.state.probed) {
				probedNodes.add(node);
			}
		}

		if (probedNodes.size() > 1) {
			ICombinatoricsVector<MarsNode> initialVector = Factory
					.createVector(probedNodes.toArray(new MarsNode[] {}));
			Generator<MarsNode> gen = Factory.createSimpleCombinationGenerator(
					initialVector, 2);

			long startTime = System.currentTimeMillis();
			for (ICombinatoricsVector<MarsNode> combination : gen) {
				List<MarsNode> pair = combination.getVector();
				MarsNode a = pair.get(0);
				MarsNode b = pair.get(1);

				MarsNodePath path = beliefs.map.path(a, b);
				if (path != null && path.searchPath.size() - 1 == 2) {
					boolean occupied = false;
					for (AIMASEnemyAgent enemy : beliefs.opponentAgents
							.values()) {
						if (enemy.position.equals(a)
								|| enemy.position.equals(b)) {
							occupied = true;
							break;
						}
					}

					if (!occupied) {
						Map<MarsNode, ArrayList<AIMASAgent>> agentsConfiguration = new HashMap<>();
						ArrayList<AIMASAgent> agentPlaceholder = new ArrayList<AIMASAgent>();
						agentPlaceholder.add(getDummyAgent(beliefs));
						agentsConfiguration.put(a, agentPlaceholder);
						agentsConfiguration.put(b, agentPlaceholder);
						int score = 0;// getScoreFor(agentsConfiguration, new
										// HashMap<MarsNode,
										// ArrayList<AIMASEnemyAgent>>(),
										// beliefs.teamName);

						sortedPairs.add(new MarsNodePair(a, b, score));
					}
				}
			}
			System.out.println("Exec time: "
					+ (System.currentTimeMillis() - startTime));
			Collections.sort(sortedPairs, new Comparator<MarsNodePair>() {
				public int compare(MarsNodePair o1, MarsNodePair o2) {
					return -Integer.compare(o1.score, o2.score);
				}
			});
		}

		return sortedPairs;
	}

	private static AIMASExplorerAgent getDummyAgent(GlobalBeliefs beliefs) {
		if (dummyAgent == null) {
			dummyAgent = new AIMASExplorerAgent("Dummy", beliefs.teamName);
		}
		return dummyAgent;
	}

//	public static void outputToDot(AIMASGroup group) {
//		String filename = String.format("GroupHierarchy");
//
//		BufferedWriter out = null;
//		try {
//			FileWriter fstream = new FileWriter(String.format("dot/%s.dot",
//					filename));
//			out = new BufferedWriter(fstream);
//
//			out.write("graph GroupHierarchy {\n");
//
//			out.write(String.format("%s\n", group.toString()));
//
//			List<AIMASGroup> queue = new ArrayList<>();
//			queue.add(group);
//			Set<AIMASGroup> used = new HashSet<AIMASGroup>();
//			Map<AIMASGroup, ArrayList<AIMASGroup>> children = new HashMap<AIMASGroup, ArrayList<AIMASGroup>>();
//
//			while (!queue.isEmpty()) {
//				AIMASGroup currentGroup = queue.remove(0);
//				used.add(currentGroup);
//
//				for (AIMASGroup g : currentGroup.subgroups) {
//					if (!queue.contains(g) && !used.contains(g)) {
//						ArrayList<AIMASGroup> childList = children
//								.get(currentGroup);
//						if (childList == null) {
//							children.put(currentGroup, childList);
//						}
//
//						children.get(currentGroup).add(g);
//						queue.add(g);
//					}
//					out.write(String.format("%s\n", g.toString()));
//
//				}
//			}
//
//			for (MarsNode node : nodes.values()) {
//				for (Entry<MarsNode, Integer> nb : node.neighbours.entrySet()) {
//
//					String label = nb.getValue() == MarsNode.UNKNOWN_EDGE_WEIGHT ? ""
//							: Integer.toString(nb.getValue());
//					String color = "black";
//					String style = nb.getValue() == MarsNode.UNKNOWN_EDGE_WEIGHT ? "dotted"
//							: "solid";
//
//					MarsNodePair p = new MarsNodePair(node, nb.getKey());
//
//					if (!drawnEdges.contains(p))
//						out.write(String.format(
//								"%s -- %s [label=\"%s\" color=%s style=%s]\n",
//								node.name, nb.getKey().name, label, color,
//								style));
//
//					drawnEdges.add(p);
//				}
//			}
//
//			out.write("}\n");
//			out.close();
//
//			Runtime.getRuntime().exec(
//					String.format("fdp -Tpng dot/%s.dot -o ps/%s.png",
//							filename, filename));
//		} catch (IOException e) {
//			System.err.println("Error: " + e.getMessage());
//
//			if (out != null) {
//				try {
//					out.close();
//				} catch (IOException e1) {
//					// TODO Auto-generated catch block
//					e1.printStackTrace();
//				}
//			}
//		}
//	}
}
