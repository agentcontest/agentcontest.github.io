package aimas2014.planning;

import java.util.List;
import java.util.Set;

import aimas2014.search.GoalConditionType;
import aimas2014.search.SearchNodeType;
import aimas2014.search.actions.ActionType;

public abstract class AgentGoal extends GoalConditionType {
    @Override
	public abstract boolean suceeded(SearchNodeType s);
    public abstract AgentPlan producePlan(LocalBeliefs beliefs, List<ActionType> actionLibrary);
    
    public abstract Set<ActionType> actionsRequired();
    
    @Override
    public String toString() {
    	return getClass().getSimpleName();
    }
}