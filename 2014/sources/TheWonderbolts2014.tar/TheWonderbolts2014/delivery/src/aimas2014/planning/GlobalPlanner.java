package aimas2014.planning;

import java.util.ArrayList;
import java.util.List;

import aimas2014.agents.AIMASAgent;
import aimas2014.environment.MarsNode;
import aimas2014.goals.GotoNodeGoal;

public class GlobalPlanner implements Runnable {

	private boolean idle = true;
	private boolean doPlan = false;

	private List<AgentGoal> availableAgentDesires = new ArrayList<>();
	private GlobalBeliefs sharedBeliefs;

	private static final class Lock {
	}

	private final Lock idleLock = new Lock();
	private final Lock optimalNodesLock = new Lock();

	public GlobalPlanner() {
		super();
	}

	public synchronized List<AgentGoal> getDesiresFor(AIMASAgent agent) {
		//sharedBeliefs = agent.getSharedBeliefs();

		synchronized (optimalNodesLock) {
			if (0 == availableAgentDesires.size()) {
				doPlan = true;

				synchronized (idleLock) {
					idle = false;
					idleLock.notifyAll();
				}
			}

			return availableAgentDesires;
		}

	}

	@Override
	public void run() {
	    
	    
//		while (true) {
//			try {
//				synchronized (idleLock) {
//					while (idle) {
//						idleLock.wait();
//					}
//				}
//
//				if (doPlan)
//				    planOptimalPositions();
//
//				synchronized (idleLock) {
//					idle = true;
//				}
//			} catch (InterruptedException e) {
//
//				e.printStackTrace();
//			}
//		}
	}

	private void planOptimalPositions() {
		doPlan = false;
	    
	    synchronized (optimalNodesLock) {
	        availableAgentDesires.clear();
        }
		
		if (sharedBeliefs.map.unexploredNodes.size() > 0)
			return;
		
		List<MarsNode> optimalNodes = new ArrayList<MarsNode>();
		
        try {
            optimalNodes = Utilities.getScoreOptimizingConfigurationFor(sharedBeliefs, sharedBeliefs.agents.size());
            
            if (0 == optimalNodes.size())
                throw new Exception("Empty optimal node set");
        } catch (Exception e) {
            e.printStackTrace();
        } 
			
        synchronized (optimalNodesLock) { 
			try {
                for (MarsNode node: optimalNodes) {
                	availableAgentDesires.add(new GotoNodeGoal(node));
                }
            } catch (Exception e1) {
                e1.printStackTrace();
            }
		}
	}
}
