package aimas2014.planning;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.javatuples.Triplet;

public class Auction {
	
	public static <T, U> List<Triplet<T, U, Integer>> produceTargets(Collection<T> groupA, Collection<U> groupB, BinaryFunctor<T, U> generator) {
		List<Triplet<T, U, Integer>> targets = new ArrayList<>(groupA.size() * groupB.size());
		
		for (T e1 : groupA) {
			for (U e2 : groupB) {
				Integer result = generator.apply(e1, e2);

				if (null != result)
					targets.add(Triplet.with(e1, e2, result));
			}
		}
		
		return targets;
	}
	
	public static <T, U> Map<T, U> auction(List<Triplet<T, U, Integer>> targets, int num) {
		Collections.sort(targets, new Comparator<Triplet<T, U, Integer>>() {
			@Override
			public int compare(Triplet<T, U, Integer> o1, Triplet<T, U, Integer> o2) {
				return o1.getValue2().compareTo(o2.getValue2());
			}
		});
		
		Set<T> takenGroupA = new HashSet<>(num);
		Set<U> takenGroupB = new HashSet<>(num);

		Map<T, U> results = new HashMap<>(num);
		
		for (int i = 0, j = 0; i < targets.size() && j < num; ++i) {
			Triplet<T, U, Integer> triple = targets.get(i);
			
			T e1 = triple.getValue0();
			U e2 = triple.getValue1();
			
			if (takenGroupA.contains(e1) || takenGroupB.contains(e2))
				continue;
			
			results.put(e1, e2);

			takenGroupA.add(e1);
			takenGroupB.add(e2);
			
			++j;
		}

		return results;
	}

	public static <T, U> Map<T, U> auction(Collection<T> groupA, Collection<U> groupB, BinaryFunctor<T, U> generator) {
		return auction(produceTargets(groupA, groupB, generator), groupA.size());
	}
}
