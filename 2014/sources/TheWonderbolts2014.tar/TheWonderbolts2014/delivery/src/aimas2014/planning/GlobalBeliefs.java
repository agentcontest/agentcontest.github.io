package aimas2014.planning;

import java.util.HashMap;
import java.util.Map;

import aimas2014.agents.AIMASAgent;
import aimas2014.agents.AIMASEnemyAgent;
import aimas2014.environment.MarsMap;

public class GlobalBeliefs {
	public Map<String, AIMASAgent> agents = new HashMap<>();
	public Map<String, AIMASEnemyAgent> opponentAgents = new HashMap<>();
	
    public MarsMap map = new MarsMap();

    public int numVertices;
    public int simulationStep = Integer.MAX_VALUE;
    public int agentStep = 0;

    public String teamName;
    
    public int numOpponents() {
    	return agents.size();
    }
    
    public int numInspectedOpponents() {
		int result = 0;

		for (AIMASEnemyAgent agent : opponentAgents.values()) {
			if (0 <= agent.agentStepInspected)
				result += 1;
		}

		return result;
	}
}