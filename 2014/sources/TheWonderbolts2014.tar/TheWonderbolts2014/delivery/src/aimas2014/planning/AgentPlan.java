package aimas2014.planning;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;

import aimas2014.search.SearchNodeType;
import aimas2014.search.actions.ActionType.InstantiatedAction;
import eis.iilang.Action;

public class AgentPlan {
    private Queue<InstantiatedAction> plannedActions;
    
    public SearchNodeType initialNode;
    public SearchNodeType terminalNode;
    
    public AgentPlan(List<InstantiatedAction> solution, SearchNodeType initial, SearchNodeType terminal) {
        this.plannedActions = new ArrayDeque<>(solution);
        
        this.initialNode = initial;
        this.terminalNode = terminal;
    }
    
    public AgentPlan(List<InstantiatedAction> solution) {
        this(solution, null, null);
    }

    public AgentPlan() {
        this(new ArrayList<InstantiatedAction>(), null, null);
    }

    public Action next() {
        if (plannedActions.isEmpty())
            return null;
        
        return plannedActions.poll().realize();
    }

    public InstantiatedAction peek() {
        return plannedActions.peek();
    }

    public int length() {
        return plannedActions.size();
    }
    
    public AgentPlan append(InstantiatedAction action) {
        plannedActions.add(action);
        
//        if (null != terminalNode)
//        	terminalNode = action.apply(terminalNode);
        
        return this;
    }
    
    public boolean sound() {
    	return initialNode != null && terminalNode != null && plannedActions.size() > 0;
    }
    
    public boolean isEmpty() {
        return 0 == length();
    }
}
