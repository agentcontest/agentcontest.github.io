package aimas2014.planning;

import java.util.Collection;
import java.util.List;

import aimas2014.agents.AIMASAgent;
import aimas2014.agents.AIMASEnemyAgent;
import aimas2014.environment.MarsNode;
import aimas2014.search.actions.ActionType;
import eis.iilang.Percept;

public class LocalPlanner {
	@SuppressWarnings("deprecation")
	private String getParameter(Percept p, Integer i) {
		return p.getParameters().get(i).toString();
	}

	protected final AIMASAgent agent;

	public LocalPlanner(AIMASAgent agent) {
		this.agent = agent;
	}

	public LocalBeliefs revise(LocalBeliefs beliefs, Collection<Percept> percepts) {

		for (Percept p : percepts) {
			if (p.getName().equals("step")) {
				beliefs.globalBeliefs.simulationStep = Integer.parseInt(getParameter(p, 0));
			} else if (p.getName().equals("lastActionResult")) {
				beliefs.lastActionResult = getParameter(p, 0);
			} else if (p.getName().equals("health")) {
				beliefs.health = Integer.parseInt(getParameter(p, 0));
			} else if (p.getName().equals("maxHealth")) {
				beliefs.maxHealth = Integer.parseInt(getParameter(p, 0));
			} else if (p.getName().equals("position")) {
				beliefs.position = beliefs.map.getNode(getParameter(p, 0));
			} else if (p.getName().equals("energy")) {
				beliefs.energy = Integer.parseInt(getParameter(p, 0));
			} else if (p.getName().equals("strength")) {
				beliefs.strength = Integer.parseInt(getParameter(p, 0));
			} else if (p.getName().equals("visRange")) {
				beliefs.visRange = Integer.parseInt(getParameter(p, 0));
			} else if (p.getName().equals("maxEnergy")) {
				beliefs.maxEnergy = Integer.parseInt(getParameter(p, 0));
			} else if (p.getName().equals("role")) {
				beliefs.role = getParameter(p, 0);
			} else if (p.getName().equals("vertices")) {
				beliefs.globalBeliefs.numVertices = Integer.parseInt(getParameter(p, 0));
			}
		}

		for (Percept p : percepts) {
			if (p.getName().equals("visibleEntity")) {
				
				String name = getParameter(p, 0);
				String position = getParameter(p, 1);
				String team = getParameter(p, 2);
				String status = getParameter(p, 3);
				
				GlobalBeliefs gb = beliefs.globalBeliefs;
				MarsNode nodePosition =  beliefs.map.getNode(position);
				
				if (!gb.teamName.equals(team)) {
					if (!gb.opponentAgents.containsKey(name)) {
						gb.opponentAgents.put(name, new AIMASEnemyAgent(name, team, nodePosition, status));
					} 
					
					AIMASEnemyAgent agent = gb.opponentAgents.get(name);

					agent.agentStepLastSeen = beliefs.globalBeliefs.agentStep;
					agent.status = status;
					agent.position = nodePosition;
				}
				
			} else if (p.getName().equals("visibleEdge")) {
				String v1 = getParameter(p, 0);
				String v2 = getParameter(p, 1);

				MarsNode n1 = beliefs.map.getNode(v1);
				MarsNode n2 = beliefs.map.getNode(v2);

				n1.addEdge(n2, MarsNode.UNKNOWN_EDGE_WEIGHT);
				n2.addEdge(n1, MarsNode.UNKNOWN_EDGE_WEIGHT);

				if (!beliefs.map.exploredNodes.contains(n1)) {
					beliefs.map.unexploredNodes.add(n1);
				}

				if (!beliefs.map.exploredNodes.contains(n2)) {
					beliefs.map.unexploredNodes.add(n2);
				}
			} else if (p.getName().equals("probedVertex")) {
				String n = getParameter(p, 0);
				int weight = Integer.parseInt(getParameter(p, 1));

				beliefs.map.getNode(n).weight = weight;
				beliefs.map.getNode(n).state.probed = true;
			} else if (p.getName().equals("surveyedEdge")) {
				String p1 = getParameter(p, 0);
				String p2 = getParameter(p, 1);
				int cost = Integer.parseInt(getParameter(p, 2));

				MarsNode n1 = beliefs.map.getNode(p1);
				MarsNode n2 = beliefs.map.getNode(p2);

				if (null != n1)
					n1.setEdgeCost(n2, cost);

				if (null != n2)
					n2.setEdgeCost(n1, cost);

			} else if (p.getName().equals("position")) {
				MarsNode positionNode = beliefs.map.getNode(getParameter(p, 0));

				beliefs.map.unexploredNodes.remove(positionNode);
				beliefs.map.exploredNodes.add(positionNode);
			} else if (p.getName().equals("inspectedEntity")) {
				String name = getParameter(p, 0);
				String team = getParameter(p, 1);
				
				GlobalBeliefs gb = beliefs.globalBeliefs;
				
				if (!gb.teamName.equals(team) && gb.opponentAgents.containsKey(name)) {
					AIMASEnemyAgent agent = gb.opponentAgents.get(name);

					agent.agentStepLastSeen = beliefs.globalBeliefs.agentStep;
					agent.agentStepInspected = beliefs.globalBeliefs.agentStep;

					agent.type = getParameter(p, 2);
					agent.position = beliefs.map.getNode(getParameter(p, 3));
					agent.energy = Integer.parseInt(getParameter(p, 4));
					agent.maxEnergy = Integer.parseInt(getParameter(p, 5));
					
					agent.health = Integer.parseInt(getParameter(p, 6));
					agent.maxHealth = Integer.parseInt(getParameter(p, 7));
					
					agent.strength = Integer.parseInt(getParameter(p, 8));
					agent.visRange = Integer.parseInt(getParameter(p, 9));
				}				
			}  
		}

		return beliefs;
	}

	public boolean sound(AgentPlan plan, List<AgentGoal> intentions, LocalBeliefs beliefs) {
		if (beliefs.lastActionResult.contains("failed")) {
			return false;
		}

		return true;
	}

	public AgentPlan plan(LocalBeliefs beliefs, List<ActionType> actionLibrary, List<AgentGoal> intentions) {
		for (AgentGoal goal : intentions) {
			return goal.producePlan(beliefs, actionLibrary);
		}

		return new AgentPlan();
	}

	public boolean reconsider(List<AgentGoal> intentions, LocalBeliefs beliefs) {
		return false;
	}
}
