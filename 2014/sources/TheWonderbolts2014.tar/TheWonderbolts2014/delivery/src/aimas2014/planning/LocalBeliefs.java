package aimas2014.planning;

import aimas2014.environment.MarsMap;
import aimas2014.environment.MarsNode;

public class LocalBeliefs {
    public int energy = 0;
    public int maxEnergy = 0;
    public int health = 0;
    public int maxHealth = 0;
    public int visRange = 0;
    public int strength = 0;
    
    public String lastActionResult = "";
    public String role = "Unknown";
    public String name = "Unnamed agent";
    
    public MarsMap map = new MarsMap();
    public MarsNode position = null;

    public GlobalBeliefs globalBeliefs;
}