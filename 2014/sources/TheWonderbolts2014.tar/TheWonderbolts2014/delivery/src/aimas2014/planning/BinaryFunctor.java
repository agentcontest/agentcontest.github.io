package aimas2014.planning;

public abstract class BinaryFunctor<T, K> {
	public abstract Integer apply(T e1, K e2);
}