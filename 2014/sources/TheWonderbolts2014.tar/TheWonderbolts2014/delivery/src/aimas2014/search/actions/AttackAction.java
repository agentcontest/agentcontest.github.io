package aimas2014.search.actions;

import java.util.ArrayList;
import java.util.List;

import aimas2014.search.SearchNodeType;
import aimas2014.search.TargetedSearchNode;
import aimas2014.search.instantiations.InstantiatedAttackAction;

public class AttackAction extends ActionType {

	@Override
	public List<InstantiatedAction> instantiations(SearchNodeType s) {
		List<InstantiatedAction> result = new ArrayList<>();

		if (s instanceof TargetedSearchNode)
			result.add(new InstantiatedAttackAction(((TargetedSearchNode) s).target));

		return result;
	}

	@Override
	public boolean equals(Object obj) {
		return obj instanceof AttackAction;
	}
}