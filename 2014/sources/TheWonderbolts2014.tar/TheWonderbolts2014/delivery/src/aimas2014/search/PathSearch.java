package aimas2014.search;

import java.util.List;

import aimas2014.environment.MarsNode;
import aimas2014.environment.MarsNodePath;

public class PathSearch {
	
	public static MarsNode energyCenter(MarsNodePath path) {
		final List<MarsSearchNode> searchPath = path.searchPath;
		
		int leftPointer = 0;
		int rightPointer = searchPath.size() - 1;
		
		while (leftPointer != rightPointer) {
			int leftValue = searchPath.get(leftPointer++).totalEnergySpent - searchPath.get(leftPointer).totalEnergySpent;
			int rightValue = searchPath.get(rightPointer).totalEnergySpent - searchPath.get(rightPointer--).totalEnergySpent; 
			
			if (leftValue <= rightValue) {
				leftPointer += 1;
			} else {
				rightPointer += 1;
			}
		}
				
		return searchPath.get(leftPointer).node;
	}
}
