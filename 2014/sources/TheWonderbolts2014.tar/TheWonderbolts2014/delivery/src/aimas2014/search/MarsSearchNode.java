package aimas2014.search;

import aimas2014.environment.MarsNode;

public class MarsSearchNode extends SearchNodeType {
    public MarsNode node;
    
    public int steps;
    public int totalEnergySpent;
    public int currentEnergy;
    public final int maxEnergy;
    
    // Node states
    public boolean nodeProbed;
    public boolean nodeSurveyed;
    
    // Node action states
    public boolean nodeAttacked;
    public boolean nodeParried;
    public boolean nodeInspected;
    public boolean nodeRepaired;
    
    public MarsSearchNode(MarsNode newNode, int currentEnergy, int maxEnergy) {
        this.node = newNode;
        this.steps = 0;
        this.totalEnergySpent = 0;
        this.currentEnergy = currentEnergy;
        this.maxEnergy = maxEnergy;
        this.nodeProbed = newNode.state.probed;
        this.nodeSurveyed = newNode.allEdgesSurveyed();
        
        this.nodeAttacked = false;
        this.nodeParried = false;
        this.nodeInspected = false;
        this.nodeRepaired = false;
    }
    
    public MarsSearchNode(MarsSearchNode parent) {
        this.node = parent.node;
        this.steps = parent.steps;
        this.totalEnergySpent = parent.totalEnergySpent;
        this.currentEnergy = parent.currentEnergy;
        this.maxEnergy = parent.maxEnergy;
        this.nodeProbed = parent.nodeProbed;
        this.nodeSurveyed = parent.nodeSurveyed;
        
        this.nodeAttacked = false;
        this.nodeParried = false;
        this.nodeInspected = false;
        this.nodeRepaired = false;
    }
    
    public MarsSearchNode step() {
    	steps += 1;
    	
    	return this;
    }
    
    public MarsSearchNode cost(int cost) {
    	totalEnergySpent += cost;
    	currentEnergy = Math.max(currentEnergy - cost, 0);
    	
    	return this;
    }
    
    public MarsSearchNode probed() {
    	nodeProbed = true;
    	
    	return this;
    }
    
    public MarsSearchNode surveyed() {
    	nodeSurveyed = true;
    	
    	return this;
    }
    
    public MarsSearchNode attacked() {
    	nodeAttacked = true;
    	
    	return this;
    }
    
    public MarsSearchNode parried() {
    	nodeParried = true;
    	
    	return this;
    }
    
    public MarsSearchNode repaired() {
    	nodeRepaired = true;
    	
    	return this;
    }
    
    public MarsSearchNode inspected() {
    	nodeInspected = true;
    	
    	return this;
    }
    
    public MarsSearchNode moved(MarsNode to) {
    	node = to;
    	nodeProbed = to.state.probed;
        nodeSurveyed = to.allEdgesSurveyed();
    	
    	return this;
    }
    
    public MarsSearchNode recharged() {
    	currentEnergy = currentEnergy + (maxEnergy / 2);
        currentEnergy = currentEnergy > maxEnergy ? maxEnergy : currentEnergy;
    	
    	return this;
    }
    
    @Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((node == null) ? 0 : node.hashCode());
		result = prime * result + ((parentAction == null) ? 0 : parentAction.hashCode());
		result = prime * result + (nodeProbed ? 1231 : 1237);
		result = prime * result + (nodeSurveyed ? 1231 : 1237);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof MarsSearchNode))
			return false;
		
		MarsSearchNode other = (MarsSearchNode) obj;
		
		return node.equals(other.node) && parentAction.equals(other.parentAction) 
				&& nodeProbed == other.nodeProbed 
				&& nodeSurveyed == other.nodeSurveyed
				&& nodeAttacked == other.nodeAttacked
				&& nodeParried == other.nodeParried
				&& nodeInspected == other.nodeInspected
				&& nodeRepaired == other.nodeRepaired;
	}

	@Override
	public SearchNodeType copy() {
		return new MarsSearchNode(this);
	}
    
    
    

}
