package aimas2014.search;

import aimas2014.environment.MarsNode;

public abstract class MarsNodePredicate {
	public abstract boolean test(final MarsNode node);
}