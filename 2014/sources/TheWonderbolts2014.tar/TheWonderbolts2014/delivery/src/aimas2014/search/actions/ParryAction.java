package aimas2014.search.actions;

import java.util.ArrayList;
import java.util.List;

import aimas2014.search.SearchNodeType;
import aimas2014.search.instantiations.InstantiatedParryAction;

public class ParryAction extends ActionType {

    @Override
    public List<InstantiatedAction> instantiations(SearchNodeType s) {
        List<InstantiatedAction> result = new ArrayList<>();

        result.add(new InstantiatedParryAction());
        
        return result;
    }
}