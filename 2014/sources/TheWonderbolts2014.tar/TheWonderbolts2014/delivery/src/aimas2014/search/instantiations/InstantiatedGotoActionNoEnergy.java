package aimas2014.search.instantiations;

import massim.javaagents.agents.MarsUtil;
import aimas2014.environment.MarsNode;
import aimas2014.search.MarsSearchNode;
import aimas2014.search.SearchNodeType;
import aimas2014.search.actions.ActionType.InstantiatedAction;
import eis.iilang.Action;

public class InstantiatedGotoActionNoEnergy extends InstantiatedAction {
    private final MarsNode toNode;
    private final int edgeCost;

    public InstantiatedGotoActionNoEnergy(MarsNode toNode, int edgeCost) {
        super();
        this.toNode = toNode;
        this.edgeCost = edgeCost;
    }
    
    @Override
    public Action realize() {
        return MarsUtil.gotoAction(toNode.name);
    }
    
    @Override
    public SearchNodeType apply(SearchNodeType s) {
        return ((MarsSearchNode) s.copy()).step().cost(edgeCost).moved(toNode);
    }
    
    @Override
    public int hashCode() {
        return ("goto" + toNode.name).hashCode();
    }
    
    @Override
    public boolean equals(Object obj) {
    	if (obj instanceof InstantiatedGotoActionNoEnergy) {
    		return toNode.equals(((InstantiatedGotoActionNoEnergy) obj).toNode);
    	}
    	
    	return false;
    }

	@Override
	public boolean isApplicable(SearchNodeType s) {
		return MarsNode.UNKNOWN_EDGE_WEIGHT != edgeCost;
	}
}