package aimas2014.search.instantiations;

import massim.javaagents.agents.MarsUtil;
import aimas2014.agents.PositionedEntity;
import aimas2014.search.MarsSearchNode;
import aimas2014.search.SearchNodeType;
import aimas2014.search.actions.ActionType.InstantiatedAction;
import eis.iilang.Action;

public final class InstantiatedAttackAction extends InstantiatedAction {
	private final PositionedEntity target;

	public InstantiatedAttackAction(PositionedEntity target) {
		this.target = target;
	}

	@Override
	public Action realize() {
		return MarsUtil.attackAction(target.getEntityName());
	}

	@Override
	public SearchNodeType apply(SearchNodeType s) {
		return ((MarsSearchNode) s.copy()).step().cost(2).attacked();
	}

	@Override
	public int hashCode() {
		return "attack".hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return obj instanceof InstantiatedAttackAction;
	}

	@Override
	public boolean isApplicable(SearchNodeType s) {
		MarsSearchNode fromNode = (MarsSearchNode) s;
		
		if (!fromNode.node.equals(target.getPosition()))
			return false;
		
		return ((MarsSearchNode) s).currentEnergy >= 2;
	}
}