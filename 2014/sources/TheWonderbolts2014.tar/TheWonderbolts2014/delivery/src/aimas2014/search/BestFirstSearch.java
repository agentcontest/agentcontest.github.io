package aimas2014.search;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;

import aimas2014.environment.MarsNode;
import aimas2014.goals.GotoNodeGoal;
import aimas2014.planning.AgentPlan;
import aimas2014.search.actions.ActionType;
import aimas2014.search.actions.ActionType.InstantiatedAction;
import aimas2014.search.actions.GotoAction;
import aimas2014.search.actions.MoveActionNoEnergy;
import aimas2014.search.actions.RechargeAction;
import aimas2014.search.actions.VisitNodeAction;


public class BestFirstSearch {
    
    public static final class EnergyComparator implements Comparator<SearchNodeType> {
		@Override
		public int compare(SearchNodeType o1, SearchNodeType o2) {
			MarsSearchNode p1 = (MarsSearchNode) o1;
			MarsSearchNode p2 = (MarsSearchNode) o2;
			
			return Integer.compare(p1.totalEnergySpent, p2.totalEnergySpent);
		}
	}

	public static final class StepComparator implements Comparator<SearchNodeType> {
		@Override
		public int compare(SearchNodeType o1, SearchNodeType o2) {
			MarsSearchNode p1 = (MarsSearchNode) o1;
			MarsSearchNode p2 = (MarsSearchNode) o2;
			
			int stepResult = Integer.compare(p1.steps, p2.steps);
			
			return ((0 == stepResult) ? Integer.compare(p1.totalEnergySpent, p2.totalEnergySpent) : stepResult);
		}
	}

	final static public class Solution {
        public final SearchNodeType initialNode;
        public final SearchNodeType terminalNode;
        
        public Solution(SearchNodeType initialNode, SearchNodeType terminalNode) {
            super();
            this.initialNode = initialNode;
            this.terminalNode = terminalNode;
        }
        
        public boolean sound() {
        	return null != initialNode && null != terminalNode;
        }
    }
    
    public static AgentPlan reconstructPlan(Solution solution) {
        if (!solution.sound()) {
            return new AgentPlan(new ArrayList<InstantiatedAction>(), solution.initialNode, solution.terminalNode);
        }
        
        List<InstantiatedAction> reverseSolution = new ArrayList<>();

        SearchNodeType node = solution.terminalNode;

        while (null != node.parentNode) {
            reverseSolution.add(node.parentAction);
            node = node.parentNode;
        }

        Collections.reverse(reverseSolution);

        return new AgentPlan(reverseSolution, solution.initialNode, solution.terminalNode);
    }
        
    public static Solution plan(SearchNodeType initial, List<ActionType> actions, GoalConditionType goal, Comparator<SearchNodeType> heuristic) {
        Queue<SearchNodeType> openSet = new PriorityQueue<>(1, heuristic);
        Set<SearchNodeType> closedSet = new HashSet<>();
        
        openSet.add(initial);
        
        while (!openSet.isEmpty()) {
            SearchNodeType s = openSet.poll().expand();
            
            if (goal.suceeded(s)) {
                return new Solution(initial, s);
            }
            
            closedSet.add(s);
            
            for (ActionType a : actions) {
            	List<InstantiatedAction> children = a.instantiations(s);
                
                for (InstantiatedAction ia: children) {
                	if (ia.isApplicable(s)) {
                	
	                    SearchNodeType child = ia.apply(s);
	                    
	                    child.parentNode = s;
	                    child.parentAction = ia;
	
	                    if (closedSet.contains(child) || openSet.contains(child)) {
	                        continue;
	                    }
	                    
	                    
	                    openSet.add(child);                        
	                }
                }
            }
        }
        
        return new Solution(initial, null);
    }
    
    public static Solution plan(SearchNodeType initial, List<ActionType> actions, GoalConditionType goal) {
        return plan(initial, actions, goal, new StepComparator());
    }
    
    public static Solution findNearestNodes(final MarsNode fromNode, final MarsNodePredicate predicate, final int goalCount) {
    	GoalConditionType g = new GoalConditionType() {
    		
    		@Override
    		public boolean suceeded(SearchNodeType s) {
    			return s instanceof VisitNode && goalCount == ((VisitNode) s).visits.size();
    		}
    	};
    	
    	Comparator<SearchNodeType> h = new Comparator<SearchNodeType>() {
    		@Override
    		public int compare(SearchNodeType o1, SearchNodeType o2) {
    			final VisitNode p1 = (VisitNode) o1;
    			final VisitNode p2 = (VisitNode) o2;
    			
    			int stepResult = Integer.compare(p1.steps, p2.steps);
    			
    			return ((0 == stepResult) ? Integer.compare(p1.energySpent, p2.energySpent) : stepResult);
    		}
    	};
    	
    	List<ActionType> actionLibrary = new ArrayList<>();
        
    	actionLibrary.add(new VisitNodeAction());
    	
    	VisitNode initial = new VisitNode(fromNode, predicate);
        
        return plan(initial, actionLibrary, g, h);
    }
    
    public static Solution lowestEnergyPath(MarsNode from, MarsNode to) {
        List<ActionType> actionLibrary = new ArrayList<>();
        
        actionLibrary.add(new MoveActionNoEnergy());
        
        MarsSearchNode initial = new MarsSearchNode(from, 0, 0);
        
        return plan(initial, actionLibrary, new GotoNodeGoal(to), new EnergyComparator());
    }
    
    public static Solution shortestMovePath(MarsNode from, MarsNode to, int currentEnergy, int maxEnergy) {
        List<ActionType> actionLibrary = new ArrayList<>();
        
        actionLibrary.add(new GotoAction());
        actionLibrary.add(new RechargeAction());
        
        MarsSearchNode initial = new MarsSearchNode(from, currentEnergy, maxEnergy);
        
        return plan(initial, actionLibrary, new GotoNodeGoal(to), new StepComparator());
    }
    
    public static AgentPlan shortestMovePlan(MarsNode from, MarsNode to, int currentEnergy, int maxEnergy) {     
        return reconstructPlan(shortestMovePath(from, to, currentEnergy, maxEnergy));
    }
    
    public static AgentPlan lowestEnergyPlan(MarsNode from, MarsNode to) {     
        return reconstructPlan(lowestEnergyPath(from, to));
    }
}
