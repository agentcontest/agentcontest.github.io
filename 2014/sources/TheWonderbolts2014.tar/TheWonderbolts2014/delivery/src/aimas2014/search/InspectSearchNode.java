package aimas2014.search;

import aimas2014.environment.MarsNode;

public class InspectSearchNode extends MarsSearchNode {

	boolean nodeInspected = false;

	public InspectSearchNode(MarsNode newNode, int currentEnergy, int maxEnergy) {
		super(newNode, currentEnergy, maxEnergy);
	}
	
	public InspectSearchNode(MarsSearchNode parent) {
		super(parent);
	}
	
    public InspectSearchNode inspected() {
    	nodeInspected = true;
    	
    	return this;
    }
    
    @Override
    public SearchNodeType copy() {
    	InspectSearchNode cp = ((InspectSearchNode) super.copy());
    	
    	cp.nodeInspected = nodeInspected;
    	
    	return cp;
    }
}
