package aimas2014.search.instantiations;

import massim.javaagents.agents.MarsUtil;
import aimas2014.search.MarsSearchNode;
import aimas2014.search.SearchNodeType;
import aimas2014.search.actions.ActionType.InstantiatedAction;
import eis.iilang.Action;

public final class InstantiatedProbeAction extends InstantiatedAction {
    @Override
    public Action realize() {
        return MarsUtil.probeAction();
    }

    @Override
    public SearchNodeType apply(SearchNodeType s) {
        return ((MarsSearchNode) s.copy()).step().cost(1).probed();
    }

    @Override
    public int hashCode() {
        return "probe".hashCode();
    }
    
    @Override
    public boolean equals(Object obj) {
    	return obj instanceof InstantiatedProbeAction;
    }

	@Override
	public boolean isApplicable(SearchNodeType s) {
		MarsSearchNode fromNode = (MarsSearchNode) s;
		
		return !fromNode.nodeProbed && fromNode.currentEnergy >= 1;
	}
}