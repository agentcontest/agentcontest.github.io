package aimas2014.search.actions;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

import aimas2014.environment.MarsNode;
import aimas2014.search.SearchNodeType;
import aimas2014.search.VisitNode;
import eis.iilang.Action;

public class VisitNodeAction extends ActionType {

	public static class InstantiatedVisitNodeAction extends InstantiatedAction {

		private final MarsNode toNode;
		private final int edgeCost;
		
		public InstantiatedVisitNodeAction(MarsNode toNode, int edgeCost) {
			this.toNode = toNode;
			this.edgeCost = edgeCost;
		}
		
		@Override
		public Action realize() {
			return null;
		}

		@Override
		public SearchNodeType apply(SearchNodeType s) {
			VisitNode newNode = new VisitNode((VisitNode) s, toNode);
			
			newNode.energySpent += edgeCost;
			
			return newNode;
		}

		@Override
		public int hashCode() {
			return toNode.hashCode();
		}

		@Override
		public boolean equals(Object obj) {
			return obj instanceof InstantiatedVisitNodeAction && toNode.equals(((InstantiatedVisitNodeAction) obj).toNode);
		}

		@Override
		public boolean isApplicable(SearchNodeType s) {
			return true;
		}
	}
	

	@Override
	public List<InstantiatedAction> instantiations(SearchNodeType s) {
		VisitNode v = (VisitNode) s;
		List<InstantiatedAction> result = new ArrayList<>();
		
		for (Entry<MarsNode, Integer> neighbour : v.node.getNeighbours()) {
            MarsNode neighbourNode = neighbour.getKey();
            Integer edgeCost = neighbour.getValue();
            
            if (MarsNode.UNKNOWN_EDGE_WEIGHT == edgeCost)
                continue;
            
            result.add(new InstantiatedVisitNodeAction(neighbourNode, edgeCost));
        }
		
		return result;
	}
	
}