package aimas2014.search;

import aimas2014.search.actions.ActionType.InstantiatedAction;

public abstract class SearchNodeType  {
    public SearchNodeType parentNode;
    public InstantiatedAction parentAction;
    
    public SearchNodeType() {}
    
    @Override
    public abstract boolean equals(Object obj);
    
    @Override
    public abstract int hashCode();
    
    public abstract SearchNodeType copy();
    
    public SearchNodeType expand() {
    	return this;
    }
}