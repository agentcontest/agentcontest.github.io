package aimas2014.search;

import java.util.ArrayList;
import java.util.List;

import aimas2014.environment.MarsNode;

public class VisitNode extends SearchNodeType {

	public final MarsNode prevNode;
	public final MarsNode node;
	public final List<VisitNode> visits;
	public final int steps;
	public int energySpent;
	public final MarsNodePredicate predicate;
	
	public VisitNode(VisitNode parent, MarsNode newNode) {
		this.prevNode = parent.node;
		this.node = newNode;
		this.visits = parent.visits;
		this.steps = parent.steps + 1;
		this.energySpent = parent.energySpent;
		this.predicate = parent.predicate;
	}
	
	public VisitNode(MarsNode initial, MarsNodePredicate predicate) {
		this.prevNode = null;
		this.node = initial;
		this.steps = 0;
		this.energySpent = 0;
		this.visits = new ArrayList<>();
		this.predicate = predicate;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj instanceof VisitNode) {
			VisitNode other = (VisitNode) obj;
			
			return node.equals(other.node) && (prevNode == null ? true : prevNode.equals(other.prevNode));
		}
		
		return false;
	}

	@Override
	public int hashCode() {
		return node.hashCode();
	}
	
	@Override
	public String toString() {
		return String.format("VisitNode(%s)", node.name);
	}
	
	@Override
	public SearchNodeType expand() {
		if (predicate.test(node))
			visits.add(this);
		
		return super.expand();
	}

	@Override
	public SearchNodeType copy() {
		return null;
	}
}