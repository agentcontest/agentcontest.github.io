package aimas2014.search.actions;

import java.util.List;

import aimas2014.search.SearchNodeType;
import eis.iilang.Action;

public abstract class ActionType {
    
    public abstract static class InstantiatedAction {
        public abstract Action realize();
        
        public abstract <T extends SearchNodeType> SearchNodeType apply(SearchNodeType s);
        public abstract boolean isApplicable(SearchNodeType s);
        
        public abstract int hashCode();
        public abstract boolean equals(Object obj);
    }
    
    public abstract List<InstantiatedAction> instantiations(SearchNodeType s);
    
    @Override
    public boolean equals(Object obj) {
    	return obj.getClass().equals(this.getClass());
    }

	@Override
	public int hashCode() {
		return super.hashCode();
	}
}