package aimas2014.search;



public abstract class GoalConditionType {
    public abstract boolean suceeded(SearchNodeType s);
    public boolean impossible(SearchNodeType s) { return false; }
    public boolean reconsider(SearchNodeType s) { return false; }
}

