package aimas2014.search;

import aimas2014.environment.MarsNode;

public class BFSSearch {

    public BFSSearch() {
    }

    class SearchNode {
        SearchNode parentNode;
        MarsNode node;

        public SearchNode(SearchNode parentNode, MarsNode node) {
            this.parentNode = parentNode;
            this.node = node;
        }
    }

//    public List<MarsNode> search(MarsNode from, Predicate predicate) {
//        Set<MarsNode> closedSet = new HashSet<>();
//        Queue<SearchNode> openSet = new ArrayDeque<>();
//
//        openSet.add(new SearchNode(null, from));
//
//        while (!openSet.isEmpty()) {
//            SearchNode currentNode = openSet.poll();
//
//            closedSet.add(currentNode.node);
//
//            if (predicate.call(currentNode.node)) {
//                ArrayList<MarsNode> reverseSolution = new ArrayList<>();
//
//                SearchNode solutionNode = currentNode;
//
//                while (solutionNode.node != from) {
//                    reverseSolution.add(solutionNode.node);
//                    solutionNode = solutionNode.parentNode;
//                }
//
//                Collections.reverse(reverseSolution);
//
//                return reverseSolution;
//            }
//
//            for (Entry<MarsNode, Integer> neighbour : currentNode.node.getNeighbours()) {
//                if (!closedSet.contains(neighbour)) {
//                    openSet.add(new SearchNode(currentNode, neighbour.getKey()));
//                }
//            }
//        }
//
//        return null;
//    }
//
//    public List<MarsNode> searchForNode(MarsNode from, MarsNode to) {
//        return search(from, new TargetNodePredicate(to));
//    }
//
//    public List<MarsNode> searchForNearestUnexploredNode(MarsNode from) {
//        return search(from, new UnexploredNodePredicate());
//    }
}
