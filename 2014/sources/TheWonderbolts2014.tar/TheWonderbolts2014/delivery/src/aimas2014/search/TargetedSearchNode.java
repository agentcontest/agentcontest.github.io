package aimas2014.search;

import aimas2014.agents.PositionedEntity;
import aimas2014.environment.MarsNode;

public class TargetedSearchNode extends MarsSearchNode {

	public final PositionedEntity target;

	public TargetedSearchNode(MarsNode newNode, int currentEnergy, int maxEnergy, PositionedEntity target) {
		super(newNode, currentEnergy, maxEnergy);
		
		this.target = target;
	}
	
	public TargetedSearchNode(MarsSearchNode parent, PositionedEntity target) {
		super(parent);
		
		this.target = target;
	}
    
    @Override
    public SearchNodeType copy() {
    	return new TargetedSearchNode(this, target);
    }
    
    @Override
    public String toString() {
    	return String.format("%s (a=%b, i=%b)", node.name, nodeAttacked, nodeInspected);
    }
}
