package aimas2014.search.actions;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

import aimas2014.environment.MarsNode;
import aimas2014.search.MarsSearchNode;
import aimas2014.search.SearchNodeType;
import aimas2014.search.instantiations.InstantiatedGotoActionNoEnergy;

public class MoveActionNoEnergy extends ActionType {
    
    @Override
    public List<ActionType.InstantiatedAction> instantiations(SearchNodeType s) {
        List<InstantiatedAction> result = new ArrayList<>();
        
        MarsSearchNode fromNode = (MarsSearchNode) s;
        
        for (Entry<MarsNode, Integer> neighbour : fromNode.node.getNeighbours()) {
            MarsNode neighbourNode = neighbour.getKey();
            Integer edgeCost = neighbour.getValue();
            
            InstantiatedGotoActionNoEnergy instantiatedAction = new InstantiatedGotoActionNoEnergy(neighbourNode, edgeCost);

            if (instantiatedAction.isApplicable(s))
            	result.add(instantiatedAction);
        }
        
        return result;
    }
    
}