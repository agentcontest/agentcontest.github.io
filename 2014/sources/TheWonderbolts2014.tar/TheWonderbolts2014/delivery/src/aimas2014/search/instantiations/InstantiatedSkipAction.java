package aimas2014.search.instantiations;

import massim.javaagents.agents.MarsUtil;
import aimas2014.search.MarsSearchNode;
import aimas2014.search.SearchNodeType;
import aimas2014.search.actions.ActionType.InstantiatedAction;
import eis.iilang.Action;

public class InstantiatedSkipAction extends InstantiatedAction {
    @Override
    public Action realize() {
        return MarsUtil.skipAction();
    }

    @Override
    public SearchNodeType apply(SearchNodeType s) {
    	return ((MarsSearchNode) s.copy()).step().cost(0);
    }

    @Override
    public int hashCode() {
        return "skip".hashCode();
    }
    
    @Override
    public boolean equals(Object obj) {
    	return obj instanceof InstantiatedSkipAction;
    }

	@Override
	public boolean isApplicable(SearchNodeType s) {
		return true;
	}
}