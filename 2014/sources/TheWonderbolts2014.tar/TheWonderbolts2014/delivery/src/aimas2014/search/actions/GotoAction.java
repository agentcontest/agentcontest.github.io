package aimas2014.search.actions;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

import aimas2014.environment.MarsNode;
import aimas2014.search.MarsSearchNode;
import aimas2014.search.SearchNodeType;
import aimas2014.search.instantiations.InstantiatedGotoAction;

public class GotoAction extends ActionType {
	
	private final int costUnsurveyedEdge;
	
	public GotoAction(int costUnsurveyedEdge) {
		this.costUnsurveyedEdge = MarsNode.UNKNOWN_EDGE_WEIGHT;
	}
	
	public GotoAction() {
		this(MarsNode.UNKNOWN_EDGE_WEIGHT);
	}
    
    @Override
    public List<ActionType.InstantiatedAction> instantiations(SearchNodeType s) {
        List<InstantiatedAction> result = new ArrayList<>();
        
        for (Entry<MarsNode, Integer> neighbour : ((MarsSearchNode) s).node.getNeighbours()) {
            MarsNode neighbourNode = neighbour.getKey();
            Integer edgeCost = neighbour.getValue();
            
            if (MarsNode.UNKNOWN_EDGE_WEIGHT == edgeCost && MarsNode.UNKNOWN_EDGE_WEIGHT != costUnsurveyedEdge)
                edgeCost = costUnsurveyedEdge;
            
            if (MarsNode.UNKNOWN_EDGE_WEIGHT == edgeCost)
            	continue;

            result.add(new InstantiatedGotoAction(neighbourNode, edgeCost));
        }
        
        return result;
    }
    
}