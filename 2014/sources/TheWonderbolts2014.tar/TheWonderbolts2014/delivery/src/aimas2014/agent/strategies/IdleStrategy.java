package aimas2014.agent.strategies;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import aimas2014.goals.IdleGoal;
import aimas2014.goals.WeightedDesire;
import aimas2014.goals.WeightedDesire.CategoryTag;
import aimas2014.goals.WeightedDesire.SourceTag;
import aimas2014.planning.LocalBeliefs;

public class IdleStrategy extends AgentStrategy {
	
	@Override
	public List<WeightedDesire> options(LocalBeliefs beliefs) {
		List<WeightedDesire> result = super.options(beliefs);
		
		result.add(new WeightedDesire(new IdleGoal(), CategoryTag.UTILITY, SourceTag.LOCAL, 0.0f));
		
		return result;
	}
	
	@Override
	public Collection<WeightedDesire> filter(Collection<WeightedDesire> desires) {
		List<WeightedDesire> results = new ArrayList<WeightedDesire>(desires.size());
		
		for (WeightedDesire wd: desires) {
			if (SourceTag.LOCAL == wd.source)
				results.add(wd);
		}
		
		if (0 == results.size())
			return desires;
		
		return results;
	}
}
