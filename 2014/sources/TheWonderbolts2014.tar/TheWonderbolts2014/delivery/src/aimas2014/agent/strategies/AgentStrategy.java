package aimas2014.agent.strategies;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import aimas2014.goals.WeightedDesire;
import aimas2014.planning.AgentGoal;
import aimas2014.planning.LocalBeliefs;
import aimas2014.search.actions.ActionType;

public abstract class AgentStrategy {

    public float normalizedWeight(LocalBeliefs beliefs, WeightedDesire desire) {
    	return desire.priority.getValue();
    }
    
    public List<WeightedDesire> sortDesires(final LocalBeliefs beliefs, List<WeightedDesire> desires) {
        
        Collections.sort(desires, new Comparator<WeightedDesire>() {

			@Override
			public int compare(WeightedDesire o1, WeightedDesire o2) {
				return -Float.compare(normalizedWeight(beliefs, o1), normalizedWeight(beliefs, o2));
			}
		});
        
        return desires;
    }
    
    public List<WeightedDesire> options(LocalBeliefs beliefs) {
		return new ArrayList<>();
	}
    
    public Collection<WeightedDesire> filter(Collection<WeightedDesire> desires) {
		return desires;
	}
    
    public List<AgentGoal> intentions(LocalBeliefs beliefs, Collection<ActionType> actionLibrary, List<WeightedDesire> desires) {
    	List<AgentGoal> results = new ArrayList<>();
    	
    	sortDesires(beliefs, desires);

    	for (WeightedDesire wd: desires)
    	{
    		if (actionLibrary.containsAll(wd.goal.actionsRequired())) {
    			results.add(wd.goal);
    			
    			break;
    		}
    	}

		return results;
	}
    
    
}
