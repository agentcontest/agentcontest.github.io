package aimas2014.agent.strategies;

import java.util.List;

import aimas2014.goals.WeightedDesire;
import aimas2014.goals.WeightedDesire.CategoryTag;
import aimas2014.goals.WeightedDesire.SourceTag;
import aimas2014.planning.LocalBeliefs;
import aimas2014.setup.Config;

public class DefaultSentinelStrategy extends DefaultStrategy {

	@Override
	public float normalizedWeight(LocalBeliefs beliefs, WeightedDesire desire) {
		float w = desire.priority.getValue();
		
		if (beliefs.globalBeliefs.agentStep < (int) Config.get("SENTINEL_LOCAL_DESIRE_PRIORITY_UNTIL", 50.0))
			w *= (desire.source == SourceTag.LOCAL ? (float) Config.get("SENTINEL_LOCAL_DESIRE_PRIORITY_FACTOR", 1.5) : 1.0f);
		
		w *= (desire.source == SourceTag.LOCAL && desire.category == CategoryTag.DEFENSIVE ? (float) Config.get("SENTINEL_LOCAL_DEFENSIVE_FACTOR", 20.0) : 1.0f);
		
		return w;
	}
	
	@Override
	public List<WeightedDesire> options(LocalBeliefs beliefs) {
		return super.options(beliefs);
	}
	
	

}
