package aimas2014.agent.strategies;

import java.util.ArrayList;
import java.util.List;


public class CombinedStrategy extends AgentStrategy {

    public final List<AgentStrategy> strategies = new ArrayList<AgentStrategy>(); 
    
    public CombinedStrategy(final List<AgentStrategy> strategies) {
    	
        for (AgentStrategy strategy: strategies)
            this.strategies.add(strategy);
    }
}
