package aimas2014.agent.strategies;

import java.util.Collection;
import java.util.List;

import aimas2014.agents.AIMASAgent;
import aimas2014.agents.AIMASEnemyAgent;
import aimas2014.environment.MarsNode;
import aimas2014.environment.MarsNodePath;
import aimas2014.goals.GotoNodeGoal;
import aimas2014.goals.IdleGoal;
import aimas2014.goals.ParryGoal;
import aimas2014.goals.SurveyNodeGoal;
import aimas2014.goals.WeightedDesire;
import aimas2014.goals.WeightedDesire.CategoryTag;
import aimas2014.goals.WeightedDesire.SourceTag;
import aimas2014.planning.LocalBeliefs;
import aimas2014.search.BestFirstSearch;
import aimas2014.search.BestFirstSearch.Solution;
import aimas2014.search.MarsNodePredicate;
import aimas2014.search.VisitNode;

public class DefaultStrategy extends AgentStrategy {
	
	@Override
	public List<WeightedDesire> options(LocalBeliefs beliefs) {
		List<WeightedDesire> result = super.options(beliefs);
		
		result.add(new WeightedDesire(new IdleGoal(), CategoryTag.UTILITY, SourceTag.LOCAL, 0.0f));
		
		Solution sol = BestFirstSearch.findNearestNodes(beliefs.position, new MarsNodePredicate() {
			
			@Override
			public boolean test(MarsNode node) {
				return !node.allEdgesSurveyed();
			}
		}, beliefs.map.numUnsurveyedNodes());
		
		for (VisitNode node: ((VisitNode) sol.initialNode).visits) {
			float factor = 0.1f / Math.max(1.0f, node.steps);
		
			result.add(new WeightedDesire(new SurveyNodeGoal(node.node), CategoryTag.UTILITY, SourceTag.LOCAL, factor));
		}
		
		boolean inDanger = false;
		for (AIMASEnemyAgent e: beliefs.globalBeliefs.opponentAgents.values()) {
			if (!e.type.equals("Saboteur"))
				continue;
			
			MarsNodePath p = beliefs.map.path(beliefs.position, e.position);
			
			if (null == p)
				continue;
			
			if (p.searchPath.size() <= 1)
				inDanger = true;
		}

		if (inDanger && beliefs.role.equals("Sentinel"))
			result.add(new WeightedDesire(new ParryGoal(), CategoryTag.DEFENSIVE, SourceTag.LOCAL, 1.0f));
		
		if (0 == beliefs.health) {
			int minDist = Integer.MAX_VALUE;
			AIMASAgent closestRepairer = null;
			
			for (AIMASAgent a: beliefs.globalBeliefs.agents.values()) {
				if (!a.beliefs.name.equals(beliefs.name) || !a.beliefs.role.equals("Repairer")) 
					continue;
				
				MarsNodePath p = beliefs.map.path(beliefs.position, a.beliefs.position);
				
				if (null == p)
					continue;
				
				int dist = p.energy;
				
				if (dist < minDist) {
					closestRepairer = a;
					minDist = dist;
				}
					
			}
			
			if (null != closestRepairer)
				result.add(new WeightedDesire(new GotoNodeGoal(closestRepairer.beliefs.position), CategoryTag.DEFENSIVE, SourceTag.LOCAL, 1.0f));
		}
		
		return result;
	}
	
	@Override
	public float normalizedWeight(LocalBeliefs beliefs, WeightedDesire desire) {
		return super.normalizedWeight(beliefs, desire);// * ((desire.source == SourceTag.LOCAL && desire.category == CategoryTag.DEFENSIVE) ? 0.1f : 1.0f);
	}
	
	@Override
	public Collection<WeightedDesire> filter(Collection<WeightedDesire> desires) {
		return desires;
	}
}
