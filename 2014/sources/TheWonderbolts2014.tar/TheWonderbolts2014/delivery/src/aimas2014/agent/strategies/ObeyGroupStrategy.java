package aimas2014.agent.strategies;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import aimas2014.goals.WeightedDesire;
import aimas2014.goals.WeightedDesire.SourceTag;

public class ObeyGroupStrategy extends DefaultStrategy {

	@Override
	public Collection<WeightedDesire> filter(Collection<WeightedDesire> desires) {
		List<WeightedDesire> results = new ArrayList<WeightedDesire>(desires.size());
		
		for (WeightedDesire wd: desires) {
			if (SourceTag.GROUP == wd.source)
				results.add(wd);
		}
		
		if (0 == results.size())
			return desires;
		
		return results;
	}
}
