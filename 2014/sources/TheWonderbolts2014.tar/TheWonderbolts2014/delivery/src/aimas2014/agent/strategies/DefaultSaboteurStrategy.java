package aimas2014.agent.strategies;

import java.util.List;

import aimas2014.goals.WeightedDesire;
import aimas2014.goals.WeightedDesire.CategoryTag;
import aimas2014.planning.LocalBeliefs;
import aimas2014.setup.Config;

public class DefaultSaboteurStrategy extends DefaultStrategy {

	@Override
	public float normalizedWeight(LocalBeliefs beliefs, WeightedDesire desire) {
		float w = super.normalizedWeight(beliefs, desire);
		
		return w * (desire.category == CategoryTag.OFFENSIVE ? (float) Config.get("SABOTEUR_OFFENSIVE_DESIRE_FACTOR", 1.5) : 1.0f);
	}
	
	@Override
	public List<WeightedDesire> options(LocalBeliefs beliefs) {
		List<WeightedDesire> desires = super.options(beliefs);
		
//		List<Pair<AIMASEnemyAgent, Integer>> enemyAgents = new ArrayList<>();
//		
//		for (AIMASEnemyAgent ea: beliefs.globalBeliefs.opponentAgents.values()) {
//			if (ea.status.equals("normal")) {
//				enemyAgents.add(Pair.with(ea, beliefs.map.distance(beliefs.position, ea.position)));
//			}
//		}
//		
//		Collections.sort(enemyAgents, new Comparator<Pair<AIMASEnemyAgent, Integer>>() {
//
//			@Override
//			public int compare(Pair<AIMASEnemyAgent, Integer> o1, Pair<AIMASEnemyAgent, Integer> o2) {
//				return o1.getValue1().compareTo(o2.getValue1());
//			}
//		});
//
//		if (enemyAgents.size() > 0 && beliefs.map.UNKNOWN_DISTANCE != enemyAgents.get(0).getValue1()) {
//			desires.add(new WeightedDesire(new AttackAgentGoal(enemyAgents.get(0).getValue0()), CategoryTag.OFFENSIVE, SourceTag.LOCAL, new PriorityTag(0.8f)));
//		}
		
		return desires;
	}
	
	

}
