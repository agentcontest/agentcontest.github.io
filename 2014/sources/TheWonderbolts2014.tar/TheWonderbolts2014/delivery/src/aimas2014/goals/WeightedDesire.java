package aimas2014.goals;

import aimas2014.planning.AgentGoal;

public class WeightedDesire {
	public static enum SourceTag {
		LOCAL, GROUP, GLOBAL
	}
	
	public static enum CategoryTag {
        OFFENSIVE, DEFENSIVE, UTILITY, OTHER
    }
	
	public static class PriorityTag {
	    public final float priority;
	    
	    public static enum PredefinedPriority {
	        NONE(0), LOW(63), MED(127), HIGH(255);
	        
	        public final int priority;

	        private PredefinedPriority(int priority) {
	            this.priority = priority;
	        }
	        
	        public float getPriority() {
	            return (float) priority / 255;
	        }
	    }

        public PriorityTag(float priority) {
            this.priority = priority;
        }
	    
        public PriorityTag(PredefinedPriority priority) {
            this.priority = priority.getPriority();
        }
        
        public float getValue() {
            return priority;
        }
	}
    
    public final AgentGoal goal;
    
    public final CategoryTag category;
    public final SourceTag source;
    public final PriorityTag priority;
    
    public WeightedDesire(AgentGoal goal, CategoryTag category, SourceTag source, PriorityTag priority) {
        this.goal = goal;
        this.category = category;
        this.source = source;
        this.priority = priority;
    }
    
    public WeightedDesire(AgentGoal goal, CategoryTag category, SourceTag source, float priority) {
        this(goal, category, source, new PriorityTag(priority));
    }
    
    @Override
    public String toString() {
    	return String.format("%s (%s, %s, %.02f)", goal, category, source, priority.getValue());
    }
    
}