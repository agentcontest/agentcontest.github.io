package aimas2014.goals;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import aimas2014.environment.MarsNode;
import aimas2014.planning.AgentGoal;
import aimas2014.planning.AgentPlan;
import aimas2014.planning.LocalBeliefs;
import aimas2014.search.BestFirstSearch;
import aimas2014.search.MarsSearchNode;
import aimas2014.search.SearchNodeType;
import aimas2014.search.actions.ActionType;

public class FindNodeGoal extends AgentGoal {
    MarsNode targetNode;

    public FindNodeGoal(MarsNode targetNode) {
        super();
        this.targetNode = targetNode;
    }

    @Override
    public boolean suceeded(SearchNodeType s) {
        return ((MarsSearchNode) s).node.equals(targetNode);
    }

	@Override
	public AgentPlan producePlan(LocalBeliefs beliefs, List<ActionType> actionLibrary) {
		return BestFirstSearch.lowestEnergyPlan(beliefs.position, targetNode);
	}
	
	private final static Set<ActionType> actionsRequired = new HashSet<>();

	@Override
	public Set<ActionType> actionsRequired() {
		return actionsRequired;
	}
}