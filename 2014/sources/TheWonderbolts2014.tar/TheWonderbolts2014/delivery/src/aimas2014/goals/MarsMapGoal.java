package aimas2014.goals;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import aimas2014.planning.AgentGoal;
import aimas2014.planning.AgentPlan;
import aimas2014.planning.LocalBeliefs;
import aimas2014.search.BestFirstSearch;
import aimas2014.search.BestFirstSearch.Solution;
import aimas2014.search.BestFirstSearch.StepComparator;
import aimas2014.search.MarsSearchNode;
import aimas2014.search.actions.ActionType;

public abstract class MarsMapGoal extends AgentGoal {

	@Override
	public AgentPlan producePlan(LocalBeliefs beliefs, List<ActionType> actionLibrary) {
		MarsSearchNode initial = new MarsSearchNode(beliefs.position, beliefs.energy, beliefs.maxEnergy);

		Solution sol = BestFirstSearch.plan(initial, actionLibrary, this, new StepComparator());
		
		if (!sol.sound()) {
			System.err.println("Failed to produce plan for: " + this.toString());
		}

		return BestFirstSearch.reconstructPlan(sol);
	}

	private final static Set<ActionType> defaultActionsRequired = new HashSet<>();

	@Override
	public Set<ActionType> actionsRequired() {
		return defaultActionsRequired;
	}
}
