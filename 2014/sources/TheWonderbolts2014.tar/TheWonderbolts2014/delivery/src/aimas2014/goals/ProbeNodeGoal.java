package aimas2014.goals;

import java.util.HashSet;
import java.util.Set;

import aimas2014.environment.MarsNode;
import aimas2014.search.MarsSearchNode;
import aimas2014.search.SearchNodeType;
import aimas2014.search.actions.ActionType;
import aimas2014.search.actions.ProbeAction;

public class ProbeNodeGoal extends TargetedMarsMapGoal {

    public ProbeNodeGoal(MarsNode targetNode) {
        super(targetNode);
    }

    @Override
    public boolean suceeded(SearchNodeType s) {
        if (!(s instanceof MarsSearchNode))
            return false;
        
        MarsSearchNode n = (MarsSearchNode) s;
        
        return n.node.equals(target.getPosition()) && n.nodeProbed;
    }

	private final static Set<ActionType> actionsRequired = new HashSet<>();

	@Override
	public Set<ActionType> actionsRequired() {
		if (0 == actionsRequired.size()) {
			actionsRequired.addAll(super.actionsRequired());
			actionsRequired.add(new ProbeAction());
		}
		
		return actionsRequired;
	}
}