package aimas2014.goals;

import aimas2014.environment.MarsNode;
import aimas2014.search.MarsSearchNode;
import aimas2014.search.SearchNodeType;

public class GotoNodeGoal extends MarsMapGoal {
    public final MarsNode targetNode;

    public GotoNodeGoal(MarsNode targetNode) {
        super();
        this.targetNode = targetNode;
    }

    @Override
    public boolean suceeded(SearchNodeType s) {
        return ((MarsSearchNode) s).node.equals(targetNode);
    }
}