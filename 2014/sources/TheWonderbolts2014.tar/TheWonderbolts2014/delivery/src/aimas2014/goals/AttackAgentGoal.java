package aimas2014.goals;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import aimas2014.agents.AIMASEnemyAgent;
import aimas2014.planning.AgentPlan;
import aimas2014.planning.LocalBeliefs;
import aimas2014.search.SearchNodeType;
import aimas2014.search.TargetedSearchNode;
import aimas2014.search.actions.ActionType;
import aimas2014.search.actions.AttackAction;

public class AttackAgentGoal extends TargetedMarsMapGoal {

	public AttackAgentGoal(AIMASEnemyAgent target) {
		super(target);
	}

	@Override
	public boolean suceeded(SearchNodeType s) {
		TargetedSearchNode n = (TargetedSearchNode) s;
        
        return n.node.equals(target.getPosition()) && n.nodeAttacked;
	}
	
	@Override
	public AgentPlan producePlan(LocalBeliefs beliefs, List<ActionType> actionLibrary) {
		return super.producePlan(beliefs, actionLibrary);
	}

	private final static Set<ActionType> actionsRequired = new HashSet<>();

	@Override
	public Set<ActionType> actionsRequired() {
		if (0 == actionsRequired.size()) {
			actionsRequired.add(new AttackAction());
		}
		
		return actionsRequired;
	}
}
