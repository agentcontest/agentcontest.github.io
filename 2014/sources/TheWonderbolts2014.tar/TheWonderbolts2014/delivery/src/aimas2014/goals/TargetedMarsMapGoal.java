package aimas2014.goals;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import aimas2014.agents.PositionedEntity;
import aimas2014.planning.AgentGoal;
import aimas2014.planning.AgentPlan;
import aimas2014.planning.LocalBeliefs;
import aimas2014.search.BestFirstSearch;
import aimas2014.search.BestFirstSearch.Solution;
import aimas2014.search.BestFirstSearch.StepComparator;
import aimas2014.search.TargetedSearchNode;
import aimas2014.search.actions.ActionType;

public abstract class TargetedMarsMapGoal extends AgentGoal {

	protected final PositionedEntity target;
	
	public TargetedMarsMapGoal(PositionedEntity target) {
		super();
		this.target = target;
	}
	
	@Override
	public AgentPlan producePlan(LocalBeliefs beliefs, List<ActionType> actionLibrary) {
		TargetedSearchNode initial = new TargetedSearchNode(beliefs.position, beliefs.energy, beliefs.maxEnergy, target);
		
		Solution sol = BestFirstSearch.plan(initial, actionLibrary, this, new StepComparator());
		
		if (!sol.sound()) {
			System.err.println("Failed to produce plan for: " + this.toString());
		}
		
		return BestFirstSearch.reconstructPlan(sol);
	}

	private final static Set<ActionType> defaultActionsRequired = new HashSet<>();

	@Override
	public Set<ActionType> actionsRequired() {
		return defaultActionsRequired;
	}
}
