package aimas2014.goals;

import java.util.HashSet;
import java.util.Set;

import aimas2014.agents.AIMASAgent;
import aimas2014.search.SearchNodeType;
import aimas2014.search.TargetedSearchNode;
import aimas2014.search.actions.ActionType;
import aimas2014.search.actions.RepairAction;

public class RepairAgentGoal extends TargetedMarsMapGoal {

	public RepairAgentGoal(AIMASAgent target) {
		super(target);
	}

	@Override
	public boolean suceeded(SearchNodeType s) {
		TargetedSearchNode n = (TargetedSearchNode) s;
        
        return n.node.equals(target.getPosition()) && n.nodeRepaired;
	}

	private final static Set<ActionType> actionsRequired = new HashSet<>();

	@Override
	public Set<ActionType> actionsRequired() {
		if (0 == actionsRequired.size()) {
			actionsRequired.add(new RepairAction());
		}
		
		return actionsRequired;
	}
}
