package aimas2014.goals;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import aimas2014.planning.AgentGoal;
import aimas2014.planning.AgentPlan;
import aimas2014.planning.LocalBeliefs;
import aimas2014.search.SearchNodeType;
import aimas2014.search.actions.ActionType;
import aimas2014.search.instantiations.InstantiatedRechargeAction;

public class IdleGoal extends AgentGoal {

	private final static Set<ActionType> actionsRequired = new HashSet<>();
	
	@Override
	public boolean suceeded(SearchNodeType s) {
		return true;
	}

	@Override
	public AgentPlan producePlan(LocalBeliefs beliefs, List<ActionType> actionLibrary) {
		return new AgentPlan().append(new InstantiatedRechargeAction());
	}

	@Override
	public Set<ActionType> actionsRequired() {
		return actionsRequired;
	}
}
