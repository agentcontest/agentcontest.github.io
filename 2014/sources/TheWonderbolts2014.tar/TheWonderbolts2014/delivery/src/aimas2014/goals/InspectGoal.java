package aimas2014.goals;

import java.util.HashSet;
import java.util.Set;

import aimas2014.agents.AIMASEnemyAgent;
import aimas2014.search.SearchNodeType;
import aimas2014.search.TargetedSearchNode;
import aimas2014.search.actions.ActionType;
import aimas2014.search.actions.InspectAction;

public class InspectGoal extends TargetedMarsMapGoal {

    public InspectGoal(AIMASEnemyAgent agent) {
        super(agent);
    }

    @Override
    public boolean suceeded(SearchNodeType s) {
        if (!(s instanceof TargetedSearchNode))
            return false;
        
        TargetedSearchNode n = (TargetedSearchNode) s;
        if(!n.node.equals(n.target.getPosition()))
        	return false;
        
        if (!n.nodeInspected)
        	return false;

        return true;
    }
    
    private final static Set<ActionType> actionsRequired = new HashSet<>();

	@Override
	public Set<ActionType> actionsRequired() {
		if (0 == actionsRequired.size()) {
			actionsRequired.add(new InspectAction());
			actionsRequired.addAll(super.actionsRequired());
		}
		
		return actionsRequired;
	}
}