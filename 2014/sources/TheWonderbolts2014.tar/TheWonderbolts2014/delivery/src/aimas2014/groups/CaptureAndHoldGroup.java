package aimas2014.groups;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import aimas2014.agents.AIMASAgent;
import aimas2014.agents.AIMASEnemyAgent;
import aimas2014.agents.AIMASExplorerAgent;
import aimas2014.agents.AIMASInspectorAgent;
import aimas2014.agents.AIMASRepairerAgent;
import aimas2014.agents.AIMASSaboteurAgent;
import aimas2014.agents.AIMASSentinelAgent;
import aimas2014.environment.MarsNode;
import aimas2014.environment.MarsNodePath;
import aimas2014.goals.AttackAgentGoal;
import aimas2014.goals.GotoNodeGoal;
import aimas2014.goals.InspectGoal;
import aimas2014.goals.ProbeNodeGoal;
import aimas2014.goals.RepairAgentGoal;
import aimas2014.goals.WeightedDesire;
import aimas2014.goals.WeightedDesire.CategoryTag;
import aimas2014.goals.WeightedDesire.PriorityTag;
import aimas2014.goals.WeightedDesire.SourceTag;
import aimas2014.planning.Auction;
import aimas2014.planning.GlobalBeliefs;
import aimas2014.setup.Config;

public class CaptureAndHoldGroup extends AIMASGroup {

	public final Set<MarsNode> nodes;

	public final Set<AIMASSaboteurAgent> saboteurs = new HashSet<>();
	public final Set<AIMASRepairerAgent> repairers = new HashSet<>();
	public final Set<AIMASSentinelAgent> sentinels = new HashSet<>();
	public final Set<AIMASInspectorAgent> inspectors = new HashSet<>();
	public final Set<AIMASExplorerAgent> explorers = new HashSet<>();

	public CaptureAndHoldGroup(AIMASGroup parentGroup, GlobalBeliefs groupBeliefs, Set<MarsNode> nodes) {

		super(parentGroup, groupBeliefs);

		this.nodes = nodes;
	}
	
	public void addMember(AIMASAgent newMember) {
		if (newMember instanceof AIMASSaboteurAgent)
			saboteurs.add((AIMASSaboteurAgent) newMember);
		
		if (newMember instanceof AIMASRepairerAgent)
			repairers.add((AIMASRepairerAgent) newMember);
		
		if (newMember instanceof AIMASSentinelAgent)
			sentinels.add((AIMASSentinelAgent) newMember);
		
		if (newMember instanceof AIMASExplorerAgent)
			explorers.add((AIMASExplorerAgent) newMember);
		
		if (newMember instanceof AIMASInspectorAgent)
			inspectors.add((AIMASInspectorAgent) newMember);
		
		members.add(newMember);
	}
	
	public void addMembers(Collection<AIMASAgent> newMembers) {
		for (AIMASAgent a: newMembers) {
			addMember(a);
		}
	}

	public Set<AIMASEnemyAgent> visibleOpponents() {
		Collection<AIMASAgent> allMembers = allMembers();
		Set<AIMASEnemyAgent> result = new HashSet<>();

		for (AIMASAgent a : allMembers) {
			for (AIMASEnemyAgent e : globalBeliefs.opponentAgents.values()) {
				if (Math.abs(e.agentStepLastSeen - globalBeliefs.agentStep) > 1)
					continue;

				if (result.contains(e))
					continue;

				MarsNodePath path = globalBeliefs.map.path(a.beliefs.position, e.position);

				if (null == path)
					continue;

				int dist = path.searchPath.size() - 1;

				if (dist <= a.beliefs.visRange)
					result.add(e);
			}
		}

		return result;
	}

	public Set<MarsNode> neighboringNodes(Set<MarsNode> nodes) {
		Set<MarsNode> result = new HashSet<>();

		for (MarsNode n : nodes) {
			result.addAll(n.neighbours.keySet());
		}

		return result;
	}

	@Override
	public void propagateDesires(List<WeightedDesire> desires) {
		Set<AIMASEnemyAgent> visibleOpponents = visibleOpponents();

		List<AIMASAgent> placedAgents = new ArrayList<>();
		placedAgents.addAll(inspectors);
		placedAgents.addAll(sentinels);
		placedAgents.addAll(explorers);
		placedAgents.addAll(saboteurs);
		placedAgents.addAll(repairers);
		
		Map<AIMASInspectorAgent, AIMASEnemyAgent> inspectAuction = Auction.auction(inspectors, visibleOpponents,
				new InspectEnemyFunctor());
		
		Map<AIMASSaboteurAgent, AIMASEnemyAgent> saboteurAuction = Auction.auction(saboteurs, visibleOpponents,
				new SabotageEnenemyFunctor());
		
		Map<AIMASExplorerAgent, MarsNode> probingAuction = Auction.auction(explorers, neighboringNodes(nodes),
				new ProbeNodeFunctor());

		Map<AIMASAgent, MarsNode> gotoAuction = Auction.auction(placedAgents, nodes, new GotoNodeFunctor());

		for (Entry<AIMASAgent, MarsNode> e : gotoAuction.entrySet()) {
			List<WeightedDesire> agentDesires = new ArrayList<>(desires);

			agentDesires.add(new WeightedDesire(new GotoNodeGoal(e.getValue()), CategoryTag.UTILITY, SourceTag.GROUP,
					new PriorityTag((float) Config.get("CAHG_HOLD_GROUND_DESIRE_WEIGHT", 0.8))));

			e.getKey().receiveDesires(agentDesires);
		}

		for (Entry<AIMASSaboteurAgent, AIMASEnemyAgent> e : saboteurAuction.entrySet()) {
			List<WeightedDesire> agentDesires = new ArrayList<>(desires);

			agentDesires.add(new WeightedDesire(new AttackAgentGoal(e.getValue()), CategoryTag.OFFENSIVE,
					SourceTag.GROUP, new PriorityTag((float) Config.get("CAHG_SABOTAGE_DESIRE_WEIGHT", 0.8))));

			e.getKey().receiveDesires(agentDesires);
		}

		for (Entry<AIMASInspectorAgent, AIMASEnemyAgent> e : inspectAuction.entrySet()) {
			List<WeightedDesire> agentDesires = new ArrayList<>(desires);

			agentDesires.add(new WeightedDesire(new InspectGoal(e.getValue()), CategoryTag.OFFENSIVE, SourceTag.GROUP,
					new PriorityTag((float) Config.get("CAHG_INSPECT_DESIRE_WEIGHT", 0.8))));

			e.getKey().receiveDesires(agentDesires);
		}

		for (Entry<AIMASExplorerAgent, MarsNode> e : probingAuction.entrySet()) {
			List<WeightedDesire> agentDesires = new ArrayList<>(desires);

			agentDesires.add(new WeightedDesire(new ProbeNodeGoal(e.getValue()), CategoryTag.DEFENSIVE,
					SourceTag.GROUP, new PriorityTag((float) Config.get("CAHG_PROBE_DESIRE_WEIGHT", 0.8))));

			e.getKey().receiveDesires(agentDesires);
		}
	}
}