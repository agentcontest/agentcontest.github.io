package aimas2014.groups;

import aimas2014.agents.AIMASAgent;
import aimas2014.agents.AIMASRepairerAgent;
import aimas2014.environment.MarsNodePath;
import aimas2014.planning.BinaryFunctor;

public class RepairDisabledAgentFunctor extends BinaryFunctor<AIMASRepairerAgent, AIMASAgent> {
	
	@Override
	public Integer apply(AIMASRepairerAgent e1, AIMASAgent e2) {
		if (0 != e2.beliefs.health || e1.equals(e2))
			return null;
		
		MarsNodePath path = e1.beliefs.globalBeliefs.map.path(e1.beliefs.position, e2.beliefs.position);
		
		if (null == path)
			return null;
		
		return path.searchPath.size() + path.energy / e1.beliefs.maxEnergy;
	}
}