package aimas2014.groups;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.javatuples.Triplet;

import aimas2014.agents.AIMASAgent;
import aimas2014.agents.AIMASExplorerAgent;
import aimas2014.environment.MarsNode;
import aimas2014.goals.ProbeNodeGoal;
import aimas2014.goals.WeightedDesire;
import aimas2014.goals.WeightedDesire.CategoryTag;
import aimas2014.goals.WeightedDesire.PriorityTag;
import aimas2014.goals.WeightedDesire.SourceTag;
import aimas2014.planning.Auction;
import aimas2014.planning.GlobalBeliefs;
import aimas2014.search.BestFirstSearch;
import aimas2014.search.MarsNodePredicate;
import aimas2014.search.VisitNode;
import aimas2014.setup.Config;

public class ExplorerGroup extends AIMASGroup {    
    
    private static int id_cardinality = 0;
    
    private final List<AIMASExplorerAgent> explorers = new ArrayList<AIMASExplorerAgent>();
    
    public ExplorerGroup(AIMASGroup parentGroup, GlobalBeliefs groupBeliefs, List<AIMASAgent> explorers) {
        super(parentGroup, groupBeliefs, "Explorer group " + ++id_cardinality);
        
        for (AIMASAgent a: explorers)
        	this.explorers.add((AIMASExplorerAgent) a);
        
        members.addAll(explorers);
    }

    @Override
    public void propagateDesires(final List<WeightedDesire> desires) {
        List<Triplet<AIMASExplorerAgent, MarsNode, Integer>> targets = new ArrayList<>();
        
        for (AIMASExplorerAgent agent: explorers) {
        	final MarsNode initialNode = agent.beliefs.position; 
    		
        	final MarsNodePredicate p = new MarsNodePredicate() {
				@Override
				public boolean test(final MarsNode node) {
					return !node.state.probed;
				}
			};

        	final BestFirstSearch.Solution sol = BestFirstSearch.findNearestNodes(initialNode, p, members.size());
        	final VisitNode v = (VisitNode) sol.initialNode;
        	
        	for (VisitNode n: v.visits) {
        		targets.add(Triplet.with(agent, n.node, n.steps));
        	}
        }
        
        Map<AIMASExplorerAgent, MarsNode> r = Auction.auction(targets, members.size());
        
		for (Entry<AIMASExplorerAgent, MarsNode> e : r.entrySet()) {
			List<WeightedDesire> agentDesires = new ArrayList<>(desires);
        	
			agentDesires.add(new WeightedDesire(new ProbeNodeGoal(e.getValue()), CategoryTag.UTILITY, SourceTag.GROUP, new PriorityTag((float) Config.get("EXPLORATION_GROUP_PROBE_DESIRE_WEIGHT", 0.9))));
        	
        	e.getKey().receiveDesires(agentDesires);
		}
    }
}
