package aimas2014.groups;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Queue;
import java.util.Set;

import aimas2014.agents.AIMASAgent;
import aimas2014.agents.AIMASExplorerAgent;
import aimas2014.agents.AIMASInspectorAgent;
import aimas2014.agents.AIMASRepairerAgent;
import aimas2014.agents.AIMASSaboteurAgent;
import aimas2014.agents.AIMASSentinelAgent;
import aimas2014.environment.MarsNode;
import aimas2014.goals.WeightedDesire;
import aimas2014.planning.GlobalBeliefs;
import aimas2014.planning.Utilities;

public class CaptureAndHoldManagerGroup extends AIMASGroup {

	private final Set<AIMASSaboteurAgent> saboteurs = new HashSet<>();
	private final Set<AIMASRepairerAgent> repairers = new HashSet<>();
	private final Set<AIMASSentinelAgent> sentinels = new HashSet<>();
	private final Set<AIMASExplorerAgent> explorers = new HashSet<>();
	private final Set<AIMASInspectorAgent> inspectors = new HashSet<>();
	
	public CaptureAndHoldManagerGroup(AIMASGroup parentGroup, GlobalBeliefs groupBeliefs) {
		super(parentGroup, groupBeliefs);
	}

	public void addMembers(Collection<AIMASAgent> newMembers) {
		for (AIMASAgent a: newMembers) {
			
			if (a instanceof AIMASSaboteurAgent)
				saboteurs.add((AIMASSaboteurAgent) a);
			
			if (a instanceof AIMASRepairerAgent)
				repairers.add((AIMASRepairerAgent) a);
			
			if (a instanceof AIMASSentinelAgent)
				sentinels.add((AIMASSentinelAgent) a);
			
			if (a instanceof AIMASExplorerAgent)
				explorers.add((AIMASExplorerAgent) a);
			
			if (a instanceof AIMASInspectorAgent)
				inspectors.add((AIMASInspectorAgent) a);
			
			members.add(a);
		}
	}

	@Override
	public void initialize() {
	}
	
	@Override
	public void propagateDesires(List<WeightedDesire> desires) {
		members.addAll(allMembers());
		
		subgroups.clear();
		
		List<HashSet<MarsNode>> groups = Utilities.getGreedyScoreOptimizingConfigurationFor(globalBeliefs, members.size());

		if (null == groups || groups.size() == 0) {
			System.out.println("Could not create any optimized subsets");
			
			return;
		}
		
		Queue<AIMASSaboteurAgent> sbq = new ArrayDeque<>(saboteurs);
		Queue<AIMASRepairerAgent> raq = new ArrayDeque<>(repairers);
		Queue<AIMASSentinelAgent> saq = new ArrayDeque<>(sentinels);

		List<CaptureAndHoldGroup> cahgs = new ArrayList<>();
		
		for (HashSet<MarsNode> g: groups) {
			CaptureAndHoldGroup cahg = new CaptureAndHoldGroup(parentGroup, globalBeliefs, g);
			
			if (g.size() >= 1 && 0 < sbq.size()) cahg.addMember(sbq.poll());
			if (g.size() >= 2 && 0 < raq.size()) cahg.addMember(raq.poll());
			if (g.size() >= 3 && 0 < saq.size()) cahg.addMember(saq.poll());
			
			subgroups.add(cahg);
			cahgs.add(cahg);
		}

		Queue<AIMASAgent> others = new ArrayDeque<>();
		others.addAll(sbq);
		others.addAll(raq);
		others.addAll(saq);
		others.addAll(inspectors);
		others.addAll(explorers);
		
		boolean somethingAssigned = true;
		while(others.size() > 0 && somethingAssigned) {
			somethingAssigned = false;
			
			for (CaptureAndHoldGroup g: cahgs) {
				if (0 == others.size())
					continue;
				
				if (g.nodes.size() > g.members.size()) {
					g.addMember(others.poll());
					
					somethingAssigned = true;
				}
			}
		}
			
		members.clear();
		members.addAll(others);
		
		for (AIMASGroup g: subgroups) {
			g.propagateDesires(desires);
		}
		
//		if (globalBeliefs.agentStep % 20 == 0) {
//			Queue<String> colors = new PriorityQueue<>();
//			
//			colors.add("red");
//			colors.add("green");
//			colors.add("blue");
//			colors.add("yellow");
//			colors.add("orange");
//			colors.add("pink");
//			colors.add("brown");
//			colors.add("cyan");
//			colors.add("darkorchid");
//			colors.add("goldenrod1");
			
//			Collection<Pair<String, Collection<MarsNode>>> result = new ArrayList<>();
//			
//			for (Set<MarsNode> set : groups) {
//				result.add(new Pair<String, Collection<MarsNode>>(colors.poll(), set));
//				
//				globalBeliefs.map.outputToDot(globalBeliefs, result);
//			}	
//		}
	}
}
