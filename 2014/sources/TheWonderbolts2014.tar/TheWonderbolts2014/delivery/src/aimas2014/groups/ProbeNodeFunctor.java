package aimas2014.groups;

import aimas2014.agents.AIMASExplorerAgent;
import aimas2014.environment.MarsNode;
import aimas2014.environment.MarsNodePath;
import aimas2014.planning.BinaryFunctor;

public class ProbeNodeFunctor extends BinaryFunctor<AIMASExplorerAgent, MarsNode> {
	
	@Override
	public Integer apply(AIMASExplorerAgent e1, MarsNode e2) {
		if (e2.state.probed)
			return null;
		
		MarsNodePath path = e1.beliefs.globalBeliefs.map.path(e1.beliefs.position, e2);
		
		if (null == path)
			return null;
		
		return path.searchPath.size() + path.energy / e1.beliefs.maxEnergy;
	}
}