package aimas2014.groups;

public abstract class GroupStrategy {
    String name = "Unnamed group strategy";
    
    public abstract void setupGroup(AIMASGroup root);
    public abstract GroupStrategy planningStep(int i, AIMASGroup group);
}
