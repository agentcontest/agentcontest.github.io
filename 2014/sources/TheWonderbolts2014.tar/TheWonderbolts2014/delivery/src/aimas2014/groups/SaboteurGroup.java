package aimas2014.groups;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import aimas2014.agents.AIMASAgent;
import aimas2014.agents.AIMASEnemyAgent;
import aimas2014.agents.AIMASSaboteurAgent;
import aimas2014.goals.AttackAgentGoal;
import aimas2014.goals.WeightedDesire;
import aimas2014.goals.WeightedDesire.CategoryTag;
import aimas2014.goals.WeightedDesire.PriorityTag;
import aimas2014.goals.WeightedDesire.SourceTag;
import aimas2014.planning.Auction;
import aimas2014.planning.GlobalBeliefs;

public class SaboteurGroup extends AIMASGroup {    
    
    private static int id_cardinality = 0;
    
    private final List<AIMASSaboteurAgent> saboteurs = new ArrayList<>();
    
    public SaboteurGroup(RootGroup rootGroup, GlobalBeliefs globalBeliefs, List<AIMASAgent> repairers) {
    	super(rootGroup, globalBeliefs, "Saboteur group " + ++id_cardinality);
    	
    	for (AIMASAgent a: repairers)
        	this.saboteurs.add((AIMASSaboteurAgent) a);
        
        members.addAll(repairers);
	}

    @Override
    public void propagateDesires(final List<WeightedDesire> desires) {
		Map<AIMASSaboteurAgent, AIMASEnemyAgent> r = Auction.auction(saboteurs, globalBeliefs.opponentAgents.values(), new SabotageEnenemyFunctor());
		
		for (Entry<AIMASSaboteurAgent, AIMASEnemyAgent> e : r.entrySet()) {
			List<WeightedDesire> agentDesires = new ArrayList<>(desires);
			
    		agentDesires.add(new WeightedDesire(new AttackAgentGoal(e.getValue()), CategoryTag.OFFENSIVE, SourceTag.GROUP, new PriorityTag(0.7f)));
        	
        	e.getKey().receiveDesires(agentDesires);
		}
		
		for (AIMASGroup g: subgroups) {
			List<WeightedDesire> subgroupDesires = new ArrayList<>(desires);
			
			g.propagateDesires(subgroupDesires);
		}
    }
}
