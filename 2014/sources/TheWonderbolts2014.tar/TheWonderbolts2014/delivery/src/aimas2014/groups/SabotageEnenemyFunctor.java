package aimas2014.groups;

import aimas2014.agents.AIMASEnemyAgent;
import aimas2014.agents.AIMASSaboteurAgent;
import aimas2014.environment.MarsNodePath;
import aimas2014.planning.BinaryFunctor;
import aimas2014.setup.Config;

public class SabotageEnenemyFunctor extends BinaryFunctor<AIMASSaboteurAgent, AIMASEnemyAgent> {
	@Override
	public Integer apply(AIMASSaboteurAgent e1, AIMASEnemyAgent e2) {
		if (!e2.status.equals("normal") || Math.abs(e2.agentStepLastSeen - e1.beliefs.globalBeliefs.agentStep) >= 1)
			return null;
		
		MarsNodePath path = e1.beliefs.globalBeliefs.map.path(e1.beliefs.position, e2.position);
		
		if (null == path)
			return null;
		
		double factor = 1.0;
		int untilStepIE = (int) Config.get("SABOTEUR_IE_PRIORITY_UNTIL_STEP", 80.0);
		
		int constant = 0;
		if (e2.type.equals("Saboteur")) {
			constant = (int) Config.get("SABOTEUR_SABOTEUR_PRIORITY_CONSTANT", -5.0); 
		}
		
		if (e1.beliefs.globalBeliefs.agentStep < untilStepIE && e2.type.equals("Explorer") || e2.type.equals("Inspector")) {
			constant = (int) Config.get("SABOTEUR_IE_PRIORITY_CONSTANT", -2.0); 
		}
		
		return (int) ((path.searchPath.size() + path.energy / e1.beliefs.maxEnergy)) + constant;
	}
}