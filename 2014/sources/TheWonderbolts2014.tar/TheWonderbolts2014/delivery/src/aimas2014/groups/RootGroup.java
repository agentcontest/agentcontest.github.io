package aimas2014.groups;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import aimas2014.agents.AIMASAgent;
import aimas2014.agents.AIMASExplorerAgent;
import aimas2014.agents.AIMASInspectorAgent;
import aimas2014.agents.AIMASRepairerAgent;
import aimas2014.agents.AIMASSaboteurAgent;
import aimas2014.agents.AIMASSentinelAgent;
import aimas2014.goals.WeightedDesire;
import aimas2014.planning.GlobalBeliefs;
import aimas2014.setup.Config;

public class RootGroup extends AIMASGroup {

	// public GroupStrategy currentStrategy;

	public RootGroup(AIMASGroup parentGroup, GlobalBeliefs globalBeliefs) {
		super(parentGroup, globalBeliefs, "Root group");
	}

	private SaboteurGroup sbg;
	private ExplorerGroup expg;
	private RepairerGroup rpg;
	private CaptureAndHoldManagerGroup cahmg;

	//private SentinelInspectorManagerGroup simg;

	public final String explorerClassName = AIMASExplorerAgent.class.getSimpleName();
	public final String inspectorClassName = AIMASInspectorAgent.class.getSimpleName();
	public final String sentinelClassName = AIMASSentinelAgent.class.getSimpleName();
	public final String saboteurClassName = AIMASSaboteurAgent.class.getSimpleName();
	public final String repairerClassName = AIMASRepairerAgent.class.getSimpleName();

	private final List<AIMASAgent> explorers = new ArrayList<>();
	private final List<AIMASAgent> inspectors = new ArrayList<>();
	private final List<AIMASAgent> sentinels = new ArrayList<>();
	private final List<AIMASAgent> saboteurs = new ArrayList<>();
	private final List<AIMASAgent> repairers = new ArrayList<>();
	
	
	private int timeSinceExplorersReclaim = 0;
	
	@Override
	public void propagateDesires(final List<WeightedDesire> desires) {

		double explorationStop = Config.get("EXPLORATION_STOP_STEP", 100.0);
		int startCAHGAt = (int) Config.get("CAPTURE_HOLD_GROUP_STEP", 20.0);

		int numProbedNodes = globalBeliefs.map.numProbedNodes();
		int numNodes = globalBeliefs.map.numNodes();
		double f = ((double) numProbedNodes) / ((double) numNodes);

		if (expg != null && (++timeSinceExplorersReclaim > explorationStop)) {
			List<AIMASAgent> allExplorerAgents = new ArrayList<>(expg.allMembers());
			List<AIMASAgent> reclaimedExplorers = new ArrayList<>(allExplorerAgents).subList(0, Math.min(2, allExplorerAgents.size())); 
			
			System.out.format("ROOT RECLAIMING %d FREE E AGENTS\n", reclaimedExplorers.size());
			
			expg.members.removeAll(reclaimedExplorers);
			members.addAll(reclaimedExplorers);

			timeSinceExplorersReclaim = 0;
			
			if (0 == expg.members.size())
				expg = null;
		}
		
		if (null != cahmg) {
			cahmg.addMembers(members);
			members.clear();
		}
		
		for (AIMASGroup group : subgroups) {
			List<WeightedDesire> subgroupDesires = new ArrayList<>(desires);
			
			group.propagateDesires(subgroupDesires);
		}

		for (AIMASAgent agent : members) {
			agent.receiveDesires(desires);
		}
	}

	@Override
	public void initialize() {
		Map<String, List<AIMASAgent>> membersPerType = new HashMap<>();

		for (AIMASAgent agent : members) {
			String className = agent.getClass().getSimpleName();

			if (!membersPerType.containsKey(className))
				membersPerType.put(className, new ArrayList<AIMASAgent>());

			membersPerType.get(className).add(agent);
		}

		explorers.clear();
		inspectors.clear();
		sentinels.clear();
		repairers.clear();
		saboteurs.clear();
		
		subgroups.clear();

		if (membersPerType.containsKey(explorerClassName))
			explorers.addAll(membersPerType.get(explorerClassName));

		if (membersPerType.containsKey(inspectorClassName))
			inspectors.addAll(membersPerType.get(inspectorClassName));

		if (membersPerType.containsKey(sentinelClassName))
			sentinels.addAll(membersPerType.get(sentinelClassName));

		if (membersPerType.containsKey(repairerClassName))
			repairers.addAll(membersPerType.get(repairerClassName));
		
		if (membersPerType.containsKey(saboteurClassName))
			saboteurs.addAll(membersPerType.get(saboteurClassName));
		
		if (0 < saboteurs.size()) {
			sbg = new SaboteurGroup(this, globalBeliefs, saboteurs);
			subgroups.add(sbg);
			
			members.removeAll(saboteurs);
		}

		if (0 < explorers.size()) {
			expg = new ExplorerGroup(this, globalBeliefs, explorers);
			subgroups.add(expg);
			
			members.removeAll(explorers);
		}
		
		if (0 < repairers.size()) {
			rpg = new RepairerGroup(this, globalBeliefs, repairers);
			
			subgroups.add(rpg);
			
			members.removeAll(repairers);
		}
		
		{
			cahmg = new CaptureAndHoldManagerGroup(this, globalBeliefs);
			subgroups.add(cahmg);
			
			cahmg.addMembers(inspectors);
			cahmg.addMembers(sentinels);
			cahmg.addMembers(saboteurs);
			cahmg.addMembers(repairers);
			
			members.removeAll(inspectors);
			members.removeAll(sentinels);
			members.removeAll(saboteurs);
			members.removeAll(repairers);
		}

		for (AIMASGroup group : subgroups) {
			group.initialize();
		}
	}	
}
