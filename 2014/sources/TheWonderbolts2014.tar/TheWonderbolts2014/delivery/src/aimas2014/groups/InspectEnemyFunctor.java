package aimas2014.groups;

import aimas2014.agents.AIMASEnemyAgent;
import aimas2014.agents.AIMASInspectorAgent;
import aimas2014.environment.MarsNodePath;
import aimas2014.planning.BinaryFunctor;

final class InspectEnemyFunctor extends BinaryFunctor<AIMASInspectorAgent, AIMASEnemyAgent> {
	@Override
	public Integer apply(AIMASInspectorAgent e1, AIMASEnemyAgent e2) {
		if (e2.agentStepInspected >= 0)
			return null;
		
		MarsNodePath p = e1.beliefs.map.path(e1.beliefs.position, e2.position);
		
		if (null == p)
			return null;
		
		return p.searchPath.size() + p.energy / e1.beliefs.maxEnergy;
	}
}