package aimas2014.groups;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import aimas2014.agents.AIMASAgent;
import aimas2014.goals.WeightedDesire;
import aimas2014.planning.GlobalBeliefs;

public abstract class AIMASGroup {
    public final String name;
    
    public final Set<AIMASGroup> subgroups = new HashSet<>();
    public final Set<AIMASAgent> members = new HashSet<>();
    
    public final AIMASGroup parentGroup;
    public final GlobalBeliefs globalBeliefs;

    public GroupStrategy strategy;
    
    public AIMASGroup(AIMASGroup parentGroup, GlobalBeliefs globalBeliefs, String name) {
        super();
        
        this.parentGroup = parentGroup;
        this.globalBeliefs = globalBeliefs;
        this.name = name;
    }
    
    public AIMASGroup(AIMASGroup parentGroup, GlobalBeliefs groupBeliefs) {
        this(parentGroup, groupBeliefs, "Unnamed group");
    }

    @Override
    public String toString() {
        return name;
    }
    
    public String toStringUnique() {
        return name + super.toString();
    }
    
    public void propagateDesires(final List<WeightedDesire> desires) {
        for (AIMASGroup group: subgroups) {
            group.propagateDesires(desires);
        }
        
        for (AIMASAgent agent: members) {
            agent.receiveDesires(desires);
        }
    }

    public Set<AIMASAgent> allMembers() {
    	if (0 == subgroups.size()) {
    		return new HashSet<>(members);
    	} else {
    		Set<AIMASAgent> result = null;
    		
    		for (AIMASGroup group: subgroups) {
    			if (null == result)
    				result = group.allMembers();
    			else
    				result.addAll(group.allMembers());
    		}
    		
    		return result;
    	}
    }
    
    
	public void initialize() {
	}
}
