package aimas2014.groups;

import java.util.ArrayList;
import java.util.List;

import aimas2014.agents.AIMASAgent;
import aimas2014.agents.AIMASRepairerAgent;
import aimas2014.environment.MarsNodePath;
import aimas2014.goals.GotoNodeGoal;
import aimas2014.goals.IdleGoal;
import aimas2014.goals.RepairAgentGoal;
import aimas2014.goals.WeightedDesire;
import aimas2014.goals.WeightedDesire.CategoryTag;
import aimas2014.goals.WeightedDesire.PriorityTag;
import aimas2014.goals.WeightedDesire.SourceTag;
import aimas2014.planning.GlobalBeliefs;
import aimas2014.setup.Config;

public class RepairAgentPair extends AIMASGroup {    
    
    private static int id_cardinality = 0;
    
    private final AIMASRepairerAgent repairer;
    private final AIMASAgent targetAgent;
    
    public RepairAgentPair(AIMASGroup rootGroup, GlobalBeliefs globalBeliefs, AIMASRepairerAgent repairer, AIMASAgent targetAgent) {
    	super(rootGroup, globalBeliefs, "Repair-agent pair " + ++id_cardinality);

    	this.repairer = repairer;
    	this.targetAgent = targetAgent;
    	
        members.add(repairer);
    	members.add(targetAgent);
	}

    @Override
    public void propagateDesires(final List<WeightedDesire> desires) {
    	MarsNodePath p = globalBeliefs.map.path(repairer.beliefs.position, targetAgent.beliefs.position);
    	
    	if (null != p) {
    		{
    			List<WeightedDesire> agentDesires = new ArrayList<>(desires);
    			
    			agentDesires.add(new WeightedDesire(new RepairAgentGoal(targetAgent), CategoryTag.DEFENSIVE, SourceTag.GROUP, new PriorityTag((float) Config.get("REPAIRER_GROUP_REPAIR_DESIRE_WEIGHT", 0.7))));
    			
    			repairer.receiveDesires(agentDesires);
    		}
    		
    		{
    			List<WeightedDesire> agentDesires = new ArrayList<>(desires);
    			
    			if (p.searchPath.size() >= 1)
    				agentDesires.add(new WeightedDesire(new GotoNodeGoal(repairer.beliefs.position), CategoryTag.UTILITY, SourceTag.GROUP, new PriorityTag((float) Config.get("REPAIRER_GROUP_IDLE_DESIRE_WEIGHT", 0.7))));
    			else
    				agentDesires.add(new WeightedDesire(new IdleGoal(), CategoryTag.UTILITY, SourceTag.GROUP, new PriorityTag((float) Config.get("REPAIRER_GROUP_IDLE_DESIRE_WEIGHT", 0.8))));
    			
    			targetAgent.receiveDesires(agentDesires);
    		}
    	}
    }
    
    public boolean stillRequired() {
    	return 0 == targetAgent.beliefs.health && 0 != repairer.beliefs.health;
    }
}
