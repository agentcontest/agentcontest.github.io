package aimas2014.groups;

import aimas2014.agents.AIMASAgent;
import aimas2014.environment.MarsNode;
import aimas2014.environment.MarsNodePath;
import aimas2014.planning.BinaryFunctor;

public class GotoNodeFunctor extends BinaryFunctor<AIMASAgent, MarsNode> {
	
	@Override
	public Integer apply(AIMASAgent e1, MarsNode e2) {
		MarsNodePath p = e1.beliefs.map.path(e1.beliefs.position, e2);

		if (null == p)
			return null;

		return p.searchPath.size() + p.energy / e1.beliefs.maxEnergy;
	}
}