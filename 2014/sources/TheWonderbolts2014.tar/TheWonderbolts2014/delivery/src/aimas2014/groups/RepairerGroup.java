package aimas2014.groups;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import aimas2014.agents.AIMASAgent;
import aimas2014.agents.AIMASRepairerAgent;
import aimas2014.goals.WeightedDesire;
import aimas2014.planning.Auction;
import aimas2014.planning.GlobalBeliefs;

public class RepairerGroup extends AIMASGroup {    
    
    private static int id_cardinality = 0;
    
    private final List<AIMASRepairerAgent> repairers = new ArrayList<>();
    private final List<RepairAgentPair> repairAgentPairs = new ArrayList<>();
    
    public RepairerGroup(RootGroup rootGroup, GlobalBeliefs globalBeliefs, List<AIMASAgent> repairers) {
    	super(rootGroup, globalBeliefs, "Repairer group " + ++id_cardinality);
    	
    	for (AIMASAgent a: repairers)
        	this.repairers.add((AIMASRepairerAgent) a);
        
        members.addAll(repairers);
	}

    @Override
    public void propagateDesires(final List<WeightedDesire> desires) {
		members.addAll(repairers);
    	
		subgroups.clear();
    	repairAgentPairs.clear();
    	
		Map<AIMASRepairerAgent, AIMASAgent> r1 = Auction.auction(repairers, members, new RepairDisabledAgentFunctor());
		
		for (Entry<AIMASRepairerAgent, AIMASAgent> e : r1.entrySet()) {
			subgroups.add(new RepairAgentPair(this, globalBeliefs, e.getKey(), e.getValue()));
			
			members.remove(e.getKey());
		}
		
		List<AIMASAgent> remainingAgents = new ArrayList<AIMASAgent>(globalBeliefs.agents.values());
		remainingAgents.removeAll(r1.values());
		
		Map<AIMASRepairerAgent, AIMASAgent> r2 = Auction.auction(repairers, remainingAgents, new RepairDisabledAgentFunctor());
		
		for (Entry<AIMASRepairerAgent, AIMASAgent> e : r2.entrySet()) {
			subgroups.add(new RepairAgentPair(this, globalBeliefs, e.getKey(), e.getValue()));
			
			members.remove(e.getKey());
		}
		
		for (AIMASGroup g: subgroups) {
			List<WeightedDesire> subgroupDesires = new ArrayList<>(desires);
			
			g.propagateDesires(subgroupDesires);
		}
    }
}
