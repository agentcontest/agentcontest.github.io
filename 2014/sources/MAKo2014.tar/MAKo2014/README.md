# MAKo
This ZIP file contains the source code of MAKo. MAKo is the result of a research lab of the University Koblenz · Landau<sup>1</sup> for participating in the 2014's Multi-Agent Programming Contest<sup>2</sup>. It is built using a mixture of AgentSpeak(L)<sup>3</sup>, Jason<sup>4,5</sup> and Java<sup>6</sup>. Additionally, MAKo uses the libraries EIS<sup>7</sup> and EISMASSIM<sup>8</sup> which are managed by Dr. Koen Hindriks<sup>9</sup>.

## Licence
MAKo itself is GPLv3 licenced. Both EIS and EISMASSIM are licenced GLPv3. The used Jason libraries are licenced LGPLv2.1. For further information, see the files COPYING and LICENSE located in the project parent and in the respective library folders.

## Footnotes
1. http://www.uni-koblenz-landau.de/ Homepage of the University Koblenz · Landau. Last accessed 27.09.2014.
2. https://multiagentcontest.org/ Homepage of the Multi-Agent Programming Contest. Last accessed 27.09.2014.
3. Rao, A.S., 1996. AgentSpeak (L): BDI agents speak out in a logical computable language, in: Agents Breaking Away. Springer, pp. 42–55.
4. Bordini, R.H., Hübner, J.F., Vieira, R., 2005. Jason and the Golden Fleece of agent-oriented programming, in: Multi-Agent Programming. Springer, pp. 3–37.
5. http://jason.sourceforge.net/wp/ Homepage of Jason. Last accessed 27.09.2014.
6. https://www.java.com/en/ Homepage of Java. Last accessed 27.09.2014.
7. https://github.com/eishub/eis Repository of EIS. Last accessed 27.09.2014.
8. https://github.com/eishub/massim Repository of EISMASSIM. Last accessed 27.09.2014.
9. https://github.com/eishub The Environment Interface Standard (EIS) hub. Last accessed 27.09.2014.
