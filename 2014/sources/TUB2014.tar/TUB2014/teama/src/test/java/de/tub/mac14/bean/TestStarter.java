package de.tub.mac14.bean;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import de.dailab.ccact.tools.agentunit.ActionTesterNode;

public class TestStarter {

	public static String NODES_SPRINGCONFIGFILE = "classpath:Bteam.xml";
	public static String NODE_NAME = "MAC14BTeamNode";

	static ActionTesterNode testAgentNode;
	

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		testAgentNode = new ActionTesterNode(NODES_SPRINGCONFIGFILE, NODE_NAME);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		testAgentNode.stop();
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		try {
			Thread.sleep(1000*60*60*2);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
