package de.tub.mac14.graphutils;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.LinkedList;

import org.junit.Test;
import org.junit.Before;

import de.tub.mac14.ontology.Vertex;

public class PathmapTest {
	
	private Vertex v0;
	private Vertex v1;
	private Vertex v2;
	private Vertex v3;
	private Vertex v4;
	
	
	/**
	 * Sets up the basic graph that will be used in the tests
	 */
	@Before 
    public void setUpBasicGraph() {
		v0 = new Vertex(0);
		v0.setValue(1);
		v1 = new Vertex(1);
		v1.setValue(3);
		v2 = new Vertex(2);
		v2.setValue(6);
		v3 = new Vertex(3);
		v3.setValue(7);
		v4 = new Vertex(4);
		v4.setValue(5);
		
		v0.addEdge(v1);
		v1.addEdge(v0);
		v0.getEdgeTo(v1).setValue(5);
		v1.getEdgeTo(v0).setValue(5);

		v0.addEdge(v2);
		v2.addEdge(v0);
		v0.getEdgeTo(v2).setValue(10);
		v2.getEdgeTo(v0).setValue(10);
		
		v0.addEdge(v3);
		v3.addEdge(v0);
		v0.getEdgeTo(v3).setValue(8);
		v3.getEdgeTo(v0).setValue(8);
		
		v1.addEdge(v2);
		v2.addEdge(v1);
		v1.getEdgeTo(v2).setValue(3);
		v2.getEdgeTo(v1).setValue(3);
		
		v1.addEdge(v3);
		v3.addEdge(v1);
		v1.getEdgeTo(v3).setValue(1);
		v3.getEdgeTo(v1).setValue(1);
		
		v1.addEdge(v4);
		v4.addEdge(v1);
		v1.getEdgeTo(v4).setValue(7);
		v4.getEdgeTo(v1).setValue(7);
		
		v3.addEdge(v4);
		v4.addEdge(v3);
		v3.getEdgeTo(v4).setValue(2);
		v4.getEdgeTo(v3).setValue(2);
    }
	
	
	/**
	 * Tests if the pathmap Dijkstra's algorithm implementation is working well
	 * with the basic graph
	 */
	@Test
    public void testPathmapCreation() {
		Pathmap pathmap = new Pathmap(v0);
		
		assertEquals(0, pathmap.getDistanceTo(v0));
		assertEquals(5, pathmap.getDistanceTo(v1));
		assertEquals(8, pathmap.getDistanceTo(v2));
		assertEquals(6, pathmap.getDistanceTo(v3));
		assertEquals(8, pathmap.getDistanceTo(v4));
    }
	
	/**
	 * Tests if the pathmap Dijkstra's algorithm implementation is working well
	 * with some unknown edges
	 */
	@Test
    public void testPathmapUnknownEdgeCosts() {
		
		
		// v0 --- v3
		v0.getEdgeTo(v3).setValue(-1);
		v3.getEdgeTo(v0).setValue(-1);
		
		// v1 --- v4
		v1.getEdgeTo(v4).setValue(-1);
		v4.getEdgeTo(v1).setValue(-1);

		Pathmap pathmap = new Pathmap(v0);
		
		assertEquals(0, pathmap.getDistanceTo(v0));
		assertEquals(5, pathmap.getDistanceTo(v1));
		assertEquals(8, pathmap.getDistanceTo(v2));
		// Obs: The default value for unknown edges affects this test
		assertEquals(5, pathmap.getDistanceTo(v3));
		assertEquals(7, pathmap.getDistanceTo(v4));
    }
	
	
	/**
	 * Tests if the pathmap Dijkstra's algorithm implementation is working well
	 * with unknown vertex weights
	 */
	@Test
    public void testPathmapUnknownVertexValues() {
		v2.setValue(-1);
		v3.setValue(-1);

		Pathmap pathmap = new Pathmap(v0);
		
		assertEquals(0, pathmap.getDistanceTo(v0));
		assertEquals(5, pathmap.getDistanceTo(v1));
		assertEquals(8, pathmap.getDistanceTo(v2));
		assertEquals(6, pathmap.getDistanceTo(v3));
		assertEquals(8, pathmap.getDistanceTo(v4));
    }
	
	/**
	 * Tests the get path method
	 */
	@Test
	public void testGetPath() {
		Pathmap pathmap = new Pathmap(v0);
		
		LinkedList<Vertex> pathToV0 = new LinkedList<>(Arrays.asList(v0));
		LinkedList<Vertex> pathToV1 = new LinkedList<>(Arrays.asList(v0, v1));
		LinkedList<Vertex> pathToV2 = new LinkedList<>(Arrays.asList(v0, v1, v2));
		LinkedList<Vertex> pathToV3 = new LinkedList<>(Arrays.asList(v0, v1, v3));
		LinkedList<Vertex> pathToV4 = new LinkedList<>(Arrays.asList(v0, v1, v3, v4));
		
		assertEquals(pathToV0, pathmap.getPath(v0));
		assertEquals(pathToV1, pathmap.getPath(v1));
		assertEquals(pathToV2, pathmap.getPath(v2));
		assertEquals(pathToV3, pathmap.getPath(v3));
		assertEquals(pathToV4, pathmap.getPath(v4));
	}
}
