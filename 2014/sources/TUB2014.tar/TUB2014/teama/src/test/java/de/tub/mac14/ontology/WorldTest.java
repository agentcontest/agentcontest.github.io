package de.tub.mac14.ontology;

import de.tub.mac14.common.Config;
import de.tub.mac14.connection.parsinghelper.EdgeContainer;
import de.tub.mac14.connection.parsinghelper.VerticesContainer;
import de.tub.mac14.enums.Role;
import de.tub.mac14.enums.Team;
import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class WorldTest {

	@Test
	public void test() {
		World world = new World("A5", 4, 4);
		world.newEdge(0, 1);
		world.newEdge(1, 2);
		world.newEdge(3, 2);
		world.newEdge(3, 0);

		world.newEdge(0, 1); // duplicate
		world.newEdge(1, 0); // duplicate
		// invalid -> Exception
		// world.newEdge(4, 0); // invalid -> Exception
		world.probeVertex(0, 5);
		world.surveyEdge(0, 1, 4);

		// TODO (maybe :P): test edges

		Perception p = new Perception("A5");

		RobotStatus status = new RobotStatus();
		status.role = "Explorer";
		status.name = "A1";
		p.robots.add(status);

		status = new RobotStatus();
		status.role = "Explorer";
		status.name = "A3";
		p.robots.add(status);

		status = new RobotStatus();
		status.role = "Inspector";
		status.name = "A4";
		p.robots.add(status);

		status = new RobotStatus();
		status.role = "Explorer";
		status.name = "B1";
		p.robots.add(status);

		status = new RobotStatus();
		status.role = "Explorer";
		status.name = "B7";
		p.robots.add(status);

		// me
		status = new RobotStatus();
		status.role = "Explorer";
		status.name = "A5";
		p.robots.add(status);

		p.verticies = new VerticesContainer();
		p.edges = new EdgeContainer();

		world.update(p);

		assertEquals(5, world.filterRobots(null, Role.EXPLORER).size());
		assertEquals(3, world.filterRobots(Team.WE, Role.EXPLORER).size());
		assertEquals(1, world.filterRobots(Team.WE, Role.INSPECTOR).size());
		assertEquals(0, world.filterRobots(Team.ENEMY, Role.INSPECTOR).size());
		assertEquals(2, world.filterRobots(Team.ENEMY, Role.EXPLORER).size());
		assertEquals(Config.getInt("GAME_NUM_ROBOTS") * 2,
				world.filterRobots(null, null).size());
		assertEquals(Config.getInt("GAME_NUM_ROBOTS"),
				world.filterRobots(Team.WE, null).size());

	}

}
