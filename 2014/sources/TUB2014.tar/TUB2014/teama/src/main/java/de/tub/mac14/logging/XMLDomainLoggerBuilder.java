/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package de.tub.mac14.logging;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * Builder class for convenient initializing of all the logs.
 * @author mattu
 */
public class XMLDomainLoggerBuilder {
	
	Document d;
	DomainLogger domainer;
	String logPath = "";
	
	public XMLDomainLoggerBuilder(File xmlFilePath) throws SAXException, IOException{
		try {
			d = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(xmlFilePath);
		} catch (ParserConfigurationException ex) {
			throw new RuntimeException("Parser configuration not good!" );
		}
	}
	
	
	public DomainLogger getDomainLogger() {
		
		
		domainer = new DomainLogger();
		
		NodeList rootList = d.getElementsByTagName("loggers");
		
		Element root = (Element) rootList.item(0);
		logPath = root.getAttribute("logpath");
		
		ArrayList<Element> rootLoggers = getLoggerElements(root);
		
		for(Element rootLogger : rootLoggers){
			domainer.addLogger(getLoggerFromElement(rootLogger, ""));
		}
		
		Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {

			@Override
			public void run() {
				domainer.closeAllLogger();
			}
		}));
		return domainer;
		
	}
	
	
	private Logger getLoggerFromElement(Element el, String logHierarchy){
		String name = el.getAttribute("name");
		boolean append = el.hasAttribute("append");
		boolean main = el.hasAttribute("main");
		String outFile = logHierarchy.concat(name + ".");
		Logger l = new Logger(name, logPath, outFile + "log", append);
		if(main){
			l.makeMainLog();
			this.domainer.addMainLogIgnore(logHierarchy.concat(name));
		}
		for(Element childLogger : getLoggerElements(el)){
			l.addChild(getLoggerFromElement(childLogger, outFile));
		}
		return l;
	}
	
	private ArrayList<Element> getLoggerElements(Element el){
		NodeList rootLoggers = el.getChildNodes();
		ArrayList<Element> loggerEles = new ArrayList<>();
		for(int i = 0; i < rootLoggers.getLength(); i++){
			
			if(rootLoggers.item(i).getNodeName().equalsIgnoreCase("logger")){
				loggerEles.add((Element) rootLoggers.item(i));
			}
		}
		return loggerEles;
	}
	
	
}
