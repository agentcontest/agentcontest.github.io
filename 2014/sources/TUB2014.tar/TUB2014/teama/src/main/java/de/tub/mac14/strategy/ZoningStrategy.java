package de.tub.mac14.strategy;

import de.tub.mac14.bean.DefaultDecisionBean;
import de.tub.mac14.common.Log;
import de.tub.mac14.common.Tuple;
import de.tub.mac14.communication.Inform;
import de.tub.mac14.enums.MessageSubject;
import de.tub.mac14.graphutils.Coloring;
import de.tub.mac14.graphutils.Coloring2;
import de.tub.mac14.ontology.Hotspot;
import de.tub.mac14.ontology.Intention;
import de.tub.mac14.ontology.Robot;
import de.tub.mac14.ontology.Vertex;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Set;

/**
 *
 * @author mattu
 */
public class ZoningStrategy extends Strategy{
	static public int DEPTH = 3;
    ArrayList<Robot> hotSpotRobots;
    ArrayList<Vertex> ourPositions;
	private int bestRating = Integer.MIN_VALUE;
    private ArrayList<Vertex> bestPositions;
	Hotspot myHotspot;
    long startTime;
    
    public ZoningStrategy(DefaultDecisionBean bean) {
        super(bean);
       
    }

    @Override
    public Intention decide() {
		myHotspot = StrategyAssigner.hotspotAssignments.get(me);
		if (myHotspot == null) {
			return null;
		}

        //for resetting.
		this.bestRating = Integer.MIN_VALUE;
		this.hotSpotRobots = getOtherHotspotRobots(myHotspot, true, myHotspot.extendedNeighbors);
		
		if (!hotSpotRobots.contains(me)) {
			hotSpotRobots.add(me);
		}

		// find master Zoner
		Robot master = StrategyAssigner.pleaseLetMeBeTheMasterOhPleaseOhPlease(myHotspot, me);

		// if we are not the master -> wait for instructions
		if (!master.equals(me)) {
			// Check if we need to approach the hotspot
			Intention approach = new GotoHotspotStrategy(ddb).decide();
			return (approach == null) ? waitForInstructions(master) : approach;
		}

		// We only calculate the positions for the first DEPTH robots.
		Collections.shuffle(hotSpotRobots);

        this.bestPositions = new ArrayList<>(hotSpotRobots.size());

        this.ourPositions = new ArrayList<>(hotSpotRobots.size());
		for (int i = 0; i < hotSpotRobots.size(); i++) {
			Robot r = hotSpotRobots.get(i);
			ourPositions.add(r.position);
		}

		 Log.log("debug.strategy.zoning","ZONING " + me);
		Log.log("debug.strategy.zoning", myHotspot.toString());
		 Log.log("debug.strategy.zoning",hotSpotRobots.toString());
		 Log.log("debug.strategy.zoning",ourPositions.toString());

        this.startTime = System.currentTimeMillis();
		if (!hotSpotRobots.isEmpty()) {
			calculateBestPosition();
			sendInstructions();
		}

		// Check if we need to approach the hotspot
		Intention approach = new GotoHotspotStrategy(ddb).decide();
		return (approach == null) ? checkedGoto(bestPositions.get(hotSpotRobots.indexOf(me))) : approach;
    }
    
    
	private void sendInstructions() {
		// <robotId, gotoVertex>
		ArrayList<Tuple<Integer, Integer>> message = new ArrayList<>(DEPTH);
		for (int i = 0; i < hotSpotRobots.size() && i <= DEPTH; i++) {
			Robot r = hotSpotRobots.get(i);
			Vertex gotoV = bestPositions.get(i);
			message.add(new Tuple<>(r.usersuffix, gotoV.getId()));
		}
		ddb.sendInform(ddb.getGroupAddress(), MessageSubject.GOTO_INSTRUCTION, message);
		Log.log("debug.strategy.zoning",me.username + ": sent Message");
	}

	@SuppressWarnings("unchecked")
	private Intention waitForInstructions(Robot master) {
		Inform template = new Inform(MessageSubject.GOTO_INSTRUCTION);
		template.setSenderUsername(master.usersuffix);
		template.setStep(world.id);

//		Log.log("debug.strategy.zoning",world.getMe().username + ": Wait for message from " + master.username);
		Inform message = ddb.waitForInform(template);
		if (message == null) {
			Log.log("debug.strategy.zoning","ERROR: "+world.getMe().username + ": Nothing happend");
			return null;
		}

//		Log.log("debug.strategy.zoning",world.getMe().username + ": Message received");
		ArrayList<Tuple<Integer, Integer>> instructions = (ArrayList<Tuple<Integer, Integer>>) message.getMessage();
		for (Tuple<Integer, Integer> t : instructions) {
			if (t.first.equals(me.usersuffix)) {
				return checkedGoto(world.getVertex(t.second));
			}
		}
		return null;
	}

	/**
	 * This method is supposed to return the vertex, on which the robot should
	 * move to maximize the zone-score. It needs to take an array list
	 * containing the robots, which are also assigned to out hotspot.
	 * 
	 * @return A vertex, to which the robot should go to.
	 */
	private void calculateBestPosition() {
		int depth = (hotSpotRobots.size() > 2) ? 2 : hotSpotRobots.size() - 1;
		Coloring2 coloring = new Coloring2(
				myHotspot.extendedNeighbors,
				world.enemyRobots);
		recursive(depth, coloring, new LinkedList<Vertex>());
		
		if (this.bestPositions.size() != this.hotSpotRobots.size()) {
			Log.log("debug.strategy.zoning", "Needed to replace best positions");
			this.bestPositions = this.ourPositions;
		}
		Log.log("debug.strategy.zoning", "BEST POSITION:  hotspot: " + myHotspot.center.getFullId() + " Postitions: "
				+ Arrays.toString(bestPositions.toArray()) + " Rating: " + bestRating);
    }
    
    /**
     * Recursive method which moves the robot specified by depth and then 
     * calls itself with depth -1. The new Position is saved in ourPosition.
     * when at 0, the robot at hotSpotRobots[0] is moved and the current ourPositions
     * are rated by the zoning algorithm and if this position is better than the other, 
     * it is stored.
     * @param depth
     */
	@SuppressWarnings("unchecked")
	private void recursive(int depth, Coloring2 coloring, LinkedList<Vertex> changes) {
        
        Robot currentRobot = this.hotSpotRobots.get(depth);
        //Remove thePosition of the over robots from the possible positions list to avoid Klumpen
		Set<Vertex> possiblePositions = currentRobot.position.getNeighbors(1, true);
		// possiblePositions.removeAll(this.ourPositions);
        possiblePositions.add(currentRobot.position);
        for(Vertex v : possiblePositions){
			// check if vertex is part of the hotspot
			if (!this.myHotspot.extendedNeighbors.contains(v)) {
				continue;
			}
            this.ourPositions.set(depth, v);
			changes.add(v);
            
            if(depth == 0){
				int rating = coloring.colorGraph(ourPositions);// rateTheCurrentPosition
//              //***Commented this out so the robots stay in their place longer
//				// Just favor moving over staying in the same place.
//				// So if the rating is the same for the current position and
//				// a neighbor position, we go to the neighbor.
//                if (!v.equals(currentRobot.position)) {
//					rating += 1;
//				}
				Log.log("debug.strategy.zoning",world.getMe().username + ": " + rating +
						": " + ourPositions.toString());
                if(rating > bestRating){
					//Log.log("debug.strategy.zoning","Better reating");
                    bestRating = rating;
					bestPositions = (ArrayList<Vertex>) this.ourPositions.clone();
                }
            }else{
				recursive(depth - 1, coloring, changes);
            }
			changes.removeLast();
            //if the we are too late, break and return what you've got so far.
            if(System.currentTimeMillis() - startTime > 1500) {
                Log.log("debug.strategy.zoning","I BROKE: "+ this.me.username);
                break;
            }
        }
        
    }
    
    
    
}
