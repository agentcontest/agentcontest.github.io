package de.tub.mac14.connection;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac14.common.Utils;
import de.tub.mac14.connection.parsinghelper.EdgeContainer;
import de.tub.mac14.connection.parsinghelper.RobotStatusBuilder;
import de.tub.mac14.connection.parsinghelper.TeamStatusBuilder;
import de.tub.mac14.connection.parsinghelper.VerticesContainer;
import de.tub.mac14.enums.Role;
import de.tub.mac14.ontology.AuthResponse;
import de.tub.mac14.ontology.Bye;
import de.tub.mac14.ontology.Perception;
import de.tub.mac14.ontology.SimEnd;
import de.tub.mac14.ontology.World;
import java.util.ArrayList;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

/**
 * Class to parse contest server messages
 * 
 * @author axle
 */
public class MessageParser {
	private String username;

	public MessageParser(String username) {
		this.username = username;
	}

	public IFact parse(Document message) {
		Element root = message.getDocumentElement();
		// try {
		// TransformerFactory.newInstance().newTransformer().transform(
		// new DOMSource(message), new StreamResult(System.out));
		// } catch (TransformerConfigurationException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// } catch (TransformerException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// } catch (TransformerFactoryConfigurationError e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }

		String messageType = root.getAttribute("type").trim();

		if (messageType
				.equalsIgnoreCase(MessageConstants.MESSAGE_ACTION_REQUEST)) {
			return receivePerception(root);
		}
		if (messageType.equalsIgnoreCase(MessageConstants.MESSAGE_SIM_START)) {
			return receiveSimStart(root);
		}
		if (messageType.equalsIgnoreCase(MessageConstants.MESSAGE_SIM_END)) {
			return receiveSimEnd(root);
		}
		if (messageType.equalsIgnoreCase(MessageConstants.MESSAGE_BYE)) {
			return new Bye();
		}
		if (messageType
				.equalsIgnoreCase(MessageConstants.MESSAGE_AUTH_RESPONSE)) {
			return receiveAuth(root);
		}
		return null;
	}

	private IFact receivePerception(Element root) {
		Perception perception = new Perception(username);
		perception.timestamp = Long.parseLong(root.getAttribute("timestamp"));
		NodeList nodes = root.getElementsByTagName("perception");

		Element childPerception = (Element) nodes.item(0);
		perception.id = childPerception.getAttribute("id");
		perception.deadline = Long.parseLong(childPerception
				.getAttribute("deadline"));

		ArrayList<Element> perceptionElements = Utils
				.getElementChildrenFromNode(childPerception);
		// Iterate over all child nodes

		for (Element currElement : perceptionElements) {
//			System.out.println(">> " + currElement.getTagName());
			if (currElement.getTagName().equalsIgnoreCase("simulation")) {
				perception.simulationStep = Integer.parseInt(currElement
						.getAttribute("step"));
			} else if (currElement.getTagName().equalsIgnoreCase("self")) {
				perception.robots.add(RobotStatusBuilder
						.buildRobotStatusFromSelf(currElement,
								perception.username));
			} else if (currElement.getTagName().equalsIgnoreCase("team")) {
				perception.teamStatus = TeamStatusBuilder
						.buildTeamStatusFromDom(currElement);
			} else if (currElement.getTagName().equalsIgnoreCase(
					"visibleVertices")) {
				if (perception.verticies == null) {
					perception.verticies = new VerticesContainer();
				}
				perception.verticies.addVisibleVertices(currElement);
			} else if (currElement.getTagName().equalsIgnoreCase(
					"probedVertices")) {
				if (perception.verticies == null) {
					perception.verticies = new VerticesContainer();
				}
				perception.verticies.addProbedVertices(currElement);
			} else if (currElement.getTagName().equalsIgnoreCase(
					"surveyedEdges")
					|| currElement.getTagName()
							.equalsIgnoreCase("visibleEdges")) {
				if (perception.edges == null) {
					perception.edges = new EdgeContainer();
				}
				perception.edges.parseEdges(currElement);
			} else if (currElement.getTagName().contains("visibleEntities")) {
				RobotStatusBuilder.buildRobotStatusFromVisibleEntities(
						currElement, perception.robots);
			} else if (currElement.getTagName().contains("inspectedEntities")) {
				RobotStatusBuilder.buildRobotStatusFromInspectedEntities(
						currElement, perception.robots);
			}

		}

		return perception;
	}

	private IFact receiveSimStart(Element root) {
		int numVertices;

		NodeList childs = root.getElementsByTagName("simulation");
		Element childSimulation = (Element) childs.item(0);

		numVertices = Integer
				.parseInt(childSimulation.getAttribute("vertices"));
		int numEdges = Integer.parseInt(childSimulation.getAttribute("edges"));
		int maxsteps = Integer.parseInt(childSimulation.getAttribute("steps"));
		World world = new World(username, numVertices, numEdges);
		world.getMe().role = Role.getRoleFromString(childSimulation
				.getAttribute("role"));

		return world;
	}

	private IFact receiveSimEnd(Element root) {
		SimEnd simEnd = new SimEnd();

		NodeList childs = root.getElementsByTagName("sim-result");
		Element childSimResult = (Element) childs.item(0);

		simEnd.setRanking(childSimResult.getAttribute("ranking"));
		simEnd.setScore(childSimResult.getAttribute("score"));

		return simEnd;
	}

	private IFact receiveAuth(Element root) {
		NodeList nodes = root.getElementsByTagName("authentication");

		String result = ((Element) nodes.item(0)).getAttribute("result");

		if (result.equalsIgnoreCase("ok")) {
			return new AuthResponse(true);
		} else {
			return new AuthResponse(false);
		}
	}

}
