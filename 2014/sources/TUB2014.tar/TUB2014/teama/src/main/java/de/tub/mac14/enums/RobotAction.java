package de.tub.mac14.enums;

/**
 * This Enum should represent all actions and provide a method to 
 * get the String from the enum
 * 
 */
public enum RobotAction {
	SKIP, ATTACK, GOTO, PARRY, PROBE, SURVEY, INSPECT, REPAIR, BUY, RECHARGE;
	public String toString() {
		return this.name().toLowerCase();
	}
}
