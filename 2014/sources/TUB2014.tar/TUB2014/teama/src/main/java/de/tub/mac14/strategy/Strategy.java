/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package de.tub.mac14.strategy;

import java.util.Random;
import java.util.Set;

import de.tub.mac14.bean.DefaultDecisionBean;
import de.tub.mac14.enums.RobotAction;
import de.tub.mac14.ontology.Edge;
import de.tub.mac14.ontology.Hotspot;
import de.tub.mac14.ontology.Intention;
import de.tub.mac14.ontology.Robot;
import de.tub.mac14.ontology.Vertex;
import de.tub.mac14.ontology.World;

import java.util.ArrayList;

/**
 * This class acts as a Template for all the strategies implemented. It should 
 * provide methods shared by all strategies.
 * @author mattu
 */
public abstract class Strategy {
	
	protected World world;
	
	protected DefaultDecisionBean ddb;
	
	protected Robot me;

	private boolean disabled;

	public Strategy(DefaultDecisionBean bean){
		this.world = bean.getWorld();
		this.ddb = bean;
		this.me = this.world.getMe();
		this.disabled = this.me.isDisabled();
	} 
	
	
	
	/**
	 * This Method shall be implemented by all subclasses. It is intended 
	 * to provide the algorithm use to determine the next move of the Agent
	 * @return The next move, that shall be made
	 */
	public abstract Intention decide();
	
	protected Vertex randomNeighbor() {
		Set<Vertex> neighbors = me.position.getNeighbors();
		Random r = new Random();
		int choice = (neighbors.size() == 1) ? 0 : r.nextInt(neighbors.size());
		int i = 0;
		for (Vertex v : neighbors) {
			if (i == choice) {
				return v;
			}
			i++;
		}
		return null;
	}

	protected void disable() {
		this.disabled = true;
	}

	public boolean isDisabled() {
		return this.disabled;
	}
        
        /**
         * This Method creates your goto-intention in a convenient way. 
         * It checks, weather the vertex is reachable, weather you have enough 
         * energy and weather the edge is surveyed.
         * @param v The Vertex, where the robot shall go
         * @return either a Recharge, Survey or goto-Intention or even null, if something went horribly wrong
         */
	public Intention checkedGoto(Vertex v) {
		if (!me.position.getNeighbors().contains(v)) {
			return null;
		}
		Edge e = me.position.getEdgeTo(v);

		if (!e.isSurveyed() && !me.isDisabled()) {
			return new Intention(RobotAction.SURVEY, null);
		}

		if (e.getValue() > me.energy || me.lastActionResult.startsWith("failed_res")) {
			return new Intention(RobotAction.RECHARGE, null);
		}
		return new Intention(RobotAction.GOTO, v.getFullId());
	}
        
        /**
	 * This Method is used to get the Robots which follow specified master.
	 * If no robot follows the specified master, an Empty arrayList is being returned
	 * @param master 
	 * @return 
	 */
	protected ArrayList<Robot> getOtherFollowingRobots(Robot master){
		ArrayList<Robot> followingRobots = new ArrayList<>();
		
		for(Robot possibleFollower : StrategyAssigner.whoFollowsWho.keySet()){
			if(!possibleFollower.equals(me) && StrategyAssigner.whoFollowsWho.get(possibleFollower).equals(master)){
				followingRobots.add(possibleFollower);
			}
		}
		
		return followingRobots;
		
	}
	
	/**
	 * This Method is used to get the Robots which are assigned to a hotspot. If
	 * no robot follows the specified master, an Empty arrayList is being
	 * returned
	 * 
	 * @param myHotspot
	 * @param selfIncluded also return me if I am assigned.
	 * @param filter only returns robots inside.
	 * @return
	 */
	protected ArrayList<Robot> getOtherHotspotRobots(Hotspot myHotspot, boolean selfIncluded, Set<Vertex> filter) {
		ArrayList<Robot> followingRobots = new ArrayList<>();
		for (Robot possibleFollower : StrategyAssigner.hotspotAssignments.keySet()) {
			if (StrategyAssigner.hotspotAssignments.get(possibleFollower).equals(myHotspot)) {
				if (selfIncluded || !possibleFollower.equals(me)) {
					if (filter == null || filter.contains(possibleFollower.position)) {
						followingRobots.add(possibleFollower);
					}
				}
			}
		}
		return followingRobots;
	}
}
