package de.tub.mac14.strategy;

import de.tub.mac14.bean.DefaultDecisionBean;
import de.tub.mac14.enums.RobotAction;
import de.tub.mac14.ontology.Intention;

public class FallbackStrategy extends Strategy {

	public FallbackStrategy(DefaultDecisionBean bean) {
		super(bean);
	}

	@Override
	public Intention decide() {
		// I am aware that the default fallback shoul be a RECHARGE
		// and not a SKIP. But for now SKIP is easier to debug. (If you see
		// a SKIP in MarsMonitor, you know that the FallbackStrategy was used).
		return new Intention(RobotAction.RECHARGE, null);
	}

}
