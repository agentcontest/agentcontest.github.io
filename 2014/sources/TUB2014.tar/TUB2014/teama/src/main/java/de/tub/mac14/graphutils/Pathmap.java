package de.tub.mac14.graphutils;

/**
 * The constructor of this class takes a start vertex and than builds a
 * pathmap. With a pathmap the caller can easily determine the shortest paths
 * to any node. (Multiple times and without using A* over and over again.)
 */

import java.util.HashMap;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Set;

import de.tub.mac14.common.Tuple;
import de.tub.mac14.ontology.Vertex;

public class Pathmap {

	// <Key, Tuple<distance, previous Node>
	private HashMap<Vertex, Tuple<Integer, Vertex>> pathmap;
	private Set<Vertex> filter;

	public Pathmap(Vertex start, Set<Vertex> filter) {
		this.filter = filter;
		init(start);
	}

	/**
	 * Generates the Pathmap using the Dijkstra's algorithm starting from
	 * the given node.
	 * 
	 * @param start Source node for the algorithm
	 */
	public Pathmap(Vertex start) {
		init(start);
	}

	private void init(Vertex start) {
		pathmap = new HashMap<>();
		pathmap.put(start, new Tuple<Integer, Vertex>(0, null));
		
		
		/**
		 * Helper class only used to order the Priority Queue
		 */
		class VertexDistance implements Comparable<VertexDistance> {
			public final Vertex vertex;
			public final int distance;
			
			public VertexDistance(Vertex vertex, int distance) {
				this.vertex = vertex;
				this.distance = distance;
			}
			
			@Override
			public int compareTo(VertexDistance o) {
				// none of them is infinity
				return distance - o.distance;
				
			}

			/**
			 * Necessarry for removing things in the PriorityQueue.
			 */
			@Override
			public boolean equals(Object o) {
				return ((VertexDistance) o).vertex.equals(vertex);
			}
		}
		

		// Queue ordered by the distance from the start vertex to the given vertex
		PriorityQueue<VertexDistance> priorityQueue = new PriorityQueue<>();
		
		// Add the start node to the queue and to the entries map
		VertexDistance initialVertex = new VertexDistance(start, 0);
		priorityQueue.add(initialVertex);
		
		// While there are vertex to be visited in the queue
		while (!priorityQueue.isEmpty()) {
			// Get the vertex with the smallest distance
			VertexDistance uVertexDistance = priorityQueue.poll();
			Vertex u = uVertexDistance.vertex;
			int distanceToU = pathmap.get(u).getFirst();

			// Visit all neighbors from the vertex
			for (Vertex v : u.getNeighbors()) {
				if (filter != null && !filter.contains(v)) {
					continue;
				}
				int weight = u.getEdgeTo(v).getValue();
				
				int distancePassingByU = distanceToU + weight;
				
				// Only put a new entry into the pathmap if the current path is
				// shorter.
				if (!pathmap.containsKey(v) || distancePassingByU < pathmap.get(v).getFirst()) {
					// remove v from the priority queue (only if this is an
					// update)
					if (pathmap.containsKey(v)) {
						priorityQueue.remove(new VertexDistance(v, pathmap.get(v).first));
					}
					
					// update the distance to v
					pathmap.put(v, new Tuple<Integer, Vertex>(distancePassingByU,u));
					VertexDistance newV = new VertexDistance(v, distancePassingByU);
					priorityQueue.add(newV);
				}
			}
		}
	}

	/**
	 * Return the distance from the start node to the given vertex.
	 * 
	 * @param end The destination vertex
	 * @return The distance to the vertex or -1 if there's no path to the given
	 *         vertex.
	 */
	public int getDistanceTo(Vertex end) {
		if(pathmap.get(end) != null) {
			return pathmap.get(end).getFirst();
		} else {
			return -1;
		}
	}

	
	/**
	 * Generate the path to a destination.
	 * 
	 * @param end The destination vertex
	 * @return A List containing the vertices you must traverse
	 * in order to reach the destination. The list is ordered from
	 * the start node until the destination node. It returns an empty
	 * list if there's no path between the start node and the destination
	 * node.
	 */
	public LinkedList<Vertex> getPath(Vertex end) {
		// Maybe it is more convenient to create
		// a Path class and return it here.
		LinkedList<Vertex> path = new LinkedList<>();
		
		if(pathmap.containsKey(end)) {
			Vertex currentVertex = end;
			
			while(currentVertex != null) {
				path.push(currentVertex);
				currentVertex = pathmap.get(currentVertex).getSecond();
			}
		}
		
		return path;
	}

	public Set<Vertex> getReachable() {
		return pathmap.keySet();
	}
}
