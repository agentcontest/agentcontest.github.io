package de.tub.mac14.strategy;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import de.tub.mac14.bean.DefaultDecisionBean;
import de.tub.mac14.common.Config;
import de.tub.mac14.enums.RobotAction;
import de.tub.mac14.ontology.Hotspot;
import de.tub.mac14.ontology.Hotspots;
import de.tub.mac14.ontology.Intention;
import de.tub.mac14.ontology.Robot;
import de.tub.mac14.ontology.Vertex;

public class SaboteurExploringStrategy extends SaboteurMasterStrategy {

	private static Integer HOTSPOT_JUST_CHECKED = 40;
	private static Integer HOTSPOT_CHECKED_DECAY = 1;
	public static HashMap<Robot, Hotspot> robotsThatExploreVertex = new HashMap<Robot, Hotspot>();
	public static ConcurrentHashMap<Hotspot, Integer> checkedHotspots = new ConcurrentHashMap<Hotspot, Integer>();

	/**
	 * just provide a bean and have everything else on default
	 * 
	 * @param bean
	 */
	public SaboteurExploringStrategy(DefaultDecisionBean bean) {
		super(bean);
	}

	public SaboteurExploringStrategy(DefaultDecisionBean bean,
			SaboteurParams params) {
		super(bean);
		HOTSPOT_JUST_CHECKED = params.getHOTSPOT_JUST_CHECKED() == null ? HOTSPOT_JUST_CHECKED
				: params.getHOTSPOT_JUST_CHECKED();
	}

	@Override
	public Intention decide() {
		decreaseCheckedHotspots();
		// if on the same position as an enemy: attack!
		// gather a list of all enemies
		ArrayList<Robot> enemies = world.getEnemys();
		// iterate all enemies, check if on same position
		for (Robot r : enemies) {
			if (r.position != null && !r.isDisabled() && !probablyDisabled(r)
					&& r.position.equals(me.position)) {
				// EXTERMINATE! EXTERMINATE!
				attacked(r);
				if (decisionDebug)
					System.out.println(">>> attack guy on same spot");
				return new Intention(RobotAction.ATTACK,
						Config.get("GAME_ENEMY_ROBOT_PREFIX") + r.usersuffix);
			}
		}

		// Am I assigned to some hotspot to explore ?
		for (Robot r : robotsThatExploreVertex.keySet()) {
			if (r.equals(me)) {
				return explore(robotsThatExploreVertex.get(r));
			}
		}

		// no hotspots in this world? nothing to do here!
		if (world == null || world.hotspots == null
				|| world.hotspots.hotspots == null) {
			if (decisionDebug)
				System.out.println(">> no hotspots, decide not to decide");
			return null;
		}

		// find hotspots that are no aim for us
		Set<Hotspot> enemyHotspots = world.hotspots.hotspots;
		Set<Hotspot> enemyBases = new HashSet<Hotspot>(enemyHotspots.size());
		for (Hotspot currentHotspot : enemyHotspots) {
			enemyBases.add(currentHotspot);
		}
		// our bases are no enemy bases
		enemyBases.removeAll(StrategyAssigner.hotspotAssignments.values());
		// go to no place where someone else is going
		enemyBases.removeAll(robotsThatExploreVertex.values());
		// go to no place that was already checked recently
		enemyBases.removeAll(checkedHotspots.keySet());
		// and go to the next one in range, update hotspotsThatWillBeExplored
		if (!enemyBases.isEmpty()) {
			int minDistance = Integer.MAX_VALUE;
			Hotspot closestHotspot = null;
			for (Hotspot aim : enemyBases) {
				int temp = ddb.pathmap.getDistanceTo(aim.center);
				if (temp < minDistance) {
					minDistance = temp;
					closestHotspot = aim;
				}
			}
			if (decisionDebug)
				System.out.println(">> decide to invade "
						+ closestHotspot.center.getFullId());
			robotsThatExploreVertex.put(me, closestHotspot);
			RepairerAssistStrategy.assist(me);
			explore(closestHotspot);
		}
		return null;
	}

	/**
	 * 
	 */
	private void decreaseCheckedHotspots() {
		for (Hotspot h : checkedHotspots.keySet()) {
			checkedHotspots.put(h, checkedHotspots.get(h)
					- HOTSPOT_CHECKED_DECAY);
			if (checkedHotspots.get(h) <= 0) {
				checkedHotspots.remove(h);
			}
		}
	}

	/**
	 * explore a Vertex. mark as oke for the next few rounds if we are on this
	 * Vertex
	 * 
	 * @param hotspot
	 */
	private Intention explore(Hotspot hotspot) {
		if (decisionDebug)
			System.out.println(">>> explore my assigned enemy base");
		// if we are on this Vertex then remove from the assignment list
		if (me.position.equals(hotspot.center)) {
			if (decisionDebug)
				System.out.println(">>>> A am here, mark as checked");
			robotsThatExploreVertex.remove(me);
			RepairerAssistStrategy.release(me);
			checkedHotspots.put(hotspot, HOTSPOT_JUST_CHECKED);
		} else {
			// otherwise go there
			if (ddb.pathmap.getPath(hotspot.center).size() > 1)
				return checkedGoto(ddb.pathmap.getPath(hotspot.center).get(1));
		}
		return null;
	}

}
