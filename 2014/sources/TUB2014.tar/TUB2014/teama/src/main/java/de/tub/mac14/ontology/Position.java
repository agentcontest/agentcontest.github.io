package de.tub.mac14.ontology;

import java.util.Set;

public class Position implements Comparable<Position> {
    public int value;
    public Set<Vertex> stand;
	public Set<Vertex> area;

	@Override
	public boolean equals(Object o) {
		return stand.equals(o);
	}

	@Override
	public int hashCode() {
		return stand.hashCode();
	}

	@Override
	public int compareTo(Position o) {
		return Integer.compare(this.value, o.value);
	}
}
