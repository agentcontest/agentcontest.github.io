package de.tub.mac14.strategy;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import de.tub.mac14.bean.DefaultDecisionBean;
import de.tub.mac14.common.Config;
import de.tub.mac14.common.Log;
import de.tub.mac14.enums.RobotAction;
import de.tub.mac14.enums.Team;
import de.tub.mac14.graphutils.PositionFinder;
import de.tub.mac14.ontology.Intention;
import de.tub.mac14.ontology.Position;
import de.tub.mac14.ontology.Robot;
import de.tub.mac14.ontology.Vertex;

public class BottleneckStrategy extends Strategy {

	private int infiltration_rounds = 0;
	public static ConcurrentHashMap<Robot, Position> positionAssignments = new ConcurrentHashMap<>();

	public BottleneckStrategy(DefaultDecisionBean bean) {
		super(bean);
	}

	@Override
	public Intention decide() {
		synchronized (positionAssignments) {
			Position pos = positionAssignments.get(me);
			if (pos == null) {
				return null;
			}
			Vertex goal = pos.stand.iterator().next();
			Log.log("debug.strategy.bottleneck", me.username + " GOTO " + goal);
			Set<Robot> goalRobots = world.getRobotsOn(goal);
			for (Robot r : goalRobots) {
				if (r.team == Team.ENEMY) {
					// Try to go one step into the bottleneck
					int count = 0;
					Vertex candidate = null;
					for (Vertex v : goal.getNeighbors()) {
						if (pos.area.contains(v)) {
							count++;
							candidate = v;
						}
					}
					if (count == 1) {
						goal = candidate;
						Log.log("debug.strategy.bottleneck", me.username + " GOTO " + goal + " instead");
					}
				}
			}
			
			// check infiltration
			boolean infiltrated = false;
			for (Robot r : world.enemyRobots) {
				if (r.position == null) {
					continue;
				}
				if (pos.area.contains(r.position)) {
					infiltrated = true;
					break;
				}
			}
			if (infiltrated) {
				infiltration_rounds++;
			} else {
				infiltration_rounds--;
			}
			if (infiltration_rounds > Config.getInt("INFILTRATION_THRESHOLD")) {
				Log.log("debug.strategy.bottleneck", me.username + " Infiltration detected: " + goal);
				positionAssignments.remove(me);
				HashSet<Position> remove = new HashSet<Position>();
				remove.add(pos);
				PositionFinder.goodPositions.removeAll(remove);
			}
			if (goal.equals(me.position)) {
				return new Intention(RobotAction.RECHARGE, null);
			}

			if (ddb.pathmap.getDistanceTo(goal) == -1) {
				return null;
			}
			Vertex next = ddb.pathmap.getPath(goal).get(1);
			return checkedGoto(next);
		}
	}

}
