package de.tub.mac14.common;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Properties;

public class Config {
	private static final String PATH_TO_CONFIG = "src/main/resources/Config.properties";
	
	private static HashMap<String, String> configMap;
	
	private static Properties config;

	static {
		config = new Properties();
		configMap = new HashMap<>();
		BufferedInputStream stream;
		try {
			stream = new BufferedInputStream(
					new FileInputStream(PATH_TO_CONFIG));
			config.load(stream);
			
			Enumeration<String> propNames = (Enumeration<String>) config.propertyNames();
			while (propNames.hasMoreElements()) {
				String propName = propNames.nextElement();
				configMap.put(propName, config.getProperty(propName));
			}
						
			stream.close();
		} catch (FileNotFoundException e) {
			System.err.println("Config File not found.");
			System.exit(0);
		} catch (IOException e) {
			System.err.println("Config file invalid.");
			System.err.println(e.getMessage());
			System.exit(0);
		}
	}


	
	public static String get(String key) {
		return configMap.get(key);
	}

	public static int getInt(String key) {
		return Integer.parseInt(configMap.get(key));
	}
	
}
