/**
 * A vertex is a node in the game World.
 * Each vertex has a unique id, a value and some edges to other vertices.
 * A vertex shares its Edge-Objects with its neighbors.
 * @author Felix
 */

package de.tub.mac14.ontology;

import de.tub.mac14.common.Config;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import de.dailab.jiactng.agentcore.knowledge.IFact;

public class Vertex implements IFact, Cloneable {

	private static final long serialVersionUID = 4424524903037020283L;
	private Integer id;
	private Integer value; // -1 if unknown
	transient private ConcurrentHashMap<Vertex, Edge> edges;

	private static final String ID_PREFIX = "v";

	/**
	 * Constructor
	 */
	public Vertex(int id) {
		this.id = id;
		this.value = -1;
		this.edges = new ConcurrentHashMap<Vertex, Edge>(8);
	}

	public int getId() {
		return id;
	}

	public String getFullId() {
		return ID_PREFIX + id;
	}
	
	/**
	 * Returns a list of adjacent neighbors.
	 */
	public Set<Vertex> getNeighbors() {
		return new HashSet<Vertex>(edges.keySet());
	}

	public int getValue() {
		return (value == (-1)) ? Config.getInt("DEFAULT_VERTEX_VALUE") : value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public boolean isProbed() {
		return (this.value != -1);
	}

	public boolean addEdge(Vertex v) {
		if (!this.edges.containsKey(v)) {
			Edge e;
			if ((e = v.getEdgeTo(this)) != null) {
				edges.put(v, e);
			} else {
				edges.put(v, new Edge(this, v));
			}
			return true;
		}
		return false;
	}

	public Edge getEdgeTo(Vertex vertex) {
		return this.edges.get(vertex);
	}

	@Override
	public boolean equals(Object o) {
		Vertex other = (Vertex) o;
		return (id.equals(other.getId()));
	}

	public String toString() {
		return "v" + id;
	}

	/**
	 * Returns all neighbors in a i-surrounding. If i is 2 all neighbors and its
	 * neighbors are returned. Recursive.
	 */
	public Set<Vertex> getNeighbors(int i, boolean selfIncluded) {
		if (i == 0) {
			return new HashSet<Vertex>();
		}
		HashSet<Vertex> n = new HashSet<Vertex>();
		if (selfIncluded) {
			n.add(this);
		}
		for (Vertex v : this.getNeighbors()) {
			if (!n.contains(v)) {
				n.add(v);
				n.addAll(v.getNeighbors(i - 1, false));
			}
		}
		return n;
	}

	@Override
	public int hashCode() {
		return id.hashCode();
	}
}
