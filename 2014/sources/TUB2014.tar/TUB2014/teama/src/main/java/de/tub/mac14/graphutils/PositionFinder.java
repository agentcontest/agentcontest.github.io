package de.tub.mac14.graphutils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

import de.tub.mac14.common.Config;
import de.tub.mac14.common.Log;
import de.tub.mac14.enums.Role;
import de.tub.mac14.enums.Team;
import de.tub.mac14.ontology.Hotspot;
import de.tub.mac14.ontology.Position;
import de.tub.mac14.ontology.Robot;
import de.tub.mac14.ontology.Vertex;
import de.tub.mac14.ontology.World;
import de.tub.mac14.strategy.BottleneckStrategy;

public class PositionFinder {
	public static List<Position> goodPositions = new CopyOnWriteArrayList<Position>();

	private final static int THRESHOLD = Config.getInt("POSITION_THRESHOLD");
	private final static int AMOUNT = Config.getInt("POSITION_AMOUNT");
	private final World world;
	private int currentAmount;

	public PositionFinder(World world) {
		this.world = world;
	}

	public void updateGoodPositions(Vertex candidate) {
		if (!candidate.isProbed()) {
			return;
		}
		
		// check if this is inside a hotspot
		for (Hotspot h : world.hotspots.hotspots) {
			if (h.allVertices.contains(candidate)) {
				return;
			}
		}

		// check if we are already in an area of a bottleneck stand
		for (Position p : goodPositions) {
			if (p.area.contains(candidate) && !p.stand.contains(candidate)) {
				return;
			}
		}
		Set<Vertex> visited = new HashSet<Vertex>();
		Set<Vertex> area = new HashSet<Vertex>();
		visited.add(candidate);
		int value = candidate.getValue();
		for (Vertex n : candidate.getNeighbors()) {
			visited.clear();
			visited.add(candidate);
			currentAmount = 0;
			int res = bfs(n, visited);
			if (res != 0) {
				area.addAll(visited);
				value += res;
			}
			
		}
		if (value >= THRESHOLD) {
			Log.log("debug.strategy.bottleneck", "Found new Bottleneck: " + candidate + " value = " + value + "  " + area.toString());
			// Found a bottleneck
			// Remove other "good Positions" if this good Position contains
			// the others.
			Set<Position> remove = new HashSet<Position>();
			for (Position p : goodPositions) {
				if (area.contains(p.stand.iterator().next())) {
					Log.log("debug.strategy.bottleneck", "Removed Bottleneck " + p.stand.iterator().next());
					remove.add(p);
				}
			}
			goodPositions.removeAll(remove);
			Position newP = new Position();
			newP.stand = new HashSet<Vertex>(1);
			newP.stand.add(candidate);
			newP.area = new HashSet<Vertex>(area);
			newP.value = value;
			goodPositions.add(newP);
			reassign();
		}
	}

	private void reassign() {
		synchronized (BottleneckStrategy.positionAssignments) {
			BottleneckStrategy.positionAssignments.clear();
			ArrayList<Position> copyGoodPositions = new ArrayList<Position>(goodPositions);
			Collections.sort(copyGoodPositions);
			for (int i = copyGoodPositions.size() - 1; i >= 0; i--) {
				Position pos = copyGoodPositions.get(i);

				// Find nearest Sentinel
				Pathmap p = new Pathmap(pos.stand.iterator().next());
				Robot bestRobot = null;
				int bestDistance = 99999;
				for (Robot r : world.filterRobots(Team.WE, Role.SENTINEL)) {
					if (BottleneckStrategy.positionAssignments.containsKey(r)) {
						continue;
					}
					int distance = p.getDistanceTo(r.position);
					if (distance >= 0 && distance < bestDistance) {
						bestRobot = r;
						bestDistance = distance;
					}
				}
				if (bestRobot != null) {
					BottleneckStrategy.positionAssignments.put(bestRobot, pos);
					Log.log("debug.strategy.bottleneck", "Assigned " + bestRobot.username + " to " + pos.stand.iterator().next());
				}
			}
		}
	}

	private int bfs(Vertex current, Set<Vertex> visited) {
		currentAmount++;
		if (currentAmount >= AMOUNT) {
			return 0;
		}
		visited.add(current);
		if (!current.isProbed()) {
			return 0;
		}
		int sum = current.isProbed() ? current.getValue() : 0;
		for (Vertex n : current.getNeighbors()) {
			if (visited.contains(n)) {
				continue;
			}
			int ret = bfs(n, visited); // does this work?
			if (ret == 0) {
				return 0;
			}
			sum += ret;
		}
		return sum;
	}
}
