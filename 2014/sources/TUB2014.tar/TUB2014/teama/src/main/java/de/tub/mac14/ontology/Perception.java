package de.tub.mac14.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac14.connection.parsinghelper.EdgeContainer;
import de.tub.mac14.connection.parsinghelper.VerticesContainer;
import java.util.ArrayList;
/**
 * ATM, A Simple container file, that holds the contents of the Received
 * perception
 * @author mattu
 */
public class Perception implements IFact {
	private static final long serialVersionUID = 8856781490395163392L;

	public String username;
	
	public long timestamp;
        
        public long deadline;
        
        public int simulationStep;
        
	public String id;
        
        
        public TeamStatus teamStatus;
        
        public VerticesContainer verticies;
		
		public EdgeContainer edges;
		
		public ArrayList<RobotStatus> robots;
		
	//TODO add parsed perception here
	
	public Perception(String username) {
		this.username = username;
		this.robots = new ArrayList<>();
	}
        
        
}
