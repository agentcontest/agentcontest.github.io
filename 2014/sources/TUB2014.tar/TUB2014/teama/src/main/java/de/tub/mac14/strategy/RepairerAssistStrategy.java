package de.tub.mac14.strategy;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;

import de.tub.mac14.bean.DefaultDecisionBean;
import de.tub.mac14.ontology.Intention;
import de.tub.mac14.ontology.Robot;
import de.tub.mac14.ontology.Vertex;

public class RepairerAssistStrategy extends Strategy {
	// first Robot assisting other Robot
	private static HashMap<Robot, Robot> assistingMap = new HashMap<Robot, Robot>();
	private static LinkedList<Robot> pending = new LinkedList<Robot>();
	static boolean assistingDebug = true;

	public RepairerAssistStrategy(DefaultDecisionBean bean) {
		super(bean);
	}

	@Override
	public Intention decide() {
		if (me == null || me.position == null) {
			return null;
		}
		if (assistingMap.containsKey(me)) {
			return decideToAssist(assistingMap.get(me));
		} else {
			if (!pending.isEmpty()) {
				if (assistingDebug)
					System.out.println(">> assist: poll pending list");
				assistingMap.put(me, pending.poll());
				return decideToAssist(assistingMap.get(me));
			}
		}
		return null;
	}

	private Intention decideToAssist(Robot robot) {
		List<Vertex> pathToRobot = ddb.pathmap.getPath(robot.position);

		// only go to the node if there are more than one node between them
		if (pathToRobot.size() > 3) {
			if (assistingDebug)
				System.out.println(">> assist: goto " + robot.username);
			Vertex destination = pathToRobot.get(1);
			return checkedGoto(destination);
		}
		return null;
	}

	/**
	 * call this number if YOU! want YOUR ROBOT to be assisted by this beautiful
	 * Repairer for just 5000$
	 * 
	 * @param poorGuy
	 */
	public static void assist(Robot poorGuy) {
		if (assistingDebug)
			System.out.println(">> assist: " + poorGuy.username
					+ " in the future");
		pending.add(poorGuy);
	}

	/**
	 * not satisfied with our service ? well f*#k you!
	 * @param poorGuy
	 */
	public static void release(Robot poorGuy) {
		if (assistingDebug)
			System.out.println(">> assist: release assisting of "
					+ poorGuy.username);
		pending.remove(poorGuy);
		LinkedList<Robot> depricated = new LinkedList<Robot>();
		for (Entry<Robot, Robot> entry : assistingMap.entrySet()) {
			if (entry.getValue().equals(poorGuy)) {
				depricated.add(entry.getKey());
			}
		}
		for (Robot r : depricated) {
			assistingMap.remove(r);
		}
	}

}
