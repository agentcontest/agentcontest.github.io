/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package de.tub.mac14.ontology;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * This Class represents the information about the team sent from the 
 * server to the Agents.
 * @author mattu
 */
public class TeamStatus implements Serializable{
    
	private static final long serialVersionUID = 1640067273968667648L;

	public int lastStepScore;
    
	public int money;
    
	public int score;
    
	public int zonesScore;
    
    public ArrayList<String> achievementNames;
    
	
	public TeamStatus(){
        achievementNames = new ArrayList<>();

	}
    
}
