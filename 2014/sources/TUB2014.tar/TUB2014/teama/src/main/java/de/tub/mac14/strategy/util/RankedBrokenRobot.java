package de.tub.mac14.strategy.util;

import java.util.LinkedList;

import de.tub.mac14.ontology.Robot;
import de.tub.mac14.ontology.Vertex;

/**
 * find out who to kill first by ranking this fine comparable in an
 * exquisite list of enemies
 * 
 * @author jens
 * 
 */
public class RankedBrokenRobot implements Comparable<RankedBrokenRobot> {
	public static int[] ROLE_BONI = { 2, 6, 4, 0, 0 };
	public Robot self;
	public Robot me;
	public int roleBonus;
	public LinkedList<Robot> otherRepairers;

	public RankedBrokenRobot(Robot r, Robot me, LinkedList<Robot> otherRepairers) {
		self = r;
		this.me = me;
		this.otherRepairers = otherRepairers;
		roleBonus = ROLE_BONI[self.role.ordinal()];
		
	}

	public int getScore() {
		// TODO jens: get more complicated
//		return (startValue - distance + roleBonus) * 100 - self.usersuffix;
		for (Robot r : otherRepairers) {
			if (r.position.equals(self.position) && !r.equals(self)) {
				return 0;
			}
		}
		int samePositionBoni = (me.position.equals(self.position)) ? 1 : 0;
		return (roleBonus + samePositionBoni);

	}

	@Override
	public int compareTo(RankedBrokenRobot o) {
		return Integer.compare(getScore(), o.getScore());
	}

}

