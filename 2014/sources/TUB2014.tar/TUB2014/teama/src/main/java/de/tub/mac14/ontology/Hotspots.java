package de.tub.mac14.ontology;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Stack;

import de.tub.mac14.common.Config;
import de.tub.mac14.graphutils.Pathmap;

public class Hotspots {
	private final World world;

	/**
	 * A mapping from all vertices to a custom value.
	 */
	private HashMap<Vertex, Double> tempGraph;

	/**
	 * A Set of regions. In a region all vertices are mapped to its value.
	 */
	HashSet<HashMap<Vertex, Double>> regions;

	/**
	 * A collection of "hotspots". Hotspots are special vertices with high
	 * values around. <center, Tuple<sizeOfRegion, valueSum>>
	 */
	public HashSet<Hotspot> hotspots;

	private long timer;

	public Hotspots(World world) {
		timer = System.currentTimeMillis();
		this.world = world;
		blur();
		threshold();
		findRegions();
		findHotspots();
		timer = System.currentTimeMillis() - timer;
	}

	/**
	 * _Reads_ regions and _creates_ hotspots.
	 */
	private void findHotspots() {
		hotspots = new HashSet<>(regions.size());
		for (HashMap<Vertex, Double> region : regions) {
			// We need to find the subgraphs center.
			// We do this by finding the one vertex for wich the largest
			// distance to all other vertices is minimized.

			double value_sum = 0.0;
			Set<Vertex> filter = region.keySet();
			int smallest_largest_distance = 999999;
			Vertex center = null;
			// iterate through all vertices in the region
			for (Entry<Vertex, Double> entry : region.entrySet()) {
				Vertex v = entry.getKey();
				Double value = entry.getValue();
				int largest_distance = largest_distance(region, filter, v);
				if (largest_distance < smallest_largest_distance) {
					smallest_largest_distance = largest_distance;
					center = v;
				}
				value_sum += value;
			}
			// create new Hotspot
			Hotspot hotspot = new Hotspot(center, region.keySet(), value_sum);
			hotspots.add(hotspot);
		}
	}

	private int largest_distance(HashMap<Vertex, Double> region, Set<Vertex> filter, Vertex v) {
		Pathmap p = new Pathmap(v, filter);

		int largest_distance = -999999;
		// iterate through all vertices in the region
		for (Vertex v2 : region.keySet()) {
			int distance = p.getDistanceTo(v2);
			if (distance > largest_distance) {
				largest_distance = distance;
			}
		}
		return largest_distance;
	}

	/*
	 * _Reads_ tempGraph and _creates_ regions.
	 */
	private void findRegions() {
		// Use a Iterator for the HashMap so we can remove the entries on the
		// fly.
		Iterator<Vertex> it = tempGraph.keySet().iterator();
		
		// At the first run remove all entries with 0.0 in it.
		while (it.hasNext()) {
			Vertex v = it.next();
			if (tempGraph.get(v).equals(0.0)) {
				it.remove();
			}
		}
		
		// Now create the set of regions.
		// Use a DFS for that.
		regions = new HashSet<HashMap<Vertex, Double>>();
		it = tempGraph.keySet().iterator();
		while (it.hasNext()) {
			HashMap<Vertex, Double> region = new HashMap<Vertex, Double>();
			Stack<Vertex> stack = new Stack<Vertex>();
			HashSet<Vertex> visited = new HashSet<Vertex>();
			stack.push(it.next());
			while (!stack.isEmpty()) {
				Vertex current = stack.pop();
				visited.add(current);
				region.put(current, tempGraph.get(current));
				for (Vertex nb : current.getNeighbors()) {
					if (tempGraph.containsKey(nb) && !visited.contains(nb)) {
						stack.push(nb);
					}
				}
			}
			// Region building finished
			regions.add(region);
		}

	}

	/**
	 * _Reads_ the world and _writes_ in tempGraph the blured values of every
	 * vertex.
	 */
	private void blur() {
		tempGraph = new HashMap<Vertex, Double>(world.numVertices);
		for (Vertex v : world.getGraph()) {
			int sum_nb = v.getValue();
			for (Vertex v_nb : v.getNeighbors()) {
				sum_nb += v_nb.getValue();
			}
			Double blured = ((double) sum_nb) / (v.getNeighbors().size() + 1);
			tempGraph.put(v, blured);
		}
	}

	/**
	 * Set values of tempGraph under a certain threshold to 0
	 */
	private void threshold() {
		for (Entry<Vertex, Double> entry : tempGraph.entrySet()) {
			if (entry.getValue() < Config.getInt("HOTSPOTS_THRESHOLD")) {
				tempGraph.put(entry.getKey(), 0.0);
			}
		}
	}
	
	@Override
	public String toString() {
		String s = "";
		s += "------------Hotspots-----------\n";
		for (Hotspot h : hotspots) {
			s += h.center.getFullId() + ": Size: " + h.size() + ", Value: "
					+ h.value + "\n";
		}
		s += "-----------" + timer + "ms------------\n";
		return s;
	}
}
