package de.tub.mac14.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac14.common.Config;
import de.tub.mac14.common.Log;
import de.tub.mac14.common.Stats;
import de.tub.mac14.common.Tuple;
import de.tub.mac14.common.Utils;
import de.tub.mac14.enums.Role;
import de.tub.mac14.enums.Team;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Set;

public class World implements IFact, Cloneable {
	private static final long serialVersionUID = -2750428164254110909L;

	public String username;
	public Integer usersuffix; // same as username except the prefix

	public int id;
	public Integer perceptionsReceived;
	public Object lock = new Object();

	public Integer numVertices;
	public Integer numEdges;
	public Integer probedVertices;
	public Integer surveyedEdges;

	private ArrayList<Vertex> vertices;

	public Hotspots hotspots;

	// Note that the first Robot is named "TUB1" and not "TUB0"
	// So everything is shifted by 1.
	public ArrayList<Robot> ourRobots;
	public ArrayList<Robot> enemyRobots;

	public int money = -1;
	public int score = -1;

	/**
	 * Constructor Should be called when receiving sim-start. Initialized
	 * vertices and robots.
	 */
	public World(String username, Integer numvertices, Integer numedges) {
		this.perceptionsReceived = 0;
		this.username = username;
		this.usersuffix = Utils.getNumericalSuffix(username);
		this.numVertices = numvertices;
		this.numEdges = numedges;
		this.probedVertices = 0;
		this.surveyedEdges = 0;
		this.vertices = new ArrayList<Vertex>(numvertices);
		for (int i = 0; i < numvertices; i++) {
			vertices.add(new Vertex(i));
		}
		int numRobots = Config.getInt("GAME_NUM_ROBOTS");
		this.ourRobots = new ArrayList<Robot>(numRobots);
		this.enemyRobots = new ArrayList<Robot>(numRobots);
		for (int i = 1; i <= numRobots; i++) {
			String ourUsername = Config.get("GAME_OUR_ROBOT_PREFIX") + i;
			String enemyUsername = Config.get("GAME_ENEMY_ROBOT_PREFIX") + i;
			ourRobots.add(new Robot(ourUsername, Team.WE));
			enemyRobots.add(new Robot(enemyUsername, Team.ENEMY));
		}
		System.out.println("New World created with numVertices = "
				+ numvertices);
	}

	public Robot getMe() {
		return getOurRobot(usersuffix);
	}

	public Robot getOurRobot(int usernameSuffix) {
		return ourRobots.get(usernameSuffix - 1);
	}

	public Robot getEnemyRobot(int usernameSuffix) {
		return enemyRobots.get(usernameSuffix - 1);
	}

	/**
	 * Filters ourRobots and enemyRobots according to the given parameters
	 * 
	 * @param team
	 *            can be null (both teams are considered)
	 * @param role
	 *            can be null (all roles are considered)
	 */
	public LinkedList<Robot> filterRobots(Team team, Role role) {
		LinkedList<Robot> list = new LinkedList<Robot>();
		if (team == Team.WE || team == null) {
			list = _filterRobots(list, ourRobots, role);
		}
		if (team == Team.ENEMY || team == null) {
			list = _filterRobots(list, enemyRobots, role);
		}
		return list;
	}

	private LinkedList<Robot> _filterRobots(LinkedList<Robot> list,
			ArrayList<Robot> robots, Role role) {
		for (Robot r : robots) {
			if (r.role == role || role == null) {
				list.add(r);
			}
		}
		return list;
	}

	/**
	 * Gets a robot by its username. Returns null if robot doesn't exist.
	 */
	@Deprecated
	// Use getOurRobot() and getEnemyRobot() instead!
	public Robot getRobot(String username) {
		int index = Utils.getNumericalSuffix(username);

		if (username.startsWith(Config.get("GAME_OUR_ROBOT_PREFIX"))) {
			return getOurRobot(index);
		} else {
			return getEnemyRobot(index);
		}
	}

	/**
	 * get all enemies and hunt them down
	 * 
	 * @return a new list of enemy robots so nothing get's changed here
	 */
	public ArrayList<Robot> getEnemys() {
		return new ArrayList<Robot>(enemyRobots);
	}
	
	public ArrayList<Robot> getOurRobots() {
		return new ArrayList<Robot>(ourRobots);
	}
	
	public ArrayList<Vertex> getGraph(){
		return vertices;
	}

	public Vertex getVertex(int index) {
		return vertices.get(index);
	}

	public ArrayList<Vertex> getVertices() {
		return this.vertices;
	}
	
	/**
	 * Returns an iterator which can be used to iterate over all vertices in a
	 * BFS fashion. So the first vertex next() returns is the start vertex. Then
	 * its neighbors, then the neighbors neighbors...
	 * 
	 * @param start
	 * @return
	 */
	public Iterator<Vertex> getVertices(Vertex start) {
		class VertexIterator implements Iterator<Vertex> {

			HashSet<Vertex> visited;
			HashSet<Vertex> current;
			HashSet<Vertex> next;

			public VertexIterator(Vertex start) {
				visited = new HashSet<Vertex>();
				current = new HashSet<Vertex>();
				next = new HashSet<Vertex>();
				current.add(start);
			}

			@Override
			public boolean hasNext() {
				return (!(current.isEmpty() && next.isEmpty()));
			}

			@Override
			public Vertex next() {
				if (current.isEmpty()) {
					current = next;
					next = new HashSet<Vertex>();
				}
				Vertex v = current.iterator().next();
				current.remove(v);
				for (Vertex n : v.getNeighbors()) {
					if (!visited.contains(n) && !current.contains(n)) {
						next.add(n);
					}
				}
				visited.add(v);
				return v;
			}

			@Override
			public void remove() {
				// Not used
			}
		}
		return new VertexIterator(start);
	}

	public HashSet<Edge> getEdges() {
		HashSet<Edge> set = new HashSet<Edge>();
		for (Vertex v1 : this.vertices) {
			for (Vertex v2 : v1.getNeighbors()) {
				set.add(v1.getEdgeTo(v2));
			}
		}
		return set;
	}

	/**
	 * Process a perception.
	 */
	public void update(Perception perception) {
		if (perception.id != null) {
			synchronized (this.lock) {
				int pId = Integer.parseInt(perception.id);
				if (pId > this.id) {
					newRound();
					this.id = pId;
				}
			}

		}

		if (perception.robots != null) {
			for (RobotStatus robStat : perception.robots) {
				this.updateRobot(this.getRobot(robStat.name), robStat);
			}
		}

		// Probe vertices
		if (perception.verticies != null) {
			for (Tuple<Integer, Integer> v : perception.verticies.probedVertices) {
				probeVertex(v.getFirst(), v.getSecond());
			}
		}

		// Add edges
		if (perception.edges != null) {
			for (Tuple<Tuple<Integer, Integer>, Integer> edge : perception.edges.edges) {
				int from = edge.getFirst().getFirst();
				int to = edge.getFirst().getSecond();
				Integer value = edge.getSecond();
				newEdge(from, to);

				// Survey edge
				if (value != null) {
					surveyEdge(from, to, value);
				}
			}
		}

		// update money and score
		if (perception.teamStatus != null) {
			this.money = perception.teamStatus.money;
			this.score = perception.teamStatus.score;
		}

		synchronized (this.lock) {
			perceptionsReceived += 1;
			if (this.allPerceptionsReceived()) {
				// All perceptions received. Wake up Agents.
				lock.notifyAll();
			}
		}

		// update stats
		if (getMe().lastActionResult != null
				&& getMe().username.equals(perception.username)
				&& getMe().lastActionResult.startsWith("fail")) {
			if (getMe().lastActionResult.startsWith("failed_random")) {
				Stats.getInstance().failedRandom++;
			} else if (getMe().lastActionResult.startsWith("failed_in_range")) {
				Stats.getInstance().failedRange++;
			} else if (getMe().lastActionResult.startsWith("failed_att")) {
				Stats.getInstance().failedAttacked++;
			} else {
				if (getMe().lastAction.startsWith("noAction")) {
					Stats.getInstance().failedNoAction++;
				} else {
					Stats.getInstance().failed++;
					Log.log("error", getMe().username + ": " + getMe().lastAction + " - " + getMe().lastActionResult);
				}
			}
		}
	}

	/**
	 * Inserts a new edge. Can be called multiple times with the same vertices.
	 */
	void newEdge(int v1, int v2) {

		Vertex vertex1 = getVertex(v1);
		Vertex vertex2 = getVertex(v2);
		if (vertex1.addEdge(vertex2)) {
			vertex2.addEdge(vertex1);
		}
	}

	void probeVertex(int v, int value) {
		Vertex vertex = getVertex(v);
		if (!vertex.isProbed()) {
			this.probedVertices++;
		}
		vertex.setValue(value);
	}

	public boolean allProbed() {
		return this.numVertices.equals(this.probedVertices);
	}

	public boolean allSurveyed() {
		return this.numEdges.equals(this.surveyedEdges);
	}

	void surveyEdge(int v1, int v2, int value) {
		Vertex vertex1 = getVertex(v1);
		Vertex vertex2 = getVertex(v2);

		Edge edge = vertex1.getEdgeTo(vertex2);
		if (edge == null) {
			throw new IllegalArgumentException("Edge to survey not found");
		}
		if (!edge.isSurveyed()) {
			this.surveyedEdges++;
		}
		edge.setValue(value);
	}

	public String toString() {
		String ret = "";
		for (Vertex v : vertices) {
			ret += v + "\n";
		}
		return ret;
	}

	/**
	 * Main method for testing things.
	 */
	public static void main(String[] args) {
		World world = new World("A5", 4, 6);
		world.newEdge(0, 1);
		world.newEdge(1, 2);
		world.newEdge(3, 2);
		world.newEdge(3, 0);

		world.newEdge(0, 1); // duplicate
		world.newEdge(1, 0); // duplicate
		// world.newEdge(1, 1); // invalid -> Exception
		// world.newEdge(4, 0); // invalid -> Exception

		System.out.println(world);
		Vertex v0 = world.getVertex(0);
		Vertex v1 = world.getVertex(1);
		System.out.println(v1.getEdgeTo(v0));
		System.out.println("Probe Vertex...");
		world.probeVertex(0, 5);

		System.out.println(world);

		System.out.println("Survey Edge...");
		world.surveyEdge(0, 1, 4);

		System.out.println(world);

		System.out.println(world.getMe());
		System.out.println(world.getEnemyRobot(27));
		System.out.println(world.getRobot("A27"));
	}

	private void updateRobot(Robot robo, RobotStatus stat) {
		robo.username = stat.name;
		robo.energy = stat.energy == null ? robo.energy : stat.energy;
		robo.health = stat.health == null ? robo.health : stat.health;
		robo.lastAction = stat.lastAction == null ? robo.lastAction
				: stat.lastAction;
		robo.lastActionParam = stat.lastActionParam == null ? robo.lastActionParam
				: stat.lastActionParam;
		robo.lastActionResult = stat.lastActionResult == null ? robo.lastActionResult
				: stat.lastActionResult;
		robo.maxEnergy = stat.maxEnergy == null ? robo.maxEnergy
				: stat.maxEnergy;
		robo.maxEnergyDisabled = stat.maxEnergyDisabled == null ? robo.maxEnergyDisabled
				: stat.maxEnergyDisabled;
		robo.maxHealth = stat.maxHealth == null ? robo.maxHealth
				: stat.maxHealth;
		robo.position = stat.position == null ? robo.position : this
				.getVertex(Utils.getNumericalSuffix(stat.position));
		robo.role = stat.role == null ? robo.role : Role
				.getRoleFromString(stat.role);
		robo.visRange = stat.visRange == null ? robo.visRange : stat.visRange;
		robo.zoneScore = stat.zoneScore == null ? robo.zoneScore
				: stat.zoneScore;
		robo.strength = stat.strength == null ? robo.strength : stat.strength;
	}

	public void updateHotspots() {
		hotspots = new Hotspots(this);
	}

	public void newRound() {
		for (Robot r : enemyRobots) {
			r.position = null;
		}
		this.perceptionsReceived = 0;
	}

	public Set<Robot> getRobotsOn(Vertex v) {
		HashSet<Robot> robots = new HashSet<>();
		for (Robot r : this.enemyRobots) {
			if (r.position != null && r.position.equals(v)) {
				robots.add(r);
			}
		}
		for (Robot r : this.ourRobots) {
			if (r.position != null && r.position.equals(v)) {
				robots.add(r);
			}
		}
		return robots;
	}

	public boolean allPerceptionsReceived() {
		if (perceptionsReceived.equals(Config.getInt("GAME_NUM_ROBOTS"))) {
			return true;
		} else {
			return false;
		}
	}
}
