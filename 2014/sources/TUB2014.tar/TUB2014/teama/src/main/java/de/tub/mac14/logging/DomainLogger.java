/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package de.tub.mac14.logging;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;

/**
 *
 * @author mattu
 */
public class DomainLogger {
	
	private HashMap<String, Logger> loggers;
	StringBuilder b;
	
	private ArrayList<String> mainLogs;
	
	public DomainLogger(String[] domains, boolean append){
		if(DomainLogger.hasDublicates(domains)) throw new IllegalArgumentException("Domain names contains dublicates, see: " + Arrays.toString(domains) );
		
		
		loggers = new HashMap<>();
		mainLogs = new ArrayList<>();
		b = new StringBuilder();
		for(String domainString : domains){
			String[] loggerpath = domainString.split("\\.");
			if(!this.loggers.containsKey(loggerpath[0])){
				this.loggers.put(loggerpath[0], new Logger(loggerpath[0], loggerpath[0] + ".log", append));
			}
			Logger currentLogger = this.loggers.get(loggerpath[0]);
			
			for(int i = 1; i < loggerpath.length; i++){
				String fName = this.getDotSeparatedString(Arrays.copyOfRange(loggerpath, 0, i+1)) + ".log";
				if(!currentLogger.hasChild(loggerpath[i])){
					currentLogger.addChild(new Logger(loggerpath[i], fName, append));
				}
				currentLogger = currentLogger.getChildByName(loggerpath[i]);
				
			}
		}
	}
	
	public DomainLogger(){
		loggers = new HashMap<>();
		mainLogs = new ArrayList<>();
		b = new StringBuilder();
	}
	
	public void addLogger(Logger logger){
		if(logger == null) throw new IllegalArgumentException("Given Logger is null!");
		if(logger.name.isEmpty()) throw new IllegalArgumentException("Logger does not have a name!");
		if(logger.name.split("\\.").length == 1){
			this.loggers.put(logger.name, logger);
		}else{
			Logger parentLogger = retrieveLoggerAtDepth(logger.name, logger.name.split("\\.").length-1);
			if(parentLogger == null) throw new IllegalArgumentException("Parent Logger has not been found!" + logger.name);
			parentLogger.addChild(logger);
			if(logger.isMain) this.mainLogs.add(logger.name);
		}
		
	}
	
	public void setMainLog(String log){
		
		Logger newMain = this.retrieveLogger(log);
		if (newMain == null) {
			throw new IllegalArgumentException("Given Logger not found!" + log);
		}

		for(String l : mainLogs){
			this.retrieveLogger(l).unmakeMainLog();
		}
		newMain.makeMainLog();
		this.mainLogs.add(log);
	}
	
	public void addMainLog(String log){
		Logger newMain = this.retrieveLogger(log);
		if (newMain == null) {
			throw new IllegalArgumentException("Given Logger not found!" + log);
		}
		newMain.makeMainLog();
		this.mainLogs.add(log);
	}
	
	void addMainLogIgnore(String log){
		this.mainLogs.add(log);
	}
	
	public void resetMainLog(){
		this.mainLogs.clear();
	}
	
	public void log(String domain, String msg){
		StackTraceElement caller = Thread.currentThread().getStackTrace()[3];
		
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTimeInMillis(System.currentTimeMillis());
		this.goDownAndLog(domain, this.buildOutput(caller,domain,  msg));
//		String[] loggerpath = domain.split("\\.");
//		Logger currentLogger = this.loggers.get(loggerpath[0]);
//		if(currentLogger == null) throw new IllegalArgumentException("Given Logger not found" + loggerpath[0]);
//		currentLogger.log(this.buildOutput(cal, caller,domain,  msg));
//		for(int i = 1; i < loggerpath.length; i++){
//			//iterate over the logger path to make it print out and throw an exception if not found
//			if(currentLogger.hasChild(loggerpath[i])){
//				currentLogger = currentLogger.getChildByName(loggerpath[i]);
//				currentLogger.log(this.buildOutput(cal, caller,domain,  msg));
//			}else{
//				throw new IllegalArgumentException("Given Logger-Domain not found!" + domain);
//			}
//			
//		}
		
	}
	
	public void log(String msg){
		if(this.mainLogs.isEmpty()) return;
		StackTraceElement caller = Thread.currentThread().getStackTrace()[2];
		
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTimeInMillis(System.currentTimeMillis());
		
		for(String mainLog : mainLogs){
			this.goDownAndLog(mainLog, this.buildOutput(caller,mainLog,  msg));
		}
	}
	
	private String buildOutput( StackTraceElement caller, String domain, String msg){
		if (b.length() != 0)
			b.delete(0, b.length());
		b.append("[");
		b.append(domain);
		b.append("]:  ");
//		b.append("[");
//		b.append(cal.get(GregorianCalendar.YEAR));
//		b.append("-");
//		b.append(cal.get(GregorianCalendar.MONTH));
//		b.append("-");
//		b.append(cal.get(GregorianCalendar.DAY_OF_MONTH));
//		b.append(" ");
//		b.append(cal.get(GregorianCalendar.HOUR_OF_DAY));
//		b.append(":");
//		b.append(cal.get(GregorianCalendar.MINUTE));
//		b.append(":");
//		b.append(cal.get(GregorianCalendar.SECOND));
//		b.append(" ");
//		b.append(caller.getFileName().subSequence(0,caller.getFileName().length()-5));
//		b.append("#");
//		b.append(caller.getMethodName());
//		b.append(":");
//		b.append(caller.getLineNumber());
//		b.append("]: ");
		b.append(msg);
		return b.toString();
	}
	
	
	public Logger retrieveLogger(String log){
		
		return retrieveLoggerAtDepth(log, log.split("\\.").length);
	}
	
		public Logger retrieveLoggerAtDepth(String log, int depth){
		String[] loggerpath = log.split("\\.");
		Logger currentLogger =  this.loggers.get(loggerpath[0]);
		if(currentLogger == null) return null;
		
		for(int i = 1; i< depth; i++){
			if(currentLogger.hasChild(loggerpath[i])){
				currentLogger = currentLogger.getChildByName(loggerpath[i]);
			}else{
				return null;
			}
		}
		return currentLogger;
	}

	
	private void goDownAndLog(String domain, String msg) {
		
		String[] loggerpath = domain.split("\\.");
		Logger currentLogger = this.loggers.get(loggerpath[0]);
		if (currentLogger == null) {
			throw new IllegalArgumentException("Given Logger not found" + loggerpath[0]);
		}
		currentLogger.log(msg);
		for (int i = 1; i < loggerpath.length; i++) {
			//iterate over the logger path to make it print out and throw an exception if not found
			if (currentLogger.hasChild(loggerpath[i])) {
				currentLogger = currentLogger.getChildByName(loggerpath[i]);
				currentLogger.log(msg);
			} else {
				throw new IllegalArgumentException("Given Logger-Domain not found!" + domain);
			}

		}
	}
	
	static boolean hasDublicates(final String[] domains)
  {
	  HashSet<String> set = new HashSet<>();
	  
	  for(String s : domains){
		  if(!set.add(s)){
			  return true;
		  }
	  }
	  return false;
  }

	private String getDotSeparatedString(String[] copyOfRange) {
		String out = copyOfRange[0];
		for(int i = 1; i<copyOfRange.length; i++){
			out = out.concat("." + copyOfRange[i]);
		}
		return out;
	}
	
	public void closeAllLogger(){
		for(String loggerName : this.loggers.keySet()){
			Logger l = this.loggers.get(loggerName);
			closeLoggerRecursive(l);
		}
	}
	
	public void closeLoggerRecursive(Logger l){
		l.close();
		ArrayList<Logger> children = l.getChildren();
		if(children.isEmpty()) return;
		else{
			for(Logger logger : children){
				closeLoggerRecursive(logger);
			}
		}
		
	}
	
	

	
	
	
}
