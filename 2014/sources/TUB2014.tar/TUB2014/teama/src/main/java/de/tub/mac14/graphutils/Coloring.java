package de.tub.mac14.graphutils;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import de.tub.mac14.enums.Team;
import de.tub.mac14.ontology.Hotspot;
import de.tub.mac14.ontology.Robot;
import de.tub.mac14.ontology.Vertex;
import de.tub.mac14.ontology.World;

public class Coloring {
	
	private World world;
	private HashMap<Vertex, Team> colorsPhase1;
	private HashMap<Vertex, Team> colorsPhase2;
	private Hotspot hotspot;
	private List<Vertex> robots;
	private List<Vertex> standingRobots;
	private List<Vertex> changingRobots;
	private List<Vertex> enemyRobots;

	public Coloring(World world, Hotspot hotspot, List<Vertex> robots, List<Vertex> changingRobots) {
		this.world = world;
		this.hotspot = hotspot;
		this.robots = new LinkedList<>(robots);
		this.changingRobots = new LinkedList<>(changingRobots);
		this.standingRobots = new LinkedList<>(robots);
		this.standingRobots.removeAll(changingRobots);
		this.colorsPhase1 = new HashMap<Vertex, Team>();
		this.colorsPhase2 = new HashMap<Vertex, Team>();
		this.enemyRobots = new LinkedList<>();
		init();
	}

	private void init() {
		List<Vertex> temp = new LinkedList<>();
		for (Vertex v : hotspot.extendedNeighbors) {
			temp.add(v);
			colorsPhase1.put(v, null);
			colorsPhase2.put(v, null);

			// find enemies
			for (int i = 0; i < world.enemyRobots.size(); i++) {
				Robot robot = world.enemyRobots.get(i);
				if (robot.position != null && robot.position.equals(v)) {
					enemyRobots.add(v);
				}
			}
		}
		colorGraph(temp);
	}

	public int colorGraph(List<Vertex> changes) {
		HashMap<Vertex, Team> colorsPhase1Reset = new HashMap<>();
		HashMap<Vertex, Team> colorsPhase2Reset = new HashMap<>();
		boolean init = (colorsPhase1.get(changes.get(0)) == null);
		if (!init) {
			this.robots = new LinkedList<>(standingRobots);
			this.robots.addAll(changes);
		}
		
		// PHASE 1
		for (Vertex v : changes) {
			if (colorsPhase1.containsKey(v)) {
				if (!colorsPhase1Reset.containsKey(v)) {
					colorsPhase1Reset.put(v, colorsPhase1.get(v));
				}
				colorsPhase1.put(v, getTeamDominationForVertex(v));
			}
		}
		for (Vertex v : changingRobots) {
			// This is recalculated every round anyway.
			// So no need for resetting this.
			colorsPhase1.put(v, getTeamDominationForVertex(v));
		}
		
		// PHASE 2: Coloring empty vertices that are direct neighbors of
		// dominated vertices

		// Collect all vertexes that could be changed:
		HashSet<Vertex> phase2Changes = new HashSet<>();
		// 1. All neighbors of changes
		for (Vertex v : changes) {
			phase2Changes.addAll(v.getNeighbors(1, true));
		}
		// 2. All neighbors of changingRobots
		for (Vertex v : changingRobots) {
			phase2Changes.addAll(v.getNeighbors());
		}

		for (Vertex v : colorsPhase1.keySet()) {
			if (phase2Changes.contains(v)) {
				colorsPhase2Reset.put(v, colorsPhase2.get(v));
				if (colorsPhase1.get(v) != Team.NONE) {
					// Doesn't change the score.
					// But set this to NONE, so there are no nulls while
					// initializing.
					colorsPhase2.put(v, Team.NONE);
					continue;
				}
				Set<Vertex> neighbours = v.getNeighbors();
				int ourTeamDominatedNeighbours = 0;
				int enemyTeamDominatedNeighbours  = 0;
				for (Vertex n : neighbours) {
					Team vTeam = colorsPhase1.get(n);
					if (vTeam == Team.WE)
						ourTeamDominatedNeighbours++;
					else if (vTeam == Team.ENEMY)
						enemyTeamDominatedNeighbours++;
				}

				if (ourTeamDominatedNeighbours > enemyTeamDominatedNeighbours && ourTeamDominatedNeighbours > 1){
					colorsPhase2.put(v, Team.WE);
				}
				else if (enemyTeamDominatedNeighbours > ourTeamDominatedNeighbours && enemyTeamDominatedNeighbours > 1){
					colorsPhase2.put(v, Team.ENEMY);
				} else {
					colorsPhase2.put(v, Team.NONE);
				}
			} // for all phase2Changes
		}

		int score = getScore();

		// Reset colors to normal
		if (!init) {
			colorsPhase1.putAll(colorsPhase1Reset);
			colorsPhase2.putAll(colorsPhase2Reset);
		}

		return score;
	}
	
	private int getScore() {
		int score = 0;
		for (Entry<Vertex, Team> entry : colorsPhase1.entrySet()) {
			Vertex vertex = entry.getKey();
			Team team = entry.getValue();
			if (team == Team.WE && vertex.isProbed()) {
				score += vertex.getValue();
			} else if (team == Team.ENEMY && vertex.isProbed()) {
				score -= vertex.getValue();
			}
		}
		for (Entry<Vertex, Team> entry : colorsPhase2.entrySet()) {
			Vertex vertex = entry.getKey();
			Team team = entry.getValue();
			if (team == Team.WE && colorsPhase1.get(vertex) != Team.WE &&
					vertex.isProbed()) {
				score += vertex.getValue();
			} else if (team == Team.ENEMY && colorsPhase1.get(vertex) != Team.ENEMY &&
					vertex.isProbed()) {
				score -= vertex.getValue();
			}
		}
		return score;
	}

	public Team getTeamDominationForVertex(Vertex vertex) {
		if (vertex != null) {
			int ourTeamCounter = 0;
			int enemyTeamCounter = 0;
			for (Vertex v : robots) {
				if (v.equals(vertex)) {
					ourTeamCounter++;
				}
			}
			for (Vertex v : enemyRobots) {
				if (v.equals(vertex)) {
					enemyTeamCounter++;
				}

			}

			if (ourTeamCounter > enemyTeamCounter)
				return Team.WE;
			else if (enemyTeamCounter > ourTeamCounter)
				return Team.ENEMY;
			else
				return Team.NONE;
		}
		else
			return null;
	}
}
