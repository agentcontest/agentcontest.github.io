/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package de.tub.mac14.common;

import java.io.Serializable;

/**
 * Simple Tuple implementation. Should be self-explanatory. May be used, to 
 * return 2 values instead of one. Tuple Representation is: <first, second>
 * @author mattu
 */
public class Tuple<U,V> implements Serializable{

	@Override
	public String toString() {
		return "Tuple (" + first + ", " + second + ")";
	}

	public U first;
	public V second;
	
	/**
	 * Creates a Tuple-Object of the given types. It should be a basic 
	 * container for two values;
	 * @param first The first entry of the tuple <first, second>
	 * @param second The second Entry of the Tuple
	 */
	public Tuple(U first, V second){
		this.first = first;
		this.second = second;
	}
	
	/**
	 * The Empty constructor of Tuple. When using this, make shure to 
	 * use the setters to set the Two values;
	 */
	public Tuple(){
		
	}
	
	public U getFirst(){
		return this.first;
	}
	
	public V getSecond(){
		return this.second;
	}
	
	public void setFirst(U first){
		this.first = first;
	}
	
	public void setSecond(V second){
		this.second = second;
	}
}
