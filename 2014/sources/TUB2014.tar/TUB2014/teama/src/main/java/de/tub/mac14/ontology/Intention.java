package de.tub.mac14.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac14.enums.RobotAction;

public class Intention implements IFact {
	
	private static final long serialVersionUID = -5482169226353959121L;
	
	public RobotAction action;
	public String param;
	
	public RobotAction getAction() {
		return action;
	}

	public Intention(RobotAction action, String param) {
		this.action = action;
		this.param = param;
	}
	
	public String toString() {
		return action + "(" + param + ")";
	}
	
	public void setAction(RobotAction action) {
		this.action = action;
	}

	public String getParam() {
		return param;
	}

	public void setParam(String param) {
		this.param = param;
	}
}
