package de.tub.mac14.strategy;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map.Entry;
import java.util.Set;

import de.tub.mac14.bean.DefaultDecisionBean;
import de.tub.mac14.common.Config;
import de.tub.mac14.common.Log;
import de.tub.mac14.enums.Role;
import de.tub.mac14.graphutils.PositionFinder;
import de.tub.mac14.ontology.Hotspot;
import de.tub.mac14.ontology.Intention;
import de.tub.mac14.ontology.Position;
import de.tub.mac14.ontology.Robot;

public class AssignHotspotStrategy extends Strategy {

	public AssignHotspotStrategy(DefaultDecisionBean bean) {
		super(bean);
	}

	@Override
	public Intention decide() {
		Hotspot bestHotspot = null;
		double bestScore = 0.;
		for (Hotspot hotspot : world.hotspots.hotspots) {
//			for (Position p : PositionFinder.goodPositions) {
//				if (p.area.contains(hotspot.center)) {
//					continue;
//				}
//			}
			if (ddb.pathmap.getDistanceTo(hotspot.center) > -1) {
				double score = getScore(hotspot);
				// discard hotspot if score is not positive
				if (score > 0. && score > bestScore) {
					bestScore = score;
					bestHotspot = hotspot;
				}
			}
		}

		if (bestHotspot != null) {
			Hotspot before = StrategyAssigner.hotspotAssignments.get(me);
			if (before == null || !bestHotspot.equals(before)) {
				System.err.println(me.username + ": Hotspot assignment changed to " + bestHotspot.center.getFullId());
			}
			StrategyAssigner.hotspotAssignments.put(me, bestHotspot);
		} else {
			StrategyAssigner.hotspotAssignments.remove(me);
		}
		if (me.usersuffix.equals(20)) {
			Log.log("debug.strategy.hotspot", "Current assignments");
			HashMap<Hotspot, Set<Robot>> counter = new HashMap<Hotspot, Set<Robot>>();
			for (Entry<Robot, Hotspot> h : StrategyAssigner.hotspotAssignments.entrySet()) {
				Set<Robot> set = counter.get(h.getValue());
				if (set == null) {
					set = new HashSet<Robot>();
				}
				set.add(h.getKey());
				counter.put(h.getValue(), set);
			}
			for (Entry<Hotspot, Set<Robot>> e : counter.entrySet()) {
				Log.log("debug.strategy.hotspot", e.getKey().center + ": " + e.getValue().toString());
			}
		}
		return null;
	}

	private double getScore(Hotspot hotspot) {
		double value = hotspot.value * Config.getInt("GOTOHOTSPOT_VALUE_FACTOR");
		int distance = (int) (ddb.pathmap.getDistanceTo(hotspot.center) * Config.getInt("GOTOHOTSPOT_DISTANCE_FACTOR") * 0.1);
		int robotsAlreadyAssigned = countHotspotAssignments(hotspot, false);
		int ownRoleAlreadyAssigned = countHotspotAssignments(hotspot, true);
		double exploredFactor = ((((double) world.probedVertices) / world.numVertices) - 1)
				* Config.getInt("GOTOHOTSPOT_EXPLORED_FACTOR");
		double capacity = (((double) hotspot.size()) / (robotsAlreadyAssigned + 1))
				* Config.getInt("GOTOHOTSPOT_SIZE_FACTOR");
		int robotPenalty = robotsAlreadyAssigned * Config.getInt("GOTOHOTSPOT_ROBOTS_FACTOR");
		double score = -distance + value + capacity + exploredFactor - robotPenalty;

		// Add rewards for special roles. So we get at least one repairer
		// on each assigned hotspt.
		if (robotsAlreadyAssigned > 0 && ownRoleAlreadyAssigned == 0) {
			if (me.role == Role.REPAIRER) {
				score += 1000;
			}
		}

		// Add rewards for hotspots with only 1 robot assigned to it.
		if (robotsAlreadyAssigned == 1) {
			score += 50;
		}

		// TODO felix: uncomment when mattus logger is active
		// if (me.usersuffix.equals(7)) {
		// System.out.println("-----Scores for " + hotspot.getFullId());
		// System.out.println("d: -" + distance);
		// System.out.println("v:  " + value);
		// System.out.println("s:  " + capacity);
		// System.out.println("r: " + robotsAlreadyAssigned);
		// System.out.println("e: " + exploredFactor);
		// System.out.println("score: " + score);
		// }

		return score;
	}

	private int countHotspotAssignments(Hotspot hotspot, boolean onlyMyRole) {
		int count = 0;
		for (Entry<Robot, Hotspot> entry : StrategyAssigner.hotspotAssignments.entrySet()) {
			Robot robot = entry.getKey();
			Hotspot robotHotspot = entry.getValue();
			if (hotspot.equals(robotHotspot) && !robot.equals(me)) {
				if (!onlyMyRole || robot.role == me.role) {
					count++;
				}
			}
		}
		return count;
	}

}
