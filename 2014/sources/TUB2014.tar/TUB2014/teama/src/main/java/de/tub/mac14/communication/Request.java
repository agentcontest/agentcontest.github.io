package de.tub.mac14.communication;

import de.dailab.jiactng.agentcore.comm.IMessageBoxAddress;
import de.tub.mac14.enums.MessageSubject;
import de.tub.mac14.enums.Role;

/**
 * Class used to send request messages to the agents.
 * 
 * @author lucas
 *
 * @param <T> Type of the message content
 */
public class Request extends Message {
	private static final long serialVersionUID = 3582556566496341719L;
	
	
	/**
	 * Constructs a generic Inform with all fields set to null. Can be
	 * used to filter any Request message in the memory or to make a custom
	 * filter using the setters methods.
	 */
	public Request() {
		super();
	}
	
	/**
	 * Constructs a message setting only the user. It may be used
	 * to filter the messages by user in the memory.
	 * 
	 * @param senderBoxAddress The JIAC Message Adress Box of the sender
	 */
	public Request(IMessageBoxAddress senderBoxAddress) {
		super(senderBoxAddress, null, null, null, null, null);
	}
	
	/**
	 * Constructs a message setting only the sender role. It may
	 * be used to filter the messages by role in the memory.
	 * 
	 * @param senderRole The role from the robot that sent the message
	 */
	public Request(Role senderRole) {
		super(null, null, senderRole, null, null, null);
	}
	
	/**
	 * Constructs a message setting only the subject. It may
	 * be used to filter the messages by subject in the memory.
	 * 
	 * @param subject The Message Subject
	 */
	public Request(MessageSubject subj) {
		super(null, null, null, subj, null, null);
	}
	
	/**
	 * Constructs a message setting only the step. It may be used to filter the
	 * messages by step in the memory.
	 * 
	 * @param subject The Message Step
	 */
	public Request(Integer step) {
		super(null, null, null, null, step, null);
	}
		
	/**
	 * Constructs a Request to be sent or to filter an specific message.
	 * 
	 * @param senderBoxAddress The JIAC Message Adress Box of the sender
	 * @param senderUsername The username from the robot that sent the message
	 * @param senderRole The role from the robot that sent the message
	 * @param subj The Message Subject
	 * @param step The Message step
	 * @param message The object that will be sent (payload)
	 */
	public Request(IMessageBoxAddress senderBoxAddress, Integer senderUsersuffix, Role senderRole, MessageSubject subj,
			Integer step, Object message) {
		super(senderBoxAddress, senderUsersuffix, senderRole, subj, step, message);
	}
}
