package de.tub.mac14.strategy.util;

import java.util.List;

import de.tub.mac14.ontology.Robot;
import de.tub.mac14.ontology.Vertex;

/**
 * find out who to kill first by ranking this fine comparable in an
 * exquisite list of enemies
 * 
 * @author jens
 * 
 */
public class RankedEnemy implements Comparable<RankedEnemy> {
	public static int[] ENEMY_ROLE_BONI = { 15, 0, 20, 0, 10 };
	public static int[] ENEMY_ROLE_BONI_D = { 0, 5, 12, 10, 0 };
	public Robot self;
	public int startValue;
	public int distance = 0;
	public List<Vertex> path;
	public int roleBonus;

	public RankedEnemy(Robot r, int val) {
		this(r, val, null);
	}

	public RankedEnemy(Robot r, int val, List<Vertex> pathToEnemy) {
		self = r;
		startValue = val;
		if (pathToEnemy != null)
			distance = pathToEnemy.size();
		path = pathToEnemy;
		if (pathToEnemy == null) {
			roleBonus = ENEMY_ROLE_BONI[self.role.ordinal()];
		} else {
			roleBonus = ENEMY_ROLE_BONI_D[self.role.ordinal()];
		}
		
	}

	public int getScore() {
		// TODO jens: get more complicated
//		return (startValue - distance + roleBonus) * 100 - self.usersuffix;
		return (startValue - distance + roleBonus);

	}

	@Override
	public boolean equals(Object o) {
		if (o == null)
			return false;
		if (o instanceof RankedEnemy) {
			return self.equals(((RankedEnemy) o).self);
		}
		return o.equals(this);
	}

	@Override
	public int compareTo(RankedEnemy o) {
		return Integer.compare(getScore(), o.getScore());
	}

}

