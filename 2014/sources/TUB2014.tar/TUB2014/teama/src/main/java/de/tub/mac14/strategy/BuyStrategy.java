package de.tub.mac14.strategy;

import de.tub.mac14.bean.DefaultDecisionBean;
import de.tub.mac14.enums.RobotAction;
import de.tub.mac14.enums.Role;
import de.tub.mac14.ontology.Intention;

public class BuyStrategy extends Strategy {

	/**
	 * Default constructor which calls super(). Pass the DefaultDecisionBean in
	 * order to enable the agent communication for this strategy.
	 * 
	 * @param ddb
	 *            The default decision bean this strategy belongs to.
	 */
	public BuyStrategy(DefaultDecisionBean ddb) {
		super(ddb);
	}

	/**
	 * Decides what to buy next. If it has not enough money, it returns null.
	 * 
	 * @return The Intention which contains either a buy action
	 */
	@Override
	public Intention decide() {
		if (me.isDisabled()) {
			return null;
		}
		if (!ddb.getWorld().getMe().isDisabled()) {
			Role myRole = ddb.getWorld().getMe().role;
			Intention intention = myRole.equals(Role.SABOTEUR) ? decideSaboteurVisibilityRange()
					: null;

			if (intention != null)
				System.out.println(ddb.getWorld().username + ": I'll buy some "
						+ intention.param);

			return intention;
		}

		return null;
	}

	public Intention decideSaboteurVisibilityRange() {
		if (ddb.getWorld().money >= 4 * 2) {
			if (ddb.getWorld().getMe().visRange == 1) {
				return new Intention(RobotAction.BUY, "sensor");
			} else if (me.strength.equals(4)) {
				return new Intention(RobotAction.BUY, "sabotageDevice");
			}
		}

		return null;
	}

	public Intention decideSaboteurStrength() {
		if (ddb.getWorld().money >= 4 * 2) {
			return new Intention(RobotAction.BUY, "sabotageDevice");
		}

		return null;
	}

	public Intention decideRepairerVisibilityRange() {
		if (ddb.getWorld().money >= 6 * 2) {
			return new Intention(RobotAction.BUY, "sensor");
		}

		return null;
	}

	public Intention decideAllHealth() {
		if (ddb.getWorld().money >= 28 * 2) {
			return new Intention(RobotAction.BUY, "shield");
		}

		return null;
	}

	public Intention decideAllEnergy() {
		if (ddb.getWorld().money >= 28 * 2) {
			return new Intention(RobotAction.BUY, "battery");
		}

		return null;
	}

}
