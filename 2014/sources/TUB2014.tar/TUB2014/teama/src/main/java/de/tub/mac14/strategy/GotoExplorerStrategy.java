/**
 * This strategy does two things:
 * 
 * 1. At the beginning, if no explorer is in sight, it goes (randomly,
 * but not too randomly) around until an explorer is in sight.
 * 
 * 2. If one or more Explorer is in sight, the robot chooses which
 * Explorer to follow. It uses the static field
 * StrategyAssigner.whoFollowsWho to do so. It tells the StrategyAssigner
 * which explorer to follow but returns null. To followRobotStrategy will
 * goto this explorer.
 */
package de.tub.mac14.strategy;

import java.util.LinkedList;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;

import de.tub.mac14.bean.DefaultDecisionBean;
import de.tub.mac14.common.Config;
import de.tub.mac14.enums.RobotAction;
import de.tub.mac14.enums.Role;
import de.tub.mac14.enums.Team;
import de.tub.mac14.ontology.Intention;
import de.tub.mac14.ontology.Robot;
import de.tub.mac14.ontology.Vertex;

public class GotoExplorerStrategy extends Strategy {

	// When we go somewhere randomly we save the current Vertex
	// So next time we won't return to this vertex
	private Vertex comeFrom;

	public GotoExplorerStrategy(DefaultDecisionBean bean) {
		super(bean);
	}

	@Override
	public Intention decide() {
		LinkedList<Robot> explorers = world.filterRobots(Team.WE, Role.EXPLORER);
		LinkedList<Robot> reachableExplorers = new LinkedList<Robot>();
		for (Robot explorer : explorers) {
			if (ddb.pathmap.getDistanceTo(explorer.position) != -1) {
				reachableExplorers.add(explorer);
			}
		}
		if (reachableExplorers.isEmpty()) {
			return goSomewhere();
		} else {
			assignMasterExplorer(reachableExplorers);
			return null;
		}
	}

	private void assignMasterExplorer(LinkedList<Robot> reachableExplorers) {
		// Assign next explorer
		double bestScore = -999999;
		Robot bestExplorer = null;
		for (Robot r : reachableExplorers) {
			double score = getScore(r);
			if (score > bestScore) {
				bestScore = score;
				bestExplorer = r;
			}
		}
		StrategyAssigner.setMaster(me, bestExplorer);
	}

	/**
	 * Evaluates which explorer to follow by taking the following into account:
	 * > The distance to the explorer > How many other robots of the same type
	 * are following a explorer > How many other robots of any type are
	 * following a explorer
	 */
	private double getScore(Robot explorer) {
		int distance = ddb.pathmap.getDistanceTo(explorer.position);

		// count followers
		int sameTypeFollowers = 0;
		int followers = 0;
		for (Entry<Robot, Robot> entry : StrategyAssigner.whoFollowsWho.entrySet()) {
			if (!entry.getValue().equals(explorer) || entry.getKey() == me) {
				continue;
			}
			followers++;
			if (entry.getKey().role == me.role) {
				sameTypeFollowers++;
			}
		}
		// System.out.println(explorer.username + " has " + followers +
		// " followers");

		return -Config.getInt("GOTOEXPLORER_STRATEGY_TYPEFOLLOWERS_FACTOR") * sameTypeFollowers
				- Config.getInt("GOTOEXPLORER_STRATEGY_FOLLOWERS_FACTOR") * followers
				- distance;
	}

	/**
	 * Returns a random neighbor. But leaves out the neighbor we came from.
	 */
	private Intention goSomewhere() {
		Set<Vertex> neighbors = me.position.getNeighbors();
		LinkedList<Vertex> strippedNeighbors = new LinkedList<Vertex>();
		for (Vertex v : neighbors) {
			if (comeFrom == null || !comeFrom.equals(v) || neighbors.size() <= 1) {
				strippedNeighbors.add(v);
			}
		}
		Random r = new Random();
		if (strippedNeighbors.isEmpty()) {
			return null;
		}
		int rIdx = r.nextInt(strippedNeighbors.size());
		Vertex nextVertex = strippedNeighbors.get(rIdx);
		Intention intention = checkedGoto(nextVertex);
		if (intention.action == RobotAction.GOTO) {
			comeFrom = nextVertex;
		}
		return intention;
	}

}
