package de.tub.mac14.strategy;

import java.util.List;

import de.tub.mac14.bean.DefaultDecisionBean;
import de.tub.mac14.enums.RobotAction;
import de.tub.mac14.ontology.Intention;
import de.tub.mac14.ontology.Robot;
import de.tub.mac14.ontology.Vertex;

public class FollowRobotStrategy extends Strategy {
	
	Robot followed;

	/**
	 * Creates a new Strategy to follow a given robot.
	 * 
	 * @param ddb Default Decision Bean
	 * @param followed Robot that will be followed
	 */
	public FollowRobotStrategy(DefaultDecisionBean ddb) {
		super(ddb);
	}

	@Override
	public Intention decide() {
		this.followed = StrategyAssigner.getMaster(me);
		if(me == null) {
			return new Intention(RobotAction.SKIP, null);
		}
		
		if (this.followed == null) {
			return null;
		}
		
		List<Vertex> pathToFollowed = ddb.pathmap.getPath(followed.position);
		
		// only go to the node if there are more than one node between them
		if(pathToFollowed.size() > 3) {
			Vertex destination = pathToFollowed.get(1);
			return checkedGoto(destination);
		}
		
		// default action
		return new Intention(RobotAction.RECHARGE, null);
	}

}
