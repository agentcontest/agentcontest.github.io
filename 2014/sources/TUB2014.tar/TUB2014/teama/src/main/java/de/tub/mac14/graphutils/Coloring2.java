package de.tub.mac14.graphutils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import de.tub.mac14.enums.Team;
import de.tub.mac14.ontology.Robot;
import de.tub.mac14.ontology.Vertex;

public class Coloring2 {

	private final HashMap<Vertex, Integer> colors;
	private final Set<Vertex> filter;
	private final List<Robot> enemyRobots;
	private Team current;

	public Coloring2(Set<Vertex> filter, List<Robot> enemyRobots) {
		this.filter = filter;
		this.colors = new HashMap<>(filter.size());
		this.enemyRobots = enemyRobots;
	}

	public int colorGraph(List<Vertex> robots) {
		colors.clear();
		
		// PHASE 1
		for (Robot r : enemyRobots) {
			if (r.position != null && filter.contains(r.position)) {
				if (colors.containsKey(r.position)) {
					colors.put(r.position, colors.get(r.position) - 1);
				} else {
					colors.put(r.position, -1);
				}
			}
		}
		for (Vertex v : robots) {
			if (colors.containsKey(v)) {
				colors.put(v, colors.get(v) + 1);
			} else {
				colors.put(v, 1);
			}
		}

		// PHASE 2: Coloring empty vertices that are direct neighbors of
		// dominated vertices

		for (Vertex v : filter) {
			if (!colors.containsKey(v)) {
				Set<Vertex> neighbours = v.getNeighbors();
				int ourNeighbours = 0;
				int enemyNeighbours = 0;
				for (Vertex n : neighbours) {
					Integer val = colors.get(n);
					if (val != null) {
						if (val >= 1) {
							ourNeighbours++;
						}
						else if (val <= 0) {
							enemyNeighbours++;
						}
					}
				}
				if (ourNeighbours > enemyNeighbours && ourNeighbours > 1) {
					colors.put(v, 1);
				} else if (enemyNeighbours > ourNeighbours && enemyNeighbours > 1) {
					colors.put(v, -1);
				}
			}
		}

		// PHASE 3
		for (Vertex v : filter) {
			if (!colors.containsKey(v)) {
				current = Team.NONE;
				HashSet<Vertex> visited = new HashSet<Vertex>();
				boolean ok = doPhase3(v, visited);
				if (ok && current == Team.WE) {
					colorPhase3(visited, 1);
				} else if (ok && current == Team.ENEMY) {
					colorPhase3(visited, -1);
				} else {
					colorPhase3(visited, 0);
				}
			}
		}

		return getScore();
	}

	private boolean doPhase3(Vertex v, Set<Vertex> visited) {
		visited.add(v);
		for (Vertex n : v.getNeighbors()) {
			if (!filter.contains(n)) {
				return false;
			}
			if (visited.contains(n)) {
				continue;
			}

			Integer color = colors.get(n);

			if (color == null) {
				// do recursion
				if (!doPhase3(n, visited)) {
					return false;
				}
			} else if (color.equals(0)) {
				// We end up here if:
				// - ourRobotsOnN == enemyRobotsOnN (Phase 1)
				// - a previous run of Phase 3 broke early
				return false;
			} else if (color > 0) {
				if (current == Team.ENEMY) {
					return false;
				}
				current = Team.WE;
			} else if (color < 0) {
				if (current == Team.WE) {
					return false;
				}
				current = Team.ENEMY;
			}
		} // for (Vertex n : v.getNeighbors()) {
		return true;
	}

	private void colorPhase3(Set<Vertex> visited, int i) {
		for (Vertex v : visited) {
			colors.put(v, i);
		}
	}

	private int getScore() {
		int score = 0;
		for (Entry<Vertex, Integer> entry : colors.entrySet()) {
			Vertex vertex = entry.getKey();
			Integer team = entry.getValue();
			if (vertex.isProbed()) {
				if (team > 0) {
					score += vertex.getValue();
				} else if (team < 0) {
					score -= vertex.getValue();
				}
			}
		}
		return score;
	}
}
