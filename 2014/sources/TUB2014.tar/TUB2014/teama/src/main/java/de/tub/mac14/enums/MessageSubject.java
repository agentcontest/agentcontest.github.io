package de.tub.mac14.enums;

/**
 * Enum for the subject of messages sent by the agents.
 * 
 * @author lucas
 *
 */
public enum MessageSubject {
	REPAIR_ME,    // Request that someone must "repair" the given agent
	GOING_TO, // Informs that this agent is "going to" some place
	GOTO_INSTRUCTION; //Instruct a robot to go somewhere
	
	/**
	 * Make a string from the given subject.
	 * 
	 * @return A string for the given subject item.
	 */
	@Override
	public String toString(){
		switch(this){
			case REPAIR_ME:
				return "RepairMe";
			case GOING_TO:
				return "GoingTo";
			default:
			return "";
		}
	}

}
