/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package de.tub.mac14;

/**
 *
 * @author mattu
 */
public class StartServerAndTeam {
	public static void main(String[] args) {
		RunServer.main(args);
		BTeamStarter.main(null);
		RunDummyTeam.main(null);
	}
}
