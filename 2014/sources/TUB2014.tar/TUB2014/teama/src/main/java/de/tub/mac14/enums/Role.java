package de.tub.mac14.enums;
/**
 * Enum for the 5 roles. Some methods like getActions() and the default stats
 * could be implemented here.
 * @author flix
 *
 */

public enum Role {
	EXPLORER, REPAIRER, SABOTEUR, SENTINEL, INSPECTOR;
	
	public static Role getRoleFromString(String role){
		switch(role){
			case "Explorer":
				return Role.EXPLORER;
			case "Repairer":
				return Role.REPAIRER;
			case "Saboteur":
				return Role.SABOTEUR;
			case "Sentinel":
				return Role.SENTINEL;
			case "Inspector":
				return Role.INSPECTOR;
			default:
				throw new IllegalArgumentException("No Corresponding Role Found: " + role);
		}
	}
	
	/**
	 * ToString- Method, that is consistent with "getRoleFromString", so that e.g 
	 * getRoleFromString(Role.SENTINEL.toString()) == Role.SENTINEL.
	 * @return 
	 */
	@Override
	public String toString(){
		switch(this){
			case EXPLORER:
				return "Explorer";
			case REPAIRER:
				return "Repairer";
			case SABOTEUR:
				return "Saboteur";
			case SENTINEL:
				return "Sentinel";
			case INSPECTOR:
				return "Inspector";
			default:
				return "";
		}
	}
}
