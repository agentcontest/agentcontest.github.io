package de.tub.mac14.ontology;

/**
 * A robot with all its stats.
 * Handle with Care: All fields except username and team are initialized with
 * null. The user should ALWAYS check if the value is known.
 * @author flix
 */



import de.tub.mac14.common.Utils;
import de.tub.mac14.enums.Role;
import de.tub.mac14.enums.Team;
import de.dailab.jiactng.agentcore.knowledge.IFact;

public class Robot implements IFact, Comparable<Robot> {
	private static final long serialVersionUID = -7504566463751142387L;
	
	public String username;
	public final Integer usersuffix;
	public final Team team;
	public Role role;
	
	public Integer energy;
	public Integer maxEnergy;
	public Integer maxEnergyDisabled;

	public Integer health;
	public Integer maxHealth;

	public Integer strength;

	public Integer visRange;

	public Integer zoneScore;

	public Vertex position;

	public String lastAction;
	public String lastActionParam;
	public String lastActionResult;

	public Robot(String username, Team team) {
		this.username = username;
		this.usersuffix = Utils.getNumericalSuffix(username);
		this.team = team;
	}
	
	public boolean isDisabled(){
		return (this.health == null) ? false : this.health.equals(0);
	}
	
	@Override
	public String toString() {
		return username;
	}

	@Override
	public int compareTo(Robot o) {
		return usersuffix.compareTo(o.usersuffix);
	}

	@Override
	public boolean equals(Object o) {
		Robot r = (Robot) o;//		b.append("[");
		return this.usersuffix.equals(r.usersuffix);
	}
	
	@Override
	public int hashCode() {
		return this.usersuffix.hashCode();
	}
}
