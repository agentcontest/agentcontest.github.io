package de.tub.mac14.strategy;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import de.tub.mac14.bean.DefaultDecisionBean;
import de.tub.mac14.common.Config;
import de.tub.mac14.enums.RobotAction;
import de.tub.mac14.ontology.Intention;
import de.tub.mac14.ontology.Robot;
import de.tub.mac14.ontology.Vertex;
import de.tub.mac14.strategy.util.RankedEnemy;

public class SaboteurAggressorStrategy extends SaboteurMasterStrategy {

	public SaboteurAggressorStrategy(DefaultDecisionBean bean, SaboteurParams params) {
		super(bean);
	}

	@Override
	public Intention decide() {

		// gather a list of all human beings
		ArrayList<Robot> humans = world.getEnemys();
		// have a nice list to see who will be served first
		LinkedList<RankedEnemy> exterminationList = new LinkedList<RankedEnemy>();
		List<Vertex> pathToEnemy = null;
		// iterate all humans, let's see what we can reach
		for (Robot r : humans) {
			if (r.position != null && !r.isDisabled() && !probablyDisabled(r)) {
				if (r.position.equals(me.position)) {
					exterminationList.add(new RankedEnemy(r,
							ENEMY_ON_SAME_LOCATION_RANK));
				} else {
					pathToEnemy = ddb.pathmap.getPath(r.position);
					if (pathToEnemy != null && !pathToEnemy.isEmpty()) {
						if (validPath(pathToEnemy, r.position))
							exterminationList.add(new RankedEnemy(r,
									ENEMY_REACHABLE_RANK, pathToEnemy));
					}
				}
			}
		}
		if (!exterminationList.isEmpty()) {
			Collections.sort(exterminationList);
			Collections.reverse(exterminationList);
			if (scoringDebug) {
				System.out.println("---------- TABLE OF INTERREST");
				for (RankedEnemy aim : exterminationList) {
					System.out.println("--- " + aim.self.username + " - "
							+ aim.getScore() + " - (" + aim.startValue + " - "
							+ aim.distance + " + " + aim.roleBonus
							+ ") * 100 - " + aim.self.usersuffix);
				}
			}
			for (RankedEnemy aim : exterminationList) {
				if (aim.getScore() < 1) {
					if (scoringDebug || decisionDebug)
						System.out.println("null, no aim with nice score");
					return null;
				}
				if (scoringDebug || decisionDebug)
					System.out.println(">>> aim for " + aim.self.username);

				// EXPLAIN! EXPLAIN!
				if (lastAim == null) {
					lastAim = aim;
					inspectEnemy(aim.self);
				} else if (!aim.equals(lastAim)) {
					inspectEnemy(aim.self);
					dontInspectEnemy(lastAim.self);
				}
				lastAim = aim;
				// if we are on the same spot as the enemy number one or can
				// reach him
				if (enemyReachable(aim)) {
					// EXTERMINATE! EXTERMINATE!
					attacked(aim.self);
					if (scoringDebug || decisionDebug)
						System.out.println(">>> ATTACK");
					return new Intention(RobotAction.ATTACK,
							Config.get("GAME_ENEMY_ROBOT_PREFIX")
									+ aim.self.usersuffix);
				} else if (aim.path != null && aim.path.size() > 1) {
					// APPROACH! APPROACH!
					if (scoringDebug || decisionDebug)
						System.out.println(">>> APPROACH");
					return checkedGoto(aim.path.get(1));
				}
			}
		}
		// SEARCH FOR HUMANS!
		if (decisionDebug)
			System.out.println("null, end this strategy");
		return null;
	}

	/**
	 * This method decides whether an enemy is in range for an attack. TODO:
	 * what should be done if the vis_range is increased?
	 * 
	 * @param aim
	 * @return
	 */
	protected boolean enemyReachable(RankedEnemy aim) {
		if (me != null && me.position != null && aim.self != null
				&& aim.self.position != null)
			return me.position.equals(aim.self.position);
		if (aim.path != null) {
			return aim.path.size() <= EXTERMINATION_RANGE;
		}
		return false;
	}

}
