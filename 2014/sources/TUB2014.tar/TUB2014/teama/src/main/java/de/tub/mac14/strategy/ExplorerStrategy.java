/**
 * This is the strategy for the explorer. The explorers should probe all
 * vertices in the begin phase.
 *
 * Note: We need a proper "strategy engine". So maybe this implementation here
 * will move to another location soon.
 */

package de.tub.mac14.strategy;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Set;

import de.tub.mac14.bean.DefaultDecisionBean;
import de.tub.mac14.common.Config;
import de.tub.mac14.common.Tuple;
import de.tub.mac14.communication.Inform;
import de.tub.mac14.enums.MessageSubject;
import de.tub.mac14.enums.RobotAction;
import de.tub.mac14.enums.Role;
import de.tub.mac14.enums.Team;
import de.tub.mac14.graphutils.PositionFinder;
import de.tub.mac14.ontology.Intention;
import de.tub.mac14.ontology.Robot;
import de.tub.mac14.ontology.Vertex;

public class ExplorerStrategy extends Strategy{

	LinkedList<Robot> ourExplorers;
	HashSet<Vertex> explorersGoingTo;
	PositionFinder positionFinder;

	public ExplorerStrategy(DefaultDecisionBean ddb) {
		super(ddb);
		explorersGoingTo = new HashSet<Vertex>();
		positionFinder = new PositionFinder(world);
	}

	@Override
	public Intention decide() {
		ourExplorers = world.filterRobots(Team.WE, Role.EXPLORER);
		receiveGoingTo();
		if (me == null) {
			return new Intention(RobotAction.SKIP, null);
		}

		if (!me.position.isProbed()) {
			// Vertex is not probed -> Probe it
			// But before let's check if another explorer is currently on
			// the same node. Then probe only if our user suffix is smaller.

			boolean anotherExplorerWillProbe = false;
			for (Robot r : ourExplorers) {
				// r.position can be null in the first round.
				if (r.position != null && r.position.equals(me.position)
						&& r.usersuffix < me.usersuffix) {
					anotherExplorerWillProbe = true;
				}
			}
			if (!anotherExplorerWillProbe) {
				return new Intention(RobotAction.PROBE, me.position.getFullId());
			}
		}

		positionFinder.updateGoodPositions(me.position);

		// Current Vertex is (or gets) probed. Let's go somewhere else.

		// Find the best Vertex to go.
		double bestScore = -99999;
		Vertex bestVertex = null;
		for (Vertex v : me.position.getNeighbors()) {
			if (v.isProbed() || isExplorerOn(v)) {
				continue;
			}

			// if this vertex is unprobed but has only probed neighbors, do a
			// ranged probe action.
			if (unprobedNeighbors(v).getFirst().equals(0)) {
				if (me.energy >= v.getEdgeTo(me.position).getValue() + 1) {
					return new Intention(RobotAction.PROBE, v.getFullId());
				}
				else {
					return new Intention(RobotAction.RECHARGE, null);
				}
			}
			double score = getScore(v);
			if (score > bestScore) {
				bestVertex = v;
				bestScore = score;
			}
		}

		// If all vertices around this explorer are already probed we find the
		// nearest unprobed Vertex
		if (bestVertex == null) {
			// System.out.println(me.username + ": I don't know where to go.");
			Vertex nearestUnprobedVertex = findPathToNearestUnpropedVertex();
			// Check if we may terminate early
			if (nearestUnprobedVertex == null || terminationCheck(nearestUnprobedVertex)) {
				System.out.println(me.username + ": I deactivate my ExplorerStrategy");
				disable();
				return null;
			}

			// Propergate Intention to other explorers
			ddb.sendInform(ddb.getGroupAddress(), MessageSubject.GOING_TO, nearestUnprobedVertex);

			Vertex nextStep = ddb.pathmap.getPath(nearestUnprobedVertex).get(1);

			return checkedGoto(nextStep);
		}
		return checkedGoto(bestVertex);
	}

	private boolean terminationCheck(Vertex v) {
		double percentProbed = ((double) world.probedVertices) / world.numVertices;
		System.err.println(world.numVertices);
		percentProbed *= 100;
		if (percentProbed < Config.getInt("EXPLORER_STRATEGY_TERMINATION_PERCENTAGE")) {
			return false;
		}
		// we have probed enough, but we return true anyway if v is
		// nearby.
		if (ddb.pathmap.getDistanceTo(v) < Config.getInt("EXPLORER_STRATEGY_TERMINATION_DISTANCE")) {
			return false;
		} else {
			return true;
		}
	}

	private double getScore(Vertex v) {
		Tuple<Integer, Integer> neighbors = unprobedNeighbors(v);

		int distancePenalty = (isVertexToNearestExplorer(v)) ?
				Config.getInt("EXPLORER_STRATEGY_DISTANCE_PANALTY") : 0;
		int unprobedNNeighborsPenalty = Config
				.getInt("EXPLORER_STRATEGY_UNPROBED_FACTOR")
				* neighbors.getFirst();
		int edgeWeightPenalty = Config
				.getInt("EXPLORER_STRATEGY_EDGEWEIGHT_FACTOR")
				* me.position.getEdgeTo(v).getValue();
		int valueReward = Config.getInt("EXPLORER_STRATEGY_VALUE_FACTOR") *
				neighbors.getSecond();
		// System.out.println(me.username + ": Distance: " + distanceReward
		// + ", unprobed: "
		// + unprobedNNeighborsPenalty + ", edgeweight: "
		// + edgeWeightPenalty);
		return -distancePenalty - unprobedNNeighborsPenalty - edgeWeightPenalty + valueReward;
	}

	private boolean isVertexToNearestExplorer(Vertex v) {
		Robot nearestExplorer = null;
		int nearestDistance = 99999;
		for (Robot explorer : ourExplorers) {
			if (explorer.position != null && explorer != me) {
				int distance = ddb.pathmap.getDistanceTo(explorer.position);
				if (distance > 0 && distance < nearestDistance) {
					nearestDistance = distance;
					nearestExplorer = explorer;
				}
			}
		}
		if (nearestExplorer == null) {
			return false;
		}
		Vertex nextStep = ddb.pathmap.getPath(nearestExplorer.position).get(1);
		return nextStep.equals(v);
	}

	/**
	 * Iterate once over the neighbors and returns <how many neighbors are
	 * unprobed, the summed value over all probed neighbors>
	 */
	private Tuple<Integer, Integer> unprobedNeighbors(Vertex vertex) {
		int unprobedNeighbors = 0;
		int probedValues = 0;
		for (Vertex neighbor : vertex.getNeighbors()) {
			if (neighbor.isProbed()) {
				probedValues += neighbor.getValue();
			} else {
				unprobedNeighbors++;
			}
		}
		return new Tuple<Integer, Integer>(unprobedNeighbors, probedValues);
	}

	private Vertex findPathToNearestUnpropedVertex() {
		Vertex nearestUnprobedVertex = null;
		Iterator<Vertex> i = this.world.getVertices(me.position);
		i.next(); // Discard start
		while (i.hasNext() && nearestUnprobedVertex == null) {
			Vertex goal = i.next();
			if ((!goal.isProbed()) && checkOtherExplorers(goal)) {
				nearestUnprobedVertex = goal;
			}
		}
		return nearestUnprobedVertex;
	}

	private boolean isExplorerOn(Vertex v) {
		for (Robot explorer : ourExplorers) {
			if (explorer.position == v) {
				return true;
			}
		}
		return false;
	}

	private boolean checkOtherExplorers(Vertex v) {
		int radius = Config.getInt("EXPLORER_STRATEGY_RADIUS");
		Set<Vertex> neighbors = v.getNeighbors(radius, true);
		for (Robot r : ourExplorers) {
			if (neighbors.contains(r.position)) {
				return false;
			}
		}
		for (Vertex goal : explorersGoingTo) {
			for (Vertex neighbor : neighbors) {
				if (neighbor.getId() == goal.getId()) {
					return false;
				}
			}
		}
		return true;
	}

	/**
	 * Receive Messages from other explorers and store them in the persistant
	 * field explorersGoingTo.
	 */
	private void receiveGoingTo() {
		Inform template = new Inform(
				null,
				null,
				Role.EXPLORER,
				MessageSubject.GOING_TO,
				null,
				null);
		Set<Inform> messages = ddb.filterReceivedInforms(template);
		for (Inform message : messages) {
			if (!message.getSenderUsersuffix().equals(me.usersuffix)) {
				// System.out.println(me.username + ": I know that " +
				// message.getSenderUsername() + " wanna goto "
				// + ((Vertex) message.getMessage()).getFullId());
				explorersGoingTo.add((Vertex) message.getMessage());
			}
		}
	}

}
