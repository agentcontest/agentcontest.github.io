package de.tub.mac14.bean;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

import org.w3c.dom.Document;

import de.dailab.jiactng.agentcore.IAgentBean;
import de.dailab.jiactng.agentcore.action.AbstractMethodExposingBean;
import de.dailab.jiactng.agentcore.action.Action;
import de.dailab.jiactng.agentcore.comm.CommunicationAddressFactory;
import de.dailab.jiactng.agentcore.comm.ICommunicationAddress;
import de.dailab.jiactng.agentcore.comm.ICommunicationBean;
import de.dailab.jiactng.agentcore.comm.IGroupAddress;
import de.dailab.jiactng.agentcore.comm.message.IJiacMessage;
import de.dailab.jiactng.agentcore.comm.message.JiacMessage;
import de.tub.mac14.common.Config;
import de.tub.mac14.common.Stats;
import de.tub.mac14.communication.Inform;
import de.tub.mac14.communication.Request;
import de.tub.mac14.connection.ActionFactory;
import de.tub.mac14.enums.MessageSubject;
import de.tub.mac14.graphutils.Pathmap;
import de.tub.mac14.ontology.Intention;
import de.tub.mac14.ontology.World;
import de.tub.mac14.strategy.Strategy;
import de.tub.mac14.strategy.StrategyAssigner;

public class DefaultDecisionBean extends AbstractMethodExposingBean {

	private World world;
	IGroupAddress teamChannel;
	PerceptionBean perceptionBean;
	ServerCommunicationBean serverCommunicationBean;
	Action sendAction;
	public Pathmap pathmap;
	
	StrategyAssigner strategyAssigner;
	
	private IGroupAddress groupAddress = null;

	public IGroupAddress getGroupAddress() {
		return groupAddress;
	}

	/**
	 * Send a request message to a given receiver.
	 * 
	 * @param recv
	 * @param subj
	 * @param payload
	 */
	public void sendRequest(ICommunicationAddress recv, MessageSubject subj, Object payload) {
		Action send = this.retrieveAction(ICommunicationBean.ACTION_SEND);
		Request req = new Request(this.thisAgent.getAgentDescription().getMessageBoxAddress(),
				world.getMe().usersuffix, world.getMe().role, subj, this.world.id, payload);
		JiacMessage transport = new JiacMessage(req);
		this.invoke(send, new Serializable[] { transport, recv });
	}
	
	/**
	 * Send an inform message to a given receiver.
	 * 
	 * @param recv
	 * @param subj
	 * @param payload
	 */
	public void sendInform(ICommunicationAddress recv, MessageSubject subj, Object payload) {
		Action send = this.retrieveAction(ICommunicationBean.ACTION_SEND);
		Inform inform = new Inform(this.thisAgent.getAgentDescription().getMessageBoxAddress(),
				world.getMe().usersuffix, world.getMe().role, subj, this.world.id, payload);
		JiacMessage transport = new JiacMessage(inform);
		this.invoke(send, new Serializable[] { transport, recv });
	}
	
	/**
	 * Send a request to the whole group. 
	 * 
	 * @param subj
	 * @param message
	 */
	public void sendRequestToGroup(MessageSubject subj, Object message) {
		sendRequest(this.groupAddress, subj, message);
	}
	
	/**
	 * Send an inform to the whole group.
	 * 
	 * @param subj
	 * @param message
	 */
	public void sendInformToGroup(MessageSubject subj, Object message) {
		sendRequest(this.groupAddress, subj, message);
	}
	
	/**
	 * Filter the messages received by this agent using the given
	 * request template. It uses the fields in the given template
	 * that are not 'null' trying to match these fields with the
	 * Request objects that are stored in the memory.
	 * 
	 * @param req The request template to filter the messages.
	 * @return A set with the payload of the matched messages.
	 */
	public Set<Request> filterReceivedRequests(Request req) {
		Set<Request> requests = new LinkedHashSet<>();
		
		// Filter all request messages
		Set<JiacMessage>message = memory
				.removeAll(new JiacMessage(req));
		
		// Parse the messages
		for (JiacMessage msg : message) {
			requests.add((Request)msg.getPayload());
			System.out.println(msg.getSender().getName());
		}
		
		return requests;
	}
	
	/**
	 * Filter the messages received by this agent using the given
	 * inform template. It uses the fields in the given template
	 * that are not 'null' trying to match these fields with the
	 * Inform objects that are stored in the memory.
	 * 
	 * @param req The inform template to filter the messages.
	 * @return A set with the payload of the matched messages.
	 */
	public Set<Inform> filterReceivedInforms(Inform inf) {
		Set<Inform> informs = new LinkedHashSet<>();
		
		// Filter all inform messages
		Set<JiacMessage>message = memory
				.removeAll(new JiacMessage(inf));
		
		// Parse the messages
		for (JiacMessage msg : message) {
			if (msg.getPayload() instanceof Inform) {
				informs.add((Inform) msg.getPayload());
			}
		}
		
		return informs;
	}
	
	/**
	 * Build a set with all the requests that this agent received
	 * 
	 * @return A set with the requests
	 */
	public Set<Request> receiveAllRequests() {
		return filterReceivedRequests(new Request());
	}
	
	/**
	 * Build a set with all the informs that this agent received
	 * 
	 * @return A set with the informs
	 */
	public Set<Inform> receiveAllInforms() {
		return filterReceivedInforms(new Inform());
	}
	
	public void deleteOldMessages() {
		Inform template = new Inform(world.id - 1);
		filterReceivedInforms(template);
	}

	/**
	 * Wait for a single inform. It scans for the message waiting
	 * <code>WAIT_MESSAGE_ITERATION_SLEEP</code> milliseconds between
	 * each search, and then return the first Inform that matches the given 
	 * filter or null if the message doesn't arrive in <code>WAIT_MESSAGE_TIMEOUT</code>
	 * milliseconds.
	 * 
	 * @param inf An Inform Filter
	 * @return The first message that arrives and matches the filter or <code>null</code>
	 * if the timeout is reached
	 */
	public Inform waitForInform(Inform inf) {
		Set<Inform> res = waitForInform(inf, 1);
		if (res == null) {
			return null;
		}
		Iterator<Inform> it = res.iterator();
		if (it.hasNext()) {
			return it.next();
		}
		return null;
	}

	public Set<Inform> waitForInform(Inform inf, int amount) {
		Set<Inform> res = new LinkedHashSet<>();
		
		Integer stepSleep = Config.getInt("WAIT_MESSAGE_ITERATION_SLEEP");
		Integer timeout = Config.getInt("WAIT_MESSAGE_TIMEOUT");
		Integer elapsedTime = 0;
		res = new HashSet<Inform>();
		do {
			res.addAll(filterReceivedInforms(inf));
			
			if (res.size() < amount) {
				try {
					Thread.sleep(stepSleep);
				} catch (InterruptedException e) {
					return null;
				}
			}
			elapsedTime += stepSleep;
			
		} while (res.size() < amount
				&& (System.currentTimeMillis() - serverCommunicationBean.t0 < timeout));
		
		return (res.size() < amount ? null : res);
	}

	
	public void setWorld(World world) {
		this.world = world;
		// Somewhere the Stats singleton has to learn the world.
		// Let it be here
		if (world.usersuffix.equals(1)) {
			Stats.getInstance().setWorld(world);
		}

		// The StrategyAssigner can only be initialized if the world is set.
		// So initialize the StrategyAssigner here.
		this.strategyAssigner = new StrategyAssigner(this);

	}
    
    public void restart(){
        this.world = null;
        this.strategyAssigner= null;
        Stats.getInstance().clear();
        this.pathmap = null;
    }

	public World getWorld() {
		return this.world;
	}

	@Override
	public void doInit() {
		this.groupAddress = CommunicationAddressFactory
				.createGroupAddress(Config.get("TEAM_COMM_GROUP_NAME"));
	}
	
	@Override
	public void doStart() {
		Action join = this.retrieveAction(ICommunicationBean.ACTION_JOIN_GROUP);
		this.invoke(join, new Serializable[] { groupAddress });
		
		for (IAgentBean ab : thisAgent.getAgentBeans()) {
			if (ab instanceof PerceptionBean) {
				this.perceptionBean = ((PerceptionBean) ab);
				this.teamChannel = perceptionBean.teamChannel;
			}
			if (ab instanceof ServerCommunicationBean) {
				this.serverCommunicationBean = (ServerCommunicationBean) ab;
			}
		}
		// retrieving needed actions from own CommunicationBean
		sendAction = memory.read(new Action(
				"de.dailab.jiactng.agentcore.comm.ICommunicationBean#send",
				null, new Class[] { IJiacMessage.class,
						ICommunicationAddress.class }, null));
		if (sendAction == null)
			throw new RuntimeException("Could not find Communication...1");
	}

	public void decide() {
		strategyAssigner.newRound();
		deleteOldMessages();

		// Output stats
		if (world.usersuffix.equals(1)) {
			Stats.getInstance().update();
			Stats.getInstance().output();
		}
		// Wait for all Perceptions to arrive.
		synchronized (world.lock) {
			try {
				while (!world.allPerceptionsReceived()) {
					world.lock.wait(100);
				}
			} catch (InterruptedException e) {
			}
		}

		updatePathmap();
		world.updateHotspots();

		Strategy strategy;
		while((strategy = strategyAssigner.nextStrategy()) != null) {
			if (strategy.isDisabled()) {
				continue;
			}
			Intention intention = strategy.decide();
			if (intention == null) {
				continue;
			}
			sendActionResponse(intention);
			
			break;
		}
	}

	public void sendActionResponse(Intention intention) {
		try {
			Document response = ActionFactory.getAction(intention.action,
					intention.param, "" + getWorld().id);
			serverCommunicationBean.sendActionResponse(response);
			// System.out.println("SENT " + intention.action + " id=" +
			// getWorld().id);
		} catch (NullPointerException e) {
			e.printStackTrace();
			System.err.println("agent: " + getWorld().username);
		}
	}
	
	private void updatePathmap() {
		pathmap = new Pathmap(world.getMe().position);
	}

}
