/**
 * All robots will first execute this BasicStrategy.
 * Here we should decide if the robot should do a parry Action.
 * Also if the energy is 0, we can send a recharge Action here.
 */
package de.tub.mac14.strategy;

import de.tub.mac14.bean.DefaultDecisionBean;
import de.tub.mac14.common.Config;
import de.tub.mac14.enums.RobotAction;
import de.tub.mac14.enums.Role;
import de.tub.mac14.enums.Team;
import de.tub.mac14.ontology.Intention;
import de.tub.mac14.ontology.Robot;
import de.tub.mac14.ontology.Vertex;

import java.util.Random;
import java.util.Set;

public class BasicStrategy extends Strategy {

    Random parryRandomizer;
    // In order to randomize the parrying, if we realize, that the agents parry to often
    public static final int parryChance = Config.getInt("PARRY_CHANCE");

	public BasicStrategy(DefaultDecisionBean bean) {
            super(bean);
            parryRandomizer = new Random(System.nanoTime());
	}

	@Override
	public Intention decide() {
		if (me.energy.equals(0)) {
			return new Intention(RobotAction.RECHARGE, null);
		}

        // Check, if there is a saboteur on my position ( and if i'm no saboteur, as a saboteur should attack and not parry)
		boolean saboteur = false;
		boolean someoneelse = false;
		for(Robot r : world.getRobotsOn(me.position)) {
			if (r.position != null && r.role != null && r.team == Team.ENEMY && r.role == Role.SABOTEUR) {
				saboteur = true;
			}
			if (r.position != null && r.role != null && r.team == Team.WE && !r.equals(me)) {
				someoneelse = true;
			}
		}

		if (saboteur && !(me.role == Role.SABOTEUR && !me.isDisabled())) { //  && !me.isDisabled()) {
			if (someoneelse || me.isDisabled() || me.role == Role.SABOTEUR || me.role == Role.EXPLORER || me.role == Role.INSPECTOR) {
				return checkedGoto(randomNeighbor());
			} else if (me.energy > 1) {
				return new Intention(RobotAction.PARRY, null);
			} else {
				return new Intention(RobotAction.RECHARGE, null);
			}
		}
		
		Set<Vertex> neighbors = me.position.getNeighbors();
		boolean move = false;
		for (Vertex v : me.position.getNeighbors()) {
			for (Robot r : world.getRobotsOn(v)) {
				if (r.team == Team.ENEMY && r.position != null && r.role != null && r.role == Role.SABOTEUR) {
					if (r.position.getNeighbors().contains(me.position) && me.role != Role.SABOTEUR) {
						neighbors.remove(v);
						move = true;
					}
				}
			}
		}
		if (move && !neighbors.isEmpty()) {
			return checkedGoto(neighbors.iterator().next());
		}
		
		return null;
	}

}
