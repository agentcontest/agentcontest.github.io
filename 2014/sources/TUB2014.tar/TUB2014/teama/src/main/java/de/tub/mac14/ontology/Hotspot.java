package de.tub.mac14.ontology;

import java.util.HashSet;
import java.util.Set;

public class Hotspot {
	public Vertex center;
	public Set<Vertex> allVertices;
	public double value;
    public Set<Position> positions;

	/** allVertices + it's direct neighbors */
	public Set<Vertex> extendedNeighbors;

	public Hotspot(Vertex center, Set<Vertex> allVertices, double value) {
		this.center = center;
		this.allVertices = allVertices;
		this.value = value;

		extendedNeighbors = new HashSet<>();

		// If the hotspot is small, we use more neighbors because it could give
		// us a better ZoneScore.
		int radius = (allVertices.size() > 6) ? 1 : 2;
		for (Vertex v : allVertices) {
			extendedNeighbors.addAll(v.getNeighbors(radius, true));
		}
	}

	public int size() {
		return allVertices.size();
	}

	@Override
	public boolean equals(Object o) {
		return ((Hotspot) o).center.equals(this.center);
	}

	@Override
	public int hashCode() {
		return center.hashCode();
	}
}
