package de.tub.mac14.strategy;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;

import de.tub.mac14.bean.DefaultDecisionBean;
import de.tub.mac14.common.Tuple;
import de.tub.mac14.enums.RobotAction;
import de.tub.mac14.graphutils.Pathmap;
import de.tub.mac14.ontology.Intention;
import de.tub.mac14.ontology.Robot;
import de.tub.mac14.ontology.Vertex;
import de.tub.mac14.strategy.util.RankedEnemy;

/**
 * possible Actions: <lu><li>goto, parry, survey, buy, attack, recharge, skip</li>
 * </lu><br>
 * Props: <lu> <li>
 * Energy: 7</li><li>
 * Health: 3</li><li>
 * Strength: 4</li><li>
 * Vis_Range: 1</li></lu>
 * 
 * @author jens
 * 
 */
public class SaboteurMasterStrategy extends Strategy {
	private static final Integer ENEMY_HITLIST_UPGRADE = 10;
	private static final Integer ENEMY_HITLIST_DECAY = 1;
	private static final Integer ENEMY_HITLIST_PROBABLY_DISABLED = 12;
	private static final CharSequence FAILURE_PARRIED = "failed parried";
	private static int MAX_SABOTEURS_TO_INVADE_BASES = 2;
	private final int FIRST_SABOTEUR_SUFFIX = 13;
	protected final int EXTERMINATION_COST = 2;
	protected int EXTERMINATION_RANGE = 1; // aka visibility_range
	private int MAX_GOTO_RANGE = 4;
	private String nickName = "DARLEK KAHN";

	protected int ENEMY_ON_SAME_LOCATION_RANK = 7;
	protected int ENEMY_REACHABLE_RANK = 5;
	private int[] ENEMY_ROLE_BONI = { 2, 10, 5, 0, 0 };
	private int MAX_HOTSPOT_DISTANCE = 7;

	protected RankedEnemy lastAim = null;
	private static HashMap<Robot, Integer> hitList = new HashMap<Robot, Integer>();

	private SaboteurExploringStrategy sabExplStrategy;
	private SaboteurAggressorStrategy sabAggStrategy;

	static boolean scoringDebug = false;
	static boolean hitlistDebug = false;
	static boolean decisionDebug = true;

	/**
	 * just provide a bean and have everything else on default
	 * 
	 * @param bean
	 */
	public SaboteurMasterStrategy(DefaultDecisionBean bean) {
		super(bean);
	}

	/**
	 * 
	 * @param bean
	 */
	public SaboteurMasterStrategy(DefaultDecisionBean bean,
			SaboteurParams params) {
		this(bean);

		this.sabExplStrategy = new SaboteurExploringStrategy(bean, params);
		this.sabAggStrategy = new SaboteurAggressorStrategy(bean, params);

		MAX_GOTO_RANGE = params.getMAX_GOTO_RANGE() == null ? MAX_GOTO_RANGE
				: params.getMAX_GOTO_RANGE();
		/*
		 * the following value needs to be higher than MaxGotoRange because the
		 * scoring method won't be positive for enemies that far away otherwise.
		 */
		ENEMY_REACHABLE_RANK = params.getENEMY_REACHABLE_RANK() == null ? MAX_GOTO_RANGE + 1
				: params.getENEMY_REACHABLE_RANK(); // TODO jens: this is ugly

		ENEMY_ON_SAME_LOCATION_RANK = params.getENEMY_ON_SAME_LOCATION_RANK() == null ? ENEMY_ON_SAME_LOCATION_RANK
				: params.getENEMY_ON_SAME_LOCATION_RANK();
		RankedEnemy.ENEMY_ROLE_BONI = params.getENEMY_ROLE_BONI() == null ? ENEMY_ROLE_BONI
				: params.getENEMY_ROLE_BONI();
		EXTERMINATION_RANGE = params.getVISIBILITY_RANGE() == null ? EXTERMINATION_RANGE
				: params.getVISIBILITY_RANGE();
		MAX_HOTSPOT_DISTANCE = params.getMAX_HOTSPOT_DISTANCE() == null ? MAX_HOTSPOT_DISTANCE
				: params.getMAX_HOTSPOT_DISTANCE();
		MAX_SABOTEURS_TO_INVADE_BASES = params
				.getMAX_SABOTEURS_TO_INVADE_BASES() == null ? MAX_SABOTEURS_TO_INVADE_BASES
				: params.getMAX_SABOTEURS_TO_INVADE_BASES();
	}

	@Override
	public Intention decide() {
		if (me == null || me.position == null) {
			if (scoringDebug)
				System.out.println(">> null");
			return null;
		}
		if (me.usersuffix == FIRST_SABOTEUR_SUFFIX) {
			decreaseHitList();
		}
		if (scoringDebug)
			System.out.println("> decide: " + me.username);
		validateLastAction();
		

		// recharge if a new attack would not be possible
		if (me.energy < EXTERMINATION_COST) {
			if (decisionDebug)
				System.out.println(">> decide: recharge");
			return new Intention(RobotAction.RECHARGE, null);
		}

		// INVADE SOME ENEMY BASES ?
		if (shallInvade()) {
			Intention sabExplInt = sabExplStrategy.decide();
			if (sabExplInt != null) {
				if (decisionDebug)
					System.out.println(">> decide: invade");
				return sabExplInt;
			}
		}

		// PROTECT HOTSPOT
		Vertex hotSpot;
		if (StrategyAssigner.hotspotAssignments.get(me) != null) {
			if ((hotSpot = StrategyAssigner.hotspotAssignments.get(me).center) != null) {
				LinkedList<Vertex> path = ddb.pathmap.getPath(hotSpot);
				if (path != null && path.size() > MAX_HOTSPOT_DISTANCE) {
					if (decisionDebug)
						System.out.println(">> decide: protect, goto "
								+ path.get(1));
					return checkedGoto(path.get(1));
				}
			}
		}

		if (decisionDebug)
			System.out.println(">> decide: aggressor");
		return sabAggStrategy.decide();

	}

	/**
	 * you shall invade if you are assigned to invade a certain hotspot or if
	 * there are not enough saboteurs that do so
	 * 
	 * @return
	 */
	private boolean shallInvade() {
		return SaboteurExploringStrategy.robotsThatExploreVertex.get(me) != null
				|| SaboteurExploringStrategy.robotsThatExploreVertex.size() < MAX_SABOTEURS_TO_INVADE_BASES;
	}

	/**
	 * we must check if the last attack was parried. validate if the last action
	 * was an attack and if its result was successful
	 */
	protected void validateLastAction() {
		if (me.lastActionResult.contains(FAILURE_PARRIED)) {
			// reverse last hitlist entry
			Integer val = hitList.get(lastAim.self);
			if (val == null) {
				return;
			}
			hitList.put(lastAim.self, val - ENEMY_HITLIST_UPGRADE);
		}
	}

	/**
	 * every round the points associated with the robots in this list shall
	 * decay. if the value is zero or less, the entry will be removed
	 */
	protected static void decreaseHitList() {
		LinkedList<Robot> removeList = new LinkedList<Robot>();
		for (Entry<Robot, Integer> entry : hitList.entrySet()) {
			entry.setValue(entry.getValue() - ENEMY_HITLIST_DECAY);
			if (entry.getValue() <= 0) {
				removeList.add(entry.getKey());
			}
		}
		for (Robot r : removeList) {
			hitList.remove(r);
		}

		if (hitlistDebug) {
			System.out.println(">>>>>> new round -- HITLIST: ");
			for (Entry<Robot, Integer> e : hitList.entrySet()) {
				System.out.println(">>>> \t" + e.getKey().username + "\t"
						+ e.getValue());
			}
		}
	}

	/**
	 * if an enemy was attacked, it will be added to the HitList. if the enemy
	 * is already listed, its associated value will be increased
	 * 
	 * @param aim
	 */
	protected void attacked(Robot aim) {
		Integer val = hitList.get(aim);
		if (val == null) {
			val = 0;
		}
		hitList.put(aim, val + ENEMY_HITLIST_UPGRADE);
		inspectEnemy(aim);
	}

	/**
	 * returns whether an enemy is probably disabled by our attacks by now.
	 * 
	 * @param r
	 * @return
	 */
	protected boolean probablyDisabled(Robot r) {
		if (hitList.get(r) == null)
			return false;
		return hitList.get(r) > ENEMY_HITLIST_PROBABLY_DISABLED;
	}

	/**
	 * have this entity explained. send over to inspectors
	 * 
	 * @param enemy
	 */
	protected void inspectEnemy(Robot enemy) {
		StrategyAssigner.needToBeInspectedEntities.add(enemy);

	}

	/**
	 * inspectors do not have to inspect this entity any more
	 * 
	 * @param enemy
	 */
	protected void dontInspectEnemy(Robot enemy) {
		for (Entry<Robot, Tuple<Robot, Integer>> entry : StrategyAssigner.whoInspectsWho
				.entrySet()) {
			if (entry.getValue().getFirst().equals(enemy)) {
				StrategyAssigner.whoInspectsWho.remove(entry.getKey());
			}
		}
		StrategyAssigner.needToBeInspectedEntities.remove(enemy);
	}

	/**
	 * returns whether this path is good to go
	 * 
	 * @param pathToEnemy
	 * @param position
	 * @return
	 */
	protected boolean validPath(List<Vertex> pathToEnemy, Vertex enemyPosition) {
		boolean inRange = pathToEnemy.size() < MAX_GOTO_RANGE;
		Vertex hotSpot;
		if (StrategyAssigner.hotspotAssignments.get(me) != null) {
			if ((hotSpot = StrategyAssigner.hotspotAssignments.get(me).center) != null) {
				Pathmap pmap = new Pathmap(hotSpot);
				if (pmap.getDistanceTo(enemyPosition) > MAX_HOTSPOT_DISTANCE) {
					return false;
				}
			}
		}
		return inRange;
	}

	/**
	 * who are you ?
	 */
	public String toString() {
		return "I AM " + nickName;
	}

	public static class SaboteurParams {
		private static final int NUMBER_OF_ROLES = 5;

		private Integer HOTSPOT_JUST_CHECKED = null;

		private Integer MAX_GOTO_RANGE = null;
		private Integer ENEMY_ON_SAME_LOCATION_RANK = null;
		private Integer VISIBILITY_RANGE = null;
		private Integer ENEMY_REACHABLE_RANK = null;
		private int[] ENEMY_ROLE_BONI = null;
		private Integer MAX_HOTSPOT_DISTANCE = null;
		private Integer MAX_SABOTEURS_TO_INVADE_BASES = null;

		public static SaboteurParams getNewInstance() {
			return new SaboteurParams();
		}

		/**
		 * The maximum range that is searched for enemies to be attacked
		 * 
		 * @param mAX_GOTO_RANGE
		 */
		public SaboteurParams setMAX_GOTO_RANGE(Integer mAX_GOTO_RANGE) {
			MAX_GOTO_RANGE = mAX_GOTO_RANGE;
			return this;
		}

		public Integer getENEMY_ON_SAME_LOCATION_RANK() {
			return ENEMY_ON_SAME_LOCATION_RANK;
		}

		public Integer getMAX_GOTO_RANGE() {
			return MAX_GOTO_RANGE;
		}

		public Integer getMAX_SABOTEURS_TO_INVADE_BASES() {
			return MAX_SABOTEURS_TO_INVADE_BASES;
		}

		public SaboteurParams setMAX_SABOTEURS_TO_INVADE_BASES(Integer i) {
			MAX_SABOTEURS_TO_INVADE_BASES = i;
			return this;
		}

		/**
		 * A bonus that is set to rank an enemy that is on the same spot than
		 * this saboteur
		 * 
		 * @param eNEMY_ON_SAME_LOCATION_RANK
		 */
		public SaboteurParams setENEMY_ON_SAME_LOCATION_RANK(
				Integer eNEMY_ON_SAME_LOCATION_RANK) {
			ENEMY_ON_SAME_LOCATION_RANK = eNEMY_ON_SAME_LOCATION_RANK;
			return this;
		}

		public Integer getVISIBILITY_RANGE() {
			return VISIBILITY_RANGE;
		}

		/**
		 * should be used when upgraded
		 * 
		 * @param vISIBILITY_RANGE
		 */
		public SaboteurParams setVISIBILITY_RANGE(Integer vISIBILITY_RANGE) {
			VISIBILITY_RANGE = vISIBILITY_RANGE;
			return this;
		}

		public Integer getENEMY_REACHABLE_RANK() {
			return ENEMY_REACHABLE_RANK;
		}

		/**
		 * the following value needs to be higher than MaxGotoRange because the
		 * scoring method won't be positive for enemies that far away otherwise.
		 * 
		 * @param eNEMY_REACHABLE_RANK
		 */
		public SaboteurParams setENEMY_REACHABLE_RANK(
				Integer eNEMY_REACHABLE_RANK) {
			ENEMY_REACHABLE_RANK = eNEMY_REACHABLE_RANK;
			return this;
		}

		public int[] getENEMY_ROLE_BONI() {
			return ENEMY_ROLE_BONI;
		}

		/**
		 * An array containing the boni for each role that is used while scoring
		 * which enemy to attack.<br>
		 * The order of this boni is the same as the Role-Enums ordinels.<br>
		 * <p>
		 * new int[]{EXPLORER, REPAIRER, SABOTEUR, SENTINEL, INSPECTOR}
		 * </p>
		 * 
		 * @param eNEMY_ROLE_BONI
		 */
		public SaboteurParams setENEMY_ROLE_BONI(int[] eNEMY_ROLE_BONI) {
			if (eNEMY_ROLE_BONI != null
					&& eNEMY_ROLE_BONI.length == NUMBER_OF_ROLES)
				ENEMY_ROLE_BONI = eNEMY_ROLE_BONI;
			return this;
		}

		public Integer getMAX_HOTSPOT_DISTANCE() {
			return MAX_HOTSPOT_DISTANCE;
		}

		/**
		 * The maximum distance that a saboteur should have to a hotspot
		 * assigned to it. This interferes with MAX_GOTO_RANGE.
		 * 
		 * @param mAX_HOTSPOT_DISTANCE
		 */
		public SaboteurParams setMAX_HOTSPOT_DISTANCE(
				Integer mAX_HOTSPOT_DISTANCE) {
			MAX_HOTSPOT_DISTANCE = mAX_HOTSPOT_DISTANCE;
			return this;
		}

		public Integer getHOTSPOT_JUST_CHECKED() {
			return HOTSPOT_JUST_CHECKED;
		}

	}

	public int getEXTERMINATION_RANGE() {
		return EXTERMINATION_RANGE;
	}

	/**
	 * Use if saboteur was upgraded
	 * 
	 * @param eXTERMINATION_RANGE
	 */
	public void setEXTERMINATION_RANGE(int eXTERMINATION_RANGE) {
		EXTERMINATION_RANGE = eXTERMINATION_RANGE;
	}

}
