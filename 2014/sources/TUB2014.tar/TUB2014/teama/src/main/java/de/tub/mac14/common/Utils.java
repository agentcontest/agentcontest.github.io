/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package de.tub.mac14.common;

import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Class, that contains static utitlity methods, that may come in handy.
 * @author mattu
 */
public class Utils {
	
	
	/**
	 * This method extracts all of the Element-child-nodes from parent, 
	 * and casts it to org.w3c.dom.Element
	 * @param parent
	 * @return 
	 */
	public static ArrayList<Element> getElementChildrenFromNode(Node parent){
		NodeList nodeChildren = parent.getChildNodes();
		ArrayList<Element> elementChildren = new ArrayList<>();
		
		for(int i = 0; i < nodeChildren.getLength(); i++){
			if(nodeChildren.item(i).getNodeType() == Node.ELEMENT_NODE){
				elementChildren.add((Element) nodeChildren.item(i));					
			}
		}
		
		return elementChildren;
	}
	/**
	 * Remove all non-digit-Characters 
	 * @param string
	 * @return 
	 */
	public static int getNumericalSuffix(String string){
		Matcher m = Pattern.compile("\\d+").matcher(string);
		m.find();
		return Integer.parseInt(m.group());
	}
	
	public static void printStringRepresentationOfDocument(Document doc) throws TransformerConfigurationException, TransformerException, UnsupportedEncodingException{
		TransformerFactory tf = TransformerFactory.newInstance();
    Transformer transformer = tf.newTransformer();
    transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
    transformer.setOutputProperty(OutputKeys.METHOD, "xml");
    transformer.setOutputProperty(OutputKeys.INDENT, "yes");
    transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");

    transformer.transform(new DOMSource(doc), 
         new StreamResult(new OutputStreamWriter(System.out, "UTF-8")));
	}
	
	
}
