/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package de.tub.mac14.logging;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;

/**
 *
 * @author mattu
 */
public class Logger {
	static int msgBeforeFlush = 20;
	int flush = 0;
	final static int lineswrite = 2000;
	String name;
	long id;
	
	boolean append;
	
	File outFile;
	
	FileWriter outStream;
	
	public  boolean isMain;
	
	private HashMap<String, Logger> childLogger;
	
	private Logger parent;
	
	
	public Logger(String name, String outFile, boolean append) {
		File loggerFolder = new File("logs");
		if(!loggerFolder.exists() || !loggerFolder.isDirectory()){
			loggerFolder.mkdirs();
		}
		this.append = append;
		this.name = name;
		this.id = System.currentTimeMillis();
		this.outFile = new File("logs/" + outFile);
		this.isMain = false;
		this.childLogger = new HashMap<>();
		try {
			
			outStream = new FileWriter(outFile, append);
            
		} catch (FileNotFoundException ex) {
			java.util.logging.Logger.getLogger(Logger.class.getName()).log(Level.SEVERE, null, ex);
		} catch (IOException ex) {
			java.util.logging.Logger.getLogger(Logger.class.getName()).log(Level.SEVERE, null, ex);
		}
	}
	
	public Logger(String name, String logPath,  String fileName, boolean append) {
		File loggerFolder = new File(logPath);
		if(!loggerFolder.exists() || !loggerFolder.isDirectory()){
			loggerFolder.mkdirs();
		}
		this.append = append;
		this.name = name;
		this.childLogger = new HashMap<>();
		
		this.outFile = new File(logPath + fileName);
		System.out.println(this.outFile.getAbsolutePath());
		this.isMain = false;
		try {
			outStream = new FileWriter(this.outFile, append);
		} catch (FileNotFoundException ex) {
			java.util.logging.Logger.getLogger(Logger.class.getName()).log(Level.SEVERE, null, ex);
		} catch (IOException ex) {
			java.util.logging.Logger.getLogger(Logger.class.getName()).log(Level.SEVERE, null, ex);
		}
	}
	
	public Logger(String name, boolean append) {
		this.append = append;
		this.name = name;
		this.id = System.currentTimeMillis();
		this.outFile = new File(name+".log");
		this.childLogger = new HashMap<>();

		
		try {
			this.outStream = new FileWriter(outFile, append);
		} catch (FileNotFoundException ex) {
			java.util.logging.Logger.getLogger(Logger.class.getName()).log(Level.SEVERE, null, ex);
		} catch (IOException ex) {
			java.util.logging.Logger.getLogger(Logger.class.getName()).log(Level.SEVERE, null, ex);
		}
	}
	
	
	public void log(String msg){
		flush++;
		try {
			outStream.append(msg + "\n");
            if(flush > msgBeforeFlush){
                flush = 0;
                outStream.flush();
            }
		} catch (IOException ex) {
			throw new RuntimeException("Something went wrong while Logging!", ex);
		}
		
		
		if (isMain) {
			if (this.name.equals("error")) {
				System.err.println(msg);
			} else {
				System.out.println(msg);
			}
		}
		
	}

	public void makeMainLog() {
		this.isMain = true;
	}
	
	public void unmakeMainLog(){
		this.isMain = false;
	}
	
	/**
	 * This method returns the logger with the given name that is a 
	 * child of this logger. If there is no child logger with the specified name, 
	 * this method returns null
	 * @param name The name of the logger, which may be a child of this logger
	 * @return a reference to the logger with the specified name
	 */
	public Logger getChildByName(String name){
		return this.childLogger.get(name);
	}
	
	public boolean hasChild(String name){
		return this.getChildByName(name)!= null;
	}
	
	public void addChild(Logger l){
		this.childLogger.put(l.name, l);
	}
	
	public ArrayList<Logger> getChildren(){
		ArrayList<Logger> loggers = new ArrayList<>();
		for(String loggerName : this.childLogger.keySet()){
			loggers.add(this.childLogger.get(loggerName));
		}
		
		return loggers;
	}
	
	public void close(){
		System.out.println("Closing Logger: " + this.outFile.getName());
		try {
			this.outStream.flush();
			this.outStream.close();
		} catch (IOException ex) {
			throw new RuntimeException("Unable to close Logger: " + this.outFile.getName(), ex);
		}
	}
	
	
	
}
