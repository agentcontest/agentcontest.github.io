/**
 * This strategy will be assigned to sentinels because they have a range of 3.
 * It will do a survey action, when there are at least 
 * SURVEY_STRATEGY_MIN_UNKNOWN unknown edges in range.
 */
package de.tub.mac14.strategy;

import de.tub.mac14.bean.DefaultDecisionBean;
import de.tub.mac14.common.Config;
import de.tub.mac14.enums.RobotAction;
import de.tub.mac14.ontology.Intention;
import de.tub.mac14.ontology.Vertex;

public class SurveyStrategy extends Strategy {

	public SurveyStrategy(DefaultDecisionBean bean) {
		super(bean);
	}

	@Override
	public Intention decide() {
		if (me.isDisabled()) {
			return null;
		}
		for (Vertex v : me.position.getNeighbors()) {
			if (!me.position.getEdgeTo(v).isSurveyed()) {
				return new Intention(RobotAction.SURVEY, null);
			}
		}
		return null;
	}
}
