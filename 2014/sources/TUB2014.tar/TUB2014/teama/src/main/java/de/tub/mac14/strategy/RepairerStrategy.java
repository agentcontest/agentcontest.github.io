package de.tub.mac14.strategy;

import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;

import com.sun.xml.internal.bind.v2.schemagen.xmlschema.List;

import de.tub.mac14.bean.DefaultDecisionBean;
import de.tub.mac14.common.Log;
import de.tub.mac14.communication.Inform;
import de.tub.mac14.enums.MessageSubject;
import de.tub.mac14.enums.RobotAction;
import de.tub.mac14.enums.Role;
import de.tub.mac14.enums.Team;
import de.tub.mac14.ontology.Intention;
import de.tub.mac14.ontology.Robot;
import de.tub.mac14.ontology.Vertex;
import de.tub.mac14.strategy.util.RankedBrokenRobot;
import de.tub.mac14.strategy.util.RankedEnemy;

public class RepairerStrategy extends Strategy {

	private final int REPAIR_COST_ENABLED = 2;
	private final int REPAIR_COST_DISABLED = 3;
	
	public RepairerStrategy(DefaultDecisionBean bean) {		
		super(bean);
	}

	@Override
	public Intention decide() {
		if (me == null) {
			return new Intention(RobotAction.SKIP, null);
		}
		if ((me.energy < REPAIR_COST_DISABLED && me.isDisabled()) || (!me.isDisabled()
				&& (me.energy < REPAIR_COST_ENABLED))) {
			return new Intention(RobotAction.RECHARGE, null);
		}

		// FELIX SIMPLE REPAIR
		LinkedList<Robot> otherRepairers = world.filterRobots(Team.WE, Role.REPAIRER);
		otherRepairers.remove(me);
		LinkedList<RankedBrokenRobot> brokenList = new LinkedList<RankedBrokenRobot>();
		for (Robot r : world.getOurRobots()) {
			if (!r.isDisabled() || r.equals(me)) {
				continue;
			}
			if (r.position.equals(me.position) || r.position.getNeighbors().contains(me.position)) {
				brokenList.add(new RankedBrokenRobot(r, me, otherRepairers));
			}
		}
		Robot bestRobot = null;
		if (!brokenList.isEmpty()) {
			Collections.sort(brokenList);
			Collections.reverse(brokenList);
			bestRobot = brokenList.get(0).self;
			if (brokenList.size() > 1) {
				for (Robot r : otherRepairers) {
					if (r.position.equals(me.position) && r.usersuffix > me.usersuffix) {
						if (!r.isDisabled()) {
							bestRobot = brokenList.get(1).self;
						}
					}
				}
			}
		}
		if (bestRobot != null) {
			if (me.position.equals(bestRobot.position)) {
				// REPAIR
				return new Intention(RobotAction.REPAIR, bestRobot.username);
			} else {
				// GOTO
				return checkedGoto(bestRobot.position);
			}
		}
		// FELIX SIMPLE REPAIR END

		Set<Robot> robotsToRepair = waitForMessages();
		if (robotsToRepair == null || robotsToRepair.isEmpty()) {
			return null;
		}

		Robot nearestRobot = null;
		int bestDistance = 99999;
		for (Robot r : robotsToRepair) {
			int distance = ddb.pathmap.getDistanceTo(r.position);
			if (distance != -1 && distance < bestDistance) {
				nearestRobot = r;
				bestDistance = distance;
			}
		}
		if (nearestRobot == null) {
			return null;
		}
		return checkedGoto(nearestRobot.position);
	}

	private Set<Robot> waitForMessages() {
		Inform template = new Inform(MessageSubject.REPAIR_ME);
		template.setStep(world.id);
		Set<Inform> message = ddb.waitForInform(template, countDisabledRobots());
		if (message == null) {
			Log.log("debug.strategy.repair", "ERROR: " + world.getMe().username + ": Nothing happend");
			return null;
		}

		Log.log("debug.strategy.repair", world.getMe().username +
				": Messages received");

		// filter informs
		HashSet<Robot> robots_to_repair = new HashSet<Robot>();
		for (Inform i : message) {
			Robot r = (Robot) i.getMessage();
			if (r != null && r.equals(me)) {
				robots_to_repair.add(world.getOurRobot(i.getSenderUsersuffix()));
			}
		}
		return robots_to_repair;
	}
	
	private int countDisabledRobots() {
		int count = 0;
		for (Robot r : world.ourRobots) {
			if (r.isDisabled()) {
				count++;
			}
		}
		return count;
	}

}
