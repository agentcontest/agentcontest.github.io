package de.tub.mac14.strategy;

import de.tub.mac14.bean.DefaultDecisionBean;
import de.tub.mac14.ontology.Hotspot;
import de.tub.mac14.ontology.Intention;
import de.tub.mac14.ontology.Vertex;
import de.tub.mac14.strategy.Strategy;
import de.tub.mac14.strategy.StrategyAssigner;

import java.util.LinkedList;

/**
 * This Strategy lets a robot move to its designated zoning area. 
 * Once its reached the hotspot, the zoningStrategy takes over.
 * @author mattu
 */
public class GotoHotspotStrategy extends Strategy{

    public GotoHotspotStrategy(DefaultDecisionBean bean) {
        super(bean);
    }

    @Override
    public Intention decide() {
        // calculate a distance, in which the robot should be
		Hotspot myHotSpot = StrategyAssigner.hotspotAssignments.get(me);
		if (myHotSpot == null) {
			return null;
		}
		if (myHotSpot.extendedNeighbors.contains(me.position)) {
			// We are there
			return null;
		}
		LinkedList<Vertex> path = ddb.pathmap.getPath(myHotSpot.center);
		if (path == null || path.isEmpty()) {
			return null;
        }
		return super.checkedGoto(path.get(1));
    }
    
}
