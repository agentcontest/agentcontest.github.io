package de.tub.mac14.common;

import de.tub.mac14.logging.DomainLogger;
import de.tub.mac14.logging.XMLDomainLoggerBuilder;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.xml.sax.SAXException;

/**
 * Use this class to log messages to the logfiles
 * @author mrGizmo
 */
public class Log {
    private static XMLDomainLoggerBuilder loggerBuilder;
    private static DomainLogger logger;
    
    static{
        try {
            loggerBuilder = new XMLDomainLoggerBuilder(new File("src/main/resources/loggerConfig.xml"));
            logger = loggerBuilder.getDomainLogger();
        } catch (SAXException ex) {
            throw new RuntimeException(ex.toString());
        } catch (IOException ex) {
            throw new RuntimeException("Unable to Load file: ", ex);
        }
    }
    
    /**
     * This Method logs the given string to the specified main-logger, causing 
     * the message to be printed on stdOut and into the logfiles
     * @param message 
     */
	public synchronized static void log(String message) {
        logger.log(message);
    }
    
    /**
     * This message causes the specified message to be logged to the specified 
     * domain logger, including all of its super-loggers.
     * @param domain the logger, to which it should be logged, in the form of java-packet notation (i.e.: strategy.debug.explorer)
     * @param message the message to be logged
     */
	public synchronized static void log(String domain, String message) {
        logger.log(domain, message);
    }
}
