package de.tub.mac14.connection;

public interface MessageConstants {
	/** states the action success */

	/**
	 * possible agent actions
	 */

	public static final String ACTION_SKIP = "skip";
	public static final String ACTION_GOTO = "goto";
	public static final String ACTION_ATTACK = "attack";
	public static final String ACTION_PARRY = "parry";
	public static final String ACTION_PROBE = "probe";
	public static final String ACTION_SURVEY = "survey";
	public static final String ACTION_INSPECT = "inspect";
	public static final String ACTION_REPAIR = "repair";
	public static final String ACTION_BUY = "buy";
	public static final String ACTION_RECHARGE = "recharge";

	/**
	 * possible message types
	 */

	public static final String MESSAGE_ACTION_REQUEST = "request-action";
	public static final String MESSAGE_ACTION_RESPONSE = "action";
	public static final String MESSAGE_AUTH_RESPONSE = "auth-response";
	public static final String MESSAGE_AUTH_REQUEST = "auth-request";
	public static final String MESSAGE_SIM_START = "sim-start";
	public static final String MESSAGE_SIM_END = "sim-end";
	public static final String MESSAGE_BYE = "bye";
}
