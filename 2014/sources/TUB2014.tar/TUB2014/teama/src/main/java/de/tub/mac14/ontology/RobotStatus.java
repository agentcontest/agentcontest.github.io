/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package de.tub.mac14.ontology;

import java.io.Serializable;

/**
 *This Class represents the status of a single robot. This includes 
 * stuff like the current health and energy. Currently it is used to store 
 * informations from a received perception conveniently. Probably needs to be 
 * extended sometime in the future.
 * @author mattu
 */
public class RobotStatus implements Serializable{
    
    
    public Integer energy;
    public Integer maxEnergy;
    public Integer maxEnergyDisabled;
    
    public Integer health;
    public Integer maxHealth;
    
    public Integer strength;
    
    public Integer visRange;
           
    public Integer zoneScore;
    
    public String position;
    
	public String team;
	public String name;
	
	public String role;
	
    public String lastAction;
    public String lastActionParam;
    public String lastActionResult;
    
    /**
	 * Default constructor for the Builder classes
	 */
	public RobotStatus(){
		
	}
	
	public String toString(){
		String out = "";
		
		return out;
	}
    
}
