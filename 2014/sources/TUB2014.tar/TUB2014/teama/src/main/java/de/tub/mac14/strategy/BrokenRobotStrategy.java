package de.tub.mac14.strategy;

import de.tub.mac14.bean.DefaultDecisionBean;
import de.tub.mac14.enums.MessageSubject;
import de.tub.mac14.enums.RobotAction;
import de.tub.mac14.enums.Role;
import de.tub.mac14.enums.Team;
import de.tub.mac14.ontology.Intention;
import de.tub.mac14.ontology.Robot;
import de.tub.mac14.ontology.Vertex;

public class BrokenRobotStrategy extends Strategy {

	public BrokenRobotStrategy(DefaultDecisionBean bean) {
		super(bean);
	}

	@Override
	public Intention decide() {
		if (!me.isDisabled()) {
			return null;
		}
		Robot repairer = findNearestRepairer();

		if (repairer != null) {
			// send REPAIR_ME message
			ddb.sendInform(ddb.getGroupAddress(), MessageSubject.REPAIR_ME, repairer);

			for(Robot r : world.getRobotsOn(me.position)) {
				if (r.position != null && r.role != null && r.team == Team.ENEMY && r.role == Role.SABOTEUR) {
					return null;
				}
			}
			
			if (me.position.getNeighbors(1, true).contains(repairer.position)) {
				// Hold still if the Doctor is near.
				// (Don't be afraid - It does't hurt!)
				if (me.role == Role.REPAIRER && me.usersuffix < repairer.usersuffix) {
					// Avoid 2 broken repairers livelock
					return null;
				}
				return new Intention(RobotAction.RECHARGE, null);
			}
			if (me.role == Role.REPAIRER) {
				// even if a repairer is disabled, it should execute the
				// repairerStrategy if a other broken robot is near
				if (brokenRobotIsNear()) {
					return null;
				}
			}
			return checkedGoto(ddb.pathmap.getPath(repairer.position).get(1));
		}
		// no repairer found yet, send REPAIR_ME message anyway
		ddb.sendInform(ddb.getGroupAddress(), MessageSubject.REPAIR_ME, null);
		return checkedGoto(randomNeighbor());
	}

	private boolean brokenRobotIsNear() {
		for (Vertex v : me.position.getNeighbors(1, true)) {
			for (Robot r : world.getRobotsOn(v)) {
				if (r.team == Team.WE && r.isDisabled() && !r.equals(me)) {
					return true;
				}
			}
		}
		return false;
	}

	private Robot findNearestRepairer() {
		Robot bestRobot = null;
		int bestDistance = 99999;
		for (Robot r : world.filterRobots(Team.WE, Role.REPAIRER)) {
			int distance = ddb.pathmap.getDistanceTo(r.position);
			if (distance != -1 && !r.equals(me) && distance < bestDistance) {
				bestDistance = distance;
				bestRobot = r;
			}
		}
		return bestRobot;
	}

}
