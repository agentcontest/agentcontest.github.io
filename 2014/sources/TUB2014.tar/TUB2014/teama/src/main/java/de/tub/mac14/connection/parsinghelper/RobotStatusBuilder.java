/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package de.tub.mac14.connection.parsinghelper;

import de.tub.mac14.common.Utils;
import de.tub.mac14.enums.Role;
import de.tub.mac14.ontology.RobotStatus;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collection;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.w3c.dom.Element;

/**
 * This class is used to construct a RobotStatu object from the appropriate
 * dom-element.
 * 
 * @author mattu
 */
public class RobotStatusBuilder {

	public static RobotStatus buildRobotStatusFromSelf(Element self, String name) {
		RobotStatus status = new RobotStatus();
		status.name = name;
		status.role = roleFromName(name);
		// The Fields are named like the corresponding attributes of the <self>
		// element.
		// This way, we can use the name of the Field to dynamically get an
		// Attribute by
		// name:
		// iterate over all fields in this class
		for (Field currentField : status.getClass().getFields()) {
			try {
				// if we found an integer, use Integer.parseInt() when reading
				// attribute valued
				if (currentField.getType().getSimpleName()
						.equalsIgnoreCase("Integer")) {

					// first, cut of the leadig 'i' from the name
					String attributeName = currentField.getName();
					if (self.hasAttribute(attributeName)) {
						// then set the field of this class to the specefied
						// value
						currentField.set(status, Integer.parseInt(self
								.getAttribute(attributeName)));
					}
				} else if (currentField.getType().getSimpleName()
						.equalsIgnoreCase("string")) {
					// the same wonderful things apply to the fields, that have
					// a string as a value
					String attributeName = currentField.getName();
					// but without Integer.parseInt()
					if (self.hasAttribute(attributeName)) {
						currentField.set(status,
								self.getAttribute(attributeName));
					} else if (attributeName.equalsIgnoreCase("position")
							&& self.hasAttribute("node")) {
						currentField.set(status, self.getAttribute("node"));
					}

				}
			} catch (SecurityException | IllegalAccessException ex) {
				Logger.getLogger(RobotStatus.class.getName()).log(Level.SEVERE,
						null, ex);
				throw new RuntimeException(
						"Excpetion while parsing domFile or setting Values of RobotStatus. ",
						ex);
			}
		}

		return status;
	}

	/**
	 * try to get a role from the name retrieved
	 * 
	 * @param name
	 * @return
	 */
	private static String roleFromName(String name) {
		int id = Utils.getNumericalSuffix(name);
		if (id > 0)
			if (id < 7) { // explorer
				return Role.EXPLORER.toString();
			} else if (id < 13) { // repairer
				return Role.REPAIRER.toString();
			} else if (id < 17) { // saboteur
				return Role.SABOTEUR.toString();
			} else if (id < 23) { // sentinel
				return Role.SENTINEL.toString();
			} else if (id < 29) { // inspector
				return Role.INSPECTOR.toString();
			}
		return null;
	}

	public static ArrayList<RobotStatus> buildRobotStatusFromVisibleEntities(
			Element currentElement, ArrayList<RobotStatus> robots) {
		// System.out.println("> buildRobotStatusFromVisibleEntities");
		ArrayList<Element> eles = Utils
				.getElementChildrenFromNode(currentElement);
		for (Element ele : eles) {
			// System.out.println(">>> visible: " + ele.getAttribute("name"));
			robots.add(RobotStatusBuilder.buildRobotStatusFromSelf(ele,
					ele.getAttribute("name")));
		}
		return robots;
	}

	public static Collection<? extends RobotStatus> buildRobotStatusFromInspectedEntities(
			Element currentElement, ArrayList<RobotStatus> robots) {
		// System.out.println("> buildRobotStatusFromInspectedEntities");
		ArrayList<Element> eles = Utils
				.getElementChildrenFromNode(currentElement);
		for (Element ele : eles) {
			// System.out.println(">>> visible: " + ele.getAttribute("name"));
			robots.add(RobotStatusBuilder.buildRobotStatusFromSelf(ele,
					ele.getAttribute("name")));
		}
		return robots;
	}
}
