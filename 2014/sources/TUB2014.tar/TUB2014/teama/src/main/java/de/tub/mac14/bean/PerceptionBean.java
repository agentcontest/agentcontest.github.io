package de.tub.mac14.bean;

import de.dailab.jiactng.agentcore.IAgentBean;
import de.dailab.jiactng.agentcore.action.AbstractMethodExposingBean;
import de.dailab.jiactng.agentcore.action.Action;
import de.dailab.jiactng.agentcore.comm.CommunicationAddressFactory;
import de.dailab.jiactng.agentcore.comm.ICommunicationAddress;
import de.dailab.jiactng.agentcore.comm.IGroupAddress;
import de.dailab.jiactng.agentcore.comm.message.IJiacMessage;
import de.dailab.jiactng.agentcore.comm.message.JiacMessage;
import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac14.connection.MessageParser;
import de.tub.mac14.ontology.AuthResponse;
import de.tub.mac14.ontology.Authentication;
import de.tub.mac14.ontology.Bye;
import de.tub.mac14.ontology.Intention;
import de.tub.mac14.ontology.Perception;
import de.tub.mac14.ontology.RobotStatus;
import de.tub.mac14.ontology.SimEnd;
import de.tub.mac14.ontology.World;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Set;

import org.sercho.masp.space.event.SpaceEvent;
import org.sercho.masp.space.event.SpaceObserver;
import org.sercho.masp.space.event.WriteCallEvent;
import org.w3c.dom.Document;

/**
 * This agent component handles all related to perception:
 * - Server messages
 * - Messages from other agents
 *  
 * @author axle
 */
public class PerceptionBean extends AbstractMethodExposingBean {

	private String username;
	private MessageParser messageParser;

	private ServerCommunicationBean serverCommunicationBean;
	private DefaultDecisionBean decisionBean;

	/** Actions to communicate with other team members. */
	private Action sendAction, registerAction;

	/** The channel where agents of one team share their knowledge. */
	public IGroupAddress teamChannel;
	public long time;

	public World world;

	public String getTeamChannel() {
		return this.teamChannel.toString();
	}

	public void setTeamChannel(String teamChannel) {
		this.teamChannel = CommunicationAddressFactory
				.createGroupAddress(teamChannel);
	}

	@Override
	public void doInit() throws Exception {
		super.doInit();
                
                //Search the Agent for the Perception and SeverCommunication bean
		for (IAgentBean ab : thisAgent.getAgentBeans()) {
			if (ab instanceof ServerCommunicationBean) {
				this.serverCommunicationBean = (ServerCommunicationBean) ab;
				//Initialize the Parser of the XML-Messenges
                                messageParser = new MessageParser(
						serverCommunicationBean.getUsername());
			} else if (ab instanceof DefaultDecisionBean) {
				this.decisionBean = (DefaultDecisionBean) ab;
			}
		}

		SpaceObserver<IFact> messageObserver = new SpaceObserver<IFact>() {
			private static final long serialVersionUID = -2109274101459190774L;

			@Override
			public void notify(SpaceEvent<? extends IFact> event) {
				// System.err.println(event.toString());
				if (event instanceof WriteCallEvent) {
					Object eventObj = ((WriteCallEvent) event).getObject();
					if (eventObj instanceof IJiacMessage) {
						IJiacMessage message = (IJiacMessage) eventObj;

						if (message != null) {
							IFact payload = message.getPayload();

							if (payload instanceof Perception) {
								message = memory.remove(message);
								Perception perception = (Perception) payload;

								// ignore own perception that we have received
								// via team channel
								if (!perception.username.equals(username)) {

									// only process actual perceptions and when
									// world is initialized
									if (world != null) {
										world.update(perception);
									}
								}
							} 
						}
					}
				}
			}
		};
		memory.attach(messageObserver);

	}

	public void doStart() throws Exception {
		super.doStart();

		Authentication auth = memory.read(new Authentication(null, null));
		if (auth != null) {
			this.username = auth.getUsername();
		} else {
			System.err.println("NO AUTHENTICATION FOUND");
		}

		// retrieving needed actions from own CommunicationBean
		sendAction = memory.read(new Action(
				"de.dailab.jiactng.agentcore.comm.ICommunicationBean#send",
				null, new Class[] { IJiacMessage.class,
						ICommunicationAddress.class }, null));
		if (sendAction == null)
			throw new RuntimeException("Could not find Communication...1");
                
		registerAction = memory
				.read(new Action(
						"de.dailab.jiactng.agentcore.comm.ICommunicationBean#joinGroup",
						null, new Class[] { IGroupAddress.class }, null));
		if (registerAction == null)
			throw new RuntimeException("Could not find Communication...2");

		invoke(registerAction, new Serializable[] { this.teamChannel });
	}

	public void processServerMessage(Document message) {
		IFact parseResult = messageParser.parse(message);

		time = System.nanoTime();

		if (parseResult instanceof Perception) {

			// Perception received
			Perception perception = (Perception) parseResult;

			// send own perception to other agents
			sendPerception(perception);

			if (world != null) {
				world.update(perception);
				decisionBean.decide();
			} else {
				System.err.println("## [INFO] Agent " + this.username
						+ " received ActionRequest before process SimStart!");
			}
		}

		else if (parseResult instanceof World) {

			// SimStart received
			world = (World) parseResult;

			decisionBean.setWorld(world);
			memory.write(world);
			
			//Propagate Perception with only the role of ourself
			Perception p = new Perception(username);
			RobotStatus myStatus = new RobotStatus();
			myStatus.name = username;
			myStatus.role = world.getMe().role.toString();
			p.robots = new ArrayList<RobotStatus>();
			p.robots.add(myStatus);
			sendPerception(p);
			if (memory.readAllOfType(World.class).size() == 1) {
				System.err.println("World found!!!");
			} else {
				System.err.println("World not found!!!");
			}
		}

		else if (parseResult instanceof SimEnd) {
			// SimEnd received
			SimEnd simEnd = (SimEnd) parseResult;
			//simEnd.setSimName(world.simulationId);
			memory.write(simEnd);

			memory.remove(world);
			world = null;
            decisionBean.restart();

			System.out.println(simEnd);
		}

		else if (parseResult instanceof Bye) {

			Set<SimEnd> results = memory.readAllOfType(SimEnd.class);
			for (SimEnd rse : results) {
				System.out.println(rse);
			}
			System.out.flush();

			Runtime.getRuntime().halt(666);

		}

		else if (parseResult instanceof AuthResponse) {
			String s = ((AuthResponse) parseResult).isAuthSuccessful() ? "AUTHENTICATION OK!"
					: "AUTHENTICATION FAILED!";
			System.out.println(s);
		}

	}

	/**
	 * Sends the own perception to all team members.
	 * 
	 * @param perception
	 *            the perception object to send
	 */
	private void sendPerception(Perception perception) {
		JiacMessage msg = new JiacMessage(perception);
		Serializable[] params = new Serializable[2];
		params[0] = msg;
		params[1] = this.teamChannel;
		invoke(sendAction, params);
	}

	/**
	 * Sends the own intention to all team members.
	 * 
	 * @param intention
	 *            the intention object to send
	 */
	public void sendIntention(Intention intention) {
		JiacMessage msg = new JiacMessage(intention);
		Serializable[] params = new Serializable[2];
		params[0] = msg;
		params[1] = this.teamChannel;
		invoke(sendAction, params);
	}
}
