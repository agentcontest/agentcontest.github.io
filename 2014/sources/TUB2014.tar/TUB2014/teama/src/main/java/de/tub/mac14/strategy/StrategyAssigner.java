package de.tub.mac14.strategy;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

import de.tub.mac14.bean.DefaultDecisionBean;
import de.tub.mac14.common.Log;
import de.tub.mac14.common.Tuple;
import de.tub.mac14.ontology.Hotspot;
import de.tub.mac14.ontology.Robot;
import de.tub.mac14.ontology.World;

public class StrategyAssigner {

	private final DefaultDecisionBean ddb;
	private final World world;
	private final Robot me;

	/**
	 * In this queue the strategies for this robot are saved. The robot will
	 * first execute the first strategy in the queue. If the strategy returns
	 * null, it will continue with the seccond one - and so on and so on...
	 */
	private final LinkedList<Strategy> strategyQueue;
	private int currentStrategy = -1;

	/**
	 * In this HashMap it is saved which robot follows which currently.<br>
	 * (key = follower, value = master)
	 */
	static public ConcurrentHashMap<Robot, Robot> whoFollowsWho = new ConcurrentHashMap<Robot, Robot>();

	/**
	 * The GotoHotspotStrategy uses this field to determine to which hotspot to
	 * go.
	 */
	static public ConcurrentHashMap<Robot, Hotspot> hotspotAssignments = new ConcurrentHashMap<>();

	/**
	 * This field is going to be cleared every round. If a robot enters first in
	 * the ZoningStrategy it will set itself as a master.
	 */
	static private HashMap<Hotspot, Robot> masterZoner = new HashMap<>();
	static private int round = -1;

	/**
	 * This is where we list all entities that are unknown and need to be
	 * inspected ASAP!<br>
	 * The Inspectors will take care of who is approaching this aim.
	 */
	static public ConcurrentLinkedQueue<Robot> needToBeInspectedEntities = new ConcurrentLinkedQueue<Robot>();

	/**
	 * should only be used by Inspectors to organize their work
	 */
	static public ConcurrentHashMap<Robot, Tuple<Robot, Integer>> whoInspectsWho = new ConcurrentHashMap<Robot, Tuple<Robot, Integer>>();

	/**
	 * Constructor
	 */
	public StrategyAssigner(DefaultDecisionBean ddb) {
		this.ddb = ddb;
		this.world = ddb.getWorld();
		this.me = world.getMe();

		this.strategyQueue = new LinkedList<Strategy>();

		// Assign strategies according to our role to the queue.
		switch (me.role) {
		case EXPLORER:
			this.strategyQueue.add(new BrokenRobotStrategy(ddb));
			this.strategyQueue.add(new BasicStrategy(ddb));
			this.strategyQueue.add(new SurveyStrategy(ddb));
			this.strategyQueue.add(new ExplorerStrategy(ddb));
			this.strategyQueue.add(new AssignHotspotStrategy(ddb));
			this.strategyQueue.add(new FollowRobotZoningStrategy(ddb));
			this.strategyQueue.add(new ZoningStrategy(ddb));
			this.strategyQueue.add(new FallbackStrategy(ddb));
			break;
		case SABOTEUR:
			// this.strategyQueue.add(new BuyStrategy(ddb));
			this.strategyQueue.add(new BrokenRobotStrategy(ddb));
			// this.strategyQueue.add(new BuyStrategy(ddb));
			this.strategyQueue.add(new BasicStrategy(ddb));
			this.strategyQueue.add(new SurveyStrategy(ddb));
//			this.strategyQueue.add(new SaboteurMasterStrategy(ddb,
//					SaboteurParams
//							.getNewInstance()
							// protect a range of 3 Edges
//							.setMAX_GOTO_RANGE(5)
							// see java doc for more info.
//							.setENEMY_ROLE_BONI(new int[] { 2, 5, 10, 0, 0 })
							// with this config a saboteur will always be
							// attacked first
							// if not a enemy rapairer is on the same note than
							// our one
//							.setENEMY_ON_SAME_LOCATION_RANK(7)
//							.setMAX_HOTSPOT_DISTANCE(7)));
			this.strategyQueue.add(new SaboteurSimpleStrategy(ddb));
			this.strategyQueue.add(new GotoExplorerStrategy(ddb));
			this.strategyQueue.add(new FollowRobotZoningStrategy(ddb));
			this.strategyQueue.add(new ZoningStrategy(ddb));
			this.strategyQueue.add(new FallbackStrategy(ddb));
			break;
		case INSPECTOR:
			this.strategyQueue.add(new BrokenRobotStrategy(ddb));
			this.strategyQueue.add(new BasicStrategy(ddb));
			this.strategyQueue.add(new SurveyStrategy(ddb));
			// this.strategyQueue.add(new InspectorStrategy(ddb));
			this.strategyQueue.add(new AssignHotspotStrategy(ddb));
			this.strategyQueue.add(new GotoExplorerStrategy(ddb));
			this.strategyQueue.add(new FollowRobotZoningStrategy(ddb));
			this.strategyQueue.add(new ZoningStrategy(ddb));
			this.strategyQueue.add(new FallbackStrategy(ddb));
			break;
		case REPAIRER:
			this.strategyQueue.add(new BrokenRobotStrategy(ddb));
			this.strategyQueue.add(new BasicStrategy(ddb));
			this.strategyQueue.add(new SurveyStrategy(ddb));
			this.strategyQueue.add(new RepairerStrategy(ddb));
			this.strategyQueue.add(new AssignHotspotStrategy(ddb));
			this.strategyQueue.add(new GotoExplorerStrategy(ddb));
			this.strategyQueue.add(new FollowRobotZoningStrategy(ddb));
			this.strategyQueue.add(new ZoningStrategy(ddb));
			this.strategyQueue.add(new FallbackStrategy(ddb));
			break;
		case SENTINEL:
			this.strategyQueue.add(new BrokenRobotStrategy(ddb));
			this.strategyQueue.add(new BasicStrategy(ddb));
			this.strategyQueue.add(new SurveyStrategy(ddb));
			this.strategyQueue.add(new BottleneckStrategy(ddb));
			this.strategyQueue.add(new AssignHotspotStrategy(ddb));
			this.strategyQueue.add(new GotoExplorerStrategy(ddb));
			this.strategyQueue.add(new FollowRobotZoningStrategy(ddb));
			this.strategyQueue.add(new ZoningStrategy(ddb));
			this.strategyQueue.add(new FallbackStrategy(ddb));
			break;
		default:
			break;
		}

		newRound();
	}

	public static Robot getMaster(Robot follower) {
		return StrategyAssigner.whoFollowsWho.get(follower);
	}

	public static void setMaster(Robot follower, Robot master) {
		StrategyAssigner.whoFollowsWho.put(follower, master);

		// TODO felix: uncomment this when the logger works.
		// List<Robot> sortedKeys = new
		// ArrayList<Robot>(whoFollowsWho.keySet());
		// Collections.sort(sortedKeys);
		//
		// System.out.println("---------whoFollowsWho-----------");
		// for (Robot r : sortedKeys) {
		// System.out.println(r.username + " --- " +
		// whoFollowsWho.get(r).username);
		// }
		// System.out.println("---------------------------------");
	}

	public void newRound() {
		this.currentStrategy = -1;
		synchronized (masterZoner) { // just in case...
			if (round != world.id) {
				round = world.id;
				Log.log("stats", "NEW ROUND: " + round);
				masterZoner.clear();
			}
		}
	}

	public Strategy nextStrategy() {
		currentStrategy++;
		if (strategyQueue.size() <= currentStrategy) {
			return null;
		}
		return strategyQueue.get(currentStrategy);
	}

	public static synchronized Robot pleaseLetMeBeTheMasterOhPleaseOhPlease(
			Hotspot hotspot, Robot robot) {
		if (!masterZoner.containsKey(hotspot)) {
			masterZoner.put(hotspot, robot);
		}
		return masterZoner.get(hotspot);
	}
}
