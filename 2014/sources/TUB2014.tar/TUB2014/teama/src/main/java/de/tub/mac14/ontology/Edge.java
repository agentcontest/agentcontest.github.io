/**
 * A Edge between two Vertices.
 * @author Felix
 */

package de.tub.mac14.ontology;

import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac14.common.Config;

public class Edge implements IFact, Cloneable {
	private static final long serialVersionUID = -6644156139899741595L;

	// Let always v1.id < v2.id
	protected Vertex v1;
	protected Vertex v2;
	private Integer value; // -1 if unknown

	/**
	 * Constructor
	 */
	public Edge(Vertex v1, Vertex v2) {
		if (v1.getId() < v2.getId()) {
			this.v1 = v1;
			this.v2 = v2;
		} else {
			this.v2 = v1;
			this.v1 = v2;
		}
		value = -1;
	}
	
	/**
	 * Constructor with the value
	 * @param v1
	 * @param v2
	 * @param value
	 */
	public Edge(Vertex v1, Vertex v2, Integer value) {
		if (v1.getId() < v2.getId()) {
			this.v1 = v1;
			this.v2 = v2;
		} else {
			this.v2 = v1;
			this.v1 = v2;
		}
		this.value = value;
	}

	public boolean isSurveyed() {
		return (value > -1);
	}

	public String toString() {
		return "(" + v1.getId() + ", " + v2.getId() + "):" + value;
	}
	
	public void setValue(int value) {
		this.value = value;
	}
	
	public int getValue() {
		return (value == -1) ? Config.getInt("DEFAULT_EDGE_WEIGHT") : value;
	}
	
	@Override
	public boolean equals(Object o) {
		if (!(o instanceof Edge)) {
			return false;
		}
		Edge other = (Edge) o;
		return (this.v1.equals(other.v1) && this.v2.equals(other.v2));
	}
	
	/**
	 * We need to provide a custom hashCode so the HashSet will recognize
	 * identical Edges. The hashCode can be simple. If collisions occur equals()
	 * will be called.
	 */
	@Override
	public int hashCode() {
		return v1.getId() + v2.getId();
	}

	public Vertex getNeighbor(Vertex from) {
		if (v1.equals(from)) {
			return v2;
		} else if (v2.equals(from)) {
			return v1;
		} else {
			throw new IllegalArgumentException("Vertex illegal");
		}
	}
}
