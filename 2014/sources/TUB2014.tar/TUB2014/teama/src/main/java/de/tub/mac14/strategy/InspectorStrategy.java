package de.tub.mac14.strategy;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Map.Entry;
import java.util.Set;

import de.tub.mac14.bean.DefaultDecisionBean;
import de.tub.mac14.common.Tuple;
import de.tub.mac14.enums.RobotAction;
import de.tub.mac14.ontology.Intention;
import de.tub.mac14.ontology.Robot;
import de.tub.mac14.ontology.Vertex;

public class InspectorStrategy extends Strategy {

	private final int INSPECTION_COST = 2;
	private final int FIRST_INSPECTOR_SUFFIX = 23;

	boolean inspectorDebug = true;

	public InspectorStrategy(DefaultDecisionBean bean) {
		super(bean);
	}

	@Override
	public Intention decide() {
		if (me.usersuffix == FIRST_INSPECTOR_SUFFIX) {
			newRound();
		}
		if (me == null || me.position == null)
			return null;
		if (me.energy == null || me.energy < INSPECTION_COST)
			return new Intention(RobotAction.RECHARGE, null);

		// if we are already assigned to inspect a robot, do so
		if (!StrategyAssigner.whoInspectsWho.isEmpty()) {
			Intention res = followOrdersOnList(StrategyAssigner.whoInspectsWho
					.entrySet());
			if (res != null)
				return res;
		}

		// if not, lets work on the assigning list
		LinkedList<InterrestingEntity> entityList = new LinkedList<InterrestingEntity>();
		if (!StrategyAssigner.needToBeInspectedEntities.isEmpty()) {
			LinkedList<Vertex> path;
			for (Robot r : StrategyAssigner.needToBeInspectedEntities) {
				if (r.position != null) {
					path = ddb.pathmap.getPath(r.position);
					if (path != null)
						entityList.add(new InterrestingEntity(r, path));
				}
			}
			if (!entityList.isEmpty()) {
				Collections.sort(entityList);
				Collections.reverse(entityList);
				// we stole this aim from someone else, delete him from the list
				LinkedList<Robot> removeList = new LinkedList<Robot>();
				for (Entry<Robot, Tuple<Robot, Integer>> entry : StrategyAssigner.whoInspectsWho
						.entrySet()) {
					if (entry.getValue().getFirst()
							.equals(entityList.getFirst().getRobot())) {
						removeList.add(entry.getKey());
					}
				}
				for (Robot r : removeList) {
					StrategyAssigner.whoInspectsWho.remove(r);
				}
				// inspect
				inspect(entityList.getFirst().getRobot(), entityList.getFirst()
						.getPath());
			}
		}

		// let's see if we are closer to some enemy to be inspected than our
		// colleagues
		entityList.clear();
		if (!StrategyAssigner.whoInspectsWho.isEmpty()) {
			LinkedList<Vertex> path;
			for (Entry<Robot, Tuple<Robot, Integer>> entry : StrategyAssigner.whoInspectsWho
					.entrySet()) {
				if (entry.getValue() != null
						&& entry.getValue().getFirst().position != null) {
					path = ddb.pathmap
							.getPath(entry.getValue().getFirst().position);
					if (path != null
							&& path.size() < entry.getValue().getSecond()) {
						entityList.add(new InterrestingEntity(entry.getValue()
								.getFirst(), path));
					}
				}
			}
			if (!entityList.isEmpty()) {
				Collections.sort(entityList);
				Collections.reverse(entityList);
				// we stole this aim from someone else, delete him from the list
				LinkedList<Robot> removeList = new LinkedList<Robot>();
				for (Entry<Robot, Tuple<Robot, Integer>> entry : StrategyAssigner.whoInspectsWho
						.entrySet()) {
					if (entry.getValue().getFirst()
							.equals(entityList.getFirst().getRobot())) {
						removeList.add(entry.getKey());
					}
				}
				for (Robot r : removeList) {
					StrategyAssigner.whoInspectsWho.remove(r);
				}
				inspect(entityList.getFirst().getRobot(), entityList.getFirst()
						.getPath());
			}
		}

		// otherwise help with some other strategy
		return null;
	}

	private void newRound() {
		if (inspectorDebug) {
			System.out.println(">>>>>> need to be inspected:");
			for (Robot r : StrategyAssigner.needToBeInspectedEntities)
				System.out.println(">>> " + r.username);
			System.out.println(">>>>>> who inspects who:");
			for (Entry<Robot, Tuple<Robot, Integer>> e : StrategyAssigner.whoInspectsWho.entrySet()){
				System.out.println(">>> "+e.getKey().username+" \t--> "+e.getValue().getFirst().username);
			}
		}
	}

	/**
	 * If we are enlisted here as key, inspect the robot in it's value
	 * 
	 * @param set
	 *            (key = probably me, value_tuple = robot to inspect; distance
	 *            between me and robot)
	 * @return null if we are not on this list or the operation failed
	 */
	private Intention followOrdersOnList(
			Set<Entry<Robot, Tuple<Robot, Integer>>> set) {
		for (Entry<Robot, Tuple<Robot, Integer>> entry : set) {
			if (entry.getKey().equals(me)) {
				return inspect(entry.getValue().getFirst());
			}
		}
		return null;
	}

	/**
	 * Inspect a Robot.<br>
	 * This may includes walking to it and deleting it from any task list.
	 * 
	 * @param aim
	 *            the robot to inspect
	 * @return null if this can not be done
	 */
	private Intention inspect(Robot aim) {
		try {
			LinkedList<Vertex> path = ddb.pathmap.getPath(aim.position);
			return inspect(aim, path);
		} catch (Exception e) {
			// TODO: Add Logging message by time
		}
		return null;
	}

	/**
	 * Inspect a Robot.<br>
	 * This may includes walking to it and deleting it from any task list.
	 * 
	 * @param aim
	 *            the robot to inspect
	 * @param path
	 * @return
	 */
	private Intention inspect(Robot aim, LinkedList<Vertex> path) {
		StrategyAssigner.needToBeInspectedEntities.remove(aim);
		StrategyAssigner.whoInspectsWho.put(me, new Tuple<Robot, Integer>(aim,
				path.size()));
		try {
			if (aim.position != null && aim.position.equals(me.position)) {
				robotInspected(aim, me);
				return new Intention(RobotAction.INSPECT, null);
			}
			return checkedGoto(path.get(1));
		} catch (Exception e) {
			// TODO: Add Logging message by time
		}
		return null;
	}

	/**
	 * mark the aimed robot as inspected by me.
	 * 
	 * @param aim
	 * @param me
	 */
	private void robotInspected(Robot aim, Robot me) {
		StrategyAssigner.whoInspectsWho.remove(me);
		StrategyAssigner.needToBeInspectedEntities.remove(aim);
	}

	/**
	 * 
	 * 
	 * @author jens
	 * 
	 */
	private class InterrestingEntity implements Comparable<InterrestingEntity> {
		private Robot self;
		private int distance;
		private LinkedList<Vertex> path;

		public InterrestingEntity(Robot r, LinkedList<Vertex> path) {
			this.self = r;
			this.distance = path.size();
			this.path = path;
		}

		public LinkedList<Vertex> getPath() {
			return path;
		}

		public int getDistance() {
			return distance;
		}

		public Robot getRobot() {
			return self;
		}

		@Override
		public int compareTo(InterrestingEntity o) {
			return Integer.compare(getDistance(), o.getDistance());
		}

	}

}
