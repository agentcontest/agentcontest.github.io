/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package de.tub.mac14;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author mattu
 */
public class RunServer {
	
	public static void main(String[] args) {
		String hostname;
		
		File runningFolder;
		if(args.length != 0 && !args[0].equals("")){
			runningFolder = (new File(args[0]));
		}else{
			System.out.println("The Folder of agentcontest-2013-1.4.jar has not been specified, for example: /home/mattu/NetBeansProject/pjmac-sose2014/common/ac13-contest-server");
			return;
		}
		try {
			hostname = InetAddress.getLocalHost().getHostName();
		} catch (UnknownHostException ex) {
			System.out.println("Retrieving the hostname failed! " + ex.getLocalizedMessage());
			return;
		}
		ProcessBuilder pb = new ProcessBuilder(System.getProperty("java.home") + File.separator + "bin" + File.separator + "java", "-ea","-Dcom.sun.management.jmxremote","-Xss2000k", "-Xmx600M" ,"-DentityExpansionLimit=1000000", "-DelementAttributeLimit=1000000" ,"-Djava.rmi.server.hostname="+hostname, "-jar", "agentcontest-2013-1.4.jar", "--conf" ,"conf/2013-3sims.xml");
		
		pb.directory(runningFolder);
		// Redirect Console input
		pb.redirectInput(ProcessBuilder.Redirect.INHERIT);
		// But discard output
		pb.redirectOutput(new File("/dev/null"));

		try {
			final Process p = pb.start();
			Runtime.getRuntime().addShutdownHook(new Thread() {
				@Override
				public void run() {
					p.destroy();
				}
			});
		} catch (IOException ex) {
			Logger.getLogger(RunServer.class.getName()).log(Level.SEVERE, null, ex);
		}

		}
		
	
	
}
