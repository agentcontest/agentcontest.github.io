package de.tub.mac14.strategy;

import de.tub.mac14.bean.DefaultDecisionBean;
import de.tub.mac14.ontology.Hotspot;
import de.tub.mac14.ontology.Intention;
import de.tub.mac14.ontology.Robot;
import de.tub.mac14.ontology.Vertex;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

/**
 * This strategy shall be an improved version of the simple FollowRobotStrategy.
 * The plan is to make the robots swarm around a hotspot or follow a master
 * while caring about zoning, so that there won't be 4 robots on the same spot
 * following a master.
 * 
 * @author mattu
 */
public class FollowRobotZoningStrategy extends Strategy{
	
	/**
	 * Default constructor which calls super(). Pass the DefaultDecisionBean in order 
	 * to enable the agent communication for this strategy.
	 * @param ddb The default decision bean this strategy belongs to.
	 */
	public FollowRobotZoningStrategy(DefaultDecisionBean ddb){
		super(ddb);
	}
	
	/**
	 * This Method decides, what to do next. It searches goal vertex (hotspot or
	 * master) for all nodes with a distance of 2. Then, every follower is
	 * assigned a node it should travel to in order to surround the goal evenly.
	 * 
	 * @return The Intention which contains either a goto to the preferred node
	 *         or a Recharge operation, if the Robot does not have enough energy
	 *         for the desired goto
	 */
	@Override
	public Intention decide() {
		// First determine the goal vertex and the other Robots following that
		// goal.
		Vertex goal = null;
		ArrayList<Robot> otherFollowingRobots = null;
		Hotspot goalHotspot = null;
		goalHotspot = StrategyAssigner.hotspotAssignments.get(me);
		if (goalHotspot == null) {
			Robot master = StrategyAssigner.getMaster(me);
			if (master != null) {
				goal = master.position;
				otherFollowingRobots = super.getOtherFollowingRobots(master);
			}
		} else {
			return null;
		}

		if (goal == null) { // We have no hotspot and no robot to follow
			return null;
		}
		// Now, the first task is to get All vertices, which have a maximum
		// distance to the goal of 2
		ArrayList<Vertex> possibleVertices = this.getAllVerticesAroundRobot2(goal);
		
		Vertex bestVertex;
		int numberOfFollowingRobots = otherFollowingRobots.size() + 1;
		
		// From now on, it is assumed, that the order of the otherFollowing robots is somewhat clockwise (or counter clockwise).
		// Although, this is not necessary or even true, it seems to work pretty good :)
		int spacing = possibleVertices.size() >= numberOfFollowingRobots ? possibleVertices.size() / numberOfFollowingRobots : 1;
		int position = 0;
		for (Robot otherRobot : otherFollowingRobots) { //get number of Robots with id lower than mine
			if (otherRobot.usersuffix < me.usersuffix) {
				position++;
			}
		}
		// now assign the desired vertex to bestVertex. Note, that this does not need to be the vertex we go to.
		bestVertex = possibleVertices.get((spacing * position) % possibleVertices.size());
		
		//Now we search the way to the best vertex...
		List<Vertex> bestPath = ddb.pathmap.getPath(bestVertex);
		// and assign the next node on the way to bestVertex
		if(bestPath.size() >1){
			bestVertex = bestPath.get(1);
		}else if(bestPath.isEmpty()){ // or take a random neighbor if there is no way.
			bestVertex = me.position.getNeighbors().iterator().next();
		}
		//note: if the size of  bestPath is 1, we do not need to do anything, as 
		// already are on the bestVertex.
		
		return checkedGoto(bestVertex);
		
	}
	
	/**
	 * This Method searches the surrounding of centerRobot for all Vertices that
	 * are 2 nodes apart from centerRobot. It just iterates over all the
	 * neighbors of the Neighbors,
	 * 
	 * @param goal The Robot, to which every returned node should have a
	 *            distance of 2
	 * @return An ArrayList containing the desired vertices.
	 */
	private ArrayList<Vertex> getAllVerticesAroundRobot2(Vertex goal) {
		
		HashSet<Vertex> surroundingVertices = new HashSet<>(goal.getNeighbors(2, false));
		int initSize = surroundingVertices.size();
		Vertex[] initVertices = surroundingVertices.toArray(new Vertex[1]);
		surroundingVertices.clear();
		for(int i = 0; i < initSize; i++){
			surroundingVertices.addAll(initVertices[i].getNeighbors());
		}
		
		surroundingVertices.remove(goal);
		
		return new ArrayList<Vertex>(surroundingVertices);
	}
	


}
