/**
 * This is a singleton which keeps track of some stats.
 */

package de.tub.mac14.common;

import java.util.LinkedList;

import de.tub.mac14.enums.Role;
import de.tub.mac14.ontology.Edge;
import de.tub.mac14.ontology.Vertex;
import de.tub.mac14.ontology.World;

public class Stats {
	private static Stats instance = null;

	private World world = null;

	public int currentStep = 0;
	public int allProbedStep = -1;
	public int failedRandom = 0;
	public int failedRange = 0;
	public int failedAttacked = 0;
	public int failedNoAction = 0;
	public int failed = 0;
	private LinkedList<Tuple<Role, Integer>> responseTimes;
	private LinkedList<Tuple<Role, Integer>> currentResponseTimes;

	private Stats() {
		responseTimes = new LinkedList<Tuple<Role, Integer>>();
		currentResponseTimes = new LinkedList<Tuple<Role, Integer>>();
		System.err.println("Created new instance of Stats.");
	}

	public void setWorld(World world) {
		this.world = world;
	}

	public synchronized static Stats getInstance() {
		if (instance == null) {
			instance = new Stats();
		}
		return instance;
	}

	public synchronized void addResponseTime(Role role, int time) {
		this.responseTimes.add(new Tuple<Role, Integer>(role, time));
		this.currentResponseTimes.add(new Tuple<Role, Integer>(role, time));
	}
	/**
	 * Should be called once per round
	 */
	public synchronized void update() {
		// Update currentStep
		this.currentStep = world.id;

		if (allProbedStep == -1) {
			// check if all vertices are probed:
			if (world.allProbed()) {
				allProbedStep = currentStep;
			}
		}
	}

	public synchronized void output() {
		Log.log("stats.game","---------Current Stats--------");
		Log.log("stats.game","Step: " + currentStep);
		Log.log("stats.game","Probed: " + world.probedVertices + "/" + world.numVertices);
		Log.log("stats.game","Money: " + world.money);
		if (allProbedStep != -1) {
			Log.log("stats.game","All Probed Step: " + allProbedStep);
		}
		Log.log("stats.game","Surveyed: " + world.surveyedEdges + "/" + world.numEdges);

		Log.log("stats.game","");
		Log.log("stats.game","Average Response Times (Current / All):");
		// for (Role role : Role.values()) {
		// Log.log("stats.game",role.toString() + ": "
		// + calculateAverageTime(currentResponseTimes, role)
		// + " / " + calculateAverageTime(responseTimes, role));
		// }
		Log.log("stats.game","All: " + calculateAverageTime(currentResponseTimes, null) + " / "
				+ calculateAverageTime(responseTimes, null));
		// Log.log("stats.game","\n");
		// Log.log("stats.game","Total actions: " + responseTimes.size());
		Log.log("stats.game","failed_random = " + failedRandom);
		Log.log("stats.game","failed_in_range = " + failedRange);
		Log.log("stats.game","failed_attacked = " + failedAttacked);
		Log.log("stats.game","failed noAction = " + failedNoAction);
		Log.log("stats.game","failed_* = " + failed);
		Log.log("stats.game","------------------------------");
		currentResponseTimes.clear();

	}

	private synchronized String calculateAverageTime(LinkedList<Tuple<Role, Integer>> list, Role role) {
		long timesSum = 0;
		int counter = 0;
		for (Tuple<Role, Integer> entry : list) {
			if (entry.getFirst() != role && role != null) {
				continue;
			}
			timesSum += entry.getSecond();
			counter++;
		}
		return Math.round(timesSum / (double) counter) + "ms";
	}

    public void clear() {
        instance = null;
    }
}
