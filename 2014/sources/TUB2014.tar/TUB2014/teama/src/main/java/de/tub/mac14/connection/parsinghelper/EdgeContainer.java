/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package de.tub.mac14.connection.parsinghelper;

import de.tub.mac14.common.Tuple;
import de.tub.mac14.common.Utils;

import java.io.Serializable;
import java.util.ArrayList;

import org.w3c.dom.Element;

/**
 *
 * @author mattu
 */
public class EdgeContainer implements Serializable{
	//Contains: <<node1,node2>, weight>
	public ArrayList<Tuple<Tuple<Integer, Integer>, Integer>> edges;
	
	public EdgeContainer(){
		this.edges = new ArrayList<>();
	}
	
	public void parseEdges(Element domEdges){
		ArrayList<Element> eles = Utils.getElementChildrenFromNode(domEdges);
		
		for(Element currentElement : eles){
			
			int n1id,n2id;
			
			String node1 = currentElement.getAttribute("node1");
			String node2 = currentElement.getAttribute("node2");
			
			n1id = Utils.getNumericalSuffix(node1);
			n2id = Utils.getNumericalSuffix(node2);
			
			Integer weight = currentElement.hasAttribute("weight")?Integer.parseInt(currentElement.getAttribute("weight")):null;
			
			Tuple<Integer, Integer> inner = new Tuple<>(n1id, n2id);
			Tuple<Tuple<Integer,Integer>, Integer> outer = new Tuple<>(inner, weight);
			
			this.edges.add(outer);
		}
	}
	
	
	@Override
	public String toString(){
		String out = "";
		
		for(Tuple<Tuple<Integer, Integer>,Integer> el:edges){
			out = out.concat("<");
			out = out.concat("<" + el.first.first + ", " + el.first.second + ">, ");
			out = out.concat((String) (el.second == null?"null" : el.second));
			out = out.concat("> ; ");
		}
		
		return out;
	}
	
	
	
	
	
	
}
