/**
 * This strategy does two things:
 * 
 * 1. At the beginning, if no explorer is in sight, it goes (randomly,
 * but not too randomly) around until an explorer is in sight.
 * 
 * 2. If one or more Explorer is in sight, the robot chooses which
 * Explorer to follow. It uses the static field
 * StrategyAssigner.whoFollowsWho to do so. It tells the StrategyAssigner
 * which explorer to follow but returns null. To followRobotStrategy will
 * goto this explorer.
 */
package de.tub.mac14.strategy;

import java.util.LinkedList;
import java.util.Map.Entry;

import de.tub.mac14.bean.DefaultDecisionBean;
import de.tub.mac14.common.Config;
import de.tub.mac14.enums.Role;
import de.tub.mac14.enums.Team;
import de.tub.mac14.ontology.Intention;
import de.tub.mac14.ontology.Robot;

public class GotoSaboteurStrategy extends Strategy {

	public GotoSaboteurStrategy(DefaultDecisionBean bean) {
		super(bean);
	}

	@Override
	public Intention decide() {
		LinkedList<Robot> saboteurs = world.filterRobots(Team.WE, Role.SABOTEUR);
		LinkedList<Robot> reachableSaboteurs = new LinkedList<Robot>();
		for (Robot saboteur : saboteurs) {
			if (ddb.pathmap.getDistanceTo(saboteur.position) != -1) {
				reachableSaboteurs.add(saboteur);
			}
		}
		if (!reachableSaboteurs.isEmpty()) {
			assignMasterSaboteur(reachableSaboteurs);
		}
		return null;
	}

	private void assignMasterSaboteur(LinkedList<Robot> reachableSaboteurs) {
		// Assign next explorer
		double bestScore = -999999;
		Robot bestSaboteur = null;
		for (Robot r : reachableSaboteurs) {
			double score = getScore(r);
			if (score > bestScore) {
				bestScore = score;
				bestSaboteur = r;
			}
		}
		StrategyAssigner.setMaster(me, bestSaboteur);
	}

	/**
	 * Evaluates which saboteur to follow by taking the following into account:
	 * > The distance to the saboteur > How many other robots of the same type
	 * are following a saboteur > How many other robots of any type are
	 * following a saboteur
	 */
	private double getScore(Robot saboteur) {
		int distance = ddb.pathmap.getDistanceTo(saboteur.position);

		// count followers
		int sameTypeFollowers = 0;
		int followers = 0;
		for (Entry<Robot, Robot> entry : StrategyAssigner.whoFollowsWho.entrySet()) {
			if (!entry.getValue().equals(saboteur) || entry.getKey() == me) {
				continue;
			}
			followers++;
			if (entry.getKey().role == me.role) {
				sameTypeFollowers++;
			}
		}
		// System.out.println(explorer.username + " has " + followers +
		// " followers");

		return -Config.getInt("GOTOSABOTEUR_STRATEGY_TYPEFOLLOWERS_FACTOR") * sameTypeFollowers
				- Config.getInt("GOTOSABOTEUR_STRATEGY_FOLLOWERS_FACTOR") * followers
				- distance;
	}


}
