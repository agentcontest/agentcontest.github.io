/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package de.tub.mac14.connection.parsinghelper;

import de.tub.mac14.common.Utils;
import de.tub.mac14.ontology.RobotStatus;
import de.tub.mac14.ontology.TeamStatus;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.w3c.dom.Element;

/**
 * This class is used to construct a TeamStatus object from 
 * the appropriate dom-element.
 * @author mattu
 */
public class TeamStatusBuilder {
	
	public static TeamStatus buildTeamStatusFromDom(Element team){
		TeamStatus status = new TeamStatus();
		// The Fields are named like the corresponding attributes of the <team> element. 
        //This way, we can use the name of the Field to dynamically get an Attribute by 
        //name:
        //iterate over all fields in this class
        for (Field currentField : status.getClass().getFields()) { 
            try {
                if (currentField.getType().getSimpleName().equalsIgnoreCase("int")) {
                    // first, cut of the leadig 'i' from the name                    
                    String attributeName = currentField.getName();
                    
					// then set the field of this class to the specefied value 
                    if(team.hasAttribute(attributeName)){
						currentField.set(status, Integer.parseInt(team.getAttribute(attributeName)));
					}
                }
            } catch (SecurityException | IllegalAccessException ex) {
                Logger.getLogger(RobotStatus.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        //currently, we are at the <team>-element. One step deeper in the tree lies 
        // the <achievements>- element, which holds many <achievement> elements:
        //  <team>
        //      <achievements>
        //          <achievement></achievement>
        //          <achievement></achievement>
        //      </achievements>
        //  </team>
        // if there exists a <achievements> element, we retrieve it from the team-node
        ArrayList<Element> children = Utils.getElementChildrenFromNode(team);
        // and then retrieve all the <achievement>-elements
        // if there is no <achievements> element, the size of the list will be 0
        // and the  for-loop will not be executed.
        if(children.size() > 0) children = Utils.getElementChildrenFromNode(children.get(0));
        for(int i = 0; i < children.size(); i++){
            Element child =  children.get(i);
            if(child.getTagName().equalsIgnoreCase("achievement")){
                status.achievementNames.add(child.getAttribute("name"));
            }
        }
		
		
		return status;
	}
	
}
