package de.tub.mac14.communication;

import de.dailab.jiactng.agentcore.comm.IMessageBoxAddress;
import de.dailab.jiactng.agentcore.knowledge.IFact;
import de.tub.mac14.enums.MessageSubject;
import de.tub.mac14.enums.Role;

/**
 * Main message class. Used to send information to other agents
 * using JIACMessages.
 * 
 * @author lucas
 *
 */
public class Message implements IFact {
	private static final long serialVersionUID = 2711869619098337328L;
	private IMessageBoxAddress senderBoxAddress;
	private Integer senderUsersuffix;
	private Role senderRole;
	private MessageSubject subject;
	private Integer step;
	private Object message;

	/**
	 * Constructs a message with all the fields set to null.
	 */
	public Message()  {
		senderBoxAddress = null;
		senderUsersuffix = null;
		senderRole = null;
		subject = null;
		step = null;
		message = null;
	}
	
	/**
	 * Constructs a Request to be sent or to filter an specific message.
	 * 
	 * @param senderBoxAddress The JIAC Message Adress Box of the sender
	 * @param senderUsername The username from the robot that sent the message
	 * @param senderRole The role from the robot that sent the message
	 * @param subj The Message Subject
	 * @param message The object that will be sent (payload)
	 */
	public Message(IMessageBoxAddress senderBoxAddress, Integer senderUsersuffix, Role senderRole, MessageSubject subj,
			Integer step, Object message) {
		this.senderBoxAddress = senderBoxAddress;
		this.senderUsersuffix = senderUsersuffix;
		this.senderRole = senderRole;
		this.subject = subj;
		this.step = step;
		this.message = message;
	}
	
	public IMessageBoxAddress getUser() {
		return senderBoxAddress;
	}

	public void setUser(IMessageBoxAddress senderBoxAddress) {
		this.senderBoxAddress = senderBoxAddress;
	}

	public Integer getSenderUsersuffix() {
		return senderUsersuffix;
	}

	public void setSenderUsername(Integer senderUsersuffix) {
		this.senderUsersuffix = senderUsersuffix;
	}

	public Role getSenderRole() {
		return senderRole;
	}

	public void setSenderRole(Role senderRole) {
		this.senderRole = senderRole;
	}

	public MessageSubject getSubject() {
		return subject;
	}

	public void setSubject(MessageSubject subject) {
		this.subject = subject;
	}

	public Integer getStep() {
		return step;
	}

	public void setStep(Integer step) {
		this.step = step;
	}

	public Object getMessage() {
		return message;
	}

	public void setMessage(Object message) {
		this.message = message;
	}

	@Override
	public String toString() {
		final String ret = String.format(
				"Message [senderBoxAddress=%s, senderUsersuffix=%s, senderRole=%s, subj=%s, step=%s, message=%s]",
				senderBoxAddress, senderUsersuffix, senderRole, subject, step, message);
		return ret;
	}
}
