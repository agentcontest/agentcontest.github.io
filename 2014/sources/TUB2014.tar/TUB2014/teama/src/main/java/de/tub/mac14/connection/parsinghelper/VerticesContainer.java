/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package de.tub.mac14.connection.parsinghelper;

import de.tub.mac14.common.Tuple;
import de.tub.mac14.common.Utils;

import java.io.Serializable;
import java.util.ArrayList;

import org.w3c.dom.Element;

/**
 * This Class may not be good.  should be some kind of a container for all 
 * vertices specified in the <perception>- xml. there just needs to be some kind of 
 * wrapper class for all of them, i think.
 * @author mattu
 */
public class VerticesContainer implements Serializable{

	// <Id, Team>
	// <id, Value>
	public ArrayList<Tuple<Integer, String>> visibleVertices;
    public ArrayList<Tuple<Integer, Integer>> probedVertices;
    
    public VerticesContainer(){
        visibleVertices = new ArrayList<>();
        probedVertices = new ArrayList<>();
    }
    
    public void addVisibleVertices(Element vertices){
        ArrayList<Element> children = Utils.getElementChildrenFromNode(vertices);
		
        for(int i = 0; i< children.size() ; i++){
            String vertexName = children.get(i).getAttribute("name");
            String vertexTeam = children.get(i).getAttribute("team");
			int vId = vertexName.contains("vertex")?Integer.parseInt(vertexName.replace("vertex", "")) : Integer.parseInt(vertexName.substring(1));
            visibleVertices.add(new Tuple<>(vId, vertexTeam));
        }
    }
	
	public void addProbedVertices(Element vertices){
		ArrayList<Element> children = Utils.getElementChildrenFromNode(vertices);
		
		for(Element el : children){
			String name = el.getAttribute("name");
			int value = Integer.parseInt(el.getAttribute("value"));
			int vId = name.contains("vertex")?Integer.parseInt(name.replace("vertex", "")) : Integer.parseInt(name.substring(1));
			
			probedVertices.add(new Tuple<>(vId, value));
			
		}
	}
    
}
