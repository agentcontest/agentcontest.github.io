package de.tub.mac14.strategy;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

import de.tub.mac14.bean.DefaultDecisionBean;
import de.tub.mac14.common.Config;
import de.tub.mac14.common.Tuple;
import de.tub.mac14.enums.RobotAction;
import de.tub.mac14.graphutils.Pathmap;
import de.tub.mac14.ontology.Intention;
import de.tub.mac14.ontology.Robot;
import de.tub.mac14.ontology.Vertex;
import de.tub.mac14.strategy.util.RankedEnemy;

public class SaboteurSimpleStrategy extends Strategy {
	private static final Integer ENEMY_HITLIST_UPGRADE = 15;
	private static final Double ENEMY_HITLIST_DECAY = 0.25;
	private static final Integer ENEMY_HITLIST_PROBABLY_DISABLED = 12;
	private static final CharSequence FAILURE_PARRIED = "failed_parried";
	private static final CharSequence FAILURE_IN_RANGE = "failed_in_range";
	private static final CharSequence FAILURE_RANDOM = "failed_random";
	private static final double RANGE_PROPABILITY = 0.7;
	// private static int MAX_SABOTEURS_TO_INVADE_BASES = 2;
	private final int FIRST_SABOTEUR_SUFFIX = 13;
	private final int LAST_SABOTEUR_SUFFIX = 16;

	protected final int EXTERMINATION_COST = 2;
	private int MAX_GOTO_RANGE = 10;
	// private String nickName = "DARLEK KAHN";

	protected int ENEMY_ON_SAME_LOCATION_RANK = 12;
	protected int ENEMY_REACHABLE_RANK = 2;
	// private int[] ENEMY_ROLE_BONI = { 2, 10, 5, 0, 0 };
	private int[] ENEMY_HEALTH = { 4, 6, 3, 1, 6 };
	private boolean[] ENEMY_CAN_PARRY = { false, true, true, true, false };
	private int MAX_HOTSPOT_DISTANCE = 7;

	protected RankedEnemy lastAim = null;
	private boolean needToMove;
	private static ConcurrentHashMap<Robot, Deque<Double>> hitList = new ConcurrentHashMap<Robot, Deque<Double>>();

	static boolean scoringDebug = false;
	static boolean hitlistDebug = false;
	static boolean decisionDebug = false;

	public SaboteurSimpleStrategy(DefaultDecisionBean bean) {
		super(bean);
	}

	@Override
	public Intention decide() {
		if (me == null || me.position == null) {
			return null;
		}
		validateLastAction();
		if (me.usersuffix == LAST_SABOTEUR_SUFFIX) {
			decreaseHitList();
		}

		// recharge if a new attack would not be possible
		if (me.energy < EXTERMINATION_COST) {
			return new Intention(RobotAction.RECHARGE, null);
		}

		// if on the same location as a fellow saboteur, go somewhere else
		needToMove = false;
		for (int i = FIRST_SABOTEUR_SUFFIX; i <= LAST_SABOTEUR_SUFFIX; i++) {
			if (me.position.equals(world.getOurRobot(i).position)) {
				if (me.usersuffix < world.getOurRobot(i).usersuffix) {
					needToMove = true;
				}
			}
		}
		return decideAttack();
	}

	private Intention decideAttack() {
		// gather a list of all human beings
		ArrayList<Robot> humans = world.getEnemys();
		// have a nice list to see who will be served first
		LinkedList<RankedEnemy> exterminationList = new LinkedList<RankedEnemy>();
		List<Vertex> pathToEnemy = null;
		// iterate all humans, let's see what we can reach
		for (Robot r : humans) {
			if (r.position != null && !r.isDisabled() && !probablyDisabled(r)) {
				if (r.position.equals(me.position) && !needToMove) {
					exterminationList.add(new RankedEnemy(r,
							ENEMY_ON_SAME_LOCATION_RANK));
				} else {
					pathToEnemy = ddb.pathmap.getPath(r.position);
					if (pathToEnemy != null && !pathToEnemy.isEmpty()) {
						if (validPath(pathToEnemy, r.position))
							exterminationList.add(new RankedEnemy(r,
									ENEMY_REACHABLE_RANK, pathToEnemy));
					}
				}
			}
		}
		if (!exterminationList.isEmpty()) {
			Collections.sort(exterminationList);
			Collections.reverse(exterminationList);
			if (scoringDebug) {
				System.out.println("---------- TABLE OF INTERREST");
				for (RankedEnemy aim : exterminationList) {
					System.out.println("--- " + aim.self.username + " - "
							+ aim.getScore() + " - (" + aim.startValue + " - "
							+ aim.distance + " + " + aim.roleBonus
							+ ") * 100 - " + aim.self.usersuffix);
				}
			}
			for (RankedEnemy aim : exterminationList) {
				if (aim.getScore() < 1) {
					// if (scoringDebug || decisionDebug)
					// System.out.println("null, no aim with nice score");
					return null;
				}
				// if (scoringDebug || decisionDebug)
				// System.out.println(">>> aim for " + aim.self.username);

				// EXPLAIN! EXPLAIN!
				if (lastAim == null) {
					lastAim = aim;
					inspectEnemy(aim.self);
				} else if (!aim.equals(lastAim)) {
					inspectEnemy(aim.self);
					dontInspectEnemy(lastAim.self);
				}
				lastAim = aim;
				// if we are on the same spot as the enemy number one or can
				// reach him
				if (enemyReachable(aim)) {
					// EXTERMINATE! EXTERMINATE!
					attacked(aim);
					// if (scoringDebug || decisionDebug)
					// System.out.println(">>> ATTACK");
					return new Intention(RobotAction.ATTACK, aim.self.username);
				} else if (aim.path != null && aim.path.size() > 1) {
					// APPROACH! APPROACH!
					// if (scoringDebug || decisionDebug)
					// System.out.println(">>> APPROACH");
					return checkedGoto(aim.path.get(1));
				}
			}
		}
		// SEARCH FOR HUMANS!
		if (decisionDebug)
			System.out.println("null, end this strategy");
		return null;
	}

	/**
	 * returns whether an enemy is probably disabled by our attacks by now.
	 * 
	 * @param r
	 * @return
	 */
	protected boolean probablyDisabled(Robot r) {
		if (hitList.get(r) == null || hitList.get(r).isEmpty())
			return false;
		return hitList.get(r).peekFirst() > ENEMY_HEALTH[r.role.ordinal()];
	}

	/**
	 * every round the points associated with the robots in this list shall
	 * decay. if the value is zero or less, the entry will be removed
	 */
	protected void decreaseHitList() {
		LinkedList<Robot> removeList = new LinkedList<Robot>();
		for (Entry<Robot, Deque<Double>> entry : hitList.entrySet()) {
			try {
				entry.getValue().push(
						entry.getValue().peek() - ENEMY_HITLIST_DECAY);
			} catch (NoSuchElementException e) {
				removeList.add(entry.getKey());
			}

			// try {
			// entry.getValue().addFirst(
			// entry.getValue().peekFirst() - ENEMY_HITLIST_DECAY
			// + ENEMY_HEALTH[entry.getKey().role.ordinal()]);
			// } catch (NullPointerException e) {
			// entry.getValue().addFirst(
			// entry.getValue().peekFirst() - ENEMY_HITLIST_DECAY);
			// }

			if (entry.getValue().peekFirst() < 0) {
				removeList.add(entry.getKey());
			}
		}
		for (Robot r : removeList) {
			hitList.remove(r);
		}

		if (hitlistDebug) {
			System.out.println(">>>>>> new round -- HITLIST: ");
			for (Entry<Robot, Deque<Double>> e : hitList.entrySet()) {
				System.out.print(">>>> \t" + e.getKey().username + "\t"
						+ e.getValue().peekFirst() + " | ");
				for (Double d : e.getValue())
					System.out.print(d + ", ");
				System.out.print("\n");
			}
		}
	}

	/**
	 * we must check if the last attack was parried. validate if the last action
	 * was an attack and if its result was successful
	 */
	protected void validateLastAction() {
		if (lastAim == null)
			return;
		if (me.lastActionResult.contains(FAILURE_PARRIED)
				|| me.lastActionResult.contains(FAILURE_IN_RANGE)
				|| me.lastActionResult.contains(FAILURE_RANDOM)) {
			// reverse last hitlist entry
			Deque<Double> val = hitList.get(lastAim.self);
			if (val == null || val.isEmpty() || val.peekFirst() <= 0.01) {
				hitList.remove(lastAim.self);
				return;
			}
			val.removeFirst();
		}
	}

	/**
	 * returns whether this path is good to go
	 * 
	 * @param pathToEnemy
	 * @param position
	 * @return
	 */
	protected boolean validPath(List<Vertex> pathToEnemy, Vertex enemyPosition) {
		boolean inRange = pathToEnemy.size() < MAX_GOTO_RANGE;
		Vertex hotSpot;
		if (StrategyAssigner.hotspotAssignments.get(me) != null) {
			if ((hotSpot = StrategyAssigner.hotspotAssignments.get(me).center) != null) {
				Pathmap pmap = new Pathmap(hotSpot);
				if (pmap.getDistanceTo(enemyPosition) > MAX_HOTSPOT_DISTANCE) {
					return false;
				}
			}
		}
		return inRange;
	}

	/**
	 * have this entity explained. send over to inspectors
	 * 
	 * @param enemy
	 */
	protected void inspectEnemy(Robot enemy) {
		StrategyAssigner.needToBeInspectedEntities.add(enemy);

	}

	/**
	 * inspectors do not have to inspect this entity any more
	 * 
	 * @param enemy
	 */
	protected void dontInspectEnemy(Robot enemy) {
		for (Entry<Robot, Tuple<Robot, Integer>> entry : StrategyAssigner.whoInspectsWho
				.entrySet()) {
			if (entry.getValue().getFirst().equals(enemy)) {
				StrategyAssigner.whoInspectsWho.remove(entry.getKey());
			}
		}
		StrategyAssigner.needToBeInspectedEntities.remove(enemy);
	}

	/**
	 * Decide if an Enemy is reachable by a ranged attack. take in mind that
	 * enemies may parry
	 * 
	 * @param aim
	 * @return
	 */
	protected boolean enemyReachable(RankedEnemy aim) {
		if (aim == null)
			return false;
		if (me != null && me.position != null && aim.self != null
				&& aim.self.position != null
				&& me.position.equals(aim.self.position))
			return true;
//		if (ENEMY_CAN_PARRY[aim.self.role.ordinal()])
//			return false;
		if (aim.path != null)
			if (aim.path.size() <= ddb.getWorld().getMe().visRange
					&& aim.path.size() + EXTERMINATION_COST <= me.energy) {
				if (Math.random() < RANGE_PROPABILITY) {
					return true;
				} else {
					return false;
				}
			}

		return false;
	}

	/**
	 * if an enemy was attacked, it will be added to the HitList. if the enemy
	 * is already listed, its associated value will be increased
	 * 
	 * @param aim
	 */
	protected void attacked(RankedEnemy aim) {
		Deque<Double> val = hitList.get(aim.self);
		if (val == null) {
			val = new ArrayDeque<Double>();
			val.addFirst(0.0);
			hitList.put(aim.self, val);
		}
		// val.addFirst(val.getFirst() + ENEMY_HITLIST_UPGRADE
		// + ENEMY_HEALTH[aim.role.ordinal()]);
		int distance = 0;
		if (aim.path != null)
			distance = aim.path.size() - 1;
		int max = 0;
		try {
			max = me.strength;
		} catch (Exception e) {
			max = 4;
		}
		int upgrade = Math.max(max - 2 * distance, 1);
		val.push(val.peek() + upgrade);
		inspectEnemy(aim.self);
	}

}
