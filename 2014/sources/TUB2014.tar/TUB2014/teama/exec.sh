#/bin/sh
git pull
mvn install -Dmaven.test.skip=true
mvn exec:java -Dexec.mainClass="de.tub.mac14.BTeamStarter"

