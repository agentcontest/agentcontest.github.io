mvn exec:java -Dexec.mainClass="de.tub.mac14.BTeamStarter" -Dexec.classpathScope=runtime
