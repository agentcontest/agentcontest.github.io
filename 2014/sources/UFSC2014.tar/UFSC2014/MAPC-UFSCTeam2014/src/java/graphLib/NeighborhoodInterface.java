package graphLib;

import java.util.List;

public interface NeighborhoodInterface {
    public List<Integer> execute(Graph g, int s, int paramInt);
}
