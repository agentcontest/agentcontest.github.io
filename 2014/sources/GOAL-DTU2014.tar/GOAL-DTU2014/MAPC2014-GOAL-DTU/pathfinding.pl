%% Callable pathfinding predicates using the A* algorithm 

% Heuristics
heuZero(_,_,0).

% Edge weight functions
cleanWeight(unknown,6):-!.
cleanWeight(Weight,Weight).

adjacentNode(CurNode, (Weight, AdjNode)):- neighbor(CurNode,NWeight,AdjNode),cleanWeight(NWeight,Weight).
adjacentNodeWeightOne(CurNode, (1, AdjNode)):- neighbor(CurNode,_,AdjNode).

% Goal functions
goalReached(Pos, GPosList) :- memberchk(Pos, GPosList).
unknownNodeReached(Pos, _):- vertex(Pos,_), edge(Pos,Pos2,_), \+ vertex(Pos2, _),!.
unprobedNodeReached(Pos, _):- vertexValue(Pos,unknown).
unprobedNodeReachedExChecks(Pos, _):- vertexValue(Pos,unknown),not(needExploring(unknown)), needExploring(List), member(Vertex,List), needProbe(Vertex).
unsurveyedNodeReached(Pos,_):- needSurvey(Pos).
repairerOnNodeReached(Pos,_):- teamStatus(NameAgent,Pos,_), role(NameAgent, 'Repairer'),!.
enemyOnNodeReached(Pos,_):- enabledEnemy(_, Pos), !.

% Dijkstra from S to T
% path(Vertex0, Vertex, Path, Dist) is true if Path is the shortest path from Vertex0 to Vertex, and the length of the path is Dist. The graph is defined by e/3. e.g. path(penzance, london, Path, Dist)
path(Start, Target, Path, Dist) :-
	aStarSearch(Start, [Target], 1, heuZero, adjacentNode,goalReached, [Target], [Path], [Dist]), Path = [_|_].

pathFewest(Start, Target, Path, Dist) :-
	aStarSearch(Start, [Target], 1, heuZero, adjacentNodeWeightOne, goalReached, [Target], [Path], [Dist]), !, Path = [_|_].

% Dijkstra with multiple goal nodes
pathMultiple(Start, Targets, Max, Ends, Paths, Dists) :-
	aStarSearch(Start, Targets, Max, heuZero, adjacentNode, goalReached, Ends, Paths, Dists), !.

% Dijkstra for closest unknown vertex
pathClosestUnknownVertex(Start, UnknownVertex, Path, Dist) :-
	aStarSearch(Start, [], 1, heuZero, adjacentNode, unknownNodeReached, [UnknownVertex], [Path], [Dist]), !, Path = [_|_].

% Dijkstra for closest non-probed vertex
pathClosestNonProbed(Start, NonProbedVertex, Path, Dist) :-
	aStarSearch(Start, [], 1, heuZero, adjacentNode, unprobedNodeReached, [NonProbedVertex], [Path], [Dist]), !, Path = [_|_].

% Dijkstra for closest non-probed vertices
pathClosestNonProbedMultiple(Start, MaxGoals, Found, Paths, Dists) :-
	aStarSearch(Start, [], MaxGoals, heuZero, adjacentNode, unprobedNodeReached, Found, Paths, Dists), !.

% Dijkstra for closest non-probed vertex, with some additional checks
pathClosestNonProbedWithExtraChecks(Start, NonProbedVertex, Path, Dist) :-
	aStarSearch(Start, [], 1, heuZero, adjacentNode, unprobedNodeReachedExChecks, [NonProbedVertex], [Path], [Dist]), !, Path = [_|_].

% Dijkstra for closest non-surveyed vertex
pathClosestNonSurveyed(Start, NonSurveyedVertex, Path, Dist) :-
	aStarSearch(Start, [], 1, heuZero, adjacentNode, unsurveyedNodeReached, [NonSurveyedVertex], [Path], [Dist]), !, Path = [_|_].

% Dijkstra for closest Repairer
pathClosestRepairer(Start, LocationRepairer, NameAgent, Path, Dist) :-
	aStarSearch(Start, [], 1, heuZero, adjacentNode, repairerOnNodeReached, [LocationRepairer], [Path], [Dist]), !, Path = [_|_],
	teamStatus(NameAgent,LocationRepairer,_), role(NameAgent,'Repairer').

% Dijkstra for closest non-disabled enemy
pathClosestEnemy(Start, LocationEnemy, NameEnemy, Path, Dist) :-
	aStarSearch(Start, [], 1, heuZero, adjacentNode, enemyOnNodeReached, [LocationEnemy], [Path], [Dist]), !, Path = [_|_],
	enabledEnemy(NameEnemy,LocationEnemy).

% Dijkstra for closest enabled enemies
pathClosestEnabledEnemies(Start, MaxGoals, FoundTargets) :-
	findall((ID,V), enabledEnemy(ID,V), Tmp1),
	zip(_, L, Tmp1),
	aStarSearch(Start, L, MaxGoals, heuZero, adjacentNode, goalReached, FoundGoals, Paths, Dists), !,
	zip3(FoundGoals, Dists, Paths, Tmp2),
	findall((ID,V,D,P), (member((ID,V),Tmp1), memberchk(V,FoundGoals), memberchk((V,D,P),Tmp2)), FoundTargets).

% Dijkstra for closest dangerous enemies
pathClosestDangerousEnemies(Start, MaxGoals, FoundTargets) :-
	findall((ID,V), (enabledEnemy(ID,V), dangerousEnemy(ID)), Tmp1),
	zip(_, L, Tmp1),
	aStarSearch(Start, L, MaxGoals, heuZero, adjacentNode, goalReached, FoundGoals, Paths, Dists), !,
	zip3(FoundGoals, Dists, Paths, Tmp2),
	findall((ID,V,D,P), (member((ID,V),Tmp1), memberchk(V,FoundGoals), memberchk((V,D,P),Tmp2)), FoundTargets).

% Dijkstra for closest enemies of specific roles
pathClosestRoleEnemies(Start, MaxGoals, Roles, FoundTargets) :-
	findall((ID,V), (enabledEnemy(ID,V), inspectedEnemy(ID,R), memberchk(R,Roles)), Tmp1),
	zip(_, L, Tmp1),
	aStarSearch(Start, L, MaxGoals, heuZero, adjacentNode, goalReached, FoundGoals, Paths, Dists), !,
	zip3(FoundGoals, Dists, Paths, Tmp2),
	findall((ID,V,D,P), (member((ID,V),Tmp1), memberchk(V,FoundGoals), memberchk((V,D,P),Tmp2)), FoundTargets).

% Dijkstra for closest disabled allies of specific roles
pathClosestDisabled(Start, MaxGoals, Ignored, Roles, FoundTargets) :-
	findall((ID,V), (teamStatus(ID,V,0), role(ID,R), memberchk(R,Roles), \+ memberchk(ID,Ignored)), Tmp1),
	zip(_, L, Tmp1),
	aStarSearch(Start, L, MaxGoals, heuZero, adjacentNode, goalReached, FoundGoals, Paths, Dists), !,
	zip3(FoundGoals, Dists, Paths, Tmp2),
	findall((ID,V,D,P), (member((ID,V),Tmp1), memberchk(V,FoundGoals), memberchk((V,D,P),Tmp2)), FoundTargets).

% Dijkstra for closest threatened allies of specific roles
pathClosestThreatened(Start, MaxGoals, Ignored, Roles, FoundTargets) :-
	findall((ID,V), (teamStatus(ID,V,Health), Health > 0, role(ID,R), memberchk(R,Roles),
			 \+ memberchk(ID,Ignored), enabledEnemy(E,V), dangerousEnemy(E)),
		Tmp1),
	zip(_, L, Tmp1),
	aStarSearch(Start, L, MaxGoals, heuZero, adjacentNode, goalReached, FoundGoals, Paths, Dists), !,
	zip3(FoundGoals, Dists, Paths, Tmp2),
	findall((ID,V,D,P), (member((ID,V),Tmp1), memberchk(V,FoundGoals), memberchk((V,D,P),Tmp2)), FoundTargets).
