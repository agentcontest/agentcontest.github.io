extractNodes([], []).
extractNodes([node(V,_,_)|Tail], [V|Rest]) :-
	extractNodes(Tail, Rest).

extractCosts([], []).
extractCosts([node(_,_,Cost)|Tail], [Cost|Rest]) :-
	extractCosts(Tail, Rest).

removePosition(_, [], []).
removePosition(N, [N|Tail], Tail) :- !.
removePosition(N1, [N2|Ns], [N2|Rest]) :-
	N1 \= N2,
	removePosition(N1,Ns,Rest).

insertSorted(X, [], [X]).
insertSorted(X, [Y|Rest], [X,Y|Rest]) :-
	X @< Y, !.
insertSorted(X, [Y|Rest0], [Y|Rest]) :-
	insertSorted(X, Rest0, Rest).

updateFront(N,EF,NewEF,Heu) :-
	N=node(Pos,_,SCost),
	\+ member((_,node(Pos,_,_)),EF),
	HeuCost is SCost + Heu,
	insertSorted((HeuCost,N),EF,NewEF).
updateFront(N,EF,NewEF,Heu) :-
	N=node(Pos,_,SCost),
	append(StEF,[OtherNode|EndEF],EF),
	OtherNode = (_,node(Pos,_,OCost)),
	SCost < OCost,
	HeuCost is SCost + Heu,
	append(StEF,EndEF,TempEF),
	insertSorted((HeuCost,N),TempEF,NewEF).

updateExplored(N,EF,EF) :-
	N=node(Pos,_,_),
	\+ member(node(Pos,_,_),EF).
updateExplored(N,EF,NewEF) :-
	N=node(Pos,_,SCost),
	append(StEF,[OtherNode|EndEF],EF),
	OtherNode = (_,node(Pos,_,OCost)),
	SCost < OCost,
	append(StEF,EndEF,NewEF).

checkSuc(Successor, OldFrontier, NewFrontier, OldExplored, NewExplored,Goals,HeuFunc) :-
	Successor = node(SPos,_,_),
	CalcHeu =..[HeuFunc,SPos,Goals,Heu],
	call(CalcHeu),
	updateExplored(Successor,OldExplored,NewExplored),
	updateFront(Successor,OldFrontier,NewFrontier,Heu).

asLoopSuc([],F,F,E,E,_,_).
asLoopSuc([Suc|Successors],OldFrontier, FinalFrontier, OldExplored, FinalExplored,Goals,HeuFunc) :-
	(	checkSuc(Suc,OldFrontier, NewFrontier, OldExplored, NewExplored,Goals,HeuFunc), !
	;	(OldFrontier=NewFrontier,OldExplored=NewExplored)
	),
	asLoopSuc(Successors,NewFrontier,FinalFrontier, NewExplored, FinalExplored,Goals,HeuFunc).


aStarMainLoop(_,_,_,MaxGoals,_,_,_,_,_,[]) :- MaxGoals =< 0, !.
aStarMainLoop(N,Goals,PrevGoals,MaxGoals,Frontier,Explored,HeuFunc,AdjFunc,GoalFunc,[N|NRest]) :-
	ReducedMaxGoals is MaxGoals - 1,
	N=node(CPos,_,_), CheckGoal =.. [GoalFunc,CPos,Goals],
	\+ member(CPos,PrevGoals), call(CheckGoal), !,
	removePosition(CPos,Goals,ReducedGoals),
	aStarMainLoop(N,ReducedGoals,[CPos|PrevGoals],ReducedMaxGoals,Frontier,Explored,HeuFunc,AdjFunc,GoalFunc,NRest), !.
aStarMainLoop(CurrentNode,Goals,PrevGoals,MaxGoals,Frontier,Explored,HeuFunc,AdjNodeFunc,GoalFunc,EndNodes) :-
	CurrentNode = node(CurrentPos, _, SCost),
	findall( AdjN,
		 ( FindAdjNode =.. [AdjNodeFunc, CurrentPos, (AdjCost,AdjPos)],
		   call(FindAdjNode),
		   AdjFullCost is AdjCost + SCost,
		   AdjN = node(AdjPos, CurrentNode, AdjFullCost)
		 ), L),
	asLoopSuc(L,Frontier,NewFrontier,Explored,TempExplored,Goals,HeuFunc),
	(NewFrontier == [] ->
		(is_list(EndNodes), ! ; EndNodes = [])
	;	NewFrontier = [(_,NewCurrent)|RestFront],
		NewExplored = [CurrentNode|TempExplored], !,
		aStarMainLoop(NewCurrent,Goals,PrevGoals,MaxGoals,RestFront,NewExplored,HeuFunc,AdjNodeFunc,GoalFunc,EndNodes)
	).
aStarMainLoop(_,_,_,_,[],_,_,_,_,[]) :- !.


aStarGenRoutes([],[]).
aStarGenRoutes([Node|RestNodes], [Route|RestRoutes]) :-
	aStarGenRoute(Node,[],Route),
	aStarGenRoutes(RestNodes,RestRoutes).

aStarGenRoute(nil,R,R).
aStarGenRoute(node(Pos,Parent,_),Route,FinalRoute) :-
	aStarGenRoute(Parent,[Pos|Route],FinalRoute).

aStarSearch(StartPos,Goals,MaxGoals,HeuFunc,AdjNodeFunc,GoalFunc,EndPosList,Routes,Costs) :-
	aStarMainLoop(node(StartPos,nil,0),Goals,[],MaxGoals,[],[],HeuFunc,AdjNodeFunc,GoalFunc,EndNodes), !,
	extractCosts(EndNodes,Costs),
	extractNodes(EndNodes,EndPosList),
	aStarGenRoutes(EndNodes,Routes), !.
