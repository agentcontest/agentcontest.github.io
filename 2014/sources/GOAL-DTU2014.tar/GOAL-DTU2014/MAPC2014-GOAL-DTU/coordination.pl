%% Action coordination
% The ranks (Rs) ensure that the best ranked target is chosen when their costs tie 
actionCoordination(Target) :-
	findall((D,R,T,A), (possibleTargets(A,Ts,Rs,Ds), zip3(Ds,Rs,Ts,Zs), member((D,R,T),Zs)), L),
	sort(L,S), me(Me), chooseBest(Me,S,[],Target).

chooseBest(A,[(_,_,T,B)|R],Chosen,S) :- A \= B, chooseBest(A,R,[T|Chosen],S), !. 
chooseBest(A,[(_,_,T,A)|R],Chosen,S) :- memberchk(T,Chosen), chooseBest(A,R,Chosen,S).
chooseBest(A,[(_,_,T,A)|_],Chosen,T).


%% Synchronization checks
hasSynchronizedMails :-
	aggregate_all(count, (me(M), agent(A), not(M = A)), NA),
	aggregate_all(count, mailsSynchronized(A), NS), NS >= NA. 

hasCoordinated :- role('Explorer'), !, aggregate_all(count, possibleTargets(_,_,_,_), 6).
hasCoordinated :- role('Saboteur'), !, aggregate_all(count, possibleTargets(_,_,_,_), 4).
hasCoordinated.
