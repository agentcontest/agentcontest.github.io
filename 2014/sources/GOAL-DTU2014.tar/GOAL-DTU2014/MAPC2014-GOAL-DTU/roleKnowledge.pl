%% Explorer specific knowledge

needProbe(Vertex) :- vertex(Vertex,unknown).
needProbe(Vertex) :- not(vertex(Vertex,_)).

% True when we should decide swarm positions
timeToDecideSwarm :- decidedSwarmAt(OldS), step(NewS), D is NewS - OldS, D >= 60, !.
timeToDecideSwarm :- swarmPosition(unknown), !, optimum(X), calcZoneValue(X,V), V >= 70.


%% Saboteur specific knowledge

% Goal for committing to disabling an enemy agent
% The goal also succeeds when we are disabled to make sure that other Saboteurs can hit this target when we cannot
hunt(ID) :- enemyStatus(ID,_,normal), disabled, !.
hunt(ID) :- enemyStatus(ID,_,disabled), !.

% To determine which enemies are on the current position
enemyHere(ID) :- currentPos(Vertex), visibleEntity(ID,Vertex,Team,_), enemyTeam(Team).

% To determine which enemies are close to the current position
enemyNear(ID,Pos) :- currentPos(Pos), enemyHere(ID).
enemyNear(ID,Pos) :- neighbor(Pos), visibleEntity(ID,Pos,Team,_), enemyTeam(Team).

% To determine when a non-disabled enemy is at your position
enabledEnemyHere(Id) :- currentPos(Vertex), visibleEntity(Id,Vertex,Team,normal), enemyTeam(Team).

% When a non-disabled enemy is at or next to your position
enabledEnemyNear(ID,Pos) :- currentPos(Pos), enabledEnemyHere(ID).
enabledEnemyNear(Id,Pos) :- neighbor(Pos), visibleEntity(Id,Pos,Team,normal), enemyTeam(Team).

% A list of all locations near enemies
enabledEnemiesNear(List) :- findall(Vertex,enabledEnemyNear(ID,Vertex),L), sort(L,List), List = [_|_].

% Short predicate for finding enemies worth attacking
enabledEnemy(ID,Vertex) :- enemyStatus(ID,Vertex,normal).

% Used for buying upgrades. Only buy if the second highest enemy Saboteur has a strength or health advantage and if enough time has elapsed.
timeToBuy :- step(Step), Step >= 140.
enemySaboteurSecondMaxStrength(Strength) :- findall(Str, inspectedEntity(_, _,'Saboteur', _, _, _, _, _, Str, _), L), msort(L, S), length(S, N), N > 1, sort([N,3],A), nth1(1,A,Index), nth1(Index, S, Strength), !.
enemySaboteurSecondMaxHealth(Health) :- findall(Hp, inspectedEntity(_, _,'Saboteur', _, _, _, _, Hp, _, _), L),  msort(L, S), length(S, N), N > 1, sort([N,3],A), nth1(1,A,Index), nth1(Index, S, Health), !.


%% Repairer specific knowledge

% Predicate that returns disabled allies near or on the current position
disabledAllyNear(ID,Here) :- currentPos(Here), team(Team), me(Me), visibleEntity(ID,Here,Team,disabled), ID \= Me, !.
disabledAllyNear(ID,Vertex) :- team(Team), neighbor(Vertex), visibleEntity(ID,Vertex,Team,disabled), !.
disabledAllyNear(ID,Vertex) :- currentPos(Here), team(Team), visibleEdge(Here,Vertex), visibleEntity(ID,Vertex,Team,disabled), !.

% The repairing(ID) goal. 
% When the injured agent is no longer disabled, then the goal has been achieved.
% A repair goal should never be adopted unless there exists a path between the repairer and the injured agent. 
repairing(Agent) :- agent(Agent), not(teamStatus(Agent,_,0)). 


%% Inspector specific knowledge

% Predicate that returns uninspected agents close to the inspector
% This also makes sure enemy Saboteurs are suitable for inspection again when last inspection is older than 50 steps
uninspectedNear(Agent) :- visibleEntity(Agent,Vertex,Team,_), enemyTeam(Team), (currentPos(Vertex) ; neighbor(Vertex)), 
	(not(inspectedEntity(Agent,_,_,_,_,_,_,_,_,_)); ( inspectedEnemy(Agent, 'Saboteur'), lastInspect(Agent,LI), step(S), LI2 is LI + 50, LI2 < S)).
uninspectedEntity(Agent) :- not(inspectedEntity(Agent,_,_,_,_,_,_,_,_,_)).
