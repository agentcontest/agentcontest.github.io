﻿Multi-Agent Programming Contest 2014 - GOAL-DTU

Participants from DTU Compute:

- Jørgen Villadsen - Supervisor - Associate professor

- Andreas Viktor Hess

- Øyvind Grønland Woller

Algorithms, Logic and Graphs Section
Department of Applied Mathematics and Computer Science
Technical University of Denmark

http://www2.compute.dtu.dk/~jovi/MAS/

----------

Uses GOAL Eclipse plugin

Uses EISMASSim 2.2 with changes to EnvironmentInterface.java and Mars2013Entity.java in massim/eismassim as in diff files