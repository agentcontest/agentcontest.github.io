% Energy/money checks
energyGE(Nr) :- Nr = unknown, energy(E), E >= 9.
energyGE(Nr) :- Nr \= unknown, energy(E), E >= Nr.
moneyGE(Nr) :- money(M), M >= Nr.
maxEnergy(E) :- disabled, maxEnergyDisabled(E), !.
maxEnergy(E) :- not(disabled), maxEnergyWorking(E).
recharge(Nr) :- not(disabled), maxEnergy(E), Nr is round(0.5*E).
recharge(Nr) :- disabled, maxEnergy(E), Nr is round(0.3*E).

% Energy cost of ranged actions
energyRangedGE(Base,V) :- currentPos(V), energyGE(Base), !.
energyRangedGE(Base,V) :- neighbor(V), N is Base+1, energyGE(N), !.
energyRangedGE(Base,V) :- not(currentPos(V)), not(neighbor(V)), currentPos(S), pathFewest(S,V,L,_), !, length(L,Dist), N is Base+Dist-1, energyGE(N).

% Role of the agent
role(Role) :- me(Id), role(Id, Role).

% Team determination
enemyTeam(T) :- inspectedEntity(_, T, _, _, _, _, _, _, _, _).
enemyTeam(T) :- not(team(T)), T \= none.

% Defines when an agent is disabled
disabled :- health(0).

% Predicates for determining when a node or its neighbor needs surveying
needSurvey(V) :- vertex(V,_), (edge(V,_,unknown) ; not(edge(V,_,_))), !.
needSurvey(V) :- not(vertex(V,_)).
neighborNeedSurvey(V) :- currentPos(Here), neighborNeedSurvey(Here,V).
neighborNeedSurvey(V,W) :- vertex(V,_), edge(V,W,_), needSurvey(W).

% True when an optimum is found and it is time to swarm
optimum :- optimum(_), !, timeToSwarm.

% Random predicates. random/3 with float inputs should work, but it doesn't!
randomFloat(R) :-  R is (random(65391)/65391). % There seems to be a bug when using the built-in random/3 predicate
randomInt(N,R) :- randomFloat(X), R is floor(X*N).
randomElement(List, Elem) :- length(List,N), N > 0, randomInt(N,R), nth0(R,List,Elem).

% Defines whether an enemy is to be considered dangerous for sure
dangerousEnemy(ID) :- inspectedEnemy(ID, 'Saboteur'), !.
dangerousEnemy(ID) :- not(inspectedEnemy(ID, _)), !, findall(ID2, inspectedEnemy(ID2, 'Saboteur'), List), length(List,N), N < 4.

enabledDangerousEnemyHere(ID) :- enabledEnemyHere(ID), dangerousEnemy(ID).

% Enemy is passive when disabled, can also be used on allies.
passiveEnemy(Id) :- visibleEntity(Id,_,_,disabled), !.
passiveEnemy(Id) :- inspectedEnemy(Id,Role), !, Role \= 'Saboteur'.
passiveEnemy(Id) :- not(inspectedEnemy(Id,_)), !, findall(Id2, inspectedEnemy(Id2, 'Saboteur'), List), length(List, N), N == 4.

% Enabled ally Saboteurs at current vertex
enabledAllySaboteurHere :- currentPos(V), me(Me), teamStatus(ID,V,HP), HP > 0, role(ID,'Saboteur'), ID \= Me, !.

% Short predicate to extract the most useful information from an inspected enemy
inspectedEnemy(Id,Role) :- inspectedEntity(Id, _, Role, _, _, _, _, _, _, _).

% Vertex value checks (checks for unknown before evaluating arithmetic operation)
vertexValueGT(A, B) :- A \= unknown, B \= unknown, A > B.
vertexValueGE(A, B) :- A \= unknown, B \= unknown, A >= B.

% Sum of the values of all vertices in a list
vertexListSum([], 0).
vertexListSum([H|T], Sum) :- vertexValue(H,V), V == unknown, vertexListSum(T,S), Sum is S+1.
vertexListSum([H|T], Sum) :- vertexValue(H,V), V \== unknown, vertexListSum(T,S), Sum is S+V.

% True when it is time to swarm. It differs from Explorers and the others 
timeToSwarm :- not(role('Explorer')), swarmPosition(Opt), Opt \= unknown, !.
timeToSwarm :- role('Explorer'), optimum(_), step(Cur), Cur > 150.

% Get your swarm position
hasSwarmPos(X) :- swarmPosition(X), X \= unknown.

% Optimums are vertices that are maxima such that no other vertex with a higher value exists, which is true of the vertices with value 10.
% No local maxima n with value < 10 exists (with very high probability) because of the map generation algorithm.
optimum(X) :- vertex(X,10).

% The effect (in percent of non-ranged effect) and effective range of ranged actions
expectedEffectiveRange(survey,ER) :- visibilityRange(VR), ER is (VR-1)/3+1.
expectedEffectiveRange(Action,Dist,ER) :- member(Action,[probe,inspect,attack,repair]), visibilityRange(VR), ER is VR/4. % Probably too old
effectCalc(MV,VR,0,MV).
effectCalc(MV,VR,Dist,Effect) :- Dist > 0, Effect is max(VR-2*Dist,1).
rangedAttackEffect(Dist,0.0) :- strength(0).
rangedAttackEffect(Dist,Percent) :- strength(MV), MV > 0, visibilityRange(VR), effectCalc(MV,VR,Dist,Ef), Percent is Ef/MV.
rangedRepairEffect(Dist,Target,Percent) :- role(Target,R), member(R,['Inspector','Repairer']), visibilityRange(VR), effectCalc(6,VR,Dist,Effect), Percent is Effect/6.
rangedRepairEffect(Dist,Target,Percent) :- role(Target,R), member(R,['Saboteur','Explorer']), visibilityRange(VR), effectCalc(4,VR,Dist,Effect), Percent is Effect/4.
rangedRepairEffect(Dist,Target,Percent) :- role(Target,'Sentinel'), visibilityRange(VR), effectCalc(1,VR,Dist,Effect), Percent is Effect/1.

% Zip/unzip functions
zip([],[],[]) :- !.
zip([],_,[]) :- !.
zip(_,[],[]) :- !.
zip([A|AT],[B|BT],[(A,B)|T]) :- zip(AT,BT,T).

zip3([],[],[],[]) :- !.
zip3([],_,_,[]) :- !.
zip3(_,[],_,[]) :- !.
zip3(_,_,[],[]) :- !.
zip3([A|AT],[B|BT],[C|CT],[(A,B,C)|T]) :- zip3(AT,BT,CT,T).

% List creation functions
makeList(N,M,L) :- length(L,N), fillList(L,M).

fillList([],_).
fillList([N|T],N) :- fillList(T,N).

