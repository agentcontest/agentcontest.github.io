%% Algorithm(s) for calculating valuable zones/areas to control

% Main predicate for zone control algorithm
calcSwarms(Chosen, Value) :-
	decideOptimums(Opts), findall((Val,Swarm), (member(Opt,Opts), calcAreaControl(Opt,Swarm,Val)), L),
	sort(L,S), length(S,N), nth1(N,S,(Value,Chosen)), !.


%% Python-DTU's algorithm for calculating swarm positions, reimplementation in GOAL

% Find all optimums that are not already in use
allOptimums(Opts) :- allOptimums(Opts,[]).
allOptimums(Opts,Ignore) :- 
	findall(V, (optimum(V), not(member(V,Ignore)), not((neighbor(V,N),member(N,Ignore)))), Opts), length(Opts,N), N > 0, !.

% Finds the optimum nodes that can contain a swarm with the largest
% Potential values as defined by calcZoneValue
bestOptimums(List,Opts) :- 
	findall((ValSum,Swarm), (member(Swarm,List), calcZoneValue(Swarm,ValSum)), L), sort(L,S),
	length(S,N), nth1(N,S,(MaxVal,_)), Limit is round(0.65*MaxVal), bestOptimumsAux(S,Limit,L2), sort(L2,Opts).

bestOptimumsAux([],_,[]).
bestOptimumsAux([(Val,Opt)|T],Limit,[Opt|Rest]) :- Val >= Limit, bestOptimumsAux(T,Limit,Rest).
bestOptimumsAux([(Val,_)|T],Limit,Rest) :- Val < Limit, bestOptimumsAux(T,Limit,Rest).

% Choose the best optimums
decideOptimums(Opts) :- allOptimums(L), !, bestOptimums(L, Opts), !.

% Calculates the sum of the values for all the neighbors, and their neighbors, and the vertex O, around the vertex O
calcZone(O,S) :- findall(N, (neighbor(O,_,N)), L1), findall(N, (member(M,L1), neighbor(M,_,N)), L2), union(L1,L2,L3), sort(L3,S).
calcZoneValue(O,V) :- calcZone(O,L), vertexListSum(L,V).

largestZone([],0,_).
largestZone([H|T],Val,V) :- calcZoneValue(H,X), largestZone(T,XT,VT), (X > XT -> (V = H, Val = X); (V = VT, Val = XT)).

% calcAreaControl returns pairs of agents and vertices which determine where the agents shall stand when swarming
% Chosen = agent-vertex pairs
calcAreaControl(Opt,Chosen,Value) :-
	allVertices(Tmp), delete(Tmp,Opt,Vs),
	swarmAgents([A|AT]), cacAux(Vs,AT,[Opt],Rest), Chosen = [(A,Opt)|Rest], 
	swarmValue(Chosen, Value), !.

cacAux(_,[],_,[]).
cacAux(Vs,[A|T],Chosen,[(A,Best)|Rest]) :-
	calcOwned(Chosen, Owned), bestPosition(Vs,Chosen,Owned,Best), cacAux(Vs,T,[Best|Chosen],Rest).

allVertices(Vs) :- findall(V, (vertex(V,Val), Val \= unknown, Val \= 1), L), sort(L,Vs), !.

swarmAgents(As) :- timeToSwarm, swarmAgents(As,['Saboteur','Repairer'],[]), !.
swarmAgents(As) :- swarmAgents(As,['Saboteur','Repairer','Explorer'],[]), !.
swarmAgents(As,Ignored,LowPriority) :- 
	findall(A, (agent(A), role(A,R), not(memberchk(R,Ignored)), not(memberchk(R,LowPriority))), L1), sort(L1,Tmp1), !,
	findall(A, (agent(A), role(A,R), memberchk(R,LowPriority)), L2), sort(L2,Tmp2), !, append(Tmp1,Tmp2,As).

swarmValue(Chosen,Val) :- findall(V, member((_,V), Chosen), L), calcOwned(L,Owned), swarmValueAux(Owned,Val).

swarmValueAux([],0).
swarmValueAux([V|T],Val) :-
	swarmValueAux(T,Part), vertexValue(V,Tmp), (Tmp == unknown -> VVal = 1 ; VVal = Tmp), !, Val is Part + VVal.

bestPosition([],_,_,_) :- fail, !.
bestPosition(Vs,Chosen,Owned,Best) :-
	subtract(Vs,Chosen,NewVs), bpAux(NewVs,Chosen,Owned,_,Best), vertex(Best,_).

bpAux([],_,_,0,_).
bpAux([V1|R],Chosen,Owned,MaxVal,Best) :- 
	bpZoneVal(V1, Chosen, Owned, Val1),  bpAux(R,Chosen,Owned,Val2,V2), 
	(Val1 > Val2 -> (Best = V1, MaxVal = Val1) ; (Best = V2, MaxVal = Val2)).

bpZoneVal(V,Chosen,Owned,Val) :-
	vertex(V,VVal), knownNeighbors(V,Ns), subtract(Ns,Owned, Ws), 
	bpZoneValAux(Ws,Chosen,ValPart), Val is ValPart + VVal.

bpZoneValAux([],_,0).
bpZoneValAux([W|R], Chosen, ValSum) :-
	knownNeighbors(W,Tmp), intersection(Tmp,Chosen,Zs), vertex(W,Tmp2), (Tmp2 == unknown -> WVal = 1 ; WVal = Tmp2),
	bpZoneValAuxAux(Zs,WVal,ValPart1), bpZoneValAux(R,Chosen,ValPart2), ValSum is ValPart1 + ValPart2.

bpZoneValAuxAux([],_,0).
bpZoneValAuxAux([_|R],WVal,ValSum) :- bpZoneValAuxAux(R,WVal,ValPart), ValSum is WVal + ValPart.

calcOwned([],[]).
calcOwned(Chosen,Owned) :- Chosen = [_|T], coAux(Chosen,T,O), union(Chosen,O,Owned).

coAux([H],[],[H]).
coAux([H|T],T,Owned) :- T = [N|R], neighborIntersect(H,T,O), coAux([N|R],R,O2), union(O,O2,Owned).

neighborIntersect(_,[],[]).
neighborIntersect(V,[H|T],NI) :- knownNeighbors(V,NV), knownNeighbors(H,NH), intersection(NV,NH,X), neighborIntersect(V,T,Y), union(X,Y,NI).

validSwarms(Swarms) :- not(memberchk((_,unknown),Swarms)), !.
