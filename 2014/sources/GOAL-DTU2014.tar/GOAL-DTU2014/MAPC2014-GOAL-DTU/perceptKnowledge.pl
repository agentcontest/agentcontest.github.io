% Some information about the agent itself from the percepts
money(M) :- storedPercept(money(M)).
energy(E) :- storedPercept(energy(E)).
maxEnergyWorking(E) :- storedPercept(maxEnergy(E)).
maxEnergyDisabled(E) :- storedPercept(maxEnergyDisabled(E)).
strength(S) :- storedPercept(strength(S)).
maxHealth(H) :- storedPercept(maxHealth(H)).
visibilityRange(R) :- storedPercept(visRange(R)).

% Visible entities, vertices and edges from the percepts
visibleEntity(Id,Vertex,Team,Status) :- storedPercept(visibleEntity(Id,Vertex,Team,Status)).
visibleVertex(Vertex) :- storedPercept(visibleVertex(Vertex,_)).
visibleEdge(Vertex1,Vertex2) :- storedPercept(visibleEdge(Vertex1,Vertex2)).
visibleEdge(Vertex1,Vertex2) :- storedPercept(visibleEdge(Vertex2,Vertex1)).

% Action result percepts
lastAction(Action) :- storedPercept(lastAction(Action)).
lastActionParam(Param) :- storedPercept(lastActionParam(Param)).
lastActionResult(failed_parry) :- storedPercept(lastActionResult(failed_parry)), !.
lastActionResult(failed_in_range) :- storedPercept(lastActionResult(failed_in_range)), !.
lastActionResult(failed_attacked) :- storedPercept(lastActionResult(failed_attacked)), !.
lastActionResult(Result) :- storedPercept(lastActionResult(Result)).
lastActionResultFailed :- storedPercept(lastActionResult(Result)), atom_chars(Result,Chrs), append([f,a,i,l,e,d],_,Chrs).
surveyedEdge(V1,V2,Weight) :- storedPercept(surveyedEdge(V1,V2,Weight)).
probedVertex(V,Value) :- storedPercept(probedVertex(V,Value)).
