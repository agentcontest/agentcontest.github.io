from behaviour_components.sensors import Sensor

from knowledge_base.knowledge_base_client import KnowledgeBaseClient

from agent_mutual.agent_utils import max_float, get_knowledge_base_name
from agent_mutual.constants import Constants

from state import State

from agent_auctioning.routing import Routing

class DestinationDistanceSensor(Sensor):
    '''
    This sensor is used for determining the duration in steps to some destination positon.
    '''
    def __init__(self, name, agent_name, reference):
        '''
        Constructor.
        :param name: this sensors name
        :type name: string
        :param agent_name: this agents name
        :type agent_name: string
        :param reference: the instance that holds the destination position
        '''
        super(DestinationDistanceSensor, self).__init__(name=name, initial_value=max_float())
        self._agent_name = agent_name
        self._reference = reference

        self._routing = None
        self._worldperception = None

    def reset(self):
        self._routing = None
        self._worldperception = None

        self.update(self._initial_value)

    def add_routing(self, routing):
        '''
        Adds routing instance.
        :param routing: the routing instance
        :return routing: Routing
        '''
        self._routing = routing

    def update_worldperception(self, worldperception):
        '''
        Updates worldperception and updates sensor information.
        :param worldperception: the current worldperception
        :type worldperception: WorldPerception
        '''
        self._worldperception = worldperception
        self.update_step()

    def update_step(self):
        '''
        Updates the current sensor data.
        '''
        destination = self._reference.get_destination()
        if destination:
            distance = self._routing.pathplanner.number_of_required_steps_to_facility(\
                    self._worldperception.agent.pos, destination)
            self.update(distance)
        else:
            self.update(max_float())


class ExplorationSensor(Sensor):
    '''
    This sensor is used for determining if there are unexplored grid points.
    '''
    def __init__(self, agent_name, reference):
        '''
        Constructor.
        :param agent_name: this agents name
        :type agent_name: string
        :param reference: the instance that holds the current grid point
        '''
        super(ExplorationSensor, self).__init__(name='exploration_sensor', initial_value=False)
        self._agent_name = agent_name
        self._reference = reference

        self._client = KnowledgeBaseClient(knowledge_base_name=get_knowledge_base_name())

        self._grid = None
        self._worldperception = None

    def reset(self):
        self._grid = None
        self._worldperception = None

        self.update(self._initial_value)

    def set_grid(self, grid):
        '''
        Updates the current grid with the given one.
        :param grid: the new grid
        :type grid: ExplorationGrid
        '''
        self._grid = grid

    def update_worldperception(self, worldperception):
        '''
        Updates worldperception and updates sensor information.
        :param worldperception: the current worldperception
        :type worldperception: WorldPerception
        '''
        self._worldperception = worldperception
        self.update_step()

    def update_step(self):
        '''
        Updates the current sensor data.
        '''
        state = State.get()
        if (state == State.EXPLORATION or state == State.IDLE) and\
                (self._reference.has_destination() or self._unexplored_grid_points_exist()):
            self.update(True)
        else:
            self.update(False)

    def _unexplored_grid_points_exist(self):
        '''
        Determines if there exist any unexplored grid points by querying the knowledge base.
        :result: if unexplored grid points exist True else False
        :type: bool
        '''
        exploration_knowledge = self._client.all(('*', 'exploring', '*', '*', '*'))
        if len(exploration_knowledge) < len(self._grid.lats) * len(self._grid.longs):
            return True
        return False


class FinishExplorationSensor(Sensor):
    '''
    This sensor is used for determining if the exploration of the current grid point can be finished.
    '''
    def __init__(self, agent_name):
        '''
        Constructor.
        :param agent_name: this agents name
        :type agent_name: string
        '''
        super(FinishExplorationSensor, self).__init__(name='finish_exploration_sensor',\
                initial_value=False)
        self._agent_name = agent_name

        self._worldperception = None

    def reset(self):
        self._worldperception = None

        self.update(self._initial_value)

    def update_worldperception(self, worldperception):
        '''
        Updates worldperception and updates sensor information.
        :param worldperception: the current worldperception
        :type worldperception: WorldPerception
        '''
        self._worldperception = worldperception
        self.update_step()

    def update_step(self):
        '''
        Updates the current sensor data.
        '''
        state = State.get()
        if state == State.EXPLORATION:
            self.update(True)
        else:
            self.update(False)


class ChargingSensor(Sensor):
    '''
    This sensor is used for determining if the charging may be triggered.
    '''
    def __init__(self, agent_name):
        '''
        Constructor.
        :param agent_name: this agents name
        :type agent_name: string
        '''
        super(ChargingSensor, self).__init__(name='charging_sensor', initial_value=False)
        self._agent_name = agent_name

        self._worldperception = None

    def reset(self):
        self._worldperception = None

        self.update(self._initial_value)

    def update_worldperception(self, worldperception):
        '''
        Updates worldperception and updates sensor information.
        :param worldperception: the current worldperception
        :type worldperception: WorldPerception
        '''
        self._worldperception = worldperception
        self.update_step()

    def update_step(self):
        '''
        Updates the current sensor data.
        '''
        state = State.get()
        if state != State.EXECUTE_PLAN:
            self.update(True)
        else:
            self.update(False)


class BatterySensor(Sensor):
    '''
    This sensor is used for measuring the battery value of this agent.
    '''
    def __init__(self, agent_name):
        '''
        Constructor.
        :param agent_name: this agents name
        :type agent_name: string
        '''
        super(BatterySensor, self).__init__(name='battery_sensor', initial_value=100.0)
        self._agent_name = agent_name

        self._worldperception = None

    def reset(self):
        self._worldperception = None

        self.update(self._initial_value)

    def update_worldperception(self, worldperception):
        '''
        Updates worldperception and updates sensor information.
        :param worldperception: the current worldperception
        :type worldperception: WorldPerception
        '''
        self._worldperception = worldperception
        self.update_step()

    def update_step(self):
        '''
        Updates the current sensor data.
        '''
        self.update(self._worldperception.agent.charge)


class FullBatterySensor(Sensor):
    '''
    This sensor is used for determining if the battery of this agent is already full.
    '''
    def __init__(self, agent_name, role):
        '''
        Constructor.
        :param agent_name: this agents name
        :type agent_name: string
        :param role: this agents role
        :type role: Role
        '''
        super(FullBatterySensor, self).__init__(name='full_battery_sensor', initial_value=True)
        self._agent_name = agent_name
        self._role = role

        self._worldperception = None

    def reset(self):
        self._worldperception = None

        self.update(self._initial_value)

    def update_worldperception(self, worldperception):
        '''
        Updates worldperception and updates sensor information.
        :param worldperception: the current worldperception
        :type worldperception: WorldPerception
        '''
        self._worldperception = worldperception
        self.update_step()

    def update_step(self):
        '''
        Updates the current sensor data.
        '''
        self.update(bool(self._worldperception.agent.charge >= self._role.base_battery))


class FinishChargingSensor(Sensor):
    '''
    This sensor is used for determining if the charging may be finished.
    '''
    def __init__(self, agent_name):
        '''
        Constructor.
        :param agent_name: this agents name
        :type agent_name: string
        '''
        super(FinishChargingSensor, self).__init__(name='finish_charging_sensor', initial_value=False)
        self._agent_name = agent_name

        self._worldperception = None

    def reset(self):
        self._worldperception = None

        self.update(self._initial_value)

    def update_worldperception(self, worldperception):
        '''
        Updates worldperception and updates sensor information.
        :param worldperception: the current worldperception
        :type worldperception: WorldPerception
        '''
        self._worldperception = worldperception
        self.update_step()

    def update_step(self):
        '''
        Updates the current sensor data.
        '''
        state = State.get()
        if state == State.CHARGING:
            self.update(True)
        else:
            self.update(False)


class ExecutePlanSensor(Sensor):
    '''
    This sensor is used for determining if there are plans to be executed.
    '''
    def __init__(self, agent_name, reference):
        '''
        Constructor.
        :param agent_name: this agents name
        :type agent_name: string
        :param reference: the instance holding the plans
        '''
        super(ExecutePlanSensor, self).__init__(name='execute_plan_sensor', initial_value=False)
        self._agent_name = agent_name
        self._reference = reference

        self._worldperception = None

    def reset(self):
        self._worldperception = None

        self.update(self._initial_value)

    def update_worldperception(self, worldperception):
        '''
        Updates worldperception and updates sensor information.
        :param worldperception: the current worldperception
        :type worldperception: WorldPerception
        '''
        self._worldperception = worldperception
        self.update_step()

    def update_step(self):
        '''
        Updates the current sensor data.
        '''
        if self._reference.has_work_to_do():
            self.update(True)
        else:
            self.update(False)


class FinishExecutePlanSensor(Sensor):
    '''
    This sensor is used for determining if there are no plans left to execute.
    '''
    def __init__(self, agent_name, reference):
        '''
        Constructor.
        :param agent_name: this agents name
        :type agent_name: string
        :param reference: the instance holding the plans
        '''
        super(FinishExecutePlanSensor, self).__init__(name='finish_execute_plan_sensor',\
                initial_value=False)
        self._agent_name = agent_name
        self._reference = reference

        self._worldperception = None

    def reset(self):
        self._worldperception = None

        self.update(self._initial_value)

    def update_worldperception(self, worldperception):
        '''
        Updates worldperception and updates sensor information.
        :param worldperception: the current worldperception
        :type worldperception: WorldPerception
        '''
        self._worldperception = worldperception
        self.update_step()

    def update_step(self):
        '''
        Updates the current sensor data.
        '''
        if State.get() == State.EXECUTE_PLAN:
            self.update(True)
        else:
            self.update(False)


class WellBuildingSensor(Sensor):
    '''
    This sensor is used for determining if wells could be built.
    '''
    def __init__(self, agent_name):
        '''
        Constructor.
        :param agent_name: this agents name
        :type agent_name: string
        '''
        super(WellBuildingSensor, self).__init__(name='well_building_sensor', initial_value=False)
        self._agent_name = agent_name

        self._client = KnowledgeBaseClient(knowledge_base_name=get_knowledge_base_name())

        self._worldperception = None
        self._preferred_well = None

    def reset(self):
        self._worldperception = None
        self._preferred_well = None

        self.update(self._initial_value)

    def set_preferred_well(self, well):
        '''
        Sets the preferred well to build.
        :param well: the preferred well
        :type well: Well
        '''
        self._preferred_well = well

    def update_worldperception(self, worldperception):
        '''
        Updates worldperception and updates sensor information.
        :param worldperception: the current worldperception
        :type worldperception: WorldPerception
        '''
        self._worldperception = worldperception
        self.update_step()

    def update_step(self):
        '''
        Updates the current sensor data.
        '''
        state = State.get()
        if state == State.IDLE or state == State.WELL_BUILDING:
            cw = self._client.peek((Constants.WELL, Constants.CURRENT_WELL, '*', '*', '*', '*', '*'))
            if (cw and (cw[4]==Constants.EXISTENT or\
                    (cw[4]==Constants.NONEXISTENT and self._enough_money()))) or\
                    self._client.exists((Constants.WELL, Constants.DISMANTLED_WELL, '*', '*',\
                    Constants.EXISTENT, '*', '*')):
                self.update(True)
            else:
                self.update(False)
        else:
            self.update(False)

    def _enough_money(self):
        '''
        Returns if there is enough money left to build a new well.
        :return: True if there is enough money else False
        :type: bool
        '''
        if self._worldperception.team.massium >= self._preferred_well.cost:
            return True
        return False


class WellCompletelyBuiltSensor(Sensor):
    '''
    This sensor is used for determining if the current well has already been built up fully.
    '''
    def __init__(self, agent_name):
        '''
        Constructor.
        :param agent_name: this agents name
        :type agent_name: string
        '''
        super(WellCompletelyBuiltSensor, self).__init__(name='well_completely_built_sensor',\
                initial_value=False)
        self._agent_name = agent_name

        self._client = KnowledgeBaseClient(knowledge_base_name=get_knowledge_base_name())

        self._worldperception = None
        self._last_well = None

    def reset(self):
        self._worldperception = None
        self._last_well = None

        self.update(self._initial_value)

    def update_worldperception(self, worldperception, well_knowledge):
        '''
        Updates worldperception and updates sensor information.
        :param well_knowledge:
        :param worldperception: the current worldperception
        :type worldperception: WorldPerception
        '''
        self._worldperception = worldperception
        self._update_last_well(well_knowledge)
        self.update_step()

    def _update_last_well(self, well_knowledge):
        '''
        Updates the last well by retrieving it from the knowledge base.
        '''
        if not self._last_well and well_knowledge:
            self._last_well = well_knowledge[5]

    def update_step(self):
        '''
        Updates the current sensor data.
        '''
        state = State.get()
        if (state == State.IDLE or state == State.WELL_BUILDING) and\
                (self._last_well and self._is_last_well_done()):
            self._last_well = None
            self.update(True)
        else:
            self.update(False)

    def _is_last_well_done(self):
        '''
        Returns if the last well has been built successfully.
        :return: True if last well is already built else False
        :type: bool
        '''
        return self._client.exists((Constants.WELL, Constants.WELL_DONE, '*', '*', '*', self._last_well,\
                '*'))


class FinishWellBuildingSensor(Sensor):
    '''
    This sensor is used for determining if the well building may be finished.
    '''
    def __init__(self, agent_name):
        '''
        Constructor.
        :param agent_name: this agents name
        :type agent_name: string
        '''
        super(FinishWellBuildingSensor, self).__init__(name='finish_well_building_sensor',\
                initial_value=False)
        self._agent_name = agent_name

        self._worldperception = None

    def reset(self):
        self._worldperception = None

        self.update(self._initial_value)

    def update_worldperception(self, worldperception):
        '''
        Updates worldperception and updates sensor information.
        :param worldperception: the current worldperception
        :type worldperception: WorldPerception
        '''
        self._worldperception = worldperception
        self.update_step()

    def update_step(self):
        '''
        Updates the current sensor data.
        '''
        state = State.get()
        if state == State.WELL_BUILDING:
            self.update(True)
        else:
            self.update(False)


class EnemyWellDiscoveredSensor(Sensor):
    '''
    This sensor is used for determining if a well can be dismantled.
    '''
    def __init__(self, agent_name):
        '''
        Constructor.
        :param agent_name: this agents name
        :type agent_name: string
        '''
        super(EnemyWellDiscoveredSensor, self).__init__(name='enemy_well_discovered_sensor',\
                initial_value=False)
        self._agent_name = agent_name

        self._client = KnowledgeBaseClient(knowledge_base_name=get_knowledge_base_name())

        self._worldperception = None

    def reset(self):
        self._worldperception = None

        self.update(self._initial_value)

    def update_worldperception(self, worldperception):
        '''
        Updates worldperception and updates sensor information.
        :param worldperception: the current worldperception
        :type worldperception: WorldPerception
        '''
        self._worldperception = worldperception
        self.update_step()

    def update_step(self):
        '''
        Updates the current sensor data.
        '''
        state = State.get()
        if (state == State.IDLE or state == State.WELL_DISMANTLING) and\
                (self._client.exists((Constants.WELL, Constants.ENEMY_WELL, '*', '*', Constants.EXISTENT,\
                '*', '*')) or self._client.exists((Constants.WELL, Constants.CURRENT_DISMANTLE_WELL, '*',\
                '*', '*', '*', '*'))):
            self.update(True)
        else:
            self.update(False)


class WellCompletelyDismantledSensor(Sensor):
    '''
    This sensor is used for determining if the current well has already been built up fully.
    '''
    def __init__(self, agent_name):
        '''
        Constructor.
        :param agent_name: this agents name
        :type agent_name: string
        '''
        super(WellCompletelyDismantledSensor, self).__init__(name='well_completely_dismantled_sensor',\
                initial_value=False)
        self._agent_name = agent_name

        self._client = KnowledgeBaseClient(knowledge_base_name=get_knowledge_base_name())

        self._worldperception = None
        self._last_well = None

    def reset(self):
        self._worldperception = None
        self._last_well = None

        self.update(self._initial_value)

    def update_worldperception(self, worldperception):
        '''
        Updates worldperception and updates sensor information.
        :param worldperception: the current worldperception
        :type worldperception: WorldPerception
        '''
        self._worldperception = worldperception
        self._update_last_well()
        self.update_step()

    def _update_last_well(self):
        '''
        Updates the last well by retrieving it from the knowledge base.
        '''
        if not self._last_well:
            w = self._client.peek((Constants.WELL, Constants.CURRENT_DISMANTLE_WELL, '*', '*', '*', '*',\
                    '*'))
            if w:
                self._last_well = w[5]

    def update_step(self):
        '''
        Updates the current sensor data.
        '''
        state = State.get()
        if state == State.WELL_DISMANTLING and self._last_well and self._is_last_well_done():
            self._last_well = None
            self.update(True)
        else:
            self.update(False)

    def _is_last_well_done(self):
        '''
        Returns true if the last well has been dismantled successfully.
        :return: True if last discovered enemy well has been dismantled successfully.
        :type: bool
        '''
        return self._client.peek((Constants.WELL, Constants.ENEMY_WELL, '*', '*', Constants.NONEXISTENT,\
                self._last_well, '*'))


class FinishWellDismantlingSensor(Sensor):
    '''
    This sensor is used for determining if the well dismantling may be finished.
    '''
    def __init__(self, agent_name):
        '''
        Constructor.
        :param agent_name: this agents name
        :type agent_name: string
        '''
        super(FinishWellDismantlingSensor, self).__init__(name='finish_well_dismantling_sensor',\
                initial_value=False)
        self._agent_name = agent_name

        self._worldperception = None

    def reset(self):
        self._worldperception = None

        self.update(self._initial_value)

    def update_worldperception(self, worldperception):
        '''
        Updates worldperception and updates sensor information.
        :param worldperception: the current worldperception
        :type worldperception: WorldPerception
        '''
        self._worldperception = worldperception
        self.update_step()

    def update_step(self):
        '''
        Updates the current sensor data.
        '''
        state = State.get()
        if state == State.WELL_DISMANTLING:
            self.update(True)
        else:
            self.update(False)

class DefaultSensor(Sensor):
    '''
    This sensor is used for determining if we are in idle state.
    '''
    def __init__(self, agent_name):
        '''
        Constructor.
        :param agent_name: this agents name
        :type agent_name: string
        '''
        super(DefaultSensor, self).__init__(name='default_sensor', initial_value=False)
        self._agent_name = agent_name

        self._worldperception = None

    def reset(self):
        self._worldperception = None

        self.update(self._initial_value)

    def update_worldperception(self, worldperception):
        '''
        Updates worldperception and updates sensor information.
        :param worldperception: the current worldperception
        :type worldperception: WorldPerception
        '''
        self._worldperception = worldperception
        self.update_step()

    def update_step(self):
        '''
        Updates the current sensor data.
        '''
        state = State.get()
        if state == State.IDLE:
            self.update(True)
        else:
            self.update(False)
