#!/usr/bin/env python2

import rospy

from behaviour_components.managers import Manager

from agent_mutual.agent_utils import log, get_knowledge_base_name
from agent_mutual.statistics import Stats

from agent_auctioning.routing import Routing

from exploration import ExplorationBehaviourGraph, ExplorationGrid
from charging import ChargingBehaviourGraph
from execute_plan import ExecutePlanBehaviourGraph
from wells import WellBehaviourGraph
from well_dismantling import WellDismantlingBehaviourGraph
from default import DefaultBehaviourGraph

from actions import Action, GoToAction, GoToFacilityAction, RechargeAction
from state import State

class AgentRHBP(object):
    '''
    This class contains the rhbp manager and all the behaviour graphs that are needed to let this agent
    participate in the simulation process by responding to action requests by triggering the sending of
    actions.
    '''
    def __init__(self, agent_name, agent_number):
        '''
        Constructor.
        :param agent_name: the agents name
        :type agent_name: string
        '''
        self._agent_name = agent_name
        self._agent_number = agent_number

        # ensure also max_parallel_behaviours during debugging
        self._manager = Manager(prefix=self._agent_name, max_parallel_behaviours=1)
        self._behaviour_network_initialized = False

        self._routing = None
        self._worldperception = None

        self._sim_started = False

    def reset(self):
        del self._sim_started

        self._routing = None
        self._worldperception = None

        State.set(State.IDLE)

        self._sim_started = False

    def start(self, msg):
        """
        Hands over the simulation start information and initializes the behaviour network.
        :param msg:  the message
        :type msg: SimStart
        """

        self._routing = Routing(node_name=self._agent_name, role=msg.role, cell_size=msg.cell_size,\
                proximity=msg.proximity, map_name=msg.map)

        speed = 4.8
        grid = ExplorationGrid(speed=speed, cell_size=msg.cell_size, min_lat=msg.min_lat, \
                                    max_lat=msg.max_lat, min_lon=msg.min_lon, max_lon=msg.max_lon)

        if not self._behaviour_network_initialized:
            self._initialize_behaviour_network(msg=msg, routing=self._routing, grid=grid)
            self._behaviour_network_initialized = True
        else:
            self._reset_behaviour_network(msg=msg, routing=self._routing, grid=grid)

        self._sim_started = True

    def _initialize_behaviour_network(self, msg, routing, grid):
        '''
        Initializes the rhbp behaviour network.
        :param msg:  the message
        :type msg: SimStart
        '''
        self._exploration_graph = ExplorationBehaviourGraph(agent_name=self._agent_name)
        self._exploration_graph.prepare(msg, routing=routing, grid=grid)

        self._charging_graph = ChargingBehaviourGraph(agent_name=self._agent_name, role=msg.role)
        self._charging_graph.prepare(msg, routing=routing)

        self._execute_plan_graph = ExecutePlanBehaviourGraph(agent_name=self._agent_name,\
                agent_number=self._agent_number)
        self._execute_plan_graph.prepare(msg, routing=routing)

        self._well_graph = WellBehaviourGraph(agent_name=self._agent_name)
        self._well_graph.prepare(msg, routing=routing, grid=grid)

        self._well_dismantle_graph = WellDismantlingBehaviourGraph(agent_name=self._agent_name)
        self._well_dismantle_graph.prepare(routing=routing)

        self._default_graph = DefaultBehaviourGraph(agent_name=self._agent_name)
        self._default_graph.prepare(msg, routing=routing)

        # precondition such that exploration must be finished first when at destination
        self._charging_graph.add_precondition(self._exploration_graph.get_not_finished_condition())
        self._execute_plan_graph.add_precondition(self._exploration_graph.get_not_finished_condition())
        self._well_graph.add_precondition(self._exploration_graph.get_not_finished_condition())
        self._well_dismantle_graph.add_precondition(self._exploration_graph.get_not_finished_condition())
        self._default_graph.add_precondition(self._exploration_graph.get_not_finished_condition())

        # precondition such that execute plan is favorized when there are plans to execute
        self._exploration_graph.add_precondition(self._execute_plan_graph.get_not_finished_condition())
        self._charging_graph.add_precondition(self._execute_plan_graph.get_not_finished_condition())
        self._well_graph.add_precondition(self._execute_plan_graph.get_not_finished_condition())
        self._well_dismantle_graph.add_precondition(self._execute_plan_graph.get_not_finished_condition())
        self._default_graph.add_precondition(self._execute_plan_graph.get_not_finished_condition())

        # precondition to make charging more important
        #self._exploration_graph.add_precondition(self._charging_graph.get_negated_charging_condition())
        #self._well_graph.add_precondition(self._charging_graph.get_negated_charging_condition())
        #self._default_graph.add_precondition(self._charging_graph.get_negated_charging_condition())

        # prioritize exploration before well building & well dismantling & default
        self._well_graph.add_precondition(self._exploration_graph.get_negated_exploration_condition())
        self._well_dismantle_graph.add_precondition(\
                self._exploration_graph.get_negated_exploration_condition())
        self._default_graph.add_precondition(self._exploration_graph.get_negated_exploration_condition())

        # prioritize well building before well dismantling & default
        self._well_dismantle_graph.add_precondition(\
                self._well_graph.get_negated_well_building_condition())
        self._default_graph.add_precondition(self._well_graph.get_negated_well_building_condition())

        # prioritize well dismantling before default
        self._default_graph.add_precondition(\
                self._well_dismantle_graph.get_negated_well_dismantle_condition())

        """
        # TODO: for debugging two teams with different strategies
        if self._agent_name.find('A') >= 0:
            log(agent_name=self._agent_name, text='team A will build, explore, dismantle')
            # prioritize well building before exploration
            self._exploration_graph.add_precondition(self._well_graph.get_negated_well_condition())
            # prioritize well building before well dismantling
            self._well_dismantle_graph.add_precondition(self._well_graph.get_negated_well_condition())
            # prioritize exploration before well dismantling
            self._well_dismantle_graph.add_precondition(\
                    self._exploration_graph.get_negated_exploration_condition())
        else:
            log(agent_name=self._agent_name, text='team B will dismantle, explore, build')
            # prioritize well dismantling before exploration
            self._exploration_graph.add_precondition(\
                    self._well_dismantle_graph.get_negated_well_dismantle_condition())
            # prioritize exploration before well building
            self._well_graph.add_precondition(self._exploration_graph.get_negated_exploration_condition())
            # prioritize well dismantling before well building
            self._well_graph.add_precondition(\
                    self._well_dismantle_graph.get_negated_well_dismantle_condition())
        """

    def _reset_behaviour_network(self, msg, routing, grid):
        self._exploration_graph.reset()
        self._exploration_graph.prepare(msg, routing=routing, grid=grid)

        self._charging_graph.reset()
        self._charging_graph.prepare(msg, routing=routing)

        self._execute_plan_graph.reset()
        self._execute_plan_graph.prepare(msg, routing=routing)

        self._well_graph.reset()
        self._well_graph.prepare(msg, routing=routing, grid=grid)

        self._well_dismantle_graph.reset()
        self._well_dismantle_graph.prepare(routing=routing)

        self._default_graph.reset()
        self._default_graph.prepare(msg, routing=routing)

    def compute_next_deadline(self, simulation_step, timestamp, deadline):
        '''
        :param timestamp: the timestamp
        :type timestamp: uint64
        :param deadline: the deadline of the action response:
        :type timestamp: uint64
        '''
        # calculate deadline
        self._start_time = rospy.get_rostime()
        safety_offset = rospy.Duration.from_sec(0.3)  # Safety offset in seconds
        recharge_offset = rospy.Duration.from_sec(0.1)  # Recharge offset in seconds
        deadline_msg = rospy.Time.from_sec(deadline / 1000.0)
        current_msg = rospy.Time.from_sec(timestamp / 1000.0)

        # TODO
        #self._deadline = self._start_time + (deadline_msg - current_msg) - safety_offset
        #self._deadline = deadline_msg - recharge_offset
        self._deadline = deadline_msg - safety_offset
        if self._start_time < deadline_msg - recharge_offset:
            return True
        else:
            log(self._agent_name, '[RHBP] (step='+str(simulation_step)+\
                    ') Request Action too late! Send no action!', 'err')
            return False

    def update_worldperception(self, worldperception):
        '''
        Updates worldperception.
        :param worldperception: the current worldperception
        :type worldperception: WorldPerception
        '''
        self._worldperception = worldperception

        self._routing.update_facilites(worldperception.facilities)

        self._exploration_graph.update_worldperception(self._worldperception)
        self._charging_graph.update_worldperception(self._worldperception)
        self._execute_plan_graph.update_worldperception(self._worldperception)
        self._well_graph.update_worldperception(self._worldperception)
        self._well_dismantle_graph.update_worldperception(self._worldperception)
        self._default_graph.update_worldperception(self._worldperception)

    def do_step(self):
        """
        Triggers the rhbp decision-making and planning, while tracking the available time and behaviour
        responses.
        """
        # set flag that current route existing
        if self._worldperception.agent.last_action == GoToAction.ACTION and\
                self._worldperception.agent.last_action_result == 'successful':
            Action.goto_success = True

        # handle failed location error
        if self._worldperception.agent.last_action_result == 'failed_location':
            if Action.last_position:
                GoToAction(agent_name=self._agent_name, position=Action.last_position).send()
            elif Action.last_facility:
                GoToFacilityAction(agent_name=self._agent_name, facility=Action.last_facility).send()
            else:
                Action.sent = False
        else:
            Action.sent = False

        while not Action.sent and rospy.get_rostime() < self._deadline:
            # action send is finally triggered by a selected behaviour
            self._manager.step(guarantee_decision=True)
            #self._manager.step()
            if not Action.sent:
                # update rhbp sensors
                self._update_sensors()

        duration = rospy.get_rostime() - self._start_time
        Stats.log_action_response_duration(duration=duration.to_sec())

        if not Action.sent:  # Our decision-making has taken too long
            # send recharge action
            log(self._agent_name, '[RHBP] (step='+str(self._worldperception.simulation_step)+\
                    ') Decision-making timeout! {'+State.get()+'}', 'err')
            RechargeAction(agent_name=self._agent_name).send()
            Stats.log_decision_making_timeouts()

    def _update_sensors(self):
        '''
        Updates the sensors of all behaviour graphs.
        '''
        self._exploration_graph.update_sensors()
        self._charging_graph.update_sensors()
        self._execute_plan_graph.update_sensors()
        self._well_graph.update_sensors()
        self._well_dismantle_graph.update_sensors()
        self._default_graph.update_sensors()

    def has_been_initialized(self):
        return hasattr(self, '_sim_started')

    def has_been_started(self, simulation_step):
        if not self._sim_started:
            log(self._agent_name, '[RHBP] (step='+str(simulation_step)+\
                    ') Sim not yet started!', 'err')
            return False
        return True
