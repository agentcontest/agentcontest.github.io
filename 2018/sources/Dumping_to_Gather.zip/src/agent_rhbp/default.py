from behaviour_components.activators import BooleanActivator, ThresholdActivator
from behaviour_components.conditions import Condition, Negation, Conjunction
from behaviour_components.condition_elements import Effect
from behaviour_components.goals import GoalBase

from behaviours import DefaultBehaviour, FinishDefaultBehaviour
from sensors import DefaultSensor, DestinationDistanceSensor

class DefaultBehaviourGraph(object):

    def __init__(self, agent_name):
        '''
        Constructor.
        :param agent_name: the agents name
        :type agent_name: string
        '''
        self._agent_name = agent_name

        self._routing = None

        # behaviours
        self._default_behaviour = DefaultBehaviour(agent_name=self._agent_name)
        self._finish_default_behaviour = FinishDefaultBehaviour(agent_name=self._agent_name,\
                reference=self._default_behaviour)

        # sensors
        self._default_sensor = DefaultSensor(agent_name=self._agent_name)
        self._default_distance_sensor = DestinationDistanceSensor(name='default_distance',\
                agent_name=self._agent_name, reference=self._default_behaviour)

        # effects
        self._default_behaviour.add_effect(effect=Effect(\
                sensor_name=self._default_distance_sensor.name, indicator=-1.0, sensor_type=float))
        self._finish_default_behaviour.add_effect(effect=Effect(\
                sensor_name=self._default_sensor.name, indicator=-1.0, sensor_type=bool))

        # conditions
        self._default_condition = Condition(sensor=self._default_sensor,\
                activator=BooleanActivator(desiredValue=True))
        self._at_default_destination_condition = Condition(self._default_distance_sensor,\
                ThresholdActivator(thresholdValue=0, isMinimum=False))

        self._default_behaviour.add_precondition(self._default_condition)
        self._default_behaviour.add_precondition(Negation(self._at_default_destination_condition))

        self._finish_default_behaviour.add_precondition(self._default_condition)
        self._finish_default_behaviour.add_precondition(self._at_default_destination_condition)

        # goal
        #self._default_goal = GoalBase(name='default_goal', permanent=True,\
        #        plannerPrefix=self._agent_name, conditions=[Negation(self._default_condition)])

    def reset(self):
        self._routing = None

        self._default_behaviour.reset()
        self._finish_default_behaviour.reset()

        self._default_sensor.reset()
        self._default_distance_sensor.reset()

    def prepare(self, msg, routing):
        '''
        Hands over the sim-start message and an routing instance.
        :param msg: the sim start message
        :type msg: SimStart
        :param routing: the routing instance
        :type routing: Routing
        '''
        self._routing = routing
        self._default_distance_sensor.add_routing(self._routing)

    def add_precondition(self, condition):
        '''
        Adds the given precondition to all behaviours but the finish behaviour.
        :param condition: the precondition
        :type condition: Condition
        '''
        self._default_behaviour.add_precondition(condition)

    def update_worldperception(self, worldperception):
        '''
        Updates worldperception.
        :param worldperception: the current worldperception
        :type worldperception: WorldPerception
        '''
        self._default_behaviour.update_worldperception(worldperception)

        self._default_sensor.update_worldperception(worldperception)
        self._default_distance_sensor.update_worldperception(worldperception)

    def update_sensors(self):
        '''
        Updates the sensors.
        '''
        self._default_sensor.update_step()
        self._default_distance_sensor.update_step()
