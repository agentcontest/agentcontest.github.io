from behaviour_components.activators import BooleanActivator, ThresholdActivator
from behaviour_components.conditions import Condition, Negation, Disjunction
from behaviour_components.condition_elements import Effect
from behaviour_components.goals import GoalBase

from behaviours import WellBuildingBehaviour, BuildBehaviour, FinishWellBuildingBehaviour,\
        WellDismantlingBehaviour, DismantleBehaviour, FinishWellDismantlingBehaviour
from sensors import DestinationDistanceSensor, WellBuildingSensor, WellCompletelyBuiltSensor,\
        FinishWellBuildingSensor, EnemyWellDiscoveredSensor, WellCompletelyDismantledSensor,\
        FinishWellDismantlingSensor

from actions import DismantleWellAction

from knowledge_base.knowledge_base_client import KnowledgeBaseClient

from agent_mutual.constants import Constants
from agent_mutual.statistics import Stats
from agent_mutual.agent_utils import get_knowledge_base_name

from mac_ros_bridge.msg import Well, Agent

from mac_agent.msg import WorldPerception


class WellDismantlingBehaviourGraph(object):
    '''
    This class establishes the rhbp behaviour graph for well building purposes. When not in execution plan
    state or exploration state this is used to build wells which is necessary for generating score points.
    '''
    def __init__(self, agent_name):
        '''
        Constructor.
        :param agent_name: the agents name
        :type agent_name: string
        '''
        self._agent_name = agent_name

        self._client = KnowledgeBaseClient(knowledge_base_name=get_knowledge_base_name())

        self._routing = None

        # behaviours
        self._well_dismantling_behaviour = WellDismantlingBehaviour(agent_name=self._agent_name)
        self._dismantle_behaviour = DismantleBehaviour(agent_name=self._agent_name)
        self._finish_well_dismantling_behaviour = FinishWellDismantlingBehaviour(\
                agent_name=self._agent_name)

        # sensors
        self._enemy_well_discovered_sensor = EnemyWellDiscoveredSensor(agent_name=self._agent_name)
        self._enemy_well_distance_sensor = DestinationDistanceSensor(name='enemy_well_distance', \
                agent_name=self._agent_name, reference=self._well_dismantling_behaviour)
        self._well_completely_dismantled_sensor = WellCompletelyDismantledSensor(\
                agent_name=self._agent_name)
        self._finish_well_dismantling_sensor = FinishWellDismantlingSensor(agent_name=self._agent_name)

        # effects
        self._well_dismantling_behaviour.add_effect(Effect(\
                sensor_name=self._enemy_well_distance_sensor.name, indicator=-1.0, sensor_type=float))
        self._dismantle_behaviour.add_effect(effect=Effect(\
                sensor_name=self._well_completely_dismantled_sensor.name, indicator=1.0,sensor_type=bool))
        self._finish_well_dismantling_behaviour.add_effect(Effect(\
                sensor_name=self._finish_well_dismantling_sensor.name, indicator=-1.0, sensor_type=bool))

        # conditions
        self._enemy_well_discovered_condition = Condition(sensor=self._enemy_well_discovered_sensor,\
                activator=BooleanActivator(desiredValue=True))
        self._at_enemy_well_condition = Condition(sensor=self._enemy_well_distance_sensor,
                activator=ThresholdActivator(thresholdValue=0, isMinimum=False))
        self._well_completely_dismantled_condition = Condition(sensor=\
                self._well_completely_dismantled_sensor, activator=BooleanActivator(desiredValue=True))
        self._finish_well_dismantling_condition = Condition(sensor=self._finish_well_dismantling_sensor,\
                activator=BooleanActivator(desiredValue=True))

        self._well_dismantling_behaviour.add_precondition(self._enemy_well_discovered_condition)
        #self._well_dismantling_behaviour.add_precondition(\
        #        Negation(self._well_completely_dismantled_condition))
        self._well_dismantling_behaviour.add_precondition(Negation(self._at_enemy_well_condition))

        self._dismantle_behaviour.add_precondition(self._enemy_well_discovered_condition)
        self._dismantle_behaviour.add_precondition(self._at_enemy_well_condition)
        self._dismantle_behaviour.add_precondition(Negation(self._well_completely_dismantled_condition))

        #self._finish_well_dismantling_behaviour.add_precondition(\
        #        self._well_completely_dismantled_condition)
        self._finish_well_dismantling_behaviour.add_precondition(Disjunction(\
                self._well_completely_dismantled_condition,\
                Negation(self._enemy_well_discovered_condition)))
        self._finish_well_dismantling_behaviour.add_precondition(self._finish_well_dismantling_condition)

        # goal
        self._well_dismantling_goal = GoalBase(name='well_dismantling_goal', permanent=True,\
                plannerPrefix=self._agent_name,\
                conditions=[Negation(self._finish_well_dismantling_condition)])

    def reset(self):
        self._routing = None

        self._well_dismantling_behaviour.reset()
        self._dismantle_behaviour.reset()
        self._finish_well_dismantling_behaviour.reset()

        self._enemy_well_discovered_sensor.reset()
        self._enemy_well_distance_sensor.reset()
        self._well_completely_dismantled_sensor.reset()
        self._finish_well_dismantling_sensor.reset()

    def prepare(self, routing):
        '''
        Hands over the sim-start message and an routing instance.
        :param msg: the sim start message
        :type msg: SimStart
        :param routing: the routing instance
        :type routing: Routing
        '''
        self._routing = routing
        self._well_dismantling_behaviour.add_routing(self._routing)
        self._enemy_well_distance_sensor.add_routing(self._routing)

    def add_precondition(self, condition):
        '''
        Adds the given precondition to all behaviours but the finish behaviour.
        :param condition: the precondition
        :type condition: Condition
        '''
        self._well_dismantling_behaviour.add_precondition(condition)
        self._dismantle_behaviour.add_precondition(condition)

    def update_worldperception(self, worldperception):
        '''
        Updates worldperception.
        :param worldperception: the current worldperception
        :type worldperception: WorldPerception
        '''
        self._handle_well_dismantled(agent=worldperception.agent,\
                enemy_wells=worldperception.facilities.enemy_wells)

        self._well_dismantling_behaviour.update_worldperception(worldperception)
        self._dismantle_behaviour.update_worldperception(worldperception)

        self._enemy_well_discovered_sensor.update_worldperception(worldperception)
        self._enemy_well_distance_sensor.update_worldperception(worldperception)
        self._well_completely_dismantled_sensor.update_worldperception(worldperception)
        self._finish_well_dismantling_sensor.update_worldperception(worldperception)

    def update_sensors(self):
        """
        Updates the sensors.
        """
        # first well building behaviour because sensors use updated destination
        self._well_dismantling_behaviour.update_destination()

        self._enemy_well_discovered_sensor.update_step()
        self._enemy_well_distance_sensor.update_step()
        self._well_completely_dismantled_sensor.update_step()
        self._finish_well_dismantling_sensor.update_step()

    def _handle_well_dismantled(self, agent, enemy_wells):
        """
        Handles the dismantling process of a well by updating the knowledge base.
        :param agent:
        :type agent: Agent
        :param enemy_wells:
        :type enemy_wells: Well[]
        :return:
        """
        current_well_knowledge = self._client.peek((Constants.WELL,\
                Constants.CURRENT_DISMANTLE_WELL, '*', '*', '*', '*', '*'))
        if agent.last_action == DismantleWellAction.ACTION and\
                agent.last_action_result == 'successful' and current_well_knowledge:

            # if there is no facility, well was completely dismantled:
            if not agent.facility:
                self._client.update(pattern=current_well_knowledge,\
                        new=(Constants.WELL, Constants.ENEMY_WELL, current_well_knowledge[2],\
                        current_well_knowledge[3], Constants.NONEXISTENT, current_well_knowledge[5], '0'))
                # delete destination since well does not exist anymore
                self._well_dismantling_behaviour.clear_destination()
                return

        # make sure current dismantle position is really deleted:
        current_well_knowledge = self._client.peek((Constants.WELL, Constants.CURRENT_DISMANTLE_WELL, str(agent.pos.lat),
                                                   str(agent.pos.long), '*', '*', '*'))
        if current_well_knowledge and not agent.in_facility:
            self._client.update(pattern=current_well_knowledge,
                                new=(Constants.WELL, Constants.ENEMY_WELL, current_well_knowledge[2],
                                     current_well_knowledge[3], Constants.NONEXISTENT, current_well_knowledge[5], '0'))
            # delete destination since well does not exist anymore
            self._well_dismantling_behaviour.clear_destination()

            # TODO: delete if not necessary:
            """
            # if agent is at well:
            elif current_well_knowledge[5] == agent.facility:
                current_integrity = self._get_current_integrity(enemy_wells, agent.facility)
                if current_integrity:  # update integrity
                    self._client.update(pattern=current_well_knowledge,\
                            new=(Constants.WELL, Constants.CURRENT_DISMANTLE_WELL,\
                            current_well_knowledge[2], current_well_knowledge[3],\
                            current_well_knowledge[4], agent.facility, str(current_integrity)))
            """
    def _get_current_integrity(self, enemy_wells, well_name):

        for w in enemy_wells:
            if w.name == well_name:
                return w.integrity

    def get_negated_well_dismantle_condition(self):
        """
        Returns the negation of the condition required for dismantling wells.
        :return:
        """
        return Negation(self._enemy_well_discovered_condition)
