from behaviour_components.activators import BooleanActivator, ThresholdActivator,\
        LinearActivator
from behaviour_components.conditions import Condition, Negation, Conjunction, Disjunction
from behaviour_components.condition_elements import Effect
from behaviour_components.goals import GoalBase

from behaviours import ChargingBehaviour, ChargeBehaviour, RechargeBehaviour, FinishChargingBehaviour

from sensors import ChargingSensor, BatterySensor, FullBatterySensor,\
        DestinationDistanceSensor, FinishChargingSensor

class ChargingBehaviourGraph(object):
    '''
    This class establishes the rhbp behaviour graph for charging purposes. When not in execution plan
    state this is used to prevent the agent from an empty battery.
    '''
    def __init__(self, agent_name, role):
        '''
        Constructor.
        :param agent_name: the agents name
        :type agent_name: string
        :param role: the agents role
        :type role: Role
        '''
        self._agent_name = agent_name
        self._role = role

        self._routing = None

        battery_capacity = self._role.base_battery
        charge_lower_bound = int(0.3 * battery_capacity)
        charge_upper_bound = int(battery_capacity)

        # behaviours
        self._charging_behaviour = ChargingBehaviour(agent_name=self._agent_name)
        self._charge_behaviour = ChargeBehaviour(agent_name=self._agent_name)
        self._recharge_behaviour = RechargeBehaviour(agent_name=self._agent_name)
        self._finish_charging_behaviour = FinishChargingBehaviour(agent_name=self._agent_name,\
                reference=self._charging_behaviour)

        # sensors
        self._charging_sensor = ChargingSensor(agent_name=self._agent_name)
        self._battery_sensor = BatterySensor(agent_name=self._agent_name)
        self._full_battery_sensor = FullBatterySensor(agent_name=self._agent_name, role=self._role)
        self._finish_charging_sensor = FinishChargingSensor(agent_name=self._agent_name)
        self._charging_station_distance_sensor =\
                DestinationDistanceSensor(name='charging_station_distance', agent_name=self._agent_name,\
                reference=self._charging_behaviour)

        # effects
        self._charging_behaviour.add_effect(effect=Effect(\
                sensor_name=self._charging_station_distance_sensor.name, indicator=-1.0,\
                sensor_type=float))
        self._charge_behaviour.add_effect(effect=Effect(\
                sensor_name=self._battery_sensor.name, indicator=battery_capacity/3.0, sensor_type=float))
        self._charge_behaviour.add_effect(effect=Effect(\
                sensor_name=self._full_battery_sensor.name, indicator=1.0, sensor_type=bool))
        self._recharge_behaviour.add_effect(effect=Effect(\
                sensor_name=self._battery_sensor.name, indicator=1.0, sensor_type=float))
        self._recharge_behaviour.add_effect(effect=Effect(\
                sensor_name=self._full_battery_sensor.name, indicator=1.0, sensor_type=bool))
        self._finish_charging_behaviour.add_effect(effect=Effect(\
                sensor_name=self._finish_charging_sensor.name, indicator=-1.0, sensor_type=bool))

        # conditions
        self._charging_condition = Condition(sensor=self._charging_sensor,\
                activator=BooleanActivator(desiredValue=True))
        self._finish_charging_condition = Condition(sensor=self._finish_charging_sensor,\
                activator=BooleanActivator(desiredValue=True))
        self._at_charging_station_condition = Condition(self._charging_station_distance_sensor,\
                activator=ThresholdActivator(thresholdValue=0, isMinimum=False))
        self._empty_battery_condition = Condition(self._battery_sensor,\
                activator=ThresholdActivator(thresholdValue=0, isMinimum=False))
        self._full_battery_condition = Condition(self._full_battery_sensor,\
                activator=BooleanActivator(desiredValue=True))
        self._require_charging_condition = Condition(sensor=self._battery_sensor,\
                activator=LinearActivator(zeroActivationValue=charge_upper_bound,\
                fullActivationValue=charge_lower_bound))

        self._charging_behaviour.add_precondition(self._charging_condition)
        self._charging_behaviour.add_precondition(Negation(self._at_charging_station_condition))
        self._charging_behaviour.add_precondition(self._require_charging_condition)
        self._charging_behaviour.add_precondition(Negation(self._empty_battery_condition))

        self._charge_behaviour.add_precondition(self._charging_condition)
        self._charge_behaviour.add_precondition(self._at_charging_station_condition)
        self._charge_behaviour.add_precondition(Negation(self._full_battery_condition))

        self._recharge_behaviour.add_precondition(self._charging_condition)
        self._recharge_behaviour.add_precondition(Negation(self._at_charging_station_condition))
        self._recharge_behaviour.add_precondition(self._empty_battery_condition)

        self._finish_charging_behaviour.add_precondition(self._finish_charging_condition)
        self._finish_charging_behaviour.add_precondition(self._at_charging_station_condition)
        self._finish_charging_behaviour.add_precondition(self._full_battery_condition)

        # goal
        self._charging_goal = GoalBase(name='charging_goal', permanent=True,\
                plannerPrefix=self._agent_name, conditions=[Negation(self._finish_charging_condition),\
                Negation(self._require_charging_condition)])
                #plannerPrefix=self._agent_name, conditions=[Negation(self._finish_charging_condition)])
                #self._full_battery_condition])
                #Negation(Conjunction(self._charging_condition, self._require_charging_condition))])

    def reset(self):
        self._routing = None

        self._charging_behaviour.reset()
        self._charge_behaviour.reset()
        self._recharge_behaviour.reset()
        self._finish_charging_behaviour.reset()

        self._charging_sensor.reset()
        self._battery_sensor.reset()
        self._full_battery_sensor.reset()
        self._finish_charging_sensor.reset()
        self._charging_station_distance_sensor.reset()

    def prepare(self, msg, routing):
        '''
        Hands over the sim-start message and an routing instance.
        :param msg: the sim start message
        :type msg: SimStart
        :param routing: the routing instance
        :type routing: Routing
        '''
        self._routing = routing
        self._charging_behaviour.add_routing(self._routing)
        self._charging_station_distance_sensor.add_routing(self._routing)

    def add_precondition(self, condition):
        '''
        Adds the given precondition to all behaviours but the finish behaviour.
        :param condition: the precondition
        :type condition: Condition
        '''
        self._charging_behaviour.add_precondition(condition)
        self._charge_behaviour.add_precondition(condition)
        self._recharge_behaviour.add_precondition(condition)

    def update_worldperception(self, worldperception):
        '''
        Updates worldperception.
        :param worldperception: the current worldperception
        :type worldperception: WorldPerception
        '''
        self._charging_behaviour.update_worldperception(worldperception)

        self._charging_sensor.update_worldperception(worldperception)
        self._battery_sensor.update_worldperception(worldperception)
        self._full_battery_sensor.update_worldperception(worldperception)
        self._finish_charging_sensor.update_worldperception(worldperception)
        self._charging_station_distance_sensor.update_worldperception(worldperception)

    def update_sensors(self):
        '''
        Updates the sensors.
        '''
        self._charging_sensor.update_step()
        self._battery_sensor.update_step()
        self._full_battery_sensor.update_step()
        self._finish_charging_sensor.update_step()
        self._charging_station_distance_sensor.update_step()

    def get_negated_charging_condition(self):
        return Negation(self._require_charging_condition)
