import rospy
import random
import sys

from agent_mutual.agent_utils import log, max_float, zip_plans, unzip_plans, get_current_timestamp,\
        get_auctioneer_topic_prefix, get_position, get_knowledge_base_name, get_items_string,\
        get_team_name
from agent_mutual.constants import Constants

from behaviour_components.behaviours import BehaviourBase

from knowledge_base.knowledge_base_client import KnowledgeBaseClient

from mac_ros_bridge.msg import Position, Item, GenericAction, Well
from mac_agent.msg import TaskFinishedMsg, PlanStatusMsg, WayPoint, WorldPerception, CancelJobMsg,\
        RetrieveNAssemblePlan, RetrieveNDeliverPlan

from mac_agent.srv import AssignedPlansSrv, AssignedPlansSrvResponse

from actions import GoToAction, GoToFacilityAction, ChargeAction, RechargeAction, GatherResourceAction,\
        StoreAction, DeliverAction, BuildWellAction, DismantleWellAction, AssembleAction,\
        AssistAssembleAction, RetrieveAction, RetrieveDeliveredAction

from state import State

from mac_utils.graphhopper import PathPlanner

try:
    from Queue import PriorityQueue # ver. < 3.0
except ImportError:
    from queue import PriorityQueue

class ExplorationBehaviour(BehaviourBase):
    '''
    Behaviour for going to the closest unexplored grid point.
    '''
    def __init__(self, agent_name, **kwargs):
        '''
        Constructor.
        :param agent_name: the agents name
        :type agent_name: string
        '''
        super(ExplorationBehaviour, self).__init__(plannerPrefix=agent_name, name='explore',\
                requires_execution_steps=True, **kwargs)
        self._agent_name = agent_name

        self._client = KnowledgeBaseClient(knowledge_base_name=get_knowledge_base_name())

        self._routing = None
        self._grid = None
        self._worldperception = None

        self._current_grid_point = None

    def reset(self):
        self._routing = None
        self._grid = None
        self._worldperception = None

        self._current_grid_point = None

    def add_routing(self, routing):
        '''
        Adds a routing instance.
        :params routing: the routing instance
        :type routing: Routing
        '''
        self._routing = routing

    def set_grid(self, grid):
        '''
        Updates the current exploration grid with the given exploration grid information.
        :params grid: the new grid
        :type grid: ExplorationGrid
        '''
        self._grid = grid

    def get_destination(self):
        '''
        Returns the current grid point position.
        :return: the current grid point
        :type: Position
        '''
        return self._current_grid_point

    def has_destination(self):
        '''
        Returns if there is a current grid point.
        :return: if there is a current grid point True else False
        :type: bool 
        '''
        return self._current_grid_point != None

    def clear_destination(self):
        '''
        Deletes the current grid point.
        '''
        self._current_grid_point = None

    def update_worldperception(self, worldperception):
        '''
        Updates worldperception.
        :param worldperception: the current worldperception
        :type worldperception: WorldPerception
        '''
        self._worldperception = worldperception
        self._handle_grid_point_not_reachable()

    def _handle_grid_point_not_reachable(self):
        '''
        Checks if there is no route to the current grid point and deletes the not reachable current
        grid point.
        '''
        if State.get() == State.EXPLORATION and\
                self._worldperception.agent.last_action_result == 'failed_no_route':
            # update point as not reachable in Knowledge Base:
            t = self._client.peek((self._agent_name, 'exploring', '*', '*', 'true'))
            if t:
                self._client.update((self._agent_name, 'exploring', t[2], t[3], 'true'),
                                    (self._agent_name, 'exploring', t[2], t[3], Constants.NOT_REACHABLE))
            # clear current grid point
            self.clear_destination()

    def do_step(self):
        '''
        Triggers the execution of this behaviour. Sends action to go to the current grid point and if
        there is none, it chooses the closest.
        '''
        log(self._agent_name, 'ExplorationBehaviour triggered!')
        state = State.get()
        if state == State.IDLE or state == State.EXPLORATION:
            if not self._current_grid_point:
                self._current_grid_point = self._get_next_grid_point()
            if self._current_grid_point:
                State.set(State.EXPLORATION)
                GoToAction(agent_name=self._agent_name, position=self._current_grid_point).send()

    def _get_next_grid_point(self):
        '''
        Chooses the grid point that is closest to this agent.
        :return: the closest grid point
        :type: Position
        '''
        exploration_knowledge = self._client.all(('*', 'exploring', '*', '*', '*'))
        # clear grid occupation
        self._grid.clear_occupation()
        # update occupation grid
        for t in exploration_knowledge:
            self._grid.occ[int(t[2])][int(t[3])] = True

        # choose closest grid point
        close_grid_points = self._get_euclidean_closest_grid_point()
        if len(close_grid_points) > 0:
            best_grid_point = close_grid_points[0]
            # check if chosen grid point not selected yet
            (i,j) = best_grid_point[1]
            if not self._client.exists(('*', 'exploring', str(i), str(j), '*')):
                if self._routing.pathplanner.number_of_required_steps_to_facility(\
                        self._worldperception.agent.pos, best_grid_point[0])>=0:
                    # TODO
                    #if self._worldperception.agent.role == 'drone':
                    self._client.push((self._agent_name, 'exploring', str(i), str(j), 'true'))
                    return best_grid_point[0]
                else:
                    self._client.push((self._agent_name, 'exploring', str(i), str(j),\
                            Constants.NOT_REACHABLE))
                    return self._get_next_grid_point()
            else:
                return self._get_next_grid_point()
        else:
            return None

    def _get_euclidean_closest_grid_point(self):
        closest_distance = sys.maxint
        closest_grid_point = None
        for i, lat in enumerate(self._grid.lats):
            for j, lon in enumerate(self._grid.longs):
                # check if gridpoint unexplored
                if self._grid.occ[i][j] == False:
                    p = Position(lat=self._grid.lats[i], long=self._grid.longs[j])
                    distance = PathPlanner.euclidean_distance(self._worldperception.agent.pos, p)
                    if closest_distance > distance:
                        closest_distance = distance
                        closest_grid_point = (p,(i,j))
        return [closest_grid_point] if closest_grid_point else []

    def _get_euclidean_closest_grid_points(self, k):
        '''
        Returns k grid points that are closest to this agent measured in euclidean distance.
        :param k: the number of grid points to return
        :type k: uint32
        :return: the list of k closest grid points
        :type: Position[]
        '''
        n = 0
        q = PriorityQueue()
        for i, lat in enumerate(self._grid.lats):
            for j, lon in enumerate(self._grid.longs):
                # check if gridpoint unexplored
                if self._grid.occ[i][j] == False:
                    p = Position(lat=self._grid.lats[i], long=self._grid.longs[j])
                    q.put((PathPlanner.euclidean_distance(self._worldperception.agent.pos, p), (p,(i,j))))
                    n += 1
        return [q.get()[1] for _ in range(min(n, k))]


class FinishExplorationBehaviour(BehaviourBase):
    '''
    Finishes the exploration behaviour and switches into the idle state.
    '''
    def __init__(self, agent_name, reference, **kwargs):
        '''
        Constructor.
        :param agent_name: the agents name
        :type agent_name: string
        :param reference: reference which contains the current grid point
        '''
        super(FinishExplorationBehaviour, self).__init__(plannerPrefix=agent_name, name='finish_explore',\
                requires_execution_steps=False, **kwargs)
        self._agent_name = agent_name
        self._reference = reference

        self._client = KnowledgeBaseClient(knowledge_base_name=get_knowledge_base_name())

        self._grid = None

    def reset(self):
        self._grid = None

    def set_grid(self, grid):
        '''
        Updates the current exploration grid with the given exploration grid information.
        :params grid: the new grid
        :type grid: ExplorationGrid
        '''
        self._grid = grid

    def do_step(self):
        '''
        Triggers the execution of this behaviour. Finishes the exploration behaviour by deleting the
        current grid point from the reference behaviour and sets the current state to idle.
        '''
        log(self._agent_name, 'FinishExplorationBehaviour triggered!')
        t = self._client.peek((self._agent_name, 'exploring', '*', '*', 'true'))
        if t:
            self._client.update((self._agent_name, 'exploring', t[2], t[3], 'true'),\
                    (self._agent_name, 'exploring', t[2], t[3], 'false'))
        self._reference.clear_destination()
        State.set(State.IDLE)


class ChargingBehaviour(BehaviourBase):
    '''
    Behaviour that goes to the closest charging station.
    '''
    def __init__(self, agent_name, **kwargs):
        '''
        Constructor.
        :param agent_name: the agents name
        :type agent_name: string
        '''
        super(ChargingBehaviour, self).__init__(plannerPrefix=agent_name, name='charging',\
                requires_execution_steps=True, **kwargs)
        self._agent_name = agent_name

        self._routing = None
        self._worldperception = None

        self._current_charging_station = None

    def reset(self):
        self._routing = None
        self._worldperception = None

        self._current_charging_station = None

    def add_routing(self, routing):
        '''
        Adds a routing instance.
        :params routing: the routing instance
        :type routing: Routing
        '''
        self._routing = routing

    def get_destination(self):
        '''
        Returns the current charging station position.
        :return: the current charging station position
        :type: Position
        '''
        if not self._current_charging_station:
            return None
        return self._current_charging_station.pos

    def has_destination(self):
        '''
        Returns if there is a current charging station.
        :return: if there is a current charging station True else False
        :type: bool
        '''
        return self._current_charging_station != None

    def clear_destination(self):
        '''
        Deletes the current charging station.
        '''
        self._current_charging_station = None

    def update_worldperception(self, worldperception):
        '''
        Updates worldperception.
        :param worldperception: the current worldperception
        :type worldperception: WorldPerception
        '''
        self._worldperception = worldperception

    def do_step(self):
        '''
        Triggers the charging behaviour. Sends a action to go to the current charging station and if
        there is none it chooses the closest.
        '''
        log(self._agent_name, 'ChargingBehaviour triggered!')
        state = State.get()
        if state != State.EXECUTE_PLAN:
            State.set(State.CHARGING)
            self._current_charging_station = self._get_closest_charging_station()
            GoToFacilityAction(agent_name=self._agent_name,\
                    facility=self._current_charging_station).send()

    def _get_closest_charging_station(self):
        """
        Determines the charging station that is the closest to the current agents position.
        :return: the closest charging station
        :type: ChargingStation
        """
        min_distance = max_float()
        chosen_facility = None
        for facility in self._worldperception.facilities.charging_stations:
            d = self._routing.pathplanner.number_of_required_steps_to_facility(\
                    self._worldperception.agent.pos, facility.pos)
            if d < min_distance:
                min_distance = d
                chosen_facility = facility
        return chosen_facility


class ChargeBehaviour(BehaviourBase):
    '''
    Behavior that triggers the charge action.
    '''
    def __init__(self, agent_name, **kwargs):
        '''
        Constructor.
        :param agent_name: the agents name
        :type agent_name: string
        '''
        super(ChargeBehaviour, self).__init__(plannerPrefix=agent_name, name='charge',\
                requires_execution_steps=True, **kwargs)
        self._agent_name = agent_name

    def reset(self):
        pass

    def do_step(self):
        '''
        Triggers the charge behaviour. Sends a charge action and sets the current state to charging.
        '''
        log(self._agent_name, 'ChargeBehaviour triggered!')
        State.set(State.CHARGING)
        ChargeAction(agent_name=self._agent_name).send()


class RechargeBehaviour(BehaviourBase):
    '''
    Behavior that triggers the recharge action.
    '''
    def __init__(self, agent_name, **kwargs):
        '''
        Constructor.
        :param agent_name: the agents name
        :type agent_name: string
        '''
        super(RechargeBehaviour, self).__init__(plannerPrefix=agent_name, name='recharge',\
                requires_execution_steps=True, **kwargs)
        self._agent_name = agent_name

    def reset(self):
        pass

    def do_step(self):
        '''
        Triggers the recharge behaviour. Sends a recharge action and sets the current state to charging.
        '''
        log(self._agent_name, 'RechargeBehaviour triggered!')
        State.set(State.CHARGING)
        RechargeAction(agent_name=self._agent_name).send()


class FinishChargingBehaviour(BehaviourBase):
    '''
    Behaviour that finishes the charging.
    '''
    def __init__(self, agent_name, reference, **kwargs):
        '''
        Constructor.
        :param agent_name: the agents name
        :type agent_name: string
        :param reference: reference which contains the current charging station
        '''
        super(FinishChargingBehaviour, self).__init__(plannerPrefix=agent_name, name='finish_charging',\
                requires_execution_steps=False, **kwargs)
        self._agent_name = agent_name
        self._reference = reference

    def reset(self):
        pass

    def do_step(self):
        '''
        Triggers the execution of this behaviour. Finishes the charging behaviour by deleting the
        current charging station from the reference behaviour and sets the current state to idle.
        '''
        log(self._agent_name, 'FinishChargingBehaviour triggered!')
        self._reference.clear_destination()
        State.set(State.IDLE)


class ExecutePlanBehaviour(BehaviourBase):
    '''
    Behaviour that executes the assigned plans one ofter the other.
    '''
    def __init__(self, agent_name, agent_number, **kwargs):
        '''
        Constructor.
        :param agent_name: the agents name
        :type agent_name: string
        :param role: agents role
        :type role: Role
        '''
        super(ExecutePlanBehaviour, self).__init__(plannerPrefix=agent_name, name='execute_plan',\
                requires_execution_steps=True, **kwargs)
        self._agent_name = agent_name
        self._agent_number = agent_number

        self._client = KnowledgeBaseClient(knowledge_base_name=get_knowledge_base_name())

        self._role = None
        self._products = {}
        self._routing = None

        self._worldperception = None

        self._plans = []
        self._finished_plans = {}

        self._current_plan = None
        self._waypoint_index = 0

        self._last_carried_items = []
        self._holding_reserved_items = []

        self._pub_local_plan_status = None
        self._pub_local_task_finished = None

        self._srv_local_assigned_plans = rospy.Service('~assigned_plans', AssignedPlansSrv,\
                self._assigned_plans_request)

        rospy.Subscriber(get_team_name()+"/cancel_job", CancelJobMsg, self._cancel_job_callback,\
                queue_size=self._agent_number)

    def reset(self):
        self._role = None
        self._products = {}
        self._routing = None

        self._worldperception = None

        self._plans = []
        self._finished_plans = {}

        self._current_plan = None
        self._waypoint_index = 0

        self._last_carried_items = []
        self._holding_reserved_items = []

        self._pub_local_plan_status = None
        self._pub_local_task_finished = None

    def add_products(self, products):
        for p in products:
            self._products[p.name] = p

    def add_role(self, role):
        self._role = role

    def add_routing(self, routing):
        '''
        Adds a routing instance.
        :params routing: the routing instance
        :type routing: Routing
        '''
        self._routing = routing

    def update_worldperception(self, worldperception):
        '''
        Updates worldperception, updates item information and adjusts plan progress.
        :param worldperception: the current worldperception
        :type worldperception: WorldPerception
        '''
        self._worldperception = worldperception
        if State.get() == State.EXECUTE_PLAN:
            if self._current_plan:
                self._adjust_plan_progress(action=self._worldperception.agent.last_action,\
                        params=self._worldperception.agent.last_action_params,\
                        result=self._worldperception.agent.last_action_result)
            else:
                log(self._agent_name,'Currently no plan to adjust the progress to! num_plans='+\
                        str(len(self._plans)), 'err')
        self._last_carried_items = self._worldperception.agent.items

    # TODO not needed for now
    def _update_unreserved_items_knowledge(self):
        '''
        Updates the knowledge about unreserved items this agent holds in the knowledgebase.
        '''
        unreserved_items = []
        for i in self._last_carried_items:
            reserved_amount = 0
            for h in self._holding_reserved_items:
                if i.name == h.name:
                    reserved_amount += h.amount
            if i.amount > reserved_amount:
                unreserved_items.append(Item(name=i.name, amount=i.amount-reserved_amount))

        # delete agent specific unreserved item knowledge first
        self._client.pop((self._agent_name, 'unreserved_items', '*', '*'))

        # updated unreserved items
        for ui in unreserved_items:
            self._client.push((self._agent_name, 'unreserved_items', ui.name, str(ui.amount)))

    def _assigned_plans_request(self, request):
        '''
        Receives the currently assigned plans from the planhandler at the bidder node, updates the local
        plans and sends back the updated plan list.
        :param request: assigned plan request
        :type request: AssignedPlansSrv
        '''
        plans = unzip_plans(plans=request.plans)

        new_plans = []
        # check plan received plans and update status
        for p in plans:
            if not (p.task.job_id in self._finished_plans and\
                    p.task.task_id in self._finished_plans[p.task.job_id]):
                new_plans.append(p)

        # update current plan before
        if len(new_plans) > 0:
            # if a current plan exists
            if self._current_plan and self._current_plan.task.job_id == new_plans[0].task.job_id and\
                    self._current_plan.task.task_id == new_plans[0].task.task_id:
                new_plans[0] = self._current_plan
            # if no current plan exists
            elif not self._current_plan:
                for p in self._plans:
                    if p.task.job_id == new_plans[0].task.job_id and\
                            p.task.task_id == new_plans[0].task.task_id:
                        new_plans[0] = p
                        break

            if new_plans[0].start_step > self._worldperception.simulation_step:
                new_plans[0].start_step = self._worldperception.simulation_step
            self._move_together(plans=new_plans)

        log(self._agent_name, 'OldPlans '+str([p.task.job_id+' #'+str(p.task.task_id)+' ['+\
                str(p.start_step)+', '+str(p.start_step+p.route.duration)+']' for p in self._plans])+\
                ' NewPlans '+str([p.task.job_id+' #'+str(p.task.task_id)+' ['+str(p.start_step)+\
                ', '+str(p.start_step+p.route.duration)+']' for p in new_plans]), 'err')

        self._plans = new_plans
        return AssignedPlansSrvResponse(ack=True, plans=zip_plans(self._plans))

    def _cancel_job_callback(self, msg):
        for idx, p in enumerate(self._plans):
            if p.task.job_id == msg.job_id:
                if idx > 0:
                    if p.task.job_id not in self._finished_plans:
                        self._finished_plans[p.task.job_id] = []
                    self._finished_plans[p.task.job_id].append(p.task.task_id)
                if type(p).__name__ in [RetrieveNAssemblePlan.__name__, RetrieveNDeliverPlan.__name__]:
                    self._clear_reserved_item_knowledge(job_id=p.task.job_id , task_id=p.task.task_id)

        plan = None
        if self._current_plan:
            plan = self._current_plan
        elif len(self._plans) > 0:
            plan = self._plans[0]
        index = self._waypoint_index
        if plan and plan.task.job_id == msg.job_id:
            # skip waypoints
            pos = None
            for wp in plan.route.waypoints[index:]:
                if wp.action.action_type != StoreAction.ACTION:
                    wp.skip = True
                else:
                    pos = wp.pos

            # get carrying job items
            items = []
            remove_items = []
            for i in self._holding_reserved_items:
                if i.job_id == msg.job_id:
                    carried_item = None
                    for lci in self._last_carried_items:
                        if i.name == lci.name:
                            carried_item = lci
                            break
                    if carried_item:
                        if i.amount > carried_item.amount:
                            i.amount = carried_item.amount
                        items.append(i)
                    else:
                        remove_items.append(i)

            for ri in remove_items:
                self._holding_reserved_items.remove(ri)

            # if carrying job items store them in storage
            if len(items) > 0:
                store_wp = WayPoint()
                store_wp.store_all_job_specific_items = True
                items_after = []
                for i in plan.route.waypoints[-1].items:
                    if i.job_id != msg.job_id:
                        items_after.append(i)
                store_wp.items = items_after
                if not pos:
                    pos = self._worldperception.agent.pos
                closest_storage=self._get_closest_storage_to_store(pos=pos, items=items)
                store_wp.instance_name = closest_storage.name
                store_wp.pos = closest_storage.pos
                store_wp.action = GenericAction(action_type=StoreAction.ACTION, items=items)
                store_wp.parts_at = len(items)
                store_wp.steps_at = len(items)

                plan.route.waypoints.append(store_wp)

                # update route parameters
                self._routing.update_waypoints(start_index=index, route=plan.route)
                self._routing.update_route(route=plan.route)
                self._update_plan_timings()

    def _move_together(self, plans):
        '''
        Move the list of given plans together such that the successor plan starts the execution one step
        after the predecessor plan should be finished.
        :param plans: the plans to move together
        :return plans: Plan[]
        '''
        for idx, p in enumerate(plans[:-1]):
            plans[idx+1].start_step = p.start_step + p.route.duration + 1

    def do_step(self):
        '''
        Triggers the execution of the current plan which depends on the current waypoint.
        '''
        if len(self._plans) > 0 and (State.get() != State.EXECUTE_PLAN or not self._current_plan):
            plan = self._plans[0]
            old_start_step = plan.start_step
            plan.start_step = self._worldperception.simulation_step
            self._move_together(self._plans)
            self._current_plan = plan
            self._waypoint_index = 0
            State.set(State.EXECUTE_PLAN)
            log(self._agent_name, 'Starting new Plan: '+str(self._current_plan.task.job_id)+' task#'+\
                    str(self._current_plan.task.task_id)+' - start_step: '+\
                    str(old_start_step)+' -> '+str(self._current_plan.start_step))
        elif len(self._plans) == 0:
            log(self._agent_name, 'ExecutePlanBehaviour - No plan to execute!','err')
            return

        log(self._agent_name, 'Execute '+type(self._current_plan).__name__+': ['+\
                str(self._current_plan.task.job_id)+'(#'+str(self._current_plan.task.auction_id)+\
                ') stage#'+str(self._current_plan.task.stage_id)+'(task#'+\
                str(self._current_plan.task.task_id)+')]')

        wp = self._current_plan.route.waypoints[self._waypoint_index]

        # update this waypoint if some items arrived in storage inbetween
        if wp.action.action_type == StoreAction.ACTION and wp.store_all_job_specific_items:

                wp.store_all_job_specific_items = False

                # get carrying job items
                items = []
                for i in self._holding_reserved_items:
                    if i.job_id == self._current_plan.task.job_id:
                        items.append(i)

                if len(items) > 0:
                    wp.action.items = items
                    wp.parts_at = len(items)
                    wp.steps_at = len(items)
                else:
                    self._handle_waypoint_done()
                    return

        # check if already at waypoint
        # TODO if an agent is a waypoint -> update position
        if self._routing.pathplanner.number_of_required_steps_to_facility(\
                self._worldperception.agent.pos, wp.pos) == 0:

            if wp.action.action_type == ChargeAction.ACTION:
                # if already charged
                if self._worldperception.agent.charge >= self._role.base_battery:
                    wp.parts_at = wp.success_parts_at
                    # finalize waypoint directly
                    self._handle_waypoint_done()
                    return
                ChargeAction(agent_name=self._agent_name).send()

            elif wp.action.action_type == GatherResourceAction.ACTION:
                GatherResourceAction(agent_name=self._agent_name).send()

            elif wp.action.action_type == StoreAction.ACTION:
                # next item to store
                item = wp.action.items[wp.success_parts_at]
                StoreAction(agent_name=self._agent_name, item_name=item.name, amount=item.amount).send()

            elif wp.action.action_type == RetrieveAction.ACTION:
                item = wp.action.items[wp.success_parts_at]
                RetrieveAction(agent_name=self._agent_name, item_name=item.name, amount=item.amount)\
                        .send()

            elif wp.action.action_type == RetrieveDeliveredAction.ACTION:
                item = wp.action.items[wp.success_parts_at]
                RetrieveDeliveredAction(agent_name=self._agent_name, item_name=item.name,\
                        amount=item.amount).send()

            elif wp.action.action_type == DeliverAction.ACTION:
                DeliverAction(agent_name=self._agent_name, job_id=self._current_plan.task.job_id).send()

            elif wp.action.action_type == AssembleAction.ACTION:
                self._set_assemble_knowledge(job_id=self._current_plan.task.job_id,\
                        successor=self._current_plan.task.successor)
                AssembleAction(agent_name=self._agent_name, item=wp.action.product).send()

            elif wp.action.action_type == AssistAssembleAction.ACTION:
                if self._is_assemble_agent_ready(agent=wp.action.agent,\
                        job_id=self._current_plan.task.job_id,\
                        successor=self._current_plan.task.successor):
                    AssistAssembleAction(agent_name=self._agent_name, assemble_agent=wp.action.agent)\
                            .send()
                else:
                    # reduce steps at workshop if assembling agent already finished
                    if wp.success_parts_at > 0:
                        wp.parts_at = wp.success_parts_at
                    # send recharge action while waiting for assembling agent
                    RechargeAction(agent_name=self._agent_name).send()
            else:
                log(self._agent_name, 'Unexpected waypoint action type: '+str(wp.action.action_type)+'!',\
                        'err')
        else:
            # handle charge 0 -> send recharge action
            if self._worldperception.agent.charge == 0:
                log(self._agent_name,'Agents charge is 0 while executing plan!', 'err')
                RechargeAction(agent_name=self._agent_name).send()
                return

            # check if current waypoint is reachable without charging
            route=self._routing.get_route(start_pos=self._worldperception.agent.pos,\
                    start_charge=self._worldperception.agent.charge, end_pos=wp.pos)
            if len(route.waypoints) > 1:
                self._current_plan.route.waypoints.insert(self._waypoint_index, route.waypoints[0])
                # update subsequent waypoints and route duration
                self._routing.update_waypoints(start_index=self._waypoint_index,\
                        route=self._current_plan.route)
                self._routing.update_route(route=self._current_plan.route)
                self._update_plan_timings()
                wp = self._current_plan.route.waypoints[self._waypoint_index]

            if wp.action.action_type == GatherResourceAction.ACTION:
                GoToAction(agent_name=self._agent_name, position=wp.pos).send()
            else:
                GoToFacilityAction(agent_name=self._agent_name, facility=wp.instance_name).send()

    def _update_plan_timings(self):
        if self._current_plan and len(self._plans) > 0:
            first = self._plans[0]
            if first.task.job_id == self._current_plan.task.job_id and\
                    first.task.task_id == self._current_plan.task.task_id:
                self._plans[0] = self._current_plan
                self._move_together(self._plans)

    def _set_assemble_knowledge(self, job_id, successor):
        self._client.update(('assemble', self._agent_name, '*', '*'),\
                ('assemble', self._agent_name, job_id, str(successor)))

    def _clear_assemble_knowledge(self):
        self._client.pop(('assemble', self._agent_name, '*', '*'))

    def _is_assemble_agent_ready(self, agent, job_id, successor):
        return self._client.exists(('assemble', agent, job_id, str(successor)))

    def _clear_reserved_item_knowledge(self, job_id, task_id):
        self._client.pop((Constants.RESERVED_ITEM, '*', '*', '*', '*', job_id, str(task_id)))

    def _adjust_plan_progress(self, action, params, result):
        '''
        Checks, monitiors and adjusts the progress status at the current waypoint, chooses a new
        waypoint if the current is done and chooses a new plan if the current is done.
        :param action: last action
        :type action: string
        :param params: last action params
        :type params: string
        :param result: last action result
        :type result: string
        '''
        failed_job_status = False
        task = self._current_plan.task
        wp = self._current_plan.route.waypoints[self._waypoint_index]

        if action == GoToAction.ACTION or action == GoToAction.CONTINUE:
            wp.total_steps_to += 1
            if result == 'successful':
                wp.success_steps_to += 1

        elif action == wp.action.action_type:
            wp.total_steps_at += 1

            if action == ChargeAction.ACTION:
                if result == 'successful':
                    wp.success_steps_at += 1
                    wp.success_parts_at += 1

            elif action == GatherResourceAction.ACTION:
                if result == 'successful':
                    # gathered
                    new_item = self._get_new_item(task=task)
                    self._merge_items(amount=wp.parts_at, item_list=self._holding_reserved_items,\
                            item=new_item)

                    wp.success_steps_at += 1
                    wp.success_parts_at += new_item.amount
                    log(self._agent_name, 'Gathered '+new_item.name+' '+\
                            str(wp.success_parts_at)+'/'+str(wp.parts_at)+' at '+\
                            wp.instance_name+'!')

                    # if gathered too many items store them first
                    if wp.success_parts_at > wp.parts_at:
                        store_wp = WayPoint()
                        store_wp.items = []+wp.items
                        item = Item(name=new_item.name, amount=wp.success_parts_at - wp.parts_at)
                        closest_storage = self._get_closest_storage_to_store(pos=wp.pos, items=[item])
                        store_wp.instance_name = closest_storage.name
                        store_wp.pos = closest_storage.pos
                        store_wp.action = GenericAction(action_type=StoreAction.ACTION, items=[item])
                        store_wp.parts_at = 1
                        store_wp.steps_at = 1

                        self._current_plan.route.waypoints.insert(self._waypoint_index+1, store_wp)

                        # update route parameters
                        self._routing.update_waypoints(start_index=self._waypoint_index,\
                                route=self._current_plan.route)
                        self._routing.update_route(route=self._current_plan.route)
                        self._update_plan_timings()

                        # delete later chargingstations
                        index = -1
                        for i in range(self._waypoint_index+2, len(self._current_plan.route.waypoints)):
                            if self._current_plan.route.waypoints[i].action.action_type ==\
                                    ChargeAction.ACTION:
                                index = i;
                            else:
                                break
                        if index != -1:
                            self._current_plan.route.waypoints[self._waypoint_index+2:index+1] = []

                elif result == 'partial_successful':
                    wp.success_steps_at += 1

            elif action == AssembleAction.ACTION:
                if result == 'successful':
                    # assembled
                    lost_items = self._get_lost_items()
                    self._remove_items(remove_items=lost_items, job_id=task.job_id, task_id=task.task_id,\
                            predecessors=task.predecessors, item_list=self._holding_reserved_items)
                    lost_items_str = get_items_string(lost_items)
                    log(self._agent_name, 'Lost '+lost_items_str+' for assembling purposes!')

                    # cancel if too many items lost
                    if len(task.items) < len(lost_items):
                        failed_job_status = False

                    # produced
                    new_item = self._get_new_item(task=task)
                    self._merge_items(amount=wp.parts_at, item_list=self._holding_reserved_items,\
                            item=new_item)

                    wp.success_steps_at += 1
                    wp.success_parts_at += new_item.amount
                    log(self._agent_name, 'Assembled '+new_item.name+' -> '+\
                            str(wp.success_parts_at)+'/'+str(wp.parts_at)+' at '+\
                            wp.instance_name+'!')

                    # clear assemble coordination knowledge if ready
                    if wp.parts_at <= wp.success_parts_at:
                        self._clear_assemble_knowledge()

            elif action == AssistAssembleAction.ACTION:
                if result == 'successful':
                    # assembled
                    lost_items = self._get_lost_items()
                    self._remove_items(remove_items=lost_items, job_id=task.job_id, task_id=task.task_id,\
                            predecessors=task.predecessors, item_list=self._holding_reserved_items)
                    lost_items_str = get_items_string(lost_items)
                    log(self._agent_name, 'Lost '+lost_items_str+' for assembling purposes!')

                    # cancel if too many items lost
                    if len(task.items) < len(lost_items):
                        failed_job_status = False

                    wp.success_steps_at += 1
                    wp.success_parts_at += 1
                    log(self._agent_name, 'AssistAssembled '+wp.action.agent+' -> '+\
                            task.product.name+' -> '+str(wp.success_parts_at)+'/'+str(wp.parts_at)+\
                            ' at '+wp.instance_name+'!')

            elif action == DeliverAction.ACTION:
                if result == 'successful' or result == 'successful_partial':
                    # TODO use successful result to tell if job finished
                    # delivered
                    lost_items = self._get_lost_items()
                    self._remove_items(remove_items=lost_items, job_id=task.job_id, task_id=task.task_id,\
                            predecessors=task.predecessors, item_list=self._holding_reserved_items)
                    lost_items_str = get_items_string(lost_items)
                    log(self._agent_name, 'Delivered '+lost_items_str+' at '+wp.instance_name+'!')

                    wp.success_steps_at += 1
                    wp.success_parts_at += 1

                elif result == 'failed_job_status':
                    log(self._agent_name, 'Deliver action failed! Status of '+task.job_id+\
                            ' does not fit! Cancel '+task.job_id+' execution!', 'err')
                    failed_job_status = True

                    '''
                    # skip this waypoint
                    wp.skip = True
                    # for now we store the items in this storage
                    store_wp = WayPoint()
                    store_wp.items = []+wp.items
                    items = wp.action.items[wp.success_parts_at:]
                    closest_storage=self._get_closest_storage_to_store(pos=wp.pos, items=items)
                    store_wp.instance_name = closest_storage.name
                    store_wp.pos = closest_storage.pos
                    store_wp.action = GenericAction(action_type=StoreAction.ACTION, items=items)
                    store_wp.parts_at = len(items)
                    store_wp.steps_at = len(items)

                    self._current_plan.route.waypoints.insert(self._waypoint_index+1, store_wp)

                    # update route parameters
                    self._routing.update_waypoints(start_index=self._waypoint_index,\
                            route=self._current_plan.route)
                    self._routing.update_route(route=self._current_plan.route)
                    self._update_plan_timings()
                    '''
                else:
                    # TODO handle
                    log(self._agent_name, 'Deliver action not successful! '+result, 'err')

            elif action == StoreAction.ACTION:
                if result == 'successful':
                    # stored
                    lost_items = self._get_lost_items()
                    self._remove_items(remove_items=lost_items, job_id=task.job_id, task_id=task.task_id,\
                            predecessors=task.predecessors, item_list=self._holding_reserved_items)
                    lost_items_str = get_items_string(lost_items)
                    log(self._agent_name, 'Stored '+lost_items_str+' in '+wp.instance_name+'!')

                    wp.success_steps_at += 1
                    wp.success_parts_at += 1

                elif result == 'failed_capacity':
                    # skip this waypoint
                    wp.skip = True

                    # for now we store the items in this storage
                    store_wp = WayPoint()
                    store_wp.items = []+wp.items
                    items = wp.action.items[wp.success_parts_at:]
                    closest_storage=self._get_closest_storage_to_store(pos=wp.pos, items=items)
                    store_wp.instance_name = closest_storage.name
                    store_wp.pos = closest_storage.pos
                    store_wp.action = GenericAction(action_type=StoreAction.ACTION, items=items)
                    store_wp.parts_at = len(items)
                    store_wp.steps_at = len(items)

                    self._current_plan.route.waypoints.insert(self._waypoint_index+1, store_wp)

                    # update route parameters
                    self._routing.update_waypoints(start_index=self._waypoint_index,\
                            route=self._current_plan.route)
                    self._routing.update_route(route=self._current_plan.route)
                    self._update_plan_timings()

                elif result == 'failed_item_amount':
                    item = wp.action.items[wp.success_parts_at]
                    if item.amount == 1:
                        # skip this waypoint
                        wp.skip = True
                    else:
                        item.amount -= 1

            elif action in [RetrieveAction.ACTION, RetrieveDeliveredAction.ACTION]:
                if result == 'successful':
                    # retrieved
                    new_item = self._get_new_item(task=task)
                    self._merge_items(amount=None, item_list=self._holding_reserved_items,\
                            item=new_item)

                    wp.success_steps_at += 1
                    wp.success_parts_at += 1
                    log(self._agent_name, 'Retrieved '+new_item.name+' -> '+\
                            str(new_item.amount)+' at '+wp.instance_name+'!')

                    # clear reserved item knowledge if ready
                    if wp.parts_at <= wp.success_parts_at:
                        self._clear_reserved_item_knowledge(job_id=task.job_id , task_id=task.task_id)
                elif result == 'failed_item_amount':
                    log(self._agent_name, 'Retrieving item failed! Demanded item is not present in '+\
                            'storage. Cancel '+task.job_id+' execution!', 'err')
                    failed_job_status = True
                    self._clear_reserved_item_knowledge(job_id=task.job_id , task_id=task.task_id)
        else:
            if action == RechargeAction.ACTION and wp.action.action_type == AssistAssembleAction.ACTION\
                    and self._current_plan.task.workshop_name == self._worldperception.agent.facility:
                log(self._agent_name, 'Recharged! Waiting for assembler: '+wp.action.agent+'!', 'err')
                wp.total_steps_at += 1
            else:
                log(self._agent_name, 'Unexpected action: '+action+'!', 'err')
                if self._worldperception.agent.in_facility:
                    wp.total_steps_at += 1
                else:
                    wp.total_steps_to += 1

        # adjust publishers to current plan
        if not self._pub_local_plan_status:
            self._pub_local_plan_status = rospy.Publisher(get_auctioneer_topic_prefix(task.auctioneer)+\
                    task.job_id+'_plan_status', PlanStatusMsg, queue_size=self._agent_number, latch=True)
        if not self._pub_local_task_finished:
            self._pub_local_task_finished = rospy.Publisher(get_auctioneer_topic_prefix(task.auctioneer)+\
                    task.job_id+'_task_finished', TaskFinishedMsg, queue_size=self._agent_number,\
                    latch=True)

        if self._current_plan and self._current_plan.route:
            # send status update -> to auction
            msg = PlanStatusMsg(timestamp=get_current_timestamp(), job_id=task.job_id,\
                    task_id=task.task_id, agent=self._agent_name,\
                    start_step=self._current_plan.start_step, route=self._current_plan.route,\
                    failed_job_status=failed_job_status)

            if self._pub_local_plan_status.get_num_connections() > 0:
                self._pub_local_plan_status.publish(msg)

        # change plan list if plan done & waypoint index if waypoint done
        if wp.parts_at <= wp.success_parts_at or wp.skip:
            self._handle_waypoint_done()

    def _get_closest_storage_to_store(self, pos, items):
        volume = 0
        for i in items:
            volume += self._products[i.name].volume * i.amount

        strgs = self._worldperception.facilities.storages
        strgs_sorted = self._routing._get_euclidean_closest(instances=strgs, pos=pos, num_best=len(strgs))

        # TODO handle if no such storage exists
        for storage in strgs_sorted:
            if storage.total_capacity - storage.used_capacity >= volume:
                return storage

    def _get_lost_items(self):
        '''
        Returns all items that have been lost in the last simulation step.
        :return items: lost items
        :type items: Item[]
        '''
        items = []
        for i in self._last_carried_items:
            found = False
            for j in self._worldperception.agent.items:
                if i.name == j.name:
                    found = True
                    if i.amount > j.amount:
                        items.append(Item(name=i.name, amount=i.amount-j.amount))
                        break
            if not found:
                items.append(i)

        return items

    def _get_new_item(self, task):
        '''
        Determines the newly received item/s by comparing the old item set with the new one and sets
        the corresponding task information to this item/s (allocating).
        :params task: the task to reserve the new item for
        :type task: Task
        :return: the new item
        :type: Item
        '''
        last_item = None
        new_item = None
        for item in self._worldperception.agent.items:
            already_existed = False
            for i in self._last_carried_items:
                if item.name == i.name:
                    already_existed = True
                    if item.amount > i.amount:
                        last_item = i
                        break
            if (already_existed and last_item) or not already_existed:
                new_item = item
                break

        # allocate items
        if last_item and new_item:
            return Item(name=new_item.name, amount=new_item.amount - last_item.amount, reserved=True,\
                    job_id=task.job_id, task_id=task.task_id)
        elif new_item:
            return Item(name=new_item.name, amount=new_item.amount, reserved=True, job_id=task.job_id,\
                    task_id=task.task_id)
        else:
            log(self._agent_name, 'No new item!', 'err')
            return None

    def _merge_items(self, amount, item_list, item):
        '''
        Add the given item to the given item list such that items of the same type (name,
        task information) are merged, but a threshold of the given amount may not be exceeded.
        :params amount: the max amount of the given item in the item_list
        :type amount: uint32
        :params item_list: the item list to merge with
        :type item_list: Item[]
        :params item: the item to add to the list
        :type item: Item
        '''
        for i in item_list:
            if i.name == item.name and i.reserved == item.reserved and\
                    i.job_id == item.job_id and i.task_id == item.task_id:
                i.amount += item.amount
                if amount and i.amount > amount:
                    i.amount = amount
                return
        item_list.append(item)

    def _remove_items(self, remove_items, job_id, task_id, predecessors, item_list):

        if len(remove_items) > 0:
            found = False
            ilist = []
            for i in item_list:
                for ri in remove_items:
                    if i.name == ri.name and i.reserved and i.job_id == job_id and\
                            (len(predecessors) == 0 or i.task_id in predecessors or i.task_id == task_id):
                        found = True
                        if i.amount > ri.amount:
                            i.amount -= ri.amount
                        else:
                            ilist.append(i)

            if not found:
                log(self._agent_name, 'No item to remove! item_list: '+str(item_list)+' remove_items: '+\
                        str(remove_items), 'err')

            for i in ilist:
                item_list.remove(i)

    def _handle_waypoint_done(self):
        '''
        Chooses a new waypoint if the current is done and chooses a new plan if the current is done.
        Sends a plan done message if a plan is done and iterates the waypoint index if the current
        waypoint is done.
        '''
        # handle plan done
        if self._waypoint_index + 1 >= len(self._current_plan.route.waypoints):

            if self._current_plan.task.job_id != self._plans[0].task.job_id or\
                    self._current_plan.task.task_id != self._plans[0].task.task_id:
                log(self._agent_name, 'Current plan inconsistent with first plan list entry! '+\
                        str((self._current_plan.task.job_id, self._current_plan.task.task_id))+' != '+\
                        str((self._plans[0].task.job_id, self._plans[0].task.task_id)), 'err')

            if self._plans[0].task.job_id not in self._finished_plans:
                self._finished_plans[self._plans[0].task.job_id] = []
            self._finished_plans[self._plans[0].task.job_id].append(self._plans[0].task.task_id)

            # remove current plan from list
            del self._plans[0]

            # readjust plan timings
            if len(self._plans) > 0:
                self._plans[0].start_step = self._worldperception.simulation_step
                self._move_together(self._plans)

            # send plan finished message -> to auction and bidder
            msg = TaskFinishedMsg(timestamp=get_current_timestamp(), agent=self._agent_name,\
                    auctioneer=self._current_plan.task.auctioneer, job_id=self._current_plan.task.job_id,\
                    task_id=self._current_plan.task.task_id)

            if self._pub_local_task_finished.get_num_connections() > 0:
                self._pub_local_task_finished.publish(msg)

            # reset plan status publisher
            self._pub_local_plan_status = None
            # reset task finished publisher
            self._pub_local_task_finished = None
            # reset current plan
            self._current_plan = None
            # reset waypoint
            self._waypoint_index = 0
            # clear assemble knowledge
            self._clear_assemble_knowledge()

        # plan not done -> iterate waypoint index
        else:
            self._waypoint_index += 1
            # skip waypoints
            wp = self._current_plan.route.waypoints[self._waypoint_index]
            if wp.parts_at <= wp.success_parts_at or wp.skip:
                self._handle_waypoint_done()

    def has_work_to_do(self):
        '''
        Determines if the agent has plans to execute.
        :result: if there are plans to do True else False
        :type: bool
        '''
        return len(self._plans) > 0


class FinishExecutePlanBehaviour(BehaviourBase):
    '''
    Behaviour that finishes the plan execution and switches to the idle state.
    '''
    def __init__(self, agent_name, **kwargs):
        '''
        Constructor.
        :param agent_name: name of the agent
        :type agent_name: string
        '''
        super(FinishExecutePlanBehaviour, self).__init__(plannerPrefix=agent_name,\
                name='finish_execute_plan', requires_execution_steps=False, **kwargs)
        self._agent_name = agent_name

    def reset(self):
        pass

    def do_step(self):
        '''
        Finishes the current execute plan behaviour by setting the agents state to idle.
        '''
        log(self._agent_name, 'FinishExecutePlanBehaviour triggered!')
        State.set(State.IDLE)


class WellBuildingBehaviour(BehaviourBase):
    '''
    Behaviour that goes to the current position the well should be build or is already built.
    '''
    def __init__(self, agent_name, **kwargs):
        '''
        Constructor.
        :param agent_name: name of the agent
        :type agent_name: string
        '''
        super(WellBuildingBehaviour, self).__init__(plannerPrefix=agent_name, name='well_building',\
                requires_execution_steps=True, **kwargs)
        self._agent_name = agent_name

        self._client = KnowledgeBaseClient(knowledge_base_name=get_knowledge_base_name())

        self._worldperception = None
        self._current_well_position = None

    def reset(self):
        self._worldperception = None
        self._current_well_position = None

    def get_destination(self):
        '''
        Returns the current well position.
        :return: the current well position
        :type: Position
        '''
        return self._current_well_position

    def has_destination(self):
        '''
        Returns if there is a current well position.
        :return: if there is a current well position True else False
        :type: bool
        '''
        return self._current_well_position != None

    def clear_destination(self):
        '''
        Deletes the current well position
        '''
        self._current_well_position = None

    def update_worldperception(self, worldperception, well_knowledge):
        '''
        Updates worldperception.
        :param well_knowledge: the knowledge base tuple for the well to build
        :param worldperception: the current worldperception
        :type worldperception: WorldPerception
        '''
        self._worldperception = worldperception
        # check if theres no route to the current well position
        self._check_n_handle_failed_no_route()
        # update destination
        self.update_destination(well_knowledge)

    def _check_n_handle_failed_no_route(self):
        '''
        If there is no route to the current well position remove the well position information from
        the knowledgebase such that the well is built somewhere else.
        '''
        if State.get() == State.WELL_BUILDING and\
                (self._worldperception.agent.last_action == GoToAction.ACTION or\
                self._worldperception.agent.last_action == GoToAction.CONTINUE) and\
                self._worldperception.agent.last_action_result == 'failed_no_route':
            self._client.pop((Constants.WELL, Constants.CURRENT_WELL, '*', '*', Constants.NONEXISTENT,\
                    '*', '*'))

    def update_destination(self, well_knowledge):
        '''
        Updates the current knowledgebase well position.
        '''
        if well_knowledge:
            self._current_well_position = Position(lat=float(well_knowledge[2]),\
                    long=float(well_knowledge[3]))
        else:
            self._current_well_position = None

    def do_step(self):
        '''
        Triggers the well building behaviour. Sends a action to go to the current well position and if
        there is none it chooses a new position.
        '''
        log(self._agent_name, 'WellBuildingBehaviour triggered!')
        state = State.get()
        if state == State.IDLE or state == State.WELL_BUILDING:
            if self.has_destination() or self._is_well_to_build_existent():
                State.set(State.WELL_BUILDING)
                GoToAction(agent_name=self._agent_name, position=self._current_well_position).send()

    def _is_well_to_build_existent(self):
        self.update_destination(self._client.peek((Constants.WELL, Constants.DISMANTLED_WELL, '*',\
                '*', Constants.EXISTENT, '*', '*')))
        if not self.has_destination():
            self.update_destination(self._client.peek((Constants.WELL, Constants.CURRENT_WELL, '*', '*',\
                    '*', '*', '*')))
        return self.has_destination()


class BuildBehaviour(BehaviourBase):
    '''
    Behaviour to do the build action for creating a well on the map or building up the already existing
    well such that it generates score.
    '''
    def __init__(self, agent_name, **kwargs):
        '''
        Constructor.
        :param agent_name: name of the agent
        :type agent_name: string
        '''
        super(BuildBehaviour, self).__init__(plannerPrefix=agent_name, name='build',\
                requires_execution_steps=True, **kwargs)
        self._agent_name = agent_name

        self._client = KnowledgeBaseClient(knowledge_base_name=get_knowledge_base_name())

        self._preferred_well = None
        self._worldperception = None

    def reset(self):
        self._preferred_well = None
        self._worldperception = None

    def set_preferred_well(self, well):
        '''
        Sets the preferred welltype.
        :param well: the well instance
        :type well: Well
        '''
        self._preferred_well = well

    def update_worldperception(self, worldperception):
        '''
        Updates worldperception.
        :param worldperception: the current worldperception
        :type worldperception: WorldPerception
        '''
        self._worldperception = worldperception

    def do_step(self):
        '''
        Triggers the build behaviour. Sends a build action and sets the current state to well building.
        '''
        log(self._agent_name, 'BuildBehaviour triggered!')
        cw = self._client.peek((Constants.WELL, Constants.CURRENT_WELL, '*', '*', '*', '*', '*'))
        if (cw and cw[4] == Constants.EXISTENT) or self._client.exists((Constants.WELL,\
                Constants.DISMANTLED_WELL, '*', '*', Constants.EXISTENT, '*', '*')):
            State.set(State.WELL_BUILDING)
            BuildWellAction(agent_name=self._agent_name).send()
        elif cw and cw[4] == Constants.NONEXISTENT:
            State.set(State.WELL_BUILDING)
            BuildWellAction(agent_name=self._agent_name, welltype=self._preferred_well.name).send()


class FinishWellBuildingBehaviour(BehaviourBase):
    '''
    Behaviour that finish the building of the well. Switches to idle state.
    '''
    def __init__(self, agent_name, **kwargs):
        '''
        Constructor.
        :param agent_name: name of the agent
        :type agent_name: string
        '''
        super(FinishWellBuildingBehaviour, self).__init__(plannerPrefix=agent_name,\
                name='finish_well_building', requires_execution_steps=False, **kwargs)
        self._agent_name = agent_name

    def reset(self):
        pass

    def do_step(self):
        '''
        Triggers the execution of this behaviour. Finishes the well building behaviour by deleting the
        current well position from the reference behaviour and sets the current state to idle.
        '''
        log(self._agent_name, 'FinishWellBuildingBehaviour triggered!')
        State.set(State.IDLE)


class WellDismantlingBehaviour(BehaviourBase):
    """
    Behaviour that determines a well to be dismantled and goes there.
    """
    def __init__(self, agent_name, **kwargs):
        '''
        Constructor.
        :param agent_name: name of the agent
        :type agent_name: string
        '''
        super(WellDismantlingBehaviour, self).__init__(plannerPrefix=agent_name, name='well_dismantling',\
                requires_execution_steps=True, **kwargs)
        self._agent_name = agent_name

        self._client = KnowledgeBaseClient(knowledge_base_name=get_knowledge_base_name())

        self._worldperception = None  # type: WorldPerception
        self._routing = None  # type: Routing
        self._enemy_well = None  # type: Well
        self._current_enemy_well_position = None  # type: Position

    def reset(self):
        self._worldperception = None  # type: WorldPerception
        self._routing = None  # type: Routing
        self._enemy_well = None  # type: Well
        self._current_enemy_well_position = None  # type: Position

    def add_routing(self, routing):
        """
        Adds a routing instance to this behaviour.
        :param routing:
        """
        self._routing = routing

    def get_destination(self):
        '''
        Returns the current well position.
        :return: the current well position
        :type: Position
        '''
        return self._current_enemy_well_position

    def has_destination(self):
        '''
        Returns if there is a current well position.
        :return: if there is a current well position True else False
        :type: bool
        '''
        return self._current_enemy_well_position is not None

    def clear_destination(self):
        '''
        Deletes the current well position
        '''
        self._current_enemy_well_position = None

    def update_worldperception(self, worldperception):
        '''
        Updates worldperception.
        :param worldperception: the current worldperception
        :type worldperception: WorldPerception
        '''
        self._worldperception = worldperception

    def update_destination(self):
        """
        Updates the destination by retrieving the current well to dismantle from the knowledge base.
        :return:
        """
        # the current well to dismantle has already been chosen, so take this one:
        current_dismantle_well = self._client.peek((Constants.WELL, Constants.CURRENT_DISMANTLE_WELL,\
                '*', '*', '*', '*', '*'))
        if current_dismantle_well:
            self._enemy_well = Well(name=current_dismantle_well[5],
                                    pos=Position(lat=float(current_dismantle_well[2]),
                                                 long=float(current_dismantle_well[3])),
                                    integrity=int(current_dismantle_well[6]))

            # update position
            self._current_enemy_well_position = self._enemy_well.pos
        else:  # no enemy well chosen yet
            self._enemy_well = None
            self._current_enemy_well_position = None

    def _choose_well_to_dismantle(self):
        """
        Checks the discovered enemy wells and chooses the closest one, if there are multiple.
        Should only be called when the behaviour is triggered.
        :return:
        """
        enemy_wells = self._get_enemy_wells()
        # get all enemy wells with integrity greater 0
        real_enemy_wells_temp = [w for w in enemy_wells if w.integrity > 0]

        if real_enemy_wells_temp:
            real_enemy_wells = []
            for r in real_enemy_wells_temp:
                if self._routing.pathplanner.number_of_required_steps_to_facility(\
                        start=self._worldperception.agent.pos, destination=r.pos) >= 0:
                    real_enemy_wells.append(r)
        else:
            real_enemy_wells = real_enemy_wells_temp


        if not real_enemy_wells or len(real_enemy_wells) == 0:
            self._enemy_well = None
            return
        elif len(real_enemy_wells) == 1:
            self._enemy_well = real_enemy_wells[0]
        else:  # choose closest well to current position
            if self._routing:
                self._enemy_well, _ = self._routing.get_real_closest(instances=real_enemy_wells,
                                                                    pos=self._worldperception.agent.pos)
        # update knowledge base
        ewk = self._client.peek(pattern=(Constants.WELL, Constants.ENEMY_WELL, '*', '*',\
                Constants.EXISTENT, self._enemy_well.name, '*'))
        if ewk:
            self._client.update(pattern=ewk,
                    new=(Constants.WELL, Constants.CURRENT_DISMANTLE_WELL, ewk[2], ewk[3], ewk[4],
                    self._enemy_well.name, ewk[6]))

    def _get_enemy_wells(self):
        """
        Create Well objects from all enemy wells saved in knowledge base.
        :return: list of all known enemy wells
        """
        enemy_wells = []
        enemy_well_knowledge = self._client.all((Constants.WELL, Constants.ENEMY_WELL, '*', '*',\
                Constants.EXISTENT, '*', '*'))
        for w in enemy_well_knowledge:
            enemy_wells.append(Well(name=w[5], pos=Position(lat=float(w[2]), long=float(w[3])),\
                    integrity=int(w[6])))
        return enemy_wells

    def do_step(self):
        '''
        Triggers the well building behaviour. Sends a action to go to the current well position and if
        there is none it chooses a new position.
        '''
        log(self._agent_name, 'WellDismantlingBehaviour triggered!')
        state = State.get()
        if state == State.IDLE or state == State.WELL_DISMANTLING:
            self.update_destination()
            if not self.has_destination():
                self._choose_well_to_dismantle()
            if self.has_destination():
                State.set(State.WELL_DISMANTLING)
                GoToAction(agent_name=self._agent_name, position=self._current_enemy_well_position).send()


class DismantleBehaviour(BehaviourBase):
    """
    Behaviour that carries out the dismantle action for dismantling an already discovered and chosen
    enemy well.
    """
    def __init__(self, agent_name, **kwargs):
        """
        Constructor.
        :param agent_name: name of the agent
        :type agent_name: string
        """
        super(DismantleBehaviour, self).__init__(plannerPrefix=agent_name, name='dismantle',
                                                 requires_execution_steps=True, **kwargs)
        self._agent_name = agent_name

        self._client = KnowledgeBaseClient(knowledge_base_name=get_knowledge_base_name())

        self._worldperception = None

    def reset(self):
        self._worldperception = None

    def update_worldperception(self, worldperception):
        """
        Updates worldperception.
        :param worldperception: the current worldperception
        :type worldperception: WorldPerception
        """
        self._worldperception = worldperception

    def do_step(self):
        """
        Triggers the dismantle behaviour. Sends a build action and sets the current state to well
        building.
        """
        log(self._agent_name, 'DismantleBehaviour triggered!')
        if self._client.exists((Constants.WELL, Constants.CURRENT_DISMANTLE_WELL,\
                '*', '*', '*', '*', '*')):
            State.set(State.WELL_DISMANTLING)
            DismantleWellAction(agent_name=self._agent_name).send()


class FinishWellDismantlingBehaviour(BehaviourBase):
    """
    Behaviour that finish the building of the well. Switches to idle state.
    """
    def __init__(self, agent_name, **kwargs):
        '''
        Constructor.
        :param agent_name: name of the agent
        :type agent_name: string
        '''
        super(FinishWellDismantlingBehaviour, self).__init__(plannerPrefix=agent_name,\
                name='finish_well_dismantling', requires_execution_steps=False, **kwargs)
        self._agent_name = agent_name

    def reset(self):
        pass

    def do_step(self):
        '''
        Triggers the execution of this behaviour. Finishes the well building behaviour by deleting the
        current well position from the reference behaviour and sets the current state to idle.
        '''
        log(self._agent_name, 'FinishWellDismantlingBehaviour triggered!')
        State.set(State.IDLE)

class DefaultBehaviour(BehaviourBase):

    def __init__(self, agent_name, **kwargs):
        '''
        Constructor.
        :param agent_name: the agents name
        :type agent_name: string
        '''
        super(DefaultBehaviour, self).__init__(plannerPrefix=agent_name, name='default',\
                requires_execution_steps=True, **kwargs)
        self._agent_name = agent_name

        self._client = KnowledgeBaseClient(knowledge_base_name=get_knowledge_base_name())

        self._worldperception = None
        self._current_destination = None

    def reset(self):
        self._worldperception = None
        self._current_destination = None

    def get_destination(self):
        return self._current_destination

    def has_destination(self):
        return self._current_destination != None

    def clear_destination(self):
        self._current_destination = None

    def update_worldperception(self, worldperception):
        '''
        Updates worldperception.
        :param worldperception: the current worldperception
        :type worldperception: WorldPerception
        '''
        self._worldperception = worldperception

    def do_step(self):
        '''
        Triggers the execution of this behaviour. Sends action to go to the current destination and if
        there is none, it chooses a random one.
        '''
        log(self._agent_name, 'DefaultBehaviour triggered!', 'err')
        state = State.get()
        if state == State.IDLE:
            if not self._current_destination:
                self._current_destination = self._get_next_destination()
            if self._current_destination:
                GoToAction(agent_name=self._agent_name, position=self._current_destination).send()

    def _get_next_destination(self):
        '''
        Chooses a random resource node position and if there is no resource node yet ->
        return a random charging station position.
        :return: resource node position
        :type: Position
        '''
        #values = ['patrol_wells']
        values = ['patrol_wells', 'patrol_resource_nodes']
        if random.choice(values) == 'patrol_wells':
            built_wells = self._client.all((Constants.WELL, Constants.WELL_DONE, '*', '*', '*', '*', '*'))
            if built_wells and len(built_wells) > 0:
                chosen_well = random.choice(built_wells)
                return Position(lat=float(chosen_well[2]), long=float(chosen_well[3]))

        if len(self._worldperception.facilities.resources) > 0:
            return random.choice(self._worldperception.facilities.resources).pos
        else:
            return random.choice(self._worldperception.facilities.charging_stations).pos


class FinishDefaultBehaviour(BehaviourBase):
    '''
    Finishes the default behaviour.
    '''
    def __init__(self, agent_name, reference, **kwargs):
        '''
        Constructor.
        :param agent_name: the agents name
        :type agent_name: string
        :param reference: reference which contains the current grid point
        '''
        super(FinishDefaultBehaviour, self).__init__(plannerPrefix=agent_name, name='finish_default',\
                requires_execution_steps=False, **kwargs)
        self._agent_name = agent_name
        self._reference = reference

    def reset(self):
        pass

    def do_step(self):
        '''
        Triggers the execution of this behaviour. Finishes the default behaviour by deleting the
        current destination from the reference behaviour.
        '''
        log(self._agent_name, 'FinishDefaultBehaviour triggered!', 'err')
        self._reference.clear_destination()
