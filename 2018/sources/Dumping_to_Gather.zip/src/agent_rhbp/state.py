class State(object):
    '''
    This class is used for storing as well as switching the agents current state.
    '''
    # different agent states
    IDLE = 'IDLE'
    EXPLORATION = 'EXPLORE'
    CHARGING = 'CHARGE'
    EXECUTE_PLAN = 'EXECUTE_PLAN'
    GATHER_RESOURCES = 'GATHER_RESOURCES'
    WELL_BUILDING = 'WELL_BUILDING'
    WELL_DISMANTLING = 'WELL_DISMANTLING'
    # current state
    _current_state = IDLE

    @staticmethod
    def get():
        '''
        Returns the current state.
        :return: current state
        :type: string
        '''
        return State._current_state

    @staticmethod
    def set(new_state):
        '''
        Sets the current state.
        :param new_state: the new state
        :type: string
        '''
        State._current_state = new_state
