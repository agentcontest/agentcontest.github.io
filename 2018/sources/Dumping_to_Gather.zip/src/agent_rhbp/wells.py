from behaviour_components.activators import BooleanActivator, ThresholdActivator
from behaviour_components.conditions import Condition, Negation, Disjunction
from behaviour_components.condition_elements import Effect
from behaviour_components.goals import GoalBase

from behaviours import WellBuildingBehaviour, BuildBehaviour, FinishWellBuildingBehaviour
from sensors import DestinationDistanceSensor, WellBuildingSensor, WellCompletelyBuiltSensor,\
        FinishWellBuildingSensor

from actions import BuildWellAction

from knowledge_base.knowledge_base_client import KnowledgeBaseClient

from knowledge_base.update_handler import KnowledgeBaseFactCache

from agent_mutual.constants import Constants
from agent_mutual.statistics import Stats
from agent_mutual.agent_utils import get_knowledge_base_name, log, get_number, get_agent_number

from agent_auctioning.routing import Routing

from mac_utils.graphhopper import PathPlanner

from mac_ros_bridge.msg import Position
from mac_agent.msg import WorldPerception

import copy


class WellBehaviourGraph(object):
    '''
    This class establishes the rhbp behaviour graph for well building purposes. When not in execution plan
    state or exploration state this is used to build wells which is necessary for generating score points.
    '''
    def __init__(self, agent_name):
        '''
        Constructor.
        :param agent_name: the agents name
        :type agent_name: string
        :param grid: the exploration grid
        :type grid: ExplorationGrid
        '''
        self._agent_name = agent_name

        self.exploration_grid = None
        self.facilities = None
        self._possible_well_points_by_distance = None  # type: list[tuple[Position, float]]
        self._not_reachable_well_points = []  # type: list[tuple[Position, float]]

        self._client = KnowledgeBaseClient(knowledge_base_name=get_knowledge_base_name())

        self._kb_well_cache = KnowledgeBaseFactCache(pattern=(Constants.WELL, '*', '*', '*', '*', '*', '*'),
                                                     knowledge_base_name=get_knowledge_base_name())

        self._routing = None  # type: Routing

        self._well_recipes = None
        self._preferred_well = None
        self.well_knowledge_to_build_next = None

        self._build_failed = 0

        # behaviours
        self._well_building_behaviour = WellBuildingBehaviour(agent_name=self._agent_name)
        self._build_behaviour = BuildBehaviour(agent_name=self._agent_name,\
                reference=self._well_building_behaviour)
        self._finish_well_building_behaviour = FinishWellBuildingBehaviour(agent_name=self._agent_name)

        # sensors
        self._well_building_sensor = WellBuildingSensor(agent_name=self._agent_name)
        self._well_distance_sensor = DestinationDistanceSensor(name='well_distance',\
                agent_name=self._agent_name, reference=self._well_building_behaviour)
        self._well_completely_built_sensor = WellCompletelyBuiltSensor(agent_name=self._agent_name)
        self._finish_well_building_sensor = FinishWellBuildingSensor(agent_name=self._agent_name)

        # effects
        self._well_building_behaviour.add_effect(effect=Effect(\
                sensor_name=self._well_distance_sensor.name, indicator=-1.0, sensor_type=float))
        self._build_behaviour.add_effect(effect=Effect(\
                sensor_name=self._well_completely_built_sensor.name, indicator=1.0, sensor_type=bool))
        self._finish_well_building_behaviour.add_effect(effect=Effect(\
                sensor_name=self._finish_well_building_sensor.name, indicator=-1.0, sensor_type=bool))

        # conditions
        self._well_building_condition = Condition(sensor=self._well_building_sensor,\
                activator=BooleanActivator(desiredValue=True))
        self._at_well_condition = Condition(sensor=self._well_distance_sensor,\
                activator=ThresholdActivator(thresholdValue=0, isMinimum=False))
        self._well_completely_built_condition = Condition(sensor=self._well_completely_built_sensor,\
                activator=BooleanActivator(desiredValue=True))
        self._finish_well_building_condition = Condition(sensor=self._finish_well_building_sensor,\
                activator=BooleanActivator(desiredValue=True))

        self._well_building_behaviour.add_precondition(self._well_building_condition)
        self._well_building_behaviour.add_precondition(Negation(self._at_well_condition))

        self._build_behaviour.add_precondition(self._well_building_condition)
        self._build_behaviour.add_precondition(self._at_well_condition)
        self._build_behaviour.add_precondition(Negation(self._well_completely_built_condition))

        self._finish_well_building_behaviour.add_precondition(Disjunction(\
                self._well_completely_built_condition, Negation(self._well_building_condition)))
        self._finish_well_building_behaviour.add_precondition(self._finish_well_building_condition)

        # goal
        self._well_building_goal = GoalBase(name='well_building_goal', permanent=True,\
                plannerPrefix=self._agent_name, conditions=\
                [Negation(self._finish_well_building_condition)])

    def reset(self):
        self.exploration_grid = None
        self.facilities = None
        self._possible_well_points_by_distance = None
        self._not_reachable_well_points = []

        self._build_failed = 0

        self._routing = None

        self._well_recipes = None
        self._preferred_well = None
        self.well_knowledge_to_build_next = None

        self._well_building_behaviour.reset()
        self._build_behaviour.reset()
        self._finish_well_building_behaviour.reset()

        self._well_building_sensor.reset()
        self._well_distance_sensor.reset()
        self._well_completely_built_sensor.reset()
        self._finish_well_building_sensor.reset()

    def prepare(self, msg, routing, grid):
        '''
        Hands over the sim-start message and an routing instance.
        :param msg: the sim start message
        :type msg: SimStart
        :param routing: the routing instance
        :type routing: Routing
        '''
        self.exploration_grid = grid
        self._well_recipes = msg.wells
        self._preferred_well = self._choose_preferred_well_type(wells=self._well_recipes)
        self._build_behaviour.set_preferred_well(well=self._preferred_well)
        self._well_building_sensor.set_preferred_well(well=self._preferred_well)

        self._routing = routing
        self._well_distance_sensor.add_routing(self._routing)

    def _choose_preferred_well_type(self, wells):
        '''
        Chooses the preferred welltype that should be build.
        :param wells: list of possible wells
        :type wells: Well[]
        :return: the chosen well
        :rtype: Well
        '''
        well = None
        highest_value = 0.0
        for w in wells:
            value = self._get_well_value(well=w)
            if highest_value < value:
                well = w
                highest_value = value
        return well

    def _get_well_value(self, well):
        '''
        Value function that generates some value for every well based on well efficiency and
        integrity difference.
        :param well: the well to consider
        :type well: Well
        :return: the value
        :type: float
        '''
        # TODO mhh which one do we choose?
        value = 'efficient'
        if value == 'cheapest':
            return 100000.0/float(well.cost)
        elif value == 'efficient':
            return well.efficiency
        elif value == 'integrity':
            return well.integrity
        else:
            integrity_minuend = 100
            return well.efficiency * (integrity_minuend - (well.integrity - well.initial_integrity))

    def add_precondition(self, condition):
        '''
        Adds the given precondition to all behaviours but the finish behaviour.
        :param condition: the precondition
        :type condition: Condition
        '''
        self._well_building_behaviour.add_precondition(condition)
        self._build_behaviour.add_precondition(condition)

    def update_worldperception(self, worldperception):
        '''
        Updates worldperception.
        :param worldperception: the current worldperception
        :type worldperception: WorldPerception
        '''
        if worldperception.agent.last_action == BuildWellAction.ACTION:
            if worldperception.agent.last_action_result == 'failed_location':
                log(self._agent_name, 'Action build'+str(worldperception.agent.last_action_params)+\
                        ' failed: failed location', 'err')
                if len(worldperception.agent.last_action_params) > 0:
                    self._build_failed += 1
                    if self._build_failed > 5:
                        self._build_failed = 0
                        wk=self._client.peek((Constants.WELL,Constants.CURRENT_WELL,'*','*','*','*','*'))
                        if wk:
                            self._client.update(wk,
                                    (Constants.WELL, Constants.WELL_DONE, wk[2], wk[3], wk[4],\
                                    wk[5], wk[6]))
            else:
                self._build_failed = 0

        # update info about all own wells
        self._update_own_well_knowledge(own_wells=worldperception.facilities.wells)
        self._update_own_completely_dismantled_well(worldperception=worldperception)
        self._update_enemy_well_knowledge(enemy_wells=worldperception.facilities.enemy_wells)
        self._handle_well_created(agent=worldperception.agent, wells=worldperception.facilities.wells)
        self._handle_well_built_up_completely(agent=worldperception.agent,\
                wells=worldperception.facilities.wells)

        # based on current well info, update decision which well to (re-)build next
        self._update_well_to_build_next()

        # update relevant information within behaviours
        self._well_building_behaviour.update_worldperception(worldperception,\
                self.well_knowledge_to_build_next)
        self._build_behaviour.update_worldperception(worldperception)

        # update relevant information within sensors
        self._well_building_sensor.update_worldperception(worldperception)
        self._well_distance_sensor.update_worldperception(worldperception)
        self._well_completely_built_sensor.update_worldperception(worldperception,\
                self.well_knowledge_to_build_next)
        self._finish_well_building_sensor.update_worldperception(worldperception)

        # choose next well position
        # only last agent updates well position
        if get_number(self._agent_name) == get_agent_number():
            # initialize
            if not self._possible_well_points_by_distance:
                self.facilities = worldperception.facilities
                self._possible_well_points_by_distance = self._get_possible_well_points_and_distance()
                log(self._agent_name, 'calculated ' + str(len(self._possible_well_points_by_distance))
                    + ' possible well positions.')
            self._remove_not_reachable_well_points()
            self._update_current_well(agent_pos=worldperception.agent.pos)

        if get_number(self._agent_name) % (get_agent_number() / 2) == 0:
            self._update_general_well_information()

    def _update_own_well_knowledge(self, own_wells):
        """
        Updates own wells if they were built up or dismantled. Newly created wells, completely built up
        wells and completely destroyed wells will be handled separately.
        :param own_wells: wells of this team
        :type own_wells: Well[]
        """
        for w in own_wells:
            # if done well was dismantled, turn into dismantled well
            if self._kb_well_cache.does_sub_fact_exist(pattern=(Constants.WELL, Constants.WELL_DONE, str(w.pos.lat),
                                                                str(w.pos.long), Constants.EXISTENT, str(w.name), '*'))\
                    and w.integrity < self._get_max_integrity(well_type=w.type):
                self._client.update(pattern=(Constants.WELL, Constants.WELL_DONE, str(w.pos.lat),
                        str(w.pos.long), Constants.EXISTENT, str(w.name), '*'),
                        new=(Constants.WELL, Constants.DISMANTLED_WELL, str(w.pos.lat),
                        str(w.pos.long), Constants.EXISTENT, str(w.name), str(w.integrity)))
            # if dismantled well was built up or further dismantled, update integrity
            elif self._kb_well_cache.does_sub_fact_exist(pattern=(Constants.WELL, Constants.DISMANTLED_WELL,
                                                                  str(w.pos.lat), str(w.pos.long),
                                                                  Constants.EXISTENT, str(w.name), '*')):
                self._client.update(pattern=(Constants.WELL, Constants.DISMANTLED_WELL, str(w.pos.lat),
                                             str(w.pos.long), Constants.EXISTENT, str(w.name), '*'),
                                    new=(Constants.WELL, Constants.DISMANTLED_WELL, str(w.pos.lat),
                                         str(w.pos.long), Constants.EXISTENT, str(w.name), str(w.integrity)))
            # if current well was built up or dismantled, update integrity:
            else:
                current_wk = self._kb_well_cache.get_matching_sub_fact(pattern=(Constants.WELL, Constants.CURRENT_WELL,
                                                                                str(w.pos.lat), str(w.pos.long),
                                                                                Constants.EXISTENT, str(w.name), '*'))
                if current_wk and w.integrity < int(current_wk[6]):  # current well was dismantled
                    self._client.update(pattern=current_wk, new=(Constants.WELL, Constants.DISMANTLED_WELL,
                                                                 current_wk[2], current_wk[3], current_wk[4],
                                                                 current_wk[5], str(w.integrity)))
                elif current_wk:  # current well was built up
                    self._client.update(pattern=current_wk,
                                        new=(Constants.WELL, Constants.CURRENT_WELL, current_wk[2], current_wk[3],
                                             current_wk[4], current_wk[5], str(w.integrity)))

    def _update_own_completely_dismantled_well(self, worldperception):
        """
        If an own well was completely dismantled, it is not visible in own wells anymore. Hence, if an agent is at
        a position where a well should be, but it's not there anymore, it must be completely dismantled.
        :param worldperception:
        :type worldperception: WorldPerception
        :return:
        """
        at_well_knowledge = self._kb_well_cache.get_matching_sub_fact((Constants.WELL, Constants.CURRENT_WELL,
                                                                       str(worldperception.agent.pos.lat),
                                                                       str(worldperception.agent.pos.long),
                                                                       Constants.EXISTENT, '*', '*'))
        if not at_well_knowledge:
            at_well_knowledge = self._kb_well_cache.get_matching_sub_fact((Constants.WELL, Constants.WELL_DONE,
                                                                           str(worldperception.agent.pos.lat),
                                                                           str(worldperception.agent.pos.long),
                                                                           Constants.EXISTENT, '*', '*'))
        if not at_well_knowledge:
            at_well_knowledge = self._kb_well_cache.get_matching_sub_fact((Constants.WELL, Constants.DISMANTLED_WELL,
                                                                           str(worldperception.agent.pos.lat),
                                                                           str(worldperception.agent.pos.long),
                                                                           Constants.EXISTENT, '*', '*'))
        # if there should be an own well at the agent's current location, but is not,
        # it was completely destroyed
        if at_well_knowledge and not worldperception.agent.in_facility:
            log(self._agent_name, 'own well was completely destroyed and will be removed from kb')
            self._client.update(pattern=at_well_knowledge, new=(Constants.WELL,\
                    Constants.DISMANTLED_WELL, at_well_knowledge[2], at_well_knowledge[3],
                    Constants.NONEXISTENT, at_well_knowledge[5], '0'))

    def _update_enemy_well_knowledge(self, enemy_wells):
        """
        Updates the information about enemy wells in the knowledge base.
        :param enemy_wells: wells of enemy team
        :type enemy_wells: Well[]
        """
        for w in enemy_wells:
            # update enemy well that is currently being dismantled
            if self._kb_well_cache.does_sub_fact_exist(pattern=(Constants.WELL, Constants.CURRENT_DISMANTLE_WELL, \
                                                                str(w.pos.lat), str(w.pos.long), Constants.EXISTENT, str(w.name), '*')):
                self._client.update(pattern=(Constants.WELL, Constants.CURRENT_DISMANTLE_WELL,\
                        str(w.pos.lat), str(w.pos.long), Constants.EXISTENT, str(w.name), '*'),\
                        new=(Constants.WELL, Constants.CURRENT_DISMANTLE_WELL, str(w.pos.lat),\
                        str(w.pos.long), Constants.EXISTENT, str(w.name), str(w.integrity)))
            # if enemy well was completely destroyed, but rebuilt again:
            elif self._kb_well_cache.does_sub_fact_exist(pattern=(Constants.WELL, Constants.ENEMY_WELL, str(w.pos.lat), \
                                                                  str(w.pos.long), Constants.NONEXISTENT, '*', '0')):
                self._client.update(pattern=(Constants.WELL, Constants.ENEMY_WELL, str(w.pos.lat),\
                        str(w.pos.long), Constants.NONEXISTENT, '*', '0'),\
                        new=(Constants.WELL, Constants.ENEMY_WELL, str(w.pos.lat), str(w.pos.long),\
                        Constants.EXISTENT, w.name, str(w.integrity)))
            else:
                self._client.update(pattern=(Constants.WELL, Constants.ENEMY_WELL, str(w.pos.lat),\
                        str(w.pos.long), Constants.EXISTENT, str(w.name), '*'),
                        new=(Constants.WELL, Constants.ENEMY_WELL, str(w.pos.lat), str(w.pos.long),
                        Constants.EXISTENT, str(w.name), str(w.integrity)))

    def _update_well_to_build_next(self):
        """
        Chooses whether to build a new well, build up an existing well or build up a formerly dismantled well
        and saves the relevant well knowledge internally, so it can be passed to behaviours and sensors.
        Should be called in every world perception step.
        """
        dismantled_well_knowledge =  self._kb_well_cache.get_matching_sub_fact((Constants.WELL, Constants.DISMANTLED_WELL,
                                                                          '*', '*', Constants.EXISTENT, '*', '*'))
        existent_well_knowledge = self._kb_well_cache.get_matching_sub_fact((Constants.WELL, Constants.CURRENT_WELL, '*',
                                                                        '*', Constants.EXISTENT, '*', '*'))
        new_well_knowledge = self._kb_well_cache.get_matching_sub_fact((Constants.WELL, Constants.CURRENT_WELL, '*', '*',
                                                                        Constants.NONEXISTENT, '*', '*'))
        if dismantled_well_knowledge:
            self.well_knowledge_to_build_next = dismantled_well_knowledge
        elif existent_well_knowledge:
            self.well_knowledge_to_build_next = existent_well_knowledge
        else:
            self.well_knowledge_to_build_next = new_well_knowledge

    def _handle_well_created(self, agent, wells):
        '''
        Handles the situation when a new well has been created and updated the corresponding knowledge.
        :param agent: the agent
        :type agent: Agent
        :param wells: the possible wells
        :type wells: Well[]
        '''
        if agent.last_action == BuildWellAction.ACTION and len(agent.last_action_params) > 0 and\
                agent.last_action_result == 'successful':
            wk = self._kb_well_cache.get_matching_sub_fact((Constants.WELL, Constants.CURRENT_WELL, '*', '*', \
                                                            Constants.NONEXISTENT, '*', '*'))
            if wk:
                # get newly created wellname & integrity to reach
                well_name = agent.facility
                # max_integrity = self._get_max_integrity(well_name=well_name, wells=wells)
                integrity = self._get_current_integrity(well_name=well_name, wells=wells)

                # switch well to existent
                self._client.update(wk, (Constants.WELL, Constants.CURRENT_WELL, str(agent.pos.lat),\
                        str(agent.pos.long), Constants.EXISTENT, well_name, str(integrity)))
                log(self._agent_name, 'well ' + well_name + ' was created and switched to existent in KB.')

                Stats.log_well_built(well_name=well_name, cost=self._preferred_well.cost)

    def _get_max_integrity(self, well_type):
        '''
        Returns maximal integrity of the given well.
        :param well_type: the wells type
        :type well_type: string
        :return: the maximum integrity that the given well type can reach
        :rtype: int
        '''
        for w in self._well_recipes:
            # TODO: why is type inside name tag again??
            if w.name == well_type:
                return w.integrity

    def _get_well_type(self, well_name, wells):
        """
        Finds the well name in the given list of wells and returns its type.
        :param well_name: the well name
        :param wells: the list of wells
        :return: the type
        """
        for w in wells:
            if w.name == well_name:
                return w.type

    def _handle_well_built_up_completely(self, agent, wells):
        '''
        Handles the situation when a well has completely been completely built up in the last simulation
        step and updated the corresponding knowledge.
        :param agent: the agent
        :type agent: Agent
        :param wells: the possible wells
        :type wells: Well[]
        '''
        if agent.last_action == BuildWellAction.ACTION and len(agent.last_action_params) == 0 and\
                agent.last_action_result == 'successful':
            # well knowledge if current well was just built up
            wk = self._kb_well_cache.get_matching_sub_fact((Constants.WELL, Constants.CURRENT_WELL, '*', '*',
                                                            Constants.EXISTENT, '*', '*'))
                                                            #'*', '*', '*'))
            # TODO
            if not wk:  # well knowledge if dismantled well was just built up
                wk = self._kb_well_cache.get_matching_sub_fact((Constants.WELL, Constants.DISMANTLED_WELL, '*', '*',
                                                                Constants.EXISTENT, '*', '*'))
                                                                #'*', '*', '*'))
            well_name = agent.facility
            current_integrity = self._get_current_integrity(well_name=well_name, wells=wells)
            if wk:
                if wk[5] == well_name and self._get_max_integrity(well_type=self._get_well_type(well_name, wells)) \
                        <= current_integrity:
                    self._client.update(wk,
                            (Constants.WELL, Constants.WELL_DONE, wk[2], wk[3], wk[4],\
                            wk[5], str(current_integrity)))
                    self._client.update(wk,
                            (Constants.WELL, Constants.WELL_DONE, wk[2], wk[3], str(agent.pos.lat),\
                            str(agent.pos.long), str(current_integrity)))
                    log(self._agent_name, ' well with name ' + well_name + ', formerly ' + wk[1] +
                        ', was built up completely and switched to well_done.')
            # TODO: if dismantled well was built up, remember as once dismantled well,
            # because it is already discovered?

    def _get_current_integrity(self, well_name, wells):
        '''
        Returns the integrity of the given well.
        :param well_name: the wells type
        :type well_name: string
        :param wells: the possible wells
        :type wells: Well[]
        '''
        for w in wells:
            if w.name == well_name:
                return w.integrity

    def _update_current_well(self, agent_pos):
        """
        Determines a new position for the next current well to be built if there is none determined yet or
        if there is an enemy well at the same position.
        """
        # check if current nonexistent well is at same position as enemy well:
        cwk = self._kb_well_cache.get_matching_sub_fact((Constants.WELL, Constants.CURRENT_WELL, '*', '*',
                                                         '*', '*', '*'))
        if cwk:
            # check if nonexistent well is planned at same position as enemy well:
            if cwk[4] == Constants.NONEXISTENT:
                cwk_pos = Position(lat=float(cwk[2]), long=float(cwk[3]))
                if not self._at_enemy_well_position(cwk_pos):
                    return
                else:
                    log(self._agent_name, 'current nonexistent well is at same position as enemy well '
                                          'and will be replaced: ' + str(cwk[2]) + ', ' + str(cwk[3]))
            else:  # if well is existent, no need to change anything
                return
        else:
            log(self._agent_name, 'there is no current well. New position will be chosen.')

        # if there is no current well, get new position:
        next_well_pos = self._get_next_well_pos(agent_pos=agent_pos)
        if next_well_pos:
            self._client.update(pattern=(Constants.WELL, Constants.CURRENT_WELL, '*', '*', '*', '*', '*'),
                                new=(Constants.WELL, Constants.CURRENT_WELL, str(next_well_pos.lat),
                                     str(next_well_pos.long), Constants.NONEXISTENT, '', ''))
            log(self._agent_name, 'chose new well position: ' + str(next_well_pos.lat) + ', ' + str(next_well_pos.long))
            if self._possible_well_points_by_distance:
                log(self._agent_name,  'Left number of possible well positions: '
                    + str(len(self._possible_well_points_by_distance)))
            else:
                log(self._agent_name, 'No well positions left.')

    def _get_next_well_pos(self, agent_pos):
        """
        Retrieves the next well position from the ordered list of possible well positions, given that there
        is no enemy well at the same position. Returns None if there are no well positions left.
        :return: a position for the next well or None, if no position can be found
        :rtype: Position
        """
        # make sure there are well positions left:
        if not self._possible_well_points_by_distance or len(self._possible_well_points_by_distance) == 0:
            log(self._agent_name, 'no more possible well positions left!')
            return None

        next_well_tuple = self._possible_well_points_by_distance.pop(0)

        # make sure there is no enemy well at same position:
        if self._at_enemy_well_position(next_well_tuple[0]):
            log(self._agent_name, 'well position will not be chosen, because it is at same position as enemy well: '
                + str(next_well_tuple[0].lat) + ', ' + str(next_well_tuple[0].long))
            return self._get_next_well_pos(agent_pos=agent_pos)

        # make sure there is a route to well position:
        elif self._routing.pathplanner.number_of_required_steps_to_facility(start=agent_pos,
                                                                            destination=next_well_tuple[0]) < 0:
            log(self._agent_name, 'well position will not be chosen, because it is not reachable: '
                + str(next_well_tuple[0].lat) + ', ' + str(next_well_tuple[0].long))
            return self._get_next_well_pos(agent_pos=agent_pos)

        return next_well_tuple[0]

    def _at_enemy_well_position(self, current_well_pos):
        """
        Checks if there is an enemy well at same position as the given position.
        :param current_well_pos: the position of the current well
        :return: True if there is an enemy well at the same position, else False
        """
        ewk = self._kb_well_cache.get_all_matching_sub_facts((Constants.WELL, Constants.ENEMY_WELL, '*', '*',
                                                              '*', '*', '*'))
        dewk = self._kb_well_cache.get_all_matching_sub_facts((Constants.WELL, Constants.CURRENT_DISMANTLE_WELL, '*',
                                                               '*', '*', '*', '*'))
        for t in list(set().union(ewk, dewk)):
            ewk_pos = Position(lat=float(t[2]), long=float(t[3]))
            if self._routing.pathplanner.are_same_location(a=current_well_pos, b=ewk_pos):
                return True
        return False

    def update_sensors(self):
        '''
        Updates the sensors.
        '''
        # first well building behaviour because sensors use updated destination
        self._well_building_behaviour.update_destination(self.well_knowledge_to_build_next)

        self._well_building_sensor.update_step()
        self._well_distance_sensor.update_step()
        self._well_completely_built_sensor.update_step()
        self._finish_well_building_sensor.update_step()

    def get_negated_well_building_condition(self):
        """
        Returns the negation of the condition required for building wells.
        :return:
        """
        return Negation(self._well_building_condition)

    def _update_general_well_information(self):
        price = self._preferred_well.cost
        all_own_wells_built_up = self._kb_well_cache.does_sub_fact_exist(pattern=(Constants.WELL,
                                                                                  Constants.CURRENT_WELL, '*', '*',
                                                                                  Constants.EXISTENT, '*', '*')) or \
            self._kb_well_cache.does_sub_fact_exist(pattern=(Constants.WELL, Constants.DISMANTLED_WELL, '*', '*',
                                                             Constants.EXISTENT, '*', '*'))
        all_enemy_wells_dismantled = self._kb_well_cache.does_sub_fact_exist(pattern=(Constants.WELL,
                                                                                      Constants.ENEMY_WELL, '*', '*',
                                                                                      Constants.EXISTENT, '*', '*')) or\
            self._kb_well_cache.does_sub_fact_exist(pattern=(Constants.WELL, Constants.CURRENT_DISMANTLE_WELL, '*', '*',
                                                             Constants.EXISTENT, '*', '*'))
        self._client.update(pattern=(Constants.GENERAL_WELL_INFO, '*', '*', '*'),
                            new=(Constants.GENERAL_WELL_INFO, str(price), str(all_own_wells_built_up),
                                 str(all_enemy_wells_dismantled)))

    def _get_possible_well_points_and_distance(self):
        """
        Retrieves all exploration points on the outer lines of the match area and sortes them in descending
        order by their avergae distance to facilities.
        :return: the exploration points and their distance in descending order
        :rtype: list[tuple[Position, float]]
        """
        points_and_distance = []

        rows = min(len(self.exploration_grid.lats)/2, len(self.exploration_grid.longs)/2)
        for i in range(rows):
            j = i+1
            if i == 0:
                lats = []+self.exploration_grid.lats
            else:
                lats = []+self.exploration_grid.lats[i:-i]
            for lat in lats:
                # first column
                point = Position(lat=lat, long=self.exploration_grid.longs[i])
                points_and_distance.append((point, 0))

            for long in self.exploration_grid.longs[j:-j]:
                # last row
                point = Position(lat=self.exploration_grid.lats[-j], long=long)
                points_and_distance.append((point, 0))

            if i == 0:
                lats = []+self.exploration_grid.lats
            else:
                lats = []+self.exploration_grid.lats[i:-i]
            lats.reverse()
            for lat in lats:
                # last column
                point = Position(lat=lat, long=self.exploration_grid.longs[-j])
                points_and_distance.append((point, 0))
            longs = []+self.exploration_grid.longs[j:-j]
            longs.reverse()
            for long in longs:
                # first row
                point = Position(lat=self.exploration_grid.lats[i], long=long)
                points_and_distance.append((point, 0))
        # sort tuples of points by distance
        #points_and_distance.sort(key=lambda tup: tup[1], reverse=True)
        return points_and_distance

    def _get_average_distance_to_facilities(self, pos):
        """
        Calculates the average distance of the given position to all known facilities.
        :param pos: a position
        :return: the average distance
        :rtype: float
        """
        distances = []
        for f in self.facilities.charging_stations:
            distances.append(PathPlanner.euclidean_distance(pos, f.pos))
        for f in self.facilities.dumps:
            distances.append(PathPlanner.euclidean_distance(pos, f.pos))
        for f in self.facilities.resources:
            distances.append(PathPlanner.euclidean_distance(pos, f.pos))
        for f in self.facilities.shops:
            distances.append(PathPlanner.euclidean_distance(pos, f.pos))
        for f in self.facilities.storages:
            distances.append(PathPlanner.euclidean_distance(pos, f.pos))
        for f in self.facilities.workshops:
            distances.append(PathPlanner.euclidean_distance(pos, f.pos))
        return sum(distances) / len(distances)

    def _remove_not_reachable_well_points(self):
        """
        Removes all exploration points that have been marked as not reachable in the knowledge base from
        the possible well points calculated earlier. A not reachable exploration point will be saved and not
        checked in future function calls. If a not reachable exploration point was already chosen as the
        next current well position, it will be removed from the knowledge base.
        """
        # remove exploration points that could not be reached from possible well points:
        not_reachable_points = self._client.all(pattern=('*', 'exploring', '*', '*', Constants.NOT_REACHABLE))
        for np in not_reachable_points:
            # no need to check not reachable points again:
            if np in self._not_reachable_well_points:
                continue
            # compare not reachable point to possible well points:
            lat, lon = self.exploration_grid.get_lat_lon_from_ints(int(np[2]), int(np[3]))
            for wp in copy.deepcopy(self._possible_well_points_by_distance):
                if lat == wp[0].lat and lon == wp[0].long:
                    log(self._agent_name, 'not reachable exploration point was removed from possible well points: '
                        + str(wp[0].lat) + ', ' + str(wp[0].long)
                        + '. Left number of positions: ' + str(len(self._possible_well_points_by_distance)))
                    self._possible_well_points_by_distance.remove(wp)
                    # remove from kb if well point was already chosen:
                    self._remove_current_nonexistent_well_by_position(lat, lon)
            # no need to check not reachable points again:
            self._not_reachable_well_points.append(np)

    def _remove_current_nonexistent_well_by_position(self, lat, lon):
        """
        Removes a tuple for the next well to build from the knowledge base if it matches the given position.
        """
        if self._client.pop(pattern=(Constants.WELL, Constants.CURRENT_WELL, str(lat), str(lon), Constants.NONEXISTENT,
                                     '*', '*')):
            log(self._agent_name, 'not reachable exploration point already chosen as current well was removed '
                                  'from knowledge base: ' + str(lat), + ', ' + str(lon))
