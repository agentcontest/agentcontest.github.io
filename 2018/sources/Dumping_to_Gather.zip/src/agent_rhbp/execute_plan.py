from behaviour_components.activators import BooleanActivator

from behaviour_components.conditions import Condition, Negation
from behaviour_components.condition_elements import Effect
from behaviour_components.goals import GoalBase

from behaviours import ExecutePlanBehaviour, FinishExecutePlanBehaviour

from sensors import ExecutePlanSensor, FinishExecutePlanSensor

class ExecutePlanBehaviourGraph(object):
    '''
    This class establishes the rhbp behaviour graph for plan execution purposes. This is used for
    participating in job completion.
    '''
    def __init__(self, agent_name, agent_number):
        '''
        Constructor.
        :param agent_name: the agents name
        :type agent_name: string
        :param role: the agents role
        :type role: Role
        '''
        self._agent_name = agent_name
        self._agent_number = agent_number

        self._role = None
        self._products = None
        self._routing = None

        # behaviours
        self._execute_plan_behaviour = ExecutePlanBehaviour(agent_name=self._agent_name,\
                agent_number=self._agent_number)
        self._finish_execute_plan_behaviour = FinishExecutePlanBehaviour(agent_name=self._agent_name)

        # sensors
        self._execute_plan_sensor = ExecutePlanSensor(agent_name=self._agent_name,\
                reference=self._execute_plan_behaviour)
        self._finish_execute_plan_sensor = FinishExecutePlanSensor(agent_name=self._agent_name,\
                reference=self._execute_plan_behaviour)

        # effects
        self._execute_plan_behaviour.add_effect(effect=Effect(\
                sensor_name=self._execute_plan_sensor.name, indicator=-1, sensor_type=bool))
        self._finish_execute_plan_behaviour.add_effect(effect=Effect(\
                sensor_name=self._finish_execute_plan_sensor.name, indicator=-1, sensor_type=bool))

        # conditions
        self._execute_plan_condition = Condition(sensor=self._execute_plan_sensor,\
                activator=BooleanActivator(desiredValue=True))
        self._finish_execute_plan_condition = Condition(sensor=self._finish_execute_plan_sensor,\
                activator=BooleanActivator(desiredValue=True))

        self._execute_plan_behaviour.add_precondition(self._execute_plan_condition)
        self._finish_execute_plan_behaviour.add_precondition(Negation(self._execute_plan_condition))
        self._finish_execute_plan_behaviour.add_precondition(self._finish_execute_plan_condition)

        # goal
        self._execute_plan_goal = GoalBase(name='execute_plan_goal', permanent=True,\
                plannerPrefix=self._agent_name,conditions=[Negation(self._finish_execute_plan_condition),\
                Negation(self._execute_plan_condition)])

    def reset(self):
        self._role = None
        self._products = None
        self._routing = None

        self._execute_plan_behaviour.reset()
        self._finish_execute_plan_behaviour.reset()

        self._execute_plan_sensor.reset()
        self._finish_execute_plan_sensor.reset()

    def prepare(self, msg, routing):
        '''
        Hands over the sim-start message and an routing instance.
        :param msg: the sim start message
        :type msg: SimStart
        :param routing: the routing instance
        :type routing: Routing
        '''
        self._role = msg.role
        self._products = msg.products
        self._routing = routing
        self._execute_plan_behaviour.add_role(self._role)
        self._execute_plan_behaviour.add_products(self._products)
        self._execute_plan_behaviour.add_routing(self._routing)

    def add_precondition(self, condition):
        '''
        Adds the given precondition to all behaviours but the finish behaviour.
        :param condition: the precondition
        :type condition: Condition
        '''
        self._execute_plan_behaviour.add_precondition(condition)

    def update_worldperception(self, worldperception):
        '''
        Updates worldperception.
        :param worldperception: the current worldperception
        :type worldperception: WorldPerception
        '''
        self._execute_plan_behaviour.update_worldperception(worldperception)

        self._execute_plan_sensor.update_worldperception(worldperception)
        self._finish_execute_plan_sensor.update_worldperception(worldperception)

    def update_sensors(self):
        '''
        Updates the sensors.
        '''
        self._execute_plan_sensor.update_step()
        self._finish_execute_plan_sensor.update_step()

    def get_not_finished_condition(self):
        '''
        Get the condition to first let this behaviour graph finish before triggering other behaviours.
        :param condition: the precondition
        :type condition: Condition
        '''
        return Negation(self._execute_plan_condition)
