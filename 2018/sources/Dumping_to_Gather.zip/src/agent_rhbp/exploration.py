from behaviour_components.activators import BooleanActivator, ThresholdActivator
from behaviour_components.conditions import Condition, Negation, Conjunction, Disjunction
from behaviour_components.condition_elements import Effect
from behaviour_components.goals import GoalBase

from behaviours import ExplorationBehaviour, FinishExplorationBehaviour
from sensors import ExplorationSensor, FinishExplorationSensor, DestinationDistanceSensor

from mac_utils.graphhopper import PathPlanner

class ExplorationBehaviourGraph(object):
    '''
    This class establishes the rhbp behaviour graph for exploration purposes. When not in execution plan
    state this is used for the exploration of the simulation map.
    '''
    def __init__(self, agent_name):
        '''
        Constructor.
        :param agent_name: the agents name
        :type agent_name: string
        '''
        self._agent_name = agent_name

        self.grid = None
        self._routing = None

        # behaviours
        self._exploration_behaviour = ExplorationBehaviour(agent_name=self._agent_name)
        self._finish_exploration_behaviour = FinishExplorationBehaviour(agent_name=self._agent_name,\
                reference=self._exploration_behaviour)

        # sensors
        self._exploration_sensor = ExplorationSensor(agent_name=self._agent_name,\
                reference=self._exploration_behaviour)
        self._finish_exploration_sensor = FinishExplorationSensor(agent_name=self._agent_name)
        self._grid_point_distance_sensor = DestinationDistanceSensor(name='grid_point_distance',\
                agent_name=self._agent_name, reference=self._exploration_behaviour)

        # effects
        self._exploration_behaviour.add_effect(effect=Effect(\
                sensor_name=self._grid_point_distance_sensor.name, indicator=-1.0, sensor_type=float))
        self._finish_exploration_behaviour.add_effect(effect=Effect(\
                sensor_name=self._finish_exploration_sensor.name, indicator=-1.0, sensor_type=bool))

        # conditions
        self._exploration_condition = Condition(sensor=self._exploration_sensor,\
                activator=BooleanActivator(desiredValue=True))
        self._finish_exploration_condition = Condition(sensor=self._finish_exploration_sensor,\
                activator=BooleanActivator(desiredValue=True))
        self._at_grid_point_condition = Condition(self._grid_point_distance_sensor,\
                ThresholdActivator(thresholdValue=0, isMinimum=False))

        self._exploration_behaviour.add_precondition(self._exploration_condition)
        self._exploration_behaviour.add_precondition(Negation(self._at_grid_point_condition))

        self._finish_exploration_behaviour.add_precondition(self._finish_exploration_condition)
        self._finish_exploration_behaviour.add_precondition(Disjunction(self._at_grid_point_condition,\
                Negation(self._exploration_condition)))

        # goal
        self._exploration_goal = GoalBase(name='exploration_goal', permanent=True,\
                plannerPrefix=self._agent_name, conditions=[Negation(self._finish_exploration_condition)])

    def reset(self):

        self.grid = None
        self._routing = None

        self._exploration_behaviour.reset()
        self._finish_exploration_behaviour.reset()

        self._exploration_sensor.reset()
        self._finish_exploration_sensor.reset()
        self._grid_point_distance_sensor.reset()

    def prepare(self, msg, routing, grid):
        '''
        Hands over the sim-start message and an routing instance.
        Creates the exploration grid and hands it over to some components.
        :param msg: the sim start message
        :type msg: SimStart
        :param routing: the routing instance
        :type routing: Routing
        '''
        self.grid = grid
        self._exploration_behaviour.set_grid(self.grid)
        self._exploration_sensor.set_grid(self.grid)

        self._routing = routing
        self._exploration_behaviour.add_routing(self._routing)
        self._grid_point_distance_sensor.add_routing(self._routing)

    def add_precondition(self, condition):
        '''
        Adds the given precondition to all behaviours but the finish behaviour.
        :param condition: the precondition
        :type condition: Condition
        '''
        self._exploration_behaviour.add_precondition(condition)

    def update_worldperception(self, worldperception):
        '''
        Updates worldperception.
        :param worldperception: the current worldperception
        :type worldperception: WorldPerception
        '''
        self._exploration_behaviour.update_worldperception(worldperception)

        self._exploration_sensor.update_worldperception(worldperception)
        self._finish_exploration_sensor.update_worldperception(worldperception)
        self._grid_point_distance_sensor.update_worldperception(worldperception)

    def update_sensors(self):
        '''
        Updates the sensors.
        '''
        self._exploration_sensor.update_step()
        self._finish_exploration_sensor.update_step()
        self._grid_point_distance_sensor.update_step()

    def get_not_finished_condition(self):
        '''
        Get the condition to first let this behaviour graph finish before triggering other behaviours.
        :param condition: the precondition
        :type condition: Condition
        '''
        return Negation(Conjunction(self._finish_exploration_condition, self._at_grid_point_condition))

    def get_negated_exploration_condition(self):
        '''
        Returns the negated of the condition that is required for exploration.
        :return: the negated condition
        :type: Condition
        '''
        return Negation(self._exploration_condition)

    def get_grid(self):
        """
        Returns the exploration grid to be used by other behaviour graphs.
        :return: the exploration grid
        """
        return self.grid


class ExplorationGrid(object):
    '''
    Creates exploration grid.
    '''
    def __init__(self, speed, cell_size, min_lat, max_lat, min_lon, max_lon):
        """
        Constructor.
        :param speed: the speed
        :type speed: uint
        :param cell_size: the cell_size
        :type cell_size: uint
        :param min_lat: the minimum latitude of the map
        :type min_lat: float
        :param max_lat: the maximum latitude of the map
        :type max_lat: float
        :param min_lon: the minimum longitude of the map
        :type min_lon: float
        :param max_lon: the maximum longitude of the map
        :type max_lon: float
        """
        reach = speed * cell_size
        lat_num = ((max_lat - min_lat)*PathPlanner.DISTANCE_BETWEEN_CIRCLE_OF_LATITUDES)/reach
        lon_num = ((max_lon - min_lon)*PathPlanner.DISTANCE_BETWEEN_CIRCLE_OF_LONGITUDES)/reach
        lat_start = min_lat + (reach * (lat_num - int(lat_num)))/\
                (2*PathPlanner.DISTANCE_BETWEEN_CIRCLE_OF_LATITUDES)
        lon_start = min_lon + (reach * (lon_num - int(lon_num)))/\
                (2*PathPlanner.DISTANCE_BETWEEN_CIRCLE_OF_LONGITUDES)

        self.lats = [lat_start]
        self.longs = [lon_start]
        for i in range(int(lat_num)):
            self.lats.append(self.lats[i]+reach/PathPlanner.DISTANCE_BETWEEN_CIRCLE_OF_LATITUDES)
        for i in range(int(lon_num)):
            self.longs.append(self.longs[i]+reach/PathPlanner.DISTANCE_BETWEEN_CIRCLE_OF_LONGITUDES)
        self.clear_occupation()

    def clear_occupation(self):
        '''
        Removes all occupation information from this grid.
        '''
        self.occ = [[False]*len(self.longs) for i in range(len(self.lats))]

    def get_lat_lon_from_ints(self, lat_int, long_int):
        for i, lat in enumerate(self.lats):
            if i == lat_int:
                for j, lon in enumerate(self.longs):
                    if j == long_int:
                        return lat, lon
