
import rospy

from mac_ros_bridge.msg import GenericAction
from diagnostic_msgs.msg import KeyValue

from agent_mutual.agent_utils import get_bridge_topic_prefix, log

class Action(object):
    '''
    This class is an abstract to inherit for other actions. Its only purpose is one time use when an
    action could be sent to the server.
    '''
    ACTION = 'none'
    sent = False

    # goto specific
    CONTINUE = 'continue'
    goto_success = False
    last_position = None
    last_facility = None

    def __init__(self, agent_name):
        '''
        Constructor.
        :param agent_name: agents name
        :type agent_name: string
        '''
        self._agent_name = agent_name

        self._action = GenericAction()
        self._action.action_type = self.ACTION

        self._pub_generic_action = rospy.Publisher(get_bridge_topic_prefix(self._agent_name)+\
                'generic_action', GenericAction, queue_size=1)

    def send(self):
        '''
        Sends this action to the server.
        '''
        self._pub_generic_action.publish(self._action)
        log(self._agent_name, self._action.action_type+\
                str([kv.key+'='+kv.value for kv in self._action.params])+' sent!')
        Action.sent = True


class GoToAction(Action):
    ACTION = 'goto'
    def __init__(self, agent_name, position):
        '''
        Constructor.
        :param agent_name: agents name
        :type agent_name: string
        :param position: the position to go to
        :type position: Position
        '''
        super(GoToAction, self).__init__(agent_name=agent_name)
        '''
        if Action.goto_success and Action.last_position and\
                Action.last_position.lat == position.lat and Action.last_position.long == position.long:
            self._action.action_type = Action.CONTINUE
            self._action.params = []
        else:
        '''
        Action.goto_success = False
        Action.last_position = position
        Action.last_facility = None
        self._action.params = [KeyValue('latitude', str(position.lat)),\
                KeyValue('longitude', str(position.long))]


class GoToFacilityAction(Action):
    ACTION = 'goto'
    def __init__(self, agent_name, facility):
        '''
        Constructor.
        :param agent_name: agents name
        :type agent_name: string
        :param facility: facility to go to
        '''
        super(GoToFacilityAction, self).__init__(agent_name=agent_name)
        '''
        if Action.goto_success and Action.last_facility and Action.last_facility == facility:
            self._action.action_type = Action.CONTINUE
            self._action.params = []
        else:
        '''
        Action.goto_success = False
        Action.last_position = None
        if hasattr(facility, 'name'):
            Action.last_facility = facility.name
            self._action.params = [KeyValue('Facility', facility.name)]
        else:
            Action.last_facility = facility
            self._action.params = [KeyValue('Facility', facility)]


class ChargeAction(Action):
    ACTION = 'charge'
    def __init__(self, agent_name):
        '''
        Constructor.
        :param agent_name: agents name
        :type agent_name: string
        '''
        super(ChargeAction, self).__init__(agent_name=agent_name)
        self._action.params = []


class RechargeAction(Action):
    ACTION = 'recharge'
    def __init__(self, agent_name):
        '''
        Constructor.
        :param agent_name: agents name
        :type agent_name: string
        '''
        super(RechargeAction, self).__init__(agent_name=agent_name)
        self._action.params = []


class GatherResourceAction(Action):
    ACTION = 'gather'
    def __init__(self, agent_name):
        '''
        Constructor.
        :param agent_name: agents name
        :type agent_name: string
        '''
        super(GatherResourceAction, self).__init__(agent_name=agent_name)
        self._action.params = []


class StoreAction(Action):
    ACTION = 'store'
    def __init__(self, agent_name, item_name, amount):
        '''
        Constructor.
        :param agent_name: agents name
        :type agent_name: string
        :param item_name: items name to store
        :type item_name: string
        :param amount: amount of items to store
        :type amount: uint
        '''
        super(StoreAction, self).__init__(agent_name=agent_name)
        self._action.params = [KeyValue('Item', item_name),\
                KeyValue('Amount', str(amount))]


class DeliverAction(Action):
    ACTION = 'deliver_job'
    def __init__(self, agent_name, job_id):
        '''
        Constructor.
        :param agent_name: agents name
        :type agent_name: string
        :param job_id: the jobs id
        :type job_id: string
        '''
        super(DeliverAction, self).__init__(agent_name=agent_name)
        self._action.params = [KeyValue('Job', job_id)]


class AssembleAction(Action):
    ACTION = 'assemble'
    def __init__(self, agent_name, item):
        '''
        Constructor.
        :param agent_name: agents name
        :type agent_name: string
        :param item: name of the item to assemble
        :type item: string
        '''
        super(AssembleAction, self).__init__(agent_name=agent_name)
        self._action.params = [KeyValue('Item', item.name)]


class AssistAssembleAction(Action):
    ACTION = 'assist_assemble'
    def __init__(self, agent_name, assemble_agent):
        '''
        Constructor.
        :param agent_name: agents name
        :type agent_name: string
        :param assemble_agent: name of the agent who uses the assemble action -> whom should be helped
        :type assemble_agent: string
        '''
        super(AssistAssembleAction, self).__init__(agent_name=agent_name)
        self._action.params = [KeyValue('Agent', assemble_agent)]


class BuildWellAction(Action):
    ACTION = 'build'
    def __init__(self, agent_name, welltype = None):
        '''
        Constructor.
        :param agent_name: agents name
        :type agent_name: string
        :param welltype: well type to build
        :type welltype: string
        '''
        super(BuildWellAction, self).__init__(agent_name=agent_name)
        if welltype:
            self._action.params = [KeyValue('WellType', welltype)]


class DismantleWellAction(Action):
    ACTION = 'dismantle'
    def __init__(self, agent_name):
        """
        Constructor.
        :param agent_name:
        """
        super(DismantleWellAction, self).__init__(agent_name=agent_name)
        self._action.params = []

class RetrieveAction(Action):
    ACTION = 'retrieve'
    def __init__(self, agent_name, item_name, amount):
        '''
        Constructor.
        :param agent_name: agents name
        :type agent_name: string
        :param item_name: items name to store
        :type item_name: string
        :param amount: amount of items to store
        :type amount: uint
        '''
        super(RetrieveAction, self).__init__(agent_name=agent_name)
        self._action.params = [KeyValue('Item', item_name),\
                KeyValue('Amount', str(amount))]

class RetrieveDeliveredAction(Action):
    ACTION = 'retrieve_delivered'
    def __init__(self, agent_name, item_name, amount):
        '''
        Constructor.
        :param agent_name: agents name
        :type agent_name: string
        :param item_name: items name to store
        :type item_name: string
        :param amount: amount of items to store
        :type amount: uint
        '''
        super(RetrieveDeliveredAction, self).__init__(agent_name=agent_name)
        self._action.params = [KeyValue('Item', item_name),\
                KeyValue('Amount', str(amount))]
