#!/usr/bin/env python2

import rospy

from knowledge_base.knowledge_base_client import KnowledgeBaseClient

from mac_ros_bridge.msg import EntityMsg, Resource, Position, Item, RequestAction

from mac_agent.msg import WorldPerception, WorldPerceptionMsg

from agent_mutual.agent_utils import get_current_timestamp, get_knowledge_base_name, log, get_team_name


class PerceptionManager(object):
    '''
    This class creates a worldperception by considering information from the SimStart, RequestAction and
    aggragated information concerning different agents local information. The worldperception is published
    such that the auctioneer and bidder are always up to date.
    '''

    def __init__(self, agent_name):
        '''
        Constructor.
        :param agent_name: the agents name
        :type agent_name: string
        '''
        self._agent_name = agent_name

        self._client = KnowledgeBaseClient(knowledge_base_name=get_knowledge_base_name())

        self.worldperception = WorldPerception()

        self._role = None
        self._team = None
        self._team_agents = {}
        self._enemy_agents = {}
        self._explored_resources = {}

        self._sub_global_entities = rospy.Subscriber(get_team_name()+'/entities', EntityMsg,\
                self._entities_callback)

        self._pub_global_entities = rospy.Publisher(get_team_name()+'/entities', EntityMsg,\
                queue_size=1, latch=True)
        self._pub_local_worldperception = rospy.Publisher('~worldperception', WorldPerceptionMsg,\
                queue_size=1, latch=True)

        # needed for identifying enemy wells
        self._unknown_well = None
        self._last_unknown_well = None

        self._sim_started = False

    def reset(self):

        del self._sim_started

        self._clear_knowledge_base()

        self.worldperception = WorldPerception()

        self._role = None
        self._team = None
        self._team_agents = {}
        self._enemy_agents = {}
        self._explored_resources = {}

        # needed for identifying enemy wells
        self._unknown_well = None
        self._last_unknown_well = None

        self._sim_started = False

    def _clear_knowledge_base(self):
        knowledge = self._client.all(())
        while len(knowledge) > 0:
            self._client.pop(('*',) * len(knowledge[0]))
            knowledge = self._client.all(())

    def start(self, msg):
        """
        Starts the perception manager and hands over the simulation start information.
        :param msg:  the message
        :type msg: SimStart
        """
        self._role = msg.role
        self._create_role_knowledge(role=self._role)
        self._team = msg.team

        self._sim_started = True

    def _create_role_knowledge(self, role):
        if role and not self._client.exists(('role', role.name, '*', '*', '*', '*', '*')):
            self._client.update(('role', role.name, '*', '*', '*', '*', '*'),\
                    ('role', role.name, str(role.base_speed), str(role.base_load),\
                    str(role.base_battery), str(role.base_skill), str(role.base_vision)))

    def update_worldperception(self, msg):
        """
        Updates the worldperception with help of the given request action message.
        :param msg: the message
        :type msg: RequestAction
        """
        # publish entity information to collect in all perception managers
        self._publish_entities(msg)

        # create role knowledge
        self._create_role_knowledge(role=self._role)

        # update resource knowledge
        self._update_resource_knowledge(msg.resources)

        self.worldperception.simulation_step = msg.simulation_step
        self.worldperception.team = msg.team
        self.worldperception.agent = msg.agent
        self.worldperception.jobs.auction_jobs = msg.auction_jobs
        self.worldperception.jobs.mission_jobs = msg.mission_jobs
        self.worldperception.jobs.priced_jobs = msg.priced_jobs
        self.worldperception.facilities.charging_stations = msg.charging_stations
        self.worldperception.facilities.dumps = msg.dumps
        self.worldperception.facilities.shops = msg.shops
        self.worldperception.facilities.storages = msg.storages
        self.worldperception.facilities.workshops = msg.workshops
        self.worldperception.facilities.resources = self._get_explored_resources()
        self.worldperception.facilities.wells, self.worldperception.facilities.enemy_wells =\
                self._divide_wells(msg.wells)

        self.worldperception.team_agents = self._team_agents.values()
        self.worldperception.enemy_agents = self._enemy_agents.values()

    def _update_resource_knowledge(self, resources):
        """
        Updates the knowledge about resources in the knowledgebase.
        :param resources: the resources
        :type resources: list of Resource
        """
        for n in resources:
            if n.name not in self._explored_resources.keys():
            #if not self._client.exists(('resource', n.name, '*', '*', '*')):
                items = n.items[0].name
                for i in n.items[1:]:
                    items += ' ' + i.name
                self._client.push(('resource', n.name, str(n.pos.lat), str(n.pos.long), items))

    def _in_well_knowledge(self, wk, type, lat, long, status, name):
        for t in wk:
            if (type == '*' or t[1] == type) and (lat == '*' or t[2] == lat) and\
                    (long == '*' or t[3] == long) and (status == '*' or t[4] == status) and\
                    (name == '*' or t[5] == name):
                return t

    def _divide_wells(self, wells):
        """
        Divides the given wells in own and enemy wells according to the team they belong to.
        :param wells: the list of wells inside the RequestAction message
        :type wells: Well[]
        :return: list of own wells and list of enemy wells
        :rtype: Well[], Well[]
        """
        own_wells = []
        enemy_wells = []

        for w in wells:
            if w.team == self._team:
                log(self._agent_name, 'well ' + w.name + ' is of team ' + w.team +' and thus own well.')
                own_wells.append(w)
            else:
                log(self._agent_name, 'well ' + w.name + ' is of team ' + w.team +' and thus enemy well.')
                enemy_wells.append(w)
        return own_wells, enemy_wells

    def _get_explored_resources(self):
        '''
        Gets knowledge about resource nodes from the knowledge base and returns it.
        :return: list of resources
        :type: Resource[]
        '''
        resources = []
        for n in self._client.all(('resource', '*', '*', '*', '*')):
            r = Resource(name=n[1], pos=Position(lat=float(n[2]), long=float(n[3])),\
                    items=[Item(name=item_name) for item_name in n[4].split(' ')])
            resources.append(r)
            self._explored_resources[r.name] = r
        return resources

    def get_resource_number(self):
        '''
        Returns number of explored resources.
        :return: number of explored resources
        :type: uint32
        '''
        return len(self.worldperception.facilities.resources)

    def _entities_callback(self, msg):
        '''
        Callback method for the entities topic.
        :param msg: the message
        :type msg: EntityMsg
        '''
        if not self._has_started():
            return

        for e in msg.entities:
            if e.team == self._team:
                self._team_agents[e.name] = e
            else:
                self._enemy_agents[e.name] = e

    def _publish_entities(self, msg):
        '''
        Publishes all entities of the other team and the entity corresponding to this agent to all other
        perception managers. (because only this agent knows about his items.
        :param msg: the message
        :type msg: RequestAction
        '''
        entities = []
        for e in msg.entities:
            if e.name == self._agent_name:
                # add current items
                e.items = msg.agent.items
                entities.append(e)
            elif e.team != self._team:
                entities.append(e)
        entities_msg = EntityMsg(timestamp=get_current_timestamp(), entities=entities)
        self._pub_global_entities.publish(entities_msg)

    def publish_worldperception(self):
        '''
        Publishes the current worldperception to auctioneer and bidder of this agent.
        '''
        msg = WorldPerceptionMsg(timestamp=get_current_timestamp(), worldperception=self.worldperception)
        self._pub_local_worldperception.publish(msg)

    def _has_started(self):
        '''
        Return if this instance to be initialized completely.
        '''
        return hasattr(self, '_sim_started') and self._sim_started
