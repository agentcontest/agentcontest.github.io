#!/usr/bin/env python2

import rospy

from mac_ros_bridge.msg import SimStart, RequestAction, GenericAction, SimEnd, Bye

from agent_mutual.agent_utils import log, get_bridge_topic_prefix, get_number, get_items_string
from agent_mutual.statistics import Stats

from agent_perception.perception_manager import PerceptionManager
from agent_rhbp.agent_rhbp import AgentRHBP

class Agent(object):
    '''
    Main ros node which receives all the important server messages e.g. request action and contains the
    rhbp agent for responding by some action to these requests as well as the perception manager which
    handles the current worldperception.
    '''
    def __init__(self):
        '''
        Constructor.
        '''
        rospy.init_node('agent_node', anonymous=False, log_level=rospy.INFO)

        self._agent_name = rospy.get_param('~agent_name')
        self._agent_number = rospy.get_param('~agent_number')
        self._agent_topic_prefix = get_bridge_topic_prefix(agent_name=self._agent_name)

        # subscribe to MAC bridge core simulation topics
        self._sub_local_simstart = rospy.Subscriber(self._agent_topic_prefix + "start", SimStart,\
                self._sim_start_callback)
        self._sub_local_requestaction = rospy.Subscriber(self._agent_topic_prefix + "request_action", \
            RequestAction, self._action_request_callback)
        self._sub_local_end = rospy.Subscriber(self._agent_topic_prefix + "end", SimEnd,\
                self._sim_end_callback)
        self._sub_local_bye = rospy.Subscriber(self._agent_topic_prefix + "bye", Bye, self._bye_callback)

        self._agent_rhbp = AgentRHBP(agent_name=self._agent_name, agent_number=self._agent_number)
        self._perception_manager = PerceptionManager(agent_name=self._agent_name)

        self._rhbp_started = False
        self._sim_started = False

        log(self._agent_name, "Agent initialized!")

    def _reset(self):

        del self._sim_started

        self._perception_manager.reset()
        self._agent_rhbp.reset()

        self._rhbp_started = False
        self._sim_started = False

    def _sim_start_callback(self, msg):
        """
        Callback method for the SimStart message.
        :param msg:  the message
        :type msg: SimStart
        """
        # wait until initialized
        while not self._has_been_initialized():
            log(self._agent_name, 'Not initialized yet!', 'err')
            rospy.sleep(0.1)

        if not self._sim_started:  # init only once here
            self._perception_manager.start(msg)
            while not self._agent_rhbp.has_been_initialized():
                log(self._agent_name, 'RHBP not initialized yet!', 'err')
                rospy.sleep(0.1)
            self._agent_rhbp.start(msg)
            self._sim_started = True
            log(self._agent_name, "(SimStart) Agent started!")

    def _has_been_initialized(self):
        return hasattr(self, '_sim_started')

    def _action_request_callback(self, msg):
        """
        Callback method for the request action message. Updates worldperception and triggers the
        decision-making and planning.
        :param msg: the message
        :type msg: RequestAction
        """
        if not self._has_been_initialized() or not self._sim_started:
            log(self._agent_name, '(step='+str(msg.simulation_step)+') SimStart not arrived yet!', 'err')
            return

        # only log by one agent
        if get_number(string=self._agent_name) == 1:
            Stats.log_general(agent_number=self._agent_number, simulation_step=msg.simulation_step,\
                    massium=msg.team.massium, score=msg.team.score)

        log(self._agent_name, '(ActionRequest) {step='+str(msg.simulation_step)+' | '+\
                'charge='+str(msg.agent.charge)+' | position='+str(msg.agent.pos)+' | '+\
                'resource_nodes='+str(self._perception_manager.get_resource_number())+' | '+\
                str(msg.agent.last_action)+str(msg.agent.last_action_params)+'->'+\
                str(msg.agent.last_action_result)+' | items='+get_items_string(msg.agent.items)+'}')

        # test if rhbp started yet
        if not self._rhbp_started:
            self._rhbp_started = self._agent_rhbp.has_been_started(simulation_step=msg.simulation_step)

        # update world perception first
        self._perception_manager.update_worldperception(msg)

        # update rhbp agent first -> update unreserved items knowledge
        if self._rhbp_started:
            self._agent_rhbp.update_worldperception(worldperception=\
                    self._perception_manager.worldperception)

        # update action response deadline
        if self._rhbp_started and\
                self._agent_rhbp.compute_next_deadline(simulation_step=msg.simulation_step,\
                timestamp=msg.timestamp, deadline=msg.deadline):
            # do rhbp step
            self._agent_rhbp.do_step()
        else:
            # log as decision making timeout
            Stats.log_action_response_duration(duration=4.0)
            Stats.log_decision_making_timeouts()

        # publish worldperception
        self._perception_manager.publish_worldperception()

    def _sim_end_callback(self, msg):
        """
        Callback for the SimEnd message.
        :param msg:  the message
        :type msg: SimEnd
        """
        log(self._agent_name, "(SimEnd) "+str(msg))
        self._reset()

    def _bye_callback(self, msg):
        """
        Callback for the Bye message.
        :param msg:  the message
        :type msg:  Bye
        """
        log(self._agent_name, "(Bye) "+str(msg))
        log(self._agent_name, "Simulation finished")
        rospy.signal_shutdown('Shutting down {}  - Simulation server closed'.format(self._agent_name))

if __name__ == '__main__':

    try:
        agent = Agent()
        rospy.spin()

    except rospy.ROSInterruptException:
        rospy.logerr("program interrupted before completion")
