#!/usr/bin/env python2

import rospy

from mac_ros_bridge.msg import SimStart, SimEnd, Bye
from mac_agent.msg import WorldPerceptionMsg

from knowledge_base.knowledge_base_client import KnowledgeBaseClient

from agent_mutual.agent_utils import log, get_bridge_topic_prefix, get_agent_topic_prefix, get_number,\
        get_knowledge_base_name
from agent_mutual.constants import Constants
from agent_mutual.statistics import Stats

from auction import PricedJobAuction, AuctionJobAuction, MissionJobAuction

from agent_auctioning.routing import Routing
from job_decomposition import JobDecompositionManager

class Auctioneer(object):
    '''
    This is a ros node which has the purpose of analyzing, handling and managing jobs offered by the
    simulation server. For any new job a new auction is created where it gets divided into subtasks which
    then are auctioned in staged manner such that every bidder responses to all the different auction
    stages with a corresponding plan which could solve the auctioned task. Then it's decided which
    plans to take for completing the job or if the job is going to be taken anyways.
    '''
    auction_id_counter = 0

    def __init__(self):
        '''
        Constructor.
        '''
        rospy.init_node('auctioneer_node', anonymous=True, log_level=rospy.INFO)

        self._agent_name = rospy.get_param('~agent_name')
        self._agent_number = rospy.get_param('~agent_number')

        self._auctioneer_name = 'auctioneer_'+self._agent_name

        self._agent_id = get_number(string=self._agent_name)
        self._bridge_topic_prefix = get_bridge_topic_prefix(agent_name=self._agent_name)
        self._agent_topic_prefix = get_agent_topic_prefix(agent_name=self._agent_name)

        self._client = KnowledgeBaseClient(knowledge_base_name=get_knowledge_base_name())

        self._job_decomposition_manager = JobDecompositionManager(agent_name=self._agent_name,\
                node_name=self._auctioneer_name)

        self._auctions = {}

        self._priced_jobs = {}
        self._new_priced_jobs = []
        self._auction_jobs = {}
        self._new_auction_jobs = []
        self._mission_jobs = {}
        self._new_mission_jobs = []

        self._simulation_step = 0
        self._massium = 0

        self._routing = None

        rospy.Subscriber(self._bridge_topic_prefix + "start", SimStart, self._sim_start_callback)
        rospy.Subscriber(self._agent_topic_prefix + "worldperception", WorldPerceptionMsg,\
                self._worldperception_callback)
        rospy.Subscriber(self._bridge_topic_prefix + "end", SimEnd, self._sim_end_callback)
        rospy.Subscriber(self._bridge_topic_prefix + "bye", Bye, self._bye_callback)

        self._sim_started = False

        log(self._auctioneer_name, "Auctioneer initialized!")

    def _reset(self):

        del self._sim_started

        self._job_decomposition_manager.reset()

        self._quit_all_auctions()
        self._auctions = {}

        self._priced_jobs = {}
        self._new_priced_jobs = []
        self._auction_jobs = {}
        self._new_auction_jobs = []
        self._mission_jobs = {}
        self._new_mission_jobs = []

        self._simulation_step = 0
        self._massium = 0

        self._routing = None

        self._sim_started = False

    def _quit_all_auctions(self):
        for auction in self._auctions.values():
            auction.quit()

        while len(self._auctions) > 0:
            self._take_care_of_terminated_auctions()
            if len(self._auctions) > 0:
                rospy.sleep(0.1)

    def _sim_start_callback(self, msg):
        '''
        Callback method for the sim-start topic.
        :param msg: the message
        :type msg: SimStart
        '''
        # wait until initialized
        while not self._has_been_initialized():
            log(self._auctioneer_name, 'Not initialized yet!', 'err')
            rospy.sleep(0.1)

        if not self._sim_started:
            self._routing = Routing(node_name=self._auctioneer_name, role=msg.role,\
                    cell_size=msg.cell_size, proximity=msg.proximity, map_name=msg.map)
            self._job_decomposition_manager.start(routing=self._routing, products=msg.products)
            self._sim_started = True
            log(self._auctioneer_name, "(SimStart) Auctioneer started!")

    def _has_been_initialized(self):
        return hasattr(self, '_sim_started')

    def _worldperception_callback(self, msg):
        '''
        Callback method for the worldperception topic.
        :param msg: the message
        :type msg: WorldPerceptionMsg
        '''
        if not self._has_been_initialized() or not self._sim_started:
            log(self._auctioneer_name, 'SimStart not arrived yet!', 'err')
            return

        self._simulation_step = msg.worldperception.simulation_step
        self._massium = msg.worldperception.team.massium

        self._take_care_of_terminated_auctions()

        self._routing.update_facilites(msg.worldperception.facilities)
        self._job_decomposition_manager.update_worldperception(msg.worldperception)

        self._update_auctions(worldperception=msg.worldperception)

        self._priced_job_callback(msg.worldperception.jobs.priced_jobs)
        self._mission_job_callback(msg.worldperception.jobs.mission_jobs)
        self._auction_job_callback(msg.worldperception.jobs.auction_jobs)

        if len(self._new_priced_jobs) > 0 and not self._is_well_stuff_todo():
            self._handle_new_priced_jobs()
        '''
        # TODO leave out auction jobs for now -> because they are not handled
        if len(self._new_auction_jobs) > 0:
            self._handle_new_auction_jobs()
        '''
        self._handle_new_mission_jobs()

    def _take_care_of_terminated_auctions(self):
        '''
        Remove already terminated auctions from auction list and restart them if necessary.
        '''
        for auction in self._auctions.values():
            if auction.terminated:
                # terminate & remove auction
                auction.join()
                del(self._auctions[auction.job.id])

                # restart auction
                if auction.restart:
                    auction_type = type(auction).__name__
                    log(self._auctioneer_name, 'Restart '+auction_type+' -> '+str(auction.job.id)+'!',\
                            'warn')
                    if auction_type == PricedJobAuction.__name__:
                        self._new_priced_jobs.append(auction.job.id)
                    elif auction_type == MissionJobAuction.__name__:
                        self._new_mission_jobs.append(auction.job.id)
                    elif auction_type == AuctionJobAuction.__name__:
                        self._new_auction_jobs.append(auction.job.id)

    def _update_auctions(self, worldperception):
        '''
        Updates the worldperception of all active auctions.
        :param worldperception: the message object
        :type worldperception: WorldPerception
        '''
        for auction in self._auctions.values():
            # only updates simulation step for now... maybe needs more information in the future
            auction.update_auction(simulation_step=worldperception.simulation_step)

    def _priced_job_callback(self, jobs):
        '''
        Pseudo callback method for priced jobs.
        Detects if a job came in newly and puts it into a corresponding list.
        :param jobs: list of priced jobs
        :type jobs: Job[]
        '''
        for j in jobs:
            if self._is_responsible(get_number(j.id)):
                if j.id not in self._priced_jobs.keys():
                    self._new_priced_jobs.append(j.id)
                    Stats.log_total_jobs(job_name=j.id, job_type=Constants.PRICED_JOB)
                self._priced_jobs[j.id] = j

    def _auction_job_callback(self, jobs):
        '''
        Pseudo callback method for auction jobs.
        Detects if a job came in newly and puts it into a corresponding list.
        :param jobs: list of auction jobs
        :type jobs: AuctionJob[]
        '''
        for j in jobs:
            if self._is_responsible(get_number(j.job.id)):
                if j.job.id not in self._auction_jobs.keys():
                    self._new_auction_jobs.append(j.job.id)
                    Stats.log_total_jobs(job_name=j.job.id, job_type=Constants.AUCTION_JOB)
                self._auction_jobs[j.job.id] = j

    def _mission_job_callback(self, jobs):
        '''
        Pseudo callback method for mission jobs.
        Detects if a job came in newly and puts it into a corresponding list.
        :param jobs: list of mission jobs
        :type jobs: Job[]
        '''
        for j in jobs:
            if self._is_responsible(get_number(j.id)):
                if j.id not in self._mission_jobs.keys():
                    self._new_mission_jobs.append(j.id)
                    Stats.log_total_jobs(job_name=j.id, job_type=Constants.MISSION_JOB)
                self._mission_jobs[j.id] = j

    def _is_responsible(self, job_id):
        '''
        Determine if this auctioneer is responsible for the job with the given job id.
        :param job_id: the id of the job
        :type job_id: int
        :return: True if responsible else False
        :type: bool
        '''
        if self._agent_id-1 == job_id % self._agent_number:
            return True
        return False

    def _is_well_stuff_todo(self):

        knowledge = self._client.peek((Constants.GENERAL_WELL_INFO, '*', '*', '*'))
        if knowledge:
            price = int(knowledge[1])
            well_to_built_up_exists = knowledge[2] == 'True'
            enemy_well_to_dismantle_exists = knowledge[3] == 'True'
            return price <= self._massium or well_to_built_up_exists or enemy_well_to_dismantle_exists
        else:
            return False

    def _handle_new_priced_jobs(self):
        '''
        Handles new priced jobs the auctioneer is responsible for & creates one auction for each of them.
        '''
        timeout_steps = 10
        for p in self._new_priced_jobs:
            j = self._priced_jobs[p]
            if self._simulation_step - timeout_steps < j.start:
                self._auctions[j.id] = (PricedJobAuction(auction_id=self._get_new_auction_id(),\
                        agent_name=self._agent_name, agent_number=self._agent_number,\
                        simulation_step=self._simulation_step, priced_job=j,\
                        job_decomposition_manager=self._job_decomposition_manager))
                self._auctions[j.id].start()
            self._new_priced_jobs.remove(p)

    def _handle_new_auction_jobs(self):
        '''
        Handles new auction jobs the auctioneer is responsible for & creates one auction for each of them.
        '''
        for a in self._new_auction_jobs:
            j = self._auction_jobs[a]
            self._auctions[j.job.id] = (AuctionJobAuction(auction_id=self._get_new_auction_id(),\
                    agent_name=self._agent_name, agent_number=self._agent_number,\
                    simulation_step=self._simulation_step,\
                    auction_job=j, job_decomposition_manager=self._job_decomposition_manager))
            self._auctions[j.job.id].start()
            self._new_auction_jobs.remove(a)

    def _handle_new_mission_jobs(self):
        '''
        Handles new mission jobs the auctioneer is responsible for & creates one auction for each of them.
        '''
        for m in self._new_mission_jobs:
            j = self._mission_jobs[m]
            self._auctions[j.id] = (MissionJobAuction(auction_id=self._get_new_auction_id(),\
                    agent_name=self._agent_name, agent_number=self._agent_number,\
                    simulation_step=self._simulation_step,\
                    mission_job=j, job_decomposition_manager=self._job_decomposition_manager))
            self._auctions[j.id].start()
            self._new_mission_jobs.remove(m)

    def _get_new_auction_id(self):
        '''
        Gets new auction id and iterates counter.
        :return: auction id
        :return type: uint32
        '''
        Auctioneer.auction_id_counter += 1
        return Auctioneer.auction_id_counter

    def _sim_end_callback(self, msg):
        """
        Callback method for the SimEnd message.
        :param msg:  the message
        :type msg: SimEnd
        """
        log(self._auctioneer_name, "(SimEnd) "+str(msg))
        self._reset()

    def _bye_callback(self, msg):
        """
        Callback method for the Bye message.
        :param msg:  the message
        :type msg:  Bye
        """
        log(self._auctioneer_name, "(Bye) "+str(msg))
        log(self._auctioneer_name, "Simulation finished")
        rospy.signal_shutdown('Shutting down {}  - Simulation server closed'\
                .format(self._auctioneer_name))

if __name__ == '__main__':

    try:
        auctioneer = Auctioneer()
        rospy.spin()

    except rospy.ROSInterruptException:
        rospy.logerr("program interrupted before completion")
