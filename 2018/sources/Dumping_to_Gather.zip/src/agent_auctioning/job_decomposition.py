#!/usr/bin/env python2
import rospy

from mac_agent.msg import GatherNAssembleTask, RetrieveNAssembleTask, AssembleTask, GatherNDeliverTask,\
        RetrieveNDeliverTask, DeliverTask

from mac_ros_bridge.msg import Item, Role

from agent_mutual.agent_utils import log, get_position, get_knowledge_base_name
from agent_mutual.constants import Constants

from knowledge_base.knowledge_base_client import KnowledgeBaseClient

try:
    from Queue import PriorityQueue # ver. < 3.0
except ImportError:
    from queue import PriorityQueue

class JobDecompositionManager(object):
    '''
    This class decomposes the given job into stages of subtasks and returns them back such that the
    auctioneer can perform the auctioning with them.
    '''
    task_id_counter = 0

    def __init__(self, agent_name, node_name):
        '''
        Constructor.
        :param agent_name: name of the corresponding agent
        :type agent_name: string
        '''
        self._agent_name = agent_name
        self._node_name = node_name

        self._client = KnowledgeBaseClient(knowledge_base_name=get_knowledge_base_name())

        self._routing = None
        self.roles = {}
        self.products = {}

        self.worldperception = None
        self.team_agents = {}

    def reset(self):
        self._routing = None
        self.roles = {}
        self.products = {}

        self.worldperception = None
        self.team_agents = {}

    def start(self, routing, products):
        '''
        Hands over the item products.
        :param products: list of products
        :type products: Product[]
        '''
        self._routing = routing
        for p in products:
            self.products[p.name] = p
        self._get_role_knowledge()

    def _get_role_knowledge(self):
        ready = False
        while not ready:
            knowledge = self._client.all(('role', '*', '*', '*', '*', '*', '*'))
            if knowledge and len(knowledge) == 4:
                for k in knowledge:
                    self.roles[k[1]] = Role(name=k[1], base_speed=int(k[2]), base_load=int(k[3]),\
                            base_battery=int(k[4]), base_skill=int(k[5]), base_vision=int(k[6]))
                ready = True
            else:
                log(self._node_name, 'Wait for role knowledge to be complete!', 'err')
                rospy.sleep(0.5)

    def update_worldperception(self, worldperception):
        '''
        Updates current worldperception.
        :param worldperception: the worldperception
        :type worldperception: WorldPerception
        '''
        self.worldperception = worldperception
        self._update_team_agents(team_agents=self.worldperception.team_agents)

    def _update_team_agents(self, team_agents):
        # save team agents
        for ta in team_agents:
            if ta.name not in self.team_agents:
                self.team_agents[ta.name] = ta
            else:
                # TODO overwrite attributes
                pass

    def decompose_job(self, job):
        # TODO update description
        '''
        Decomposes the given job into different stages of tasks. Tasks from different stages can
        depend on each other. The list of stages are sorted in chronological order such that the order
        to send the stage request messages in is determined by it. For now the job is devided into
        tasks the following way: for each different item required for the given job a gather resource task
        is created and to deliver those gathered items a deliver items task that is linked to the former
        gather resource task by dependency is created such that the items are delivered by the
        corresponding agent to the given job storage.
        :param job: job to decompose
        :type job: Job
        :return: list of lists of tasks
        :type: Task[][]
        '''
        # get name of workshop closest to storage
        workshop_name = self._routing.get_real_closest(instances=\
                self.worldperception.facilities.workshops, pos=get_position(name=job.storage_name,\
                instances=self.worldperception.facilities.storages))[0].name

        non_assembly_stage = []
        assembly_stages = []

        products = self.products
        if len(products) == 0:
            return None

        for item in job.items:

            items = self._get_item_stack_decomposition(item=item, products=products)

            for i in items:
                if len(products[i.name].consumed_items) == 0:
                    # non-assembly items
                    task = GatherNDeliverTask(task_id=self._get_new_task_id(),\
                            storage_name=job.storage_name, items=[i])
                    non_assembly_stage.append(task)
                else:
                    # assembly items
                    # TODO old or new product decomposition
                    decomposition = self._decompose_product(job=job, item=i, workshop_name=workshop_name)
                    if not decomposition:
                        return None
                    decomposition.reverse()
                    #decomposition = self._decompose_product_old(job=job, item=i,\
                    #        workshop_name=workshop_name)
                    assembly_stages.append(decomposition)

        # sort assembling order of products
        sorted_assembly_stages = self._sort_product_assembly(assembly_stages=assembly_stages)

        # replace gather n deliver tasks with retrieve tasks
        # TODO old or new product decomposition
        non_assembly_stage = self._decompose_product(job=job, item=None,\
                    workshop_name=workshop_name, decomposition=[non_assembly_stage])
        if not non_assembly_stage:
            return None
        non_assembly_stage = non_assembly_stage[0]
        #non_assembly_stage = self._decompose_product_old(job=job, item=None,\
        #            workshop_name=workshop_name, decomposition=[non_assembly_stage])[0]

        # flatten nested into stages
        stages = []
        for s in sorted_assembly_stages:
            stages += s

        merge_non_assembly_n_assembly = False
        if len(non_assembly_stage) != 0 and (not merge_non_assembly_n_assembly or len(stages) == 0):
            stages.append(non_assembly_stage)
        else:
            stages[-1] += non_assembly_stage

        return stages

    def _decompose_product(self, job, item, workshop_name, decomposition = None):

        if not decomposition:
            decomposition = [[DeliverTask(task_id=self._get_new_task_id(), dependent=True,\
                    storage_name=job.storage_name, items=[item])]]

        next_stage_dependent = []
        next_stage_non_dependent = []
        sub_decompositions = []

        products = self.products
        if len(products) == 0:
            return None

        for idx, last_task in enumerate(decomposition[-1]):
            last_item = last_task.items[0]

            ack, storage_name, store_type =\
                    self._reserve_item(job=job, item=last_item, task_id=last_task.task_id)

            task_type = type(last_task).__name__
            if ack:
                if task_type in [DeliverTask.__name__, GatherNDeliverTask.__name__]:
                    # change to retrieve and deliver task
                    task = RetrieveNDeliverTask(task_id=last_task.task_id)
                    task.retrieve_storage_name = storage_name
                    task.stored = bool(store_type == Constants.ITEM_STORED)
                    task.items = [last_item]
                    task.storage_name = job.storage_name
                    decomposition[-1][idx] = task
                elif task_type in [AssembleTask.__name__, GatherNAssembleTask.__name__]:
                    # change to retrieve and assemble task
                    task = RetrieveNAssembleTask(task_id=last_task.task_id)
                    task.retrieve_storage_name = storage_name
                    task.stored = bool(store_type == Constants.ITEM_STORED)
                    task.items = [last_item]
                    task.workshop_name = last_task.workshop_name
                    task.product = last_task.product
                    task.storage_name = last_task.storage_name
                    task.successor = last_task.successor
                    decomposition[-1][idx] = task
            else:
                if type(last_task).__name__ in [DeliverTask.__name__, AssembleTask.__name__]:

                    for item in products[last_item.name].consumed_items:

                        new_item = Item(name=item.name, amount=last_item.amount*item.amount)

                        items = self._get_item_stack_decomposition(item=new_item, products=products,\
                                required_roles=products[last_item.name].required_roles)

                        for i in items:

                            if len(products[i.name].consumed_items) > 0:
                                task = AssembleTask(dependent=True)
                            else:
                                task = GatherNAssembleTask()

                            task.task_id = self._get_new_task_id()
                            task.items = [i]
                            task.product = last_item
                            task.workshop_name = workshop_name
                            task.storage_name = job.storage_name

                            task.successor = last_task.task_id
                            last_task.predecessors.append(task.task_id)

                            decomp = self._decompose_product(job=job, item=None,\
                                    workshop_name=workshop_name, decomposition=[[task]])
                            if type(task).__name__ == AssembleTask.__name__:
                                next_stage_dependent.append(decomp[0][0])
                                sub_decompositions += decomp[1:]
                            elif type(task).__name__ == GatherNAssembleTask.__name__:
                                next_stage_non_dependent.append(decomp[0][0])

        next_stage = next_stage_dependent + next_stage_non_dependent
        if len(next_stage) > 0:
            decomposition.append(next_stage)

        decomposition += sub_decompositions

        return decomposition

    def _decompose_product_old(self, job, item, workshop_name, decomposition=None):

        all_decomposed = False
        if not decomposition:
            decomposition = [[DeliverTask(task_id=self._get_new_task_id(), dependent=True,\
                    storage_name=job.storage_name, items=[item])]]

        products = self.products
        if len(products) == 0:
            return None

        while not all_decomposed:
            next_stage_dependent = []
            next_stage_non_dependent = []

            for idx, last_task in enumerate(decomposition[-1]):
                last_item = last_task.items[0]

                ack, storage_name, store_type =\
                        self._reserve_item(job=job, item=last_item, task_id=last_task.task_id)

                task_type = type(last_task).__name__
                if ack:
                    if task_type in [DeliverTask.__name__, GatherNDeliverTask.__name__]:
                        # change to retrieve and deliver task
                        task = RetrieveNDeliverTask(task_id=last_task.task_id)
                        task.retrieve_storage_name = storage_name
                        task.stored = bool(store_type == Constants.ITEM_STORED)
                        task.items = [last_item]
                        task.storage_name = job.storage_name
                        decomposition[-1][idx] = task
                    elif task_type in [AssembleTask.__name__, GatherNAssembleTask.__name__]:
                        # change to retrieve and assemble task
                        task = RetrieveNAssembleTask(task_id=last_task.task_id)
                        task.retrieve_storage_name = storage_name
                        task.stored = bool(store_type == Constants.ITEM_STORED)
                        task.items = [last_item]
                        task.workshop_name = last_task.workshop_name
                        task.product = last_task.product
                        task.storage_name = last_task.storage_name
                        task.successor = last_task.successor
                        decomposition[-1][idx] = task
                else:
                    if task_type in [DeliverTask.__name__, AssembleTask.__name__]:

                        for item in products[last_item.name].consumed_items:

                            new_item = Item(name=item.name, amount=last_item.amount*item.amount)

                            items = self._get_item_stack_decomposition(item=new_item, products=products,\
                                    required_roles=products[last_item.name].required_roles)

                            for i in items:

                                if len(products[i.name].consumed_items) > 0:
                                    task = AssembleTask(dependent=True)
                                    next_stage_dependent.append(task)
                                else:
                                    task = GatherNAssembleTask()
                                    next_stage_non_dependent.append(task)

                                task.task_id = self._get_new_task_id()
                                task.items = [i]
                                task.workshop_name = workshop_name
                                task.product = last_item
                                task.storage_name = job.storage_name

                                task.successor = last_task.task_id
                                last_task.predecessors.append(task.task_id)

            next_stage = next_stage_dependent + next_stage_non_dependent
            if len(next_stage) == 0:
                all_decomposed = True
            else:
                decomposition.append(next_stage)

        decomposition.reverse()

        return decomposition

    def _reserve_item(self, job, item, task_id):
        st_pos = get_position(name=job.storage_name, instances=self.worldperception.facilities.storages)
        strgs = self._routing._get_euclidean_closest(instances=self.worldperception.facilities.storages,\
                pos=st_pos, num_best=len(self.worldperception.facilities.storages))

        chosen_storage_name = None
        chosen_type = None
        knowledge = None
        for storage in strgs:
            for i in storage.items:
                if item.name == i.name and (item.amount <= i.stored or item.amount <= i.delivered):
                    if not knowledge:
                        knowledge = self._get_reserved_item_knowledge(item=item)

                    if storage.name not in knowledge:
                        if item.amount <= i.stored:
                            chosen_type = Constants.ITEM_STORED
                        elif item.amount <= i.delivered:
                            chosen_type = Constants.ITEM_DELIVERED
                        chosen_storage_name = storage.name
                        self._client.push((Constants.RESERVED_ITEM, item.name, str(item.amount),\
                                chosen_storage_name, chosen_type, job.id, str(task_id)))
                        return True, chosen_storage_name, chosen_type
                    else:
                        if item.amount <= i.stored-knowledge[storage.name][Constants.ITEM_STORED]:
                            chosen_type = Constants.ITEM_STORED
                        elif item.amount <= i.delivered-knowledge[storage.name][Constants.ITEM_DELIVERED]:
                            chosen_type = Constants.ITEM_DELIVERED

                        if chosen_type:
                            chosen_storage_name = storage.name
                            self._client.push((Constants.RESERVED_ITEM, item.name, str(item.amount),\
                                    chosen_storage_name, chosen_type, job.id, str(task_id)))
                            return True, chosen_storage_name, chosen_type

        return False, chosen_storage_name, chosen_type

    def _get_reserved_item_knowledge(self, item):
        knowledge = {}
        for _, _, amount, storage, store_type, _, _ in\
                self._client.all((Constants.RESERVED_ITEM, item.name, '*', '*', '*', '*', '*')):
            if storage not in knowledge:
                knowledge[storage] = {Constants.ITEM_STORED:0, Constants.ITEM_DELIVERED:0}
            knowledge[storage][store_type] += int(amount)
        return knowledge

    def clear_reserved_item_knowledge(self, job_id):
        self._client.pop((Constants.RESERVED_ITEM, '*', '*', '*', '*', job_id, '*'))

    def _get_item_stack_decomposition(self, item, products, required_roles=[Constants.MOTORCYCLE]):

        volume = products[item.name].volume

        if len(self.roles) == 4:
            truck_max_items = self.roles[Constants.TRUCK].base_load / volume
            car_max_items = self.roles[Constants.CAR].base_load / volume
            motorcycle_max_items = self.roles[Constants.MOTORCYCLE].base_load / volume
            drone_max_items = self.roles[Constants.DRONE].base_load / volume
        else:
            truck_max_items = 50
            car_max_items = 40
            motorcycle_max_items = 30
            drone_max_items = 15

        amounts = []
        num_trucks = item.amount / truck_max_items
        amounts += [truck_max_items] * num_trucks
        if item.amount > num_trucks*truck_max_items:
            amounts += [item.amount - (num_trucks*truck_max_items)]

        if Constants.CAR in required_roles and amounts[-1] > car_max_items:
            new = amounts[-1] - car_max_items
            if car_max_items > new:
                amounts[-1] = car_max_items
                amounts.append(new)
            else:
                amounts[-1] = new
                amounts.append(car_max_items)

        if Constants.MOTORCYCLE in required_roles and amounts[-1] > motorcycle_max_items:
            new = amounts[-1] - motorcycle_max_items
            if motorcycle_max_items > new:
                amounts[-1] = motorcycle_max_items
                amounts.append(new)
            else:
                amounts[-1] = new
                amounts.append(motorcycle_max_items)

        if Constants.DRONE in required_roles and amounts[-1] > drone_max_items:
            new = amounts[-1] - drone_max_items
            if drone_max_items > new:
                amounts[-1] = drone_max_items
                amounts.append(new)
            else:
                amounts[-1] = new
                amounts.append(drone_max_items)

        #print(item.name+' amount='+str(item.amount)+' volume='+str(volume)+' amounts='+str(amounts))

        items = [Item(name=item.name, amount=a) for a in amounts]
        return items

    def _sort_product_assembly(self, assembly_stages):

        q = PriorityQueue()
        for s in assembly_stages:
            q.put((len(s[0]), s))
        lists_1 = [q.get()[1] for _ in range(len(assembly_stages))]

        lists_2 = []
        current_length = 0
        for l in lists_1:
            if current_length != len(l[0]):
                current_length = len(l[0])
                lists_2.append([])
            lists_2[-1].append(l)

        result = []
        for group in lists_2:
            for l in group:
                q.put((len(l), l))
            result += [q.get()[1] for _ in range(len(group))]

        result.reverse()

        return result

    def _get_new_task_id(self):
        '''
        Gets new task id and iterates counter.
        :return: task id
        :return type: uint32
        '''
        JobDecompositionManager.task_id_counter += 1
        return JobDecompositionManager.task_id_counter
