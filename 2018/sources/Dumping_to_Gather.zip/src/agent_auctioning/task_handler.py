#!/usr/bin/env python2

import sys
import math
import copy

from agent_mutual.agent_utils import log, get_position, get_task_string, get_items_string

from mac_ros_bridge.msg import Item, GenericAction

# TODO remove old plans
from mac_agent.msg import Route, AssemblePlan, DeliverPlan, GatherNAssemblePlan, GatherNDeliverPlan,\
        RetrieveNAssemblePlan, RetrieveNDeliverPlan,\
        GatherResourcePlan, DeliverItemsPlan

from agent_rhbp.actions import AssembleAction, AssistAssembleAction, DeliverAction, GatherResourceAction,\
        RetrieveAction, RetrieveDeliveredAction

class TaskHandler(object):
    '''
    This class processes the given tasks and creates plans that can solve those tasks when executed.
    The created plans depend on the corresponding agents state as well as on the already assigned plans.
    '''
    def __init__(self, agent_name, node_name, planhandler):
        '''
        Constructor.
        :param agent_name: the corresponding agents name
        :type agent_name: string
        :param node_name: the corresponding nodes name
        :type node_name: string
        :param planhandler: the planhandler to get information about the already assigned plans from
        :type planhandler: PlanHandler
        '''
        self._agent_name = agent_name
        self._node_name = node_name
        self._planhandler = planhandler

        self._role = None
        self._load = 1
        self._skill = 1

        self._routing = None
        self._worldperception = None
        self._products = {}

        self._initialized = False

    def reset(self):
        self._role = None
        self._load = 1
        self._skill = 1

        self._routing = None
        self._worldperception = None
        self._products = {}

        self._initialized = False

    def init(self, role, products, routing):
        '''
        Hands over the role, the item products as well as a routing instance.
        :params role: the corresponding role
        :type role: Role
        :params products: the products
        :type products: Product[]
        :params routing: the routing instance
        :type routing: Routing
        '''
        self._role = role
        # TODO update if upgraded
        self._load = self._role.base_load
        self._skill = self._role.base_skill

        for p in products:
            self._products[p.name] = p

        self._routing = routing

        self._initialized = True

    def update_worldperception(self, worldperception):
        '''
        Updates worldperception.
        :param worldperception: the current worldperception
        :type worldperception: WorldPerception
        '''
        self._worldperception = worldperception

    def process_gather_n_assemble_task(self, task):

        task_string = get_task_string(task=task)
        plan = GatherNAssemblePlan(bidder=self._agent_name, feasible=False, task=task)

        routing = self._routing
        products = self._products
        worldperception = self._worldperception

        if not self._initialized:
            log(self._node_name, task_string+'Not initialized yet!','err')
            return plan

        item = task.items[0]
        product = task.product

        valid_resource_nodes = []
        for rn in worldperception.facilities.resources:
            if item.name in [i.name for i in rn.items]:
                valid_resource_nodes.append(rn)

        # check if valid resource nodes
        if len(valid_resource_nodes) == 0:
            log(self._node_name, task_string+'No resource node holding '+item.name+' explored yet!',\
                    'warn')
            return plan

        # get start conditions
        start_step, start_charge, start_pos, start_items = self._planhandler._get_new_start_conditions()

        # check if valid volume capacity
        old_volume = self._get_volume(start_items)
        new_volume = products[item.name].volume * item.amount
        # TODO if load not enough -> handle less amount
        if not old_volume + new_volume <= self._load:
            log(self._node_name, task_string+'Not enough load capacity: ({'+str(new_volume)+'} + '+\
                    str(old_volume)+')/'+str(self._load)+'!', 'warn')
            return plan

        # select best resource node & compute route
        ws_pos = get_position(name=task.workshop_name,\
                instances=worldperception.facilities.workshops)
        best_resource_node = None
        best_route_to_resource_node = None
        best_route_to_workshop = None
        best_duration = sys.maxint
        for vrn in valid_resource_nodes:
            r1=routing.get_route(start_pos=start_pos, start_charge=start_charge, end_pos=vrn.pos)
            if len(r1.waypoints) > 0:
                r2=routing.get_route(start_pos=vrn.pos, start_charge=r1.waypoints[-1].charge,\
                        end_pos=ws_pos)
                if len(r2.waypoints) > 0 and best_duration > r1.duration + r2.duration:
                    best_resource_node = vrn
                    best_route_to_resource_node = r1
                    best_route_to_workshop = r2
                    best_duration = r1.duration + r2.duration

        if not best_route_to_resource_node or not best_route_to_workshop:
            # TODO better log
            log(self._node_name, task_string+'No best route existing!', 'warn')
            return plan

        # set resource node waypoint parameters
        rn_wp = best_route_to_resource_node.waypoints[-1]
        rn_wp.instance_name = vrn.name
        rn_wp.items = start_items + [Item(name=item.name, amount=item.amount,\
                reserved=True, job_id=task.job_id, stage_id=task.stage_id, task_id=task.task_id)]
        rn_wp.action = GenericAction(action_type=GatherResourceAction.ACTION)
        rn_wp.parts_at = item.amount
        rn_wp.steps_at = self._get_gathering_steps(item.amount)

        # set workshop waypoint parameters
        ws_wp = best_route_to_workshop.waypoints[-1]
        ws_wp.instance_name = task.workshop_name
        if old_volume + (products[product.name].volume * product.amount) > self._load:
            ws_wp.items = start_items
        else:
            ws_wp.items = start_items + [Item(name=product.name, amount=product.amount,\
                    reserved=True, job_id=task.job_id, stage_id=task.stage_id, task_id=task.task_id)]
        ws_wp.action = GenericAction(action_type=AssistAssembleAction.ACTION, product=product,\
                items=[item])
        ws_wp.parts_at = product.amount
        ws_wp.steps_at = product.amount

        # create route
        plan.route = Route(start_pos=best_route_to_resource_node.start_pos,\
                start_charge=best_route_to_resource_node.start_charge,\
                waypoints=best_route_to_resource_node.waypoints+best_route_to_workshop.waypoints)

        # update aggregated route parameters because of change e.g. duration
        routing.update_route(plan.route)

        plan.feasible = True
        plan.start_step = start_step
        return plan

    def process_retrieve_n_assemble_task(self, task):

        task_string = get_task_string(task=task)
        plan = RetrieveNAssemblePlan(bidder=self._agent_name, feasible=False, task=task)

        routing = self._routing
        products = self._products
        worldperception = self._worldperception

        if not self._initialized:
            log(self._node_name, task_string+'Not initialized yet!','err')
            return plan

        item = task.items[0]
        product = task.product

        # get start conditions
        start_step, start_charge, start_pos, start_items = self._planhandler._get_new_start_conditions()

        # check if valid volume capacity
        old_volume = self._get_volume(start_items)
        new_volume = products[item.name].volume * item.amount
        # TODO if load not enough -> handle less amount
        if not old_volume + new_volume <= self._load:
            log(self._node_name, task_string+'Not enough load capacity: ({'+str(new_volume)+'} + '+\
                    str(old_volume)+')/'+str(self._load)+'!', 'warn')
            return plan

        retrieve_st_pos = get_position(name=task.retrieve_storage_name,\
                instances=worldperception.facilities.storages)
        r1=routing.get_route(start_pos=start_pos,start_charge=start_charge,end_pos=retrieve_st_pos)
        if len(r1.waypoints) > 0:
            ws_pos = get_position(name=task.workshop_name,\
                    instances=worldperception.facilities.workshops)
            r2=routing.get_route(start_pos=retrieve_st_pos, start_charge=r1.waypoints[-1].charge,\
                    end_pos=ws_pos)

        if len(r1.waypoints) == 0 or len(r2.waypoints) == 0:
            # TODO better log
            log(self._node_name, task_string+'No best route existing!', 'warn')
            return plan

        # set retrieve storage waypoint parameters
        r_wp = r1.waypoints[-1]
        r_wp.instance_name = task.retrieve_storage_name
        r_wp.items = start_items + [Item(name=item.name, amount=item.amount,\
                reserved=True, job_id=task.job_id, stage_id=task.stage_id, task_id=task.task_id)]
        if task.stored:
            r_wp.action = GenericAction(action_type=RetrieveAction.ACTION, items=[item])
        else:
            r_wp.action = GenericAction(action_type=RetrieveDeliveredAction.ACTION, items=[item])
        r_wp.parts_at = 1
        r_wp.steps_at = 1

        # set workshop waypoint parameters
        ws_wp = r2.waypoints[-1]
        ws_wp.instance_name = task.workshop_name
        if old_volume + (products[product.name].volume * product.amount) > self._load:
            ws_wp.items = start_items
        else:
            ws_wp.items = start_items + [Item(name=product.name, amount=product.amount,\
                    reserved=True, job_id=task.job_id, stage_id=task.stage_id, task_id=task.task_id)]
        ws_wp.action = GenericAction(action_type=AssistAssembleAction.ACTION, product=product,\
                items=[item])
        ws_wp.parts_at = product.amount
        ws_wp.steps_at = product.amount

        # create route
        plan.route = Route(start_pos=r1.start_pos, start_charge=r1.start_charge,\
                waypoints=r1.waypoints+r2.waypoints)

        # update aggregated route parameters because of change e.g. duration
        routing.update_route(plan.route)

        plan.feasible = True
        plan.start_step = start_step
        return plan

    def process_assemble_task(self, task):
        '''
        For now: requires dependency.
        '''
        task_string = get_task_string(task=task)
        plan = AssemblePlan(bidder=self._agent_name, feasible=False, task=task)

        routing = self._routing
        products = self._products
        worldperception = self._worldperception

        if not self._initialized:
            log(self._node_name, task_string+'Not initialized yet!','err')
            return plan

        item = task.items[0]
        product = task.product

        # get start conditions
        start_step, start_charge, start_pos, start_items = self._planhandler._get_new_start_conditions()

        # check if a predecessor plan already temp assigned
        if not self._planhandler.get_predecessor_plan(task=task):
            log(self._node_name, task_string+'No temp assigned predecessor plan present!', 'warn')
            return plan

        '''
        # check if valid volume capacity
        old_volume = self._get_volume(start_items)
        new_volume = products[item.name].volume * item.amount
        # TODO if load not enough -> handle less amount
        if not old_volume + new_volume <= self._load:
            log(self._node_name, task_string+'Not enough load capacity: ({'+str(new_volume)+'} + '+\
                    str(old_volume)+')/'+str(self._load)+'!', 'warn')
            return plan
        '''

        # check if product in load
        product_exists = False
        for i in start_items:
            if i.reserved and i.job_id == task.job_id and i.task_id in task.predecessors and\
                    item.name == i.name and item.amount == i.amount:
                product_exists = True
                break

        if not product_exists:
            log(self._node_name, task_string+'Product '+get_items_string([item])+' not in load!', 'warn')
            return plan

        ws_pos=get_position(name=task.workshop_name, instances=worldperception.facilities.workshops)
        route=routing.get_route(start_pos=start_pos, start_charge=start_charge, end_pos=ws_pos)

        if len(route.waypoints) == 0 or route.duration >= sys.maxint:
            log(self._node_name, task_string+'No best route existing!', 'warn')
            return plan

        # set workshop waypoint parameters
        ws_wp = route.waypoints[-1]
        ws_wp.instance_name = task.workshop_name
        if self._get_volume(start_items) + (products[product.name].volume * product.amount) >\
                self._load:
            ws_wp.items = start_items
        else:
            ws_wp.items = start_items + [Item(name=product.name, amount=product.amount,\
                    reserved=True, job_id=task.job_id, stage_id=task.stage_id, task_id=task.task_id)]
        ws_wp.action = GenericAction(action_type=AssistAssembleAction.ACTION, product=product,\
                items=[item])
        ws_wp.parts_at = product.amount
        ws_wp.steps_at = product.amount

        # update aggregated route parameters because of change e.g. duration
        routing.update_route(route)

        plan.route = route
        plan.feasible = True
        plan.start_step = start_step
        return plan

    def process_gather_n_deliver_task(self, task):
        task_string = get_task_string(task=task)
        plan = GatherNDeliverPlan(bidder=self._agent_name, feasible=False, task=task)

        routing = self._routing
        products = self._products
        worldperception = self._worldperception

        if not self._initialized:
            log(self._node_name, task_string+'Not initialized yet!','err')
            return plan

        item = task.items[0]

        valid_resource_nodes = []
        for rn in worldperception.facilities.resources:
            if item.name in [i.name for i in rn.items]:
                valid_resource_nodes.append(rn)

        # check if valid resource nodes
        if len(valid_resource_nodes) == 0:
            log(self._node_name, task_string+'No resource node holding '+item.name+' explored yet!',\
                    'warn')
            return plan

        # get start conditions
        start_step, start_charge, start_pos, start_items = self._planhandler._get_new_start_conditions()

        # check if valid volume capacity
        old_volume = self._get_volume(start_items)
        new_volume = products[item.name].volume * item.amount
        # TODO if load not enough -> handle less amount
        if not old_volume + new_volume <= self._load:
            log(self._node_name, task_string+'Not enough load capacity: ({'+str(new_volume)+'} + '+\
                    str(old_volume)+')/'+str(self._load)+'!', 'warn')
            return plan

        # select best resource node & compute route
        st_pos = get_position(name=task.storage_name,\
                instances=worldperception.facilities.storages)
        best_resource_node = None
        best_route_to_resource_node = None
        best_route_to_storage = None
        best_duration = sys.maxint
        for vrn in valid_resource_nodes:
            r1=routing.get_route(start_pos=start_pos, start_charge=start_charge, end_pos=vrn.pos)
            if len(r1.waypoints) > 0:
                r2=routing.get_route(start_pos=vrn.pos, start_charge=r1.waypoints[-1].charge,\
                        end_pos=st_pos)
                if len(r2.waypoints) > 0 and best_duration > r1.duration + r2.duration:
                    best_resource_node = vrn
                    best_route_to_resource_node = r1
                    best_route_to_storage = r2
                    best_duration = r1.duration + r2.duration

        if not best_route_to_resource_node or not best_route_to_storage:
            # TODO better log
            log(self._node_name, task_string+'No best route existing!', 'warn')
            return plan

        # set resource node waypoint parameters
        rn_wp = best_route_to_resource_node.waypoints[-1]
        rn_wp.instance_name = vrn.name
        rn_wp.items = start_items + [Item(name=item.name, amount=item.amount,\
                reserved=True, job_id=task.job_id, stage_id=task.stage_id, task_id=task.task_id)]
        rn_wp.action = GenericAction(action_type=GatherResourceAction.ACTION)
        rn_wp.parts_at = item.amount
        rn_wp.steps_at = self._get_gathering_steps(item.amount)

        # set workshop waypoint parameters
        st_wp = best_route_to_storage.waypoints[-1]
        st_wp.instance_name = task.storage_name
        st_wp.items = start_items
        st_wp.action = GenericAction(action_type=DeliverAction.ACTION, items=[item])
        st_wp.parts_at = 1
        st_wp.steps_at = 1

        # create route
        plan.route = Route(start_pos=best_route_to_resource_node.start_pos,\
                start_charge=best_route_to_resource_node.start_charge,\
                waypoints=best_route_to_resource_node.waypoints+best_route_to_storage.waypoints)

        # update aggregated route parameters because of change e.g. duration
        routing.update_route(plan.route)

        plan.feasible = True
        plan.start_step = start_step
        return plan

    def process_retrieve_n_deliver_task(self, task):
        task_string = get_task_string(task=task)
        plan = RetrieveNDeliverPlan(bidder=self._agent_name, feasible=False, task=task)

        routing = self._routing
        products = self._products
        worldperception = self._worldperception

        if not self._initialized:
            log(self._node_name, task_string+'Not initialized yet!','err')
            return plan

        item = task.items[0]

        # get start conditions
        start_step, start_charge, start_pos, start_items = self._planhandler._get_new_start_conditions()

        # check if valid volume capacity
        old_volume = self._get_volume(start_items)
        new_volume = products[item.name].volume * item.amount
        # TODO if load not enough -> handle less amount
        if not old_volume + new_volume <= self._load:
            log(self._node_name, task_string+'Not enough load capacity: ({'+str(new_volume)+'} + '+\
                    str(old_volume)+')/'+str(self._load)+'!', 'warn')
            return plan

        retrieve_st_pos = get_position(name=task.retrieve_storage_name,\
                instances=worldperception.facilities.storages)
        r1=routing.get_route(start_pos=start_pos,start_charge=start_charge,end_pos=retrieve_st_pos)
        if len(r1.waypoints) > 0:
            st_pos = get_position(name=task.storage_name,\
                    instances=worldperception.facilities.storages)
            r2=routing.get_route(start_pos=retrieve_st_pos, start_charge=r1.waypoints[-1].charge,\
                    end_pos=st_pos)

        if len(r1.waypoints) == 0 or len(r2.waypoints) == 0:
            # TODO better log
            log(self._node_name, task_string+'No best route existing!', 'warn')
            return plan

        # set retrieve storage waypoint parameters
        r_wp = r1.waypoints[-1]
        r_wp.instance_name = task.retrieve_storage_name
        r_wp.items = start_items + [Item(name=item.name, amount=item.amount,\
                reserved=True, job_id=task.job_id, stage_id=task.stage_id, task_id=task.task_id)]
        if task.stored:
            r_wp.action = GenericAction(action_type=RetrieveAction.ACTION, items=[item])
        else:
            r_wp.action = GenericAction(action_type=RetrieveDeliveredAction.ACTION, items=[item])
        r_wp.parts_at = 1
        r_wp.steps_at = 1

        # set storage waypoint parameters
        st_wp = r2.waypoints[-1]
        st_wp.instance_name = task.storage_name
        st_wp.items = start_items
        st_wp.action = GenericAction(action_type=DeliverAction.ACTION, items=[item])
        st_wp.parts_at = 1
        st_wp.steps_at = 1

        # create route
        plan.route = Route(start_pos=r1.start_pos, start_charge=r1.start_charge,\
                waypoints=r1.waypoints+r2.waypoints)

        # update aggregated route parameters because of change e.g. duration
        routing.update_route(plan.route)

        plan.feasible = True
        plan.start_step = start_step
        return plan

    def process_deliver_task(self, task):
        '''
        For now: requires dependency.
        '''
        task_string = get_task_string(task=task)
        plan = DeliverPlan(bidder=self._agent_name, feasible=False, task=task)

        routing = self._routing
        products = self._products
        worldperception = self._worldperception

        if not self._initialized:
            log(self._node_name, task_string+'Not initialized yet!','err')
            return plan

        item = task.items[0]

        # get start conditions
        start_step, start_charge, start_pos, start_items = self._planhandler._get_new_start_conditions()

        # check if a predecessor plan already temp assigned
        if not self._planhandler.get_predecessor_plan(task=task):
            log(self._node_name, task_string+'No temp assigned predecessor plan present!', 'warn')
            return plan

        '''
        # check if valid volume capacity
        old_volume = self._get_volume(start_items)
        new_volume = products[item.name].volume * item.amount
        # TODO if load not enough -> handle less amount
        if not old_volume + new_volume <= self._load:
            log(self._node_name, task_string+'Not enough load capacity: ({'+str(new_volume)+'} + '+\
                    str(old_volume)+')/'+str(self._load)+'!', 'warn')
            return plan
        '''

        # check if product in load
        product_exists = False
        for i in start_items:
            if i.reserved and i.job_id == task.job_id and i.task_id in task.predecessors and\
                    item.name == i.name and item.amount == i.amount:
                product_exists = True
                break

        if not product_exists:
            log(self._node_name, task_string+'Product '+get_items_string([item])+' not in load!', 'warn')
            return plan

        st_pos=get_position(name=task.storage_name, instances=worldperception.facilities.storages)
        route=routing.get_route(start_pos=start_pos, start_charge=start_charge, end_pos=st_pos)

        if len(route.waypoints) == 0 or route.duration >= sys.maxint:
            log(self._node_name, task_string+'No best route existing!', 'warn')
            return plan

        # set resource node waypoint parameters
        d_wp = route.waypoints[-1]
        d_wp.instance_name = task.storage_name
        d_wp.items = start_items
        d_wp.action = GenericAction(action_type=DeliverAction.ACTION, items=[item])
        d_wp.parts_at = 1
        d_wp.steps_at = 1

        # update aggregated route parameters because of change e.g. duration
        routing.update_route(route)

        plan.route = route
        plan.feasible = True
        plan.start_step = start_step
        return plan

    # TODO maybe change threshold to min -> but drones
    def _get_gathering_steps(self, amount, threshold = 20.0):
        '''
        Get gathering time - role dependent number of steps to gather resources.
        Current server resource node threshold range: [10, 30] -> we take mid -> 20.
        '''
        return math.ceil(float(amount)*threshold/float(self._skill))

    def _get_volume(self, items):
        '''
        Compute the sum of the volume of the given items.
        :param items: the items to consider
        :type items: Item[]
        :return: overall volume
        :type: uint32
        '''
        volume = 0
        for i in items:
            if i.name in self._products:
                volume += i.amount * self._products[i.name].volume
        return volume
