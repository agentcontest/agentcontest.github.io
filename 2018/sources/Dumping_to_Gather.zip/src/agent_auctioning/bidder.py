#!/usr/bin/env python2

import rospy

from mac_ros_bridge.msg import SimStart, SimEnd, Bye

from mac_agent.msg import AuctionStageMsg, AuctionStageResponseMsg, WorldPerceptionMsg,\
        ClearTempPlansMsg, AbortJobMsg, UpdatePlansMsg

from mac_agent.srv import TempAssignPlanSrv, TempAssignPlanSrvResponse, UpdateTempAssignedPlanSrv,\
        UpdateTempAssignedPlanSrvResponse, FinalAssignPlanSrv, FinalAssignPlanSrvResponse,\
        AssignedPlansSrv

from agent_mutual.agent_utils import log, get_bridge_topic_prefix, get_agent_topic_prefix,\
        get_auctioneer_topic_prefix, get_current_timestamp, zip_plans, unzip_plans, get_team_name

from agent_auctioning.routing import Routing
from agent_auctioning.task_handler import TaskHandler
from agent_auctioning.plan_handler import PlanHandler

class Bidder(object):
    '''
    This ros node is responsibe for responding to the auctioneers auction stage requests as well as
    managing & forwarding the task & plan related data that is required for the corresponding agent to 
    be able to participate in the job completion process.
    '''
    def __init__(self):
        '''
        Constructor.
        '''
        rospy.init_node('bidder_node', anonymous=True, log_level=rospy.INFO)

        self._agent_name = rospy.get_param('~agent_name')
        self._agent_number = rospy.get_param('~agent_number')

        self._bidder_name = 'bidder_'+self._agent_name
        self._bridge_topic_prefix = get_bridge_topic_prefix(agent_name=self._agent_name)
        self._agent_topic_prefix = get_agent_topic_prefix(agent_name=self._agent_name)

        self._role = None
        self._routing = None

        self._planhandler = PlanHandler(agent_name=self._agent_name, node_name=self._bidder_name)
        self._taskhandler = TaskHandler(agent_name=self._agent_name, node_name=self._bidder_name,\
                planhandler=self._planhandler)

        rospy.Subscriber(self._bridge_topic_prefix + "start", SimStart, self._sim_start_callback)
        rospy.Subscriber(self._agent_topic_prefix + "worldperception", WorldPerceptionMsg,\
                self._worldperception_callback)
        rospy.Subscriber(self._bridge_topic_prefix + "end", SimEnd, self._sim_end_callback)
        rospy.Subscriber(self._bridge_topic_prefix + "bye", Bye, self._bye_callback)

        rospy.Subscriber(get_team_name()+"/auction_stage", AuctionStageMsg,\
                self._auction_stage_callback, queue_size=self._agent_number)
        rospy.Subscriber(get_team_name()+"/clear_temp_plans", ClearTempPlansMsg,\
                self._clear_temp_plans_callback, queue_size=self._agent_number)
        rospy.Subscriber(get_team_name()+"/abort_job", AbortJobMsg, self._abort_job_callback,\
                queue_size=self._agent_number)

        rospy.Subscriber("~update_plans", UpdatePlansMsg, self._update_plans_callback,\
                queue_size=self._agent_number)

        rospy.Service('~temp_assign_plan', TempAssignPlanSrv, self._temp_assign_plan_request)
        rospy.Service('~update_temp_assigned_plan', UpdateTempAssignedPlanSrv,\
                self._update_temp_assigned_plan_request)
        rospy.Service('~final_assign_plan', FinalAssignPlanSrv, self._final_assign_plan_request)

        self._srv_proxy_assigned_plans = rospy.ServiceProxy(self._agent_topic_prefix+'assigned_plans',\
                AssignedPlansSrv)

        self._worldperception_arrived = False
        self._sim_started = False

        log(self._bidder_name, "Bidder initialized!")

    def _reset(self):

        del self._sim_started

        self._role = None
        self._routing = None

        self._planhandler.reset()
        self._taskhandler.reset()

        self._worldperception_arrived = False
        self._sim_started = False

    def _sim_start_callback(self, msg):
        '''
        Callback for the sim-start message.
        :param msg: the message
        :type msg: SimStart
        '''
        # wait until initialized
        while not self._has_been_initialized():
            log(self._bidder_name, 'Not initialized yet!', 'err')
            rospy.sleep(0.1)

        if not self._sim_started:
            self._role = msg.role
            self._routing = Routing(node_name=self._bidder_name, role=msg.role, cell_size=msg.cell_size,\
                    proximity=msg.proximity, map_name=msg.map)
            self._taskhandler.init(role=msg.role, products=msg.products, routing=self._routing)
            self._planhandler.init(role=msg.role, routing=self._routing)
            self._sim_started = True
            log(self._bidder_name, "(SimStart) Bidder started!")

    def _has_been_initialized(self):
        return hasattr(self, '_sim_started')

    def _worldperception_callback(self, msg):
        '''
        Callback for the worldperception message.
        :param msg: the message
        :type msg: WorldPerceptionMsg
        '''
        if not self._has_been_initialized() or not self._sim_started:
            log(self._bidder_name, 'SimStart not arrived yet!', 'err')
            return

        self._worldperception = msg.worldperception
        self._routing.update_facilites(self._worldperception.facilities)
        self._taskhandler.update_worldperception(self._worldperception)
        self._planhandler.update_worldperception(self._worldperception)
        self._worldperception_arrived = True

    def _auction_stage_callback(self, msg):
        '''
        Callback for the auction stage requests. Processes each task individually.
        :param msg: the message
        :type msg: AuctionStageMsg
        '''
        if not self._worldperception_arrived:
            log(self._bidder_name, "Worldperception not arrived yet!", 'err')
            return

        response = AuctionStageResponseMsg(timestamp=msg.timestamp, bidder=self._agent_name,\
                role=self._role.name, job_id=msg.job_id, auction_id=msg.auction_id, stage_id=msg.stage_id)

        # compute plans to solve the given tasks
        for task in msg.assemble_tasks:
            response.assemble_plans.append(self._taskhandler.process_assemble_task(task=task))
        for task in msg.deliver_tasks:
            response.deliver_plans.append(self._taskhandler.process_deliver_task(task=task))
        for task in msg.gather_n_assemble_tasks:
            response.gather_n_assemble_plans.append(\
                    self._taskhandler.process_gather_n_assemble_task(task=task))
        for task in msg.gather_n_deliver_tasks:
            response.gather_n_deliver_plans.append(\
                    self._taskhandler.process_gather_n_deliver_task(task=task))
        for task in msg.retrieve_n_assemble_tasks:
            response.retrieve_n_assemble_plans.append(\
                    self._taskhandler.process_retrieve_n_assemble_task(task=task))
        for task in msg.retrieve_n_deliver_tasks:
            response.retrieve_n_deliver_plans.append(\
                    self._taskhandler.process_retrieve_n_deliver_task(task=task))

        if not self._worldperception_arrived:
            log(self._bidder_name, "Worldperception not arrived yet!", 'err')
            return

        # add plans to planhandler
        self._planhandler.add_unassigned_plans(job_id=msg.job_id, stage_id=msg.stage_id,\
                plans=response.assemble_plans+response.deliver_plans+\
                response.gather_n_assemble_plans+response.gather_n_deliver_plans+\
                response.retrieve_n_assemble_plans+response.retrieve_n_deliver_plans)

        # send back auction stage response
        rospy.Publisher(get_auctioneer_topic_prefix(msg.auctioneer)+'auction_stage_response',\
                AuctionStageResponseMsg, queue_size=1, latch=True).publish(response)

    def _temp_assign_plan_request(self, request):
        '''
        Triggers the processing of the temp assign plan service request and returns a response.
        :param request: the service request
        :type request: TempAssignPlanSrv
        '''
        if not self._worldperception_arrived:
            log(self._bidder_name, "Worldperception not arrived yet!", 'err')
            return TempAssignPlanSrvResponse(ack=False, start_step=0, route=None)

        ack, start_step, route = self._planhandler.temp_assign_plan(request)
        return TempAssignPlanSrvResponse(ack=ack, start_step=start_step, route=route)

    def _update_temp_assigned_plan_request(self, request):
        if not self._worldperception_arrived:
            log(self._bidder_name, "Worldperception not arrived yet!", 'err')
            return UpdateTempAssignedPlanSrvResponse(ack=False, items=[])

        ack, items = self._planhandler.update_temp_assigned_plan(request)
        return UpdateTempAssignedPlanSrvResponse(ack=ack, items=items)

    def _final_assign_plan_request(self, request):
        '''
        Triggers the processing of the final assign plan service request and returns a response.
        Publishes assigned plans in case they changed.
        :param request: the service request
        :type request: FinalAssignPlanSrv
        '''
        if not self._worldperception_arrived:
            log(self._bidder_name, "Worldperception not arrived yet!", 'err')
            return FinalAssignPlanSrvResponse(ack=False, route=None)

        ack, route = self._planhandler.final_assign_plan(request)
        if ack:
            self._send_assigned_plans_update()
        return FinalAssignPlanSrvResponse(ack=ack, route=route)

    def _send_assigned_plans_update(self):
        '''
        Sends the currently assigned plans by service and gets back updated assigned plan list.
        Received by the ExecutePlanBehaviour. (syncronizes plans)
        '''
        plans = zip_plans(self._planhandler.get_assigned_plans())
        success = False
        # send until succesful
        while not success:
            try:
                response = self._srv_proxy_assigned_plans(timestamp=get_current_timestamp(), plans=plans)
                success = response.ack
                # updated planlist
                self._planhandler.update_assigned_plans(unzip_plans(plans=response.plans))
            except rospy.ServiceException, e:
                log(self._bidder_name, 'Assigned Plans - service call failed: '+str(e) , 'err')
                success = False

    def _clear_temp_plans_callback(self, msg):
        '''
        Callback method for removing the temp assigned plans of a given job.
        :param msg: the message
        :type msg: ClearTempPlansMsg
        '''
        if not self._worldperception_arrived:
            log(self._bidder_name, "Worldperception not arrived yet!", 'err')
            return

        self._planhandler.clear_temp_plans(msg.job_id)

    def _abort_job_callback(self, msg):
        '''
        Callback method for job abortion. Cancels corresponding plans. Triggers updating of the assigned
        plans if abortion affected assigned plans.
        :param msg: the message
        :type msg: AbortJobMsg
        '''
        if not self._worldperception_arrived:
            log(self._bidder_name, "Worldperception not arrived yet!", 'err')
            return

        if self._planhandler.abort_job(msg.job_id):
            self._send_assigned_plans_update()

    def _update_plans_callback(self, msg):
        '''
        Callback method for the update plans message. Triggers the synchronization of the assigned plans
        of the plan handler with the corresponding rhbp agent.
        '''
        if not self._worldperception_arrived:
            log(self._bidder_name, "Worldperception not arrived yet!", 'err')
            return

        self._send_assigned_plans_update()

    def _sim_end_callback(self, msg):
        """
        Callback method for the SimEnd message.
        :param msg:  the message
        :type msg: SimEnd
        """
        log(self._bidder_name, "(SimEnd) "+str(msg))
        self._reset()

    def _bye_callback(self, msg):
        """
        Callback method for the Bye message.
        :param msg:  the message
        :type msg:  Bye
        """
        log(self._bidder_name, "(Bye) "+str(msg))
        log(self._bidder_name, "Simulation finished")
        rospy.signal_shutdown('Shutting down {}  - Simulation server closed'.format(self._bidder_name))

if __name__ == '__main__':

    try:
        bidder = Bidder()
        rospy.spin()

    except rospy.ROSInterruptException:
        rospy.logerr("program interrupted before completion")
