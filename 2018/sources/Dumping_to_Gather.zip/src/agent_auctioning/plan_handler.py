#!/usr/bin/env python2

from agent_mutual.agent_utils import log

from agent_rhbp.actions import AssembleAction, AssistAssembleAction

class PlanHandler(object):
    '''
    This class manages, updates and synchronizes the plans created by the taskhandler for participating in
    a certain job. There are 3 types of plans: unassigned, temp assigned and assigned plans, where only
    the assigned plans are going to be executed, while the others are part of an ongoing auctioning
    process of possibly different auctions.
    '''
    def __init__(self, agent_name, node_name):
        '''
        Constructor.
        :param agent_name: the agents name this planhandler belongs to
        :type agent_name: string
        :param node_name: the nodes name this planhandler belongs to
        :type node_name: string
        '''
        self._agent_name = agent_name
        self._node_name = node_name

        self._role = None
        self._routing = None
        self._worldperception = None

        self._unassigned_plans = {}
        self._temp_assigned_plans = []
        self._assigned_plans = []

    def reset(self):
        self._role = None
        self._routing = None
        self._worldperception = None

        self._unassigned_plans = {}
        self._temp_assigned_plans = []
        self._assigned_plans = []

    def init(self, role, routing):
        '''
        Hands over role of the corresponding agent and routing instance to recompute routes.
        :param role: the agents role
        :type role: Role
        :param routing: an instance of the routing class
        :type routing: Routing
        '''
        self._role = role
        self._routing = routing

    def update_worldperception(self, worldperception):
        '''
        Updates worldperception.
        :param worldperception: the current worldperception
        :type worldperception: WorldPerception
        '''
        self._worldperception = worldperception

    def update_assigned_plans(self, new_assigned_plans):
        '''
        Updates the currently assigned plans.
        :param new_assigned_plans: the new plans
        :type new_assigned_plans: Plan[]
        '''
        self._assigned_plans = new_assigned_plans

    def add_unassigned_plans(self, job_id, stage_id, plans):
        '''
        Adds the given plans to the unassigned plans dictionary.
        :param job_id: the job id the plans correspond to
        :type job_id: string
        :param stage_id: id of the stage
        :type stage_id: uint32
        :param plans: the list of plans to add
        :type plans: Plan[]
        '''
        if job_id not in self._unassigned_plans:
            self._unassigned_plans[job_id] = {}
        if stage_id not in self._unassigned_plans[job_id]:
            self._unassigned_plans[job_id][stage_id] = {}
        for p in plans:
            if p.task.task_id in self._unassigned_plans[job_id][stage_id]:
                log(self._node_name,'Plan for Job '+job_id+' Task '+str(p.task.task_id)+\
                        ' already existing! Overwrite!', 'err')
            self._unassigned_plans[job_id][stage_id][p.task.task_id] = p

    def temp_assign_plan(self, request):
        '''
        Checks if the previously created unassigned plan is still possible to execute, updates the route,
        tries to temporarily assign the corresponding plan and returns the updated route.
        :param request: the temp assign plan service request message
        :type request: TempAssignPlanSrv
        :return ack: if temp assign success true else false
        :type ack: bool
        :return route: the updated route
        :type route: Route
        '''
        ack = True
        if request.job_id not in self._unassigned_plans or\
                request.stage_id not in self._unassigned_plans[request.job_id] or\
                request.task_id not in self._unassigned_plans[request.job_id][request.stage_id]:
            log(self._node_name, 'Plan not existent!', 'warn')
            ack = False
            return ack, 0, None

        plan = self._unassigned_plans[request.job_id][request.stage_id][request.task_id]

        # TODO maybe comment out again...
        # add waiting time
        plan.route.waypoints[-1].steps_at += request.waiting_time

        # update if old
        if plan.start_step < request.start_step:
            plan.start_step = request.start_step
            plan.route.start_pos=self._worldperception.agent.pos
            plan.route.start_charge=self._get_charge(self._worldperception.agent.charge)

        if self._routing.is_route_still_possible(plan.route):
            # only updates duration estimated duration for now
            self._routing.update_route(plan.route)
            # insert plan into temp assigned plans list
            ack = self._insert_temp_assigned_plan(plan)
        else:
            log(self._node_name, 'Route is not possible anymore!', 'warn')
            ack = False

        if ack:
            # update plans start step
            end_plan = self._get_last_temp_assigned_or_assigned_plan()
            if not end_plan:
                plan.start_step = end_plan.start_step + end_plan.route.duration + 1

            # update predecessor plan
            predecessor_plan = self.get_predecessor_plan(task=plan.task)
            if predecessor_plan:
                wp = predecessor_plan.route.waypoints[-1]
                if wp.action.action_type == AssistAssembleAction.ACTION:
                    wp.action.action_type = AssembleAction.ACTION

        return ack, plan.start_step, plan.route

    def update_temp_assigned_plan(self, request):
        plan = self._get_temp_assigned_plan(job_id=request.job_id, auction_id=request.auction_id,\
                stage_id=request.stage_id, task_id=request.task_id)

        ack = False
        items = None
        if plan:
            # set specific parameters
            if plan.route.waypoints[-1].action.action_type == AssistAssembleAction.ACTION:
                plan.route.waypoints[-1].action.agent = request.assemble_agent
                # remove product items
                for i in plan.route.waypoints[-1].items:
                    if i.job_id == plan.task.job_id and i.task_id == plan.task.task_id:
                        plan.route.waypoints[-1].items.remove(i)
                ack = True
                items = plan.route.waypoints[-1].items
        return ack, items

    def final_assign_plan(self, request):
        '''
        Tries to finally assign a previous temp assigned plan.
        :param request: the temp assign plan service request message
        :type request: TempAssignPlanSrv
        :return route: None for now...
        :type route: Route
        '''
        plan = self._get_temp_assigned_plan(job_id=request.job_id, auction_id=request.auction_id,\
                stage_id=request.stage_id, task_id=request.task_id)

        ack = False
        if plan:
            # insert
            ack = self._insert_final_assigned_plan(plan)

        return ack, None

    def get_predecessor_plan(self, task):
        if task.dependent:
            for p in self.get_temp_assigned_plans():
                if p.task.task_id in task.predecessors and p.task.job_id == task.job_id and\
                        p.task.auction_id == task.auction_id:
                    return p
        return None

    def _get_temp_assigned_plan(self, job_id, auction_id, stage_id, task_id):
        plan = None
        for p in self._temp_assigned_plans:
            if job_id == p.task.job_id and auction_id == p.task.auction_id and\
                    stage_id == p.task.stage_id and task_id == p.task.task_id:
                plan = p
                break
        if not plan:
            log(self._node_name, 'Temp assigned plan ['+str(job_id)+' auction #'+\
                    str(auction_id)+' stage #'+str(stage_id)+' task #'+str(task_id)+'] does not exist!',\
                    'err')
        return plan

    def _get_charge(self, charge):
        '''
        Computes the new charge with a security buffer.
        :param charge: the charge
        :type charge: uint32
        :return: buffered charge
        :type: uint32
        '''
        # TODO maybe with buffer again
        buffer_steps = 0
        if charge - buffer_steps < 0:
            return 0
        else:
            return charge - buffer_steps

    def _insert_temp_assigned_plan(self, plan):
        '''
        Tries to insert a plan into the temporarily assigned plans array and returns if successful.
        :param plan: the plan to temporary assign
        :type plan: Plan
        :return: if plan has been inserted True else False
        :type: bool
        '''
        if self._check_if_plan_fits(plan=plan, plans=self._assigned_plans):
            return self._insert_plan(plan=plan, plans=self._temp_assigned_plans)
        return False

    def _check_if_plan_fits(self, plan, plans):
        '''
        Checks if the given plan fits into the given plan list.
        It fits if the planned times don't overlap.
        :param plan: the plan to check if fitting
        :type plan: Plan
        :param plans: the plan list
        :type plans: Plan[]
        :return: if plan fits True else False
        :type: bool
        '''
        for p in plans:
            if not (plan.start_step > p.start_step + p.route.duration or\
                    plan.start_step + plan.route.duration < p.start_step):
                return False
        return True

    def _insert_plan(self, plan, plans):
        '''
        Tries to insert the given plan into the given plan list. Planned times may not overlap.
        :param plan: the plan to check if fitting
        :type plan: Plan
        :param plans: the plan list
        :type plans: Plan[]
        :return: if plan has been inserted True else False
        :type: bool
        '''
        # TODO
        #if len(plans) > 0:
        #    plan.start_step = plans[-1].start_step + plans[-1].route.duration + 1
        #plans.append(plan)
        #return True

        # only append for now
        if len(plans) == 0 or plan.start_step > plans[-1].start_step + plans[-1].route.duration:
            plans.append(plan)
            return True
        else:
            return False

    def _insert_final_assigned_plan(self, plan):
        '''
        Tries to finally insert a plan into the assigned plans array and returns if successful.
        :param plan: the plan to finally assign
        :type plan: Plan
        :return: if plan has been inserted True else False
        :type: bool
        '''
        ack = self._insert_plan(plan=plan, plans=self._assigned_plans)
        if not ack:
            log(self._node_name, 'Failed to insert temp assigned plan ['+str(plan.task.job_id)+\
                    ' auction #'+str(plan.task.auction_id)+' stage #'+str(plan.task.stage_id)+\
                    ' task #'+str(plan.task.task_id)+'] into final assigned plans!', 'warn')
        return ack

    def get_temp_assigned_plans(self):
        '''
        Returns the currently temp assigned plans.
        :return assigned_plans: the currently temp assigned plans
        :type assigned_plans: Plan[]
        '''
        return self._temp_assigned_plans

    def get_assigned_plans(self):
        '''
        Returns the currently assigned plans.
        :return assigned_plans: the currently assigned plans
        :type assigned_plans: Plan[]
        '''
        return self._assigned_plans

    def clear_temp_plans(self, job_id):
        '''
        Removes unassigned and temporary assigned plans which correspond to the given job id.
        :param job_id: the id
        :type job_id: string
        '''
        self._unassigned_plans.pop(job_id, None)
        idx = 0
        for i in range(len(self._temp_assigned_plans)):
            plan = self._temp_assigned_plans[idx]
            if plan.task.job_id == job_id:
                self._temp_assigned_plans.remove(plan)
            else:
                idx += 1

    def abort_job(self, job_id):
        '''
        Cancels all assigned plans that correspond to the given job id. Returns if a plan has been
        canceled.
        :param job_id: the id
        :type job_id: string
        :return: if a plan has been canceled
        :type: bool
        '''
        aborted = False
        idx = 0
        for i in range(len(self._assigned_plans)):
            plan = self._assigned_plans[idx]
            if plan.task.job_id == job_id:
                log(self._node_name, 'Abort executing plan [job_id='+job_id+', task #'+\
                        str(plan.task.task_id)+']!', 'warn')
                self._assigned_plans.remove(plan)
                aborted = True
            else:
                idx += 1
        return aborted

    def _get_new_start_conditions(self):
        '''
        Returns start parameters for a for computing a new route. Takes already assigned plans and
        temp assigned plans into consideration.
        :return start_step: the start step
        :type start_step: uint32
        :return start_charge: the start charge
        :type start_charge: uint32
        :return start_pos: the start position
        :type start_pos: Position
        :return start_items: the start items
        :type start_items: Item[]
        '''
        if self._do_ongoing_plans_exist():

            end_plan = self._get_last_temp_assigned_or_assigned_plan()

            if not end_plan:
                return self._get_new_start_conditions()

            start_step = end_plan.start_step + end_plan.route.duration + 1
            start_charge = end_plan.route.waypoints[-1].charge
            start_pos = end_plan.route.waypoints[-1].pos
            start_items = end_plan.route.waypoints[-1].items

            # redo if plans have been removed
            if not self._do_ongoing_plans_exist():
                return self._get_new_start_conditions()
        else:
            start_step = self._worldperception.simulation_step
            start_charge = self._get_charge(self._worldperception.agent.charge)
            start_pos = self._worldperception.agent.pos
            start_items = self._worldperception.agent.items

            # redo if plans have been added
            if self._do_ongoing_plans_exist():
                return self._get_new_start_conditions()

        return start_step, start_charge, start_pos, start_items

    def _do_ongoing_plans_exist(self):
        '''
        Returns if there are assigned or temp assigned plans to do now or in the future.
        :return: if no plans exist False else True
        :type: bool
        '''
        for p in self._temp_assigned_plans + self._assigned_plans:
            if p.start_step + p.route.duration > self._worldperception.simulation_step:
                return True
        return False

    def _get_last_temp_assigned_or_assigned_plan(self):
        last_temp_ass, last_ass = None, None
        last_temp_ass_end, last_ass_end = 0, 0

        # for now choose end of plan lists
        if len(self._temp_assigned_plans) > 0:
            last_temp_ass = self._temp_assigned_plans[-1]
            last_temp_ass_end = last_temp_ass.start_step + last_temp_ass.route.duration
        if len(self._assigned_plans) > 0:
            last_ass = self._assigned_plans[-1]
            last_ass_end = last_ass.start_step + last_ass.route.duration

        return last_temp_ass if last_temp_ass_end > last_ass_end else last_ass

    def get_number_of_temp_assigned_and_assigned_plans(self):
        '''
        Returns number of all temp and final assigned plans summed together.
        :return: number of plans
        :type: uint32
        '''
        return len(self._temp_assigned_plans) + len(self._assigned_plans)
