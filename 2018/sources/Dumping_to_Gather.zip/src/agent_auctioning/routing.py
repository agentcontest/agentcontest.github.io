#!/usr/bin/env python2

import sys
import math

from mac_utils.graphhopper import PathPlanner

from agent_mutual.agent_utils import log, get_team_name, get_duration

from mac_ros_bridge.msg import GenericAction, Agent
from mac_agent.msg import WayPoint, Route

from agent_rhbp.actions import ChargeAction

try:
    from Queue import PriorityQueue # ver. < 3.0
except ImportError:
    from queue import PriorityQueue

class Routing(object):
    '''
    This class uses the graphhopper to precalculate, update or check the possibility of still being able
    to execute routes that are used for accomplishing certain tasks.
    '''
    # TODO maybe change
    buffered_ratio = 1.05

    def __init__(self, node_name, role, cell_size, proximity, map_name):
        '''
        Constructor.
        :param node_name: name of the corresponding node
        :type node_name: string
        :param role: the corresponding agents role
        :type role: Role
        :param cell_size: the cell size
        :type cell_size: uint
        :param proximity: the proximity
        :type proximity: float
        :param map_name: the map name
        :type map_name: string
        '''
        self._node_name = node_name

        # TODO update pathplanner & role if upgraded
        self.pathplanner = PathPlanner(role=role, agent=Agent(speed=role.base_speed),\
                cell_size=cell_size, proximity=proximity, team_name=get_team_name())
        self.pathplanner.set_map(map_name)
        self._role = role

        # TODO update if upgraded
        self._battery_size = self._role.base_battery

        log(self._node_name, "Routing initialized!")

    def update_facilites(self, facilities):
        '''
        Updates the current facilities.
        :param facilities: new facilities
        :type facilities: Facilities
        '''
        self._facilities = facilities

    def get_route(self, start_pos, start_charge, end_pos):
        '''
        Computes a route from the given start position with the given start charge to the given end
        position considering charge such that charging stations are added to the route as waypoints.
        :param start_pos: the position to start from
        :type start_pos: Position
        :param start_charge: the charge to start the route with
        :type start_charge: uint32
        :param end_pos: the position to end at
        :type end_pos: Position
        :return: the route
        :type: Route
        '''
        _,end_cs_steps=self.get_real_closest(instances=self._facilities.charging_stations, pos=end_pos)
        waypoints = self._build_route(start_pos=start_pos, start_charge=start_charge, end_pos=end_pos,\
                end_cs_steps=end_cs_steps)
        if not waypoints or len(waypoints) == 0 or waypoints[-1] == None:
            return Route(duration=sys.maxint)
        return Route(start_pos=start_pos, start_charge=start_charge,\
                duration=self._get_buffered_duration(waypoints), waypoints=waypoints)

    def _build_route(self, start_pos, start_charge, end_pos,end_cs_steps, charging_stations = None):
        '''
        Builds list of waypoints with the given start conditions. Adds charging stations as waypoints
        if charge is needed.
        :param start_pos: the position to start from
        :type start_pos: Position
        :param start_charge: the charge to start the route with
        :type start_charge: uint32
        :param end_pos: the position to end at
        :type end_pos: Position
        :param end_cs_steps: the steps from the end position to the closest charging station
        :type end_cs_steps: uint32
        :return: the list of waypoints
        :type: Waypoint[]
        '''
        if not charging_stations:
            css = []
        else:
            css = [] + charging_stations

        d = self.pathplanner.number_of_required_steps_to_facility(start_pos, end_pos)
        if start_charge >= d + end_cs_steps:
            return [WayPoint(pos=end_pos, charge=start_charge-d, steps_to=d, steps_at=0, parts_at=0)]
        else:
            cs, duration = self._get_real_charging_station_inbetween(start_pos=start_pos,\
                    start_charge=start_charge, end_pos=end_pos,\
                    dont_visit_charging_stations=css)
            # try to avoid cycles
            if cs == None:
                return [None]
            else:
                css.append(cs.name)

            charge_time = int(math.ceil(float(self._battery_size-(start_charge-duration))/cs.rate))
            return [WayPoint(instance_name=cs.name, pos=cs.pos, steps_to=duration, steps_at=charge_time,\
                    parts_at=charge_time, charge=start_charge-duration,\
                    action=GenericAction(action_type=ChargeAction.ACTION))]+\
                    self._build_route(start_pos=cs.pos, start_charge=self._battery_size,\
                    end_pos=end_pos, end_cs_steps=end_cs_steps, charging_stations=css)

    def _get_real_charging_station_inbetween(self, start_pos, start_charge, end_pos,\
            dont_visit_charging_stations):
        '''
        Computes the charging station between the given start and end position such that the step duration
        of the path from start position to the charging station to the end position is minimized.
        :param start_pos: the position to start from
        :type start_pos: Position
        :param start_charge: the charge to start the route with
        :type start_charge: uint32
        :param end_pos: the position to end at
        :type end_pos: Position
        :return: the charging station and the duration to the charging station
        :type: ChargingStation, uint32
        '''
        charging_stations = self._get_euclidean_charging_station_inbetween(start_pos, end_pos,\
                num_best=int(len(self._facilities.charging_stations)/3))
        charging_station = None
        overallduration = sys.maxint
        duration = sys.maxint
        for cs in charging_stations:
            # prevent to return same charging station
            if cs.name not in dont_visit_charging_stations and\
                    (start_pos.lat != cs.pos.lat or start_pos.long != cs.pos.long):
                d1 = self.pathplanner.number_of_required_steps_to_facility(start_pos, cs.pos)
                if start_charge >= d1:
                    d2 = self.pathplanner.number_of_required_steps_to_facility(cs.pos, end_pos)
                    if overallduration > d1 + d2:
                        charging_station = cs
                        overallduration = d1 + d2
                        duration = d1
        if not charging_station:
            log(self._node_name,'No charging station in range! battery_size='+str(self._battery_size)+\
                    ' charge='+str(start_charge), 'warn')
        return charging_station, duration

    def _get_euclidean_charging_station_inbetween(self, start_pos, end_pos, num_best = 5):
        '''
        Computes the best charging stations between the given start and end position such that
        the euclidean distance from start position to the charging station to the end position
        is minimized.
        :param start_pos: the position to start from
        :type start_pos: Position
        :param end_pos: the position to end at
        :type end_pos: Position
        :param num_best: number of best charging stations to return
        :type num_best: uint32
        :return: list of the best charging stations
        :type: ChargingStation[]
        '''
        q = PriorityQueue()
        for cs in self._facilities.charging_stations:
            d = PathPlanner.euclidean_distance(start_pos, cs.pos)+\
                    PathPlanner.euclidean_distance(cs.pos, end_pos)
            q.put((d, cs))
        return [q.get()[1] for _ in range(min([len(self._facilities.charging_stations), num_best]))]

    def get_real_closest(self, instances, pos):
        '''
        Returns the instance that is closest to the given position (steps).
        :param instances: instances with a pos attribute
        :type instances: facilities or agents
        :param pos: the reference position
        :type pos: Position
        :return: the chosen instance and the step duration to this instance
        :type: Facility/Agent, uint32
        '''
        ins = self._get_euclidean_closest(instances=instances, pos=pos)
        chosen = None
        duration = sys.maxint
        for i in ins:
            d = self.pathplanner.number_of_required_steps_to_facility(pos, i.pos)
            if duration > d:
                chosen = i
                duration = d
        return chosen, duration

    def _get_euclidean_closest(self, instances, pos, num_best = 10):
        '''
        Returns the instances that are closest to the given position (euclidean).
        :param instances: instances with a pos attribute
        :type instances: facilities or agents
        :param pos: the reference position
        :type pos: Position
        :param num_best: number of best charging stations to return
        :type num_best: uint32
        :return: the best instances
        :type: Facility/Agent[]
        '''
        q = PriorityQueue()
        for i in instances:
            q.put((PathPlanner.euclidean_distance(i.pos, pos), i))
        return [q.get()[1] for _ in range(min([len(instances),num_best]))]

    def update_route(self, route):
        '''
        For now only updates the given route's duration (buffered).
        :param route: route to update
        :type route: Route
        '''
        # TODO buffer or not?
        route.duration = self._get_buffered_duration(route.waypoints)
        #route.duration = get_duration(route.waypoints)

    def _get_buffered_duration(self, waypoints):
        '''
        Returns the buffered duration to traverse along the given Waypoints.
        :param waypoints: the waypoints to consider
        :type waypoints: Waypoint[]
        :return: the buffered duration
        :type: uint32
        '''
        return int(math.ceil(Routing.buffered_ratio*get_duration(waypoints)))

    def is_route_still_possible(self, route):
        '''
        Checks if the given route is still possible to execute.
        Updates waypoint attributes & checks if there will be sufficient charge.
        :param route: the route to check and update
        :type route: Route
        :return: if still possible True else False
        :type: bool
        '''
        for idx, wp in enumerate(route.waypoints):
            if idx == 0:
                d = self.pathplanner.number_of_required_steps_to_facility(route.start_pos, wp.pos)
                wp.charge = route.start_charge - d
            else:
                d = self.pathplanner.number_of_required_steps_to_facility(route.waypoints[idx-1].pos,\
                        wp.pos)
                wp.charge = route.waypoints[idx-1].charge - d
            wp.steps_to = d

            if wp.charge < 0:
                return False

            if wp.action.action_type == ChargeAction.ACTION:
                cs = self._get_charging_station(wp.instance_name)
                while self._battery_size > wp.charge + wp.steps_at*cs.rate:
                    wp.steps_at += 1
                    wp.parts_at += 1
                return True

        # check charge to end charging station
        _,end_cs_steps = self.get_real_closest(instances=self._facilities.charging_stations,\
                pos=route.waypoints[-1].pos)
        if route.waypoints[-1].charge - end_cs_steps < 0:
            return False
        else:
            return True

    def _get_charging_station(self, name):
        '''
        Returns the charging station with the given name.
        :param name: charging station name
        :type name: string
        :return: the charging station
        :type: ChargingStation
        '''
        for cs in self._facilities.charging_stations:
            if cs.name == name:
                return cs

    def update_waypoints(self, start_index, route):
        '''
        Updates the given route such that the charge at all waypoints is consistent and the route duration
        is updated, beginning with the given waypoint index.
        :param start_index: the index of the waypoint to start from
        :type start_index: uint
        :param route: the route to update
        :type route: Route
        '''
        current_wp = route.waypoints[start_index]
        for idx, wp in enumerate(route.waypoints[start_index+1:]):
            if not wp.skip:
                route=self.get_route(start_pos=current_wp.pos,\
                        start_charge=current_wp.charge, end_pos=wp.pos)
                if len(route.waypoints) > 0:
                    wp.charge = route.waypoints[-1].charge
                    wp.steps_to = route.waypoints[-1].steps_to
                else:
                    d = self.pathplanner.number_of_required_steps_to_facility(current_wp.pos, wp.pos)
                    wp.charge = current_wp.charge - d
                    wp.steps_to = d

                if wp.action.action_type == ChargeAction.ACTION:
                    wp.steps_at = 0
                    wp.parts_at = 0
                    cs = self._get_charging_station(wp.instance_name)
                    while self._battery_size > wp.charge + wp.steps_at*cs.rate:
                        wp.steps_at += 1
                        wp.parts_at += 1

                current_wp = wp
