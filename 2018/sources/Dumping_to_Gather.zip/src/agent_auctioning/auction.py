#!/usr/bin/env python2

import rospy
import time
import sys

from agent_mutual.agent_utils import log, get_current_timestamp, get_bidder_topic_prefix, get_number,\
        get_plan, get_team_name, get_items_string, get_duration
from agent_mutual.constants import Constants
from agent_mutual.statistics import Stats

from threading import Thread

# TODO remove old tasks
from mac_agent.msg import AuctionStageMsg, AuctionStageResponseMsg,\
        ClearTempPlansMsg, AbortJobMsg, CancelJobMsg, TaskFinishedMsg, PlanStatusMsg, UpdatePlansMsg,\
        AssembleTask, DeliverTask, GatherNAssembleTask, GatherNDeliverTask, RetrieveNAssembleTask,\
        RetrieveNDeliverTask,\
        GatherResourceTask, DeliverItemsTask

from mac_agent.srv import TempAssignPlanSrv, UpdateTempAssignedPlanSrv, FinalAssignPlanSrv

from agent_rhbp.actions import AssembleAction, AssistAssembleAction, DeliverAction, GatherResourceAction

try:
    from Queue import PriorityQueue # ver. < 3.0
except ImportError:
    from queue import PriorityQueue

class Auction(Thread):
    '''
    In this thread the auctioning of the tasks a certain job is devided into is done. Firstly the job
    gets decomposed in several subtasks, then the tasks are auctioned between the bidders, which
    create a plan for each of those tasks which contains how the task can be done by the particular
    agent concerning the agents specific properties and state in that moment in the simulation world.
    This auction then decides for the best plans in regards of feasibility and earliest task finishing
    step. If all attempts for assigning the tasks to the chosen agents succeed the job is started
    in order to try to finish it and earn money for its completion.
    '''
    def __init__(self, auction_id, agent_name, agent_number, simulation_step, job,\
            job_decomposition_manager):
        '''
        Constructor.
        :param agent_name: the name of the auctioneer this auction belongs to
        :type agent_name: string
        :param agent_number: number of agents of the team this auctioneer belongs to
        :type simulation_step: uint32
        :param simulation_step: current step of the simulation
        :type simulation_step: uint32
        :param job: the job this auction is going to try to manage to fullfill
        :type job: Job
        :param job_decomposition_manager: the manager that is used to divide the given job into subtasks
        :type job_decomposition_manager: JobDecompositionManager
        '''
        Thread.__init__(self)

        self._auction_id = auction_id
        self._agent_name = agent_name
        self._agent_number = agent_number

        self._auction_name = job.id+'(#'+str(self._auction_id)+')_'+self._agent_name

        self._simulation_step = simulation_step
        self.job = job

        auction_type = type(self).__name__
        if auction_type == PricedJobAuction.__name__:
            job.type = Constants.PRICED_JOB
        elif auction_type == MissionJobAuction.__name__:
            job.type = Constants.MISSION_JOB
        elif auction_type == AuctionJobAuction.__name__:
            job.type = Constants.AUCTION_JOB

        log(self._auction_name, 'New '+job.type+'! [start='+str(self.job.start)+\
                ', end='+str(self.job.end)+', reward='+str(self.job.reward)+']', 'err')

        self._job_decomposition_manager = job_decomposition_manager

        self._agent_roles = {}

        # response time per auction stage in seconds
        self._response_duration = 2.0
        # sleep interval in seconds
        self._sleep_duration = 0.05
        # percentage of responses to receive to not restart auction
        self._percentage_responses_lower_bound = 0.9
        # to save auction responses
        self._responses = {}

        self._temp_assigned_plans = {}
        self._assigned_plans = {}

        # saved plan status for each plan
        self._plan_status = {}

        # tasks that have been finished
        self._finished_task_ids = []

        # flag to cancel auction process
        self._abort = False

        # flag to quit this auction
        self._quit = False

        # flags for auctioneer to handle terminated auctions
        self.terminated = False
        self.restart = False

        # flag if job already ended
        self._failed_job_status = False

        # TODO which percentage?
        self._restart_mission_job_time_percentage = 0.1

        self._pub_auction_stage = rospy.Publisher(get_team_name()+'/auction_stage', AuctionStageMsg,\
                queue_size=self._agent_number, latch=True)
        self._pub_clear_temp_plans = rospy.Publisher(get_team_name()+'/clear_temp_plans',\
                ClearTempPlansMsg, queue_size=self._agent_number, latch=True)
        self._pub_abort_job = rospy.Publisher(get_team_name()+'/abort_job', AbortJobMsg,\
                queue_size=self._agent_number, latch=True)
        self._pub_cancel_job = rospy.Publisher(get_team_name()+'/cancel_job', CancelJobMsg,\
                queue_size=self._agent_number, latch=True)

        self._sub_auction_stage_response = rospy.Subscriber("~auction_stage_response",\
                AuctionStageResponseMsg, self._auction_stage_response_callback,\
                queue_size=self._agent_number)
        self._sub_plan_status = rospy.Subscriber("~"+self.job.id+"_plan_status", PlanStatusMsg,\
                self._plan_status_callback, queue_size=self._agent_number)
        self._sub_task_finished = rospy.Subscriber("~"+self.job.id+"_task_finished", TaskFinishedMsg,\
                self._task_finished_callback, queue_size=self._agent_number)

    def update_auction(self, simulation_step):
        '''
        Updates simulation step of this auction.
        :param simulation_step: current step of the simulation
        :type simulation_step: uint32
        '''
        self._simulation_step = simulation_step

    def run(self):
        '''
        Starts this auctioning thread.
        '''
        items = get_items_string(self.job.items)
        log(self._auction_name, 'Auction started! ['+self.job.storage_name+', '+str(items)+']', 'err')

        # TODO check if job profitable -> abort if not

        # first decompose job
        self._decomposition = self._job_decomposition_manager.decompose_job(job=self.job)
        if not self._decomposition:
            log(self._auction_name, 'Decomposition manager not ready!', 'err')
            self._abort = True

        if not self._abort:
            log(self._auction_name, 'Tasks per stage: '+\
                    str([len(stage) for stage in self._decomposition]), 'err')

            # process auction stages consecutively
            for idx, stage in enumerate(self._decomposition):
                self._process_stage_auction(stage=stage, stage_id=idx)
                if self._abort:
                    break

        if not self._abort:
            # TODO check if job profitable -> abort if not

            # TODO POINTER

            # finally assign all temp assigned tasks to start the job execution
            self._final_plan_assignments()

        # remove job related temp assignments
        self._send_clear_temp_plans_request()

        # if auction aborted -> terminate
        if self._abort:
            if not self._quit:
                log(self._auction_name, 'Auction Aborted!', 'warn')
                self._job_decomposition_manager.clear_reserved_item_knowledge(job_id=self.job.id)
                self._send_abort_job_request()
                # restart if mission job and not to late
                self._restart_mission_job()
            self._terminate()
            return

        log(self._auction_name, 'All plans assigned - Job execution started!')

        all_tasks_finished = False
        # monitor task & job status
        while not self._quit and not all_tasks_finished:
            # leave loop if all tasks finished
            if len(self._assigned_plans) <= len(self._finished_task_ids) or\
                    (self._failed_job_status and len(self._plan_status) <= len(self._finished_task_ids)):
                all_tasks_finished = True
            else:
                # observe job & plan status -> compute if job still possible
                self._check_status()

            time.sleep(self._sleep_duration)

        if not self._quit:
            # print job specifics and log statistics
            logtype = None
            duration = self._simulation_step - self.job.start
            buffer_steps = self.job.end - self._simulation_step
            if not self._failed_job_status:
                Stats.log_job_done(job_name=self.job.id, job_type=self.job.type, duration=duration,\
                        buffer_steps=buffer_steps, reward=self.job.reward)
                log(self._auction_name, 'JOB FINISHED! start='+str(self.job.start)+' -> [step='+\
                        str(self._simulation_step)+'] -> end='+str(self.job.end), logtype='err')
            else:
                Stats.log_job_failed(job_name=self.job.id, job_type=self.job.type, duration=duration,\
                        buffer_steps=buffer_steps, fine=self.job.fine)
                log(self._auction_name, 'JOB FAILED! start='+str(self.job.start)+' -> [step='+\
                        str(self._simulation_step)+'] -> end='+str(self.job.end), logtype='err')

        # teminate this auction
        self._terminate()

    def _process_stage_auction(self, stage, stage_id):
        '''
        Processes the given auction stage: Send task requests, collect responses and process the
        responses.
        :param stage: list of tasks corresponding to this auction stage
        :type stage: Task[]
        :param stage_id: id of this stage
        :type stage_id: uint32
        '''
        self._responses[stage_id] = {}

        # create and send messages
        self._send_auction_stage_requests(stage=stage, stage_id=stage_id)

        # wait for responses
        sleeped = 0
        while sleeped < self._response_duration:
            # check if all responses received yet -> stop waiting
            if len(self._responses[stage_id]) >= self._agent_number:
                log(self._auction_name, 'Stage #'+str(stage_id)+' - All responses received after '+\
                        str(sleeped)+' seconds!')
                break
            time.sleep(self._sleep_duration)
            sleeped += self._sleep_duration

        Stats.log_auction_stage_response_duration(duration=sleeped)

        # check response number
        num_responses = len(self._responses[stage_id])
        max_responses = self._agent_number
        if max_responses > num_responses:
            log(self._auction_name, 'Stage #'+str(stage_id)+' - Received responses: '+\
                    str(num_responses)+'/'+str(max_responses)+'!', 'warn')
            # restart auction if too few responses
            if num_responses < self._percentage_responses_lower_bound*max_responses:
                log(self._auction_name, 'Stage #'+str(stage_id)+' - Less then '+\
                        str(self._percentage_responses_lower_bound*100)+\
                        '% of the responses received!', 'err')
                self._abort = True
                self.restart = True
                return

        # handle responses
        self._handle_stage_responses(stage=stage, stage_id=stage_id)

    def _send_auction_stage_requests(self, stage, stage_id):
        '''
        Sends a request containing all tasks of the given auction stage at once.
        :param stage: list of tasks corresponding to this auction stage
        :type stage: Task[]
        :param stage_id: id of this stage
        :type stage_id: uint32
        '''
        msg = AuctionStageMsg(auctioneer=self._agent_name, job_id=self.job.id,\
                auction_id=self._auction_id, stage_id=stage_id)
        for task in stage:
            task.auctioneer = self._agent_name
            task.job_id = self.job.id
            task.auction_id = self._auction_id
            task.stage_id = stage_id
            task_type = type(task).__name__
            if  task_type == AssembleTask.__name__:
                msg.assemble_tasks.append(task)
            elif task_type == DeliverTask.__name__:
                msg.deliver_tasks.append(task)
            elif task_type == GatherNAssembleTask.__name__:
                msg.gather_n_assemble_tasks.append(task)
            elif task_type == GatherNDeliverTask.__name__:
                msg.gather_n_deliver_tasks.append(task)
            elif task_type == RetrieveNAssembleTask.__name__:
                msg.retrieve_n_assemble_tasks.append(task)
            elif task_type == RetrieveNDeliverTask.__name__:
                msg.retrieve_n_deliver_tasks.append(task)
        msg.timestamp = get_current_timestamp()
        # publish auction request message
        log(self._auction_name, 'Stage #'+str(stage_id)+' - Send auction stage requests!')
        self._pub_auction_stage.publish(msg)

    def _auction_stage_response_callback(self, msg):
        '''
        Callback method for the auction stage request responses. Saves responses.
        :param msg: the message
        :type msg: AuctionStageResponseMsg
        '''
        if msg.job_id == self.job.id and msg.auction_id == self._auction_id and\
                len(self._responses) > msg.stage_id:
            self._responses[msg.stage_id][msg.bidder] = msg
            if msg.bidder not in self._agent_roles:
                self._agent_roles[msg.bidder] = msg.role

    def _handle_stage_responses(self, stage, stage_id):
        '''
        Processes the responses of the given auction stage task per task.
        :param stage: list of tasks corresponding to this auction stage
        :type stage: Task[]
        :param stage_id: id of this stage
        :type stage_id: uint32
        '''
        nested_connected_tasks = self._nest_connected_tasks(stage=stage)
        for nest_tasks in nested_connected_tasks:
            # don't consider agent responses already temp assigned in this stage
            ass_agents = []
            if stage_id in self._temp_assigned_plans:
                for tp in self._temp_assigned_plans[task.stage_id].values():
                    ass_agents.append(tp.bidder)
            responses = [r for r in self._responses[stage_id].values() if r.bidder not in ass_agents]

            nest_plans = []
            for task in nest_tasks:
                nest_plans.append([])
                task_type = type(task).__name__
                task_id = task.task_id
                if task_type == GatherNAssembleTask.__name__:
                    for r in responses:
                        nest_plans[-1].append(get_plan(task_id=task_id, plans=r.gather_n_assemble_plans))
                elif task_type == GatherNDeliverTask.__name__:
                    for r in responses:
                        nest_plans[-1].append(get_plan(task_id=task_id, plans=r.gather_n_deliver_plans))
                elif task_type == DeliverTask.__name__:
                    for r in responses:
                        nest_plans[-1].append(get_plan(task_id=task_id, plans=r.deliver_plans))
                elif task_type == AssembleTask.__name__:
                    for r in responses:
                        nest_plans[-1].append(get_plan(task_id=task_id, plans=r.assemble_plans))
                elif task_type == RetrieveNAssembleTask.__name__:
                    for r in responses:
                        nest_plans[-1].append(get_plan(task_id=task_id,plans=r.retrieve_n_assemble_plans))
                elif task_type == RetrieveNDeliverTask.__name__:
                    for r in responses:
                        nest_plans[-1].append(get_plan(task_id=task_id,plans=r.retrieve_n_deliver_plans))
                else:
                    log(self._auction_name, 'Task '+type(task).__name__+' not handled yet!')
                    self._abort = True
                    return

            # choose best response
            self._handle_task_responses(nest_tasks=nest_tasks, nest_plans=nest_plans)

            if self._abort:
                return

    def _nest_connected_tasks(self, stage):
        connected_tasks = []
        current_successor = 0
        for task in stage:
            if task.successor == 0 or task.successor != current_successor:
                current_successor = task.successor
                connected_tasks.append([task])
            else:
                connected_tasks[-1].append(task)
        return connected_tasks

    def _handle_task_responses(self, nest_tasks, nest_plans):
        # sort plans
        sorted_nest_plans = []
        for task, plans in zip(nest_tasks, nest_plans):
            pq = PriorityQueue()
            num_plans = 0
            for plan in plans:
                if plan.feasible:
                    if self._simulation_step > plan.start_step:
                        plan.start_step = self._simulation_step
                    end_step = plan.start_step + plan.route.duration
                    pq.put((end_step, plan))
                    num_plans += 1
            if num_plans == 0:
                log(self._auction_name, 'Task #'+str(task.task_id)+' - No feasible plan!', 'warn')
                self._abort = True
                return
            sorted_nest_plans.append([pq.get() for _ in range(num_plans)])

        best_plans = None
        if len(nest_tasks) == 1:
            # single task
            best_plan = None
            if nest_tasks[0].dependent:
                # if dependent sort duration wise
                best_duration = sys.maxint
                for p in sorted_nest_plans[0]:
                    plan = p[1]
                    if plan.route.duration < best_duration:
                        best_duration = plan.route.duration
                        best_plan = plan
            else:
                # if not dependent just choose fastest
                best_plan = sorted_nest_plans[0][0][1]

            best_plans = [best_plan]
        else:
            product_name = nest_tasks[0].product.name
            if product_name not in self._job_decomposition_manager.products:
                log(self._auction_name, 'Product '+product_name+' not existent!', 'err')
                self._abort = True
                return

            # simultaneous tasks
            roles = self._job_decomposition_manager.products[product_name].required_roles
            log(self._auction_name, product_name+' -> '+str(roles), 'err')

            best_plans = self._choose_best_plans(sorted_nest_plans=sorted_nest_plans, roles=roles)

        if not best_plans or len(best_plans) == 0:
            log(self._auction_name, 'Choose best plans: Found no valid combination!', 'warn')
            self._abort = True
            return

        # compute least step
        least_step = 0
        for bp in best_plans:
            d = get_duration(waypoints=bp.route.waypoints)
            if bp.start_step + d > least_step:
                least_step = bp.start_step + d

        for best_plan in best_plans:
            task = best_plan.task

            # if not able to finish plan in time -> abort auction
            if not self._is_plan_on_time(best_plan):
                log(self._auction_name, 'Task #'+str(task.task_id)+' '+type(task).__name__+\
                        ' - Best plan not on time!', 'warn')
                self._abort = True
                return

            waiting_time = least_step -\
                    (best_plan.start_step + get_duration(waypoints=best_plan.route.waypoints))

            # try to temp assign best plan
            ack, start_step, route = self._temp_assign_plan_request(plan=best_plan,\
                    waiting_time=waiting_time)

            if ack:
                # successful temp assignment
                log(self._auction_name, 'Task #'+str(task.task_id)+' '+type(task).__name__+\
                        ' - Temp assign (['+str(best_plan.start_step)+', '+\
                        str(best_plan.start_step+best_plan.route.duration)+'] -> ['+str(start_step)+\
                        ', '+str(start_step+route.duration)+'])')

                best_plan.start_step = start_step
                best_plan.route = route

                # if plan can't be ended on time anymore, restart auction
                if not self._is_plan_on_time(best_plan):
                    log(self._auction_name, 'Task #'+str(task.task_id)+' '+type(task).__name__+\
                           ' - Temp assigned plan cannot be ended on time anymore!', 'warn')
                    self._abort = True
                    self.restart = True
                    return

                # set information in predecessor plans
                if task.dependent and len(task.predecessors) > 0:
                    predecessor_plans = []
                    for pred_id in task.predecessors:
                        predecessor_plan = None
                        for stage_id in range(task.stage_id-1,-1,-1):
                            if pred_id in self._temp_assigned_plans[stage_id]:
                                predecessor_plan = self._temp_assigned_plans[stage_id][pred_id]
                        if not predecessor_plan:
                            log(self._auction_name, 'Task #'+str(task.task_id)+' '+type(task).__name__+\
                                    ' - Predecessor plan not found: '+str(task.predecessors)+'!', 'warn')
                            self._abort = True
                            self.restart = True
                            return
                        predecessor_plans.append(predecessor_plan)

                    # TODO update predecessor plans
                    for pre_plan in predecessor_plans:
                        wp = pre_plan.route.waypoints[-1]
                        if wp.action.action_type == AssistAssembleAction.ACTION:
                            if pre_plan.bidder == best_plan.bidder:
                                wp.action.action_type = AssembleAction.ACTION
                                #wp.action.items = task.items
                                #wp.items += task.items
                            else:
                                ack, items = self._update_temp_assigned_plan_request(plan=pre_plan,\
                                        assemble_agent=best_plan.bidder)

                                if not ack:
                                    log(self._auction_name, 'Task #'+str(task.task_id)+' '+\
                                            type(task).__name__+' - Update of predecessor failed: #'+\
                                            str(pre_plan.task.task_id)+'!', 'warn')
                                    self._abort = True
                                    self.restart = True
                                    return

                                wp.action.agent = best_plan.bidder
                                wp.action.items = items

                if task.stage_id not in self._temp_assigned_plans:
                    self._temp_assigned_plans[task.stage_id] = {}
                self._temp_assigned_plans[task.stage_id][task.task_id] = best_plan

                log(self._auction_name, 'Task #'+str(task.task_id)+' '+type(task).__name__+\
                        ' - Temp assignment to '+best_plan.bidder+' successful!')
            else:
                # temp assignment failed
                log(self._auction_name, 'Task #'+str(task.task_id)+' '+type(task).__name__+\
                        ' - Temp assignment to '+best_plan.bidder+' failed!', 'warn')
                self._abort = True
                self.restart = True
                return

    def _choose_best_plans(self, sorted_nest_plans, roles):
        indices = [0 for _ in range(len(sorted_nest_plans))]

        conditions_met = False
        while not conditions_met:
            _end_steps = []
            _agents = []
            _roles = []
            for i, np in zip(indices, sorted_nest_plans):
                _end_steps.append(np[i][0])
                _agents.append(np[i][1].bidder)
                _roles.append(self._agent_roles[_agents[-1]])

            # TODO remove
            log(self._auction_name, str(indices)+' == '+str(_agents))
            log(self._auction_name, str(set(roles))+' <= '+str(set(_roles)))

            if len(indices) == len(set(_agents)) and set(roles) <= set(_roles):
                conditions_met = True
            else:
                # iterate indices
                if len(indices) != len(set(_agents)):
                    # handle agents with multiple occurences first
                    for a in _agents:
                        if _agents.count(a) > 1:
                            idxs = [i for i, x in enumerate(_agents) if a == x]
                            stps = [_end_steps[i] for i in idxs]
                            index = idxs[min(enumerate(stps), key=lambda x: x[1])[0]]
                            indices[index] += 1
                            break
                    # return None if not enough plans
                    if indices[index] >= len(sorted_nest_plans[index]):
                        return None
                else:
                    # handle missing roles
                    for role in roles:
                        if role not in _roles:
                            arg_idxs = []
                            for i, np in zip(indices, sorted_nest_plans):
                                none = True
                                for j in range(i+1, len(np)):
                                    if role == self._agent_roles[np[j][1].bidder]:
                                        none = False
                                        arg_idxs.append(j)
                                        break
                                # return None if not enough plans
                                if none:
                                    arg_idxs.append(-1)
                            # if all current roles demanded
                            if set(_roles) < set(roles):
                                found_multiple = False
                                for r in _roles:
                                    if _roles.count(r) > 1:
                                        found_multiple = True
                                        idxs = [i for i, (_r, ai) in enumerate(zip(_roles, arg_idxs))\
                                                if (r == _r and ai != -1)]
                                        if len(idxs) == 0:
                                            return None
                                        stps = [sorted_nest_plans[i][arg_idxs[i]][0] for i in idxs]
                                        index = idxs[min(enumerate(stps), key=lambda x: x[1])[0]]
                                        indices[index] = arg_idxs[index]
                                        break
                                # TODO remove
                                while not found_multiple:
                                    print('XXXXXXXXX')
                            else:
                                idxs = [i for i, (_r, ai) in enumerate(zip(_roles, arg_idxs))\
                                        if (_r not in roles and ai != -1)]
                                if len(idxs) == 0:
                                    return None
                                stps = [sorted_nest_plans[i][arg_idxs[i]][0] for i in idxs]
                                index = idxs[min(enumerate(stps), key=lambda x: x[1])[0]]
                                indices[index] = arg_idxs[index]
                            # next try if conditions met
                            break

            # TODO remove
            log(self._auction_name, str(zip(_agents, zip(_roles, _end_steps))), 'err')

        indices = self._optimize_plans(indices, sorted_nest_plans, roles)

        plans = [sorted_nest_plans[i][j][1] for i,j in enumerate(indices)]

        return plans

    def _optimize_plans(self, indices, sorted_nest_plans, roles):
        '''
        Move together plans such that they don't differ too much in their end step.
        '''
        optimization_finished = False
        while not optimization_finished:

            _end_steps = []
            _agents = []
            _roles = []
            for i, np in zip(indices, sorted_nest_plans):
                _end_steps.append(np[i][0])
                _agents.append(np[i][1].bidder)
                _roles.append(self._agent_roles[_agents[-1]])
            max_step = max(_end_steps)

            changed = False
            for idx, (i, np) in enumerate(zip(indices, sorted_nest_plans)):
                if np[i][0] < max_step and i+1 < len(np):
                    previous_role = self._agent_roles[np[i][1].bidder]
                    index = i
                    for j in range(i+1, len(np)):
                        end_step = np[j][0]
                        agent = np[j][1].bidder
                        role = self._agent_roles[agent]
                        if end_step <= max_step and agent not in _agents and\
                                (previous_role not in roles or _roles.count(previous_role) > 1 or\
                                role == previous_role):
                            _end_steps[idx] = end_step
                            _agents[idx] = agent
                            _roles[idx] = role
                            index = j
                            changed = True
                    indices[idx] = index
            if not changed:
                optimization_finished = True

        # TODO remove
        log(self._auction_name, 'OPTIMIZED: '+str(zip(_agents, zip(_roles, _end_steps))), 'err')

        return indices

    def _is_plan_on_time(self, plan):
        '''
        Returns if the given plan can be finished in time (before job deadline).
        :param plan: the plan to check
        :type plan: a specific Plan
        :return: true if doable else false
        :type: bool
        '''
        # TODO always do mission jobs?
        if type(self).__name__ == MissionJobAuction.__name__:
            return True
        # TODO use extra steps?
        extra_steps = 0
        return plan.start_step + plan.route.duration <= self.job.end + extra_steps

    def _temp_assign_plan_request(self, plan, waiting_time):
        '''
        Sends temp assign plan request and returns the response.
        :param plan: plan to temp assign
        :type plan: a specific Plan
        :return: (acknowledgement, updated route)
        :type: (bool, Route)
        '''
        try:
            temp_assign_plan=rospy.ServiceProxy(get_bidder_topic_prefix(plan.bidder)+'temp_assign_plan',\
                    TempAssignPlanSrv)
            response = temp_assign_plan(timestamp=get_current_timestamp(), auctioneer=self._agent_name,\
                    job_id=plan.task.job_id, auction_id=plan.task.auction_id,\
                    stage_id=plan.task.stage_id, task_id=plan.task.task_id, start_step=plan.start_step,\
                    waiting_time=waiting_time)
            return response.ack, response.start_step, response.route
        except rospy.ServiceException, e:
            log(self._auction_name, 'Temp assign - service call failed: '+str(e) , 'err')
            return False, 0, None

    def _update_temp_assigned_plan_request(self, plan, assemble_agent):
        try:
            update_temp_assigned_plan=rospy.ServiceProxy(get_bidder_topic_prefix(plan.bidder)+\
                    'update_temp_assigned_plan', UpdateTempAssignedPlanSrv)
            response = update_temp_assigned_plan(timestamp=get_current_timestamp(),\
                    auctioneer=self._agent_name, job_id=plan.task.job_id,\
                    auction_id=plan.task.auction_id, stage_id=plan.task.stage_id,\
                    task_id=plan.task.task_id, assemble_agent=assemble_agent)
            return response.ack, response.items
        except rospy.ServiceException, e:
            log(self._auction_name, 'Update temp assigned plan - service call failed: '+str(e) , 'err')
            return False, None

    def _final_plan_assignments(self):
        '''
        Sends request to finally assign all (all stages) previously temp assigned plans.
        If assignment goes wrong -> restart this auction.
        '''
        for stage_id in range(len(self._temp_assigned_plans)):
            for plan in self._temp_assigned_plans[stage_id].values():
                # final assign plan
                ack, _ = self._final_assign_plan_request(plan=plan)

                # TODO Pointer
                if ack:
                    log(self._auction_name, 'Task #'+str(plan.task.task_id)+' '+type(plan.task).__name__+\
                            ' - Final assignment to '+plan.bidder+' successful!')
                    # fill assigned plans
                    self._assigned_plans[plan.task.task_id] = plan
                else:
                    log(self._auction_name, 'Task #'+str(plan.task.task_id)+' '+type(plan.task).__name__+\
                            ' - Final assignment to '+plan.bidder+' failed!', 'warn')
                    self._abort = True
                    self.restart = True
                    return

    def _final_assign_plan_request(self, plan):
        '''
        Finally assign the given plan to the corresponding agent.
        :params plan: the plan to finally assign
        :type plan: a specific Plan
        :return: (acknowledgement, updated route)
        :return type: (bool, Route)
        '''
        agent = ''
        task_type = type(plan.task).__name__
        if task_type in [GatherNAssembleTask.__name__, RetrieveNAssembleTask.__name__,\
                AssembleTask.__name__]:
            if plan.route.waypoints[-1].action.action_type == AssistAssembleAction.ACTION:
                agent = plan.route.waypoints[-1].action.agent

        try:
            final_assign_plan=rospy.ServiceProxy(get_bidder_topic_prefix(plan.bidder)+\
                    'final_assign_plan', FinalAssignPlanSrv)
            response = final_assign_plan(timestamp=get_current_timestamp(), auctioneer=self._agent_name,\
                    job_id=plan.task.job_id, auction_id=plan.task.auction_id,\
                    stage_id=plan.task.stage_id, task_id=plan.task.task_id, start_step=plan.start_step,\
                    agent=agent)
            return response.ack, response.route
        except rospy.ServiceException, e:
            log(self._auction_name, 'Final assign - service call failed: '+str(e) , 'err')
            return False, None

    def _send_clear_temp_plans_request(self):
        '''
        Sends a request to clear all temp assigned plans that correspond to this auction/job.
        '''
        msg = ClearTempPlansMsg(timestamp = get_current_timestamp(), job_id=self.job.id)
        self._pub_clear_temp_plans.publish(msg)

    def _send_abort_job_request(self):
        '''
        Sends a request to abort the execution of all plans that correspond to this auction/job.
        '''
        msg = AbortJobMsg(timestamp = get_current_timestamp(), job_id=self.job.id)
        self._pub_abort_job.publish(msg)

    def _plan_status_callback(self, msg):
        '''
        Callback method for the current plan status of an agent that participates in this job.
        :param msg: the message
        :type msg: PlanStatusMsg
        '''
        if msg.task_id not in self._assigned_plans:
            return

        if msg.task_id not in self._plan_status:
            log(self._auction_name, msg.agent+' started Task #'+str(msg.task_id)+':\n'\
                    'old(step='+str(self._assigned_plans[msg.task_id].start_step)+', duration='+\
                    str(self._assigned_plans[msg.task_id].route.duration)+') -> new(step='+\
                    str(msg.start_step)+', duration='+str(msg.route.duration)+')!', 'warn')
            self._send_update_plans_message(bidder_name=msg.agent)

        self._plan_status[msg.task_id] = msg

        # update assigned plans
        self._assigned_plans[msg.task_id].start_step = msg.start_step
        self._assigned_plans[msg.task_id].route = msg.route

        if not self._failed_job_status and msg.failed_job_status:
            self._failed_job_status = True
            self._send_cancel_job_message()

    def _task_finished_callback(self, msg):
        '''
        Callback method for the finished tasks corresponding to this job.
        :param msg: the message
        :type msg: TaskFinishedMsg
        '''
        if msg.auctioneer == self._agent_name and msg.job_id == self.job.id and\
                msg.task_id in self._assigned_plans.keys() and msg.task_id not in self._finished_task_ids:

            plan = self._assigned_plans[msg.task_id]
            delta_steps = (plan.start_step + plan.route.duration) - self._simulation_step
            log(self._auction_name, plan.bidder+' finished Task #'+str(msg.task_id)+\
                    ' ('+str(int(delta_steps))+' steps)!')

            self._finished_task_ids.append(msg.task_id)
            self._send_update_plans_message(bidder_name=msg.agent)

    def _send_update_plans_message(self, bidder_name):
        '''
        Sends a message to the given bidder to synchronize it's assigned job list with the list of the
        RHBP agent.
        :param bidder_name: the name of the bidder
        :type bidder_name: string
        '''
        msg = UpdatePlansMsg(timestamp=get_current_timestamp())
        rospy.Publisher(get_bidder_topic_prefix(bidder_name)+'update_plans',\
                UpdatePlansMsg, queue_size=1, latch=True).publish(msg)

    def _send_cancel_job_message(self):
        log(self._auction_name, 'Cancel this Job! start='+str(self.job.start)+' -> [step='+\
                        str(self._simulation_step)+'] -> end='+str(self.job.end), logtype='err')
        msg = CancelJobMsg(timestamp = get_current_timestamp(), job_id=self.job.id)
        self._pub_cancel_job.publish(msg)

    def _restart_mission_job(self):
        '''
        Restarts this mission job auction as long as there is enough time for completion.
        '''
        if type(self).__name__ == MissionJobAuction.__name__:
            if self.job.start+self._restart_mission_job_time_percentage*(self.job.end - self.job.start) >\
                self._simulation_step:
                log(self._auction_name, 'Restart Mission Auction!', 'err')
                self.restart = True
            elif not self.restart:
                Stats.log_job_failed(job_name=self.job.id, job_type=self.job.type, duration='inf',\
                        buffer_steps='inf', fine=self.job.fine)

    def _check_status(self):
        '''
        Checks the tasks completion status as well as the job status and the last agents status messages
        and sets the corresponding flags if this jobs execution has to be stopped.
        '''
        # TODO extend task status

        # check job status
        if not self._failed_job_status and self._simulation_step > self.job.end:
            self._failed_job_status = True
            self._send_cancel_job_message()

    def quit(self):
        self.restart = False
        self._abort = True
        self._quit = True

    def _terminate(self):
        '''
        Unregisters this auctions subscriptions and sets terminate flag such that the auctioneer knows
        that this auction can be terminated and removed from the auction list.
        '''
        self._sub_auction_stage_response.unregister()
        self._sub_plan_status.unregister()
        self._sub_task_finished.unregister()
        self.terminated = True


class PricedJobAuction(Auction):
    def __init__(self, auction_id, agent_name, agent_number, simulation_step, priced_job,\
            job_decomposition_manager):
        super(PricedJobAuction, self).__init__(auction_id=auction_id, agent_name=agent_name,\
                agent_number=agent_number, simulation_step=simulation_step, job=priced_job,\
                job_decomposition_manager=job_decomposition_manager)


class AuctionJobAuction(Auction):
    def __init__(self, auction_id, agent_name, agent_number, simulation_step, auction_job,\
            job_decomposition_manager):
        super(AuctionJobAuction, self).__init__(auction_id=auction_id, agent_name=agent_name,\
                agent_number=agent_number, simulation_step=simulation_step, job=auction_job.job,\
                job_decomposition_manager=job_decomposition_manager)
        self._auction_job = auction_job


class MissionJobAuction(Auction):
    def __init__(self, auction_id, agent_name, agent_number, simulation_step, mission_job,\
            job_decomposition_manager):
        super(MissionJobAuction, self).__init__(auction_id=auction_id, agent_name=agent_name,\
                agent_number=agent_number, simulation_step=simulation_step, job=mission_job,\
                job_decomposition_manager=job_decomposition_manager)
