
class Constants(object):
    '''
    Class containing different simulation specific constants to ensure consistency.
    '''
    # roles
    DRONE = 'drone'
    MOTORCYCLE = 'motorcycle'
    CAR = 'car'
    TRUCK = 'truck'

    # job types
    PRICED_JOB = 'PricedJob'
    MISSION_JOB = 'MissionJob'
    AUCTION_JOB = 'AuctionJob'

    # knowledge base keys
    # well specifics
    WELL = 'well'
    CURRENT_WELL = 'current_well'
    WELL_DONE = 'well_done'
    EXISTENT = 'existent'
    NONEXISTENT = 'nonexistent'
    ENEMY_WELL = 'enemy_well'
    CURRENT_DISMANTLE_WELL = 'current_dismantle_well'
    DISMANTLED_WELL = 'dismantled_well'
    GENERAL_WELL_INFO = 'general_well_info'

    # exploration point markers
    NOT_REACHABLE = 'not_reachable'

    # knowledge base names
    KB_TEAM_A = 'knowledgeBaseNodeA'
    KB_TEAM_B = 'knowledgeBaseNodeB'
    KB_GENERAL = 'knowledgeBaseNode'

    # reserved item specifics
    RESERVED_ITEM = 'reserved_item'
    ITEM_STORED = 'stored'
    ITEM_DELIVERED = 'delivered'

