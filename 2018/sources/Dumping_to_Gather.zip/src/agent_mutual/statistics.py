import os
import rospy
import numpy as np
from constants import Constants

class Stats(object):
    '''
    This class is used for logging different statistics of all agents into one central storage, such
    that the single agents data doesnt have to be aggregated.
    This script can also be executed printing live updates of the statistics to the standard output.
    Terminate the running script by CTR+C.
    '''
    # flag to disable statistic logging
    ENABLED = True

    # paths
    PATH_ROS = os.path.expanduser('~')+'/.ros/'
    PATH_STATS_DIR = 'stats/'

    FILE_GENERAL = 'general.txt'
    FILE_ACTION_RESPONSE_DURATION = 'action_response_duration.txt'
    FILE_DECISION_MAKING_TIMEOUTS = 'decision_making_timeouts.txt'
    FILE_AUCTION_STAGE_RESPONSE_DURATION = 'auction_stage_response_duration.txt'
    FILE_TOTAL_JOBS = 'total_jobs.txt'
    FILE_JOBS_DONE = 'jobs_done.txt'
    FILE_JOBS_FAILED = 'jobs_failed.txt'
    FILE_WELLS_BUILT = 'wells_built.txt'

    FILES = [FILE_GENERAL, FILE_ACTION_RESPONSE_DURATION, FILE_DECISION_MAKING_TIMEOUTS,\
            FILE_AUCTION_STAGE_RESPONSE_DURATION, FILE_TOTAL_JOBS, FILE_JOBS_DONE, FILE_JOBS_FAILED,\
            FILE_WELLS_BUILT]

    # job related dictionary keys
    N = 'n'
    D = 'durations'
    BS = 'buffer_steps'
    RF = 'rewards_or_fines'

    @staticmethod
    def create_directory():
        '''
        Creates the stats directory if it doesn't exists.
        '''
        if not os.path.exists(Stats.PATH_STATS_DIR):
            os.makedirs(Stats.PATH_STATS_DIR)

    @staticmethod
    def clear_former_stats(simulation_step):
        '''
        Deletes all logging files from former simulations to only consider the current simulations
        logged files.
        :param simulation_step: current simulation step to compare with the lastly logged simulation steps
        :type simulation_step: uint
        '''
        if simulation_step < int(Stats.get_general()[1]):
            for f in Stats.FILES:
                try:
                    os.remove(Stats.PATH_STATS_DIR+f)
                except:
                    pass

    @staticmethod
    def log_general(agent_number, simulation_step, massium, score):
        '''
        Logs agents general information.
        :param agent_number: number of agents in the current simulation
        :type agent_number: uint
        :param simulation_step: current simulation step
        :type simulation_step: uint
        :param massium: current massium amount
        :type massium: uint
        :param score: current score
        :type score: uint
        '''
        if not Stats.ENABLED:
            return

        Stats.create_directory()
        Stats.clear_former_stats(simulation_step=simulation_step)
        f = Stats.append_file(file_name=Stats.FILE_GENERAL)
        f.write(str(agent_number)+' '+str(simulation_step)+' '+str(massium)+' '+str(score)+'\n')
        f.flush()

    @staticmethod
    def log_action_response_duration(duration):
        '''
        Logs a single action response duration.
        :param duration: the duration
        :type duration: float
        '''
        if not Stats.ENABLED:
            return

        Stats.create_directory()
        f = Stats.append_file(file_name=Stats.FILE_ACTION_RESPONSE_DURATION)
        f.write(str(duration)+'\n')
        f.flush()

    @staticmethod
    def log_decision_making_timeouts():
        '''
        Logs a single decision making timeout.
        '''
        if not Stats.ENABLED:
            return

        Stats.create_directory()
        f = Stats.append_file(file_name=Stats.FILE_DECISION_MAKING_TIMEOUTS)
        f.write('t'+'\n')
        f.flush()

    @staticmethod
    def log_auction_stage_response_duration(duration):
        '''
        Logs a single auction stage response duration.
        :param duration: the duration
        :type duration: float
        '''
        if not Stats.ENABLED:
            return

        Stats.create_directory()
        f = Stats.append_file(file_name=Stats.FILE_AUCTION_STAGE_RESPONSE_DURATION)
        f.write(str(duration)+'\n')
        f.flush()

    @staticmethod
    def log_total_jobs(job_name, job_type):
        '''
        Logs a single new job.
        :param job_name: the jobs name
        :type job_name: string
        :param job_type: the jobs type
        :type job_type: string
        '''
        if not Stats.ENABLED:
            return

        Stats.create_directory()
        f = Stats.append_file(file_name=Stats.FILE_TOTAL_JOBS)
        f.write(job_name+' '+job_type+'\n')
        f.flush()

    @staticmethod
    def log_job_done(job_name, job_type, duration, buffer_steps, reward):
        '''
        Logs a single completed job.
        :param job_name: the jobs name
        :type job_name: string
        :param job_type: the jobs type
        :type job_type: string
        :param duration: duration in steps
        :type duration: uint
        :param buffer_steps: how many steps left until job deadline
        :type buffer_steps: uint
        :param reward: the reward in massiums we got for finishing this job
        :type reward: uint
        '''
        if not Stats.ENABLED:
            return

        Stats.create_directory()
        f = Stats.append_file(file_name=Stats.FILE_JOBS_DONE)
        f.write(job_name+' '+job_type+' '+str(duration)+' '+str(buffer_steps)+' '+str(reward)+'\n')
        f.flush()

    @staticmethod
    def log_job_failed(job_name, job_type, duration, buffer_steps, fine):
        '''
        Logs a single failed job.
        :param job_name: the jobs name
        :type job_name: string
        :param job_type: the jobs type
        :type job_type: string
        :param duration: duration in steps
        :type duration: uint
        :param buffer_steps: how many steps left until job deadline
        :type buffer_steps: uint
        :param fine: the fine in massiums we got for failing this job
        :type fine: uint
        '''
        if not Stats.ENABLED:
            return

        Stats.create_directory()
        f = Stats.append_file(file_name=Stats.FILE_JOBS_FAILED)
        f.write(job_name+' '+job_type+' '+str(duration)+' '+str(buffer_steps)+' '+str(fine)+'\n')
        f.flush()

    @staticmethod
    def log_well_built(well_name, cost):
        '''
        Logs information about a single built well.
        :param well_name: the wells name
        :type well_name: string
        :param cost: the wells cost in massium
        :type cost: uint
        '''
        if not Stats.ENABLED:
            return

        Stats.create_directory()
        f = Stats.append_file(file_name=Stats.FILE_WELLS_BUILT)
        f.write(well_name+' '+str(cost)+'\n')
        f.flush()

    @staticmethod
    def get_general():
        '''
        Retrieve general information about the simulation only considering the last logged element.
        :return agent_number: number of agents in the simulation
        :type agent_number: uint
        :return simulation_step: simulation step
        :type simulation_step: uint
        :return massium: massium amount
        :type massium: uint
        :return score: score
        :type score: uint
        '''
        try:
            f = Stats.read_file(file_name=Stats.FILE_GENERAL)
        except:
            return 0, 0, 0, 0
        # only consider last elements information
        g = Stats.get_list_of_elements(the_file=f, datatype=str)[-1].split(' ')
        agent_number = int(g[0])
        simulation_step = int(g[1])
        massium = int(g[2])
        score = int(g[3])
        return agent_number, simulation_step, massium, score

    @staticmethod
    def get_mean_action_response_duration():
        '''
        Retrieves the mean logged action response time.
        :return: time in seconds
        :type: float
        '''
        try:
            f = Stats.read_file(file_name=Stats.FILE_ACTION_RESPONSE_DURATION)
        except:
            return 0
        return round(np.array(Stats.get_list_of_elements(the_file=f, datatype=float)).mean(), 5)

    @staticmethod
    def get_mean_decision_making_timeouts_per_agent(agent_number):
        '''
        Retrieves the mean number of logged decision making timeouts per agent.
        :return: mean number of timeouts per agent
        :type: float
        '''
        try:
            f = Stats.read_file(file_name=Stats.FILE_DECISION_MAKING_TIMEOUTS)
        except:
            return 0
        return round(float(len(Stats.get_list_of_elements(the_file=f, datatype=str)))/agent_number, 5)

    @staticmethod
    def get_mean_auction_stage_response_duration():
        '''
        Retrieves the mean logged auction stage response time.
        :return: time in seconds
        :type: float
        '''
        try:
            f = Stats.read_file(file_name=Stats.FILE_AUCTION_STAGE_RESPONSE_DURATION)
        except:
            return 0
        return round(np.array(Stats.get_list_of_elements(the_file=f, datatype=float)).mean(), 5)

    @staticmethod
    def get_total_number_jobs():
        '''
        Retrieves the total number of logged jobs.
        :return n_priced: number of priced jobs
        :type n_priced: uint
        :return n_mission: number of mission jobs
        :type n_mission: uint
        :return n_auction: number of auction jobs
        :type n_auction: uint
        '''
        n_priced = 0
        n_mission = 0
        n_auction = 0
        try:
            f = Stats.read_file(file_name=Stats.FILE_TOTAL_JOBS)
        except:
            return n_priced, n_mission, n_auction
        for j in Stats.get_list_of_elements(the_file=f, datatype=str):
            job = j.split(' ')
            if job[1] == Constants.PRICED_JOB:
                n_priced +=1
            elif job[1] == Constants.MISSION_JOB:
                n_mission +=1
            elif job[1] == Constants.AUCTION_JOB:
                n_auction +=1
        return n_priced, n_mission, n_auction

    @staticmethod
    def get_jobs(done):
        '''
        Retrieves information about already finished logged jobs.
        :return priced: dictionary containing information about all logged priced jobs
        :type priced: dict
        :return mission: dictionary containing information about all logged priced jobs
        :type mission: dict
        :return auction: dictionary containing information about all logged priced jobs
        :type auction: dict
        '''
        priced = {Stats.N: 0, Stats.D:[], Stats.BS:[], Stats.RF:[]}
        mission = {Stats.N: 0, Stats.D:[], Stats.BS:[], Stats.RF:[]}
        auction = {Stats.N: 0, Stats.D:[], Stats.BS:[], Stats.RF:[]}
        try:
            if done:
                f = Stats.read_file(file_name=Stats.FILE_JOBS_DONE)
            else:
                f = Stats.read_file(file_name=Stats.FILE_JOBS_FAILED)
        except:
            return priced, mission, auction

        for j in Stats.get_list_of_elements(the_file=f, datatype=str):
            job = j.split(' ')
            if job[1] == Constants.PRICED_JOB:
                priced[Stats.N] += 1
                if job[2] != 'inf':
                    priced[Stats.D].append(int(job[2]))
                if job[3] != 'inf':
                    priced[Stats.BS].append(int(job[3]))
                priced[Stats.RF].append(int(job[4]))
            elif job[1] == Constants.MISSION_JOB:
                mission[Stats.N] += 1
                if job[2] != 'inf':
                    mission[Stats.D].append(int(job[2]))
                if job[3] != 'inf':
                    mission[Stats.BS].append(int(job[3]))
                mission[Stats.RF].append(int(job[4]))
            elif job[1] == Constants.AUCTION_JOB:
                auction[Stats.N] += 1
                if job[2] != 'inf':
                    auction[Stats.D].append(int(job[2]))
                if job[3] != 'inf':
                    auction[Stats.BS].append(int(job[3]))
                auction[Stats.RF].append(int(job[4]))
        return priced, mission, auction

    @staticmethod
    def get_wells_built():
        '''
        Retrieves information about logged  already built wells.
        :return number: number of wells
        :type number: uint
        :return cost: cost of all wells in massium
        :type cost: uint
        '''
        number = 0
        cost = 0
        try:
            f = Stats.read_file(file_name=Stats.FILE_WELLS_BUILT)
        except:
            return number, cost

        for w in Stats.get_list_of_elements(the_file=f, datatype=str):
            well = w.split(' ')
            number += 1
            cost += int(well[1])

        return number, cost

    @staticmethod
    def write_file(file_name):
        '''
        Opens a file with the given name for writing purposes.
        :param file_name: the name of the file
        :type file_name: string
        :return: file
        :type: File
        '''
        return open(Stats.PATH_STATS_DIR+file_name, 'w+', os.O_NONBLOCK)

    @staticmethod
    def append_file(file_name):
        '''
        Opens a file with the given name for appending purposes.
        :param file_name: the name of the file
        :type file_name: string
        :return: file
        :type: File
        '''
        return open(Stats.PATH_STATS_DIR+file_name, 'a+', os.O_NONBLOCK)

    @staticmethod
    def read_file(file_name):
        '''
        Opens a file with the given name for reading purposes.
        :param file_name: the name of the file
        :type file_name: string
        :return: file
        :type: File
        '''
        return open(Stats.PATH_ROS+Stats.PATH_STATS_DIR+file_name, 'r', os.O_NONBLOCK)

    @staticmethod
    def get_list_of_elements(the_file, datatype):
        '''
        Returns the full list of elements from the given file.
        :param the_file: the file
        :type the_file: File
        :param datatype: the datatype to convert the single elements to
        '''
        return [datatype(x) for x in the_file.read().split('\n')[:-1]]

    @staticmethod
    def print_all_statistics():
        '''
        Prints all the logged information to the standard output.
        '''
        r = 3
        separation = '----------------------------------------------------------------'
        string = separation+'\n'
        agent_number, simulation_steps, massium, score = Stats.get_general()
        string += 'Number of Agents: '+str(agent_number)
        string += '\nNumber of Simulation-Steps: '+str(simulation_steps)
        string += '\nMassium left: '+str(massium)
        string += '\nScore: '+str(score)

        string += '\n\nMean Action Response Duration: '+str(Stats.get_mean_action_response_duration())
        mean_timeouts = Stats.get_mean_decision_making_timeouts_per_agent(agent_number=agent_number)
        string += '\nMean Decision Making Timeouts per Agent: '+str(mean_timeouts)
        if simulation_steps > 0:
            string += '\nPercentage Decision Making Timeout Steps: '+\
                    str(round(float(mean_timeouts)/simulation_steps, r))
        mean_auction_stage_response = Stats.get_mean_auction_stage_response_duration()
        string += '\nMean Auction Stage Response Duration: '+str(mean_auction_stage_response)

        n_priced, n_mission, n_auction = Stats.get_total_number_jobs()
        string += '\n\nTotal number of Jobs: '+str(n_priced + n_mission + n_auction)
        string += ' | Priced Jobs: '+str(n_priced)
        string += ' | Mission Jobs: '+str(n_mission)
        string += ' | Auction Jobs: '+str(n_auction)

        n = Stats.N
        d = Stats.D
        bs = Stats.BS
        rf = Stats.RF
        priced, mission, auction = Stats.get_jobs(done=True)
        string += '\n\nJobs Done:'
        string += ' Number='+str(priced[n]+mission[n]+auction[n])
        if n_priced+n_mission+n_auction > 0:
            string += ' Percentage='+\
                    str(round(float(priced[n]+mission[n]+auction[n])/(n_priced+n_mission+n_auction), r))
        else:
            string += ' Percentage='+str(0.0)
        if priced[n]+mission[n]+auction[n] > 0:
            if len(priced[d]+mission[d]+auction[d]) > 0:
                string+=' | MeanDuration='+str(int(np.array(priced[d]+mission[d]+auction[d]).mean()))
            if len(priced[bs]+mission[bs]+auction[bs]) > 0:
                string+=' MeanBufferSteps='+str(int(np.array(priced[bs]+mission[bs]+auction[bs]).mean()))
            string += ' | TotalRewards='+str(np.array(priced[rf]+mission[rf]+auction[rf]).sum())
        string += '\nPriced Jobs Done:'
        string += ' Number='+str(priced[n])
        if n_priced > 0:
            string += ' Percentage='+\
                    str(round(float(priced[n])/(n_priced), r))
        else:
            string += ' Percentage='+str(0.0)
        if priced[n] > 0:
            if len(priced[d]) > 0:
                string += ' | MeanDuration='+str(int(np.array(priced[d]).mean()))
            if len(priced[bs]) > 0:
                string += ' MeanBufferSteps='+str(int(np.array(priced[bs]).mean()))
            string += ' | TotalRewards='+str(np.array(priced[rf]).sum())
        string += '\nMission Jobs Done:'
        string += ' Number='+str(mission[n])
        if n_mission > 0:
            string += ' Percentage='+\
                    str(round(float(mission[n])/(n_mission), r))
        else:
            string += ' Percentage='+str(0.0)
        if mission[n] > 0:
            if len(mission[d]) > 0:
                string += ' | MeanDuration='+str(int(np.array(mission[d]).mean()))
            if len(mission[bs]) > 0:
                string += ' MeanBufferSteps='+str(int(np.array(mission[bs]).mean()))
            string += ' | TotalRewards='+str(np.array(mission[rf]).sum())
        string += '\nAuction Jobs Done:'
        string += ' Number='+str(auction[n])
        if n_auction > 0:
            string += ' Percentage='+\
                    str(round(float(auction[n])/(n_auction), r))
        else:
            string += ' Percentage='+str(0.0)
        if auction[n] > 0:
            if len(auction[d]) > 0:
                string += ' | MeanDuration='+str(int(np.array(auction[d]).mean()))
            if len(auction[bs]) > 0:
                string += ' MeanBufferSteps='+str(int(np.array(auction[bs]).mean()))
            string += ' | TotalRewards='+str(np.array(auction[rf]).sum())

        f_priced, f_mission, f_auction = Stats.get_jobs(done=False)
        string += '\n\nJobs Failed:'
        string += ' Number='+str(f_priced[n]+f_mission[n]+f_auction[n])
        if priced[n]+mission[n]+auction[n] > 0:
            string += ' Percentage='+\
                    str(round(float(f_priced[n]+f_mission[n]+f_auction[n])/\
                    (f_priced[n]+f_mission[n]+f_auction[n]+priced[n]+mission[n]+auction[n]),r))
        elif f_priced[n]+f_mission[n]+f_auction[n] > 0:
            string += ' Percentage='+str(1.0)
        else:
            string += ' Percentage='+str(0.0)
        if f_priced[n]+f_mission[n]+f_auction[n] > 0:
            if len(f_priced[d]+f_mission[d]+f_auction[d]) > 0:
                string+=' | MeanDuration='+str(int(np.array(f_priced[d]+f_mission[d]+f_auction[d])\
                        .mean()))
            if len(f_priced[bs]+f_mission[bs]+f_auction[bs]) > 0:
                string += ' MeanBufferSteps='+\
                        str(int(np.array(f_priced[bs]+f_mission[bs]+f_auction[bs]).mean()))
            string += ' | TotalFines='+str(np.array(f_priced[rf]+f_mission[rf]+f_auction[rf]).sum())
        string += '\nPriced Jobs Failed:'
        string += ' Number='+str(f_priced[n])
        if priced[n] > 0:
            string += ' Percentage='+str(round(float(f_priced[n])/(f_priced[n]+priced[n]), r))
        elif f_priced[n] > 0:
            string += ' Percentage='+str(1.0)
        else:
            string += ' Percentage='+str(0.0)
        if f_priced[n] > 0:
            if len(f_priced[d]) > 0:
                string += ' | MeanDuration='+str(int(np.array(f_priced[d]).mean()))
            if len(f_priced[bs]) > 0:
                string += ' MeanBufferSteps='+str(int(np.array(f_priced[bs]).mean()))
        string += '\nMission Jobs Failed:'
        string += ' Number='+str(f_mission[n])
        if mission[n] > 0:
            string += ' Percentage='+str(round(float(f_mission[n])/(f_mission[n]+mission[n]), r))
        elif f_mission[n] > 0:
            string += ' Percentage='+str(1.0)
        else:
            string += ' Percentage='+str(0.0)
        if f_mission[n] > 0:
            if len(f_mission[d]) > 0:
                string += ' | MeanDuration='+str(int(np.array(f_mission[d]).mean()))
            if len(f_mission[bs]) > 0:
                string += ' MeanBufferSteps='+str(int(np.array(f_mission[bs]).mean()))
            string += ' | TotalFines='+str(np.array(f_mission[rf]).sum())
        string += '\nAuction Jobs Failed:'
        string += ' Number='+str(f_auction[n])
        if auction[n] > 0:
            string += ' Percentage='+str(round(float(f_auction[n])/(f_auction[n]+auction[n]), r))
        elif f_auction[n] > 0:
            string += ' Percentage='+str(1.0)
        else:
            string += ' Percentage='+str(0.0)
        if f_auction[n] > 0:
            if len(f_auction[d]) > 0:
                string += ' | MeanDuration='+str(int(np.array(f_auction[d]).mean()))
            if len(f_auction[bs]) > 0:
                string += ' MeanBufferSteps='+str(int(np.array(f_auction[bs]).mean()))
            string += ' | TotalFines='+str(np.array(f_auction[rf]).sum())

        number, costs = Stats.get_wells_built()
        string += '\n\nWells Built:'
        string += ' Number='+str(number)
        string += ' Costs='+str(costs)

        string += '\n'+separation

        print(string)

if __name__ == '__main__':

    try:
        while True:
            Stats.print_all_statistics()
            rospy.sleep(1.0)
    except KeyboardInterrupt:
        pass
