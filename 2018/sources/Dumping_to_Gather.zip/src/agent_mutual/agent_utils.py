from __future__ import division # force floating point division when using plain /

import rospy
import re
import time

from mac_agent.msg import Plans, GatherNAssemblePlan, DeliverPlan, AssemblePlan, GatherNDeliverPlan,\
        RetrieveNAssemblePlan, RetrieveNDeliverPlan,\
        GatherResourcePlan, DeliverItemsPlan

from agent_mutual.constants import Constants

try:
    from Queue import PriorityQueue # ver. < 3.0
except ImportError:
    from queue import PriorityQueue

def get_duration(waypoints):
    '''
    Returns the planned duration to traverse along the given Waypoints.
    :param waypoints: the waypoints to consider
    :type waypoints: Waypoint[]
    :return: the duration
    :type: uint32
    '''
    duration = 0
    for w in waypoints:
        if not w.skip:
            if w.steps_to > w.total_steps_to:
                duration += w.steps_to
            else:
                duration += w.total_steps_to
            if w.steps_at > w.total_steps_at:
                duration += w.steps_at
            else:
                duration += w.total_steps_at
        else:
            duration += w.total_steps_to + w.total_steps_at
    return duration

def get_items_string(items):
    return '['+','.join(str(item.amount)+'xi'+str(get_number(item.name)) for item in items)+']'

def get_task_string(task):
    return '('+task.job_id+' #'+str(task.task_id)+' '+type(task).__name__+') '

def get_plan(task_id, plans):
    for p in plans:
        if task_id == p.task.task_id:
            return p
    log('get_plan', 'No plan with the id "'+str(task_id)+'" contained: '+\
            str([p.task.task_id for p in plans])+'!', 'err')
    return None

def get_position(name, instances):
    for i in instances:
        if i.name == name:
            return i.pos
    log('get_position', 'No instance with the name "'+str(name)+'" contained!', 'err')
    return None

def zip_plans(plans):
    '''
    Wraps the given plans into the Plans message. Necessary to send plans of different types by ros
    topics / services. (I know we could define the plans more general to send by ros... but no time.)
    :param plans: list of plans
    :type plans: Plan[]
    :return: the plans message
    :type: Plans
    '''
    gather_n_assemble_plans = []
    gather_n_deliver_plans = []
    retrieve_n_assemble_plans = []
    retrieve_n_deliver_plans = []
    deliver_plans = []
    assemble_plans = []
    for p in plans:
        if type(p).__name__ == GatherNAssemblePlan.__name__:
            gather_n_assemble_plans.append(p)
        elif type(p).__name__ == GatherNDeliverPlan.__name__:
            gather_n_deliver_plans.append(p)
        elif type(p).__name__ == RetrieveNAssemblePlan.__name__:
            retrieve_n_assemble_plans.append(p)
        elif type(p).__name__ == RetrieveNDeliverPlan.__name__:
            retrieve_n_deliver_plans.append(p)
        elif type(p).__name__ == AssemblePlan.__name__:
            assemble_plans.append(p)
        elif type(p).__name__ == DeliverPlan.__name__:
            deliver_plans.append(p)
        else:
            log('zip', 'Plan not implented yet: '+str(type(p).__name__)+'!', 'err')
    return Plans(gather_n_assemble_plans=gather_n_assemble_plans, assemble_plans=assemble_plans,\
            deliver_plans=deliver_plans, gather_n_deliver_plans=gather_n_deliver_plans,\
            retrieve_n_assemble_plans=retrieve_n_assemble_plans,\
            retrieve_n_deliver_plans=retrieve_n_deliver_plans)

def unzip_plans(plans):
    '''
    Unwraps the given plans message into an array and sorts the plans by execution start time.
    :param plans: the plans message
    :type plans: Plans
    :return: the sorted list of plans
    :type: Plan[]
    '''
    q = PriorityQueue()
    for gnap in plans.gather_n_assemble_plans:
        q.put((gnap.start_step, gnap))
    for gndp in plans.gather_n_deliver_plans:
        q.put((gndp.start_step, gndp))
    for rnap in plans.retrieve_n_assemble_plans:
        q.put((rnap.start_step, rnap))
    for rndp in plans.retrieve_n_deliver_plans:
        q.put((rndp.start_step, rndp))
    for dp in plans.deliver_plans:
        q.put((dp.start_step, dp))
    for ap in plans.assemble_plans:
        q.put((ap.start_step, ap))
    n = q.qsize()
    return [q.get()[1] for _ in range(n)]

def get_auctioneer_topic_prefix(agent_name):
    '''
    Returns the auctioneer topic prefix corresponding to the given agents name.
    :param agent_name: the agents name
    :type agent_name: string
    :return: the topic prefix
    :type: string
    '''
    return '/auctioneer_'+agent_name+'/'

def get_bidder_topic_prefix(agent_name):
    '''
    Returns the bidder topic prefix corresponding to the given agents name.
    :param agent_name: the agents name
    :type agent_name: string
    :return: the topic prefix
    :type: string
    '''
    return '/bidder_'+agent_name+'/'

def get_current_timestamp():
    '''
    Returns current time in microseconds
    :return: the current timestamp
    :type: uint64
    '''
    return int(time.time() * 1000000)

def get_bridge_topic_prefix(agent_name):
    """
    Returns the topic prefix for all topics of the bridge node corresponding to the agent
    :param agent_name: current agents name
    :return: prefix just before the topic name of the bridge
    """
    return '/bridge_node_' + agent_name + '/'

def get_agent_topic_prefix(agent_name):
    """
    Returns the topic prefix for all topics of the agent node corresponding to the agent
    :param agent_name: current agents name
    :return: prefix just before the topic name of the agent
    """
    return '/agent_' + agent_name + '/'

def get_knowledge_tuple_explore_facility(agent_name, facility):
    """
    Simple function to create uniform knowledge tuples for facility exploration
    :param agent_name: name of the considered agent
    :param facility: facility name or topic that is explored
    :return: generate tuple (agent_name, exploration_key)
    """
    return agent_name, 'explores_' + facility

def get_knowledge_tuple_explore_grid(agent_name):
    """
    Simple function to create uniform knowledge tuples for grid exploration
    :param agent_name: name of the considered agent
    :return: generate tuple (agent_name, exploration_key)
    """
    return agent_name, 'explores_grid'

def max_float():
    """
    Value that is used as default for distance minimization purposes (lat, lon).
    Big enough to be a maximum and small enough to not trigger RHBP memory errors.
    :return: some constant
    :type: float
    """
    return 400.0

def get_number(string):
    """
    Extracts one connected number from the given string.
    :param string: string to extract number from
    :type string: string
    :return: the extracted number
    :type: uint64
    """
    return int(re.findall(r'\d+', string)[0])

def get_agent_number():
    """
    Retrieves the number of agents from parameter server.
    :return: the number of agents
    :rtype: int
    """
    return int(rospy.get_param(param_name='~agent_number', default='34'))

def log(agent_name, text, logtype='info'):
    """
    Prints the given text together with the corresponding agent name to the standard output.
    :param agent_name: current agents name
    :param type: str
    :param text: text to print
    :param type: str
    :param logtype: log type
    :param type: str
    """
    f = None
    if logtype == 'info':
        f = rospy.loginfo
    elif logtype == 'debug':
        f = rospy.logdebug
    elif logtype == 'warn':
        f = rospy.logwarn
    elif logtype == 'err':
        f = rospy.logerr
    else:
        rospy.logerr('Not familiar with logtype: '+logtype)

    f("["+agent_name+"] "+text)

def get_knowledge_base_name():
    """
    Returns the name of the knowledge base name defined in the launch file.
    :return: the name of the Knowledge Base
    """
    return rospy.get_param(param_name='~knowledgeBaseName', default='knowledgeBaseNodeA')

def get_team_name():
    """
    Returns the name of the team defined in the launch file. Must be set in launch file! Alternatively, use team
    name given by SimStart message.
    :return: the name of the team
    """
    return rospy.get_param(param_name='~team', default='')
