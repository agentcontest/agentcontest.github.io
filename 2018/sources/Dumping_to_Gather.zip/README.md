# Multi-Agent Programming Contest - Group 2 - Agent Workspace

## Wiki

For detailed information about this agent module please enter the [Wiki](https://gitlab.tubit.tu-berlin.de/asp_b_ss18-group2/mac_agent/wikis/home).

## Repositories

### Get the code

First enter your workspace directory:
```
cd <path>/<your workspace>
```
Clone the main mapc_workspace:
```
git clone https://gitlab.tubit.tu-berlin.de/asp_b_ss18/mapc_workspace
```
enter the mapc_workspace:
```
cd mapc_workspace
```
change your current branch to our group branch:
```
git checkout group2
```
and initialize the submodules:
```
git submodule update --init
```
and go back to your workspace directory:
```
cd ..
```
Clone the massim server repository
```
git clone https://github.com/agentcontest/massim.git massim18
```
and move it into a newly created massim directory
```
mkdir massim
mv massim18 massim
```
* your workspace
    * mapc_workspace
    * massim
      * massim18 (src root directory)

and once execute maven in the src root directory
```
cd massim/massim18
mvn install
```
In the end install the python geopy module which is used by the pathplanner:
```
sudo -H pip install geopy
```
### Our mac_agent submodule repository

#### Push to the mac_agent repo
To push your changed `mac_agent` submodule code, you have to enter the directory first:
```
cd <path>/<your workspace>/mapc_workspace/src/mac_agent/
```
If the changes aren't already in there copy your changes into the directory and do the standard git stuff:
```
git add --all
git commit -m "this commit is about this"
git push origin <branch of your choice>
```
#### Update the mac_agent submodule in the mapc_workspace repo
To update the mac_agent submodule in the mapc_workspace repository switch to that repo
```
cd <path>/<your workspace>/mapc_workspace/src/mac_agent/
```
and pull the master branch
```
git pull origin master
```
then enter the mapc_workspace root directory
```
cd ../..
```
switch the branch to our branch:
```
git checkout group2
```
and do the standard git stuff to update the head of the submodule
```
git add --all
git commit -m "update mac_agent submodule"
git push origin group2
```
## Link, Build & Launch

### Link ROS with your workspace
Enter your home directory
```
cd
```
Open the bashrc
```
gedit .bashrc
```
Copy the following lines to the end of the bashrc
```
source /opt/ros/kinetic/setup.bash
source <path>/<your workspace>/devel/setup.bash
```
Then save the bashrc and close your open terminals.

### Build the workspace
Enter the mapc_workspace directory:
```
cd <path>/<your workspace>/mapc_workspace
```
then build the code:
```
catkin_make
```
### Launch server & agents
Start the massim server:
```
./script/start_massim_src.sh
```
and choose a simulation configuration.

Start the agent nodes by executing a launchfile e.g.:
```
roslaunch mac_agent agents6_example.launch
```
Start the simulation by pressing ENTER in the massim server console.

View the running simulation by entering the address
```
localhost:8000
```
in your browser.
