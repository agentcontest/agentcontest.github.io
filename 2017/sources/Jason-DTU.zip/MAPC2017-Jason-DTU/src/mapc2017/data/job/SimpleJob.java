package mapc2017.data.job;

public class SimpleJob extends Job {

	public SimpleJob(Job job) {
		super(job);
	}

}
