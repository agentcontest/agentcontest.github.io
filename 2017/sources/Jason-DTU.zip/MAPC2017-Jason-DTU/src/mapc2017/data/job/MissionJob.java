package mapc2017.data.job;

public class MissionJob extends AuctionJob {

	public MissionJob(AuctionJob job) {
		super(job);
	}

}
