package mapc2017.data.job;

public class PostedJob extends Job {

	public PostedJob(Job job) {
		super(job);
	}

}
