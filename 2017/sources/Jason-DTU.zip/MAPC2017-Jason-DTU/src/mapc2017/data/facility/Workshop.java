package mapc2017.data.facility;

public class Workshop extends Facility {

	public Workshop(Facility facility) {
		super(facility);
	}

}
