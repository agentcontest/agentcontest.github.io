package mapc2017.data.facility;

public class Dump extends Facility {

	public Dump(Facility facility) {
		super(facility);
	}

}
