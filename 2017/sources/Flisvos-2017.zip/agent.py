
"""

 /*
  * @(#) E.Sarmas   agent.py 0.9_63 (2017-09-18)
  *
  * Author: E.Sarmas
  *
  * Created: 2017-04-06
  *
  * Description: Flisvos 2017 (MAPC 2017)
  *
  * Version: 0.9_63
  * Version-Date: 2017-09-18
  *
  * Version-Log:
  *   0.1_0 (2017-04-06)   copy from Flisvos-2016
  *   0.1_9 (2017-05-29)   rewrite so stable core and fewer changes per scenario/implementation
  *   0.6_0 (2017-06-01)   refactoring, new sim messages/info (except distance calcs), running
  *                        fewer import dependency chains, code moved to more appropriate modules
  *                        logging messages with lambda: now, may speed up logging
  *                        single method to recursively decode messages
  *                        log_data moved within attr_dict as instance method
  *                        clear agent action handling/protocol and procedures/statistics/logging level use
  *                        removed items_db, jobs_spec moved in team
  *                        simple class method like procedures for data updates within appropriate module
  *                        clearer procedure interrelationships, existence and use
  *                        cache improvement to be useful for all roles
  *                        cleaner use of JOB_STEPS_FAC so no double use and wrong results
  *                        clearer method use protocol and use of other procedures for data updates
  *                        agents_with_item_on_board and agents_with_item_buy removed and embedded
  *                        introduced deliver_jobs and explore_buys
  *                        jobs_selection does not select but returns base recipe for all not ignored jobs
  *                        new_jobs now setups assembly or marks for delivery already assembled job
  *                        deliver_jobs may arrange first moves (give and take) to fewer and faster agents
  *   0.9_50 (2017-09-03)  qualification run, new_jobs/deliver_jobs/explore_buys disabled
  *   0.9_52 (2017-09-05)  added EXERCIZE_MODE as in qualification to test goto/charge/recharge system
  *                        ability to recover a job_op, for op_goto to recover from battery stalls by
  *                        recharging enough steps for next charging station and then going to destination
  *                        new dist_cache_history, random fail steps not counted
  *                        lowered level of all goto steps calculations
  *                        random fails don't stop op_goto(s) (bad interaction of reset/send_action )
  *                        also handled correctly if happen on first step of action
  *                        fixed job_op drop and job_drop confusion
  *                        new job_data[], SPEC tracks missions and removes fine from money
  *                        better handling of actions that indicate errors (ACTION_ERRORS)
  *                        new action retrieve_delivered and procedure retrieve_delivered in plan
  *                        new dict job_failed, and sets failed_jobs, just_failed_jobs
  *                        clearer actions for job_set_completed and job_set_failed (new), update_jobs_spec
  *                        reassigned role of job_db, new dict job_party
  *                        new procedures single_recharge and single_recharge_goto for faster recharge
  *                        creat can be called with agent in charging_station in future (with charge_level)
  *                        explore_jobs works without jobs and uses tool compatibility
  *                        along with mission and priced job needs in a useful order
  *                        refactored explore_jobs setup merging all loops, and removed shop_estimate
  *                        organized job work in phases (assembly, move, delivery)
  *                        move phase orchestrates give->receive to fewer better fit agents to deliver_jobs
  *                        and works like cpu instruction scheduling filling empty slots when needed
  *                        jobs_selection finally embedded within explore_jobs
  *                        explore_jobs considers better the suitability of each shop to finish jobs
  *                        and considers agent tool_compatibility better, and also global tool cover
  *                        socket timeout to 20 sec, never low value
  *                        enhanced strategy for CHECK-ERR asserts and other CHECK-... almost everywhere
  *                        is the fastest way to verify coverage and correct operation
  *                        changed logging levels everywhere so comfortable view of logging output
  *                        new failed action recovery logic, improved recover and drop functions 
  *                        checked all actions to send an action to server
  *                        new action.has_next() and use of next_action() only after barrier
  *                        so job_drop() works correctly with current action inside barrier
  *                        strange float calcs fixed (FLOAT_EP)
  *                        new job_state_check and actions_state_check, set jobs to drop (just_failed_jobs)
  *                        disabled move operations (give->receive to fewer and faster agents)
  *                        because not so important and code not tested well for crashes and more...
  *                        explore_buys only if no concurrent buy in same shop and only for items
  *   0.9_63 (2017-09-18)  good luck :) 
  */

"""



import logging
import threading

import comm
import util
import goto
import actions
import team
import plan
import main



# DETAIL < DEBUG <   OP < INFO   < WARNING+
# agent log file =   LOG_DEBUG or LOG_DETAIL (verbose)
# main  log file =   LOG_OP
# console        =   LOG_INFO

LOGFILE_FORMAT = main.LOGFILE_FORMAT
LOGFILE_PREFIX = main.LOGFILE_PREFIX

LOG_OP = 19
LOG_DEBUG = 10
LOG_DETAIL = 9



STEP_RESPONSE_THRESHOLD = util.STEP_RESPONSE_THRESHOLD

# for speed and easy dependency / code coverage checking
LapTimer = util.LapTimer
attr_dict = util.attr_dict
Smart_Log = util.Smart_Log

settings = util.settings
print_settings = util.print_settings
print_start = util.print_start
print_view = util.print_view
print_shop_inventory = util.print_shop_inventory
update_self_tools = util.update_self_tools
create_item_db = util.create_item_db
item_spec = util.item_spec

set_map = goto.set_map
set_sim = goto.set_sim
print_sim = goto.print_sim
print_fac_goto = goto.print_fac_goto
update_fac_agents = goto.update_fac_agents
print_fac_agents = goto.print_fac_agents
print_goto_stats = goto.print_goto_stats
print_dist_cache = goto.print_dist_cache

skip = actions.skip

jobs_spec = team.jobs_spec
job_state_check = team.job_state_check
actions_state_check = team.actions_state_check
drop_jobs = team.drop_jobs
update_max_inventory = team.update_max_inventory
update_resource_nodes = team.update_resource_nodes
update_action_stats = team.update_action_stats
print_money_stats = team.print_money_stats
job_QoS_stats = team.job_QoS_stats
print_committed_status = team.print_committed_status
print_team_status = team.print_team_status
print_end = team.print_end
team_initialize = team.team_initialize

recharge = plan.recharge
new_jobs = plan.new_jobs
global_tools_coverage = plan.global_tools_coverage
explore_jobs = plan.explore_jobs
move_jobs = plan.move_jobs
deliver_jobs = plan.deliver_jobs
set_plan_shared = plan.set_plan_shared
explore_buys_forced = plan.explore_buys_forced
explore_buys = plan.explore_buys
retrieve_delivered = plan.retrieve_delivered



x_lock = threading.Lock()
#x_sema = threading.Semaphore(0)

RESULT_OK = ["successful", "successful_partial", "useless"]

ACTION_NOACTION = "noAction"
ACTION_RANDOM_FAIL = "randomFail"
ACTION_UNKNOWN = "unknownAction"

ACTION_ERRORS = [ACTION_NOACTION, ACTION_RANDOM_FAIL, ACTION_UNKNOWN]
ACTION_FAILS = [ACTION_NOACTION, ACTION_RANDOM_FAIL]

class Agent(threading.Thread):
  
  def __init__(self, id, host, port, agent_name, password, shared, verbose):
    threading.Thread.__init__(self)
    self._id = id
    self._host = host
    self._port = port
    self._agent_name = agent_name
    self._password = password
    self._shared = shared
    # specific entry value for this agent in "shared"
    self._agent_shared = None
    self._verbose = verbose
    
    log = logging.getLogger(agent_name)
    # must set !
    if verbose:
      log.setLevel(LOG_DETAIL)
    else:
      log.setLevel(LOG_DEBUG)
    
    # agent log file gets LOG_DEBUG or LOG_DETAIL if verbose
    agent_logfile = logging.FileHandler(filename = LOGFILE_PREFIX + agent_name + ".log", mode = "w")
    if verbose:
      agent_logfile.setLevel(LOG_DETAIL)
    else:
      agent_logfile.setLevel(LOG_DEBUG)
    agent_logfile.setFormatter(logging.Formatter(LOGFILE_FORMAT))
    log.addHandler(agent_logfile)
    
    log = Smart_Log(log)
    self._log = log
    
    self._comm = comm.Comm(id, host, port, agent_name, password, verbose)
    
    # agent start
    log.info(lambda: "thread {}   started logging... (level = {})".format(self.name, log.getEffectiveLevel())) 
    
    self.init_start()
    
    self._event = threading.Event()
  
  def init_start(self):
    self._step = 0
    self._money = 0
    self.sim = None
    self.view = None
    self.sim_result = None
    self.compat_tools = None
    self.self_tools = None
    self.new_tools = None
    self.job_op = None
    self.failed = False
  
  def run(self):
    
    """
    t_start = time.time()
    while True:
      time.sleep(self._id/5+1)
      self._log.info(lambda: "koukou, id = {:d}".format(self._id))
      t_now = time.time()
      if t_now > t_start + 10:
        break
    """
    
    log = self._log
    agent_name = self._agent_name
    #thread_data = threading.local()
    lap_timer = LapTimer(log, log_level=LOG_OP)
    while True:
      msg_type, data, msg_xml, msg_str = self._comm.get_msg()
      log.debug(lambda: "agent, msg_type = {:s}".format(msg_type))
      
      if msg_type == "sim-start":
        self.init_start()
        self.sim = data
        print_start(self)
        
        with x_lock:
          # shared init
          self._shared[agent_name] = attr_dict({
            "_id": self._id, "_agent_name": self._agent_name, "_log": self._log,
            "sim": self.sim, "view": self.view,
            "compat_tools": None, "self_tools": None, "new_tools": None,
            "job_op": None, "failed": False,
            "inwait": False, "event": self._event
          })
          self._agent_shared = self._shared[agent_name]
        continue
      
      if msg_type == "sim-end":
        self.sim_result = data
        # dist cache history
        print_dist_cache(self)
        # final end
        print_end(self)
        continue
      
      if msg_type == "bye":
        break
      
      if msg_type == "request-action":
        lap_timer.lap_start()
        shared = self._shared
        agent_shared = self._agent_shared
        self.view = data
        self._step = int(data.simulation.step)
        step = self._step
        self._money = int(data.team.money)
        
        print_view(self)
        # update inventory of tools on board
        update_self_tools(self)
        
        # === state handling (agent) ===        
        x = data.self.action
        percept_action = x.type
        percept_action_result = x.result
        log.debug(lambda: "step = {:d}, *** action: {} => {} ***".format(
          step, percept_action, percept_action_result
        ))
        
        if percept_action in ACTION_ERRORS:
          log.log(LOG_OP, lambda: "step = {:d}, CHECK-ERR:   ***   {}   ***   => {}".format(step, percept_action, percept_action_result))
        elif (self.job_op is None and percept_action != "skip"):
          log.log(LOG_OP, lambda: "step = {:d}, CHECK-ERR:   skip vs system {} => {}".format(
            step, percept_action, percept_action_result
          ))
        
        # update job step, check if successful last action
        failed = False        
        last_action = None
        if self.job_op is not None:
          op_action = job_op.action()
          
          if (percept_action_result not in RESULT_OK or percept_action in ACTION_FAILS) and op_action._type != "skip":
            if percept_action_result not in RESULT_OK:
              log.log(LOG_OP, lambda: "step = {:d}, CHECK-ERR:   *** action: {}, {} => {} ***".format(
                step, op_action, percept_action, percept_action_result
              ))
            # system generated fails
            if percept_action in ACTION_FAILS:
              log.log(LOG_OP, lambda: "step = {:d}, action: {} random_fail, action reset !".format(step, op_action))
              op_action.reset(self)
            # a temp_failed indicates the failure is temporary and should retry action
            elif op_action.is_temp_failed(self, percept_action_result):
              log.log(LOG_OP, lambda: "step = {:d}, action: {} temp_fail, action reset !".format(step, op_action))
              op_action.reset(self)
            else:
              log.log(LOG_OP, lambda: "step = {:d}, action: {} failed (system): {:s} !!!".format(
                step, op_action, percept_action_result
              ))
              failed = True
          else:
            # as a side effect will setup shared data to be updated
            if op_action.is_active(self, percept_action, percept_action_result):
              log.log(LOG_OP, lambda: "step = {:d}, action: {} continues (step {:d})".format(step, op_action, op_action.run_step(self)))
              last_action = op_action
            else:
              if op_action.is_failed(self):
                log.log(LOG_OP, lambda: "step = {:d}, CHECK-ERR:   action: {} failed (internal): {:s} !!!".format(
                  step, op_action, op_action.failed_error(self)
                ))
                failed = True
              else:
                ### NOTE: keep exact copy in team.actions_state_check
                log.log(LOG_OP, lambda: "step = {:d}, action: {} finished".format(step, op_action))
                last_action = op_action
                op_action = job_op.next_action()
                if op_action is None:
                  log.log(LOG_OP, lambda: "step = {:d}, job has no more actions, deleted".format(step))
                  self.job_op = None
                ### NOTE ###
        self.failed = failed
        
        # if restarting then abort any past action before crash (goto)
        # useless ? since a new goto seems to override a previous running goto
        #if len(data.route) > 0 and self.job_op is None:
        #  log.warning(lambda: "step = {:d}, aborting previous goto !".format(step))
        #  action_seq = actions.Action_Seq()
        #  action_seq.append(actions.op_abort(agent_name, 1))
        #  self.job_op = action_seq
        
        #log.debug(lambda: "agent, pre x_lock")        
        lap_timer.sub_lap("pre x_lock", log_level=LOG_DEBUG)
        
        # update shared with own data and optionally evaluate new job
        with x_lock:
          # === lock part (agent) ===
          log.debug(lambda: "agent, in x_lock")
          
          agent_shared.inwait = True
          agent_shared.view = data
          agent_shared.compat_tools = self.compat_tools
          agent_shared.self_tools = self.self_tools
          agent_shared.new_tools = self.new_tools
          agent_shared.job_op = self.job_op
          agent_shared.failed = self.failed
          
          update_resource_nodes(self)
          # runs only on success ("successful", "successful_partial", "useless")
          if last_action is not None:
            last_action.update_shared(self, percept_action, percept_action_result)
          update_action_stats(self, percept_action_result)
          
          self._event.clear()
          
          # serious issue, if not all threads connect on same step then none detects last and all stay locked here
          # fixed with check on inwait flag
          # BUT still could have situation where half threads one step ahead of other half
          # because half enter barrier at one time and then all
          # so extra check if all NUM_AGENTS present
          all_updated = True
          max_step = 0
          min_step = util.MAX_STEPS
          for x_agent_name, x_agent_data in shared.items():
            if x_agent_data.inwait is False:
              all_updated = False
              break
            x_step = int(x_agent_data.view.simulation.step)
            if x_step > max_step:
              max_step = x_step
            if x_step < min_step:
              min_step = x_step
          
          # === lock part (shared) ===
          
          ### debug
          """
          log.debug(lambda: "step = {}, all_updated = {}, len(shared) = {:d}, min_step = {:d}, max_step = {:}".format(
            agent_shared.view.simulation.step, all_updated, len(shared), min_step, max_step
          ))
          for x_agent_name in sorted(shared.keys(), key=util.natural_sort_key):
            x_agent_shared = shared[x_agent_name]
            x_step = None
            if x_agent_shared.view is not None:
              x_step = x_agent_shared.view.simulation.step
            x_inwait = x_agent_shared.inwait
            log.debug(lambda: "{:s}({}), inwait = {}".format(x_agent_name, x_step, x_inwait))
          """
          
          is_update_thread = (all_updated and len(shared) == main.NUM_AGENTS)
          
          if is_update_thread and min_step == max_step:
            
            log.log(LOG_OP, lambda: "*** step = {:d} last thread to update shared, doing job evaluation\n".format(step))
            # the following update shared data structure and assume are free to do within lock region
            
            #
            # NOTE: all operations here are serializable
            #
            
            #
            # BEGIN
            #
            lap_timer.sub_lap("pre main loop")
            
            # moved here from start-sim, if sudden out of step during sim change then could go wrong
            # team init
            if (getattr(goto, "sim_id", None) is None or goto.sim_id != self.sim.id
              or getattr(goto, "map_name", None) is None or goto.map_name != self.sim.map):
              set_map(self)
              set_sim(self)
              team_initialize()
              log.info(lambda: "*** step = {:d} new sim = {}, map = {} !!!\n".format(step, goto.sim_id, goto.map_name))
            team.step = max_step
            
            if team.first_loop:
              team.first_loop = False
              print_sim(self)
            
            # dynamic settings update !?
            settings(self)
            
            # (once) item_db and tool_db
            if not team.item_db:
              create_item_db(self)
              item_spec(self)
            
            # !!! test only !!!
            #util.test_joins(log)
            
            lap_timer.sub_lap("settings + admin")
            
            # !!! test only !!!
            #util.test_actions(self)
            
            #update_shop_inventory(self)
            #if step <= 3:
            #  update_max_inventory(self)
            #if not team.max_inventory:
            #  log.warning(lambda: "*** step = {:d} no max_inventory !!!\n".format(step))
            
            actions_state_check(self)
            
            update_fac_agents(self)
            
            jobs_spec(self)
            
            lap_timer.sub_lap("updates")
            
            # new plan shared, to avoid many recalculations and better situational awareness
            set_plan_shared(self)
            lap_timer.sub_lap("set plan shared")
            
            # drop just removed jobs
            drop_jobs(self)
            lap_timer.sub_lap("drop jobs")
            
            # retrieve all delivered items for removed jobs
            retrieve_delivered(self)
            lap_timer.sub_lap("retrieve delivered")
            
            #if util.MOVE_ENABLE:
            #  # schedule moves of any completed assemblies, may free agents
            #  move_jobs(self)
            #  lap_timer.sub_lap("move jobs")
            
            # schedule any completed assemblies, may free agents
            deliver_jobs(self)
            lap_timer.sub_lap("deliver jobs (1)")
            
            # check job operational state
            job_state_check(self)
            lap_timer.sub_lap("job state check")
            
            # never to use, all jobs will be complete before committing
            #complete_jobs(self)
            
            new_jobs(self)
            lap_timer.sub_lap("new jobs")
          
            # schedule any new jobs already complete, unusual but possible
            deliver_jobs(self)
            lap_timer.sub_lap("deliver jobs (2)")
            
            explore_buys_forced(self)
            lap_timer.sub_lap("explore buys forced")
            explore_buys(self)
            lap_timer.sub_lap("explore buys")
            
            explore_jobs(self)
            lap_timer.sub_lap("explore jobs")
            
            # no op and no charge to move around
            # could allow to buy if in shop and then recharge
            # but recharge is slow and whole process cannot be estimated well by creat
            # so not useful in the end
            recharge(self)
            lap_timer.sub_lap("recharge")
            
            #plan.dump_ops(self)
            
            # finally, some cookies, CC or CuriousCat op
            #plan.CC_op(self)
            
            lap_timer.sub_lap("other actions")
            
            # TODO... review, consolidate some logging ???
            
            # fac -> agents on spot
            print_fac_agents(self)
            
            # fac -> agents goto-ing
            print_fac_goto(self)
            
            # shop inventory
            print_shop_inventory(self)
            
            # goto stats
            print_goto_stats(self)
            
            # status logging
            print_team_status(self)
            
            # settings
            print_settings(self)
            
            # QoS
            job_QoS_stats(self)
            
            # committed jobs status
            print_committed_status(self)
            
            # available jobs summary, subsumed by SPEC messages
            #jobs_db.summary(self)
            
            # global tools coverage
            global_tools_coverage(self)
            
            # money stats
            print_money_stats(self)
            
            lap_timer.sub_lap("status logging")
            #
            # END
            #
          
          # open barrier
          # TODO, perhaps should unlock all to minimize collapse of sync with server
          if all_updated:
            #if min_step < max_step:
            #  self.unlock_min_agents(max_step)
            #else:
            #  self.unlock_all_agents()
            self.unlock_all_agents()
            
            #for x_agent_name, x_agent_data in shared.items():
            #  x_agent_data.inwait = False
            #for x_agent_name, x_agent_data in shared.items():
            #  x_sema.release()
        
        lap_timer.sub_lap("post x_lock", log_level=LOG_DEBUG)
        #log.debug(lambda: "agent, post x_lock, event wait")
        
        #x_sema.acquire()
        self._event.wait()
        
        #log.debug(lambda: "agent, event wakeup")
        
        # === action execution part (agent) ===
        # job_op
        prev_job_op = self.job_op
        job_op = agent_shared.job_op
        self.job_op = job_op
        if job_op is not None:
          drop_replaced = prev_job_op is not None and (prev_job_op._drop_state == False and job_op._drop_state == True)
          if prev_job_op is None or drop_replaced:
            drop_replaced_tag = "DROP => " if drop_replaced else ""
            log.log(LOG_OP, lambda: "step = {:d}, new job_op = {}{}".format(step, drop_replaced_tag, job_op))
          op_action = job_op.action()
          if not op_action.is_active(self) or op_action.is_continuous(self):
            op_action.send_action(self)
            log.log(LOG_OP, lambda: "step = {:d}, action: {} sent".format(step, op_action))
          else:
            # continue
            skip(self)
        else:
          # default
          skip(self)
        
        ela = lap_timer.lap("complete", log_level=LOG_DEBUG)
        ###log.debug(lambda: "elapsed time = {:.3f}".format(ela))
        if ela > STEP_RESPONSE_THRESHOLD:
          log.warning(lambda: "step = {:d}, elapsed time = {:.3f} exceeded threshold = {:.3f}".format(step, ela, STEP_RESPONSE_THRESHOLD))
          
        log.debug(lambda: "\n")
  
  def unlock_all_agents(self):
    log = self._log
    shared = self._shared
    step = self._step
    
    log.log(LOG_OP, lambda: "*** step = {:d}, unlock barrier for (all) {:d} of {:d}, NUM_AGENTS = {:d}\n".format(
      step, len(shared), len(shared), main.NUM_AGENTS
    ))
    
    for x_agent_name, x_agent_data in shared.items():
      x_agent_data.inwait = False
      x_agent_data.event.set()
  
  def unlock_min_agents(self, max_step):
    log = self._log
    shared = self._shared
    step = self._step

    q = []
    for x_agent_name, x_agent_data in shared.items():
      x_step = int(x_agent_data.view.simulation.step)
      if x_step < max_step:
        q.append(x_agent_data)
    
    log.log(LOG_OP, lambda: "*** step = {:d}, unlock barrier for (min) {:d} of {:d}, NUM_AGENTS = {:d}\n".format(
      step, len(q), len(shared), main.NUM_AGENTS
    ))
    
    for x_agent_data in q:
      x_agent_data.inwait = False
      x_agent_data.event.set()