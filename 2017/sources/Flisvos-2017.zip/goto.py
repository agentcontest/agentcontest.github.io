
"""

 /*
  * @(#) E.Sarmas   goto.py 0.9_63 (2017-09-18)
  *
  * Author: E.Sarmas
  *
  * Created: 2017-04-06
  *
  * Description: Flisvos 2017 (MAPC 2017)
  *
  * Version: 0.9_63
  * Version-Date: 2017-09-18
  *
  * Version-Log:
  *   0.1_0 (2017-04-06)   copy from Flisvos-2016
  *   0.1_9 (2017-05-29)   rewrite so stable core and fewer changes per scenario/implementation
  *   0.6_0 (2017-06-01)   refactoring, new sim messages/info (except distance calcs), running
  *                        fewer import dependency chains, code moved to more appropriate modules
  *                        logging messages with lambda: now, may speed up logging
  *                        single method to recursively decode messages
  *                        log_data moved within attr_dict as instance method
  *                        clear agent action handling/protocol and procedures/statistics/logging level use
  *                        removed items_db, jobs_spec moved in team
  *                        simple class method like procedures for data updates within appropriate module
  *                        clearer procedure interrelationships, existence and use
  *                        cache improvement to be useful for all roles
  *                        cleaner use of JOB_STEPS_FAC so no double use and wrong results
  *                        clearer method use protocol and use of other procedures for data updates
  *                        agents_with_item_on_board and agents_with_item_buy removed and embedded
  *                        introduced deliver_jobs and explore_buys
  *                        jobs_selection does not select but returns base recipe for all not ignored jobs
  *                        new_jobs now setups assembly or marks for delivery already assembled job
  *                        deliver_jobs may arrange first moves (give and take) to fewer and faster agents
  *   0.9_50 (2017-09-03)  qualification run, new_jobs/deliver_jobs/explore_buys disabled
  *   0.9_52 (2017-09-05)  added EXERCIZE_MODE as in qualification to test goto/charge/recharge system
  *                        ability to recover a job_op, for op_goto to recover from battery stalls by
  *                        recharging enough steps for next charging station and then going to destination
  *                        new dist_cache_history, random fail steps not counted
  *                        lowered level of all goto steps calculations
  *                        random fails don't stop op_goto(s) (bad interaction of reset/send_action )
  *                        also handled correctly if happen on first step of action
  *                        fixed job_op drop and job_drop confusion
  *                        new job_data[], SPEC tracks missions and removes fine from money
  *                        better handling of actions that indicate errors (ACTION_ERRORS)
  *                        new action retrieve_delivered and procedure retrieve_delivered in plan
  *                        new dict job_failed, and sets failed_jobs, just_failed_jobs
  *                        clearer actions for job_set_completed and job_set_failed (new), update_jobs_spec
  *                        reassigned role of job_db, new dict job_party
  *                        new procedures single_recharge and single_recharge_goto for faster recharge
  *                        creat can be called with agent in charging_station in future (with charge_level)
  *                        explore_jobs works without jobs and uses tool compatibility
  *                        along with mission and priced job needs in a useful order
  *                        refactored explore_jobs setup merging all loops, and removed shop_estimate
  *                        organized job work in phases (assembly, move, delivery)
  *                        move phase orchestrates give->receive to fewer better fit agents to deliver_jobs
  *                        and works like cpu instruction scheduling filling empty slots when needed
  *                        jobs_selection finally embedded within explore_jobs
  *                        explore_jobs considers better the suitability of each shop to finish jobs
  *                        and considers agent tool_compatibility better, and also global tool cover
  *                        socket timeout to 20 sec, never low value
  *                        enhanced strategy for CHECK-ERR asserts and other CHECK-... almost everywhere
  *                        is the fastest way to verify coverage and correct operation
  *                        changed logging levels everywhere so comfortable view of logging output
  *                        new failed action recovery logic, improved recover and drop functions 
  *                        checked all actions to send an action to server
  *                        new action.has_next() and use of next_action() only after barrier
  *                        so job_drop() works correctly with current action inside barrier
  *                        strange float calcs fixed (FLOAT_EP)
  *                        new job_state_check and actions_state_check, set jobs to drop (just_failed_jobs)
  *                        disabled move operations (give->receive to fewer and faster agents)
  *                        because not so important and code not tested well for crashes and more...
  *                        explore_buys only if no concurrent buy in same shop and only for items
  *   0.9_63 (2017-09-18)  good luck :) 
  */

"""



import collections
import math

import util
import goto



# DETAIL < DEBUG <   OP < INFO   < WARNING+
# agent log file =   LOG_DEBUG or LOG_DETAIL (verbose)
# main  log file =   LOG_OP
# console        =   LOG_INFO

LOG_OP = 19
LOG_DETAIL = 9



defaultdict = collections.defaultdict
Counter = collections.Counter

ceil = math.ceil
sqrt = math.sqrt
sin = math.sin
asin = math.asin
cos = math.cos

###MAPS = util.MAPS
QUAD_SIZE = util.QUAD_SIZE

# these parameters must not change dynamically
DIST_ROUTE_FAC = util.DIST_ROUTE_FAC

STEP_CHARGE = util.STEP_CHARGE
RECHARGE_RATE = util.RECHARGE_RATE

JOB_STEPS_FAC = util.JOB_STEPS_FAC

MAX_INT = util.MAX_INT

Duo = util.Duo
Hexa = util.Hexa

sign = util.sign
natural_sort_key = util.natural_sort_key
one_line_key_val_f = util.one_line_key_val_f
one_line_key_s = util.one_line_key_s



MAP_MIN_LAT = 51.4647
MAP_MAX_LAT = 51.5223
MAP_MIN_LON = -0.1978
MAP_MAX_LON = -0.0354
MAP_CENTER_LAT = (MAP_MIN_LAT + MAP_MAX_LAT) / 2
MAP_CENTER_LON = (MAP_MIN_LON + MAP_MAX_LON) / 2

MAP_CELLS_LAT = ceil((MAP_MAX_LAT - MAP_MIN_LAT)/util.CELL_SIZE)
MAP_CELLS_LON = ceil((MAP_MAX_LON - MAP_MIN_LON)/util.CELL_SIZE)
MAP_CELLS = MAP_CELLS_LAT * MAP_CELLS_LON

MAP_QUADS_LAT = ceil((MAP_MAX_LAT - MAP_MIN_LAT)/QUAD_SIZE)
MAP_QUADS_LON = ceil((MAP_MAX_LON - MAP_MIN_LON)/QUAD_SIZE)
MAP_QUADS = MAP_QUADS_LAT * MAP_QUADS_LON



sim_id = "sim-athens"
map_name = "athens"

def set_map(agent):
  
  goto.dist_cache = {}
  goto.dist_cache_history = defaultdict(list)
  goto.goto_stats = defaultdict(int)
  goto.max_goto_fac = defaultdict(float)
  goto.fac_agents = defaultdict(set)
  goto.fac_goto = defaultdict(set)
  
  agent_sim = agent.sim
  goto.sim_id = agent_sim.id
  
  map_name = agent_sim.map
  goto.map_name = map_name
  
  """
  map_data = MAPS[map_name]
  goto.MAP_MIN_LAT = map_data.minLat
  goto.MAP_MAX_LAT = map_data.maxLat
  goto.MAP_MIN_LON = map_data.minLon
  goto.MAP_MAX_LON = map_data.maxLon
  """
  
  goto.MAP_MIN_LAT = float(agent_sim.minLat)
  goto.MAP_MAX_LAT = float(agent_sim.maxLat)
  goto.MAP_MIN_LON = float(agent_sim.minLon)
  goto.MAP_MAX_LON = float(agent_sim.maxLon)
  
  goto.MAP_CENTER_LAT = (goto.MAP_MIN_LAT + goto.MAP_MAX_LAT) / 2
  goto.MAP_CENTER_LON = (goto.MAP_MIN_LON + goto.MAP_MAX_LON) / 2
  
  goto.MAP_CELLS_LAT = ceil(euclidean_d(
    goto.MAP_MIN_LAT,    goto.MAP_CENTER_LON, goto.MAP_MAX_LAT,    goto.MAP_CENTER_LON
  ) / util.CELL_SIZE)
  goto.MAP_CELLS_LON = ceil(euclidean_d(
    goto.MAP_CENTER_LAT, goto.MAP_MIN_LON,    goto.MAP_CENTER_LAT, goto.MAP_MAX_LON
  ) / util.CELL_SIZE)
  goto.MAP_CELLS = goto.MAP_CELLS_LAT * goto.MAP_CELLS_LON
  
  goto.MAP_QUADS_LAT = int(((goto.MAP_MAX_LAT - goto.MAP_MIN_LAT) + util.FLOAT_EP) / QUAD_SIZE)
  goto.MAP_QUADS_LON = int(((goto.MAP_MAX_LON - goto.MAP_MIN_LON) + util.FLOAT_EP) / QUAD_SIZE)
  goto.MAP_QUADS = goto.MAP_QUADS_LAT * goto.MAP_QUADS_LON

def set_sim(agent):
  agent_sim = agent.sim
  util.SEED_CAPITAL = int(agent_sim.seedCapital)
  util.MAX_STEPS = int(agent_sim.steps)
  util.CELL_SIZE = int(agent_sim.cellSize)
  util.PROXIMITY = int(agent_sim.proximity)

def print_sim(agent):
  log = agent._log
  shared = agent._shared
  
  log.info(lambda: "")
  x = agent.sim
  #   simulation => id, map, seedCapital, steps, team
  log.info(lambda: "sim, id = {}, map = {}, seedCapital = {}, steps = {}, team = {}".format(
    goto.sim_id, goto.map_name, util.SEED_CAPITAL, util.MAX_STEPS, x.team
  ))
  # map + parameter data
  log.info(lambda: "CELL_SIZE = {:d}, QUAD_SIZE = {:.2f}, PROXIMITY = {:d}, DIST_ROUTE_FAC = {:.2f}".format(
    util.CELL_SIZE, QUAD_SIZE, util.PROXIMITY, DIST_ROUTE_FAC))
  log.info(lambda: "map {:.5f} - {:.5f}, {:.5f} - {:.5f}".format(
    MAP_MIN_LAT, MAP_MAX_LAT, MAP_MIN_LON, MAP_MAX_LON))
  log.info(lambda: "CELLS = {:d} x {:d} = {:d}".format(MAP_CELLS_LON, MAP_CELLS_LAT, MAP_CELLS))
  log.info(lambda: "QUADS = {:d} x {:d} = {:d}".format(MAP_QUADS_LON, MAP_QUADS_LAT, MAP_QUADS))
  log.info(lambda: "STEP_CHARGE = {:d}, RECHARGE_RATE = {:d}".format(STEP_CHARGE, RECHARGE_RATE))
  log.info(lambda: "")
  #   role => name, speed, battery, load (name = car, drone, motorcycle, truck)
  for x_agent_name in sorted(shared.keys(), key=natural_sort_key):
    x_agent_shared = shared[x_agent_name]
    x_step = x_agent_shared.view.simulation.step
    x = x_agent_shared.sim.role
    log.log(LOG_OP, lambda: "{}, {:s}, name = {}, speed = {}, battery = {}, load = {}, tool = {}".format(
      x_step, x_agent_name, x.name, x.speed, x.battery, x.load, one_line_key_s(x.tool)
    ))
  log.log(LOG_OP, lambda: "")
  x = agent.view.facilities
  for x_fac_id in sorted(x.keys(), key=natural_sort_key):
    x_fac_data = x[x_fac_id]
    log.log(LOG_OP, lambda: "{} {}, loc = {}, {}".format(
      x_fac_id, x_fac_data.facility_type, x_fac_data.lat, x_fac_data.lon
    ))
  log.log(LOG_OP, lambda: "")



# euclidean approximation
# lat, lon in decimal degrees
def euclidean_d(lat1, lon1, lat2, lon2):
  RAD_1DEG = 0.017453292519943295 #math.PI/180
  R = 6371000
  # convert decimal degrees to radians 
  #lat1, lon1, lat2, lon2 = [x * RAD_1DEG for x in [lat1, lon1, lat2, lon2]]
  lat1 *= RAD_1DEG
  lon1 *= RAD_1DEG
  lat2 *= RAD_1DEG
  lon2 *= RAD_1DEG
  
  # euclidean formula
  dlon = (lon2 - lon1)
  dlat = (lat2 - lat1) 
  slat = (lat1 + lat2)/2
  x = dlon * cos(slat)
  y = dlat
  d = R * sqrt(x*x+y*y)
  return d

# haversine approximation
# lat, lon in decimal degrees
def haversine_d(lat1, lon1, lat2, lon2):
  RAD_1DEG = 0.017453292519943295 #math.PI/180
  R = 6371000
  # convert decimal degrees to radians 
  #lat1, lon1, lat2, lon2 = [x * RAD_1DEG for x in [lat1, lon1, lat2, lon2]]
  lat1 *= RAD_1DEG
  lon1 *= RAD_1DEG
  lat2 *= RAD_1DEG
  lon2 *= RAD_1DEG
  
  # haversine formula 
  dlon = (lon2 - lon1)
  dlat = (lat2 - lat1) 
  slat = sin(dlat/2)
  slon = sin(dlon/2)
  a = (slat*slat) + cos(lat1)*cos(lat2) * (slon*slon)
  c = 2 * asin(min(1.0, sqrt(a))) 
  d = R * c
  return d

"""

  === NOTE on naming ===
  fac(s) are always dictionaries with fac data,
  fac_id (s) are id(s) (names) of facilities

"""

# result in steps
def steps_direct(log, agent_shared, dst_fac, src_fac=None):
  a_self = agent_shared.view.self
  
  #agent_name = a_self.name
  agent_name = agent_shared._agent_name
  
  if src_fac is None:
    log.log(LOG_DETAIL, lambda: "*** steps_direct {:s} -> {:s}".format(agent_name, dst_fac.name))
  else:
    log.log(LOG_DETAIL, lambda: "*** steps_direct {:s}, {:s} -> {:s}".format(agent_name, src_fac.name, dst_fac.name))
  speed = int(agent_shared.sim.role.speed)
  CELL_STEP = util.CELL_SIZE * speed
  if src_fac is None:
    lat1 = float(a_self.lat)
    lon1 = float(a_self.lon)
  else:
    lat1 = float(src_fac.lat)
    lon1 = float(src_fac.lon)  
  lat2 = float(dst_fac.lat)
  lon2 = float(dst_fac.lon)
  
  #dlon = (lon2 - lon1) / CELL_STEP
  #dlat = (lat2 - lat1) / CELL_STEP
  #steps = ceil(math.sqrt(dlat**2 + dlon**2))
  
  # euclidean uses half the time of haversine with same result to last meter practically
  dist = euclidean_d(lat1, lon1, lat2, lon2)
  #steps = int(dist / CELL_STEP + 1.0) # simple math ceiling
  steps = ceil(dist / CELL_STEP )
  
  log.log(LOG_DETAIL, lambda: " => steps_direct {:.5f},{:.5f} -> {:.5f},{:.5f} = {:d} (speed = {:d})".format(
    lat1, lon1, lat2, lon2, steps, speed
  ))
  return steps

"""
# using lat, lon find if agent is inside/near a facility
def agent_fac_id(log, agent_shared):
  a_self = agent_shared.view.self
  agent_name = a_self.name
  fac_id = None
  agent_lat = float(a_self.lat)
  agent_lon = float(a_self.lon)
  for fac in agent_shared.view.facilities.values():
    fac_lat = float(fac.lat)
    fac_lon = float(fac.lon)
    if abs(agent_lat - fac_lat) <= PROXIMITY and abs(agent_lon - fac_lon) <= PROXIMITY:
      fac_id = fac.name
      break
  log.debug(lambda: "agent_fac_id {:s} => facility = {}".format(agent_name, fac_id))
  return agent_fac_id
"""

#cache_categ codes; in variable cache_p
#STEPS_NOCACHE = 0
#STEPS_CACHE = 1
#STEPS_CACHE_R = 2

#def cache_categ(cache_p):
#  return CACHE_CATEG_LIST[cache_p]

# new, direct code names; in variable cache_categ
STEPS_NOCACHE = "NOCACHE"
STEPS_CACHE = "CACHE"
STEPS_CACHE_R = "CACHE_R"
STEPS_NONE = "NONE"

CACHE_CATEG_LIST = [STEPS_NOCACHE, STEPS_CACHE, STEPS_CACHE_R, STEPS_NONE]
CACHE_CATEG_CACHE_ONLY = {STEPS_CACHE, STEPS_CACHE_R}

# indexed by <0, =0, >0
STEPS_CATEG_LIST = ["LESS", "EXACT", "MORE"]

# cache stores air paths (drone) and road paths (other roles), all adjusted to speed 1
# assumes there is no difference in road paths between roles of same mode
# dist_cache is shared now and all code should be run within lock region
dist_cache = {}
dist_cache_history = defaultdict(list)
goto_stats = defaultdict(int)
max_goto_fac = defaultdict(float)
fac_agents = defaultdict(set)
fac_goto = defaultdict(set)
  
MODE_AIR = "A"
MODE_ROAD = "R"

mode_dict = {
"drone": MODE_AIR,
"car": MODE_ROAD,
"motorcycle": MODE_ROAD,
"truck": MODE_ROAD
}

def mk_cache_key(fac_id1, fac_id2, mode):
  return "-".join([fac_id1, fac_id2, mode])

# adjust to speed
def get_cache_value(cache_key, speed):
  if cache_key in dist_cache:
    return ceil((dist_cache[cache_key] / speed))
  else:
    return None

# NOTE: must be thread-safe
def add_fac_goto(agent_name, fac_id):
  fac_goto[fac_id].add(agent_name)

# NOTE: must be thread-safe
def remove_fac_goto(agent_name, fac_id):
  if fac_id in fac_goto and agent_name in fac_goto[fac_id]:
    fac_goto[fac_id].remove(agent_name)

def print_fac_goto(agent):
  log = agent._log
  
  log.log(LOG_OP, lambda: "=== fac goto ===")
  for fac_id in sorted(fac_goto.keys(), key=natural_sort_key):
    log.log(LOG_OP, lambda: "{:s} (goto) => {}".format(fac_id, fac_goto[fac_id]))

def update_fac_agents(agent):
  log = agent._log
  
  fac_agents = defaultdict(set)
  for agent_name, agent_shared in agent._shared.items():
    facility = agent_shared.view.self.facility
    if facility != "none":
      fac_agents[facility].add(agent_name)
  goto.fac_agents = fac_agents

def print_fac_agents(agent):
  log = agent._log
  
  log.log(LOG_OP, lambda: "=== fac agents ===")
  for fac_id in sorted(fac_agents.keys(), key=natural_sort_key):
    log.log(LOG_OP, lambda: "{:s} (on spot) => {}".format(fac_id, fac_agents[fac_id]))

def update_goto_stats(log, cache_categ, steps, action_steps):
  steps_categ = STEPS_CATEG_LIST[sign(action_steps - steps) + 1]
  goto_stats[cache_categ + "-" + steps_categ] += 1
  fac = action_steps/max(steps, 1) # catch bugs
  log.log(LOG_OP, lambda: "updated goto_stats, {:s} {:d} => {:d} ({:.1f})".format(cache_categ, steps, action_steps, fac))
  if action_steps > steps:
    if fac > max_goto_fac[cache_categ]:
      max_goto_fac[cache_categ] = fac

def print_goto_stats(agent):
  log = agent._log
  
  log.log(LOG_OP, lambda: "=== goto stats ===")
  for status, status_value in sorted(goto_stats.items()):
    log.log(LOG_OP, lambda: "{:s} = {:d}".format(status, status_value))
  log.log(LOG_OP, lambda: "max cache fac (MORE) = {}".format(one_line_key_val_f(max_goto_fac, "{:.1f}")))

def print_dist_cache(agent):
  log = agent._log
  
  log.debug(lambda: "=== dist_cache ===")
  for key in sorted(dist_cache.keys()):
    log.debug(lambda: "{:s} = {}".format(key, dist_cache[key]))
  
  log.debug(lambda: "=== dist_cache history ===")
  for key in sorted(dist_cache_history.keys()):
    log.debug(lambda: "{:s} = {}".format(key, dist_cache_history[key]))

# new data for cache to use in update_shared()
# action_steps = true action_steps (reset count already subtracted)
# reset_count = count of random fails, just logged
def new_cache_data(log, agent, src_id, fac_id, action_steps, steps, cache_categ, reset_count):
  cache_key = None
  cache_value = None
  steps_categ = STEPS_CATEG_LIST[sign(action_steps - steps) + 1]
  log.log(LOG_OP, lambda: "goto_stats {:s} => {:s} completed in {:d} steps (+ {:d} random fails), estimated = {:d}, {:s}-{:s}".format(
    src_id, fac_id, action_steps, reset_count, steps, cache_categ, steps_categ
  ))
  # in new facility
  if src_id != "none" and src_id != fac_id:
    a_role = agent.sim.role
    agent_role_name = a_role.name
    agent_mode = mode_dict[agent_role_name]
    agent_role_speed = int(a_role.speed)
    # update dist_cache
    cache_key = mk_cache_key(src_id, fac_id, agent_mode)
    cache_value = action_steps * agent_role_speed
    if cache_categ in CACHE_CATEG_CACHE_ONLY and steps != action_steps:
      log.log(LOG_OP, lambda: "dist_cache prediction check, {:s} = {:d} => {:d}".format(cache_key, steps, action_steps))
  return cache_key, cache_value

# update data for cache to use in update_shared()
def update_cache_data(log, agent, cache_key, cache_value, steps):
  if cache_key and cache_value:
    dist_cache[cache_key] = cache_value
    # first entry is estimate for op_goto
    if not dist_cache_history[cache_key]:
      a_role = agent.sim.role
      agent_role_speed = int(a_role.speed)
      dist_cache_history[cache_key].append(steps * agent_role_speed)
    dist_cache_history[cache_key].append(cache_value)
    log.log(LOG_OP, lambda: "updated dist_cache {:s} => {:d}".format(cache_key, cache_value))

"""

  === NOTE on naming ===

  a steps object is a Duo(value, key), value = #steps, key = cache_categ
  a steps_xxx variable refers to a steps object always
    except for charging steps, steps (total), steps_order (for ordering)

"""

# distance agent location or src_fac to dst_fac
# use dist_cache, only from fac to fac
# return steps, cache_categ
# implement enhancement when there is no entry in cache for this role to use from other role,
# essentially replace 'role_type' to 'mode' of travel and ajust for role speed
def steps_estimate(log, agent_shared, dst_fac, src_fac=None):
  a_role = agent_shared.sim.role
  a_self = agent_shared.view.self

  #agent_name = a_self.name
  agent_name = agent_shared._agent_name
  
  #agent_fac_id = is_agent_in_fac(log, agent_shared)
  agent_fac_id = a_self.facility
  agent_role_name = a_role.name
  agent_role_mode = mode_dict[agent_role_name]
  agent_role_speed = int(a_role.speed)
  
  dst_fac_id = dst_fac.name
  src_fac_id = None
  if src_fac is None:
    log.log(LOG_DETAIL, lambda: "*** steps_estimate {:s}, facility = {:s} => {:s}".format(agent_role_name, agent_fac_id, dst_fac_id))
  else:
    log.log(LOG_DETAIL, lambda: "*** steps_estimate {:s}, {:s} => {:s}".format(agent_role_name, src_fac.name, dst_fac_id))
  if src_fac is None:
    if agent_fac_id != "none":
      src_fac_id = agent_fac_id
  else:
    src_fac_id = src_fac.name
  
  # shortcut if same facility
  if dst_fac_id == src_fac_id:
    log.log(LOG_DETAIL, lambda: " => steps_estimate, 0 (same)")
    return Duo(0, STEPS_NONE)
  
  # use cache
  cache_key_S = None
  if src_fac_id is not None:
    # try correct way first
    cache_key_S = mk_cache_key(src_fac_id, dst_fac_id, agent_role_mode)
    cache_value = get_cache_value(cache_key_S, agent_role_speed)
    #if cache_key in dist_cache:
    if cache_value:
      log.log(LOG_DETAIL, lambda: " => steps_estimate, read cache (direct) {:s} = {:d}".format(cache_key_S, cache_value))
      return Duo(cache_value, STEPS_CACHE)
    # try and get estimate from reverse way
    cache_key_R = mk_cache_key(dst_fac_id, src_fac_id, agent_role_mode)
    cache_value = get_cache_value(cache_key_R, agent_role_speed)
    #if cache_key in dist_cache:
    if cache_value:
      # use a safety factor
      # TODO... check that is done by caller, no double adjustment
      #cache_value = ceil(cache_value * JOB_STEPS_FAC)
      log.log(LOG_DETAIL, lambda: " => steps_estimate, read cache (reverse) {:s} = {:d}".format(cache_key_R, cache_value))
      return Duo(cache_value, STEPS_CACHE_R)
  
  # calculate estimate
  steps = steps_direct(log, agent_shared, dst_fac, src_fac)
  if agent_role_mode == MODE_ROAD:
    steps = ceil(steps * DIST_ROUTE_FAC)
  log.log(LOG_DETAIL, lambda: " => steps_estimate, (direct) = {:d}".format(steps))
  return Duo(steps, STEPS_NOCACHE)

# nearest charging station to get to in emergency if stalled
# returns (fac_id, steps duo)
def nearest_charging_station(log, agent_shared):
  p = []
  for charging_fac in agent_shared.view.chargingStation.values():
    steps = steps_estimate(log, agent_shared, charging_fac)
    charging_fac_id = charging_fac.name
    p.append(Duo(steps, charging_fac_id))
  best = sorted(p)[0]
  best_charging_station = best.key
  best_steps = best.value
  charge_target = best_steps.value * STEP_CHARGE
  log.debug(lambda: "*** nearest_charging_station for {:s} = {:s}, steps = {:d} {:s}, charge_target = {:d}".format(
    agent_shared._agent_name, best_charging_station, best_steps.value, best_steps.key, charge_target
  ))
  return (best_charging_station, best_steps)

# nearest charging station to fac, to use on leaving from fac
# give preference in the direction to center of map !
# returns tuple (steps, charging_fac)
def fac_charging_station(log, agent_shared, fac):
  # TODO... what if map dynamic and boundaries not known before ???
  #MAP_CENTER_LAT = util.MAP_CENTER_LAT
  #MAP_CENTER_LON = util.MAP_CENTER_LON
  fac_lat = float(fac.lat)
  fac_lon = float(fac.lon)
  min_lat = min(MAP_CENTER_LAT, fac_lat)
  max_lat = max(MAP_CENTER_LAT, fac_lat)
  min_lon = min(MAP_CENTER_LON, fac_lon)
  max_lon = max(MAP_CENTER_LON, fac_lon)
  log.debug(lambda: "*** fac_charging_station for {:s} loc = {:.5f}, {:.5f} (map center = {:.5f}, {:.5f}), bound = {:.5f} - {:.5f}, {:.5f} - {:.5f}".format(fac.name, fac_lat, fac_lon, MAP_CENTER_LAT, MAP_CENTER_LON, min_lat, max_lat, min_lon, max_lon))
  
  # first try, to center of map
  p = []
  for charging_fac in agent_shared.view.chargingStation.values():
    charging_fac_lat = float(charging_fac.lat)
    charging_fac_lon = float(charging_fac.lon)
    if min_lat <= charging_fac_lat <= max_lat and min_lon <= charging_fac_lon <= max_lon:
      steps = steps_estimate(log, agent_shared, charging_fac, fac)
      charging_fac_id = charging_fac.name
      p.append(Duo(steps, charging_fac_id))
      log.debug(lambda: "... {:s} ({:.5f}, {:.5f}), steps = {:d} {:s}".format(charging_fac_id, charging_fac_lat, charging_fac_lon, steps.value, steps.key))
  if p:
    best = sorted(p)[0]
    best_charging_station = best.key
    best_steps = best.value
    log.debug(lambda: " => fac_charging_station for {:s} = {:s}, (centered) steps = {:d} {:s}".format(fac.name, best_charging_station, best_steps.value, best_steps.key))
    return best
  
  # second try, absolutely nearest
  for charging_fac in agent_shared.view.chargingStation.values():
    steps = steps_estimate(log, agent_shared, charging_fac, fac)
    charging_fac_id = charging_fac.name
    p.append(Duo(steps, charging_fac_id))
  best = sorted(p)[0]
  best_charging_station = best.key
  best_steps = best.value
  log.debug(lambda: " => fac_charging_station for {:s} = {:s}, (nearest) steps = {:d} {:s}".format(fac.name, best_charging_station, best_steps.value, best_steps.key))
  return best

# optimal charging station on the way to dst_fac (from src_fac or from agent current location)
# returns tuple Hexa(steps_order, steps_charging_to_fac, steps_own_to_charging, steps_charging_time, steps_total, charging_fac_id)
# steps_order = steps_total
# if considered impossible to reach destination, then
#   steps_charging_time = time to fully recharge a totally empty battery_capacity
#   steps_order = MAX_STEPS, but order by steps_charging_to_fac too
# generally order by minimal steps_charging_to_fac so enough power for next charging station
def best_charging_station(log, agent_shared, dst_fac, src_fac=None, charge_level=None):
  a_role = agent_shared.sim.role
  agent_view = agent_shared.view
  a_self = agent_view.self
  
  #agent_name = a_self.name
  agent_name = agent_shared._agent_name
  
  facility = a_self.facility
  if charge_level:
    charge = charge_level
  else:
    charge = int(a_self.charge)
  battery_capacity = int(a_role.battery)
  log.debug(lambda: "*** best_charging_station {:s} => {:s} (charge = {:d}, capacity = {:d})".format(
    src_fac.name if src_fac is not None else agent_name+":"+facility, dst_fac.name, charge, battery_capacity
  ))
  
  # select charging stations to consider
  
  # TODO..., review this
  if src_fac is None:
    src_fac = agent_view.facilities.get(facility)
  if src_fac and src_fac.facility_type == "chargingStation":
    charging_stations = {src_fac.name:src_fac}
    log.debug(lambda: "   *** best_charging_station {:s} => {:s}, SMART at charging station !!!".format(
      src_fac.name if src_fac is not None else agent_name+":"+facility, dst_fac.name
    ))
  
  steps_fac_to_next_charging = fac_charging_station(log, agent_shared, dst_fac).value
  charge_use_fac_to_next_charging = steps_fac_to_next_charging.value * STEP_CHARGE
  
  p = []
  charging_stations = agent_shared.view.chargingStation
  for charging_fac in charging_stations.values():
    # TODO, check !
    # should be 0 and work correctly inside charging station
    steps_own_to_charging = steps_estimate(log, agent_shared, charging_fac, src_fac)
    steps_charging_to_fac = steps_estimate(log, agent_shared, dst_fac, charging_fac)
    charge_use_own_to_charging = steps_own_to_charging.value * STEP_CHARGE
    charge_use_charging_to_fac = steps_charging_to_fac.value * STEP_CHARGE
    charging_rate = int(charging_fac.rate)
    steps_charging_time = ceil((battery_capacity - max(charge - charge_use_own_to_charging, 0))/charging_rate)
    steps_total = steps_own_to_charging.value + steps_charging_to_fac.value + steps_charging_time
    steps_order = steps_total
    ### allow all charging stations, so at least one selected and if stall we recharge !!!
    ### just ensure no negative steps ever, and special handling of negative cases so best order is maintained
    # in case of negative cases, all sort same initially but priority to charging station nearest to destination
    # TODO..., review !
    ###
    # 2nd error class, can't reach destination, adjust steps_total
    if charge_use_charging_to_fac > battery_capacity:
      steps_order = util.MAX_STEPS + 1
      steps_total += ceil(battery_capacity / RECHARGE_RATE)
    # 1st error class, can't reach charging station, adjust steps_total
    if charge < charge_use_own_to_charging:
      steps_order = util.MAX_STEPS + 1
      steps_total += ceil(battery_capacity / RECHARGE_RATE)
    # 3nd error class, not so accurate estimate
    if ceil((charge_use_charging_to_fac + charge_use_fac_to_next_charging) * JOB_STEPS_FAC) > battery_capacity:
      steps_order = util.MAX_STEPS
    ###
    charging_fac_id = charging_fac.name
    p.append(Hexa(steps_order, steps_charging_to_fac, steps_own_to_charging, steps_charging_time, steps_total, charging_fac_id))
    log.debug(lambda: "   ... {:s}, ({:d}) steps = {:d} (to_charge = {:d} {:s}, to_fac = {:d} {:s}, charging = {:d})".format(
      charging_fac_id, steps_order, steps_total,
      steps_own_to_charging.value, steps_own_to_charging.key,
      steps_charging_to_fac.value, steps_charging_to_fac.key,
      steps_charging_time
    ))
  best = sorted(p)[0]
  log.debug(lambda: " => best_charging_station, min = {:s}, steps = {:d}".format(best.key, best.value_all))
  return best

# charge strategy for faster response chosen to be best
#   check for charge to arrive + next charging station (but centered to map first, then nearest one charging station)
#   instead of always charge in between (optimal) + arrive
#
# create sequence of op_goto(s) to target with optional detour to charging station, append to action_seq
# returns estimated steps to reach including charging time, can be MAX_STEPS indicating unreachability
# direct= False if go thru charging station, else direct if possible
#
# works correctly for starting a move from current position (without or with src_id) to a destination
# if case of stall (out of charge stall) and recharge procedure then
# should work correctly for last goto in generated sequence of
# recharge, goto charging_station, charge, "goto destination"
# for this reason the last optional parameter charge_level will be used (charge when inside charging_station)
def creat(log, agent_shared, fac_id, action_seq=None, src_id=None, job_id="", direct=False, charge_level=None):
  import actions
  
  if src_id is not None and charge_level is None:
    log.log(LOG_OP, lambda: "CHECK-ERR:   creat called with 'src_id' but not 'charge_level'")
    src_id = None
  creat_type_s = "(action)" if action_seq is not None else "(steps)"
  
  agent_view = agent_shared.view
  a_self = agent_view.self
  
  #agent_name = a_self.name
  agent_name = agent_shared._agent_name
  
  facility = a_self.facility
  if charge_level:
    charge = charge_level
  else:
    charge = int(a_self.charge)
  
  # NOTE: src_id => "none" (if None as parameter, but src_fac => None)
  fac_data = agent_view.facilities[fac_id]
  if src_id is not None:
    src_fac = agent_view.facilities[src_id]
  else:
    src_id = facility
    src_fac = None
  
  op_goto = actions.op_goto
  op_charge = actions.op_charge
  
  # prepare to test if go directly, incorporates 'direct=' parameter
  steps_fac_to_next_charging = fac_charging_station(log, agent_shared, fac_data).value
  steps_own_to_fac = steps_estimate(log, agent_shared, fac_data, src_fac)
  if direct:
    charge_budget = steps_own_to_fac.value * STEP_CHARGE
  else:
    charge_budget = ceil((steps_own_to_fac.value + steps_fac_to_next_charging.value) * JOB_STEPS_FAC) * STEP_CHARGE
  # test if go directly
  if charge_budget <= charge:
    log.debug(lambda: "*** creat 1/1 {:s}, {:s} => {:s} (direct), steps = {:d} {:s} (charge = {:d}, budget = {:d})   {:s}".format(
      creat_type_s, agent_name, fac_id,
      steps_own_to_fac.value, steps_own_to_fac.key,
      charge, charge_budget, job_id
    ))
    if action_seq is not None:
      action_seq.append(
        # _src_id = "none", if not inside a facility
        # **args: _cache_categ, _fac_id, _src_id, _job_id (can be "")
        op_goto(agent_name, steps_own_to_fac.value, _cache_categ=steps_own_to_fac.key,
        _fac_id=fac_id, _src_id=src_id, _job_id=job_id)
      )
    return steps_own_to_fac.value
  
  # go via charging station
  # Hexa(steps_order, steps_charging_to_fac, steps_own_to_charging, steps_charging_time, steps_total, charging_fac_id)
  # Hexa = 'value_sort value0 value1 value2 value_all key'
  _, steps_charging_to_fac, steps_own_to_charging, steps_charging_time, steps_total, charging_fac_id = best_charging_station(log, agent_shared, fac_data, src_fac, charge)
  charging_fac = agent_view.facilities[charging_fac_id]
  ###
  if steps_own_to_charging.value > 0:
    log.debug(lambda: "*** creat 1/3 {:s}, {:s} -> {:s} (charge), steps = {:d} {:s}   {:s}".format(
      creat_type_s, agent_name, charging_fac_id,
      steps_own_to_charging.value, steps_own_to_charging.key,
      job_id
    ))
    if action_seq is not None:
      action_seq.append(
        # _src_id = "none", if not inside a facility
        # **args: _cache_categ, _fac_id, _src_id, _job_id (can be "")
        op_goto(agent_name, steps_own_to_charging.value, _cache_categ=steps_own_to_charging.key,
        _fac_id=charging_fac_id, _src_id=src_id, _job_id=job_id)
      )
  ###
  log.debug(lambda: "*** creat 2/3 {:s}, {:s} charging, steps = {:d}   {:s}".format(
    creat_type_s, agent_name, steps_charging_time, job_id
  ))
  if action_seq is not None:
    # **args: _fac_id, _job_id (can be "")
    action_seq.append(op_charge(agent_name, steps_charging_time, _fac_id=charging_fac_id, _job_id=job_id))
  ###
  log.debug(lambda: "*** creat 3/3 {:s}, {:s} -> {:s} (direct), steps = {:d} {:s}   {:s}".format(
    creat_type_s, agent_name, fac_id,
    steps_charging_to_fac.value, steps_charging_to_fac.key,
    job_id
  ))
  if action_seq is not None:
    action_seq.append(
      # _src_id = "none", if not inside a facility
      # **args: _cache_categ, _fac_id, _src_id, _job_id (can be "")
      op_goto(agent_name, steps_charging_to_fac.value, _cache_categ=steps_charging_to_fac.key,
      _fac_id=fac_id, _src_id=charging_fac_id, _job_id=job_id)
    )
  ###
  log.debug(lambda: "creat {:s} total steps = {:d}".format(creat_type_s, steps_total))
  steps_budget = int(charge/STEP_CHARGE)
  if steps_total > steps_budget:
    log.log(LOG_OP, lambda: "CHECK-DATA:   creat {:s} total steps = {:d} vs {:d} for {:d} charge !!!".format(creat_type_s, steps_total, steps_budget, charge))  
  if action_seq is not None and src_fac and src_fac.facility_type == "chargingStation":
    log.log(LOG_OP, lambda: "CHECK-FLASH:   creat {:s} SMART at charging station steps = {:d} = {}".format(creat_type_s, steps_total, action_seq))
  return steps_total



# best workshop to use for assemblies, for all agents in party,
# and then deliver to storage
# should work even if party is already inside workshop
def best_workshop(agent, party, storage):
  log = agent._log
  
  log.log(LOG_OP, lambda: "*** best_workshop {} => {:s}".format(one_line_key_s(party), storage))
  
  shared = agent._shared
  agent_view = agent.view
  
  storage_view = agent_view.storage
  storage_fac = storage_view[storage]
  
  # TODO..., review selection logic if agents already in workshop
  # some agents already in workshop, majority over all agents
  facility_list = [shared[agent_name].view.self.facility for agent_name in party]
  facility_counter = Counter(facility_list)
  most_common_id, most_common_count = facility_counter.most_common(1)[0]
  most_common_fac = agent_view.facilities.get(most_common_id)
  if most_common_fac and most_common_fac.facility_type == "workshop":
    log.log(LOG_OP, lambda: "CHECK-FLASH:   best_workshop {} => {:s} = {:s} (common)".format(party, storage, most_common_fac.name))
    return most_common_fac.name
  
  # select based on time to finish, use min speed over all agents
  min_speed, min_speed_agent_name = sorted([(int(shared[agent_name].sim.role.speed), agent_name) for agent_name in party])[0]
  workshop_view = agent_view.workshop
  min_workshop = None
  min_steps = MAX_INT
  min_to_storage = MAX_INT
  min_to_workshop = MAX_INT
  for workshop_fac in workshop_view.values():
    # workshop to storage at min speed
    agent_shared = shared[min_speed_agent_name]
    steps_storage = steps_estimate(log, agent_shared, storage_fac, workshop_fac).value
    # bound
    if steps_storage > min_steps:
      continue
    # own to workshop
    max_to_workshop = 0
    for agent_name in party:
      agent_shared = shared[agent_name]
      steps_own_to_workshop = steps_estimate(log, agent_shared, storage_fac, workshop_fac).value
      # bound
      if steps_own_to_workshop > min_steps:
        continue
      if steps_own_to_workshop > max_to_workshop:
        max_to_workshop = steps_own_to_workshop
    steps_total = steps_storage + max_to_workshop
    log.log(LOG_OP, lambda: "   ... {:s}, steps = {:d} (to_storage = {:d}, to_workshop = {:d})".format(
      workshop_fac.name, steps_total, steps_storage, max_to_workshop
    ))
    if steps_total < min_steps:
      min_workshop = workshop_fac.name
      min_steps = steps_total
      min_to_storage = steps_storage
      min_to_workshop = max_to_workshop
  log.log(LOG_OP, lambda: " => best_workshop => {:s} steps = {:d} (to_storage = {:d}, to_workshop = {:d})".format(
      min_workshop, min_steps, min_to_storage, min_to_workshop
  ))
  return min_workshop



# returns final charging_station id
def single_recharge(log, agent_shared, action_seq, job_id):
  import actions
  
  agent_view = agent_shared.view
  a_self = agent_view.self
  a_role = agent_shared.sim.role
  
  #agent_name = a_self.name
  agent_name = agent_shared._agent_name
  
  facility = a_self.facility
  battery_capacity = int(a_role.battery)
  step = int(agent_view.simulation.step)
  
  op_goto = actions.op_goto
  op_charge = actions.op_charge
  op_recharge = actions.op_recharge
  
  fac_data = agent_view.facilities.get(facility)
  if fac_data and fac_data.facility_type == "chargingStation":
    charging_rate = int(fac_data.rate)
    steps_charging = ceil(battery_capacity/charging_rate)
    log.log(LOG_OP, lambda: "{:d}, recharge {:s} SMART charge  {:s}".format(
      step, agent_name, " "+job_id if job_id else ""
    ))
    # **args: _fac_id, _job_id (can be "")
    action_seq.append(op_charge(agent_name, steps_charging, _fac_id=facility, _job_id=job_id))
    return fac_data.name
  else:
    charging_fac_id, own_to_charging_steps = nearest_charging_station(log, agent_shared)
    charge_target = ceil(own_to_charging_steps.value * STEP_CHARGE * JOB_STEPS_FAC)
    steps_recharging = ceil(charge_target/RECHARGE_RATE)
    action_seq.extend([
      # **args: _charge_target, _job_id (can be "")
      op_recharge(agent_name, steps_recharging, _charge_target=charge_target, _job_id=job_id),
      # _src_id = "none", if not inside a facility
      # **args: _cache_categ, _fac_id, _src_id, _job_id (can be "")
      op_goto(agent_name, own_to_charging_steps.value, _cache_categ=own_to_charging_steps.key,
          _fac_id=charging_fac_id, _src_id=facility, _job_id=job_id)
    ])
    log.log(LOG_OP, lambda: "{:d}, recharge {:s} (via {:s})  {:s} => {}".format(
      step, agent_name, charging_fac_id, " "+job_id if job_id else "", action_seq
    ))
    return charging_fac_id

# should be thread-safe
def single_recharge_goto(log, agent_shared, fac_id, action_seq, job_id):
  agent_view = agent_shared.view
  a_self = agent_view.self
  a_role = agent_shared.sim.role
  
  #agent_name = a_self.name
  agent_name = agent_shared._agent_name
  
  step = int(agent_view.simulation.step)
  
  charging_fac_id = single_recharge(log, agent_shared, action_seq, job_id)
  creat(log, agent_shared, fac_id, action_seq, src_id=charging_fac_id, job_id=job_id, charge_level=0)
  log.log(LOG_OP, lambda: "{:d}, recharge_goto {:s} => {:s} (via {:s})  {:s} => {}".format(
    step, agent_name, fac_id, charging_fac_id, " "+job_id if job_id else "", action_seq
  ))



# sort agents to go to dst_id by number steps, starting from src_id or current position
# optionally, uses a steps_cache indexed by [agent_name+"-"+dst_id]
# return list of tuples sorted
# TODO, check creat use of error classes should take care to penalize agents with little or no charge
def sort_agents_speed(agent, agent_list, dst_id, src_id=None, steps_cache=None, direct=False):
  log = agent._log
  shared = agent._shared
  
  x_agents = []
  for agent_name in agent_list:
    agent_shared = shared[agent_name]
    if steps_cache is not None:
      key = agent_name+"-"+dst_id
      if key in steps_cache:
        x_steps = steps_cache[key]
      else:
        x_steps = creat(log, agent_shared, dst_id, src_id=src_id, direct=direct)
        steps_cache[key] = x_steps
    else:
        x_steps = creat(log, agent_shared, dst_id, src_id=src_id, direct=direct)
    x_agents.append((x_steps, agent_name))
  return sorted(x_agents)