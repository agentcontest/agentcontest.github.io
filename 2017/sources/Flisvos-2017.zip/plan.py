
"""

 /*
  * @(#) E.Sarmas   plan.py 0.9_63 (2017-09-18)
  *
  * Author: E.Sarmas
  *
  * Created: 2017-04-06
  *
  * Description: Flisvos 2017 (MAPC 2017)
  *
  * Version: 0.9_63
  * Version-Date: 2017-09-18
  *
  * Version-Log:
  *   0.1_0 (2017-04-06)   copy from Flisvos-2016
  *   0.1_9 (2017-05-29)   rewrite so stable core and fewer changes per scenario/implementation
  *   0.6_0 (2017-06-01)   refactoring, new sim messages/info (except distance calcs), running
  *                        fewer import dependency chains, code moved to more appropriate modules
  *                        logging messages with lambda: now, may speed up logging
  *                        single method to recursively decode messages
  *                        log_data moved within attr_dict as instance method
  *                        clear agent action handling/protocol and procedures/statistics/logging level use
  *                        removed items_db, jobs_spec moved in team
  *                        simple class method like procedures for data updates within appropriate module
  *                        clearer procedure interrelationships, existence and use
  *                        cache improvement to be useful for all roles
  *                        cleaner use of JOB_STEPS_FAC so no double use and wrong results
  *                        clearer method use protocol and use of other procedures for data updates
  *                        agents_with_item_on_board and agents_with_item_buy removed and embedded
  *                        introduced deliver_jobs and explore_buys
  *                        jobs_selection does not select but returns base recipe for all not ignored jobs
  *                        new_jobs now setups assembly or marks for delivery already assembled job
  *                        deliver_jobs may arrange first moves (give and take) to fewer and faster agents
  *   0.9_50 (2017-09-03)  qualification run, new_jobs/deliver_jobs/explore_buys disabled
  *   0.9_52 (2017-09-05)  added EXERCIZE_MODE as in qualification to test goto/charge/recharge system
  *                        ability to recover a job_op, for op_goto to recover from battery stalls by
  *                        recharging enough steps for next charging station and then going to destination
  *                        new dist_cache_history, random fail steps not counted
  *                        lowered level of all goto steps calculations
  *                        random fails don't stop op_goto(s) (bad interaction of reset/send_action )
  *                        also handled correctly if happen on first step of action
  *                        fixed job_op drop and job_drop confusion
  *                        new job_data[], SPEC tracks missions and removes fine from money
  *                        better handling of actions that indicate errors (ACTION_ERRORS)
  *                        new action retrieve_delivered and procedure retrieve_delivered in plan
  *                        new dict job_failed, and sets failed_jobs, just_failed_jobs
  *                        clearer actions for job_set_completed and job_set_failed (new), update_jobs_spec
  *                        reassigned role of job_db, new dict job_party
  *                        new procedures single_recharge and single_recharge_goto for faster recharge
  *                        creat can be called with agent in charging_station in future (with charge_level)
  *                        explore_jobs works without jobs and uses tool compatibility
  *                        along with mission and priced job needs in a useful order
  *                        refactored explore_jobs setup merging all loops, and removed shop_estimate
  *                        organized job work in phases (assembly, move, delivery)
  *                        move phase orchestrates give->receive to fewer better fit agents to deliver_jobs
  *                        and works like cpu instruction scheduling filling empty slots when needed
  *                        jobs_selection finally embedded within explore_jobs
  *                        explore_jobs considers better the suitability of each shop to finish jobs
  *                        and considers agent tool_compatibility better, and also global tool cover
  *                        socket timeout to 20 sec, never low value
  *                        enhanced strategy for CHECK-ERR asserts and other CHECK-... almost everywhere
  *                        is the fastest way to verify coverage and correct operation
  *                        changed logging levels everywhere so comfortable view of logging output
  *                        new failed action recovery logic, improved recover and drop functions 
  *                        checked all actions to send an action to server
  *                        new action.has_next() and use of next_action() only after barrier
  *                        so job_drop() works correctly with current action inside barrier
  *                        strange float calcs fixed (FLOAT_EP)
  *                        new job_state_check and actions_state_check, set jobs to drop (just_failed_jobs)
  *                        disabled move operations (give->receive to fewer and faster agents)
  *                        because not so important and code not tested well for crashes and more...
  *                        explore_buys only if no concurrent buy in same shop and only for items
  *   0.9_63 (2017-09-18)  good luck :) 
  */

"""



import collections
import math
import random

import util
import goto
import actions
import team



# DETAIL < DEBUG <   OP < INFO   < WARNING+
# agent log file =   LOG_DEBUG or LOG_DETAIL (verbose)
# main  log file =   LOG_OP
# console        =   LOG_INFO

LOG_OP = 19
LOG_DETAIL = 9



defaultdict = collections.defaultdict
Counter = collections.Counter

ceil = math.ceil
shuffle = random.shuffle

RECHARGE_RATE = util.RECHARGE_RATE
MAX_INT = util.MAX_INT

Duo = util.Duo
#Agent_Item = util.Agent_Item
#Agent_Item_Sort = util.Agent_Item_Sort

LapTimer = util.LapTimer
attr_dict = util.attr_dict
natural_sort_key = util.natural_sort_key
one_line_key_val_s = util.one_line_key_val_s
one_line_key_s = util.one_line_key_s
one_line_key = util.one_line_key
one_line_duo_s = util.one_line_duo_s

###flatten_dict_counter = util.flatten_dict_counter
copy_dict_counter = util.copy_dict_counter
get_items_available = util.get_items_available
get_items_on = util.get_items_on
job_base_resources = util.job_base_resources
job_part_resources = util.job_part_resources
#items_cost = util.items_cost
can_complete_job = util.can_complete_job
is_complete_job_1 = util.is_complete_job_1
is_complete_job_2 = util.is_complete_job_2
party_gathered = util.party_gathered
calc_self_volume = util.calc_self_volume
partition_agents = util.partition_agents
partition_agents2 = util.partition_agents2

creat = goto.creat
best_workshop = goto.best_workshop
single_recharge = goto.single_recharge
sort_agents_speed = goto.sort_agents_speed

Action_Seq = actions.Action_Seq
op_skip = actions.op_skip
op_charge = actions.op_charge
op_recharge = actions.op_recharge
op_buy = actions.op_buy
op_deliver_job = actions.op_deliver_job
op_assemble = actions.op_assemble
op_give = actions.op_give
op_receive = actions.op_receive
op_retrieve_delivered = actions.op_retrieve_delivered

# team functions only
job_start = team.job_start
job_set_assemble_party = team.job_set_assemble_party
job_set_delivery_party = team.job_set_delivery_party
job_set_opt = team.job_set_opt
job_set_assembled = team.job_set_assembled
job_set_move_planned = team.job_set_move_planned
job_set_move_completed = team.job_set_move_completed
job_set_delivery_planned = team.job_set_delivery_planned
job_set_removed = team.job_set_removed
add_explore = team.add_explore
add_retrieve_delivered = team.add_retrieve_delivered
job_update_schedule_noitems = team.job_update_schedule_noitems
shop_stats = team.shop_stats



def recharge(agent):
  log = agent._log
  shared = agent._shared
  step = agent._step
  
  for agent_name, agent_shared in shared.items():
    agent_view = agent_shared.view
    a_self = agent_view.self
    if (agent_shared.job_op is None and int(a_self.charge) == 0):
      action_seq = Action_Seq()
      single_recharge(log, agent_shared, action_seq, job_id="")
      agent_shared.job_op = action_seq



# new jobs
def new_jobs(agent):
  log = agent._log
  shared = agent._shared
  step = agent._step
  
  MAX_CONCURRENT_JOBS = util.MAX_CONCURRENT_JOBS
  
  committed_jobs = team.committed_jobs
  active_missions = team.active_missions
  
  committed_full = len(committed_jobs) >= MAX_CONCURRENT_JOBS
  if committed_full and len(active_missions) == 0:
    log.log(LOG_OP, lambda: "*** new_jobs, reached concurrent job limit ({:d}) and no active missions".format(MAX_CONCURRENT_JOBS))
    return
  
  avail_agents, _, explore_agents, _, _ = partition_agents2(agent)
  
  avail_agents |= explore_agents
  
  log.log(LOG_OP, lambda: "")
  log.log(LOG_OP, lambda: "*** new_jobs, avail_agents = ({:d}) {} (explore = ({:d}) {})".format(
    len(avail_agents), avail_agents,
    len(explore_agents), explore_agents
  ))
  
  if not avail_agents:
    log.log(LOG_OP, lambda: "*** new_jobs, no agents !\n")
    return
  
  JOB_NEW_MIN_STEPS = util.JOB_NEW_MIN_STEPS
  JOB_NEW_MAX_START_STEP = util.JOB_NEW_MAX_START_STEP
  JOB_MAX_BUY_COST_FAC = util.JOB_MAX_BUY_COST_FAC
  JOB_MIN_BALANCE = util.JOB_MIN_BALANCE
  JOB_ASSEMBLY_MAX_ADD_AGENTS = util.JOB_ASSEMBLY_MAX_ADD_AGENTS
  JOB_NEW_WORKSHOP_BUFFER_STEPS = util.JOB_NEW_WORKSHOP_BUFFER_STEPS
  ###JOB_STEPS_FAC = util.JOB_STEPS_FAC
  
  CORE_STEPS_CLASS = util.CORE_STEPS_CLASS
  CORE_MONEY_CLASS = util.CORE_MONEY_CLASS
  CORE_CAPACITY_PERCENT_CLASS = util.CORE_CAPACITY_PERCENT_CLASS
  CORE_CAPACITY_CLASS = util.CORE_CAPACITY_CLASS
  
  MAX_STEPS = util.MAX_STEPS
  
  item_db = team.item_db
  tool_db = team.tool_db
  
  jobs_view = agent.view.jobs_view
  job_spec_ignored = team.job_spec_ignored
  job_creat_step = team.job_creat_step
  
  # general job data cache, by job_id
  job_cache = {}
  
  # items on board to deliver for a job, by item_name and storage
  on_cache = defaultdict(list)
  # items to buy if agent is inside shop, by item_name and storage
  buy_cache = defaultdict(list)
  # set of all storage in on_cache, buy_cache
  storage_cache = set()
  
  # steps are to storage, just a guide for steps order criterion,
  # surely we can find a workshop on the way without much extra steps
  # workshop will be selected when all agents in party known
  steps_cache = {}
  
  # set of eligible agents, by job_id
  agents_cache = {}
  # set of eligible agents, by storage
  agents_storage = {}
  
  #
  # opt is two Counter(s)
  # a Counter() that is recipe of part items (base and assembled) to get to complete a job
  # a Counter() of tools to use
  #
  
  # opt_id is id of a recipe, corresponds to single job_id and opt combination
  opt_id = 0
  
  # all opt(s), indexed by opt_id
  opt_db = {}
  # job_id for an opt_id
  opt_job = {}
  
  # all items available, includes tools
  agent_on, agent_buy, items_on, items_buy, list_on, list_buy, buy_shop = get_items_available(agent, avail_agents)
  
  avail_items = items_on + items_buy
  ###agent_items = {a: (agent_on[a] + agent_buy[a]) for a in avail_agents}
  
  log.log(LOG_OP, lambda: "*** new_jobs, items_on = {}, items_buy = {}".format(one_line_key_val_s(items_on), one_line_key_val_s(items_buy)))
  
  ### begin initial setup
  
  # loop by job to commit to
  # fill job_cache, agents_cache, steps_cache, opt_db, opt_job, on_cache, buy_cache, buy_shop
  for job_id, job_data in jobs_view.items():
    
    if job_id in job_spec_ignored or job_id in committed_jobs:
      continue
    
    job_data = jobs_view[job_id]
    job_type = job_data.job_type
    storage = job_data.storage
    end_step = min(int(job_data.end), MAX_STEPS)
    steps = end_step - step
    
    if committed_full and job_type != "mission":
      log.log(LOG_OP, lambda: "new_jobs, setup   job_id: {:s}, committed_full or not active mission, skipped".format(
        job_id, storage, steps, JOB_NEW_MIN_STEPS
      ))
      continue
    
    # job_cache and initial checks
    if steps < JOB_NEW_MIN_STEPS:
      log.log(LOG_OP, lambda: "new_jobs, setup   job_id: {:s}, storage = {:s}, steps = {:d} < {:d} skipped".format(
        job_id, storage, steps, JOB_NEW_MIN_STEPS
      ))
      continue
    if step - job_creat_step[job_id] > JOB_NEW_MAX_START_STEP:
      log.log(LOG_OP, lambda: "new_jobs, setup   job_id: {:s}, storage = {:s}, start_step = {:d} > {:d} skipped".format(
        job_id, storage, step - job_creat_step[job_id], JOB_NEW_MAX_START_STEP
      ))
      continue
    
    reward = int(job_data.reward)
    job_cache[job_id] = (storage, end_step, steps, reward)
    log.log(LOG_OP, lambda: "new_jobs, setup   job_id: {:s}, storage = {:s}, steps = {:d}, reward = {:d}".format(job_id, storage, steps, reward))
    
    if storage not in agents_storage:
      # fill agent_cache, steps_cache and (local temporary) sc_cache for steps_class
      x_agents = set()
      sc_cache = {}
      for agent_name in avail_agents:
        agent_shared = shared[agent_name]
        key = agent_name + "-" + storage
        if key in steps_cache:
          x_steps = steps_cache[key]
        else:
          x_steps = creat(log, agent_shared, storage)
          steps_cache[key] = x_steps
        if x_steps + JOB_NEW_WORKSHOP_BUFFER_STEPS <= steps:
          x_agents.add(agent_name)
          steps_class = round(x_steps/CORE_STEPS_CLASS)*CORE_STEPS_CLASS
          sc_cache[agent_name] = steps_class
      agents_storage[storage] = x_agents
      log.log(LOG_OP, lambda: "new_jobs, setup   job_id: {:s}, agents_storage {:s} = {}".format(job_id, storage, one_line_key_s(x_agents)))
    agents_cache[job_id] = x_agents
    
    # opt_data
    # with quick check of availability
    opt_assembled, opt_base, opt_tools = job_part_resources(agent, job_id, agent_on)
    opt1_assembled_count = sum(opt_assembled.values())
    if opt1_assembled_count > 0:
      opt1 = Counter()
      opt1.update(opt_assembled)
      opt1.update(opt_base)
      opt1_all = opt1 + opt1_tools
      if opt1_all & avail_items == opt1_all:
        opt_id += 1
        opt_db[opt_id] = (opt1_all, opt1, opt1_tools, opt1_assembled_count)
        opt_job[opt_id] = job_id
        log.log(LOG_OP, lambda: "new_jobs, setup   job_id: {:s}, opt-1: {:d} ({:d}) = {}, {}".format(
          job_id, opt_id, opt1_assembled_count, one_line_key_val_s(opt1), one_line_key_s(opt1_tools)
        ))
      else:
        log.log(LOG_OP, lambda: "new_jobs, setup   job_id: {:s}, opt-1: {:d} ({:d}) = {}, {} no availability".format(
          job_id, opt_id, opt1_assembled_count, one_line_key_val_s(opt1), one_line_key_s(opt1_tools)
        ))
    opt2_all, opt2, opt2_tools = job_base_resources(agent, job_id)
    if opt2_all & avail_items == opt2_all:
      opt_id += 1
      opt_db[opt_id] = (opt2_all, opt2, opt2_tools, 0)
      opt_job[opt_id] = job_id
      log.log(LOG_OP, lambda: "new_jobs, setup   job_id: {:s}, opt-0: {:d} ({:d}) = {}, {}".format(
        job_id, opt_id, 0, one_line_key_val_s(opt2), one_line_key_s(opt2_tools)
      ))
    else:
      log.log(LOG_OP, lambda: "new_jobs, setup   job_id: {:s}, opt-0: {:d} ({:d}) = {}, {} no availability".format(
        job_id, opt_id, 0, one_line_key_val_s(opt2), one_line_key_s(opt2_tools)
      ))
    
    if storage not in storage_cache:
      # on_cache
      for item_name, item_list in list_on.items():
        # TODO..., critical sort
        key = item_name+"-"+storage
        x_on = sorted([
          (sc_cache[agent_name], -item_amount, item_price, item_amount, item_name, agent_name)
          for item_name, item_amount, item_price, agent_name in item_list
          if agent_name in x_agents
        ])
        on_cache[key] = x_on
        log.log(LOG_OP, lambda: "new_jobs, setup   ...on_cache  {:s} = {}".format(key,
          ";".join("{:s}({}):{},{}".format(agent_name, x_sort1, name, amount, price)
            for x_sort1, x_sort2, price, amount, name, agent_name in x_on
        )))
      # buy_cache
      for item_name, item_list in list_buy.items():
        # TODO..., critical sort
        key = item_name+"-"+storage
        x_buy = sorted([
          (sc_cache[agent_name], -item_amount, item_price, item_amount, item_name, agent_name, fac_id)
          for item_name, item_amount, item_price, agent_name, fac_id in item_list
          if agent_name in x_agents
        ])
        buy_cache[key] = x_buy
        log.log(LOG_OP, lambda: "new_jobs, setup   ...buy_cache {:s} = {}".format(key,
          ";".join("{:s},{:s}({}):{},{}@{}".format(agent_name, fac_id, x_sort1, name, amount, price)
            for x_sort1, x_sort2, price, amount, name, agent_name, fac_id in x_buy
        )))
      storage_cache.add(storage)
  
  ### end initial setup
  log.log(LOG_OP, lambda: "new_jobs, setup complete, jobs = {:d}, opts = {:d}".format(len(set(opt_job.values())), opt_id))
  
  # when a new job is scheduled, some of the remaining opts may be invalid
  # this is checked by adjusting on_cache and buy_cache
  opt_ids = set(opt_db.keys())
  while len(opt_ids) > 0:
    
    if not avail_agents:
      log.log(LOG_OP, lambda: "new_jobs, main   no avail_agents")
      return
    
    # indexed by opt_id
    on_use_list = defaultdict(list)
    buy_use_list = defaultdict(list)
    assemble_list = {}
    party_agents = {}
    
    priq = []
    # loop by opt_id to complete
    for opt_id in list(opt_ids):
      
      opt_all, opt, op_tools, opt_assembled_count = opt_db[opt_id]
      job_id = opt_job[opt_id]
      log.log(LOG_OP, lambda: "")
      log.log(LOG_OP, lambda: "new_jobs, main   job_id: {:s} ({:d}) {}".format(job_id, opt_id, one_line_key_val_s(opt_all)))
      
      storage, end_step, steps, reward = job_cache[job_id]
      job_needed_parts = len(opt)
      job_needed_all = len(opt_all)
      job_completed_count = 0
      agent_capacity = {}
      for agent_name in avail_agents:
        z_shared = shared[agent_name]
        z_load = int(z_shared.view.self.load)
        z_capacity_max = int(z_shared.sim.role.load)
        x_capacity = z_capacity_max - z_load
        agent_capacity[agent_name] = x_capacity
      buy_cost = 0
      on_agents = set()
      buy_agents = set()
      z_agents = agents_cache[job_id]
      
      #
      # following uses on_cache, buy_cache, buy_shop
      #
      # temp copy
      buy_shop_temp = copy_dict_counter(buy_shop)
      
      # begin check recipe
      for item_name, item_amount in opt_all.items():
        
        # agent holds item
        for *x_sort, x_price, x_amount, x_name, agent_name in on_cache[item_name+"-"+storage]:
          if agent_name not in z_agents or agent_name not in avail_agents:
            continue
          use_amount = min(item_amount, x_amount)
          log.log(LOG_OP, lambda: "new_jobs, main   job_id: {:s} ({:d}) (on)  {:s} => {:s},{:d}, use = {:d}".format(
            job_id, opt_id, agent_name, x_name, x_amount, use_amount
          ))
          on_agents.add(agent_name)
          on_use_list[opt_id].append((use_amount, item_name, agent_name))
          item_amount -= use_amount
          if item_amount == 0:
            job_completed_count += 1
            log.log(LOG_OP, lambda: "new_jobs, main   job_id: {:s} ({:d}) {:s} (on)  {:s} completed !!!".format(
              job_id, opt_id, agent_name, item_name
            ))
            break
        if job_completed_count == job_needed_all:
          log.log(LOG_OP, lambda: "new_jobs, main   job_id: {:s} ({:d}) (on)  job completed !!!".format(job_id, opt_id))
          break
        if item_amount == 0:
          continue
        
        # agent inside shop can buy, can be same agent with on board items in previous loop
        for *x_sort, x_price, x_amount, x_name, agent_name, fac_id in buy_cache[item_name+"-"+storage]:
          if agent_name not in z_agents or agent_name not in avail_agents:
            continue
          if item_name in tool_db:
            agent_shared = shared[agent_name]
            if item_name in agent_shared.self_tools or item_name not in agent_shared.new_tools:
              log.log(LOG_OP, lambda: "new_jobs, main   job_id: {:s} ({:d}) {:s} (buy), tool {:s} loaded or incompatible".format(
                job_id, opt_id, agent_name, item_name))
              continue
          s_amount = buy_shop_temp[fac_id][item_name]
          if x_amount != s_amount:
            log.log(LOG_OP, lambda: "new_jobs, main   job_id: {:s} ({:d}) {:s} (buy) => {:s},{:d}, shop amount => {:d}".format(
              job_id, opt_id, agent_name, x_name, x_amount, s_amount
            ))
            x_amount = s_amount
          use_amount = min(item_amount, x_amount)
          log.log(LOG_OP, lambda: "new_jobs, main   job_id: {:s} ({:d}) {:s} (buy) => {:s},{:d}, use = {:d}".format(
            job_id, opt_id, agent_name, x_name, x_amount, use_amount
          ))
          x_capacity = agent_capacity[agent_name]
          item_data = item_db[item_name]
          item_density = item_data.volume
          if item_density > 0:
            use_amount = min(use_amount, int(x_capacity/item_density))
            use_volume = use_amount * item_density
            if use_amount == 0:
              log.log(LOG_OP, lambda: "new_jobs, main   job_id: {:s} ({:d}) {:s} (buy) {:s} reached capacity limit !!!".format(
                job_id, opt_id, agent_name, x_name))
              continue
            else:
              log.log(LOG_OP, lambda: "new_jobs, main   job_id: {:s} ({:d}) {:s} (buy, vol adj) => {:s},{:d}, use = {:d}".format(
                job_id, opt_id, agent_name, x_name, x_amount, use_amount
              ))
            x_capacity -= use_volume
            agent_capacity[agent_name] = x_capacity
            buy_shop_temp[fac_id][item_name] -= use_amount
          #
          x_buy_cost = use_amount * x_price
          buy_cost += x_buy_cost
          #
          buy_agents.add(agent_name)
          buy_use_list[opt_id].append((use_amount, item_name, agent_name, fac_id))
          item_amount -= use_amount
          if item_amount == 0:
            job_completed_count += 1
            log.log(LOG_OP, lambda: "new_jobs, main   job_id: {:s} ({:d}) {:s} (buy) {:s} completed !!!".format(
              job_id, opt_id, agent_name, item_name
            ))
            break
        if job_completed_count == job_needed_all:
          log.log(LOG_OP, lambda: "new_jobs, main   job_id: {:s} ({:d}) (buy) job completed !!!".format(job_id, opt_id))
          break
        if item_amount == 0:
          continue
      
      log.log(LOG_OP, lambda: "new_jobs, main   job_id: {:s} ({:d}) => {:d}/{:d} items completed, buy_cost = {:d}".format(
        job_id, opt_id, job_completed_count, job_needed_all, buy_cost
      ))
      # end check recipe
      
      # basic completeness checks
      if (not on_use_list[opt_id] and not buy_use_list[opt_id]):
        log.log(LOG_OP, lambda: "new_jobs, main   {:d}, SPEC job_id: {:s} ({:d}), no agents !".format(step, job_id, opt_id))
        opt_ids.remove(opt_id)
        continue
      if not (job_completed_count == job_needed_all):
        log.log(LOG_OP, lambda: "new_jobs, main   {:d}, SPEC job_id: {:s} ({:d}), no items !".format(step, job_id, opt_id))
        job_update_schedule_noitems(agent, job_id)
        opt_ids.remove(opt_id)
        continue
      
      # cost checks
      buy_limit = int(reward * JOB_MAX_BUY_COST_FAC)      
      if buy_cost > buy_limit and not job_id in active_missions:
        log.log(LOG_OP, lambda: "new_jobs, main   {:d}, SPEC job_id: {:s} ({:d}), buy_cost {:d} exceeds limit {:d} of reward ({:.2f} of {:d}) !".format(
          step, job_id, opt_id, buy_cost, buy_limit, JOB_MAX_BUY_COST_FAC, reward
        ))
        opt_ids.remove(opt_id)
        continue
      if reward - buy_cost < JOB_MIN_BALANCE and not job_id in active_missions:
        log.log(LOG_OP, lambda: "new_jobs, main   {:d}, SPEC job_id: {:s} ({:d}), buy balance {:d} below limit {:d} !".format(
          step, job_id, opt_id, reward - buy_cost, JOB_MIN_BALANCE
        ))
        opt_ids.remove(opt_id)
        continue
      
      # assembly checks
      # if all items already assembled, then no need to do assembly checks !
      all_agents = on_agents | buy_agents
      party_agents[opt_id] = all_agents
      if (opt_assembled_count == job_needed_parts):
        pass
      else:
        # helper dict for assembly check
        agent_items = defaultdict(Counter)
        for item_amount, item_name, agent_name in on_use_list[opt_id]:
          agent_items[agent_name][item_name] += item_amount
        for item_amount, item_name, agent_name, fac_id in buy_use_list[opt_id]:
          agent_items[agent_name][item_name] += item_amount
        
        assemble_plan = defaultdict(list)
        complete_status = attr_dict()
        complete_ok = False
        x_capacity = 0
        for add_agents in range(JOB_ASSEMBLY_MAX_ADD_AGENTS + 1):
          log.log(LOG_OP, lambda: "new_jobs, main   {:d}, SPEC job_id: {:s} ({:d}), assembly check, add agents = {:d}".format(
            step, job_id, opt_id, add_agents
          ))
          if add_agents > 0:
            add_list = [a for a in avail_agents - all_agents if agent_capacity[a] >= x_capacity]
            x_agents = sort_agents_speed(agent, add_list, storage, src_id=None, steps_cache=steps_cache)
            if len(x_agents) >= 1:
              all_agents.add((x_agents[0])[1])
            else:
              break
          # opt not needed as parameter, will work with agent_items !!!
          complete_ok = can_complete_job(agent, job_id,
            all_agents, agent_items, agent_capacity,
            assemble_plan, complete_status
          )
          if complete_ok:
            assemble_list[opt_id] = assemble_plan
            party_agents[opt_id] = all_agents
            break
          elif complete_status.status == "ERR-capacity":
            x_capacity = complete_status.x_capacity
          else:
            log.log(LOG_OP, lambda: "CHECK-ERR:   new_jobs, main   {:d}, SPEC job_id: {:s} ({:d}), assembly check error: {} !".format(
              step, job_id, opt_id, complete_status.status
            ))
            break
        if not complete_ok:
          log.log(LOG_OP, lambda: "CHECK-ERR: new_jobs, main   {:d}, SPEC job_id: {:s} ({:d}), cannot do assembly after adding {:d} agents, x_capacity = {:d} !".format(
            step, job_id, opt_id, add_agents, x_capacity
          ))
          opt_ids.remove(opt_id)
          continue
      
      # TODO..., other checks ???
      
      # append to list of jobs from which to choose the best one
      benefit = reward - buy_cost
      benefit_class = round(benefit/CORE_MONEY_CLASS)*CORE_MONEY_CLASS
      # TODO, evaluate critical order criteria !!!
      # sort highest
      priq.append((benefit_class, opt_assembled_count, end_step, job_id, opt_id))
    
    # choose a job_id, generate ops
    if priq:
      priq = sorted(priq, reverse=True)
      log.log(LOG_OP, lambda: "TEMP: priq = {}".format(priq))
      best = priq[0]
      
      *X_DUMMY, job_id, opt_id = best
      storage, end_step, steps, reward = job_cache[job_id]
      opt_all, opt, opt_tools, opt_assembled_count = opt_db[opt_id]
      job_needed_parts = len(opt)
      
      log.log(LOG_OP, lambda: "*** new_jobs, scheduling   {:d}, SPEC job_id: {:s} ({:d}) = {}".format(
        step, job_id, opt_id, one_line_key_val_s(opt_all)
      ))
      
      party = party_agents[opt_id]
      # all assembled, nothing to schedule here, 'deliver_jobs' will take care
      if (opt_assembled_count == job_needed_parts):
        assemble_steps = 0
        job_set_assembled(agent, job_id)
        log.info(lambda: "*** new_jobs, scheduling   {:d}, SPEC job_id: {:s} ({:d}) all required are assembled !!!".format(step, job_id, opt_id))
      # something to assemble
      else:
        # no final steps checks, should not be off usually
        # in case of all assembled then delivery to storage, so steps has been checked in setup
        # in case of assembly, it is possible to finish assembly in workshop
        # and then use pool of assembled items for next jobs
        log.log(LOG_OP, lambda: "*** new_jobs, scheduling   {:d}, SPEC job_id: {:s} ({:d}) for agents = ({:d}) {}".format(
          step, job_id, opt_id, len(party), one_line_key_s(party)
        ))
        
        #agent_on_list = defaultdict(list)
        #for amount, name, agent_name in on_use_list[opt_id]:
        #  agent_on_list[agent_name].append((amount, name))
        agent_buy_list = defaultdict(list)
        used_shop = defaultdict(Counter)
        for item_amount, item_name, agent_name, fac_id in buy_use_list[opt_id]:
          agent_buy_list[agent_name].append((item_amount, item_name))
          used_shop[fac_id][item_name] += item_amount
        
        workshop = best_workshop(agent, party, storage)
        if workshop is None:
          log.log(LOG_OP, lambda: "CHECK-ERR:   *** new_jobs, scheduling   {:d}, SPEC job_id: {:s} ({:d}) workshop is None !!!".format(
            step, job_id, opt_id,
          ))
          opt_ids.remove(opt_id)
          continue
        # schedule per agent
        for agent_name in party:
          action_seq = Action_Seq()
          agent_shared = shared[agent_name]
          agent_view = agent_shared.view
          a_self = agent_view.self
          facility = a_self.facility
          charge = int(a_self.charge)
          # buy items
          if agent_name in agent_buy_list:
            for item_amount, item_name in agent_buy_list[agent_name]:
              action_seq.append(
                # **args: _item_name, _item_amount, _fac_id, _job_id, _explore_tag
                op_buy(agent_name, 1,
                  _item_name=item_name, _item_amount=item_amount, _fac_id=facility, _job_id=job_id, _explore_tag=""
              ))
              plan_shared_buy(agent, agent_name, item_name, item_amount, facility)
          # goto workshop
          if facility != workshop:
            if agent_name in explore_agents:
              agent_shared.job_op.clear(agent)
              log.log(LOG_OP, lambda: "*** new_jobs, scheduling   SMART explore agent {:s} => {:s}".format(
                agent_name, workshop
              ))
            creat(log, agent_shared, workshop, action_seq=action_seq, job_id=job_id)
          # assemble actions
          assemble_seq = assemble_list[opt_id][agent_name]
          assemble_steps = len(assemble_seq)
          seq_fin = False
          for i, (item_name, assembler) in enumerate(assemble_seq):
            if i == assemble_steps - 1:
              seq_fin = True
            action_seq.append(
              # **args: _job_id, _fac_id, _item_name, _party, _assembler, seq_fin=False
              op_assemble(agent_name, 1,
                _job_id=job_id, _fac_id=workshop, _item_name=item_name, _party=party, _assembler=assembler, _seq_fin=seq_fin
            ))
          if len(action_seq) > 0:
            agent_shared.job_op = action_seq
            log.log(LOG_OP, lambda: "new_jobs, schedule   job_id: {:s} ({:d})   {:s} => ({:d}) {}".format(
              job_id, opt_id, agent_name, len(action_seq), action_seq
            ))
            avail_agents.remove(agent_name)
      
      # remove items used, modify on_cache, buy_cache, buy_shop
      for fac_id in buy_shop:
        buy_shop[fac_id] -= used_shop[fac_id]
      
      # on_cache
      for use_amount, item_name, agent_name in on_use_list[opt_id]:
        key = item_name+"-"+storage
        on_cache[key] = [
          (x_sort1, x_sort2, x_price, x_amount - use_amount, x_name, x_agent_name)
          for x_sort1, x_sort2, x_price, x_amount, x_name, x_agent_name in on_cache[key]
            if x_name == item_name and x_agent_name == agent_name
        ]
      # buy_cache
      for use_amount, item_name, agent_name, fac_id in buy_use_list[opt_id]:
        key = item_name+"-"+storage
        buy_cache[key] = [
          (x_sort1, x_sort2, x_price, buy_shop[fac_id][item_name], x_name, x_agent_name, x_fac_id)
          for x_sort1, x_sort2, x_price, x_amount, x_name, x_agent_name, x_fac_id in buy_cache[key]
            if x_name == item_name and x_agent_name == agent_name and x_fac_id == fac_id
        ]
      
      # log adjusted
      # on_cache
      log.log(LOG_OP, lambda: "new_jobs, schedule   new on_cache =")
      for key, x_on in on_cache.items():
        log.log(LOG_OP, lambda: "new_jobs, schedule   on_cache  {:s} = {}".format(key,
          ";".join("{:s}({}):{},{}".format(agent_name, x_sort1, name, amount, price)
            for x_sort1, x_sort2, price, amount, name, agent_name in x_on
        )))
      # buy_cache
      log.log(LOG_OP, lambda: "new_jobs, schedule   new buy_cache =")
      for key, x_buy in buy_cache.items():
        log.log(LOG_OP, lambda: "new_jobs, schedule   buy_cache {:s} = {}".format(key,
          ";".join("{:s},{:s}({}):{},{}@{}".format(agent_name, fac_id, x_sort1, name, amount, price)
            for x_sort1, x_sort2, price, amount, name, agent_name, fac_id in x_buy
        )))
      # buy_shop
      log.log(LOG_OP, lambda: "new_jobs, schedule   new buy_shop =")
      for key in sorted(buy_shop, key=natural_sort_key):
        val = buy_shop[key]
        if val:
          log.log(LOG_OP, lambda: "... {}: {}".format(key, one_line_key_val_s(val)))
          
      # bookkeeping, job_start must be first when a job is started
      job_start(agent, job_id, step)
      job_set_assemble_party(agent, job_id, party)
      job_set_opt(agent, job_id, opt, opt_tools, assemble_steps)
      opt_ids.remove(opt_id)
      log.info(lambda: "*** new_jobs, scheduled   {:d}, SPEC {:s} => assemble_steps = {:d}, party = ({:d}) {}".format(
        step, job_id, assemble_steps, len(party), one_line_key_s(party)
      ))
  
  log.log(LOG_OP, lambda: "")



# items_dict = Counter() of items by job_id
# avail_items = Counter() of available items
# aggregate over all jobs and items in items_dict
# return (count jobs completed, max items completed, distinct items_set, sum items completed, sum items amount)
def aggregate_job_stats(agent, items_dict, avail_items):
  
  # here items means completed items except for amount where it's raw amount
  items_jobs_count = 0
  items_max = 0
  items_set = set()
  items_sum = 0
  items_amount = 0
  for job_id, job_items in items_dict.items():
    req_count = len(job_items)
    items_count = 0
    for item_name, item_amount in job_items.items():
      if item_name in avail_items:
        amount = min(item_amount, avail_items[item_name])
        if amount == item_amount:
          items_set.add(item_name)
          items_count += 1
          items_sum += 1
        items_amount += amount
    if items_count == req_count:
      items_jobs_count += 1
    if items_count > items_max:
      items_max = items_count
  
  return items_jobs_count, items_max, items_set, items_sum, items_amount

def global_tools_coverage(agent, agent_list=None):
  log = agent._log
  shared = agent._shared
  step = agent._step
  
  tool_db = team.tool_db
  
  fac_goto = goto.fac_goto
  shop_view = agent.view.shop
  
  log.info(lambda: "")
  
  if not agent_list:
    agent_list = set(shared.keys())
  
  # helper dict of destination for each agent
  agent_goto = {}
  for fac_id, fac_goto_set in fac_goto.items():
    for agent_name in fac_goto_set:
      agent_goto[agent_name] = fac_id
  
  global_tools_x = set(tool_db) # copy
  log.info(lambda: "{:d}, global tools = {}".format(step, one_line_key_s(global_tools_x)))
  
  # tools covered by existing idle agents
  tools_covered = set()
  for agent_name in agent_list:
    agent_shared = shared[agent_name]
    compat_tools = agent_shared.compat_tools
    self_tools = agent_shared.self_tools
    
    # on board
    tools_covered.update(self_tools)
    
    # on spot
    agent_view = agent_shared.view
    facility = agent_view.self.facility
    fac_data = agent_view.facilities.get(facility)
    if fac_data and fac_data.facility_type == "shop":
      fac_items = fac_data.item
      fac_items_set = set(fac_items.keys())
      tools_covered.update(fac_items_set & compat_tools)
    
    # going shop
    fac_id = agent_goto.get(agent_name)
    if fac_id and fac_id in shop_view:
      fac_data = shop_view[fac_id]
      fac_items = fac_data.item
      fac_items_set = set(fac_items.keys())
      tools_covered.update(fac_items_set & compat_tools)
  
  log.info(lambda: "   tools covered = {}".format(one_line_key_s(tools_covered)))
  global_tools_x -= tools_covered
  log.info(lambda: "   tools missing = {}".format(one_line_key_s(global_tools_x)))
  log.info(lambda: "")
  
  return global_tools_x

# indexed by False = 0, True = 1
SINGLE_S = ["not single", "single"]

# we do not go to buy all tools for all agents
# just for some and when needed to participate in assembly
# hopefully about half or less agents will have all tools and the rest will participate
# TODO..., should do swap of agents to match better capacity constraints
# priority to missions and check carefully tool compatibility
def explore_jobs(agent):
  log = agent._log
  shared = agent._shared
  step = agent._step
  
  lap_timer = LapTimer(log, log_level=LOG_OP)
  lap_timer.lap_start()
  
  MAX_CONCURRENT_AGENTS = util.MAX_CONCURRENT_AGENTS
  EXPLORE_MAX_AGENTS_WHEN_JOBS = util.EXPLORE_MAX_AGENTS_WHEN_JOBS
  JOB_STEPS_FAC = util.JOB_STEPS_FAC
  
  CORE_STEPS_CLASS = util.CORE_STEPS_CLASS
  CORE_CAPACITY_PERCENT_CLASS = util.CORE_CAPACITY_PERCENT_CLASS
  CORE_CAPACITY_CLASS = util.CORE_CAPACITY_CLASS
  
  fac_agents = goto.fac_agents
  fac_goto = goto.fac_goto
  
  explore_agents = team.explore_agents
  
  shop_view = agent.view.shop
  jobs_view = agent.view.jobs_view
  job_spec_ignored = team.job_spec_ignored
  committed_jobs = team.committed_jobs
  active_jobs = team.active_jobs
  
  avail_jobs = active_jobs - committed_jobs
  
  if avail_jobs and len(explore_agents) >= EXPLORE_MAX_AGENTS_WHEN_JOBS:
    log.log(LOG_OP, lambda: "*** explore_jobs, reached limit of explore agents when jobs ({:d}) !\n".format(EXPLORE_MAX_AGENTS_WHEN_JOBS))
    return
  
  avail_agents, _ = partition_agents(agent)
  
  # TODO..., is it restrictive ??? not consider shop if reached MAX_CONCURRENT_AGENTS
  # TODO..., maybe some shops help with tool restrictions
  avail_shops = set(
    fac_id for fac_id in shop_view.keys()
    if len(fac_agents[fac_id]) + len(fac_goto[fac_id]) < MAX_CONCURRENT_AGENTS
  )
  
  log.log(LOG_OP, lambda: "")
  log.log(LOG_OP, lambda: "*** explore_jobs, avail_shops = {}, avail_agents = ({:d}) {}".format(one_line_key_s(avail_shops), len(avail_agents), one_line_key_s(avail_agents)))
  
  if not avail_shops or not avail_agents:
    log.log(LOG_OP, lambda: "*** explore_jobs, no shops or agents !\n")
    return
  
  _, avail_items = get_items_on(agent, avail_agents)
  
  log.log(LOG_OP, lambda: "explore_jobs, avail_agents = ({:d}) {}, avail_items = {}".format(
    len(avail_agents), one_line_key_s(avail_agents), one_line_key_val_s(avail_items)
  ))
  
  lap_timer.lap("explore_jobs, === avail_agents, avail_items ===")
  
  # add tools accessible via fac_goto
  # they are not in avail_agents but go there only via explore_jobs
  # this is done only for tools
  for fac_id, fac_data in shop_view.items():
    if fac_id in fac_goto:
      for agent_name in fac_goto[fac_id]:
        agent_shared = shared[agent_name]
        compat_tools = agent_shared.compat_tools
        self_tools = agent_shared.self_tools
        avail_items.update(self_tools)
        fac_items = fac_data.item
        fac_items_set = set(fac_items.keys())
        avail_items.update(fac_items_set & compat_tools)
  
  log.log(LOG_OP, lambda: "explore_jobs, avail_items (+fac_goto) = {}".format(one_line_key_val_s(avail_items)))
  
  lap_timer.lap("explore_jobs, === avail_items (+fac_goto) ===")
  
  # unified Counter(s) of job needs to explore
  # all items for each job
  items_mission = {}
  items_priced = {}
  tools_mission = {}
  tools_priced = {}
  # global tools need for jobs, excludes what's on agents
  global_tools_mission = set()
  global_tools_priced = set()
  for job_id, job_data in jobs_view.items():
    if job_id in job_spec_ignored or job_id in committed_jobs:
      continue
    
    job_type = jobs_view[job_id].job_type
    
    # don't include tools, will be handled separately
    _, req_items, req_tools = job_base_resources(agent, job_id)
    log.log(LOG_OP, lambda: "{:s} base => items: {}, tools: {}".format(job_id, one_line_key_val_s(req_items), one_line_key_val_s(req_tools)))
    req_items -= avail_items
    req_tools -= avail_items
    log.log(LOG_OP, lambda: "{:s} buy  => items: {}, tools: {}".format(job_id, one_line_key_val_s(req_items), one_line_key_val_s(req_tools)))
    if job_type == "mission":
      items_mission[job_id] = req_items
      tools_mission[job_id] = req_tools
      global_tools_mission.update(req_tools.keys())
    else:
      items_priced[job_id] = req_items
      tools_priced[job_id] = req_tools
      global_tools_priced.update(req_tools.keys())
  
  log.log(LOG_OP, lambda: "")
  
  lap_timer.lap("explore_jobs, === job dict(s) ===")
  
  # TODO, perhaps use only this as speeds very fast
  # global tools in shops, as if all needed  
  if jobs_view:
    global_tools_x = set()
  else:
    global_tools_x = global_tools_coverage(agent, avail_agents)
    
  lap_timer.lap("explore_jobs, === global tools coverage ===")
  
  # tools compatibility agent vs shop
  tools_compat = {}
  
  shop_criteria_list = []
  shop_criteria_dict = {}
  
  # shops vs avail_agents
  for fac_id, fac_data in shop_view.items():
    fac_items = fac_data.item
    fac_items_counter = Counter({x.name: int(x.amount) for x in fac_items.values()})
    fac_items_set = set(x.name for x in fac_items.values() if int(x.amount) > 0)
    
    # capacity in shop
    capacity_on_shop = {}
    shop_capacity = 0
    for agent_name, agent_shared in shared.items():
      if agent_name in fac_agents[fac_id] or agent_name in fac_goto[fac_id]:
        load = int(agent_shared.view.self.load)
        max_capacity = int(agent_shared.sim.role.load)
        shop_capacity += max_capacity - load
    capacity_on_shop[fac_id] = shop_capacity
    
    # tools compatibility
    # all shops so may use results later with tools_count_now
    log.log(LOG_DETAIL, lambda: "tools_compat for {:s} = {}".format(fac_id, one_line_key_val_s(fac_items_counter)))
    for agent_name in avail_agents:
      agent_shared = shared[agent_name]
      a_compat_tools = agent_shared.compat_tools
      tools_count = len(a_compat_tools & fac_items_set)
      tools_compat[agent_name + "-" + fac_id] = tools_count
      log.log(LOG_DETAIL, lambda: "   compat: {:s} => {:d}".format(agent_name + "-" + fac_id, tools_count))
    
    #
    # job aggregates + criteria
    #
    # NOTE: must run for all shops !!! (so shop_criteria_dict for all shops)
    #
    # list of criteria for items, tools that can be bought at shop, aggregate over all jobs as
    #
    # count jobs(items) completed, max items completed, sum items completed, count distinct items, sum items amount,
    # count jobs(tools) completed, max tools,           sum tools,           count distinct tools
    #
    # for missions, priced
    #
    mission_items_jobs, mission_items_max, mission_items_set, mission_items_sum, mission_items_amount = aggregate_job_stats(agent, items_mission, fac_items_counter)
    mission_tools_jobs, mission_tools_max, mission_tools_set, mission_tools_sum, mission_tools_amount = aggregate_job_stats(agent, tools_mission, fac_items_counter)
    priced_items_jobs,  priced_items_max,  priced_items_set,  priced_items_sum,  priced_items_amount  = aggregate_job_stats(agent, items_priced, fac_items_counter)
    priced_tools_jobs,  priced_tools_max,  priced_tools_set,  priced_tools_sum,  priced_tools_amount  = aggregate_job_stats(agent, tools_priced, fac_items_counter)
    
    # log
    log.log(LOG_OP, lambda: "=> mission items, jobs: {:d}   max: {:d}   set: {}   sum: {:d}   amt: {:d}".format(
      mission_items_jobs, mission_items_max, one_line_key_s(mission_items_set), mission_items_sum, mission_items_amount
    ))
    log.log(LOG_OP, lambda: "=> mission tools, jobs: {:d}   max: {:d}   set: {}   sum: {:d}   amt: {:d}".format(
      mission_tools_jobs, mission_tools_max, one_line_key_s(mission_tools_set), mission_tools_sum, mission_tools_amount
    ))
    log.log(LOG_OP, lambda: "=> priced  items, jobs: {:d}   max: {:d}   set: {}   sum: {:d}   amt: {:d}".format(
      priced_items_jobs,  priced_items_max,  one_line_key_s(priced_items_set),  priced_items_sum,  priced_items_amount
    ))
    log.log(LOG_OP, lambda: "=> priced  tools, jobs: {:d}   max: {:d}   set: {}   sum: {:d}   amt: {:d}".format(
      priced_tools_jobs,  priced_tools_max,  one_line_key_s(priced_tools_set),  priced_tools_sum,  priced_tools_amount
    ))
    
    if global_tools_mission & fac_items_set != mission_tools_set:
      log.log(LOG_OP, lambda: "CHECK-ERR:   mission tools calc {} != {} aggregate".format(
        global_tools_mission & fac_items_set, mission_tools_set
      ))
    if global_tools_priced & fac_items_set  != priced_tools_set:
      log.log(LOG_OP, lambda: "CHECK-ERR:   priced  tools calc {} != {} aggregate".format(
        global_tools_priced & fac_items_set,  priced_tools_set
      ))
    
    if fac_id in avail_shops:
      log.log(LOG_OP, lambda: "shop_estimate for {:s} = {}".format(fac_id, one_line_key_val_s(fac_items_counter)))
      # TODO, choice either as separate criteria or combined pairwise
      shop_criteria_list.append((
        -round(shop_capacity/CORE_CAPACITY_CLASS)*CORE_CAPACITY_CLASS,
        len(global_tools_x & fac_items_set), # how many of missing globally we get
        len(mission_tools_set),
        len(priced_tools_set),
        mission_items_jobs, mission_items_max, mission_items_amount,
        priced_items_jobs,  priced_items_max,  priced_items_amount,
        mission_tools_jobs, mission_tools_max,
        priced_tools_jobs,  priced_tools_max,
        fac_id
      ))
    # TODO, review
    # used for benefit comparison with agent home shop, must include most important
    shop_criteria_dict[fac_id] = (
      -round(shop_capacity/CORE_CAPACITY_CLASS)*CORE_CAPACITY_CLASS,
      len(global_tools_x & fac_items_set), # how many of missing globally we get
      len(mission_tools_set),
      len(priced_tools_set),
      mission_items_jobs, mission_items_max, mission_items_amount,
      priced_items_jobs,  priced_items_max,  priced_items_amount,
      mission_tools_jobs, mission_tools_max,
      priced_tools_jobs,  priced_tools_max
    )
  
  lap_timer.lap("explore_jobs, === aggregates by fac_id ===")
  
  # agent cache
  agent_cache = {}
  for agent_name in avail_agents:
    agent_shared = shared[agent_name]
    agent_sim = agent_shared.sim
    a_role = agent_sim.role
    agent_view = agent_shared.view
    a_self = agent_view.self
    
    self_volume = int(a_self.load) #util.calc_self_volume(agent_shared)
    
    # TODO, remove after some tests
    calc_volume = calc_self_volume(agent_shared)
    if self_volume != calc_volume:
      log.log(LOG_OP, lambda: "CHECK-ERR:   {:s}, sim load {} != {} calc volume".format(
        agent_name, self_volume, calc_volume
      ))
    
    capacity_max = int(a_role.load)
    capacity_value = capacity_max - self_volume
    capacity_class = round(capacity_value/CORE_CAPACITY_CLASS)*CORE_CAPACITY_CLASS
    
    in_shop = 0
    tools_count_now = 0
    facility = a_self.facility
    fac_data = agent_view.facilities.get(facility)
    if fac_data and fac_data.facility_type == "shop":
      in_shop = 1
      tools_count_now = tools_compat[agent_name + "-" + fac_id]
    
    charge = int(a_self.charge)
    
    agent_cache[agent_name] = (capacity_value, capacity_class, in_shop, tools_count_now, facility, charge)
  
  lap_timer.lap("explore_jobs, === agent cache ===")
  
  # loop, for each shop (in order of most promising shop first)
  # find best agent that can complete most jobs in time and carry most items
  # remove agent and repeat
  # no need to handle cases of many superfluous agents to same shop
  # as existing agent will buy items (first in order of action selections) and reduce suitability
  
  # mode_random = False
  
  steps_cache = {}
  # loop per shop
  for (
    shop_capacity_sort,
    global_tools_sort, mission_tools_sort, priced_tools_sort,
    mission_items_jobs, mission_items_max, mission_items_amount,
    priced_items_jobs,  priced_items_max,  priced_items_amount,
    mission_tools_jobs, mission_tools_max,
    priced_tools_jobs,  priced_tools_max,
    fac_id
  ) in sorted(shop_criteria_list, reverse=True):
    
    if not avail_agents:
      break
    
    # all agents even in same shop so that reduce unnecessary moves
    #agents_list = [x for x in avail_agents if shared[x].view.self.facility != fac_id]
    agents_list = set(avail_agents)
    
    log.log(LOG_OP, lambda: "")
    log.log(LOG_OP, lambda: "explore_jobs, for {:s} => tool g/m/p: {:d},{:d},{:d}   m: job/max/amt: {:d},{:d},{:d} p: job/max/amt:{:d},{:d},{:d} + m: job/max: {:d},{:d} p: job/max: {:d},{:d}, agents = {}".format(
      fac_id,
      global_tools_sort, mission_tools_sort, priced_tools_sort,
      mission_items_jobs, mission_items_max, mission_items_amount,
      priced_items_jobs,  priced_items_max,  priced_items_amount,
      mission_tools_jobs, mission_tools_max,
      priced_tools_jobs,  priced_tools_max,
      one_line_key_s(agents_list)
    ))
    
    q = []
    # loop per agent
    for agent_name in agents_list:
      
      agent_shared = shared[agent_name]
      
      key = agent_name + "-" + fac_id
      if key in steps_cache:
        steps_value = steps_cache[key]
      else:
        steps_value = creat(log, agent_shared, fac_id)
        steps_cache[key] = steps_value
      steps_class = round(steps_value/CORE_STEPS_CLASS)*CORE_STEPS_CLASS
      
      tools_count = tools_compat[agent_name + "-" + fac_id]
      
      capacity_value, capacity_class, in_shop, tools_count_now, facility, charge = agent_cache[agent_name]
      
      log.log(LOG_OP, lambda: "   explore_jobs: {:s} => {:s}, tool: {:d} (now: {:d}), c: {:d} ({:d}), steps: {:d} ({:d}), in_shop: {:d} ({:s}), b: {:d}".format(
        agent_name, fac_id, tools_count, tools_count_now, capacity_value, capacity_class, steps_value, steps_class, in_shop, facility, charge 
      ))
      
      # -avail_capacity, steps_value/max(charge, 1)
      # TODO, evaluate critical order criteria !!!
      # sort highest
      q.append((
        tools_count, -in_shop, -tools_count_now, capacity_class, -steps_class, -steps_value,
        agent_name
      ))
    
    # generate ops
    #if q:
    q = sorted(q, reverse=True)
    while q:
      log.log(LOG_OP, lambda: "TEMP: q = {}".format(q))
      #best = sorted(q)[0]
      best = q.pop(0)
      *X_DUMMY, steps_class_R, steps_value_R, agent_name = best
      steps_value = -steps_value_R
      steps_class = -steps_class_R
      
      capacity_value, capacity_class, in_shop, tools_count_now, facility, charge = agent_cache[agent_name]
      
      #in_shop = not not_in_shop
      single_in_shop = False
      single_s = ""
      if in_shop:
        single_in_shop = ( (len(fac_agents[facility]) + len(fac_goto[facility])) == 1 )
        single_s = SINGLE_S[single_in_shop]
      
      log.log(LOG_OP, lambda: "*** explore_jobs, best = {:s}   tool: {:d} (now: {:d}), c: {:d} ({:d}), steps: {:d} ({:d}), in_shop: {:d} ({:s} {:s})".format(
        agent_name, tools_count, tools_count_now, capacity_value, capacity_class, steps_value, steps_class, in_shop, facility, single_s
      ))
      
      # if already in this shop, ignore
      if facility == fac_id:
        continue
      
      # no creat if
      #   already in a shop and
      #   extra benefit to new shop is negligible (?! bogus calculation ?, TODO ... validate !!!)
      # TODO... cost/benefit analysis ???
      benefit = shop_criteria_dict[fac_id] > shop_criteria_dict[facility] if in_shop else False
      if ((benefit and not single_in_shop) or not in_shop):
        if in_shop:
          log.log(LOG_OP, lambda: "CHEK-FLASH:   explore_jobs, {:s} in {:s} => {:s}".format(agent_name, facility, fac_id))
          log.log(LOG_OP, lambda: "CHEK-FLASH:   benefit new = {:}".format(shop_criteria_dict[fac_id]))
          log.log(LOG_OP, lambda: "CHEK-FLASH:   benefit old = {:}".format(shop_criteria_dict[facility]))
        action_seq = Action_Seq()
        log.log(LOG_OP, lambda: "*** explore_jobs, creat {:s} => {:s}".format(agent_name, fac_id))
        agent_shared = shared[agent_name]
        creat(log, agent_shared, fac_id, action_seq=action_seq)
        if len(action_seq) > 0:
          agent_shared.job_op = action_seq
          avail_agents.remove(agent_name)
          add_explore(agent_name)
          break
    
    lap_timer.lap("explore_jobs, === one main explore ===")
    
    if avail_jobs and len(explore_agents) >= EXPLORE_MAX_AGENTS_WHEN_JOBS:
      log.log(LOG_OP, lambda: "*** explore_jobs, reached limit of explore agents when jobs ({:d}) !\n".format(EXPLORE_MAX_AGENTS_WHEN_JOBS))
      return
  
  log.log(LOG_OP, lambda: "")



def move_jobs(agent):
  log = agent._log
  shared = agent._shared
  step = agent._step
  
  job_db = team.job_db
  
  job_assemble_party = team.job_assemble_party
  job_assembled = team.job_assembled
  job_move_planned = team.job_move_planned
  job_move_completed = team.job_move_completed
  
  committed_jobs = team.committed_jobs
  
  for job_id in list(committed_jobs):
    if not job_assembled[job_id] or job_move_planned[job_id]:
      continue
    
    log.log(LOG_OP, lambda: "*** move_jobs, job_id: {:s}".format(job_id))
    
    party = job_assemble_party[job_id]
    # if gathered anywhere except storage
    storage = job_db[job_id].storage
    gather_fac_id = party_gathered(agent, party)
    if not (gather_fac_id and gather_fac_id != storage):
      job_set_move_completed(agent, job_id)
      continue
    
    move_op = defaultdict(Action_Seq)
    move_status = attr_dict()
    if not move_job1(agent, job_id, gather_fac_id, party, move_op, move_status):
      job_set_removed(agent, job_id)
      continue
    
    for agent_name in move_op.keys():
      agent_shared = shared[agent_name]
      action_seq = move_op.get(agent_name)
      if len(action_seq) > 0:
        agent_shared.job_op = action_seq
        log.log(LOG_OP, lambda: "move_jobs, {:s} => ({:d}) {}".format(
          agent_name, len(action_seq), action_seq
        ))
    
    log.log(LOG_OP, lambda: "*** move_jobs,   {:d}, SPEC {:s} move planned ({:d} slots, {:d} ops)".format(
      step, job_id, move_status.move_slots, move_status.move_ops
    ))
    job_set_move_planned(agent, job_id, move_status.move_slots, move_status.move_ops)
    if move_status.move_ops == 0:
      log.log(LOG_OP, lambda: "*** move_jobs,   {:d}, SPEC {:s} move completed".format(step, job_id))
      job_set_move_completed(agent, job_id)

# return True if done, even without move(s), False if error
def move_job1(agent, job_id, fac_id, party, move_op, move_status):
  log = agent._log
  shared = agent._shared
  
  JOB_MOVE_MIN_STEPS_GAIN = util.JOB_MOVE_MIN_STEPS_GAIN
  
  item_db = team.item_db
  job_db = team.job_db
  
  agent_items = defaultdict(Counter)
  is_complete_1 = is_complete_job_1(agent, job_id, party)
  is_complete_2 = is_complete_job_2(agent, job_id, party, agent_items)
  if not (is_complete_1 and is_complete_2):
    if is_complete_1 == True or is_complete_2 == True:
      log.log(LOG_OP, lambda: "CHECK-ERR:   move_job1, job_id: {:s}   is_complete_1 {} != {} is_complete_2 !!!".format(
        job_id, is_complete_1, is_complete_2
      ))
  
  # here, we have agents with deliverable items
  all_agents = set(agent_items.keys())
  
  storage = job_db[job_id].storage
  party_order = sort_agents_speed(agent, all_agents, storage, direct=True)
  log.log(LOG_OP, lambda: "CHECK-FLASH:   party_order = {} ({})".format(one_line_key(party_order), one_line_key_s(all_agents)))
  
  # agent_ix points to destination agent
  agent_ix = 0
  can_move = True
  # step slot we work on, must start from 1
  slot = 1
  slot_agents = set()
  move_ops = 0
  last_ops = set()
  # move from end moving items to start until meet or no gain
  for src_agent_steps, src_agent_name in party_order[::-1]:
    if not can_move:
      break
    
    src_deliverable = agent_items.get(src_agent_name)
    if not src_deliverable:
      continue
    
    while can_move and src_deliverable:
      dst_agent_steps, dst_agent_name = party_order[agent_ix]
      if dst_agent_name == src_agent_name:
        can_move = False
        break
      if src_agent_steps - dst_agent_steps < JOB_MOVE_MIN_STEPS_GAIN:
        can_move = False
        break
      # move as much to agent_ix, adjust agent_items db
      dst_shared = shared[dst_agent_name]
      dst_role = dst_shared.sim.role
      dst_self = dst_shared.view.self
      dst_load = int(dst_self.load)
      dst_capacity_max = int(dst_role.load)
      dst_capacity = dst_capacity_max - dst_load
      for item_name, item_amount in src_deliverable:
        item_data = item_db[item_name]
        item_density = int(item_data.volume)
        if item_density > 0:
          use_amount = min(use_amount, int(dst_capacity/item_density))
          use_volume = use_amount * item_density
          if use_amount == 0:
            agent_ix += 1
            break
          else:
            if src_agent_name in slot_agents or dst_agent_name in slot_agents:
              fill_slot(agent, all_agents, slot_agents)
              slot += 1
              slot_agents = set()
            # move pair
            last_ops = set()
            # **args: _fac_id, _giver, _receiver, _item_name, _item_amount, _slot, _seq_fin=False
            src_op = op_give(src_agent_name, 1, _fac_id=fac_id,
              _giver=src_agent_name, _receiver=dst_agent_name,
              _item_name=item_name, _item_amount=use_amount,
              _slot=slot, _seq_fin=False
            )
            move_op[src_agent_name].append(src_op)
            last_ops.add(src_op)
            # **args: _fac_id, _giver, _receiver, _slot, _seq_fin=False
            dst_op = op_receive(dst_agent_name, 1, _fac_id=fac_id,
              _giver=src_agent_name, _receiver=dst_agent_name,
              _slot=slot, _seq_fin=False
            )
            move_op[dst_agent_name].append(dst_op)
            # move management
            move_ops += 2
            last_ops.add(dst_op)
            # log
            log.log(LOG_OP, lambda: "move_job1, job_id: {:}   {:s} => {:s} actions = {} => {}".format(
              job_id, src_agent_name, dst_agent_name, src_op, dst_op
            ))
            dst_capacity -= use_volume
      break
  
  for op in last_ops:
    op._seq_fin = True
  move_status.move_slots = slot
  move_status.move_ops = move_ops
  return True

# append an op_skip to each agent in agent_list - slot_agents
def fill_slot(agent, agent_list, slot_agents, move_op):
  for agent_name in agent_list - slot_agents:
    move_op[agent_name].append(op_skip(agent_name, 1))

# will work if all items ready on board scattered agents and no assembly done
def deliver_jobs(agent):
  log = agent._log
  shared = agent._shared
  step = agent._step
  
  job_db = team.job_db
  
  job_assemble_party = team.job_assemble_party
  job_assembled = team.job_assembled
  job_move_completed = team.job_move_completed
  job_delivery_planned = team.job_delivery_planned
  
  committed_jobs = team.committed_jobs
  
  for job_id in list(committed_jobs):
    #if util.MOVE_ENABLE:
    #  if not job_move_completed[job_id] or job_delivery_planned[job_id]:
    #    continue
    #else:
    #  if not job_assembled[job_id] or job_delivery_planned[job_id]:
    #    continue
    if not job_assembled[job_id] or job_delivery_planned[job_id]:
      continue
    
    log.log(LOG_OP, lambda: "*** deliver_jobs, job_id: {:s}".format(job_id))
    
    party = job_assemble_party[job_id]
    storage = job_db[job_id].storage
    deliver_op = defaultdict(Action_Seq)
    deliver_agents = set()
    if not deliver_job1(agent, job_id, storage, party, deliver_op, deliver_agents):
      job_set_removed(agent, job_id)
      continue
    
    for agent_name in deliver_op.keys():
      agent_shared = shared[agent_name]
      action_seq = deliver_op.get(agent_name)
      if len(action_seq) > 0:
        agent_shared.job_op = action_seq
        log.log(LOG_OP, lambda: "deliver_jobs, {:s} => ({:d}) {}".format(
          agent_name, len(action_seq), action_seq
        ))
    
    log.log(LOG_OP, lambda: "*** deliver_jobs,   {:d}, SPEC {:s} delivery planned".format(step, job_id))
    job_set_delivery_party(agent, job_id, deliver_agents)
    job_set_delivery_planned(agent, job_id)

# pure delivery of assembled items on board
# TODO, what if already in storage ?
def deliver_job1(agent, job_id, storage, party, deliver_op, deliver_agents):
  log = agent._log
  shared = agent._shared
  
  agent_items = defaultdict(Counter)
  is_complete_1 = is_complete_job_1(agent, job_id, party)
  is_complete_2 = is_complete_job_2(agent, job_id, party, agent_items)
  if not (is_complete_1 and is_complete_2):
    if is_complete_1 == True or is_complete_2 == True:
      log.log(LOG_OP, lambda: "CHECK-ERR:   deliver_job1, job_id: {:s}   is_complete_1 {} != {} is_complete_2 !!!".format(
        job_id, is_complete_1, is_complete_2
      ))
  
  # here, we have agents with deliverable items
  all_agents = set(agent_items.keys())
  deliver_agents.update(all_agents)

  for agent_name in deliver_agents:
    action_seq = Action_Seq()
    agent_shared = shared[agent_name]
    agent_view = agent_shared.view
    a_self = agent_view.self
    facility = a_self.facility
    charge = int(a_self.charge)
    # SMART schedule (!)
    # can be in storage and deliver immediately without need for call recharge
    if facility != storage:
      # TODO, check if needed
      if charge == 0:
        single_recharge_goto(log, agent_shared, storage, action_seq, job_id)
      else:
        creat(log, agent_shared, storage, action_seq=action_seq, job_id=job_id)
    # **args: _job_id, _fac_id
    action_seq.append(op_deliver_job(agent_name, 1, _job_id=job_id, _fac_id=storage))
    # TODO, check ...
    schedule_type = ""
    #if facility == storage:
    if facility == storage or charge == 0:
      schedule_type = "SMART "
    if len(action_seq) > 0:
      deliver_op[agent_name] = action_seq
      log.log(LOG_OP, lambda: "deliver_job1, job_id: {:s}   {:s}schedule: {:s} => ({:d}) {}".format(
        job_id, schedule_type, agent_name, len(action_seq), action_seq
      ))
  return True



# plan_shared data

# some use is extraneous as no multitasking in same step
# ie. retrieve delivered is not needed now
# buy maybe in future if improved mode
# where retrieve and new job delivers with them are scheduled in same step
# used by
#   new_jobs, to update buy (capacity + shop availability)
#   explore_buys_forced
#   explore_buys
#   retrieve_delivered, to update retrieve (capacity)

# not used by
#   explore_jobs as it will not buy and agents separate from others

# shared capacity dict
plan_agent_capacity = defaultdict(int)
plan_agent_max_capacity = defaultdict(int)

# shop data
plan_shop_items_count = defaultdict(Counter)
plan_shop_items_price = defaultdict(lambda: defaultdict(int))

# use of dict avoids use of global etc.
# other shared: explore_buy_cost
plan_shared = attr_dict({"explore_buy_forced_cost": 0, "explore_buy_cost": 0})

# new plan shared, to avoid many recalculations and better situational awareness
def set_plan_shared(agent):
  log = agent._log
  shared = agent._shared
  
  import plan
  
  shop_view = agent.view.shop
  
  plan_shared.explore_buy_forced_cost = team.explore_buy_forced_cost
  plan_shared.explore_buy_cost = team.explore_buy_cost
  
  plan.plan_shop_items_count = defaultdict(Counter)
  plan.plan_shop_items_price = defaultdict(lambda: defaultdict(int))
  for fac_id, fac_data in shop_view.items():
    fac_items = fac_data.item
    fac_items_counter = Counter({x.name: int(x.amount) for x in fac_items.values()})
    fac_items_price = {x.name: int(x.price) for x in fac_items.values()}
    plan_shop_items_count[fac_id] = fac_items_counter
    plan_shop_items_price[fac_id] = fac_items_price
  
  plan.plan_agent_capacity = defaultdict(int)
  plan.plan_agent_max_capacity = defaultdict(int)
  for agent_name, agent_shared in shared.items():
    max_capacity = int(agent_shared.sim.role.load)
    load = int(agent_shared.view.self.load)
    plan_agent_capacity[agent_name] = max(max_capacity - load, 0)
    plan_agent_max_capacity[agent_name] = max_capacity

def plan_shared_buy(agent, agent_name, item_name, item_amount, fac_id, job_id=None, explore_tag=None):

  item_db = team.item_db
  
  item_volume = item_db[item_name].volume
  item_price = plan_shop_items_price[fac_id][item_name]
  
  buy_cost = item_amount * item_price
  
  if not job_id:
    if explore_tag == "FORCE":
      plan_shared.explore_buy_forced_cost += buy_cost
    else:
      plan_shared.explore_buy_cost += buy_cost
  plan_agent_capacity[agent_name] -= item_amount * item_volume
  plan_shop_items_count[fac_id][item_name] -= item_amount

def plan_shared_retrieve_delivered(agent, agent_name, item_name, item_amount):

  item_db = team.item_db
  item_volume = item_db[item_name].volume
  
  plan_agent_capacity[agent_name] -= item_amount * item_volume

# risk that in next step(s) could be selected for jobs and not enough capacity
# NEW mode
def explore_buys_forced(agent):
  log = agent._log
  shared = agent._shared
  step = agent._step
  
  EXPLORE_BUY_FORCED_ENABLE = util.EXPLORE_BUY_FORCED_ENABLE
  EXPLORE_BUY_FORCED_MAX_STEP = util.EXPLORE_BUY_FORCED_MAX_STEP
  EXPLORE_BUY_FORCED_MAX_COST = util.EXPLORE_BUY_FORCED_MAX_COST
  EXPLORE_BUY_FORCED_MAX_ITEMS = util.EXPLORE_BUY_FORCED_MAX_ITEMS
  EXPLORE_BUY_FORCED_MAX_LOAD_PCT = util.EXPLORE_BUY_FORCED_MAX_LOAD_PCT
  EXPLORE_BUY_FORCED_MIN_CAPACITY = util.EXPLORE_BUY_FORCED_MIN_CAPACITY
  
  if not EXPLORE_BUY_FORCED_ENABLE:
    log.log(LOG_OP, lambda: "*** explore_buys_forced, disabled !\n")
    return
  
  if step >  EXPLORE_BUY_FORCED_MAX_STEP:
    log.log(LOG_OP, lambda: "*** explore_buys_forced, reached max step limit ({:d}) !\n".format(EXPLORE_BUY_FORCED_MAX_STEP))
    return
  
  if plan_shared.explore_buy_forced_cost >= EXPLORE_BUY_FORCED_MAX_COST:
    log.log(LOG_OP, lambda: "*** explore_buys_forced, reached buy_cost limit ({:d}) !\n".format(EXPLORE_BUY_FORCED_MAX_COST))
    return
  
  avail_agents, _ = partition_agents(agent)
  
  if not avail_agents:
    log.log(LOG_OP, lambda: "*** explore_buys_forced, no agents !\n")
    return
  
  log.log(LOG_OP, lambda: "*** explore_buys, avail_agents = ({:d}) {}".format(
    len(avail_agents), one_line_key_s(avail_agents)
  ))
  
  item_db = team.item_db
  
  # list of (count, item1_volume1, name) sorted high to low, higher count, lower volume
  item_spec_list = team.item_spec_list
  
  max_items = min(EXPLORE_BUY_FORCED_MAX_ITEMS, len(item_spec_list))
  
  #force_items = item_spec_list[:max_index]
  #log.log(LOG_OP, lambda: "*** explore_buys_forced, force for {}".format(
  #  ";".join(" "+s[2]+","+str(s[0])+":"+str(s[1]) for s in force_items)
  #))
  
  _, shop_item_amount, shop_item_cost, shop_item_volume = shop_stats(agent)
  items_sort = sorted([
    # sort by low volume first
    (shop_item_volume[item_name], shop_item_cost[item_name], shop_item_amount[item_name], item_name)
    for item_name in shop_item_amount.keys()
  ])
  items_list = [(20, item_db[item_name].volume, item_name) for _, _, _, item_name in items_sort]
  force_items = items_list[:max_items]
  log.log(LOG_OP, lambda: "*** explore_buys_forced, force for {}".format(
    ";".join(" "+s[2]+","+str(s[0])+":"+str(s[1]) for s in force_items)
  ))
  
  for agent_name in avail_agents:
    agent_shared = shared[agent_name]
    
    facility = agent_shared.view.self.facility
    if facility not in plan_shop_items_count:
      continue
    
    fac_items_counter = plan_shop_items_count[facility]
    fac_items_price = plan_shop_items_price[facility]
    
    for _, item_volume1, item_name in force_items:

      if not item_name in fac_items_counter:
        continue
      
      max_capacity = plan_agent_max_capacity[agent_name]
      if max_capacity < EXPLORE_BUY_FORCED_MIN_CAPACITY:
        break
      capacity_min = max_capacity - int(max_capacity * EXPLORE_BUY_FORCED_MAX_LOAD_PCT/100)
      capacity = plan_agent_capacity[agent_name]
      capacity_avail = max(capacity - capacity_min, 0)
      
      explore_buy_forced_cost = plan_shared.explore_buy_forced_cost
      
      ###log.log(LOG_OP, lambda: "item_amount = {:d}, use_amount = {:d}, item_volume1 = {:d}".format(item_amount, use_amount, item_volume1))
      item_amount = fac_items_counter[item_name]
      item_price = fac_items_price[item_name]
      use_amount = item_amount
      use_amount = min(use_amount, int(capacity_avail/max(item_volume1, 1)))
      use_amount = min(use_amount, max(int((EXPLORE_BUY_FORCED_MAX_COST - explore_buy_forced_cost)/max(item_price, 1)), 0))
      use_volume = use_amount * item_volume1
      if use_amount == 0:
        continue
      
      action_seq = Action_Seq()
      action_seq.append(
        # **args: _item_name, _item_amount, _fac_id, _job_id, _explore_tag
        op_buy(agent_name, 1,
          _item_name=item_name, _item_amount=use_amount, _fac_id=facility, _job_id="", _explore_tag="FORCE"
      ))
      plan_shared_buy(agent, agent_name, item_name, use_amount, facility, job_id="", explore_tag="FORCE")
      log.log(LOG_OP, lambda: "explore_buys_forced, {:s} ({:d}) => {:s},{:d}/{:d}".format(
        agent_name, max_capacity, item_name, use_amount, item_amount
      ))
      if use_amount == item_amount:
        log.log(LOG_OP, lambda: "CHECK-FLASH:   explore_buys_forced, {:s} ({:d}) => {:s},{:d}/{:d} all!".format(
          agent_name, max_capacity, item_name, use_amount, item_amount
        ))
      agent_shared.job_op = action_seq
      log.log(LOG_OP, lambda: "explore_buys_forced, action {:s} ({:d}) => ({:d}) {}".format(
        agent_name, max_capacity, len(action_seq), action_seq
      ))
      
      if plan_shared.explore_buy_forced_cost >= EXPLORE_BUY_FORCED_MAX_COST:
        log.log(LOG_OP, lambda: "explore_buys_forced, reached buy_cost limit ({:d}) !\n".format(EXPLORE_BUY_FORCED_MAX_COST))
        return

# risk that in next step(s) could be selected for jobs and not enough capacity
# but on the other hand builds a repository of items for jobs, useful in high job contention
# only a single buy, and only items (not tools)
def explore_buys(agent):
  log = agent._log
  shared = agent._shared
  step = agent._step
  
  EXPLORE_BUY_ENABLE = util.EXPLORE_BUY_ENABLE
  EXPLORE_BUY_MAX_STEP = util.EXPLORE_BUY_MAX_STEP
  EXPLORE_BUY_MAX_COST = util.EXPLORE_BUY_MAX_COST
  EXPLORE_BUY_MAX_ITEM_AMOUNT = util.EXPLORE_BUY_MAX_ITEM_AMOUNT
  EXPLORE_BUY_MAX_LOAD_PCT = util.EXPLORE_BUY_MAX_LOAD_PCT
  EXPLORE_BUY_MIN_CAPACITY = util.EXPLORE_BUY_MIN_CAPACITY
  
  if not EXPLORE_BUY_ENABLE:
    log.log(LOG_OP, lambda: "*** explore_buys, disabled !\n")
    return
  
  if step >  EXPLORE_BUY_MAX_STEP:
    log.log(LOG_OP, lambda: "*** explore_buys, reached max step limit ({:d}) !\n".format(EXPLORE_BUY_MAX_STEP))
    return
  
  if plan_shared.explore_buy_cost >= EXPLORE_BUY_MAX_COST:
    log.log(LOG_OP, lambda: "*** explore_buys, reached buy_cost limit ({:d}) !\n".format(EXPLORE_BUY_MAX_COST))
    return
  
  avail_agents, _ = partition_agents(agent)
  
  if not avail_agents:
    log.log(LOG_OP, lambda: "*** explore_buys, no agents !\n")
    return
  
  # NOTE: no risk of double buying a force item
  # because there will not be availability in shop
  # if still there is then it is good as we will buy totally the force item
  exclude_items = set(x.name for agent_name in avail_agents for x in shared[agent_name].view.self.self_items.values())
  
  log.log(LOG_OP, lambda: "*** explore_buys, avail_agents = ({:d}) {}, exclude: items = {}".format(
    len(avail_agents), one_line_key_s(avail_agents), one_line_key_s(exclude_items)
  ))
  
  item_db = team.item_db
  tool_db = team.tool_db
  
  for agent_name in avail_agents:
    agent_shared = shared[agent_name]
    
    facility = agent_shared.view.self.facility
    if facility not in plan_shop_items_count:
      continue
    
    fac_items_counter = plan_shop_items_count[facility]
    fac_items_price = plan_shop_items_price[facility]
    fac_items_list = sorted([
      # TODO..., sort by price first ?!?
      #item_volume1, item_price, item_amount, item_name
      (item_db[item_name].volume, fac_items_price[item_name], item_amount, item_name)
      for item_name, item_amount in fac_items_counter.items()
      if item_name not in exclude_items and item_name not in tool_db
    ])
    
    if not fac_items_list:
      continue
    
    max_capacity = plan_agent_max_capacity[agent_name]
    if max_capacity < EXPLORE_BUY_MIN_CAPACITY:
      break
    capacity_min = max_capacity - int(max_capacity * EXPLORE_BUY_MAX_LOAD_PCT/100)
    capacity = plan_agent_capacity[agent_name]
    capacity_avail = max(capacity - capacity_min, 0)
    
    explore_buy_cost = plan_shared.explore_buy_cost
    
    ###log.log(LOG_OP, lambda: "item_amount = {:d}, use_amount = {:d}, item_volume1 = {:d}".format(item_amount, use_amount, item_volume1))
    item_volume1, item_price, item_amount, item_name = fac_items_list[0]
    use_amount = item_amount
    use_amount = min(use_amount, EXPLORE_BUY_MAX_ITEM_AMOUNT)
    use_amount = min(use_amount, int(capacity_avail/max(item_volume1, 1)))
    use_amount = min(use_amount, max(int((EXPLORE_BUY_MAX_COST - explore_buy_cost)/max(item_price, 1)), 0))
    use_volume = use_amount * item_volume1
    if use_amount == 0:
      continue
    
    action_seq = Action_Seq()
    action_seq.append(
      # **args: _item_name, _item_amount, _fac_id, _job_id, _explore_tag
      op_buy(agent_name, 1,
        _item_name=item_name, _item_amount=use_amount, _fac_id=facility, _job_id="", _explore_tag=""
    ))
    plan_shared_buy(agent, agent_name, item_name, use_amount, facility, job_id="", explore_tag="")
    exclude_items.add(item_name)
    log.log(LOG_OP, lambda: "explore_buys, {:s} ({:d}) => {:s},{:d}/{:d}".format(
      agent_name, max_capacity, item_name, use_amount, item_amount
    ))
    if use_amount == item_amount:
      log.log(LOG_OP, lambda: "CHECK-FLASH:   explore_buys, {:s} ({:d}) => {:s},{:d}/{:d} all!".format(
        agent_name, max_capacity, item_name, use_amount, item_amount
      ))
    agent_shared.job_op = action_seq
    log.log(LOG_OP, lambda: "explore_buys, action {:s} ({:d}) => ({:d}) {}".format(
      agent_name, max_capacity, len(action_seq), action_seq
    ))
    
    if plan_shared.explore_buy_cost >= EXPLORE_BUY_MAX_COST:
      log.log(LOG_OP, lambda: "explore_buys, reached buy_cost limit ({:d}) !\n".format(EXPLORE_BUY_MAX_COST))
      return



# always check first, because may failed due to other team, so get back items
# the operations are untracked as should never fail
def retrieve_delivered(agent):
  return
  log = agent._log
  shared = agent._shared
  step = agent._step
  
  item_db = team.item_db
  job_db = team.job_db
  
  job_delivery_party = team.job_delivery_party
  
  storage_view = agent.view.storage
  
  avail_agents, _ = partition_agents(agent)
  
  if not avail_agents:
    log.log(LOG_OP, lambda: "*** retrieve_delivered, no agents !\n")
    return
  
  # for each storage
  for storage, storage_data in storage_view.items():
    storage_items = storage_data.item
    if not storage_items:
      continue
    
    items_list = []
    for item_name, item_stored in storage_items.items():
      if "delivered" in item_stored:
        item_amount = int(item_stored.delivered)
        item_volume = item_db[item_name].volume
        items_list.append((item_volume, item_amount, item_name))
    
    # currently only agents in storage (for some delivery for example)
    # no explicit goto to go and retrieve
    agent_load = {}
    agent_max_capacity = {}
    for agent_name in avail_agents:
      agent_shared = shared[agent_name]
      a_self = agent_shared.view.self
      facility = a_self.facility
      if facility == storage:
        a_role = agent_shared.sim.role
        agent_load[agent_name] = int(a_self.load)
        agent_max_capacity[agent_name] = int(a_role.load)
    
    agent_list = set(agent_max_capacity.keys())
    if not agent_list:
      continue
    
    log.log(LOG_OP, lambda: "*** retrieve_delivered, items = {} => {}".format(
      ";".join(" "+str(x[2])+","+str(x[1])+"*"+str(x[0]) for x in sorted(items_list)),
      one_line_key_s(agent_list)
    ))
    
    # load agents balanced
    # bigger items first !
    # TODO..., may change to smallest first so to load more ???
    # but biggest are most complex to build and load
    agent_r_map = defaultdict(Counter)
    for item_volume, item_amount, item_name in sorted(items_list, reverse=True):
      retrieve_agents = set(agent_list)
      retrieve_amount = item_amount
      for i in range(item_amount):
        agent_load_list = [
          (agent_max_capacity[agent_name] - agent_load[agent_name], agent_name)
          for agent_name in retrieve_agents
        ]
        # onto higher capacity agent first !
        agent_r = (sorted(agent_load_list, reverse=True)[0])[1]
        if not (agent_max_capacity[agent_r] - agent_load[agent_r] >= item_volume):
          break
        retrieve_amount -= 1
        agent_r_map[agent_r][item_name] += 1
        agent_load[agent_r] += item_volume
    
    # generate ops per agent
    for agent_name, r_map in agent_r_map.items():
      action_seq = Action_Seq()
      for item_name, item_amount in r_map.items():
        action_seq.append(
          # **args: _fac_id, _item_name, _item_amount, _job_id
          op_retrieve_delivered(agent_name, 1,
            _item_name=item_name, _item_amount=item_amount, _fac_id=storage, _job_id=""
        ))
        log.log(LOG_OP, lambda: "retrieve_delivered, {:s}: {:s},{:d}".format(
          agent_name, item_name, item_amount
        ))
        plan_shared_retrieve_delivered(agent, agent_name, item_name, item_amount)
      if len(action_seq) > 0:
        shared[agent_name].job_op = action_seq
        log.log(LOG_OP, lambda: "retrieve_delivered, {:s} => ({:d}) {}".format(
          agent_name, len(action_seq), action_seq
        ))
        add_retrieve_delivered(agent_name)