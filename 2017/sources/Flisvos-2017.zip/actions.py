
"""

 /*
  * @(#) E.Sarmas   actions.py 0.9_63 (2017-09-18)
  *
  * Author: E.Sarmas
  *
  * Created: 2017-04-06
  *
  * Description: Flisvos 2017 (MAPC 2017)
  *
  * Version: 0.9_63
  * Version-Date: 2017-09-18
  *
  * Version-Log:
  *   0.1_0 (2017-04-06)   copy from Flisvos-2016
  *   0.1_9 (2017-05-29)   rewrite so stable core and fewer changes per scenario/implementation
  *   0.6_0 (2017-06-01)   refactoring, new sim messages/info (except distance calcs), running
  *                        fewer import dependency chains, code moved to more appropriate modules
  *                        logging messages with lambda: now, may speed up logging
  *                        single method to recursively decode messages
  *                        log_data moved within attr_dict as instance method
  *                        clear agent action handling/protocol and procedures/statistics/logging level use
  *                        removed items_db, jobs_spec moved in team
  *                        simple class method like procedures for data updates within appropriate module
  *                        clearer procedure interrelationships, existence and use
  *                        cache improvement to be useful for all roles
  *                        cleaner use of JOB_STEPS_FAC so no double use and wrong results
  *                        clearer method use protocol and use of other procedures for data updates
  *                        agents_with_item_on_board and agents_with_item_buy removed and embedded
  *                        introduced deliver_jobs and explore_buys
  *                        jobs_selection does not select but returns base recipe for all not ignored jobs
  *                        new_jobs now setups assembly or marks for delivery already assembled job
  *                        deliver_jobs may arrange first moves (give and take) to fewer and faster agents
  *   0.9_50 (2017-09-03)  qualification run, new_jobs/deliver_jobs/explore_buys disabled
  *   0.9_52 (2017-09-05)  added EXERCIZE_MODE as in qualification to test goto/charge/recharge system
  *                        ability to recover a job_op, for op_goto to recover from battery stalls by
  *                        recharging enough steps for next charging station and then going to destination
  *                        new dist_cache_history, random fail steps not counted
  *                        lowered level of all goto steps calculations
  *                        random fails don't stop op_goto(s) (bad interaction of reset/send_action )
  *                        also handled correctly if happen on first step of action
  *                        fixed job_op drop and job_drop confusion
  *                        new job_data[], SPEC tracks missions and removes fine from money
  *                        better handling of actions that indicate errors (ACTION_ERRORS)
  *                        new action retrieve_delivered and procedure retrieve_delivered in plan
  *                        new dict job_failed, and sets failed_jobs, just_failed_jobs
  *                        clearer actions for job_set_completed and job_set_failed (new), update_jobs_spec
  *                        reassigned role of job_db, new dict job_party
  *                        new procedures single_recharge and single_recharge_goto for faster recharge
  *                        creat can be called with agent in charging_station in future (with charge_level)
  *                        explore_jobs works without jobs and uses tool compatibility
  *                        along with mission and priced job needs in a useful order
  *                        refactored explore_jobs setup merging all loops, and removed shop_estimate
  *                        organized job work in phases (assembly, move, delivery)
  *                        move phase orchestrates give->receive to fewer better fit agents to deliver_jobs
  *                        and works like cpu instruction scheduling filling empty slots when needed
  *                        jobs_selection finally embedded within explore_jobs
  *                        explore_jobs considers better the suitability of each shop to finish jobs
  *                        and considers agent tool_compatibility better, and also global tool cover
  *                        socket timeout to 20 sec, never low value
  *                        enhanced strategy for CHECK-ERR asserts and other CHECK-... almost everywhere
  *                        is the fastest way to verify coverage and correct operation
  *                        changed logging levels everywhere so comfortable view of logging output
  *                        new failed action recovery logic, improved recover and drop functions 
  *                        checked all actions to send an action to server
  *                        new action.has_next() and use of next_action() only after barrier
  *                        so job_drop() works correctly with current action inside barrier
  *                        strange float calcs fixed (FLOAT_EP)
  *                        new job_state_check and actions_state_check, set jobs to drop (just_failed_jobs)
  *                        disabled move operations (give->receive to fewer and faster agents)
  *                        because not so important and code not tested well for crashes and more...
  *                        explore_buys only if no concurrent buy in same shop and only for items
  *   0.9_63 (2017-09-18)  good luck :) 
  */

"""

import collections

import util
import goto
import team



# DETAIL < DEBUG <   OP < INFO   < WARNING+
# agent log file =   LOG_DEBUG or LOG_DETAIL (verbose)
# main  log file =   LOG_OP
# console        =   LOG_INFO

LOG_OP = 19
LOG_DETAIL = 9



OrderedDict = collections.OrderedDict

#attr_dict = util.attr_dict
one_line_key_s = util.one_line_key_s
one_line_key = util.one_line_key

party_gathered = util.party_gathered

add_fac_goto = goto.add_fac_goto
remove_fac_goto = goto.remove_fac_goto
update_goto_stats = goto.update_goto_stats
new_cache_data = goto.new_cache_data
update_cache_data = goto.update_cache_data
single_recharge_goto = goto.single_recharge_goto

job_set_assembled = team.job_set_assembled
job_set_completed = team.job_set_completed
job_set_removed = team.job_set_removed
job_update_assembled = team.job_update_assembled
job_update_delivered = team.job_update_delivered
update_buy_cost = team.update_buy_cost
remove_explore = team.remove_explore
remove_retrieve_delivered = team.remove_retrieve_delivered



class Action_Seq():
  def __init__(self):
    self._action_list = []
    self._action_index = -1
    self._action_count = 0
    self._iter_index = -1
    self._drop_state = False
  
  def __len__(self):
    return self._action_count
  
  def __iter__(self):
    self._iter_index = -1
    return self
  
  def __next__(self):
    self._iter_index += 1
    if self._iter_index < self._action_count:
      return self._action_list[self._iter_index]
    else:
      raise StopIteration
  
  def __repr__(self):
    #return [str(x) for x in self._action_list]
    return str(self._action_list)
  
  def append(self, action):
    self._action_list.append(action)
    self._action_count += 1
  
  def extend(self, extend_seq):
    for a_op in extend_seq:
      self.append(a_op)
  
  def action(self):
    if self._action_count == 0 or self._action_index >= self._action_count:
      return None
    if self._action_index == -1:
      self._action_index = 0
    return self._action_list[self._action_index]
  
  # should return result of action() if action() never called
  def next_action(self):
    self._action_index += 1
    if self._action_index >= self._action_count:
      return None
    return self._action_list[self._action_index]
  
  def has_next(self):
    if self._action_index + 1 >= self._action_count:
      return False
    return True
  
  # clear a job_queue, call administrative tracking functions
  # mainly to use for a new op_goto
  def clear(self, agent):
    _ = self.action()
    for action in self._action_list[self._action_index:]:
      action.on_action_clear(agent)
    self.__init__()
  
  # replaces with list of actions to do in case of drop of current action
  # it is called with different agent than the op agent and must use only object data
  # and can use only data provided by __init__, send_action may have not run (next action in action_seq)
  def drop(self, agent):
    action = self.action()
    self.__init__()
    if action:
      new_action_list = action.on_action_drop(agent)
      if new_action_list:
        self._action_list = new_action_list
        self._action_count = len(self._action_list)
        self._drop_state = True
  
  # replaces action with necessary actions to continue job after a failure
  def recover(self, agent):
    action = self.action()
    recover_action_seq = action.on_action_failed(agent, self)
    if recover_action_seq:
      self.__init__()
      self._action_list = recover_action_seq
      self._action_count = len(self._action_list)
      return True
    else:
      return False



RESULT_OK = "successful"

#   op_action_seq, agent_name, steps; _start_step, _is_active, _failed, _update_shared
# op_type =
#   goto
#   skip
#   charge
#   recharge
#   abort
#   buy
#   deliver_job
#   post_job
#   assemble
#   give
#   receive
#   retrieve_delivered
class Action():
  def __init__(self, type, agent_name, steps, **args):
    self._type = type
    self._agent_name = agent_name
    self._steps = steps
    self._args = args
    self._repr = ""
    # negative so calculated action_steps = step - start_step is always positive
    self._start_step = -util.MAX_STEPS
    self._is_active = False
    self._failed = False
    self._failed_msg = ""
    self._updated_shared = False
    self._job_id = None
    self._reset_count = 0
    for x_key, x_value in args.items():
      setattr(self, x_key, x_value)
  
  def __repr__(self):
    return self._repr
  
  def run_step(self, agent):
    return agent._step - self._start_step - self._reset_count
  
  # only send_action() can access data of all agent(s) (as they have been updated before call)
  def send_action(self, agent):
    pass
  
  # make possible to send_action once again; on failed_random
  def reset(self, agent):
    self._reset_count += 1
    self._is_active = False
  
  def is_continuous(self, agent):
    return False
  
  # False for single step operations
  def is_active(self, agent, percept_action=None, percept_action_result=None):
    return False
  
  # action_result indicates temporary failure (e.g. blackout)
  def is_temp_failed(self, agent, action_result):
    return False
  
  # failure status, all checks done in is_active() or send_action()
  # if not defined, failure handled by percept
  def is_failed(self, agent):
    return self._failed
  
  def failed_error(self, agent):
    return self._failed_msg
  
  # only update_shared() can update team data structures
  def update_shared(self, agent, last_action=None, last_action_result=None):
    pass
  
  def on_action_clear(self, agent):
    return None
  
  def on_action_failed(self, agent, action_seq):
    return None
  
  # returns list of actions to do in case of drop of current action
  # it is called with different agent than the op agent and must use only object data
  # and can use only data provided by __init__, send_action may have not run (next action in action_seq)
  def on_action_drop(self, agent):
    return None



# _src_id = "none", if not inside a facility
# **args: _cache_categ, _fac_id, _src_id, _job_id (can be "")
class op_goto(Action):
  def __init__(self, agent_name, steps, **args):
    super().__init__("goto", agent_name, steps, **args)
    self._cache_key = None
    self._cache_value = None
    #self._fac_data = None
    self._action_steps = 0
    self._repr = "{:s} ({:s}) goto => {:s} ({:d} steps {:s}){:s}".format(
      self._agent_name, self._src_id, self._fac_id, self._steps, self._cache_categ,
      " "+self._job_id if self._job_id else ""
    )
    # could be thread safe because only one agent instantiating op(s)
    # but instantiation now done inside on_action_failed too
    add_fac_goto(agent_name, self._fac_id)
  
  # only send_action() can access data of all agent(s) (as they have been updated before call)
  def send_action(self, agent):
    log = agent._log
    
    if self._is_active:
      log.log(LOG_OP, lambda: "CHECK-ERR:   op_goto.send_action() called more than once !!!")
      skip(agent)
      return
    if self._steps == 0:
      log.log(LOG_OP, lambda: "CHECK-ERR:   op_goto, !!! 0 step goto {}".format(self.__repr__()))
    if self._reset_count == 0:
      a_self = agent.view.self
      if int(a_self.charge) == 0:
        log.log(LOG_OP, lambda: "CHECK-ERR:   op_goto, !!! goto with no charge {}".format(self.__repr__()))
        self._is_active = False
        self._failed = True
        self._failed_msg = "NO CHARGE (START)"
        skip(agent)
        return
      # _src_id = "none", if not inside a facility
      facility = agent.view.self.facility
      if self._src_id and facility != self._src_id:
        log.log(LOG_OP, lambda: "CHECK-ERR:   op_goto, not in start facility {:s}".format(self._src_id))
        self._is_active = False
        self._failed = True
        self._failed_msg = "NOT IN START FACILITY {:s}".format(self._src_id)
        skip(agent)
        return
    if not (self._start_step >= 0):
      self._start_step = agent._step
    percept_id = agent.view.id
    agent._comm.send_action(percept_id, "goto", OrderedDict([("facility", self._fac_id)]))
    self._is_active = True
  
  def is_active(self, agent, percept_action=None, percept_action_result=None):
    log = agent._log
    
    if not self._is_active:
      return False
    
    src_id = self._src_id
    fac_id = self._fac_id
    a_self = agent.view.self
    if a_self.facility == fac_id:
      self._is_active = False
      action_steps = agent._step - self._start_step
      action_steps -= self._reset_count
      self._action_steps = action_steps
      steps = self._steps
      cache_categ = self._cache_categ
      self._cache_key, self._cache_value = new_cache_data(log, agent, src_id, fac_id, action_steps, steps, cache_categ, self._reset_count)
      #self._fac_data = new_fac_data(agent, fac_id)
    else:
      if int(a_self.charge) == 0:
        log.log(LOG_OP, lambda: "CHECK-ERR:   agent STALLED !!!")
        #recharge_job[self._agent_name] = self._job_id
        self._is_active = False
        self._failed = True
        self._failed_msg = "NO CHARGE"
    return self._is_active
  
  # only update_shared() can update team data structures
  def update_shared(self, agent, last_action=None, last_action_result=None):
    log = agent._log
    
    if not self._updated_shared and not self._is_active:
      self._updated_shared = True
      # update dist_cache
      update_cache_data(log, agent, self._cache_key, self._cache_value, self._steps)
      # update goto stats
      update_goto_stats(log, self._cache_categ, self._steps, self._action_steps)
      # if in shop, update shop_inventory
      #update_fac_data(agent, self._agent_name, self._fac_data)
      # update fac_goto
      remove_fac_goto(self._agent_name, self._fac_id)
      # update explore agents
      remove_explore(self._agent_name)
  
  def on_action_clear(self, agent):
    log = agent._log
    
    log.log(LOG_OP, lambda: "CHECK-INFO:   op_goto, clear")
    # update fac_goto
    remove_fac_goto(self._agent_name, self._fac_id)
    # update explore agents
    remove_explore(self._agent_name)
  
  def on_action_failed(self, agent, this_seq):
    log = agent._log
    
    #remove_fac_goto(self._agent_name, self._fac_id)
    #remove_explore(self._agent_name)
    
    # skip actions until goto to non charging station
    action = None
    while True:
      action = this_seq.action()
      if not action:
        break
      if action._type == "goto":
        fac_type = agent.view.facilities.get(action._fac_id).facility_type
        if fac_type != "chargingStation":
          break
      this_seq.next_action()
    if action:
      log.log(LOG_OP, lambda: "CHECK-INFO:   op_goto, recover skipped to action: {}".format(action))
    
    # schedule recharge, goto to nearest charging station, goto to final destination
    new_seq = []
    single_recharge_goto(log, agent, action._fac_id, new_seq, self._job_id)
    
    # append rest of actions
    while True:
      action = this_seq.next_action()
      if not action:
        break
      new_seq.append(action)
    
    log.log(LOG_OP, lambda: "CHECK-INFO:   op_goto, recover final op = [ {} ]".format(one_line_key(new_seq)))
    
    return new_seq
  
  # returns list of actions to do in case of drop of current action
  # it is called with different agent than the op agent and must use only object data
  # and can use only data provided by __init__, send_action may have not run (next action in action_seq)
  def on_action_drop(self, agent):
    # update fac_goto
    remove_fac_goto(self._agent_name, self._fac_id)
    # update explore agents
    remove_explore(self._agent_name)
    # just abort
    if self._is_active:
      action = op_abort(self._agent_name, 1)
      ###action._start_step = agent._step
      return [action]



# skip direct
def skip(agent):
  percept_id = agent.view.id
  agent._comm.send_action(percept_id, "skip")

# skip action
# used to fill step slots in move(s)
class op_skip(Action):
  def __init__(self, agent_name, steps, **args):
    super().__init__("skip", agent_name, steps, **args)
    self._repr = "{:s} abort".format(self._agent_name)
  
  # only send_action() can access data of all agent(s) (as they have been updated before call)
  def send_action(self, agent):
    log = agent._log
    
    if self._is_active:
      log.log(LOG_OP, lambda: "CHECK-ERR:   op_skip.send_action() called more than once !!!")
      skip(agent)
      return
    self._start_step = agent._step
    percept_id = agent.view.id
    agent._comm.send_action(percept_id, "skip")
    self._is_active = True



# affected by blackouts, get failure code, need retry
# **args: _fac_id, _job_id (can be "")
class op_charge(Action):
  def __init__(self, agent_name, steps, **args):
    super().__init__("charge", agent_name, steps, **args)
    self._last_charge = 0
    self._new_charge = 0
    self._battery_capacity = 0
    self._repr = "{:s} ({:s}) charge ({:d} steps){:s}".format(
      self._agent_name, self._fac_id, self._steps,
      " "+self._job_id if self._job_id else ""
    )
  
  # only send_action() can access data of all agent(s) (as they have been updated before call)
  def send_action(self, agent):
    log = agent._log
    
    #if self._is_active:
    #  log.log(LOG_OP, lambda: "CHECK-ERR:   op_charge.send_action() called more than once !!!")
    #  return
    a_role = agent.sim.role
    agent_view = agent.view
    a_self = agent_view.self
    facility = a_self.facility
    fac_data = agent_view.facilities.get(facility, None)
    if fac_data and fac_data.facility_type == "chargingStation" and facility == self._fac_id:
      self._battery_capacity = int(a_role.battery)
      self._last_charge = int(a_self.charge)
      #self._start_step = agent._step
      if self._start_step < 0:
        self._start_step = agent._step
      percept_id = agent.view.id
      agent._comm.send_action(percept_id, "charge")
      self._is_active = True
    else:
      log.log(LOG_OP, lambda: "CHECK-ERR:   op_charge, not in charging station {:s}".format(self._fac_id))
      self._is_active = False
      self._failed = True
      self._failed_msg = "NOT IN CHARGING STATION {:s}".format(self._fac_id)
      skip(agent)
  
  def is_continuous(self, agent):
    return True
  
  def is_active(self, agent, percept_action=None, percept_action_result=None):
    log = agent._log
    step = agent._step
    
    if not self._is_active:
      return False
    a_self = agent.view.self
    new_charge = int(a_self.charge)
    self._new_charge = new_charge
    if new_charge == self._battery_capacity:
      self._is_active = False
      action_steps = agent._step - self._start_step
      log.log(LOG_OP, lambda: "{:d}, op_charge, completed in {:d} steps (estimated = {:d})".format(step, action_steps, self._steps))
    return self._is_active
  
  # action_result indicates temporary failure (e.g. blackout)
  def is_temp_failed(self, agent, action_result):
    if action_result == "failed_facility_state":
      return True
    else:
      return False
  
  # only update_shared() can update team data structures
  def update_shared(self, agent, last_action=None, last_action_result=None):
    log = agent._log
    
    self._last_charge = self._new_charge
  
  # returns list of actions to do in case of drop of current action
  # it is called with different agent than the op agent and must use only object data
  # and can use only data provided by __init__, send_action may have not run (next action in action_seq)
  # replace with single active charge
  def on_action_drop(self, agent):
    action = op_charge(self._agent_name, self._steps, _fac_id=self._fac_id, _job_id="[DROP]")
    ###action._battery_capacity = self._battery_capacity
    ###action._last_charge = self._last_charge
    ###action._start_step = agent._step
    ###action._is_active = True
    return [action]



# **args: _charge_target, _job_id (can be "")
class op_recharge(Action):
  def __init__(self, agent_name, steps, **args):
    super().__init__("recharge", agent_name, steps, **args)
    self._last_charge = 0
    self._new_charge = 0
    self._battery_capacity = 0
    self._repr = "{:s} recharge to {:d} ({:d} steps){:s}".format(
      self._agent_name, self._charge_target, self._steps,
      " "+self._job_id if self._job_id else ""
    )
  
  # only send_action() can access data of all agent(s) (as they have been updated before call)
  def send_action(self, agent):
    log = agent._log
    
    #if self._is_active:
    #  log.log(LOG_OP, lambda: "CHECK-ERR:   op_recharge.send_action() called more than once !!!")
    #  return
    a_role = agent.sim.role
    a_self = agent.view.self
    self._battery_capacity = int(a_role.battery)
    self._last_charge = int(a_self.charge)
    if self._start_step < 0:
      self._start_step = agent._step
    percept_id = agent.view.id
    agent._comm.send_action(percept_id, "recharge")
    self._is_active = True
  
  def is_continuous(self, agent):
    return True
  
  def is_active(self, agent, percept_action=None, percept_action_result=None):
    log = agent._log
    step = agent._step
    
    if not self._is_active:
      return False
    a_self = agent.view.self
    new_charge = int(a_self.charge)
    self._new_charge = new_charge
    if new_charge >= min(self._charge_target, self._battery_capacity):
      self._is_active = False
      action_steps = agent._step - self._start_step
      log.log(LOG_OP, lambda: "{:d}, op_recharge, completed in {:d} steps (estimated = {:d})".format(step, action_steps, self._steps))
    return self._is_active
  
  # only update_shared() can update team data structures
  def update_shared(self, agent, last_action=None, last_action_result=None):
    log = agent._log
    
    self._last_charge = self._new_charge
  
  # returns list of actions to do in case of drop of current action
  # it is called with different agent than the op agent and must use only object data
  # and can use only data provided by __init__, send_action may have not run (next action in action_seq)
  # replace with single active recharge
  def on_action_drop(self, agent):
    action = op_recharge(self._agent_name, self._steps, _charge_target=self._charge_target, _job_id="[DROP]")
    ###action._battery_capacity = self._battery_capacity
    ###action._last_charge = self._last_charge
    ###action._start_step = agent._step
    ###action._is_active = True
    return [action]



# abort action
class op_abort(Action):
  def __init__(self, agent_name, steps, **args):
    super().__init__("abort", agent_name, steps, **args)
    self._repr = "{:s} abort".format(self._agent_name)
  
  # only send_action() can access data of all agent(s) (as they have been updated before call)
  def send_action(self, agent):
    log = agent._log
    
    if self._is_active:
      log.log(LOG_OP, lambda: "CHECK-ERR:   op_abort.send_action() called more than once !!!")
      skip(agent)
      return
    self._start_step = agent._step
    percept_id = agent.view.id
    agent._comm.send_action(percept_id, "abort")
    self._is_active = True



# NOTE !!! after failure to buy will not proceed to assemble/deliver because entire action sequence is aborted !!!
# this is the desired behavior
# **args: _item_name, _item_amount, _fac_id, _job_id, _explore_tag
class op_buy(Action):
  def __init__(self, agent_name, steps, **args):
    super().__init__("buy", agent_name, steps, **args)
    self._price = 0
    self._repr = "{:s} ({:s}) buy: {:s},{:d} => {:s}".format(
      self._agent_name, self._fac_id, self._item_name, self._item_amount, self._job_id
    )
  
  # only send_action() can access data of all agent(s) (as they have been updated before call)
  def send_action(self, agent):
    log = agent._log
    
    if self._is_active:
      log.log(LOG_OP, lambda: "CHECK-ERR:   op_buy.send_action() called more than once !!!")
      skip(agent)
      return
    if self._item_amount <= 0:
      log.log(LOG_OP, lambda: "CHECK-ERR:   op_buy, with zero or negative amount {:s},{:d}".format(self._item_name, self._item_amount))
      self._is_active = False
      self._failed = True
      self._failed_msg = "NO AMOUNT {:s},{:d}".format(self._item_name, self._item_amount)
      skip(agent)
      return
    item_name = self._item_name
    agent_view = agent.view
    a_self = agent_view.self
    facility = a_self.facility
    fac_data = agent_view.facilities.get(facility, None)
    # a bit superfluous as buy commands are given only when inside shop !
    if fac_data and fac_data.facility_type == "shop" and facility == self._fac_id:
      fac_items = fac_data.item
      if item_name in fac_items and int(fac_items[item_name].amount) >= self._item_amount:
        self._price = int(fac_items[item_name].price)
        self._start_step = agent._step
        percept_id = agent.view.id
        agent._comm.send_action(percept_id, "buy", OrderedDict([("item", self._item_name), ("amount", str(self._item_amount))]))
        self._is_active = True
      else:
        log.log(LOG_OP, lambda: "CHECK-ERR:   op_buy, no item or not enough amount {:s},{:d}".format(self._item_name, self._item_amount))
        self._is_active = False
        self._failed = True
        self._failed_msg = "NO ITEM {:s},{:d}".format(self._item_name, self._item_amount)
        skip(agent)
    else:
      log.log(LOG_OP, lambda: "CHECK-ERR:   op_buy, not in shop {:s}".format(self._fac_id))
      self._is_active = False
      self._failed = True
      self._failed_msg = "NOT IN SHOP {:s}".format(self._fac_id)
      skip(agent)
  
  # only update_shared() can update team data structures
  def update_shared(self, agent, last_action=None, last_action_result=None):
    log = agent._log
    
    if not self._updated_shared:
      self._updated_shared = True
      buy_cost = self._item_amount * self._price
      update_buy_cost(agent,
        buy_cost, self._item_name, self._item_amount, self._fac_id,
        self._job_id, self._explore_tag
      )



# suprefluous need for fail checks (inside correct storage, since system should check and previous goto will have checked too)
# **args: _job_id, _fac_id
class op_deliver_job(Action):
  def __init__(self, agent_name, steps, **args):
    super().__init__("deliver_job", agent_name, steps, **args)
    self._self_items = None
    self._repr = "{:s} ({:s}) deliver_job => {:s}".format(self._agent_name, self._fac_id, self._job_id)
  
  # only send_action() can access data of all agent(s) (as they have been updated before call)
  def send_action(self, agent):
    log = agent._log
    
    if self._is_active:
      log.log(LOG_OP, lambda: "CHECK-ERR:   op_deliver_job.send_action() called more than once !!!")
      skip(agent)
      return
    agent_view = agent.view
    a_self = agent_view.self
    facility = a_self.facility
    fac_data = agent_view.facilities.get(facility, None)
    if fac_data and fac_data.facility_type == "storage" and facility == self._fac_id:
      self._self_items = a_self.self_items
      self._start_step = agent._step
      percept_id = agent.view.id
      agent._comm.send_action(percept_id, "deliver_job", OrderedDict([("job", self._job_id)]))
      self._is_active = True
    else:
      log.log(LOG_OP, lambda: "CHECK-ERR:   op_deliver_job, not in storage {:s}".format(self._fac_id))
      self._is_active = False
      self._failed = True
      self._failed_msg = "NOT IN STORAGE {:s}".format(self._fac_id)
      skip(agent)
  
  # only update_shared() can update team data structures
  def update_shared(self, agent, last_action=None, last_action_result=None):
    log = agent._log
    step = agent._step
    
    if not self._updated_shared:
      self._updated_shared = True
      job_id = self._job_id
      post_items = agent.view.self.self_items
      delivered = job_update_delivered(agent, job_id, self._self_items, post_items)
      ###
      ### handle various result situations and try to do best action
      ###
      #if delivered and (last_action_result and last_action_result != "successful"):
      #  log.error(lambda: "CHECK-ERR:   op_deliver_job, job {:s} completed vs. system NOT COMPLETED !!!".format(job_id))
      #  delivered = False
      #if not delivered and (last_action_result and last_action_result == "successful"):
      #  log.error(lambda: "CHECK-ERR:   op_deliver_job, job {:s} not completed vs. system COMPLETED !!!".format(job_id))
      #  delivered = True
      #if last_action_result and last_action_result == "useless":
      #  log.error(lambda: "CHECK-ERR:   op_deliver_job, system says nothing delivered !!!".format(job_id))
      if last_action == "deliver_job" and last_action_result == "successful":
        delivered = True
      ###
      if delivered:
        log.info(lambda: "{:d}, op_deliver_job,   SPEC {:s} completed YAIII !!!".format(step, job_id))
        # complete/QoS info and job stats
        job_set_completed(agent, job_id)
      elif last_action_result == "failed_job_status":
        log.info(lambda: "{:d}, op_deliver_job,   SPEC {:s} failed sigh... !!!".format(step, job_id))
        # complete/QoS info and job stats
        job_set_removed(agent, job_id)



# **args: _job_spec (must be OrderedDict now conforming to parameter order for post_job)
# reward:, steps:, :storage,   item:, amount: ...
class op_post_job(Action):
  def __init__(self, agent_name, steps, **args):
    super().__init__("post_job", agent_name, steps, **args)
    reward = self._job_spec["reward"]
    a_steps = self._job_spec["steps"]
    storage = self._job_spec["storage"]
    self._repr = "{:s} post_job {:s} in {:s} to {:s}".format(self._agent_name, reward, a_steps, storage)
  
  # only send_action() can access data of all agent(s) (as they have been updated before call)
  def send_action(self, agent):
    log = agent._log
    
    if self._is_active:
      log.log(LOG_OP, lambda: "CHECK-ERR:   op_post_job.send_action() called more than once !!!")
      skip(agent)
      return
    self._start_step = agent._step
    percept_id = agent.view.id
    # reward, duration, storage, item1, amount1, ...
    agent._comm.send_action(percept_id, "post_job", self._job_spec)
    self._is_active = True



# sends either assemble or assist_assemble
# need to synchronize, will repeat idling until all agents gather together
# this way can handle job_op(s) with goto workshop and then assemble actions
# **args: _job_id, _fac_id, _item_name, _party, _assembler, _seq_fin=False
class op_assemble(Action):
  def __init__(self, agent_name, steps, **args):
    super().__init__("assemble", agent_name, steps, **args)
    self._self_items = None
    self._repr = "{:s} ({:s}) assemble ({:s}; {}) => {:s} {:s}{:s}".format(
      self._agent_name, self._fac_id, self._assembler, one_line_key_s(self._party), self._item_name,
      self._job_id, " fin" if self._seq_fin else ""
    )
    self._action_sent = False
  
  # only send_action() can access data of all agent(s) (as they have been updated before call)
  def send_action(self, agent):
    log = agent._log
    
    #if self._is_active:
    #  log.log(LOG_OP, lambda: "CHECK-ERR:   op_assemble.send_action() called more than once !!!")
    #  return
    agent_view = agent.view
    a_self = agent_view.self
    facility = a_self.facility
    fac_data = agent_view.facilities.get(facility, None)
    if fac_data and fac_data.facility_type == "workshop" and facility == self._fac_id:
      if party_gathered(agent, self._party) == self._fac_id:
        self._self_items = a_self.self_items
        self._action_sent = True
        self._start_step = agent._step
        percept_id = agent.view.id
        if self._assembler == self._agent_name:
          agent._comm.send_action(percept_id, "assemble", OrderedDict([("item_name", self._item_name)]))
        else:
          agent._comm.send_action(percept_id, "assist_assemble", OrderedDict([("assembler", self._assembler)]))
      else:
        skip(agent)
      self._is_active = True
    else:
      log.log(LOG_OP, lambda: "CHECK-ERR:   op_assemble, not in workshop {:s}".format(self._fac_id))
      self._is_active = False
      self._failed = True
      self._failed_msg = "NOT IN WORKSHOP {:s}".format(self._fac_id)
      skip(agent)
  
  # make possible to send_action once again; on failed_random
  def reset(self, agent):
    self._reset_count += 1
    self._is_active = False
  
  # is continuous so send_action() is called repeatedly
  def is_continuous(self, agent):
    return True
  
  def is_active(self, agent, percept_action=None, percept_action_result=None):
    log = agent._log
    
    if not self._is_active:
      return False
    # no need to check percept_action_result
    if percept_action in ["assemble", "assist_assemble"]:
      self._is_active = False
    return self._is_active
  
  # only update_shared() can update team data structures
  def update_shared(self, agent, last_action=None, last_action_result=None):
    log = agent._log
    step = agent._step
    
    if not self._updated_shared and self._action_sent:
      self._updated_shared = True
      # could check that assembled item has been produced; leave check to system
      #post_items = agent.view.self.self_items
      ###
      ### handle various result situations and try to do best action
      ###
      job_id = self._job_id
      job_assembled = job_update_assembled(agent, job_id, self._item_name)
      #if (job_assembled and not self._seq_fin) or (not job_assembled and self._seq_fin):
      #  log.log(LOG_OP, lambda: "CHECK-ERR:   op_assemble, job {:s} inconsistency assemble_count vs seq_fin !!!".format(job_id))
      # _seq_fin is reliable
      if self._seq_fin:
        log.info(lambda: "{:d}, op_assemble,   SPEC {:s} assembled YAIII !!!".format(step, job_id))
        job_set_assembled(agent, job_id)



# agents will be gathered together (in workshop usually) and so no need to synchronize
# **args: _fac_id, _giver, _receiver, _item_name, _item_amount, _slot, _seq_fin=False
class op_give(Action):
  def __init__(self, agent_name, steps, **args):
    super().__init__("give", agent_name, steps, **args)
    self._repr = "{:s} ({:s}) give {:s},{:d} => {:s} {:s}{:s}".format(
      self._agent_name, self._fac_id, self._item_name, self._item_amount, self._receiver,
      self._job_id, " fin" if self._seq_fin else ""
    )
    self._action_sent = False
  
  # only send_action() can access data of all agent(s) (as they have been updated before call)
  def send_action(self, agent):
    log = agent._log
    
    if self._is_active:
      log.log(LOG_OP, lambda: "CHECK-ERR:   op_give.send_action() called more than once !!!")
      skip(agent)
      return
    agent_view = agent.view
    a_self = agent_view.self
    facility = a_self.facility
    fac_data = agent_view.facilities.get(facility, None)
    if fac_data and facility == self._fac_id:
      shared = agent._shared
      receiver_shared = shared[self._receiver]
      if receiver_shared.view.self.facility == self._fac_id:
        self._action_sent = True
        self._start_step = agent._step
        percept_id = agent.view.id
        agent._comm.send_action(percept_id, "give", OrderedDict([
          ("agent", self._receiver), ("item_name", self._item_name), ("item_amount", str(self._item_amount))
        ]))
        self._is_active = True
      else:
        log.log(LOG_OP, lambda: "CHECK-ERR:   op_give, no agent to receive {:s}".format(self._receiver))
        self._is_active = False
        self._failed = True
        self._failed_msg = "NO AGENT"
        skip(agent)
    else:
      log.log(LOG_OP, lambda: "CHECK-ERR:   op_give, not in {:s}".format(self._fac_id))
      self._is_active = False
      self._failed = True
      self._failed_msg = "NOT IN FACILITY"
      skip(agent)
  
  # make possible to send_action once again; on failed_random
  def reset(self, agent):
    self._reset_count += 1
    self._is_active = False
  
  # only update_shared() can update team data structures
  def update_shared(self, agent, last_action=None, last_action_result=None):
    log = agent._log
    step = agent._step
    
    if not self._updated_shared and self._action_sent:
      self._updated_shared = True
      ###
      ### handle various result situations and try to do best action
      ###
      job_id = self._job_id
      slots_completed = self._slot == team.job_move_slots[job_id]
      if (slots_completed and not self._seq_fin) or (not slots_completed and self._seq_fin):
        llog.log(LOG_OP, lambda: "CHECK-ERR:   op_give, job {:s} inconsistency slot number vs seq_fin !!!".format(job_id))
      move_completed = job_update_move(agent, job_id)
      if (move_completed and not self._seq_fin) or (not move_completed and self._seq_fin):
        log.log(LOG_OP, lambda: "CHECK-ERR:   op_give, job {:s} inconsistency move_count vs seq_fin !!!".format(job_id))
      # _seq_fin is reliable?
      if self._seq_fin:
        job_id = self._job_id
        log.info(lambda: "{:d}, op_give,   SPEC {:s} move completed YAIII !!!".format(step, job_id))
        job_set_move_completed(agent, job_id)



# agents will be gathered together (in workshop usually) and so no need to synchronize
# **args: _fac_id, _giver, _receiver, _slot, _seq_fin=False
class op_receive(Action):
  def __init__(self, agent_name, steps, **args):
    super().__init__("receive", agent_name, steps, **args)
    self._repr = "{:s} ({:s}) receive (from {:s}) {:s}{:s}".format(
      self._agent_name, self._fac_id, self._giver,
      self._job_id, " fin" if self._seq_fin else ""
    )
    self._action_sent = False
  
  # only send_action() can access data of all agent(s) (as they have been updated before call)
  def send_action(self, agent):
    log = agent._log
    
    if self._is_active:
      log.log(LOG_OP, lambda: "CHECK-ERR:   op_receive.send_action() called more than once !!!")
      skip(agent)
      return
    agent_view = agent.view
    a_self = agent_view.self
    facility = a_self.facility
    fac_data = agent_view.facilities.get(facility, None)
    if fac_data and facility == self._fac_id:
      shared = agent._shared
      giver_shared = shared[self._giver]
      if giver_shared.view.self.facility == self._fac_id:
        self._action_sent = True
        self._start_step = agent._step
        percept_id = agent.view.id
        agent._comm.send_action(percept_id, "receive")
        self._is_active = True
      else:
        log.log(LOG_OP, lambda: "CHECK-ERR:   op_receive, no agent to give {:s}".format(self._giver))
        self._is_active = False
        self._failed = True
        self._failed_msg = "NO AGENT {:s}".format(self._receiver)
        skip(agent)
    else:
      log.log(LOG_OP, lambda: "CHECK-ERR:   op_receive, not in {:s}".format(self._fac_id))
      self._is_active = False
      self._failed = True
      self._failed_msg = "NOT IN FACILITY {:s}".format(self._fac_id)
      skip(agent)
  
  # make possible to send_action once again; on failed_random
  def reset(self, agent):
    self._reset_count += 1
    self._is_active = False
  
  # only update_shared() can update team data structures
  def update_shared(self, agent, last_action=None, last_action_result=None):
    log = agent._log
    step = agent._step
    
    if not self._updated_shared and self._action_sent:
      self._updated_shared = True
      ###
      ### handle various result situations and try to do best action
      ###
      job_id = self._job_id
      slots_completed = self._slot == team.job_move_slots[job_id]
      if (slots_completed and not self._seq_fin) or (not slots_completed and self._seq_fin):
        log.log(LOG_OP, lambda: "CHECK-ERR:   op_receive, job {:s} inconsistency slot number vs seq_fin !!!".format(job_id))
      move_completed = job_update_move(agent, job_id)
      if (move_completed and not self._seq_fin) or (not move_completed and self._seq_fin):
        log.log(LOG_OP, lambda: "CHECK-ERR:   op_receive, job {:s} inconsistency move_count vs seq_fin !!!".format(job_id))
      # _seq_fin is reliable?
      if self._seq_fin:
        job_id = self._job_id
        log.info(lambda: "{:d}, op_receive,   SPEC {:s} move completed YAIII !!!".format(step, job_id))
        job_set_move_completed(agent, job_id)



# suprefluous need for fail checks (inside correct storage, since system should check and previous goto will have checked too)
# **args: _fac_id, _item_name, _item_amount, _job_id
class op_retrieve_delivered(Action):
  def __init__(self, agent_name, steps, **args):
    super().__init__("retrieve_delivered", agent_name, steps, **args)
    self._self_items = None
    self._repr = "{:s} ({:s}) retrieve_delivered => {:s},{:d} {:s}".format(
      self._agent_name, self._fac_id, self._item_name, self._item_amount, self._job_id
    )
  
  # only send_action() can access data of all agent(s) (as they have been updated before call)
  def send_action(self, agent):
    log = agent._log
    
    if self._is_active:
      log.log(LOG_OP, lambda: "CHECK-ERR:   op_retrieve_delivered.send_action() called more than once !!!")
      skip(agent)
      return
    agent_view = agent.view
    a_self = agent_view.self
    facility = a_self.facility
    fac_data = agent_view.facilities.get(facility, None)
    if fac_data and fac_data.facility_type == "storage" and facility == self._fac_id:
      self._self_items = a_self.self_items
      self._start_step = agent._step
      percept_id = agent.view.id
      agent._comm.send_action(percept_id, "retrieve_delivered", OrderedDict([("item", self._item_name), ("amount", str(self._item_amount))]))
      self._is_active = True
    else:
      log.log(LOG_OP, lambda: "CHECK-ERR:   op_retrieve_delivered, not in storage {:s}".format(self._fac_id))
      self._is_active = False
      self._failed = True
      self._failed_msg = "NOT IN STORAGE {:s}".format(self._fac_id)
      skip(agent)
  
  # only update_shared() can update team data structures
  def update_shared(self, agent, last_action=None, last_action_result=None):
    log = agent._log
    step = agent._step
    
    if not self._updated_shared:
      self._updated_shared = True
    log.info(lambda: "{:d}, op_retrieve_delivered,   retrieve completed YAIII !!!".format(step))
    # update retrieve_delivered agents
    remove_retrieve_delivered(self._agent_name)
  
  def on_action_clear(self, agent):
    log = agent._log
    
    log.log(LOG_OP, lambda: "CHECK-INFO:   op_retrieve_delivered, clear")
    # update retrieve_delivered agents
    remove_retrieve_delivered(self._agent_name)
  
  def on_action_failed(self, agent, this_seq):
    # update retrieve_delivered agents
    remove_retrieve_delivered(self._agent_name)
    return None
  
  # returns list of actions to do in case of drop of current action
  # it is called with different agent than the op agent and must use only object data
  # and can use only data provided by __init__, send_action may have not run (next action in action_seq)
  def on_action_drop(self, agent):
    # update retrieve_delivered agents
    remove_retrieve_delivered(self._agent_name)
    return None