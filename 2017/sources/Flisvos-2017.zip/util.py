
"""

 /*
  * @(#) E.Sarmas   util.py 0.9_63 (2017-09-18)
  *
  * Author: E.Sarmas
  *
  * Created: 2017-04-06
  *
  * Description: Flisvos 2017 (MAPC 2017)
  *
  * Version: 0.9_63
  * Version-Date: 2017-09-18
  *
  * Version-Log:
  *   0.1_0 (2017-04-06)   copy from Flisvos-2016
  *   0.1_9 (2017-05-29)   rewrite so stable core and fewer changes per scenario/implementation
  *   0.6_0 (2017-06-01)   refactoring, new sim messages/info (except distance calcs), running
  *                        fewer import dependency chains, code moved to more appropriate modules
  *                        logging messages with lambda: now, may speed up logging
  *                        single method to recursively decode messages
  *                        log_data moved within attr_dict as instance method
  *                        clear agent action handling/protocol and procedures/statistics/logging level use
  *                        removed items_db, jobs_spec moved in team
  *                        simple class method like procedures for data updates within appropriate module
  *                        clearer procedure interrelationships, existence and use
  *                        cache improvement to be useful for all roles
  *                        cleaner use of JOB_STEPS_FAC so no double use and wrong results
  *                        clearer method use protocol and use of other procedures for data updates
  *                        agents_with_item_on_board and agents_with_item_buy removed and embedded
  *                        introduced deliver_jobs and explore_buys
  *                        jobs_selection does not select but returns base recipe for all not ignored jobs
  *                        new_jobs now setups assembly or marks for delivery already assembled job
  *                        deliver_jobs may arrange first moves (give and take) to fewer and faster agents
  *   0.9_50 (2017-09-03)  qualification run, new_jobs/deliver_jobs/explore_buys disabled
  *   0.9_52 (2017-09-05)  added EXERCIZE_MODE as in qualification to test goto/charge/recharge system
  *                        ability to recover a job_op, for op_goto to recover from battery stalls by
  *                        recharging enough steps for next charging station and then going to destination
  *                        new dist_cache_history, random fail steps not counted
  *                        lowered level of all goto steps calculations
  *                        random fails don't stop op_goto(s) (bad interaction of reset/send_action )
  *                        also handled correctly if happen on first step of action
  *                        fixed job_op drop and job_drop confusion
  *                        new job_data[], SPEC tracks missions and removes fine from money
  *                        better handling of actions that indicate errors (ACTION_ERRORS)
  *                        new action retrieve_delivered and procedure retrieve_delivered in plan
  *                        new dict job_failed, and sets failed_jobs, just_failed_jobs
  *                        clearer actions for job_set_completed and job_set_failed (new), update_jobs_spec
  *                        reassigned role of job_db, new dict job_party
  *                        new procedures single_recharge and single_recharge_goto for faster recharge
  *                        creat can be called with agent in charging_station in future (with charge_level)
  *                        explore_jobs works without jobs and uses tool compatibility
  *                        along with mission and priced job needs in a useful order
  *                        refactored explore_jobs setup merging all loops, and removed shop_estimate
  *                        organized job work in phases (assembly, move, delivery)
  *                        move phase orchestrates give->receive to fewer better fit agents to deliver_jobs
  *                        and works like cpu instruction scheduling filling empty slots when needed
  *                        jobs_selection finally embedded within explore_jobs
  *                        explore_jobs considers better the suitability of each shop to finish jobs
  *                        and considers agent tool_compatibility better, and also global tool cover
  *                        socket timeout to 20 sec, never low value
  *                        enhanced strategy for CHECK-ERR asserts and other CHECK-... almost everywhere
  *                        is the fastest way to verify coverage and correct operation
  *                        changed logging levels everywhere so comfortable view of logging output
  *                        new failed action recovery logic, improved recover and drop functions 
  *                        checked all actions to send an action to server
  *                        new action.has_next() and use of next_action() only after barrier
  *                        so job_drop() works correctly with current action inside barrier
  *                        strange float calcs fixed (FLOAT_EP)
  *                        new job_state_check and actions_state_check, set jobs to drop (just_failed_jobs)
  *                        disabled move operations (give->receive to fewer and faster agents)
  *                        because not so important and code not tested well for crashes and more...
  *                        explore_buys only if no concurrent buy in same shop and only for items
  *   0.9_63 (2017-09-18)  good luck :) 
  */

"""



import collections
#import math
import sys
import time
import re
#import logging
import configparser

#import util
import main



# DETAIL < DEBUG <   OP < INFO   < WARNING+
# agent log file =   LOG_DEBUG or LOG_DETAIL (verbose)
# main  log file =   LOG_OP
# console        =   LOG_INFO

LOG_INFO = 20
LOG_OP = 19
LOG_DEBUG = 10
LOG_DETAIL = 9



modules = sys.modules

defaultdict = collections.defaultdict
Counter = collections.Counter

# all following tuples must be sortable (so can contain only int or str etc. objects)

Duo = collections.namedtuple('Duo', 'value key')
Hexa = collections.namedtuple('Hexa', 'value_sort value0 value1 value2 value_all key')
#Hepta = collections.namedtuple('Hepta', 'value0 value1 value2 value3 value_sort0 value_sort1 key')

# amount first so natural sort by amount if needed
Item_Entry = collections.namedtuple('Item_Entry', 'amount name')

# sort1,2 first new priorities # cost not so wild differences; #amount first so natural sort by amount if needed
#Agent_Item_Sort = collections.namedtuple('Agent_Item_Sort', 'sort1 sort2 price amount name agent_name')
#Agent_Item = collections.namedtuple('Agent_Item', 'price amount name agent_name')



"""

# Python 3.5

dictclass = collections.OrderedDict

class attr_dict(dictclass):
  #def __init__(self, *args, **kwargs):
  #  super().__init__(*args, **kwargs)
  
  __getattribute__ = dictclass.__getitem__
  __setattribute__ = dictclass.__setitem__

"""

# Python 3.4, 3.5

dictclass = collections.OrderedDict

class attr_dict(collections.abc.MutableMapping):
  
  def __init__(self, *args, **kwargs):
    super().__setattr__("_data", dictclass(*args, **kwargs))
  
  def __getitem__(self, key):
    return super().__getattribute__("_data")[key]
  
  def __setitem__(self, key, value):
    super().__getattribute__("_data")[key] = value
  
  def __delitem__(self, key):
    del super().__getattribute__("_data")[key]
  
  def __iter__(self):
    return iter(super().__getattribute__("_data"))
  
  def __len__(self):
    return len(super().__getattribute__("_data"))
  
  def __contains__(self, key):
    return dictclass.__contains__(super().__getattribute__("_data"), key)
  
  def items(self):
    return super().__getattribute__("_data").items()
  
  def keys(self):
    return super().__getattribute__("_data").keys()
  
  def values(self):
    return super().__getattribute__("_data").values()
  
  def __str__(self):
    return str(super().__getattribute__("_data"))
  
  def __repr__(self):
    return repr(super().__getattribute__("_data"))
  
  __getattr__ = __getitem__
  __setattr__ = __setitem__
  
  def log_data(self, log, log_level = LOG_DEBUG, exclude_list = None):
    data = self
    #log.log(log_level, lambda: "log_data(): {}".format(data))
    log.log(log_level, lambda: "=== log_data() ===")
    level = 0
    buf = ["\n"]
    attr_dict.log_tree(data, level, buf, exclude_list)
    log.log(log_level, lambda: "\n".join(buf))
  
  @staticmethod
  def log_tree(data, level, buf, exclude_list = None):
    #log = self._log
    for key, value in data.items():
      if exclude_list and key in exclude_list:
        continue
      if isinstance(value, str):
        #log.debug("{:s}{:s} = {:s}".format("  " * level, key, value))
        buf.append("{:s}{:s} = {:s}".format("  " * level, key, value))
      elif isinstance(value, int):
        #log.debug("{:s}{:s} = {:d}".format("  " * level, key, value))
        buf.append("{:s}{:s} = {:d}".format("  " * level, key, value))
      elif isinstance(value, list):
        if len(value) > 0 and isinstance(value[0], Duo):
          buf.append("{:s}{:s} = {:s}".format("  " * level, key, one_line_duo(value)))
        else:
          buf.append("{:s}{:s} = {:s}".format("  " * level, key, one_line_key(value)))
      elif isinstance(value, set):
        buf.append("{:s}{:s} = {:s}".format("  " * level, key, one_line_key_s(value)))
      elif isinstance(value, Counter):
        buf.append("{:s}{:s} = {:s}".format("  " * level, key, one_line_key_val_s(value)))
      elif isinstance(value, attr_dict) or isinstance(value, OrderedDict) or isinstance(value, dict):
        #if len(value) > 0:
          #log.debug("{:s}{:s} =".format("  " * level, key))
          buf.append("{:s}{:s} =".format("  " * level, key))
          #for x in value:
            #log.debug("{:s}{:s}".format("  " * (level + 1), "---------------------"))
            #buf.append("{:s}{:s}".format("  " * (level + 1), "---------------------"))
          #  buf.append("{:s}{:s}".format("  " * (level + 1), "-"))
          #  self.log_tree(x, level + 1, buf)
          ###buf.append("{:s}{:s}".format("  " * (level + 1), "-"))
          attr_dict.log_tree(value, level + 1, buf)
          #log.debug("{:s}{:s}".format("  " * (level + 1), "---------------------"))
          #buf.append("{:s}{:s}".format("  " * (level + 1), "---------------------"))
          ###buf.append("{:s}{:s}".format("  " * (level + 1), "-"))
        #else:
        #  #log.debug("{:s}{:s}".format("  " * level, key))
        #  buf.append("{:s}{:s}".format("  " * level, key))
        #  self.log_tree(value, level + 1, buf)



perf_time = time.perf_counter

class LapTimer():
  """
  marks time stops and prints laps
  """
  
  def __init__(self, log, desc="", log_level=LOG_DEBUG):
    """
    initial time stop, optional description of timer
    """
    self.last_time = 0
    self.sub_time = 0
    self._log = log
    self._default_log_level=log_level
  
  def lap_start(self):
    self.last_time = perf_time()
  
  def lap(self, desc="", log_level=None):
    """
    print lap to stdout (and flush) from previous stop and mark new stop
    optional lap description to print
    """
    if not log_level:
      log_level = self._default_log_level
    ela = 0
    new_time = perf_time()
    if self.last_time != 0:
      ela = new_time - self.last_time
      self._log.log(log_level, lambda: "### " + desc + "   elapsed =  {:.3f} s".format(ela))
    self.last_time = new_time
    return ela
  
  def sub_lap(self, desc="", log_level=None):
    """
    print sub_lap to stdout (and flush) from previous stop and mark new stop
    optional lap description to print
    """
    if not log_level:
      log_level = self._default_log_level
    ela = 0
    new_time = perf_time()
    if self.sub_time < self.last_time:
      self.sub_time = self.last_time
    if self.sub_time != 0:
      ela = new_time - self.sub_time
      self._log.log(log_level, lambda: "###... " + desc + "   elapsed =  {:.3f} s".format(ela))
    self.sub_time = new_time
    return ela



# wrapper around standard log
# uses lambda functions to avoid expensive calculations
# some speed lost with function calls but is easier change in code
class Smart_Log():
  
  LOG_CRITICAL = 50
  LOG_ERROR = 40
  LOG_WARNING = 30
  LOG_INFO = 20
  LOG_DEBUG = 10
  LOG_NOTSET = 0
  
  LOG_OP = 19
  LOG_DETAIL = 9
  
  def __init__(self, log):
    self._log = log
    self._log_level = log.getEffectiveLevel()
  
  def log(self, log_level, f):
    if self._log_level <= log_level:
      s = f()
      self._log.log(log_level, s)
  
  def detail(self, f):
    log_level = Smart_Log.LOG_DETAIL
    self.log(log_level, f)
  
  def debug(self, f):
    log_level = Smart_Log.LOG_DEBUG
    self.log(log_level, f)
  
  def info(self, f):
    log_level = Smart_Log.LOG_INFO
    self.log(log_level, f)
  
  def op(self, f):
    log_level = Smart_Log.LOG_OP
    self.log(log_level, f)
  
  def warning(self, f):
    log_level = Smart_Log.LOG_WARNING
    self.log(log_level, f)
  
  def error(self, f):
    log_level = Smart_Log.LOG_ERROR
    self.log(log_level, f)
  
  def critical(self, f):
    log_level = Smart_Log.LOG_CRITICAL
    self.log(log_level, f)
  
  def getEffectiveLevel(self):
    return self._log_level



#RAD_1DEG = 0.017453292519943295 #math.PI/180
#R = 6371
#CELL_LAT = 51.4935 # degrees

MAPS = {
"london": attr_dict(minLon=-0.1978, maxLon=-0.0354, minLat=51.4647, maxLat=51.5223, mapCenterLat=51.4885438, mapCenterLon=-0.1112036),
"hannover": attr_dict(minLon=9.68, maxLon=9.81, minLat=52.33, maxLat=52.39, mapCenterLat=52.362967, mapCenterLon=9.712156),
"sanfrancisco": attr_dict(minLon=-122.495, maxLon=-122.365, minLat=37.695, maxLat=37.795, mapCenterLat=37.73, mapCenterLon=-122.43),
"paris": attr_dict(minLon=-122.495, maxLon=-122.365, minLat=37.695, maxLat=37.795, mapCenterLat=37.73, mapCenterLon=-122.43)
}

"""

0.1624 x 0.0576  4x1  "map" : "london", "minLon" : -0.1978, "maxLon" : -0.0354, "minLat" : 51.4647, "maxLat" : 51.5223
0.15 x 0.08      3x2  "map" : "paris", "minLon" : 2.26, "maxLon" : 2.41, "minLat" : 48.82, "maxLat" : 48.90
0.13 x 0.06      3x1  "map" : "hannover", "minLon" : 9.68, "maxLon" : 9.81, "minLat" : 52.33, "maxLat" : 52.39
0.13 x 0.10      3x2  "map" : "sanfrancisco", "minLon" : -122.495, "maxLon" : -122.365, "minLat" : 37.695, "maxLat" : 37.795

largest dim ~= 0.163 ~= 18.3 km < 20 km per side
max lat < 53 deg
a quad ~= 4450m lat ~= 9x500m, 2700m lon ~= 5x500m (at ~53 deg),  ~ 10-12 steps diagonally

!!! NOTE: really small number of steps to travel, battery lasts longer

"""

# TODO ... review use of parameters that change !!!

# was fraction of 1 degree lat/lon
# now is  length in meters an agent with speed 1 can travel in a single step
#CELL_SIZE = 0.001
CELL_SIZE = 500
QUAD_SIZE = 0.04
# was fraction
# now is #decimals to compare
#PROXIMITY = 0.0002
PROXIMITY = 5
#DIST_ROUTE_FAC = 1.43 # 1.2 - 1.4
DIST_ROUTE_FAC = 1.67

STEP_CHARGE = 10

RECHARGE_RATE = 5
#RECHARGE_MIN_SIM_STEPS = 50

VISIBILITY_RANGE = 500

# response threshold in sec, above which issue warning
STEP_RESPONSE_THRESHOLD = 1.5

# TODO... some limits should depend on map

# general job limits
MAX_CONCURRENT_JOBS = 2 # or 3 ?, ignored for missions, typically #agents / #avg of items in recipe a job
MAX_CONCURRENT_AGENTS = 2 # max agents in a shop

# job commit and complete criteria
#JOB_MIN_SHOP = 1 # or 2 ? restrictive, select only jobs with items available in min # shops
#JOB_NEW_MAX_INCOMPLETE_ITEMS = 1 # or 2
JOB_NEW_MIN_STEPS = 21 # 15 is usually ok
JOB_NEW_MAX_START_STEP = 200 # 12 or no limit NEW, max step to start job from first time job appeared
JOB_MAX_BUY_COST_FAC = 1 # or 0.85/0.90, percent of reward, protects against expensive unfinished jobs
JOB_MIN_BALANCE = 350 # 200, or 1000, min income, reward - buy cost, to use against charge/recharge
#JOB_EST_BUY_FAC = 0.50 # or 0.63; Delphi, higher values lead to higher estimated cost
JOB_ASSEMBLY_MAX_ADD_AGENTS = 2 # NEW, max agents to add if not enough capacity in assembly
JOB_NEW_WORKSHOP_BUFFER_STEPS = 10 # NEW, #steps to add as buffer to go to workshop in job selection calcs
JOB_MOVE_MIN_STEPS_GAIN = 5 # NEW, min steps gain to give to other faster agent

# explore parameters
# max agents to be moving at any time if there are jobs available
# limit can be exceeded only when agent is not in shop and moving to an empty shop
EXPLORE_MAX_AGENTS_WHEN_JOBS = 5

# explore buys
# boolean, 1=True, 0=False
EXPLORE_BUY_ENABLE = 1
EXPLORE_BUY_MAX_STEP = 930
EXPLORE_BUY_MAX_COST = 20000
EXPLORE_BUY_MAX_ITEM_AMOUNT = 5
EXPLORE_BUY_MAX_LOAD_PCT = 20
EXPLORE_BUY_MIN_CAPACITY = 500

EXPLORE_BUY_FORCED_ENABLE = 1
EXPLORE_BUY_FORCED_MAX_STEP = 930
EXPLORE_BUY_FORCED_MAX_COST = 20000
EXPLORE_BUY_FORCED_MAX_ITEMS = 1
EXPLORE_BUY_FORCED_MAX_LOAD_PCT = 63
EXPLORE_BUY_FORCED_MIN_CAPACITY = 300

# assembly specific
### none yet

# job estimation criteria
# TODO, review every use of JOB_STEPS_FAC !!!
JOB_STEPS_FAC = 1.33 # or 1.25 or 1.33
#JOB_ESTIMATE_ITEMS_AMOUNT_FAC = 0.50
#JOB_ESTIMATE_ITEMS_COMPLETED_FAC = 0.80 # applied on percent of (amount items/total items)*(distinct items)

# general sort class levels
CORE_STEPS_CLASS = 10 # ROUND steps to muliples of this number
CORE_MONEY_CLASS = 250 # ROUND any money to multiples of this number
CORE_CAPACITY_PERCENT_CLASS = 25 # ROUND volume/capacity percents to multiples of this number; must divide 100 !!!
CORE_CAPACITY_CLASS = 150 # ROUND capacity values to multiples of this number

# job drop parameters
#JOB_DROP_MAX_INCOMPLETE_ITEMS = 1 # or 1
#JOB_DROP_NEW_REWARD_FAC = 1.20
#JOB_DROP_NEW_REWARD_FAC_PER_ITEM = 1.30
#JOB_DROP_MIN_EXTRA_BALANCE = 2000
#JOB_DROP_NEW_MIN_STEPS = 63

# CC op parameters
#CC_OP = 0
#CC_MIN_POST_STEPS = 10
#CC_MAX_POST_STEPS = 30
#CC_MIN_A_STEPS = 7 # 77
#CC_MAX_A_STEPS = 20 # 220
#CC_MIN_REWARD_FAC = 0.43
#CC_MAX_REWARD_FAC = 0.50
#CC_POST_JOB_LIMIT = 10

# general parameters
SEED_CAPITAL = 50000
MAX_STEPS = 1000

MAX_INT = sys.maxsize

FLOAT_EP = 0.001 # normally any < e-15

# test mode, not well tested
EXERCISE_MODE = False
MOVE_ENABLE = False



"""

  === NOTE on naming ===

  agent = object of an agent, can be used in place of agent_shared too
  agent_name etc. are specific attributes
  shared = dictionary of all shared data (one per agent)
  agent_shared = dictionary entry in 'shared' for specific agent

  xxx_data for dict data, never use plain xxx
  item_data for item_db dict data always

"""

# useful generators for simpler code

"""
def facilities(agent_shared, facility_type = None):
  for fac_data in agent_shared.view.facilities.values():
    if facility_type is None or fac_data.facility_type == facility_type:
      yield fac_data

def jobs(agent_shared, job_type = None):
  for job_data in agent_shared.view.jobs.values():
    if job_type is None or job_data.job_type == job_type:
      yield job_data

def products(agent_shared):
  for product_data in agent_shared.sim.products.values():
    yield product_data

def entities(agent_shared):
  for entity_data in agent_shared.view.entities.values():
    yield entity_data

def facility_data(agent_shared, fac_id):
  return agent_shared.view.facilities[fac_id]
"""

"""
def calc_item_volume(agent_shared, item_name, item_amount):
  item_db = agent_shared.sim.item
  item_data = item_db[item_name]
  return item_amount * int(item_data.volume)

def calc_self_volume(agent_shared):
  item_db = agent_shared.sim.item
  self_items = agent_shared.view.self.self_items
  tot_volume = 0
  for s_item_data in self_items.values():
    item_data = item_db[s_item_data.name]
    tot_volume += int(s_item_data.amount) * int(item_data.volume)
  return tot_volume
"""

def sign(x):
  return (x > 0) - (x < 0)

#def natural_sort_key(str):
#  MAX_STR_LEN = 10
#  return '{:>10}'.format(str)
def natural_sort_key(str_, _nsre=re.compile(r'(\d+)')):
  return [int(s) if s.isdigit() else s for s in re.split(_nsre, str_)]

# key is assumed string
def one_line_key_val_s(x_dict):
  if x_dict:
    return ",".join(" "+str(x_key)+","+str(x_value) for x_key, x_value in sorted(x_dict.items()))
  else:
    return ""

# key is assumed string
def one_line_key_val_f(x_dict, x_format):
  if x_dict:
    format_str = " {:s} = "+x_format
    return ",".join(format_str.format(str(x_key), x_value) for x_key, x_value in sorted(x_dict.items()))
  else:
    return ""

# key is assumed string
# works for dict-keys, lists and sets too
def one_line_key_s(x_dict):
  if x_dict:
    return ",".join(" "+str(x_key) for x_key in sorted(x_dict))
  else:
    return ""

# key is assumed string
# works for dict-keys, lists and sets too
# not sorted !
def one_line_key(x_dict):
  if x_dict:
    return ",".join(" "+str(x_key) for x_key in x_dict)
  else:
    return ""

# key is assumed string
def one_line_duo_s(x_list):
  if x_list:
    return ";".join(" "+str(x[1])+","+str(x[0]) for x in sorted(x_list))
  else:
    return ""

# key is assumed string
# not sorted !
def one_line_duo(x_list):
  if x_list:
    return ";".join(" "+str(x[1])+","+str(x[0]) for x in x_list)
  else:
    return ""

"""

# nested loop
def nested_join(list1, field1, list2, field2):
  p = []
  for d1 in list1:
    d1_key = getattr(d1, field1)
    for d2 in list2:
      if d1_key == getattr(d2, field2):
        p.append((d1, d2))
        break
  return p

# efficient join needed even with lists of small size !!!
# list1, list2 are lists of objects
def sort_join(list1, field1, list2, field2):
  l = sorted(list1, key=lambda x: getattr(x, field1))
  r = sorted(list2, key=lambda x: getattr(x, field2))
  p = []
  lx = 0; lz = len(l)
  rx = 0; rz = len(r)
  while lx < lz and rx < rz:
    lval = l[lx]; lkey = getattr(l[lx], field1)
    rval = r[rx]; rkey = getattr(r[rx], field2)
    if lkey == rkey:
      p.append((lval, rval))
      lx += 1
      rx += 1
    elif lkey < rkey:
      lx += 1
    elif lkey > rkey:
      rx += 1
  return p

def hash_join(list1, field1, list2, field2):
  # list_h   hashed list
  # list_o   other list to compare with hashed
  if len(list1) < len(list2):
    list_h = list1; field_h = field1
    list_o = list2; field_o = field2
    swap = False
  else:
    list_h = list2; field_h = field2
    list_o = list1; field_o = field1
    swap = True
  h = {getattr(obj_h, field_h): obj_h for obj_h in list_h}
  p = []
  for obj_o in list_o:
    field_x = getattr(obj_o, field_o)
    if field_x in h:
      if swap:
        p.append((obj_o, h[field_x]))
      else:
        p.append((h[field_x], obj_o))
  return p

def test_joins(log):
  #list1 = [Duo("x"+str(x), x) for x in range(0, 1000000, 100000)]
  #list2 = [Duo("y"+str(y), y) for y in range(0, 1000000, 1)]
  list1 = [Duo("x"+str(x), x) for x in range(0, 15, 1)]
  list2 = [Duo("y"+str(y), y) for y in range(0, 15, 1)]
  random.shuffle(list1)
  random.shuffle(list2)
  t1 = time.time()
  for i in range(1000):
    p_sort = sort_join(list2, "key", list1, "key")
  t2 = time.time()
  log.info(lambda: "sort_join: {:.3f} s".format(t2 - t1))
  t1 = time.time()
  for i in range(1000):
    p_hash = hash_join(list2, "key", list1, "key")
  t2 = time.time()
  log.info(lambda: "hash_join: {:.3f} s".format(t2 - t1))
  t1 = time.time()
  for i in range(1000):
    p_nested = nested_join(list2, "key", list1, "key")
  t2 = time.time()
  log.info(lambda: "nested_join: {:.3f} s".format(t2 - t1))
  if sorted(p_sort) != sorted(p_hash) or sorted(p_hash) != sorted(p_nested) or sorted(p_nested) != sorted(p_sort):
    log.error(lambda: "join results are different !")

join = hash_join

"""

"""

# common iterable for lists and dicts
def common_iterable(obj):
  if isinstance(obj, dict):
    return obj.values()
  else:
    return obj

"""



# TODO... select settings to include

SETTINGS_TYPE = {
"MAX_CONCURRENT_JOBS": int,
"MAX_CONCURRENT_AGENTS": int,

"JOB_NEW_MIN_STEPS": int,
"JOB_NEW_MAX_START_STEP": int,
"JOB_NEW_WORKSHOP_BUFFER_STEPS": int,
"JOB_MAX_BUY_COST_FAC": float,
"JOB_MIN_BALANCE": int,
"JOB_ASSEMBLY_MAX_ADD_AGENTS": int,
"JOB_MOVE_MIN_STEPS_GAIN": int,

"EXPLORE_MAX_AGENTS_WHEN_JOBS": int,

"EXPLORE_BUY_ENABLE": int,
"EXPLORE_BUY_MAX_STEP": int,
"EXPLORE_BUY_MAX_COST": int,
"EXPLORE_BUY_MAX_ITEM_AMOUNT": int,
"EXPLORE_BUY_MAX_LOAD_PCT": int,
"EXPLORE_BUY_MIN_CAPACITY": int,

"EXPLORE_BUY_FORCED_ENABLE": int,
"EXPLORE_BUY_FORCED_MAX_STEP": int,
"EXPLORE_BUY_FORCED_MAX_COST": int,
"EXPLORE_BUY_FORCED_MAX_ITEMS": int,
"EXPLORE_BUY_FORCED_MAX_LOAD_PCT": int,
"EXPLORE_BUY_FORCED_MIN_CAPACITY": int,

"JOB_STEPS_FAC": float
}

# preserve order
SETTINGS_VALUE = attr_dict({
"MAX_CONCURRENT_JOBS": MAX_CONCURRENT_JOBS,
"MAX_CONCURRENT_AGENTS": MAX_CONCURRENT_AGENTS,

"JOB_NEW_MIN_STEPS": JOB_NEW_MIN_STEPS,
"JOB_NEW_MAX_START_STEP": JOB_NEW_MAX_START_STEP,
"JOB_NEW_WORKSHOP_BUFFER_STEPS": JOB_NEW_WORKSHOP_BUFFER_STEPS,
"JOB_MAX_BUY_COST_FAC": JOB_MAX_BUY_COST_FAC,
"JOB_MIN_BALANCE": JOB_MIN_BALANCE,
"JOB_ASSEMBLY_MAX_ADD_AGENTS": JOB_ASSEMBLY_MAX_ADD_AGENTS,
"JOB_MOVE_MIN_STEPS_GAIN": JOB_MOVE_MIN_STEPS_GAIN,

"EXPLORE_MAX_AGENTS_WHEN_JOBS": EXPLORE_MAX_AGENTS_WHEN_JOBS,

"EXPLORE_BUY_ENABLE": EXPLORE_BUY_ENABLE,
"EXPLORE_BUY_MAX_STEP": EXPLORE_BUY_MAX_STEP,
"EXPLORE_BUY_MAX_COST": EXPLORE_BUY_MAX_COST,
"EXPLORE_BUY_MAX_ITEM_AMOUNT": EXPLORE_BUY_MAX_ITEM_AMOUNT,
"EXPLORE_BUY_MAX_LOAD_PCT": EXPLORE_BUY_MAX_LOAD_PCT,
"EXPLORE_BUY_MIN_CAPACITY": EXPLORE_BUY_MIN_CAPACITY,

"EXPLORE_BUY_FORCED_ENABLE": EXPLORE_BUY_FORCED_ENABLE,
"EXPLORE_BUY_FORCED_MAX_STEP": EXPLORE_BUY_FORCED_MAX_STEP,
"EXPLORE_BUY_FORCED_MAX_COST": EXPLORE_BUY_FORCED_MAX_COST,
"EXPLORE_BUY_FORCED_MAX_ITEMS": EXPLORE_BUY_FORCED_MAX_ITEMS,
"EXPLORE_BUY_FORCED_MAX_LOAD_PCT": EXPLORE_BUY_FORCED_MAX_LOAD_PCT,
"EXPLORE_BUY_FORCED_MIN_CAPACITY": EXPLORE_BUY_FORCED_MIN_CAPACITY,

"JOB_STEPS_FAC": JOB_STEPS_FAC
})

# settings to configure before each game
# usually do not make much difference except at extreme values
# at least changeable easily without messing with source
def settings(agent):
  log = agent._log
  step = agent._step
  
  S_TYPE = SETTINGS_TYPE
  S_VALUE = SETTINGS_VALUE
  UTIL_MODULE = modules["util"]
  config = configparser.ConfigParser()
  config.read(main.SETTINGS_FILE)
  if not "settings" in config:
    return
  for conf_key, conf_value in config["settings"].items():
    s_key = conf_key.upper()
    # check against self modification error, both dicts must be modified together
    if s_key in S_TYPE and s_key in S_VALUE:
      func_type = S_TYPE[s_key]
      s_value = func_type(conf_value)
      if S_VALUE[s_key] != s_value:
        log.info(lambda: "{:d}, SETTING:   {:s} = {} !".format(step, s_key, s_value))
      setattr(UTIL_MODULE, s_key, s_value)
      S_VALUE[s_key] = s_value
    else:
      log.info(lambda: "SETTING:   {:s} = {} ?".format(s_key, s_value))

# no use of getattr to be sure !!!
def print_settings(agent):
  log = agent._log
  ###log.info(lambda: "========= settings =========")
  S_VALUE = SETTINGS_VALUE
  log.info(lambda: one_line_key_val_s(S_VALUE))

def print_start(agent):
  log = agent._log
  
  log.debug(lambda: "")
  log.debug(lambda: "*** sim-start ***")
  #  simulation => id, map, seedCapital, steps, team
  #                minLat, maxLat, minLon, maxLon,
  #                centerLat, centerLon, cellSize, proximity
  x = agent.sim
  log.debug(lambda: "sim, name = {}, id = {}, map = {}, seedCapital = {}, steps = {}, team = {}".format(
    x.name, x.id, x.map, x.seedCapital, x.steps, x.team
  ))
  log.debug(lambda: "sim, minLat = {}, maxLat = {}, minLon = {}, maxLon = {}, centerLat = {}, centerLon = {}".format(
    x.minLat, x.maxLat, x.minLon, x.maxLon, x.centerLat, x.centerLon
  ))
  log.debug(lambda: "sim, cellSize = {}, proximity = {}".format(x.cellSize, x. proximity))
  if x.name != agent._agent_name:
    log.error(lambda: "CHECK-ERR:   sim, name = {} != {}".format(x.name, agent._agent_name))
  #  role => name, speed, battery, load (name = car, drone, motorcycle, truck)
  x = x.role
  log.debug(lambda: "role, name = {}, speed = {}, battery = {}, load = {}, tool = {}".format(
    x.name, x.speed, x.battery, x.load, one_line_key_s(x.tool)
  ))
  #  tool => [ name ]
  log.debug(lambda: "role, tool = {}\n".format(one_line_key_s(x.tool)))

def print_view(agent):
  log = agent._log
  step = agent._step
  
  #    self => lat, lon, facility, charge, load, name, role, team,
  #      action => type, result
  #      items => [ name, amount ]
  #      route => [ i, lat, lon ]   # i = 0 ..
  a_self = agent.view.self
  x = a_self.action
  log.debug(lambda: "step = {:d}, last action = {} => {}".format(step, x.type, x.result))
  x = a_self
  log.debug(lambda: "facility = {}, route = {:d}, charge = {}, load = {} ({} {})".format(
    x.facility, len(x.route), x.charge, x.load, x.role, x.name
  ))
  #   items => [ name, amount ]
  log.debug(lambda: "on_board => {}".format(";".join(" "+s.name+","+str(s.amount) for s in x.self_items.values())))

def print_shop_inventory(agent):
  log = agent._log
  
  shop_view = agent.view.shop
  
  log.log(LOG_OP, lambda: "=== shop inventory ===")
  for fac_id in sorted(shop_view.keys(), key=natural_sort_key):
    fac_data = shop_view[fac_id]
    log.log(LOG_OP, lambda: "{:s} => {}".format(fac_id,
      ";".join(" "+item_data.name+","+str(item_data.amount)+"@"+str(item_data.price) for item_data in fac_data.item.values())
    ))

# TODO... do we really need this ?
# update self_tools (tools loaded) and new_tools (new tools can load)
def update_self_tools(agent):
  log = agent._log
  step = agent._step
  
  compat_tools = agent.compat_tools
  self_tools = agent.self_tools
  new_tools = agent.new_tools
  if compat_tools and self_tools and not new_tools:
    log.debug(lambda: "self_tools (complete) => {}".format(one_line_key_s(self_tools)))
    return
  
  agent_sim = agent.sim
  agent_view = agent.view
  
  if not compat_tools:
    compat_tools = set(agent_sim.role.tool.keys())
    agent.compat_tools = compat_tools
  log.debug(lambda: "compatible tools => {}".format(one_line_key_s(compat_tools)))
  
  self_items = set(agent_view.self.self_items.keys())
  log.debug(lambda: "self_items => {}".format(one_line_key_s(self_items)))
  
  self_tools = self_items & compat_tools 
  log.debug(lambda: "self_tools => {}".format(one_line_key_s(self_tools)))
  agent.self_tools = self_tools
  
  new_tools = compat_tools - self_items 
  log.debug(lambda: "new_tools  => {}".format(one_line_key_s(new_tools)))
  agent.new_tools = new_tools

# display analysis summary per item (assembled, level of assembly tree, etc.)
# plus statistics over all items
def create_item_db(agent):
  log = agent._log
  
  import team
  
  agent_sim = agent.sim
  item_dict = agent_sim.item
  
  tool_db = set()
  for item_name, item_data in item_dict.items():
    if "item" not in item_data:
      item_data["item"] = attr_dict()
    if "tool" not in item_data:
      item_data["tool"] = attr_dict()
    tool_db.update(item_dict[item_name].tool.keys())
  
  log.log(LOG_OP, lambda: "")
  log.log(LOG_OP, lambda: "*** tool db ***")
  log.log(LOG_OP, lambda: one_line_key_s(tool_db))
  log.log(LOG_OP, lambda: "")
  
  item_db = attr_dict()
  for item_name in item_dict.keys():
    item_tree(log, item_dict, tool_db, item_name, item_db)
  
  log.log(LOG_OP, lambda: "*** item db ***")
  item_db.log_data(log, LOG_OP)
  log.log(LOG_OP, lambda: "")
  
  team.item_db = item_db
  team.tool_db = tool_db

# item_db uses existing item view data, extending with more attributes
# recursive counts are single item only, tree structure kind, no multiples by amount
# but counters (_counter) include amount multiplicities correctly
# TODO..., enhance with more useful volume change info ?!
def item_tree(log, item_dict, tool_db, item_name, item_db):
  if item_name in item_db:
    return item_db[item_name]
  item_data = item_dict[item_name]
  #
  # name, volume, item => [ name, amount ], tool => [ name ]
  # new content, for one single item
  #
  level = 1
  needs_assembly = False
  volume = int(item_data.volume)
  min_vol_change = 0
  max_vol_change = 0
  #
  base_direct = 0
  base_total = 0
  assembled_direct = 0
  assembled_total = 0
  all_direct = 0
  all_total = 0
  tool_direct = 0
  tool_total = 0
  # for one single item, with amounts
  base_direct_counter = Counter()
  base_total_counter = Counter()
  # for one single item, counting amounts for subassemblies
  assembled_direct_counter = Counter()
  assembled_total_counter = Counter()
  # tool set
  tool_direct_set = set()
  tool_total_set = set()
  # top order, list of Duo tuples(item_amount, item_name) to assemble for 1 item
  assemble_order = []
  # item tree, default
  if 'item' not in item_data:
    item_data.item = attr_dict()
  # item tree, dfs
  min_vol = MAX_INT
  max_vol = 0
  for req_item_name, req_item_data in item_data.item.items():
    req_item_amount = int(req_item_data.amount)
    req_item_tree = item_tree(log, item_dict, tool_db, req_item_name, item_db)
    level = max(level, req_item_tree.level + 1)
    needs_assembly = True
    req_item_vol = req_item_tree.volume * req_item_amount
    if req_item_vol < min_vol:
      min_vol = req_item_vol
    if req_item_vol > max_vol:
      max_vol = req_item_vol
    if req_item_tree.level == 1:
      #
      all_direct += 1
      all_total += 1
      #
      base_direct += 1
      base_total += 1
      base_direct_counter[req_item_name] = req_item_amount
      base_total_counter[req_item_name] += req_item_amount
    else:
      #
      all_direct += 1
      all_total += (1 + req_item_tree.all_total)
      #
      base_total += req_item_tree.base_total
      base_total_counter.update(C_mul(req_item_tree.base_total_counter, req_item_amount))
      #
      assembled_direct += 1
      assembled_total += (1 + req_item_tree.assembled_total)
      assembled_direct_counter[req_item_name] = req_item_amount
      assembled_total_counter.update(C_mul(req_item_tree.assembled_total_counter, req_item_amount))
      #
      tool_total_set.update(req_item_tree.tool_total_set)
      #
      assemble_order.extend(D_mul(req_item_tree.assemble_order, req_item_amount))
  # assemble order & vol change
  if needs_assembly:
    assemble_order.append(Duo(1, item_name))
    min_vol_change = volume - max_vol
    max_vol_change = volume - min_vol
  # tool tree
  for req_tool_name in item_data.tool.keys():
    tool_direct += 1
    tool_direct_set.add(req_tool_name)
    tool_total_set.add(req_tool_name)
  tool_total = len(tool_total_set)
  # attach info
  item_data.level = level
  item_data.needs_assembly = needs_assembly
  item_data.volume = volume
  item_data.min_vol_change = min_vol_change
  item_data.max_vol_change = max_vol_change
  #
  item_data.base_direct = base_direct
  item_data.base_total = base_total
  item_data.assembled_direct = assembled_direct
  item_data.assembled_total = assembled_total
  item_data.all_direct = all_direct
  item_data.all_total = all_total
  item_data.tool_direct = tool_direct
  item_data.tool_total = tool_total
  #
  item_data.base_direct_counter = base_direct_counter
  item_data.base_total_counter = base_total_counter
  item_data.assembled_direct_counter = assembled_direct_counter
  item_data.assembled_total_counter = assembled_total_counter
  item_data.tool_direct_set = tool_direct_set
  item_data.tool_total_set = tool_total_set
  #
  item_data.assemble_order = assemble_order
  #
  item_db[item_name] = item_data
  return item_data

# for a counter
# multiply all counts by m
# returns new Counter()
def C_mul(dict_A, m):
  res = Counter(dict_A)
  for key in res.keys():
    res[key] *= m
  return res

# for a list of Duo(value, key)
# multiply all counts by m
# returns new list of Duo(value, key)
def D_mul(list_A, m):
  return [Duo(value*m, key) for value, key in list_A]

# for a vector of values
# multiply all counts by m
# returns new vector of values
def V_mul(list_A, m):
  return [value*m for value in list_A]

# flatten a dict of Counter() values to single Counter()
def flatten_dict_counter(d):
  res = Counter()
  for c in d.values():
    res.update(c)
  return res

# make a new copy of a dict of Counter() values
def copy_dict_counter(dict_A):
  res = defaultdict(Counter)
  for key, value_counter in dict_A.items():
    res[key] = Counter(value_counter)
  return res

# update (add) a dict_A of Counter() values with Counter() in dict_X
# assumes dict_X has keys a subset of dict_A keys
def update_dict_counter(dict_A, dict_X):
  for key, value_counter in dict_A.items():
    value_counter.update(dict_X[key])

def item_spec(agent):
  log = agent._log
  
  import team
  
  item_db = team.item_db
  
  item1_count = defaultdict(int)
  item1_volume1 = {}
  for item_name, item_data in item_db.items():
    if item_data.level == 2:
      for req_item_name, req_item_data in item_data.item.items():
        item1_count[req_item_name] += 1
        volume1 = item_db[req_item_name].volume
        item1_volume1[req_item_name] = volume1
  item1_list = sorted([
    (count, -item1_volume1[name], name)
    for name, count in item1_count.items()
  ], reverse=True)
  # item_count, item_volume, item_name
  item_spec_list = [(x[0], -x[1], x[2]) for x in item1_list]
  team.item_spec_list = item_spec_list
  team.item_spec_dict = item1_count



# return (7) agent_on, agent_buy, items_on, items_buy, list_on, list_buy, buy_shop of items and tools
# agent_xxx are dicts of Counter(s) of items indexed by agent
# item_xxx are Counters(s) of items (for all agents; not sum but correctly counting once items in same shop)
# list_xxx are dicts of lists of (item_name, item_amount, item_price, agent_name, {fac_id}) indexed by item_name
# buy_shop is dict of Counter(s) of items indexed by shop id
### item_price = 0 for _on items
# CE handles tools as items correctly
def get_items_available(agent, agent_list=None):
  log = agent._log
  
  shop_view = agent.view.shop
  
  agent_on = defaultdict(Counter)
  agent_buy = defaultdict(Counter)
  items_on = Counter()
  items_buy = Counter()
  list_on = defaultdict(list)
  list_buy = defaultdict(list)
  
  buy_shop = defaultdict(Counter)
  for fac_id, fac_data in shop_view.items():
    fac_items = fac_data.item
    fac_items_counter = Counter({x.name: int(x.amount) for x in fac_items.values()})
    buy_shop[fac_id] = fac_items_counter
  
  shops_used = set()
  for agent_name, agent_shared in agent._shared.items():
    if agent_list and agent_name not in agent_list:
      continue
    
    agent_view = agent_shared.view
    a_self = agent_view.self
    
    # agent_on, items_on
    on_C = Counter({x.name: int(x.amount) for x in a_self.self_items.values()})
    agent_on[agent_name] = on_C
    items_on.update(on_C)
    
    # list_on
    for item_name, item_amount in on_C.items():
      list_on[item_name].append((item_name, item_amount, 0, agent_name))
    
    # buy
    fac_id = a_self.facility
    if fac_id == "none":
      continue
    fac_data = agent_view.facilities[fac_id]
    if fac_data.facility_type == "shop":
      fac_item = fac_data.item
      # agent_buy, items_buy and list_buy
      for item_name, item_data in fac_item.items():
        # serious bug
        # tool already on agent or tool that cannot be loaded by agent !
        #if item_name in tool_db:
        #  if item_name in agent_shared.self_tools or item_name not in agent_shared.new_tools:
        #    continue
        item_amount = int(item_data.amount)
        item_price = int(item_data.price)
        list_buy[item_name].append((item_name, item_amount, item_price, agent_name, fac_id))
      agent_buy[agent_name] = buy_shop[fac_id]
      if not fac_id in shops_used:
        items_buy.update(buy_shop[fac_id])
        shops_used.add(fac_id)
  
  shops_unused = set(buy_shop.keys()) - shops_used
  for fac_id in shops_unused:
    del buy_shop[fac_id]
  
  log.log(LOG_OP, lambda: "get_items_available, agent_list = {}".format(one_line_key_s(agent_list)))
  
  log.log(LOG_OP, lambda: "agent_on =")
  for key in sorted(agent_on, key=natural_sort_key):
    val = agent_on[key]
    if val:
      log.log(LOG_OP, lambda: "... {}: {}".format(key, one_line_key_val_s(val)))
  
  log.log(LOG_OP, lambda: "agent_buy =")
  for key in sorted(agent_buy, key=natural_sort_key):
    val = agent_buy[key]
    if val:
      log.log(LOG_OP, lambda: "... {}: {}".format(key, one_line_key_val_s(val)))
  
  log.log(LOG_OP, lambda: "items_on = {}".format(one_line_key_val_s(items_on)))
  log.log(LOG_OP, lambda: "items_buy = {}".format(one_line_key_val_s(items_buy)))
  
  log.log(LOG_OP, lambda: "list_on =")
  for key in sorted(list_on, key=natural_sort_key):
    val = list_on[key]
    if val:
      log.log(LOG_OP, lambda: "... {}: {}".format(key, sorted(val)))
  
  log.log(LOG_OP, lambda: "list_buy =")
  for key in sorted(list_buy, key=natural_sort_key):
    val = list_buy[key]
    if val:
      log.log(LOG_OP, lambda: "... {}: {}".format(key, sorted(val)))
  
  log.log(LOG_OP, lambda: "buy_shop =")
  for key in sorted(buy_shop, key=natural_sort_key):
    val = buy_shop[key]
    if val:
      log.log(LOG_OP, lambda: "... {}: {}".format(key, one_line_key_val_s(val)))
  
  return agent_on, agent_buy, items_on, items_buy, list_on, list_buy, buy_shop

# return agent_on, items_on
# simpler and faster version of items_available
# CE handles tools as items correctly
def get_items_on(agent, agent_list=None):
  log = agent._log
  
  import team
  
  agent_on = defaultdict(Counter)
  items_on = Counter()
  
  for agent_name, agent_shared in agent._shared.items():
    if agent_list and agent_name not in agent_list:
      continue
    a_self = agent_shared.view.self
    # agent_on
    on_C = Counter({x.name: int(x.amount) for x in a_self.self_items.values()})
    agent_on[agent_name] = on_C
    items_on.update(on_C)
  
  log.log(LOG_OP, lambda: "get_items_on, agent_list = {}".format(one_line_key_s(agent_list)))
  for key in sorted(agent_on, key=natural_sort_key):
    val = agent_on[key]
    if val:
      log.log(LOG_OP, lambda: "... {}: {}".format(key, one_line_key_val_s(val)))
  log.log(LOG_OP, lambda: "items_on = {}".format(one_line_key_val_s(items_on)))
  
  return agent_on, items_on



# return tuple of (all, base, tools) Counter(s) needed for a job
# CE handles tools vs items correctly
def job_base_resources(agent, job_id):
  import team
  
  item_db = team.item_db
  job_db = team.job_db
  job_data = job_db[job_id]
  
  res_base = Counter()
  tools = set()
  for job_item_name, job_item_data in job_data.required.items():
    job_item_amount = int(job_item_data.amount)
    item_data = item_db[job_item_name]
    res_base.update(C_mul(item_data.base_total_counter, job_item_amount))
    tools.update(item_data.tool_total_set)
  res_tools = Counter(tools)
  res_all = Counter(res_base)
  res_all.update(res_tools)
  return (res_all, res_base, res_tools)

# return tuple of (assembled, base, tools) Counters() for a job
# whith as many assembled items as possible from a Counter of on board items
# amounts fully used, if multiple same items then used in order of assembly (recursively)
# almost same core logic as can_complete_job() but without checking for capacities etc.
# it just procudces a 'recipe' of items that can complete a job
# can't just remove all base items making a assembled item
# it's recursive, tree structure and will remove more than necessary
# need replicate the build process in order of assembly
# CE handles tools vs items correctly
def job_part_resources(agent, job_id, on_items):
  import team
  
  item_db = team.item_db
  job_db = team.job_db
  job_data = job_db[job_id]
  
  # work on a copy
  x_items = Counter(on_items)
  
  res_assembled = Counter()
  res_base = Counter()
  tools = set()
  
  for job_item_name, job_item_data in job_data.required.items():
    job_item_amount = int(job_item_data.amount)
    
    # base item counted
    if not item_db[job_item_name].needs_assembly:
      req_base[job_item_name] += job_item_amount
      continue
    
    use_amount = min(job_item_amount, x_items[job_item_name])
    # assembled item already available in some quantity
    if use_amount > 0:
      x_items[job_item_name] -= use_amount
      res_assembled[job_item_name] += use_amount
    if use_amount == job_item_amount:
      continue
    
    # now build the rest
    job_item_build = job_item_amount - use_amount
    item_part_resources(agent, job_item_name, job_item_build, x_items, res_assembled, res_base, tools)
  
  res_tools = Counter(tools)
  
  return res_assembled, res_base, res_tools

# CE handles tools vs items correctly
def item_part_resources(agent, item_name, item_build, x_items, res_assembled, res_base, tools):
  import team
  
  item_db = team.item_db
  item_data = item_db[item_name]
  
  # assembly (at least this one, else would not be called)
  for req_item_name, req_item_data in item_data.item.items():
    req_item_amount = int(req_item_data.amount)
    
    # base item counted
    if not item_db[req_item_name].needs_assembly:
      res_base[req_item_name] += req_item_amount * item_build
      continue
    
    use_amount = min(req_item_amount * item_build, x_items[req_item_name])
    # assembled item already available in some quantity
    if use_amount > 0:
      x_items[req_item_name] -= use_amount
      res_assembled[req_item_name] += use_amount
    if use_amount == req_item_amount:
      continue
    
    req_item_build = req_item_amount * item_build - use_amount
    item_part_resources(agent, req_item_name, req_item_build, x_items, res_assembled, res_base, tools)
  
  # tools, just the tools for the items that will be assembled
  for req_tool_name in item_data.tool.keys():
    tools.add(req_tool_name)



# job assembly stats, without multiplicities
# CE handles tools vs items correctly
def job_profile(agent, job_id):
  import team
  
  item_db = team.item_db
  job_db = team.job_db
  job_data = job_db[job_id]
  
  base_direct = 0
  base_total = 0
  assembled_direct = 0
  assembled_total = 0
  tools = set()
  for job_item_name, job_item_data in job_data.required.items():
    job_item_amount = int(job_item_data.amount)
    item_data = item_db[job_item_name]
    if item_data.needs_assembly:
      assembled_direct += 1
    else:
      base_direct += 1
    base_total += item_data.base_total
    assembled_total += item_data.assembled_total
    tools |= item_data.tool_total_set
  tool_total = len(tools)
  return base_direct, base_total, assembled_direct, assembled_total, tool_total

# return min and max buy cost for items in item_counter
# CE handles tools as items correctly
# if tools in item_counter then will be costed
def items_cost(agent, item_counter):
  log = agent._log
  
  shop_view = agent.view.shop

  min_buy_cost = 0
  max_buy_cost = 0
  for item_name, item_amount in item_counter.items():
    item_min_buy_cost = MAX_INT
    item_max_buy_cost = 0
    item_found = False
    for fac_id, fac_data in shop_view.items():
      fac_items = fac_data.item
      if item_name in fac_items:
        item_found = True
        x_cost = item_amount * int(fac_items[item_name].price)
        item_min_buy_cost = min(item_min_buy_cost, x_cost)
        item_max_buy_cost = max(item_max_buy_cost, x_cost)
    if item_found:
      min_buy_cost += item_min_buy_cost
      max_buy_cost += item_max_buy_cost
  return min_buy_cost, max_buy_cost



# utility function, WARNING: updates agent_items and agent_capacity dict
# all agents participate, even if not necessary
###
# updates assemble_plan, complete_status
#   agent_list = set of agents
#   agent_items = dict of Counter() per agent
#   agent_capacity = dict of available capacity per agent
#   assemble_plan = plan for assembly as list (item_name, assembler) per agent
#   complete_status = dict of certain status and information data
###
# select assembler that has highest free volume for more
# full simulation of server code
#
# status = SUCCESS, ERR-required, ERR-capacity, ERR-tool, ERR-CHECK
# x_required = item required
# x_capacity = extra capacity needed
# x_check_item = item failed check
#
# assemble_steps = total assemble steps
# CE handles tools vs items correctly
def can_complete_job(agent, job_id,
  agent_list, agent_items, agent_capacity,
  assemble_plan, complete_status
):
  log = agent._log
  
  import team
  
  item_db = team.item_db
  job_db = team.job_db
  job_data = job_db[job_id]
  
  complete_status.status = ""
  complete_status.x_capacity = 0
  complete_status.assemble_steps = 0
  
  log.log(LOG_OP, lambda: "can_complete_job {:s}, party = {}".format(job_id, one_line_key_s(agent_list)))
  
  new_items = defaultdict(Counter)
  
  for job_item_name, job_item_data in job_data.required.items():
    job_item_amount = int(job_item_data.amount)
    # skip not assembled
    if not item_db[job_item_name].needs_assembly:
      log.log(LOG_OP, lambda: "can_complete_job {:s}, item {:s},{:d} base, skipped".format(job_id, job_item_name, job_item_amount))
      continue
    # partial or full availability of assembled item
    use_amount = can_satisfy(agent, agent_items, job_item_name, job_item_amount, adjust=False)
    log.log(LOG_OP, lambda: "can_complete_job {:s}, item {:s},{:d} got {:d} assembled".format(job_id, job_item_name, job_item_amount, use_amount))
    if use_amount == job_item_amount:
      continue
    job_item_build = job_item_amount - use_amount
    if not can_assemble_item(
      agent, job_item_name, job_item_build,
      agent_list, agent_items, agent_capacity,
      assemble_plan, complete_status, new_items
    ):
      log.log(LOG_OP, lambda: "CHEK-ERR:   can_complete_job {:s}, item {:s},{:d} cannot {:d} assembled !!!".format(job_id, job_item_name, job_item_amount, job_item_build))
      return False
    log.log(LOG_OP, lambda: "can_complete_job {:s}, item {:s},{:d} can {:d} assembled".format(job_id, job_item_name, job_item_amount, job_item_build))
  
  # update agent_items
  update_dict_counter(agent_items, new_items)
  
  # final check (delivery)
  for job_item_name, job_item_data in job_data.required.items():
    job_item_amount = int(job_item_data.amount)
    use_amount = can_satisfy(agent, agent_items, job_item_name, job_item_amount, adjust=True)
    if not use_amount == job_item_amount:
      log.log(LOG_OP, lambda: "CHECK-ERR:   can_complete_job {:s}, item {:s} = {:d} vs. {:d}".format(job_id,
        job_item_name, use_amount, job_item_amount
      ))
      complete_status.status = "ERR-CHECK"
      complete_status.x_check_item = job_item_name
      return False
  
  complete_status.status = "SUCCESS"
  log.log(LOG_OP, lambda: "can_complete_job {:s}, success, steps = {:d}".format(job_id, complete_status.assemble_steps))
  return True

# adjust = True to adjust agent_items
# if can satisfy use of item_name at item_amount from all agent(s) items
# return total amount that can be used up to requested amount
# CE handles tools vs items correctly (tools for compatibility)
# if item_name is tool and agent_items contains tools then works correctly
def can_satisfy(agent, agent_items, item_name, item_amount, adjust=False):
  shared = agent._shared
  
  import team
  
  tool_db = team.tool_db
  
  needed = item_amount
  total_take = 0
  for agent_name, agent_items in agent_items.items():
    agent_shared = shared[agent_name]
    if item_name in tool_db and item_name not in agent_shared.compat_tools:
      continue
    
    take = min(agent_items[item_name], needed)
    if take > 0:
      if adjust:
        agent_items[item_name] -= take
      needed -= take
      total_take += take
      if needed == 0:
        return total_take
  
  return total_take

# by inspecting server code, to be sure about mechanism
# utility function, WARNING: updates agent_items and agent_capacity dict
# all agents participate, even if not necessary
###
# updates assemble_plan, assemble_status
#   item_name, item_build = item and required amount to build
#   agent_list = set of agents
#   agent_items = dict of Counter() per agent
#   agent_capacity = dict of available capacity per agent
#   assemble_plan = plan for assembly as list (item_name, assembler) per agent
#   assemble_status = dict of certain status and information data
###
# select assembler that has highest free volume for more
# full simulation of server code
#
# status = SUCCESS, ERR-required, ERR-capacity, ERR-tool
# x_required = item required
# x_capacity = extra capacity needed
#
# assemble_steps = total assemble steps
# CE handles tools vs items correctly
def can_assemble_item(agent, item_name, item_build,
  agent_list, agent_items, agent_capacity,
  assemble_plan, assemble_status, new_items
):
  log = agent._log
  
  import team
  
  item_db = team.item_db
  item_data = item_db[item_name]
  
  log.log(LOG_OP, lambda: "   can_assemble_item {:s},{:d}, party = {}".format(item_name, item_build, one_line_key_s(agent_list)))
  
  my_new_items = defaultdict(Counter)
  
  # pre-check and recursive step, all
  for req_item_name, req_item_data in item_data.item.items():
    req_item_amount = int(req_item_data.amount)
    req_item_x = req_item_amount * item_build
    if not item_db[req_item_name].needs_assembly:
      log.log(LOG_OP, lambda: "   can_assemble_item {:s}, item {:s},{:d} base, skipped".format(item_name, req_item_name, req_item_x))
      continue
    use_amount = can_satisfy(agent, agent_items, req_item_name, req_item_x, adjust=False)
    log.log(LOG_OP, lambda: "   can_assemble_item {:s}, item {:s},{:d} got {:d} assembled".format(item_name, req_item_name, req_item_x, use_amount))
    # == req_item_amount ???
    if use_amount == req_item_x:
      continue
    req_item_build = req_item_amount * item_build - use_amount
    if not can_assemble_item(
      agent, req_item_name, req_item_build,
      agent_list, agent_items, agent_capacity,
      assemble_plan, assemble_status, my_new_items
    ):
      log.log(LOG_OP, lambda: "CHECK-ERR:   can_assemble_item {:s}, item {:s},{:d} cannot {:d} assembled !!!".format(item_name, req_item_name, req_item_x, req_item_build))
      return False
    log.log(LOG_OP, lambda: "   can_assemble_item {:s}, item {:s},{:d} can {:d} assembled".format(item_name, req_item_name, req_item_x, req_item_build))
  
  # tool check
  for req_tool in item_data.tool.keys():
    if not can_satisfy(agent, agent_items, req_tool, 1, adjust=False) > 0:
      log.log(LOG_OP, lambda: "CHECK-ERR:   can_assemble_item {:s}, tool: {:s} missing".format(item_name, req_tool))
      assemble_status.status = "ERR-tool"
      return False
  
  # update agent_items
  update_dict_counter(agent_items, my_new_items)
  
  # final assembly
  for assembly_num in range(item_build):
    agent_capacity_list = ((agent_capacity[x_agent_name], x_agent_name) for x_agent_name in agent_list)
    assembler = (sorted(agent_capacity_list, reverse=True)[0])[1]
    if not can_assemble_item1(agent, item_name, agent_list, agent_items, agent_capacity, assembler, assemble_status):
      log.log(LOG_OP, lambda: "CHECK-ERR:   can_assemble_item {:s}, cannot be assembled-1 (assembler = {:s}) !!!".format(item_name, assembler))
      return False
    log.log(LOG_OP, lambda: "   can_assemble_item {:s}, can be assembled-1 (assembler = {:s})".format(item_name, assembler))
    new_items[assembler][item_name] += 1
    assemble_status.assemble_steps += 1
    # append to expanded assemble plan, per agent
    for agent_name in agent_list:
      assemble_plan[agent_name].append((item_name, assembler))
  
  assemble_status.status = "SUCCESS"
  return True

import functools
# custom sort compare function to compare agent names, as used by server code
def sort_cmp(s1, s2):
  l1 = len(s1)
  l2 = len(s2)
  if l1 == l2:
    return ((s1 > s2) - (s2 < s1))
  else:
    return l1 - l2

sort_key = functools.cmp_to_key(sort_cmp)

# just assemble a single item using server code logic
# status = SUCCESS, ERR-required, ERR-capacity
# x_required = item required
# x_capacity = extra capacity needed
# CE handles tools vs items correctly
def can_assemble_item1(agent, item_name, agent_list, agent_items, agent_capacity, assembler, assemble_status):
  log = agent._log
  
  import team
  
  item_db = team.item_db
  item_data = item_db[item_name]
  
  for req_item_name, req_item_data in item_data.item.items():
    needed = int(req_item_data.amount)
    req_item_volume = item_db[req_item_name].volume
    # assembler
    take = min(needed, agent_items[assembler][req_item_name])
    agent_items[assembler][req_item_name] -= take
    agent_capacity[assembler] += take * req_item_volume
    needed -= take
    # assistants
    if needed > 0:
      assistants = set(agent_list) - {assembler}
      for agent_name in sorted(assistants, key=sort_key):
        take = min(needed, agent_items[agent_name][req_item_name])
        agent_items[agent_name][req_item_name] -= take
        agent_capacity[agent_name] += take * req_item_volume
        needed -= take
        if needed == 0:
          break
    if needed > 0:
      assemble_status.status = "ERR-required"
      assemble_status.x_required = req_item_name
      return False
  
  # success, adjust for new assembled item
  item_volume = item_data.volume
  if item_volume > agent_capacity[assembler]:
    assemble_status.status = "ERR-capacity"
    assemble_status.x_capacity = item_volume - agent_capacity[assembler]
    return False
  
  # NOTE: DON'T uncomment !!!
  # added in new_items by caller
  ###agent_items[assembler][item_name] += 1
  agent_capacity[assembler] -= item_volume
  
  assemble_status.status = "SUCCESS"
  return True

# independent check if a job is complete
# CE handles tools vs items correctly
def is_complete_job_1(agent, job_id, agent_list):
  log = agent._log
  
  import team
  
  job_db = team.job_db
  job_data = job_db[job_id]
  
  _, items_on = get_items_on(agent, agent_list)
  
  for job_item_name, job_item_data in job_data.required.items():
    job_item_amount = int(job_item_data.amount)
    use_amount = min(items_on[job_item_name], job_item_amount)
    if not use_amount == job_item_amount:
      log.log(LOG_OP, lambda: "CHECK-ERR:   is_complete_job_1, job_id: {:s}   not all required items ({:s}) !!!".format(
        job_id, job_item_name
      ))
      return False
    items_on[job_item_name] -= use_amount
  
  return True

# independent check if a job is complete
# also returns dict of Counter() by job_id only for agents carrying deliverables
# CE handles tools vs items correctly
def is_complete_job_2(agent, job_id, agent_list, agent_items):
  log = agent._log
  
  import team
  
  job_db = team.job_db
  job_data = job_db[job_id]
  
  agent_on, _ = get_items_on(agent, agent_list)
  
  job_required = Counter({x.name: int(x.amount) for x in job_data.required.values()})
  job_buffer = Counter(job_required)
  all_agent_deliverable = Counter()
  for agent_name, agent_load in agent_on.items():
    agent_deliverable = job_buffer & agent_load
    if agent_deliverable:
      agent_items[agent_name] = agent_deliverable
      all_agent_deliverable.update(agent_deliverable)
      job_buffer -= agent_deliverable
  
  # should never happen !
  if all_agent_deliverable != job_required:
    log.log(LOG_OP, lambda: "CHECK-ERR:   is_complete_job_2, job_id: {:s}   not all required items ({}) !!!".format(
      job_id, job_required - all_agent_deliverable
    ))
    return False
  
  return True



# is party gathered in a facility ?
# return None or fac_id
def party_gathered(agent, party):
  shared = agent._shared
  
  fac_id = None
  for agent_name in party:
    agent_shared = shared[agent_name]
    facility = agent_shared.view.self.facility
    if facility == "none":
      return None
    if fac_id:
      if facility != fac_id:
        return None
    else:
      fac_id = facility
  
  return fac_id



"""
# calculate total volume of items in item_counter
def calc_volume(agent, item_counter):
  import team
  
  item_db = team.item_db
  
  total_volume = 0
  for item_name, item_amount in item_counter.items():
    item_data = item_db[item_name]
    total_volume += item_amount * item_data.volume
  return total_volume
"""

def calc_self_volume(agent_shared):
  import team
  
  item_db = team.item_db
  self_items = agent_shared.view.self.self_items
  
  total_volume = 0
  for s_item_data in self_items.values():
    item_data = item_db[s_item_data.name]
    total_volume += int(s_item_data.amount) * item_data.volume
  return total_volume



# return avail_agents, active_agents
def partition_agents(agent):
  log = agent._log
  shared = agent._shared
  
  import team
  
  job_party = team.job_party
  committed_jobs = team.committed_jobs
  
  all_agents = set(shared.keys())
  
  op_agents = set(name for name in shared.keys() if shared[name].job_op is not None)
  
  job_agents = set()
  for job_id in committed_jobs:
    ###log.debug(lambda: "job_party, {:s} => {}".format(job_id, one_line_key_s(job_party[job_id])))
    job_agents.update(job_party[job_id])
  
  active_agents = op_agents | job_agents
  avail_agents = all_agents - active_agents
  
  ###log.debug(lambda: "*** partition_agents")
  ###log.debug(lambda: "all_agents = {}".format(one_line_key_s(all_agents)))
  ###log.debug(lambda: "op_agents = {}".format(one_line_key_s(op_agents)))
  ###log.debug(lambda: "job_agents = {}".format(one_line_key_s(job_agents)))
  ###log.debug(lambda: "active_agents = {}".format(one_line_key_s(active_agents)))
  ###log.debug(lambda: "avail_agents = {}".format(one_line_key_s(avail_agents)))
  ###log.debug(lambda: "")
  
  return avail_agents, active_agents

# return avail_agents, active_agents, explore_agents, job_agents, retrieve_delivered_agents
def partition_agents2(agent):
  log = agent._log
  shared = agent._shared
  
  shop_view = agent.view.shop
  
  import team
  
  job_party = team.job_party
  explore_agents = team.explore_agents
  retrieve_delivered_agents = team.retrieve_delivered_agents
  committed_jobs = team.committed_jobs
  
  all_agents = set(shared.keys())
  
  """
  explore_op_agents = set()
  for agent_name, agent_shared in shared.items():
    job_op = agent_shared.job_op
    if job_op is not None and len(job_op) == 1:
      op_action = job_op.action()
      if op_action and op_action._type == "goto":
        fac_id = op_action._fac_id
        if fac_id and fac_id in shop_view:
          explore_op_agents.add(agent_name)
  
  # bug, there may be many gotos with intermediate charging station
  if explore_agents != explore_op_agents:
    log.error(lambda: "CHECK-ERR:   explore_agents ({:d}) {} != ({:d}) {} explore_op_agents !!!".format(
      len(explore_agents), one_line_key_s(explore_agents),
      len(explore_op_agents), one_line_key_s(explore_op_agents),
    ))
   sanity fix
  explore_agents = explore_op_agents
  """
  
  job_agents = set()
  for job_id in committed_jobs:
    ###log.debug(lambda: "job_party, {:s} => {}".format(job_id, one_line_key_s(job_party[job_id])))
    job_agents.update(job_party[job_id])
  
  if explore_agents & job_agents:
    log.log(LOG_OP, lambda: "CHECK-ERR:   explore_agents ({:d}) {} & ({:d}) {} job_agents !!!".format(
      len(explore_agents), one_line_key_s(explore_agents),
      len(job_agents), one_line_key_s(job_agents)
    ))
  # sanity fix
  explore_agents -= job_agents
  
  if retrieve_delivered_agents & job_agents:
    log.log(LOG_OP, lambda: "CHECK-ERR:   retrieve_delivered_agents ({:d}) {} & ({:d}) {} job_agents !!!".format(
      len(retrieve_delivered_agents), one_line_key_s(retrieve_delivered_agents),
      len(job_agents), one_line_key_s(job_agents)
    ))
  # sanity fix
  retrieve_delivered_agents -= job_agents
  
  if explore_agents & retrieve_delivered_agents:
    log.log(LOG_OP, lambda: "CHECK-ERR:   explore_agents ({:d}) {} & ({:d}) {} retrieve_delivered_agents !!!".format(
      len(explore_agents), one_line_key_s(explore_agents),
      len(retrieve_delivered_agents), one_line_key_s(retrieve_delivered_agents)
    ))
  
  active_agents = explore_agents | job_agents | retrieve_delivered_agents
  avail_agents = all_agents - active_agents
  
  ###log.debug(lambda: "*** partition_agents2")
  ###log.debug(lambda: "all_agents = {}".format(one_line_key_s(all_agents)))
  ###log.debug(lambda: "explore_agents = {}".format(one_line_key_s(explore_agents)))
  ###log.debug(lambda: "job_agents = {}".format(one_line_key_s(job_agents)))
  ###log.debug(lambda: "retrieve_delivered_agents = {}".format(one_line_key_s(retrieve_delivered_agents)))
  ###log.debug(lambda: "active_agents = {}".format(one_line_key_s(active_agents)))
  ###log.debug(lambda: "avail_agents = {}".format(one_line_key_s(avail_agents)))
  ###log.debug(lambda: "")
  
  return avail_agents, active_agents, explore_agents, job_agents, retrieve_delivered_agents