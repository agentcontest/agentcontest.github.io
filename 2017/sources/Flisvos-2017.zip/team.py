
"""

 /*
  * @(#) E.Sarmas   team.py 0.9_63 (2017-09-18)
  *
  * Author: E.Sarmas
  *
  * Created: 2017-04-06
  *
  * Description: Flisvos 2017 (MAPC 2017)
  *
  * Version: 0.9_63
  * Version-Date: 2017-09-18
  *
  * Version-Log:
  *   0.1_0 (2017-04-06)   copy from Flisvos-2016
  *   0.1_9 (2017-05-29)   rewrite so stable core and fewer changes per scenario/implementation
  *   0.6_0 (2017-06-01)   refactoring, new sim messages/info (except distance calcs), running
  *                        fewer import dependency chains, code moved to more appropriate modules
  *                        logging messages with lambda: now, may speed up logging
  *                        single method to recursively decode messages
  *                        log_data moved within attr_dict as instance method
  *                        clear agent action handling/protocol and procedures/statistics/logging level use
  *                        removed items_db, jobs_spec moved in team
  *                        simple class method like procedures for data updates within appropriate module
  *                        clearer procedure interrelationships, existence and use
  *                        cache improvement to be useful for all roles
  *                        cleaner use of JOB_STEPS_FAC so no double use and wrong results
  *                        clearer method use protocol and use of other procedures for data updates
  *                        agents_with_item_on_board and agents_with_item_buy removed and embedded
  *                        introduced deliver_jobs and explore_buys
  *                        jobs_selection does not select but returns base recipe for all not ignored jobs
  *                        new_jobs now setups assembly or marks for delivery already assembled job
  *                        deliver_jobs may arrange first moves (give and take) to fewer and faster agents
  *   0.9_50 (2017-09-03)  qualification run, new_jobs/deliver_jobs/explore_buys disabled
  *   0.9_52 (2017-09-05)  added EXERCIZE_MODE as in qualification to test goto/charge/recharge system
  *                        ability to recover a job_op, for op_goto to recover from battery stalls by
  *                        recharging enough steps for next charging station and then going to destination
  *                        new dist_cache_history, random fail steps not counted
  *                        lowered level of all goto steps calculations
  *                        random fails don't stop op_goto(s) (bad interaction of reset/send_action )
  *                        also handled correctly if happen on first step of action
  *                        fixed job_op drop and job_drop confusion
  *                        new job_data[], SPEC tracks missions and removes fine from money
  *                        better handling of actions that indicate errors (ACTION_ERRORS)
  *                        new action retrieve_delivered and procedure retrieve_delivered in plan
  *                        new dict job_failed, and sets failed_jobs, just_failed_jobs
  *                        clearer actions for job_set_completed and job_set_failed (new), update_jobs_spec
  *                        reassigned role of job_db, new dict job_party
  *                        new procedures single_recharge and single_recharge_goto for faster recharge
  *                        creat can be called with agent in charging_station in future (with charge_level)
  *                        explore_jobs works without jobs and uses tool compatibility
  *                        along with mission and priced job needs in a useful order
  *                        refactored explore_jobs setup merging all loops, and removed shop_estimate
  *                        organized job work in phases (assembly, move, delivery)
  *                        move phase orchestrates give->receive to fewer better fit agents to deliver_jobs
  *                        and works like cpu instruction scheduling filling empty slots when needed
  *                        jobs_selection finally embedded within explore_jobs
  *                        explore_jobs considers better the suitability of each shop to finish jobs
  *                        and considers agent tool_compatibility better, and also global tool cover
  *                        socket timeout to 20 sec, never low value
  *                        enhanced strategy for CHECK-ERR asserts and other CHECK-... almost everywhere
  *                        is the fastest way to verify coverage and correct operation
  *                        changed logging levels everywhere so comfortable view of logging output
  *                        new failed action recovery logic, improved recover and drop functions 
  *                        checked all actions to send an action to server
  *                        new action.has_next() and use of next_action() only after barrier
  *                        so job_drop() works correctly with current action inside barrier
  *                        strange float calcs fixed (FLOAT_EP)
  *                        new job_state_check and actions_state_check, set jobs to drop (just_failed_jobs)
  *                        disabled move operations (give->receive to fewer and faster agents)
  *                        because not so important and code not tested well for crashes and more...
  *                        explore_buys only if no concurrent buy in same shop and only for items
  *   0.9_63 (2017-09-18)  good luck :) 
  */

"""



import collections

import util
import team



# DETAIL < DEBUG <   OP < INFO   < WARNING+
# agent log file =   LOG_DEBUG or LOG_DETAIL (verbose)
# main  log file =   LOG_OP
# console        =   LOG_INFO

LOG_INFO = 20
LOG_OP = 19
LOG_DETAIL = 9



defaultdict = collections.defaultdict
Counter = collections.Counter

MAX_INT = util.MAX_INT

attr_dict = util.attr_dict
natural_sort_key = util.natural_sort_key
one_line_key_val_s = util.one_line_key_val_s
one_line_key_s = util.one_line_key_s

job_base_resources = util.job_base_resources
job_part_resources = util.job_part_resources
#job_profile = util.job_profile
#items_cost = util.items_cost
#partition_agents = util.partition_agents
partition_agents2 = util.partition_agents2



SPEC_STATE_S = ["select", "ignored"]

# update job_spec_ignored for each new system job
# spec checks on first job appearance only, some checks, most better done in other modules
# TODO... predict next mission from previous mission steps and known p, so reserve agents ???
# TODO... not start immediately a new job, or limit queue for up to 2 jobs ???
def jobs_spec(agent):
  log = agent._log
  
  JOB_NEW_MIN_STEPS = util.JOB_NEW_MIN_STEPS
  JOB_MAX_BUY_COST_FAC = util.JOB_MAX_BUY_COST_FAC
  JOB_MIN_BALANCE = util.JOB_MIN_BALANCE
  #JOB_EST_BUY_FAC = util.JOB_EST_BUY_FAC
  MAX_STEPS = util.MAX_STEPS
  
  agent_view = agent.view
  jobs_view = agent_view.jobs_view
  a_self = agent_view.self
  
  #step = int(agent_view.simulation.step)
  #step = team.step
  
  #for job_id in agent_view.posted:
  #  job_spec_checked.add(job_id)
  #  job_spec_ignored.add(job_id)
  
  # check missions first, for correct fine recording
  for job_id in list(active_missions):
    if job_id not in jobs_view:
      job_data = job_db[job_id]
      job_type = job_data.job_type
      reward = int(job_data.reward)
      
      log.info(lambda: "CHECK-ERR:   {:d}, SPEC {:s} {:s}, reward = {:d}{} mission removed, got fine !!!".format(
        step, job_id, job_type, reward, ", fine = " + job_data.fine if job_type == "mission" else ""
      ))
      active_missions.remove(job_id)
      failed_missions.add(job_id)
      team.fines += int(job_db[job_id].fine)
      update_money_stats(agent)
  
  # all other active jobs
  for job_id in list(active_jobs):
    if job_id not in jobs_view:
      # if not removed because we completed it
      if not job_completed[job_id]:
        job_set_failed(agent, job_id)
  
  
  
  # factors for estimation
  ###est_min_fac = 1 + 4 * (1 - JOB_EST_BUY_FAC)
  ###est_max_fac = 1 + 4 * JOB_EST_BUY_FAC
  
  for job_id, job_data in jobs_view.items():
    if job_id in job_spec_checked:
      continue
    
    job_db[job_id] = job_data
    job_creat_step[job_id] = step
    
    job_type = job_data.job_type
    
    """
    # TODO, remove if response time pressure ???
    # assembly stats, just show
    base_direct, base_total, assembled_direct, assembled_total, tool_total = job_profile(agent, job_id)
    log.log(LOG_OP, lambda: "{:d}, SPEC {:s} {:s}, profile: base: {:d} (total: {:d}), assembled: {:d} (total: {:d}), tools: {:d}".format(
      step, job_id, job_type,
      base_direct, base_total,
      assembled_direct, assembled_total,
      tool_total
    ))
    """
    
    # self check code
    on_items = Counter()
    res_all, res_base, res_tools = job_base_resources(agent, job_id)
    part_assembled, part_base, part_tools = job_part_resources(agent, job_id, on_items)
    part_all = part_assembled + part_base + part_tools
    if not (res_all == part_all and res_base == part_base and res_tools == part_tools):
      log.log(LOG_OP, lambda: "CHECK-ERR:   {:d}, SPEC {:s} {:s}, job_base_resources ({}, {}, {}) != job_part_resources ({:d}, {}, {}, {})".format(
        step, job_id, job_type, res_all, res_base, res_tools, part_all, part_base, part_tools
      ))
    
    end_step = min(int(job_data.end), MAX_STEPS)
    steps =  end_step - step
    reward = int(job_data.reward)
    
    """
    buy_limit = int(reward * JOB_MAX_BUY_COST_FAC)
    # only items are costed, tools are investments
    _, req_items_only, _ = job_base_resources(agent, job_id)
    job_min_buy_cost, job_max_buy_cost = items_cost(agent, req_items_only)
    job_est_buy_cost = int((job_min_buy_cost * est_min_fac + job_max_buy_cost * est_max_fac) / 6)
    #job_spec_min_buy_cost[job_id] = job_min_buy_cost
    #job_spec_max_buy_cost[job_id] = job_max_buy_cost
    #job_spec_est_buy_cost[job_id] = job_est_buy_cost
    """
    
    spec_ignored = False
    spec_error = ""
    
    if not (job_type == "priced" or job_type == "mission"):
      spec_ignored = True
      spec_error += ",JOB_TYPE"
    
    """
    if not spec_ignored:
      if team.max_inventory:
        avail_max_items = items_max_available(agent)
        if job_items != job_items & avail_max_items:
          spec_ignored = True
          spec_error += ",MAKE"
    """
    
    if not spec_ignored:
      if steps < JOB_NEW_MIN_STEPS:
        spec_ignored = True
        spec_error += ",STEPS"
    """
    if not spec_ignored:
      if job_est_buy_cost > buy_limit:
        spec_ignored = True
        spec_error += ",COST"
    
    if not spec_ignored:
      if reward - job_est_buy_cost < JOB_MIN_BALANCE:
        spec_ignored = True
        spec_error += ",BALANCE"
    """
    # TODO ... uncomment if enable CC_op
    #if CC_op_check(agent, reward, int(job_data.start), int(job_data.end), job_data.storage):
    #  spec_ignored = True
    #  spec_error += ",CC"
    
    system_jobs.add(job_id)
    if spec_ignored:
      team.job_spec_ignored_rewards += reward
      job_spec_ignored.add(job_id)
    else:
      team.job_spec_total_items_count += len(res_base)
      team.job_spec_total_items_amount += sum(res_base.values())
      team.job_spec_total_tools_count += len(res_tools)
      team.job_selection_rewards += reward
      selection_jobs.add(job_id)
      active_jobs.add(job_id)
      if job_type == "mission":
        active_missions.add(job_id)
    
    job_spec_checked.add(job_id)
    
    #log.log(LOG_OP, lambda: "{:d}, SPEC {:s} {:s}, min,max: {:d},{:d}, est: {:d} ~ {:d} (reward = {:d}{}), steps: {:d} ~ {:d}, {:s}{:s} !!!".format(
    #  step, job_id, job_type,
    #  job_min_buy_cost, job_max_buy_cost, job_est_buy_cost, buy_limit,
    #  reward, "" if job_type == "priced" else ", fine = " + job_data.fine,
    #  steps, JOB_NEW_MIN_STEPS,
    #  SPEC_STATE_S[spec_ignored], spec_error
    #))
    job_required_items = Counter({x.name: int(x.amount) for x in job_data.required.values()})
    log.log(LOG_OP, lambda: "{:d}, SPEC {:s} {:s}, e: {:d} r: {:d}{} steps: {:d} (~ {:d}), {:s}{:s} ({}) => ({}; {})".format(
      step, job_id, job_type, end_step, reward, ", f: " + job_data.fine if job_type == "mission" else "",
      steps, JOB_NEW_MIN_STEPS,
      SPEC_STATE_S[spec_ignored], spec_error,
      one_line_key_val_s(job_required_items),
      one_line_key_val_s(res_base), one_line_key_s(res_tools)
    ))



# simple procedures but avoid to access team variables directly
# kind of using the module as a class with methods

# NOTE: job_start must be first when a job is started
def job_start(agent, job_id, step):
  jobs_view = agent.view.jobs_view
  
  job_start_step[job_id] = step
  job_db[job_id] = jobs_view[job_id]
  
  job_party[job_id] = set()
  job_assemble_party[job_id] = set()
  job_delivery_party[job_id] = set()
  
  committed_jobs.add(job_id)
  scheduled_jobs.add(job_id)
  
  job_assembled[job_id] = False
  job_move_planned[job_id] = False
  job_move_completed[job_id] = False
  job_delivery_planned[job_id] = False
  job_completed[job_id] = False

def job_set_assemble_party(agent, job_id, party):
  job_party[job_id] = party
  job_assemble_party[job_id] = party

def job_set_delivery_party(agent, job_id, party):
  job_party[job_id] = party
  job_delivery_party[job_id] = party

# update job_opt base, assembled totals
# CE handles tools vs items correctly
def job_set_opt(agent, job_id, opt, opt_tools, assemble_steps):
  job_opt[job_id] = opt
  
  base_total = 0
  assembled_total = 0
  for item_name, item_amount in opt.items():
    if item_db[item_name].needs_assembly:
      assembled_total += item_amount
    else:
      base_total += item_amount
  
  job_opt_base_total[job_id] = base_total
  job_opt_assembled_total[job_id] = assembled_total
  job_opt_tool_total[job_id] = len(opt_tools.keys())
  
  job_required_total[job_id] = sum(opt.values())
  job_assemble_steps[job_id] = assemble_steps

def job_set_assembled(agent, job_id):
  job_assembled[job_id] = True

def job_set_move_planned(agent, job_id, move_slots, move_ops):
  job_move_planned[job_id] = True
  job_move_slots[job_id] = move_slots
  job_move_ops[job_id] = move_ops

def job_set_move_completed(agent, job_id):
  job_move_completed[job_id] = True

def job_set_delivery_planned(agent, job_id):
  job_delivery_planned[job_id] = True

# here completed means delivered and reward won
def job_set_completed(agent, job_id):
  log = agent._log
  
  # once only
  if job_completed[job_id]:
    log.log(LOG_OP, lambda: "CHECK-ERR:   job_set_completed, job_id: {} called more than once !!!".format(job_id))
    return
  
  log.log(LOG_OP, lambda: "CHECK-FLASH:   job_set_completed, job_id: {}".format(job_id))
  
  job_completed[job_id] = True
  completed_jobs.add(job_id)
  
  if job_id in committed_jobs:
    committed_jobs.remove(job_id)
  
  if job_id in active_missions:
    # must remove so no fine is added wrongly
    # and because it will really be removed next
    active_missions.remove(job_id)
    completed_missions.add(job_id)
  
  #if job_id in active_jobs:
  #  active_jobs.remove(job_id)
  
  # TODO..., verify that called once
  # update money
  add_job_reward(agent, job_id, success=True)
  update_money_stats(agent)
  
  # perf_stats
  print_job_perf_stats(agent, job_id, success=True)

# here failed means job finished by other team or removed from system
def job_set_failed(agent, job_id):
  log = agent._log
  
  # once only
  if job_failed[job_id]:
    log.log(LOG_OP, lambda: "CHECK-ERR:   job_set_failed, job_id: {} called more than once ?".format(job_id))
    return
  
  job_data = job_db[job_id]
  job_type = job_data.job_type
  reward = int(job_data.reward)
  
  log.log(LOG_OP, lambda: "CHECK-ERR:   job_set_failed,   {:d}, SPEC {:s} {:s}, reward = {:d} job removed".format(
    step, job_id, job_type, reward
  ))
  
  job_failed[job_id] = True
  failed_jobs.add(job_id)
  just_removed_jobs.add(job_id)
  
  if job_id in committed_jobs:
    committed_jobs.remove(job_id)
  
  if job_id in active_missions:
    active_missions.remove(job_id) # really unneccessary
    failed_missions.add(job_id)
  
  if job_id in active_jobs:
    active_jobs.remove(job_id)
  
  add_job_reward(agent, job_id, success=False)
  
  # perf_stats
  print_job_perf_stats(agent, job_id, success=False)

# means remove from committed jobs, may retry later
def job_set_removed(agent, job_id):
  log = agent._log
  
  log.log(LOG_OP, lambda: "CHECK-FLASH:   job_set_removed, job_id: {}".format(job_id))
  
  just_removed_jobs.add(job_id)
  
  if job_id in committed_jobs:
    committed_jobs.remove(job_id)
  
  # perf_stats
  print_job_perf_stats(agent, job_id, success=False)

def job_update_schedule_noitems(agent, job_id):
  job_schedule_noitems[job_id] += 1
  team.alljobs_schedule_noitems += 1

# also return True if move completed
def job_update_move(agent, job_id):
  log = agent._log
  
  log.log(LOG_OP, lambda: "job_update_move, job_id: {:s}, moved 1".format(job_id))
  job_move_count[job_id] += 1
  if job_move_count[job_id] == job_move_ops[job_id]:
    return True
  else:
    return False

# also return True if assembled
def job_update_assembled(agent, job_id, item_name):
  log = agent._log
  
  log.log(LOG_OP, lambda: "job_update_assembled, job_id: {:s}, assembled 1 {:s}".format(job_id, item_name))
  job_assemble_count[job_id] += 1
  if job_assemble_count[job_id] == (job_assemble_steps[job_id] * len(job_party[job_id])):
    return True
  else:
    return False

# also return True if delivered
def job_update_delivered(agent, job_id, pre_items, post_items):
  log = agent._log
  
  agent_name = agent._agent_name
  pre_items_counter = Counter({x.name: int(x.amount) for x in pre_items.values()})
  post_items_counter = Counter({x.name: int(x.amount) for x in post_items.values()})
  delivered = pre_items_counter - post_items_counter
  delivery_count = sum(delivered.values())
  log.log(LOG_OP, lambda: "job_update_delivered, job_id: {:s}, {:s} delivered: {:d} items".format(job_id, agent_name, delivery_count))
  job_delivery_count[job_id] += delivery_count
  if job_delivery_count[job_id] == job_required_total[job_id]:
    return True
  else:
    return False



def job_state_check(agent):
  log = agent._log
  shared = agent._shared
  
  for job_id in list(committed_jobs):
    party = job_party[job_id]
    active_agents = [name for name in party if shared[name].job_op is not None]
    if active_agents:
      continue
    
    if not job_assembled[job_id]:
      log.error(lambda: "CHECK-ERR:   job_state_check, job_id: {:s} ({}), not assembled, dropped !!!".format(
        job_id, one_line_key_s(party)
      ))
      job_set_removed(agent, job_id)
      continue
    
    """
    if util.MOVE_ENABLE:
      if not job_move_planned[job_id]:
        log.error(lambda: "CHECK-ERR:   job_state_check, job_id: {:s} ({}), not move planned, dropped !!!".format(
          job_id, one_line_key_s(party)
        ))
        job_set_removed(agent, job_id)
        continue
    
      if not job_move_completed[job_id]:
        log.error(lambda: "CHECK-ERR:   job_state_check, job_id: {:s} ({}), not move completed, enabled delivery !!!".format(
          job_id, one_line_key_s(party)
        ))
        job_set_move_completed(agent, job_id)
        continue
    """
    
    if not job_delivery_planned[job_id]:
      log.error(lambda: "CHECK-ERR:   job_state_check, job_id: {:s} ({}), not delivery planned, dropped !!!".format(
        job_id, one_line_key_s(party)
      ))
      job_set_removed(agent, job_id)
      continue
    
    if not (job_completed[job_id] or job_failed[job_id]):
      log.error(lambda: "CHECK-ERR:   job_state_check, job_id: {:s} ({}), not completed, dropped !!!".format(
        job_id, one_line_key_s(party)
      ))
      job_set_removed(agent, job_id)
      continue

# consistency checks
# handle correctly cases of random fails
# only for synchronized actions (assemble/assist_assemble, give/receive)
ACTION_NOACTION = "noAction"
ACTION_RANDOM_FAIL = "randomFail"
ACTION_UNKNOWN = "unknownAction"

ACTION_FAILS = [ACTION_NOACTION, ACTION_RANDOM_FAIL]

SYNCHRONIZED_ACTION_CLASS = {
  "assemble": "assemble",
  "assist_assemble": "assemble",
  "give": "move",
  "receive": "move"
}
def actions_state_check(agent):
  log = agent._log
  shared = agent._shared
  step = agent._step
  
  # random fail keys
  random_fails = set()
  # fail key by agent
  agent_fail = {}
  
  # initial scan, record all random fails related to synchronized ops
  for agent_name, agent_shared in shared.items():
    job_op = agent_shared.job_op
    if not job_op:
      continue
    
    # process only random fails, not (hard) fails
    # try to determine group affected and impact (for synchronized actions)
    # if there is a hard fail for other agents in the group caused by a random fail
    # it should be detected and their ops reset too
    # if the random fail happened before group operation then it is reset as usual (already in agent)
    # if the random fail did not stop the group operation then the op will be skipped
    # NOTE!!! an important assumption is that a random fail that stops the group operation
    # impacts the whole group (all agents) with some fail result
    # so no agent op is skipped when there is need to reset and retry for the whole group
    x = agent_shared.view.self.action
    percept_action = x.type
    percept_action_result = x.result
    if not percept_action in ACTION_FAILS:
      continue
    
    op_action = job_op.action()
    op_action_type = op_action._type
    if op_action_type not in SYNCHRONIZED_ACTION_CLASS:
      continue
    
    if not op_action._action_sent:
      continue
    
    job_id = op_action._job_id
    op_action_class = SYNCHRONIZED_ACTION_CLASS[op_action_type]
    fail_key = op_action_class + "-" + job_id
    # assemble
    if op_action_class == "assemble":
      assembler_shared = shared[op_action._assembler]
      fail_key = fail_key + "-" + op_action._assembler
      # percept action is last action sent
      if not (assembler_shared.failed or assembler_shared.view.self.action.type in ACTION_FAILS):
        # successful assembly
        log.log(LOG_OP, lambda: "CHECK-FLASH:   random fail, {:s} = {:s} key => completed successfully".format(agent_name, fail_key))
        ### NOTE: keep exact copy in agent.{local request-action}
        log.log(LOG_OP, lambda: "step = {:d}, action: {} finished".format(step, op_action))
        # update_shared
        op_action = job_op.action()
        op_action.update_shared(agent, "", "successful")
        # next action
        op_action = job_op.next_action()
        if op_action is None:
          log.log(LOG_OP, lambda: "step = {:d}, job has no more actions, deleted".format(step))
          agent_shared.job_op = None
        ### NOTE ###
      else:
        for party_member in job_party[job_id]:
          agent_fail[party_member] = fail_key
        random_fails.add(fail_key)
    # move(s) always fail since done in pairs
    if op_action_class == "move":
      giver = op_action._giver
      receiver = op_action._receiver
      fail_key = fail_key + "-" + giver + "-" + receiver
      agent_fail[giver] = fail_key
      agent_fail[receiver] = fail_key
      random_fails.add(fail_key)
  
  for fail_key in random_fails:
    log.log(LOG_OP, lambda: "CHECK-FLASH:   random fail, key = {:s}".format(fail_key))
  
  # second scan, fix random fails
  # all concurrent ops will have failed at this point
  # some with random fail, some without random fail
  # at the same time, record all other fails
  other_fail_agents = set()
  for agent_name, agent_shared in shared.items():
    job_op = agent_shared.job_op
    if not job_op:
      continue
    
    x = agent_shared.view.self.action
    percept_action = x.type
    percept_action_result = x.result
    if not (percept_action in ACTION_FAILS or agent_shared.failed):
      continue
    
    if agent_name not in agent_fail and agent_shared.failed:
      other_fail_agents.add(agent_name)
    
    op_action = job_op.action()
    op_action_type = op_action._type
    if op_action_type not in SYNCHRONIZED_ACTION_CLASS:
      if agent_name in agent_fail:
        log.log(LOG_OP, lambda: "CHECK-ERR!:   random fail, in party for key = {:s}, but no synchronized action for {:s} ({})".format(
          agent_fail[agent_name], agent_name, op_action
        ))
      continue
    
    op_action_class = SYNCHRONIZED_ACTION_CLASS[op_action_type]
    fail_key = op_action_class + "-" + op_action._job_id
    if op_action_class == "assemble":
      fail_key = fail_key + "-" + op_action._assembler
    if op_action_class == "move":
      fail_key = fail_key + "-" + op_action._giver + "-" + op_action._receiver
    
    if agent_name in agent_fail and fail_key not in random_fails:
      log.log(LOG_OP, lambda: "CHECK-ERR!:   random fail, {:s} = {:s} not key but in party for key = {:s}".format(
        agent_name, fail_key, agent_fail[agent_name]
      ))
    
    if agent_name not in agent_fail and fail_key in random_fails:
      log.log(LOG_OP, lambda: "CHECK-ERR!:   random fail, {:s} = {:s} key, not in party".format(
        agent_name, fail_key
      ))
    
    if fail_key not in random_fails:
      continue
    
    if not percept_action in ACTION_FAILS and percept_action_result == "successful":
      log.log(LOG_OP, lambda: "CHECK-ERR!:   random fail, {:s} = {:s} key, but successful".format(agent_name, fail_key))
    
    # fix at last, just action reset
    log.log(LOG_OP, lambda: "CHECK-FLASH:   random fail, {:s} = {:s} key, action reset".format(agent_name, fail_key))
    op_action.reset(agent_shared)
    # TODO..., hack !!!
    op_action._action_sent = False
  
  # handle all other fails
  for agent_name in other_fail_agents:
    agent_shared = shared[agent_name]
    job_op = agent_shared.job_op
    
    log.log(LOG_OP, lambda: "step = {:d}, fail for {:s}".format(step, agent_name))
    if job_op.recover(agent_shared):
      log.log(LOG_OP, lambda: "step = {:d}, job_op for {:s} successfully recovered".format(step, agent_name))
    else:
      op_action = job_op.action()
      #x_job_id = getattr(op_action, "_job_id", None)
      x_job_id = op_action._job_id
      if x_job_id:
        job_set_removed(agent, x_job_id)
      else:
        log.log(LOG_OP, lambda: "drop job_op for {:s}".format(agent_name))
        job_op.drop(agent)
        op_action = job_op.action()
        if op_action is None:
          log.log(LOG_OP, lambda: "drop job_op for {:s} has no more actions, deleted".format(agent_name))
          agent_shared.job_op = None



def drop_jobs(agent):
  for job_id in just_removed_jobs:
    job_drop(agent, job_id)
  just_removed_jobs.clear()

# NOTE: works on shared job_op(s)
# NOTE: must ensure that not overwritten, so not thread-safe but serializable
def job_drop(agent, job_id):
  log = agent._log
  shared = agent._shared
  
  if job_id not in job_party:
    log.log(LOG_OP, lambda: "CHECK-ERR:   job_drop, job_id: {:s}, job has never been active !!!".format(job_id))
    return
  
  log.log(LOG_OP, lambda: "job_drop, job_id: {:s}".format(job_id))
  
  party = job_party[job_id]
  
  for agent_name in party:
    agent_shared = shared[agent_name]
    job_op = agent_shared.job_op
    if job_op is not None:
      drop_p = False
      for op_action in job_op:
        # we must recheck just in case ...
        x_job_id = getattr(op_action, "_job_id", None)
        if x_job_id and x_job_id == job_id:
          drop_p = True
          break
      if drop_p:
        log.log(LOG_OP, lambda: "job_drop, job_id: {:s}, drop job_op for {:s}".format(job_id, agent_name))
        job_op.drop(agent)
        op_action = job_op.action()
        if op_action is None:
          log.log(LOG_OP, lambda: "job_drop, job_id: {:s}, drop job_op for {:s} has no more actions, deleted".format(job_id, agent_name))
          agent_shared.job_op = None



# update and print
def update_max_inventory(agent):
  log = agent._log
  
  if max_inventory:
    return
  
  inventory = attr_dict(agent.view.shop)
  team.max_inventory = inventory
  
  log.log(LOG_OP, lambda: "=== max inventory ===")
  for fac_id in sorted(inventory.keys(), key=natural_sort_key):
    fac_data = inventory[fac_id]
    log.log(LOG_OP, lambda: "{:s} => {}".format(
      fac_id,
      ";".join(" "+item_data.name+","+str(item_data.amount) for item_data in fac_data.item.values())
    ))
    log.log(LOG_OP, lambda: "")

# update and print
def update_resource_nodes(agent):
  log = agent._log
  
  agent_view = agent.view
  res_view = agent_view.get("resourceNode")
  if not res_view:
    return
  
  for res_id, res_data in res_view.items():
    resource_nodes[res_id] = res_data
  
  #log.info(lambda: "=== resource_nodes ===")
  #for res_id in sorted(resource_nodes.keys(), key=natural_sort_key):
  #  res_data = resource_nodes[res_id]
  #  log.info(lambda: "{:s} => {}".format(res_id, res_data.resource))
  log.debug(lambda: "=== resource_nodes ===")
  resource_nodes.log_data(log, LOG_OP)
  log.debug(lambda: "")

def update_action_stats(self, percept_action_result):
  action_stats[percept_action_result] += 1

def add_job_reward(agent, job_id, success=True):
  log = agent._log
  step = agent._step
  
  #if job_id not in job_db:
  #  log.log(LOG_OP, lambda: "CHECK-ERR:   add_job_reward,   {:d}, SPEC {:s} {:s}, job has been removed !!!".format(step, job_id))
  #  return
  
  job_data = job_db[job_id]
  job_type = job_data.job_type
  reward = int(job_data.reward)
  
  if success:
    team.rewards += reward
    log.log(LOG_OP, lambda: "CHECK-FLASH:   add_job_reward,   {:d}, SPEC {:s} {:s}, add reward = {:d} !!!".format(
      step, job_id, job_type, reward
    ))
  else:
    team.failed_rewards += reward
    if job_id in scheduled_jobs:
      log.log(LOG_OP, lambda: "CHECK-FLASH:   add_job_reward,   {:d}, SPEC {:s} {:s}, reward = {:d} scheduled job failed !!!".format(
        step, job_id, job_type, reward
      ))
      team.failed_scheduled_rewards += reward
    else:
      log.log(LOG_OP, lambda: "CHECK-FLASH:   add_job_reward,   {:d}, SPEC {:s} {:s}, reward = {:d} failed !!!".format(
        step, job_id, job_type, reward
      ))



# use both for explore buys or job buys
def update_buy_cost(agent, buy_cost, item_name, item_amount, fac_id, job_id=None, explore_tag=None):
  log = agent._log
  
  log.log(LOG_OP, lambda: "CHECK-FLASH:   update_buy_cost, ({:s}) {:s},{:d} => {:d}   {:s}{:s}".format(
    fac_id, item_name, item_amount, buy_cost, job_id, explore_tag
  ))
  
  if job_id and job_id in job_db:
    job_buy_cost[job_id] += buy_cost
    team.alljobs_buy_cost += buy_cost
  else:
    if explore_tag == "FORCE":
      team.explore_buy_forced_cost += buy_cost
    else:
      team.explore_buy_cost += buy_cost
  update_money_stats(agent)

def add_explore(agent_name):
  team.explore_count += 1
  explore_agents.add(agent_name)

def remove_explore(agent_name):
  if agent_name in explore_agents:
    explore_agents.remove(agent_name)

def add_retrieve_delivered(agent_name):
  team.retrieve_delivered_count += 1
  retrieve_delivered_agents.add(agent_name)

def remove_retrieve_delivered(agent_name):
  if agent_name in retrieve_delivered_agents:
    retrieve_delivered_agents.remove(agent_name)

def update_money_stats(agent):
  team.alljobs_cost = alljobs_buy_cost #+ alljobs_charge_cost + alljobs_recharge_cost
  team.explore_cost = explore_buy_forced_cost + explore_buy_cost #+ explore_charge_cost + explore_recharge_cost
  team.balance = rewards - alljobs_cost - explore_cost - fines
  team.money = seed + balance

def print_money_stats(agent):
  log = agent._log
  
  ###log.info(lambda: "=== money stats ===")
  log.info(lambda: "rewards = {:d}, cost = {:d} (job = {:d}, forced = {:d}, explore = {:d}, fines = {:d})".format(
    rewards, alljobs_cost + explore_cost + fines,
    alljobs_cost, explore_buy_forced_cost, explore_buy_cost, fines
  ))
  log.info(lambda: "balance = {:d}, money = {:d} (seed = {:d})".format(balance, money, seed))
  if money != agent._money:
    log.error(lambda: "CHECK-ERR:   team money {:d} != {:d} system money".format(money, agent._money))
  log.info(lambda: "explores = {:d}, per_step = {:.1f}   retrieves = {:d}".format(
    explore_count, explore_count/(step + 1), retrieve_delivered_count
  ))

def print_job_perf_stats(agent, job_id, success=None):
  log = agent._log
  step = agent._step
  
  job_data = job_db[job_id]
  job_type = job_data.job_type
  
  reward = int(job_data.reward)
  buy_cost = job_buy_cost[job_id]
  total_cost =  buy_cost #+ charge_cost + recharge_cost
  balance = reward - total_cost
  
  job_end = int(job_data.end)
  start_step = job_start_step[job_id]
  job_steps = job_end - start_step
  step = agent._step
  action_steps = step - start_step
  
  item_tries = job_schedule_noitems[job_id]
  
  log.info(lambda: "{:d}, SPEC {:s} {:s} {}, perf: steps = {:d} (of {:d}), item_tries = {:d}, balance = {:d} (reward = {:d}, cost = {:d})".format(
    step, job_id, job_type, "completed" if success else "failed",
    action_steps, job_steps, item_tries,
    balance, reward, total_cost
  ))

def job_QoS_stats(agent):
  log = agent._log
  
  avail_agents, active_agents, x_explore_agents, x_job_agents, x_retrieve_delivered_agents = partition_agents2(agent)
  
  log.info(lambda: "")
  log.info(lambda: "step = {:d}, agents: avail/active: {:d}/{:d}, explore/job/retrieve: {:d}/{:d}/{:d}".format(
    step, len(avail_agents), len(active_agents),
    len(x_explore_agents), len(x_job_agents), len(x_retrieve_delivered_agents)
  ))
  
  # round(100*len(selection_jobs)/max(len(system_jobs), 1))
  # round(100*len(failed_jobs)/max(len(selection_jobs), 1))
  # round(100*len(scheduled_jobs)/max(len(selection_jobs), 1))
  # round(100*len(completed_jobs)/max(len(scheduled_jobs), 1))
  log.info(lambda: "jobs QoS: system: {:d} => sel: {:d} ($ {:d}, ign $ {:d}) => failed: {:d} ($ {:d}), commit: {:d} (tries: {:d}) => c: {:d} f: {:d} ($ {:d})".format(
    len(system_jobs), len(selection_jobs), job_selection_rewards, job_spec_ignored_rewards,
    len(failed_jobs), failed_rewards,
    len(scheduled_jobs), alljobs_schedule_noitems,
    len(completed_jobs), len(scheduled_jobs) - len(completed_jobs), failed_scheduled_rewards
  ))
  log.info(lambda: "avg job: items: {:d} item_amount: {:d} job_amount: {:d} tools: {:d}".format(
    round(job_spec_total_items_count/max(len(selection_jobs), 1)),
    round(job_spec_total_items_amount/max(job_spec_total_items_count, 1)),
    round(job_spec_total_items_amount/max(len(selection_jobs), 1)),
    round(job_spec_total_tools_count/max(len(selection_jobs), 1))
  ))
  
  # list of (count, item1_volume1, name) sorted high to low, higher count, lower volume
  log.info(lambda: "item_spec (c/v1): {}".format(
    ";".join(" "+s[2]+","+str(s[0])+":"+str(s[1]) for s in item_spec_list)
  ))
  
  shop_count, shop_item_amount, shop_item_cost, shop_item_volume = shop_stats(agent)
  #items_list = sorted([
  #  (shop_item_volume[item_name], shop_item_cost[item_name], shop_item_amount[item_name], item_name)
  #  for item_name in shop_item_amount.keys()
  #])
  #log.info(lambda: "shops: {:d}, items(v/$/a): {} total(v/$/a): {:d}/{:d}/{:d}".format(
  #  len(shop_view.keys()), ";".join(" "+s[3]+":"+str(s[0])+"@"+str(s[1])+","+str(s[2]) for s in items_list),
  #  sum(shop_item_volume.values()), sum(shop_item_cost.values()), sum(shop_item_amount.values())    
  #))
  items_list = sorted([
    (shop_item_volume[item_name], shop_item_cost[item_name], shop_item_amount[item_name], item_name)
    for item_name in shop_item_amount.keys()
  ])
  log.info(lambda: "shops: {:d}, items(,a:v@$): {} total(a:v@$): {:d}:{:d}@{:d}".format(
    shop_count,
    # symbol-ology:   "," = amount, ":" = volume, "@" = price/cost
    ";".join(" "+s[3]+","+str(s[2])+":"+str(s[0])+"@"+str(s[1]) for s in items_list),
    sum(shop_item_amount.values()),
    sum(shop_item_volume.values()),
    sum(shop_item_cost.values())
  ))
  
  ###log.info(lambda: "")

# total shop stats, only for item_spec items
# return dict(s) shop_item_amount, shop_item_cost, shop_item_volume
def shop_stats(agent):
  log = agent._log
  
  shop_view = agent.view.shop
  
  shop_item_amount = defaultdict(int)
  shop_item_cost = defaultdict(int)
  shop_item_volume = defaultdict(int)
  for fac_id, fac_data in shop_view.items():
    for item_data in fac_data.item.values():
      item_name = item_data.name
      if item_name not in item_spec_dict:
        continue
      item_amount = int(item_data.amount)
      item_price = int(item_data.price)
      item_volume = item_db[item_name].volume
      shop_item_amount[item_name] += item_amount
      shop_item_cost[item_name] += item_amount * item_price
      shop_item_volume[item_name] += item_amount * item_volume
  return len(shop_view.keys()), shop_item_amount, shop_item_cost, shop_item_volume

def print_committed_status(agent):
  log = agent._log
  shared = agent._shared
  
  log.info(lambda: "===   committed jobs ({:d} of {:d} active jobs)   ===".format(
    len(committed_jobs), len(active_jobs)
  ))
  for job_id in committed_jobs:
    job_data = job_db[job_id]
    party = job_party[job_id]
    party_id_list = [shared[a]._id for a in party]
    log.info(lambda: "{:s}, e: {:d}, r/c: {:d}/{:d}, b/a: {:d}/{:d}, A: {} ({:d}/{:d}), D: {} ({:d}/{:d}), party: ({:d}) {}".format(
      job_id, int(job_data.end),
      int(job_data.reward), job_buy_cost[job_id],
      job_opt_base_total[job_id], job_opt_assembled_total[job_id],
      job_assembled[job_id], int(job_assemble_count[job_id]/max(len(job_assemble_party[job_id]), 1)), job_assemble_steps[job_id],
      job_delivery_planned[job_id], job_delivery_count[job_id], job_required_total[job_id],
      len(party_id_list), one_line_key_s(party_id_list)
    ))
  log.info(lambda: "===   active missions (c/f: {:d}/{:d})   ===".format(
    len(completed_missions), len(failed_missions)
  ))
  for job_id in active_missions:
    job_data = job_db[job_id]
    log.info(lambda: "{:s}, e: {:d}, r: {:d} f: {:d}".format(
      job_id, int(job_data.end), int(job_data.reward), int(job_data.fine)
    ))

def print_team_status(agent):
  log = agent._log
  shared = agent._shared
  
  log.log(LOG_OP, lambda: "========= STATUS =========")
  # TODO..., print last_action here ???
  log.log(LOG_OP, lambda: "=== agent state ===")
  for x_agent_name in sorted(shared.keys(), key=natural_sort_key):
    x_agent_shared = shared[x_agent_name]
    x_sim = x_agent_shared.sim
    x_view = x_agent_shared.view
    x_step = x_view.simulation.step
    x = x_view.self
    s = x_sim.role
    log.log(LOG_OP, lambda: "{}, {:s}({}), tool: {}, in: {}, r: {:d}, charge: {}/{}, load: {}/{} = {}".format(
      x_step, x_agent_name, x.role, one_line_key_s(s.tool), x.facility, len(x.route), x.charge, s.battery, x.load, s.load,
      ";".join(" "+s.name+","+str(s.amount) for s in x.self_items.values())
    ))
  log.log(LOG_OP, lambda: "=== agent ops ===")
  for x_agent_name in sorted(shared.keys(), key=natural_sort_key):
    job_op = shared[x_agent_name].job_op
    if job_op is not None:
      log.info(lambda: "{:s} => {}".format(x_agent_name, job_op))
  
  storage_view = agent.view.storage
  
  log.info(lambda: "=== pending retrieves ===")
  for storage, storage_data in storage_view.items():
    storage_items = storage_data.item
    if not storage_items:
      continue
    retrieve_counter = Counter({x.name: int(x.delivered) for x in storage_items.values() if "delivered" in x})
    log.info(lambda: "ready: {:s} => {}".format(storage, one_line_key_val_s(retrieve_counter)))

def print_end(agent):
  log = agent._log
  
  #  sim-result => ranking, score
  x = agent.sim_result
  log.info(lambda: "*** sim-end, ranking = {}, score = {}, action stats:{}\n".format(
    x.ranking, x.score, one_line_key_val_s(action_stats)
  ))

# run on import, must have no reference to agent object
def team_initialize():
  #log = agent._log
  #log.info(lambda: "team initialize")
  
  team.item_db = None
  team.tool_db = None
  
  # item spec
  # list of (count, -item1_volume1, name) sorted high to low, higher count, lower volume
  team.item_spec_list = []
  team.item_spec_dict = {}
  
  # data for all jobs ever worked by system (active ones in committed jobs)
  team.job_db = {}
  team.job_creat_step = {}
  team.job_start_step = defaultdict(int)
  
  team.job_assembled = defaultdict(bool)
  team.job_move_planned = defaultdict(bool)
  team.job_move_completed = defaultdict(bool)
  team.job_delivery_planned = defaultdict(bool)
  # delivered successfully and reward won
  team.job_completed = defaultdict(bool)
  # job finished by other team or removed from system
  team.job_failed = defaultdict(bool)
  
  # party of agents, there is party for
  # assembly and move(s), same party even though in move(s) fewer agents participate but for very few steps
  # delivery
  team.job_party = defaultdict(set)
  team.job_opt = defaultdict(Counter)
  team.job_opt_base_total = defaultdict(int)
  team.job_opt_assembled_total = defaultdict(int)
  team.job_opt_tool_total = defaultdict(int)
  
  team.job_assemble_party = defaultdict(set)
  team.job_assemble_steps = defaultdict(int)
  team.job_assemble_count = defaultdict(int)
  
  team.job_move_slots = defaultdict(int)
  team.job_move_ops = defaultdict(int)
  team.job_move_count = defaultdict(int)
  
  team.job_delivery_party = defaultdict(set)
  team.job_required_total = defaultdict(int)
  team.job_delivery_count = defaultdict(int)
  
  # shop_inventory = dict with key = name, value = 
  # data_step: step, data_agent: agent_name, data_item = [ name, amount, price ]
  #team.shop_inventory = None
  # initial inventory, 'shop' structure with max amount per item
  team.max_inventory = None
  
  # for CC_op
  #team.CC_op_last_step = 0
  
  # for SPEC
  ###team.job_spec_min_buy_cost = defaultdict(int)
  ###team.job_spec_max_buy_cost = defaultdict(int)
  ###team.job_spec_est_buy_cost = defaultdict(int)
  team.job_spec_checked = set()
  team.job_spec_ignored = set()
  # for selection jobs
  team.job_spec_total_items_count = 0
  team.job_spec_total_items_amount = 0
  team.job_spec_total_tools_count = 0
  
  # job stats, TODO... check updated and used
  team.job_schedule_noitems = defaultdict(int)
  team.job_buy_cost = defaultdict(int)
  #team.job_charge_cost = defaultdict(int)
  #team.job_recharge_cost = defaultdict(int)
  
  # all job totals
  team.alljobs_schedule_noitems = 0
  team.alljobs_buy_cost = 0 # total
  #team.alljobs_charge_cost = 0 # total
  #team.alljobs_recharge_cost = 0 # total
  team.alljobs_cost = 0
  # explores, TODO... check updated and used
  team.explore_count = 0
  team.explore_agents = set()
  team.explore_buy_forced_cost = 0
  team.explore_buy_cost = 0
  #team.explore_charge_cost = 0
  #team.explore_recharge_cost = 0
  team.explore_cost = 0
  #
  team.retrieve_delivered_count = 0
  team.retrieve_delivered_agents = set()
  
  # team money
  team.balance = 0 # can be negative
  team.rewards = 0
  team.seed = util.SEED_CAPITAL
  team.money = seed
  team.fines = 0
  team.job_selection_rewards = 0
  team.job_spec_ignored_rewards = 0
  team.failed_rewards = 0
  team.failed_scheduled_rewards = 0
  
  # team jobs
  team.system_jobs = set()
  team.selection_jobs = set()
  # currently committed jobs
  team.committed_jobs = set()
  # all jobs
  team.scheduled_jobs = set()
  team.completed_jobs = set()
  team.failed_jobs = set()
  # track just failed jobs so that can retrieve delivered and clean up
  team.just_removed_jobs = set()
  # all active jobs
  team.active_jobs = set()
  # track all active missions in order to calculate money and fines
  team.active_missions = set()
  team.completed_missions = set()
  team.failed_missions = set()
  
  # team management
  team.first_loop = True
  team.step = util.MAX_STEPS
  team.action_stats = defaultdict(int)
  
  # resource nodes
  team.resource_nodes = attr_dict()

team_initialize()