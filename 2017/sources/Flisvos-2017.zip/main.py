
"""

 /*
  * @(#) E.Sarmas   main.py 0.9_63 (2017-09-18)
  *
  * Author: E.Sarmas
  *
  * Created: 2017-04-06
  *
  * Description: Flisvos 2017 (MAPC 2017)
  *
  * Version: 0.9_63
  * Version-Date: 2017-09-18
  *
  * Version-Log:
  *   0.1_0 (2017-04-06)   copy from Flisvos-2016
  *   0.1_9 (2017-05-29)   rewrite so stable core and fewer changes per scenario/implementation
  *   0.6_0 (2017-06-01)   refactoring, new sim messages/info (except distance calcs), running
  *                        fewer import dependency chains, code moved to more appropriate modules
  *                        logging messages with lambda: now, may speed up logging
  *                        single method to recursively decode messages
  *                        log_data moved within attr_dict as instance method
  *                        clear agent action handling/protocol and procedures/statistics/logging level use
  *                        removed items_db, jobs_spec moved in team
  *                        simple class method like procedures for data updates within appropriate module
  *                        clearer procedure interrelationships, existence and use
  *                        cache improvement to be useful for all roles
  *                        cleaner use of JOB_STEPS_FAC so no double use and wrong results
  *                        clearer method use protocol and use of other procedures for data updates
  *                        agents_with_item_on_board and agents_with_item_buy removed and embedded
  *                        introduced deliver_jobs and explore_buys
  *                        jobs_selection does not select but returns base recipe for all not ignored jobs
  *                        new_jobs now setups assembly or marks for delivery already assembled job
  *                        deliver_jobs may arrange first moves (give and take) to fewer and faster agents
  *   0.9_50 (2017-09-03)  qualification run, new_jobs/deliver_jobs/explore_buys disabled
  *   0.9_52 (2017-09-05)  added EXERCIZE_MODE as in qualification to test goto/charge/recharge system
  *                        ability to recover a job_op, for op_goto to recover from battery stalls by
  *                        recharging enough steps for next charging station and then going to destination
  *                        new dist_cache_history, random fail steps not counted
  *                        lowered level of all goto steps calculations
  *                        random fails don't stop op_goto(s) (bad interaction of reset/send_action )
  *                        also handled correctly if happen on first step of action
  *                        fixed job_op drop and job_drop confusion
  *                        new job_data[], SPEC tracks missions and removes fine from money
  *                        better handling of actions that indicate errors (ACTION_ERRORS)
  *                        new action retrieve_delivered and procedure retrieve_delivered in plan
  *                        new dict job_failed, and sets failed_jobs, just_failed_jobs
  *                        clearer actions for job_set_completed and job_set_failed (new), update_jobs_spec
  *                        reassigned role of job_db, new dict job_party
  *                        new procedures single_recharge and single_recharge_goto for faster recharge
  *                        creat can be called with agent in charging_station in future (with charge_level)
  *                        explore_jobs works without jobs and uses tool compatibility
  *                        along with mission and priced job needs in a useful order
  *                        refactored explore_jobs setup merging all loops, and removed shop_estimate
  *                        organized job work in phases (assembly, move, delivery)
  *                        move phase orchestrates give->receive to fewer better fit agents to deliver_jobs
  *                        and works like cpu instruction scheduling filling empty slots when needed
  *                        jobs_selection finally embedded within explore_jobs
  *                        explore_jobs considers better the suitability of each shop to finish jobs
  *                        and considers agent tool_compatibility better, and also global tool cover
  *                        socket timeout to 20 sec, never low value
  *                        enhanced strategy for CHECK-ERR asserts and other CHECK-... almost everywhere
  *                        is the fastest way to verify coverage and correct operation
  *                        changed logging levels everywhere so comfortable view of logging output
  *                        new failed action recovery logic, improved recover and drop functions 
  *                        checked all actions to send an action to server
  *                        new action.has_next() and use of next_action() only after barrier
  *                        so job_drop() works correctly with current action inside barrier
  *                        strange float calcs fixed (FLOAT_EP)
  *                        new job_state_check and actions_state_check, set jobs to drop (just_failed_jobs)
  *                        disabled move operations (give->receive to fewer and faster agents)
  *                        because not so important and code not tested well for crashes and more...
  *                        explore_buys only if no concurrent buy in same shop and only for items
  *   0.9_xx (2017-09-15)  first real run with assembly and delivery !, bug fixes until day 1
  *   0.9_63 (2017-09-18)  good luck :) 
  *   0.9_63b (2017-09-19) many enhancements, better info and easier display of it
  *                        more standard way of log messages
  *                        fixed bug for 1st entry in dist_cache
  *                        new parameters and enforcement of others so
  *                        to limit explores and more balanced spread of agents in shops
  *                        so agents be ready for jobs
  *                        better management of explore_buys which proved very useful
  *                        now explores and their agents are tracked
  *                        new_jobs can now use explore agents if they have items on board !
  *   0.9_63c (2017-09-20) 
  *   0.9_63e (2017-09-21) last bug fixes, more and better stats, more tuning parameters, tons of asserts
  *                        still not tested well and not tuned especially regarding
  *                        assignment of agents to shops and proactive buying of items (explore_buys)
  *                        which often resulted in item starvation, slow job start and job misses
  *                        surprisingly the code that decides when to work on a job, how to assemble
  *                        and deliver it works very well (even with partial ready assembled items)
  *                        and no changes have been made to it for days (pfew)
  *                        stable, fast acting and reliable agent system but with not tuned operation
  *                        and not handling auctions at all (higher rewards than priced jobs)
  *                        while missions are handled perfectly but are few
  */

"""

VERSION_STR = "Flisvos 2017   0.9_63e (2017-09-18) good luck :)"



import logging
import argparse
import threading
import sys

import agent
import main



LOGFILE_PREFIX = "agent-"
#LOGFILE_FORMAT = "%(asctime)s %(name)s:%(process)d-%(thread)d %(levelname)s   %(message)s"
LOGFILE_FORMAT = "%(asctime)s %(name)9s: %(levelname)8s %(message)s"
CONSOLE_FORMAT = "%(name)9s: %(levelname)8s %(message)s"

# DETAIL < DEBUG <   OP < INFO   < WARNING+
# agent log file =   LOG_DEBUG or LOG_DETAIL (verbose)
# main  log file =   LOG_OP
# console        =   LOG_INFO

LOG_CRITICAL = 50
LOG_ERROR = 40
LOG_WARNING = 30
LOG_INFO = 20
LOG_DEBUG = 10
LOG_NOTSET = 0

LOG_OP = 19
LOG_OP_STR = "OP"

LOG_DETAIL = 9
LOG_DETAIL_STR = "DETAIL"



VERBOSE = False

###

"""

TEAM = "Flisvos-2017"

#HOST = 'agentcontest2.in.tu-clausthal.de'
HOST = 'agentcontest1.in.tu-clausthal.de'
PORT = 12300

AGENT_PREFIX = "Flisvos"
PASSWORD = "EciuynRi"

NUM_AGENTS = 28

"""

HOST = "localhost"
PORT = 12300

AGENT_PREFIX = "a"
PASSWORD = "1"

NUM_AGENTS = 28


###

PROJECT_FILES = ["main.py", "comm.py", "agent.py", "util.py", "goto.py", "actions.py", "plan.py", "team.py"]

# time after which switch to new thread
# in sec, default is 0.005 (5 ms)
SWITCH_TIME = 0.010 # 10 ms
sys.setswitchinterval(SWITCH_TIME)

SETTINGS_FILE = "settings.py"

def _main_():
  
  print()
  
  ###global VERBOSE, AGENT_PREFIX, PASSWORD, NUM_AGENTS, HOST, PORT
  
  args_parser = argparse.ArgumentParser()
  # action=, nargs=, const=, default=, type=, choices=, required=, help=, metavar=, dest=
  args_parser.add_argument('-V', '--version', action='store_true')
  args_parser.add_argument('-v', '--verbose', action='store_true')
  args_parser.add_argument('-a', '--agent_prefix', action='store')
  args_parser.add_argument('-pw', '--password', action='store')
  args_parser.add_argument('-n', '--num_agents', type=int, action='store')
  args_parser.add_argument('-H', '--host', action='store')
  args_parser.add_argument('-P', '--port', type=int, action='store')
  args_parser.add_argument('-f', '--settings', action='store')
  args = args_parser.parse_args()
  
  if args.version:
    print(VERSION_STR)
    sys.exit(0)
  if args.verbose:
    main.VERBOSE = True
  if args.agent_prefix:
    main.AGENT_PREFIX = args.agent_prefix
  if args.password:
    main.PASSWORD = args.password
  if args.num_agents:
    main.NUM_AGENTS = args.num_agents
  if args.host:
    main.HOST = args.host
  if args.port:
    main.PORT = args.port
  if args.settings:
    main.SETTINGS_FILE = args.settings
  
  logging.addLevelName(LOG_DETAIL, LOG_DETAIL_STR)
  logging.addLevelName(LOG_OP, LOG_OP_STR)
  
  log = logging.getLogger()
  log.setLevel(LOG_OP)
  # must set !
  #if main.VERBOSE:
  #  log.setLevel(LOG_DETAIL)
  #else:
  #  log.setLevel(logging.DEBUG)
  
  # main log file gets LOG_OP
  main_logfile = logging.FileHandler(filename = "main-"+main.AGENT_PREFIX+".log", mode = "w")
  main_logfile.setLevel(LOG_OP)
  main_logfile.setFormatter(logging.Formatter(LOGFILE_FORMAT))
  log.addHandler(main_logfile)
  
  # console gets LOG_INFO
  console = logging.StreamHandler()
  console.setLevel(logging.INFO)
  console.setFormatter(logging.Formatter(CONSOLE_FORMAT))
  log.addHandler(console)
  
  # main start
  log.info("")
  log.info(VERSION_STR)
  log.info("")
  log.info("started logging... (level = {})".format(log.getEffectiveLevel()))
  log.info("VERBOSE = {}".format(main.VERBOSE))
  log.info("AGENT_PREFIX = {:s}".format(main.AGENT_PREFIX))
  log.info("PASSWORD = {:s}".format(main.PASSWORD))
  log.info("NUM_AGENTS = {:d}".format(main.NUM_AGENTS))
  log.info("HOST = {:s}".format(main.HOST))
  log.info("PORT = {:d}".format(main.PORT))
  log.info("")
  
  shared = {}
  agents = [
    agent.Agent(i, main.HOST, main.PORT, main.AGENT_PREFIX + str(i), main.PASSWORD, shared, main.VERBOSE)
    for i in range(1, main.NUM_AGENTS+1)
  ]
  for a in agents:
    a.start()
  sys.exit(0)
  """
  # thread test code
  while True:
    time.sleep(1)
    t_list = threading.enumerate()
    print(time.time(), "threads =", len(t_list))
    print()
    if len(t_list) == 1 and t_list[0] == threading.main_thread():
      print("only main thread remained !")
    # just main thread
    if len(t_list) == 1:
      break
  """

if __name__ == "__main__":
  _main_()