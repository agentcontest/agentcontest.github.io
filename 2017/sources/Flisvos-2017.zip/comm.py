
"""

 /*
  * @(#) E.Sarmas   comm.py 0.9_63 (2017-09-18)
  *
  * Author: E.Sarmas
  *
  * Created: 2017-04-06
  *
  * Description: Flisvos 2017 (MAPC 2017)
  *
  * Version: 0.9_63
  * Version-Date: 2017-09-18
  *
  * Version-Log:
  *   0.1_0 (2017-04-06)   copy from Flisvos-2016
  *   0.1_9 (2017-05-29)   rewrite so stable core and fewer changes per scenario/implementation
  *   0.6_0 (2017-06-01)   refactoring, new sim messages/info (except distance calcs), running
  *                        fewer import dependency chains, code moved to more appropriate modules
  *                        logging messages with lambda: now, may speed up logging
  *                        single method to recursively decode messages
  *                        log_data moved within attr_dict as instance method
  *                        clear agent action handling/protocol and procedures/statistics/logging level use
  *                        removed items_db, jobs_spec moved in team
  *                        simple class method like procedures for data updates within appropriate module
  *                        clearer procedure interrelationships, existence and use
  *                        cache improvement to be useful for all roles
  *                        cleaner use of JOB_STEPS_FAC so no double use and wrong results
  *                        clearer method use protocol and use of other procedures for data updates
  *                        agents_with_item_on_board and agents_with_item_buy removed and embedded
  *                        introduced deliver_jobs and explore_buys
  *                        jobs_selection does not select but returns base recipe for all not ignored jobs
  *                        new_jobs now setups assembly or marks for delivery already assembled job
  *                        deliver_jobs may arrange first moves (give and take) to fewer and faster agents
  *   0.9_50 (2017-09-03)  qualification run, new_jobs/deliver_jobs/explore_buys disabled
  *   0.9_52 (2017-09-05)  added EXERCIZE_MODE as in qualification to test goto/charge/recharge system
  *                        ability to recover a job_op, for op_goto to recover from battery stalls by
  *                        recharging enough steps for next charging station and then going to destination
  *                        new dist_cache_history, random fail steps not counted
  *                        lowered level of all goto steps calculations
  *                        random fails don't stop op_goto(s) (bad interaction of reset/send_action )
  *                        also handled correctly if happen on first step of action
  *                        fixed job_op drop and job_drop confusion
  *                        new job_data[], SPEC tracks missions and removes fine from money
  *                        better handling of actions that indicate errors (ACTION_ERRORS)
  *                        new action retrieve_delivered and procedure retrieve_delivered in plan
  *                        new dict job_failed, and sets failed_jobs, just_failed_jobs
  *                        clearer actions for job_set_completed and job_set_failed (new), update_jobs_spec
  *                        reassigned role of job_db, new dict job_party
  *                        new procedures single_recharge and single_recharge_goto for faster recharge
  *                        creat can be called with agent in charging_station in future (with charge_level)
  *                        explore_jobs works without jobs and uses tool compatibility
  *                        along with mission and priced job needs in a useful order
  *                        refactored explore_jobs setup merging all loops, and removed shop_estimate
  *                        organized job work in phases (assembly, move, delivery)
  *                        move phase orchestrates give->receive to fewer better fit agents to deliver_jobs
  *                        and works like cpu instruction scheduling filling empty slots when needed
  *                        jobs_selection finally embedded within explore_jobs
  *                        explore_jobs considers better the suitability of each shop to finish jobs
  *                        and considers agent tool_compatibility better, and also global tool cover
  *                        socket timeout to 20 sec, never low value
  *                        enhanced strategy for CHECK-ERR asserts and other CHECK-... almost everywhere
  *                        is the fastest way to verify coverage and correct operation
  *                        changed logging levels everywhere so comfortable view of logging output
  *                        new failed action recovery logic, improved recover and drop functions 
  *                        checked all actions to send an action to server
  *                        new action.has_next() and use of next_action() only after barrier
  *                        so job_drop() works correctly with current action inside barrier
  *                        strange float calcs fixed (FLOAT_EP)
  *                        new job_state_check and actions_state_check, set jobs to drop (just_failed_jobs)
  *                        disabled move operations (give->receive to fewer and faster agents)
  *                        because not so important and code not tested well for crashes and more...
  *                        explore_buys only if no concurrent buy in same shop and only for items
  *   0.9_63 (2017-09-18)  good luck :) 
  */

"""



import xml.etree.ElementTree as etree
import socket
#import sys
import logging

import util



# DETAIL < DEBUG <   OP < INFO   < WARNING+
# agent log file =   LOG_DEBUG or LOG_DETAIL (verbose)
# main  log file =   LOG_OP
# console        =   LOG_INFO

LOG_DEBUG = 10
LOG_DETAIL = 9



#LapTimer = util.LapTimer
Smart_Log = util.Smart_Log
attr_dict = util.attr_dict
one_line_key_val_s = util.one_line_key_val_s



"""

must reconnect

protocol

  AUTH-REQUEST -> AUTH-RESPONSE
  SIM-START
  REQUEST-ACTION -> ACTION
  SIM-END
  BYE
  
  timestamp: ms since 1/1/1970
  
  <?xml version="1.0" encoding="UTF-8"?>
  <message timestamp="10001980000000" type="request-action">
    <!-- optional data -->
  </message>
  
  types: auth-request, auth-response, sim-start, sim-end, bye, request-action, action
  responses can omit timestamp=
  
  <?xml version="1.0" encoding="UTF-8" standalone="no"?>
  <message type="auth-request">
    <auth-request username="a1" password="1"/>
  </message>
  
  <?xml version="1.0" encoding="UTF-8" standalone="no"?>
  <message timestamp="1297263037617" type="auth-response">
    <authentication result="ok"/> ok or fail
  </message>
  
  <?xml version="1.0" encoding="UTF-8" standalone="no"?>
  <message timestamp="1489763697332" type="sim-start">
    <simulation name="agent-name" id="2017-QuickTest-Sim" map="london"
                seedCapital="10" steps="1000" team="A"
                minLat="1.1" maxLat="1.2" minLon="2.1" maxLon="2.3"
                centerLat="1.15" centerLon="2.2" cellSize="500" proximity="0.00001">
      <role battery="500" load="1000" name="SampleRole" speed="10">
        <tool name="tool0"/>
        <tool name="tool2"/>
      </role>
      <item name="item0" volume="72"/>
      <item name="item14" volume="0">
        <item amount="2" name="item12"/>
        <item amount="1" name="item8"/>
        <tool name="tool5"/>
        <tool name="tool2"/>
      </item>
    </simulation>
  </message>
  
  <?xml version="1.0" encoding="UTF-8" standalone="no"?>
  <message timestamp="1297269179279" type="sim-end">
    <sim-result ranking="2" score="9"/>
  </message>
  
  <?xml version="1.0" encoding="UTF-8" standalone="no"?>
  <message timestamp="1489763697397" type="request-action">
    <percept deadline="1489763701395" id="0">
      <simulation step="0"/>
      <self lat="51.4675" lon="-0.06057" facility="shop1" charge="101" load="5" name="a1" role="SampleRole" team="A">
        <action result="successful" type="skip"/>
        <items amount="4" name="item0"/>
        <items amount="1" name="tool1"/>
        <route i="0" lat="51.4739" lon="-0.06657"/>
        <route i="1" lat="51.47384" lon="-0.07346"/>
        <route i="2" lat="51.47379" lon="-0.08041"/>
        <route i="3" lat="51.47349" lon="-0.08759"/>
        <route i="4" lat="51.47452" lon="-0.09439"/>
        <route i="5" lat="51.47704" lon="-0.10037"/>
        <route i="6" lat="51.4777" lon="-0.10676"/>
      </self>
      <team money="10"/>
      
      <entity lat="51.4659" lon="-0.1035" name="agentB3" role="SampleRole" team="B"/>
      
      <shop lat="51.4861" lon="-0.1477" name="shop1" restock="3">
        <item amount="8" name="tool7" price="211"/>
        <item amount="10" name="item0" price="217"/>
      </shop>
      
      <workshop lat="51.4983" lon="-0.0356" name="workshop3"/>
      
      <chargingStation lat="51.5182" lon="-0.0361" name="chargingStation6" rate="88"/>
      
      <dump lat="51.5163" lon="-0.1588" name="dump2"/>
      
      <storage lat="51.4906" lon="-0.0825" name="storage6" totalCapacity="9277"
               usedCapacity="0">
        <item delivered="3" name="item0" stored="0"/>
      </storage>
      
      <resourceNode lat="51.478" lon="-0.03632" name="resourceNode1" resource="item7"/>
      
      <job start="59" end="159" id="job0" reward="5018" storage="storage2">
        <required amount="3" name="item0"/>
      </job>
      
      <auction auctionTime="5" start="10" end="100" fine="500" id="job2"
               lowestBid="20" reward="1000" storage="storage0">
        <required amount="777" name="item0"/>
      </auction>
      
      <posted start="30" end="156" id="job11" reward="6546" storage="storage8">
        <required amount="3" name="item0"/>
      </posted>
      
      <mission auctionTime="0" start="10" end="100" fine="500" id="job2"
               lowestBid="1000" reward="1001" storage="storage0">
        <required amount="42" name="item1"/>
      </mission>
      
    </percept>
  </message>
  
  # id in REQUEST-ACTION before deadline !!!
  <?xml version="1.0" encoding="UTF-8" standalone="no"?>
  <message type="action">
    <action id="0" type="goto">
      <p>51.6</p>
      <p>11.4</p>
    </action>
  </message>
  
  types =
  
  goto                facility= or lat=, lon=       # to another location or facility (not resource node !!!)
                                                    # cost = battery charge
  buy                 item=, amount=                # inside shop
  give                agent=, item=, amount=        # to a teammate
  receive                                           # from teammates (can receive from many in same step)
  store               item=, amount=                # inside storage facility
  retrieve            item=, amount=                # stored at storage facility
  retrieve_delivered  item=, amount=                # delivered at storage facility
                                                    # can retrieve partial deliveries of unsuccesful job !!!
  dump                item=, amount=                # inside dump facility
  assemble            item=                         # inside workshop
  assist_assemble     assembler=                    # assist teammate
  deliver_job         job=                          # inside storage facility
  charge                                            # inside charging station
  bid_for_job         job=, bid=                    # anywhere
  post_job            reward=, duration=, storage=, item1=, amount1=, ...
  recharge                                          # solar panels, slowly
  gather                                            # item from resource node
  continue                                          # ongoing action (goto or charge) is continued
  skip                                              # same as continue
  abort                                             # does nothing, stops ongoing actions
  
  unknownAction, randomFail, noAction
  action results =
  
  successful
  
  failed_wrong_param
  failed_unknown_facility   goto
  failed_no_route           goto, continue, skip
  failed_unknown_item       give, store, retrieve*, assemble, buy, post_, dump
  failed_item_amount        give, store, retrieve*, assemble, buy, post_, dump
  failed_capacity           give, store, retrieve*, assemble, buy, gather
  failed                    store
  failed_item_type          assemble
  failed_tools              assemble, assist_
  failed_unknown_agent      assist_
  failed_counterpart        give, receive, assist_
  failed_location           give, store, retrieve*, assemble, assist_, buy,  deliver_, dump, charge, gather
  failed_wrong_facility     store, retrieve*, assemble, buy, post_, dump, charge, gather
  failed_facility_state     charge
  failed_unknown_job        deliver_, bid_
  failed_job_status         deliver_, bid_, post_
  failed_job_type           bid_
  successful_partial        deliver_
  useless                   deliver_
  partial_success           gather
  
  steps, map, minLon, maxLon, minLat, maxLat,
  proximity, cellSize (in m),
  postJobLimit (simultaneously active),
  gotoCost, rechargeRate, visibilityRange
  
  quadSize
  
  at most 1 tool of each type required
  
  message => type
    action => id, type
      p <>
  
  message => timestamp, type
  
  sim-end
    sim-result => ranking, score
  
  sim-start (sim)
    simulation => name, id, map, seedCapital, steps, team,
                  minLat, maxLat, minLon, maxLon,
                  centerLat, centerLon, cellSize, proximity
      role => name, speed, battery, load (name = car, drone, motorcycle, truck)
        tool => [ name ]
      item => [ name, volume,
        item => [ name, amount ]
        tool => [ name ]
      ]
  
  #
  # true order is
  #
  # "simData", "selfData", "teamData", "entityData",
  # "chargingStations", "dumps", "shops", "storage", "resourceNodes", "workshops",
  # "jobs", "auctions", "missions", "postedJobs"
  #
  request-action (view)
    percept => deadline, id
      simulation => step
      self => lat, lon, facility, charge, load, name, role, team,
        action => type, result
        items => [ name, amount ]
        route => [ i, lat, lon ]   # i = 0 ..
      team => money
      
      entity => lat, lon, name, role, team
      
      shop              =>   lat, lon, name, restock,
        item => name, amount, price
      workshop          =>   lat, lon, name
      chargingStation   =>   lat, lon, name, rate
      dump              =>   lat, lon, name
      storage           =>   lat, lon, name, totalCapacity, usedCapacity
        item => name, stored, delivered
      
      resourceNode      =>   lat, lon, name, resource
      
      job    => id, start, end, reward, storage,
        required => name, amount
      posted => id, start, end, reward, storage,
        required => name, amount
      
      auction => id, auctionTime, lowestBid, fine, start, end, reward, storage,
        required => name, amount
      mission => id, auctionTime, lowestBid?, fine, start, end, reward, storage,
        required => name, amount
      
"""

AUTH_REQUEST_XML = """\
<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<message type="auth-request">
  <auth-request username="test" password="test"/>
</message>"""

AUTH_REQUEST_TAG = "auth-request"
AUTH_REQUEST_USERNAME_ATTR = "username"
AUTH_REQUEST_PASSWORD_ATTR = "password"

AUTH_RESPONSE_TAG = "auth-response"
AUTH_RESPONSE_RESULT_ATTR = "result"
AUTH_RESPONSE_OK = "ok"

ACTION_XML = """\
<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<message type="action">
  <action/>
</message>"""

ACTION_TAG = "action"
ACTION_ID_ATTR = "id"
ACTION_TYPE_ATTR = "type"

MSG_TAG = "message"
MSG_TYPE_ATTR = "type"

RECV_SIZE = 1024

# NOTE: always keep high to handle server slowness
# if low value then will timeout before move to next step
# will go to barrier, release others and hold itself
# and soon may lead to "no action"(s)
# totally unpredictable
#SOCKET_TIMEOUT = 5
SOCKET_TIMEOUT = 20

#MSG_LOG_EXCLUDE_LIST = ["entities"]
MSG_LOG_EXCLUDE_LIST = None

VIEW_SELECT_TAGS = { "simulation", "self", "team", "entity", "shop", "workshop", "chargingStation", "dump", "storage", "resourceNode", "job", "posted", "auction", "mission" }
VIEW_TAG_KEY_NAME = { "entity":"name", "shop":"name", "workshop":"name", "chargingStation":"name", "dump":"name", "storage":"name", "resourceNode":"name", "item":"name", "job":"id", "posted":"id", "auction":"id", "mission":"id", "required":"name", "items":"name", "route":"i" }

SIM_SELECT_TAGS = { "role", "self", "item" }
SIM_TAG_KEY_NAME = { "item":"name", "tool":"name" }



# optionally asyncore, asynchat, select though no performance need
class Comm:
  
  def __init__(self, id, host, port, agent_name, password, verbose):
    self._log = Smart_Log(logging.getLogger(agent_name)) # may separate loggers
    self._id = id
    self._host = host
    self._port = port
    self._agent_name = agent_name
    self._password = password
    self._verbose = verbose
    self._s = None # socket
    self._connected = False
    self._msg_list = [] # receive buffer, list of (msg_element, msg_str)
  
  def connect(self):
    log = self._log
    s = None
    try:
      self._connected = False
      s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
      #log.debug("timeout was = {:.1f}".format(s.gettimeout()))
      s.settimeout(SOCKET_TIMEOUT)
      log.debug(lambda: "timeout set = {:.1f}".format(s.gettimeout()))
      log.debug(lambda: "connecting to {:s}:{:d} ...".format(self._host, self._port))
      s.connect((self._host, self._port))
      log.debug(lambda: "socket connected")
      self._s = s
      self._connected = True
      
      auth_req_msg = etree.fromstring(AUTH_REQUEST_XML)
      auth_element = auth_req_msg.find(AUTH_REQUEST_TAG)
      auth_element.attrib[AUTH_REQUEST_USERNAME_ATTR] = self._agent_name
      auth_element.attrib[AUTH_REQUEST_PASSWORD_ATTR] = self._password
      log.debug(lambda: "send authentication {:s} {:s}".format(self._agent_name, self._password))
      msg_b = etree.tostring(auth_req_msg)
      msg_str = str(msg_b, "utf-8")
      log.log(LOG_DETAIL, lambda: "\n=== message begin === {:d} chars\n{:s}\n=== message end   ===".format(len(msg_str), msg_str))
      s.sendall(msg_b + b"\0")
      
      res = self.receive()
      if res is None:
        raise Exception("did not get auth-response message")
      
      msg_element, msg_str = res
      auth_res_msg = None
      if msg_element.tag != MSG_TAG or msg_element.get(MSG_TYPE_ATTR) != AUTH_RESPONSE_TAG:
        raise Exception("expected auth-response message")
      auth_res_msg = msg_element.find(AUTH_RESPONSE_TAG)
      if auth_res_msg is None or auth_res_msg.get(AUTH_RESPONSE_RESULT_ATTR) != AUTH_RESPONSE_OK:
        raise Exception("authentication failed")
      
      log.debug(lambda: "server connected")
    except Exception as e:
      log.debug(lambda: "connection error: {:s}".format(str(e)))
      if self._s:
        self._s.close()
      self._s = None
      self._connected = False
  
  # return (msg_element, msg_str) element
  # may receive >= 2 xml in backlog so must buffer
  # check that is "message" element and has "type"
  def receive(self):
    log = self._log
    log.log(LOG_DETAIL, lambda: "receive()")
    if self._msg_list: # true if not None or not empty
      return self._msg_list.pop(0)
    res = ""
    while True:
      b_res1 = b""
      try:
        b_res1 = self._s.recv(RECV_SIZE)
      except Exception as e:
        log.debug(lambda: "recv() error: {:s}".format(str(e)))
      if b_res1 == b"":
        log.debug(lambda: "recv() side closed !")
        self._s.close()
        self._s = None
        self._connected = False
        return None
        log.log(LOG_DETAIL, lambda: "received {:d} bytes".format(len(b_res1)))
      res1 = str(b_res1, "utf-8")
      res = res + res1
      if res1[-1] == "\0":
        break
    res = res[:-1]
    res_list = res.split("\0")
    msg_list = []
    for msg_str in res_list:
      log.log(LOG_DETAIL, lambda: "\n=== message begin === {:d} chars\n{:s}\n=== message end   ===".format(len(msg_str), msg_str))
      try:
        msg_element = etree.fromstring(msg_str)
        if msg_element.tag != MSG_TAG or msg_element.get(MSG_TYPE_ATTR) is None:
          raise Exception("xml message is not \"{:s}\" with \"{:s}\"".format(MSG_TAG, MSG_TYPE_ATTR))
        msg_list.append((msg_element, msg_str))
      except Exception as e:
        log.debug(lambda: "bad message received")
    # if no valid message assume bad connection, we may get stuck in recv(), so abort connection
    if len(msg_list) == 0:
      self._s.close()
      self._s = None
      self._connected = False
      return None
    self._msg_list = msg_list
    return self._msg_list.pop(0)
  
  # returns (msg_type, parsed_data, msg_element, msg_str)
  def get_msg(self):
    log = self._log
    log.log(LOG_DETAIL, lambda: "get_mesg()")
    while True:
      while not self._connected:
        self.connect()
      res = self.receive()
      if res != None:
        #lap_timer = LapTimer(log)
        #lap_timer.lap_start()
        msg_element, msg_str = res
        msg_type = msg_element.get(MSG_TYPE_ATTR)
        data = self.decode_data(msg_element)
        data.log_data(log, LOG_DETAIL, MSG_LOG_EXCLUDE_LIST)
        #ela = lap_timer.lap("get_msg processing")
        return (msg_type, data, msg_element, msg_str)
  
  # msg must be b"..." of xml with b"\0" at end
  def send_msg(self, msg):
    log = self._log
    log.log(LOG_DETAIL, lambda: "send_msg()")
    if not self._connected:
      log.debug(lambda: "not connected, aborted !")
      return
    try:
      self._s.sendall(msg)
      log.log(LOG_DETAIL, lambda: "send ok")
    except Exception as e:
      log.debug(lambda: "sendall() error: {:s}".format(str(e)))
      self._s.close()
      self._s = None
      self._connected = False
  
  #def send_action(self, id, action, *args):
  #def send_action(self, id, action, **kwargs):
  # param_dict is OrderedDict and holds named parameters in order
  def send_action(self, id, action, param_dict=None):
    log = self._log
    log.log(LOG_DETAIL, lambda: "send_action {:s} {}".format(action, one_line_key_val_s(param_dict)))
    action_msg = etree.fromstring(ACTION_XML)
    action_element = action_msg.find(ACTION_TAG)
    action_element.attrib[ACTION_ID_ATTR] = id
    action_element.attrib[ACTION_TYPE_ATTR] = action
    #if kwargs:
      #param = " ".join(key+"="+value for key, value in kwargs.items())
      #action_element.attrib["param"] = param
    # in new style of parameter passing order matters
    if param_dict:
      for key, value in param_dict.items():
        x = etree.SubElement(action_element, "p")
        x.text = value
    msg_b = etree.tostring(action_msg)
    msg_str = str(msg_b, "utf-8")
    log.log(LOG_DETAIL, lambda: "\n=== message begin === {:d} chars\n{:s}\n=== message end   ===".format(len(msg_str), msg_str))
    self.send_msg(msg_b + b"\0")
  
  # single, attributes of element or tag contained within element
  @staticmethod
  def decode_attribs(element, root = None, q = None):
    if q is None:
      q = attr_dict()
    x = element
    if root:
      x = element.find(root)
    for attr, value in x.attrib.items():
      q[attr] = value
    return q
  
  # dict, attributes of all nested subtags
  @staticmethod
  def decode_nested_tags(element, root, key_name, select_tags = None, nested_tag_attrib_label = None):
    #q = []
    q = attr_dict()
    x = element
    if root:
      x = element.find(root)
    if x is not None:
      for s in list(x):
        tag = s.tag
        if select_tags is not None and tag not in select_tags:
          continue
        data = attr_dict()
        for attr, value in s.attrib.items():
          data[attr] = value
        if nested_tag_attrib_label is not None:
          data[nested_tag_attrib_label] = tag
        #q.append(data)
        q[getattr(data, key_name)] = data
    return q
  
  # dict, attributes of nested subtags in 'select_tags' list
  # goes down recursively with each nested subtag (without further selection)
  # each tag creates new dict, key for each tag from 'tag_key_name'
  # if tag has key then a new entry with key is created within tag (multiple)
  # if tag has no key then data are saved within tag entry (single)
  # first level tags always exist even if empty
  # if 'root_attribs' is True then root attributes are saved within root entry
  @staticmethod
  def decode_nested_tags_recursive(element, root, tag_key_name, select_tags, root_attribs = True, q = None):
    if q is None:
      q = attr_dict()
    x = element
    if root:
      x = element.find(root)
    if root_attribs:
      for attr, value in x.attrib.items():
        q[attr] = value
    if select_tags:
      for tag in select_tags:
        q[tag] = attr_dict()
    for s in list(x):
      tag = s.tag
      if select_tags and tag not in select_tags:
        continue
      data = attr_dict()
      #for attr, value in s.attrib.items():
      #  data[attr] = value
      Comm.decode_nested_tags_recursive(s, None, tag_key_name, None, True, data)
      key_name = tag_key_name.get(tag)
      if key_name:
        if tag not in q:
          q[tag] = attr_dict()
        q[tag][getattr(data, key_name)] = data
      else:
        q[tag] = data
    return q
  
  @staticmethod
  def decode_data(msg_element):
    data = attr_dict()
    data[MSG_TAG] = Comm.decode_attribs(msg_element)
    msg_type = data[MSG_TAG][MSG_TYPE_ATTR]
    #
    # sim-end
    #
    if msg_type == "sim-end":
      #  sim-result => ranking, score
      Comm.decode_attribs(msg_element, "sim-result", data)
    #
    # sim-start
    #
    if msg_type == "sim-start":
      """
      #  simulation => id, map, seedCapital, steps, team
      data["simulation"] = Comm.decode_attribs(msg_element, "simulation")
      #  role => name, speed, battery, load (name = car, drone, motorcycle, truck)
      data["role"] = Comm.decode_attribs(msg_element, "simulation/role")
      #  tool => [ name ]
      data["tool"] = Comm.decode_nested_tags(msg_element, "simulation/role", "name")
      #  item => [ name, volume,
      #    item => [ name, amount ]
      #    tool => [ name, amount ]
      #  ]
      data["item"] = Comm.decode_nested_tags_recursive(msg_element, "simulation", {"item":"name", "tool":"name"}, ["item"], False)["item"]
      """
      Comm.decode_nested_tags_recursive(msg_element, "simulation", SIM_TAG_KEY_NAME, SIM_SELECT_TAGS, True, data)
      if "tool" not in data.role:
        data["role"]["tool"] = attr_dict()
    #
    # request-action
    #
    if msg_type == "request-action":      
      """
      #  percept => deadline, id
      data["percept"] = Comm.decode_attribs(msg_element, "percept")
      #  simulation => step
      data["simulation"] = Comm.decode_attribs(msg_element, "percept/simulation")
      #  self => lat, lon, charge, load, name, role, team
      data["self"] = Comm.decode_attribs(msg_element, "percept/self")
      #  action => result, type
      data["action"] = Comm.decode_attribs(msg_element, "percept/self/action")
      #  items => [ name, amount ]
      #  route => [ i, lat, lon ]   # i = 0 ..
      # ...
      #  team => money
      data["team"] = Comm.decode_attribs(msg_element, "percept/team")
      #  entity => [ lat, lon, name, role, team ]
      data["entity"] = Comm.decode_nested_tags(msg_element, "percept", "name", ["entity"])      
      #  shop              =>   lat, lon, name, restock,
      #    item => name, amount, price
      data["shop"] = Comm.decode_nested_tags_recursive(msg_element, "percept", {"shop":"name", "item":"name"}, ["shop"])["shop"]      
      #  workshop          =>   lat, lon, name
      data["workshop"] = Comm.decode_nested_tags(msg_element, "percept", "name", ["workshop"])
      #  chargingStation   =>   lat, lon, name, rate
      data["chargingStation"] = Comm.decode_nested_tags(msg_element, "percept", "name", ["chargingStation"])
      #  dump              =>   lat, lon, name
      data["dump"] = Comm.decode_nested_tags(msg_element, "percept", "name", ["dump"])
      #  storage           =>   lat, lon, name, totalCapacity, usedCapacity
      #    item => name, stored, delivered
      data["storage"] = Comm.decode_nested_tags_recursive(msg_element, "percept", {"storage":"name", "item":"name"}, ["storage"])["storage"]
      #  job    => id, start, end, reward, storage,
      #    required => name, amount
      data["job"] = Comm.decode_nested_tags_recursive(msg_element, "percept", {"job":"id", "required":"name"}, ["job"]).get("job", attr_dict())
      #  posted => id, start, end, reward, storage,
      #    required => name, amount
      data["posted"] = Comm.decode_nested_tags_recursive(msg_element, "percept", {"posted":"id", "required":"name"}, ["posted"]).get("posted", attr_dict())
      #  auction => id, auctionTime, lowestBid, fine, start, end, reward, storage,
      #    required => name, amount
      data["auction"] = Comm.decode_nested_tags_recursive(msg_element, "percept", {"auction":"id", "required":"name"}, ["auction"]).get("auction", attr_dict())
      #  mission => id, auctionTime, lowestBid?, fine, start, end, reward, storage,
      #    required => name, amount
      data["mission"] = Comm.decode_nested_tags_recursive(msg_element, "percept", {"mission":"id", "required":"name"}, ["mission"]).get("mission", attr_dict())
      """
      Comm.decode_nested_tags_recursive(msg_element, "percept", VIEW_TAG_KEY_NAME, VIEW_SELECT_TAGS, True, data)
      # defaults, composite data
      request_default_values(data)
      request_jobs_view_combined(data)
      request_facilities_combined(data)
    return data

# default values for 'facility' and 'items'
def request_default_values(data):
  self = data.self
  if "facility" not in self:
    self["facility"] = "none"
  if "items" not in self:
    self["items"] = attr_dict()
  if "route" not in self:
    self["route"] = attr_dict()
  # rename 'items' to 'self_items'
  self["self_items"] = self["items"]
  del self["items"]

# combine 3 job types into a single view 'jobs_view'
def request_jobs_view_combined(data):
  jobs_view = attr_dict()
  priced_jobs = data.job
  for job_id, job_data in priced_jobs.items():
    job_data.job_type = "priced"
    jobs_view[job_id] = job_data
  auction_jobs = data.auction
  for job_id, job_data in auction_jobs.items():
    job_data.job_type = "auction"
    jobs_view[job_id] = job_data
  mission_jobs = data.mission
  for job_id, job_data in mission_jobs.items():
    job_data.job_type = "mission"
    jobs_view[job_id] = job_data
  data["jobs_view"] = jobs_view

# combine all facilities into a single view 'facilities'
# sets default values for 'item' if needed for shops and storages
def request_facilities_combined(data):
  facilities = attr_dict()
  shop = data.shop
  for fac_id, fac_data in shop.items():
    if "item" not in fac_data:
      fac_data["item"] = attr_dict()
    fac_data.facility_type = "shop"
    facilities[fac_id] = fac_data
  workshop = data.workshop
  for fac_id, fac_data in workshop.items():
    fac_data.facility_type = "workshop"
    facilities[fac_id] = fac_data
  chargingStation = data.chargingStation
  for fac_id, fac_data in chargingStation.items():
    fac_data.facility_type = "chargingStation"
    facilities[fac_id] = fac_data
  dump = data.dump
  for fac_id, fac_data in dump.items():
    fac_data.facility_type = "dump"
    facilities[fac_id] = fac_data
  storage = data.storage
  for fac_id, fac_data in storage.items():
    if "item" not in fac_data:
      fac_data["item"] = attr_dict()
    fac_data.facility_type = "storage"
    facilities[fac_id] = fac_data
  resourceNode = data.resourceNode
  for fac_id, fac_data in resourceNode.items():
    fac_data.facility_type = "resourceNode"
    facilities[fac_id] = fac_data
  data["facilities"] = facilities