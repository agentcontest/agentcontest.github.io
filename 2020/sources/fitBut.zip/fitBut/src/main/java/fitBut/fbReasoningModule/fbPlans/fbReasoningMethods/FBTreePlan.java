package fitBut.fbReasoningModule.fbPlans.fbReasoningMethods;

/**
 * @author : Vaclav Uhlir
 * @since : 25.9.2019
 **/
@Deprecated
public class FBTreePlan {
    int startStep;
    FBTreePlanNode rootNode;

}
