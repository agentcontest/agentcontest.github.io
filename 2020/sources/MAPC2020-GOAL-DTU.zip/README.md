# GOAL-DTU

## Installation
Please ensure that the newest version of the [GOAL Programming Language](https://goalapl.atlassian.net/wiki/spaces/GOAL/overview) is installed.

Download the eismassim-4.3-jar-with-dependencies.jar from the target folder located [in this github repository](https://github.com/Jonas-Weile/massim_2020/tree/target/eismassim) and place it in a local folder. 
The easiest solution is to place it inside the folder containing the source code. If placed elsewhere, ensure that MAPC.mas2g file has the correct path to the eismassim jar.

## How To run
Start the massim server as explained [here](https://github.com/agentcontest/massim_2020/blob/master/docs/server.md). Once the server is running, run the agent program from GOAL. 
When the agents are connected, press `enter` in the console from which the server was started in order to begin the simulation.